FORMAT: 1A
HOST: http://dev.sollar.com/api/v1/sales

# Invoice

A API de notas fiscais serve para cadastros/consultas/cadastro/deleções das notas fiscais



## Invoice collection [/invoices]

### Criar uma nova nota fiscal [POST]

É possível criar uma nota fiscal usando esta ação.

+ Request (application/json)
    + Attributes (invoicePost)

+ Response 201 (application/json)

    + Body

            {
                "id" : "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }
  
### Listar todas as notas fiscais [GET]

Retorna uma lista de todas as notas fiscais cadastradas

+ Response 200 (application/json)
    + Attributes (array[invoiceGet])



## Invoice [/invoices/{id}]

### Buscar uma nota fiscal [GET]

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id da nota fiscal

+ Response 200 (application/json)
    + Attributes (invoiceGet)

    
### Remover uma nota fiscal [DELETE]

Deleta uma nota fiscal

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id da nota fiscal
    
+ Request (application/json)

    + Body
    
            {
                "id": "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

+ Response 200



## Update invoice [/invoices/{id}/situation]

### Atualizar uma nota fiscal [POST]

É possível atualizar uma nota fiscal usando esta ação. Permitir atualizar apenas o relacionamento entre nota fiscal e situação da nota fiscal.

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id da nota fiscal
	
+ Request (application/json)
    + Attributes (updateInvoice)

+ Response 201 (application/json)

    + Body

            {
                "id" : "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

			
			
## Search invoice [/invoices/search]

### Buscar informações de uma nota fiscal [POST]

Busca por notas fiscais baseada nos filtros inseridos no corpo da requisição.

+ Request (application/json)
    
    + Attributes (invoiceSearch)
    
+ Response 200 (application/json)

    + Attributes (array[invoice])    
    
	
	
## Data structures

### invoiceGet
+ id:  `048d1734-4f8a-44df-be49-5612777b6535` (required) - Id nota fiscal
+ createdAt: `2017-07-13T13:52:21.107Z` - Data de criação da nota fiscal
+ updatedAt: `2017-07-13T13:52:21.107Z` - Data da ultima atualização  da nota fiscal
+ number: 10230 (string, required) - Número da nota fiscal
+ series: 12312 (string, required) - Série da nota fiscal
+ total: 1000.00 (number,required) - Valor total dos itens
+ note: Dados da nota fiscal foram enviados e está aguardando retorno do mesmo. (string) - Observação da nota
+ billingDate: `2017-01-01` - Data de faturamento da nota fiscal
+ invoiceCurrency (invoiceCurrency)
+ invoiceCustomer (invoiceCustomer)
+ invoiceLocation (invoiceLocation)
+ invoiceUser (invoiceUser)
+ paymentTerm (paymentTermGet)
+ invoiceSituation(invoiceSituationGet)
+ invoiceItems (array[invoiceItem])
+ invoiceType(invoiceTypeGet)


### invoicePost
+ number: 10230 (string, required) - Número da nota fiscal
+ series: 12312 (string, required) - Série da nota fiscal
+ total: 1000.00 (number,required) - Valor total dos itens
+ note: Dados da nota fiscal foram enviados e está aguardando retorno do mesmo. (string) - Observação da nota
+ billingDate: `2017-01-01` - Data de faturamento da nota fiscal
+ invoiceCurrency (invoiceCurrencyPost)
+ invoiceCustomer (invoiceCustomerPost)
+ invoiceLocation (invoiceLocationPost)
+ invoiceUser (invoiceUserPost)
+ paymentTerm (paymentTerm)
+ invoiceSituation(invoiceSituation)
+ invoiceItems (array[invoiceItemPost])
+ invoiceType(invoiceType)


### invoiceSearch
+ id:  `048d1734-4f8a-44df-be49-5612777b6535` - Id nota fiscal
+ currencyReplicatedId: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador da moeda
+ initialBillingDate: `2017-01-01` - Data de inicio(intervalo) para faturamento da nota fiscal
+ finalBillingDate: `2017-01-01` - Data de finalização(intervalo) para faturamento da nota fiscal
+ number: 10230 (string) - Número da nota fiscal
+ series: 12312 (string) - Série da nota fiscal
+ customerReplicatedId: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do cliente que fez a compra
+ locationReplicatedId: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do local do cliente
+ invoiceTypeId: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do tipo de nota fiscal
+ paymentTermId: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador da termo de pagamento
+ userReplicatedId: `048d1734-4f8a-44df-be49-5612777b6535`  - Identificador do usuário
+ invoiceSituationId: `048d1734-4f8a-44df-be49-5612777b6535` - id da situação da nota fiscal
+ invoiceSituationDescription: Cancelado (string) - Descrição da situação da nota fiscal
+ externalId: 351r3ew3r (string) - Id externo do ERP
  
  
### invoiceItem
+ id:  `048d1734-4f8a-44df-be49-5612777b6535` (required) - Id item da nota
+ createdAt: `2017-07-13T13:52:21.114Z` - Data de vinculo do item com a nota fiscal
+ updatedAt: `2017-07-13T13:52:21.114Z` - Data de atualização do vinculo do item com a nota fiscal
+ salesOrder (salesOrder)
+ totalValue: 19.99 (number,required) - valor total para esse item. Somatorio de quantity * unitValue
+ unitValue: 1.99 (number,required) - Valor unitário do produto
+ invoiceItemMeasureUnit (invoiceItemMeasureUnit)
+ quantity: 1 (number, required) - quantidade de produtos 
+ invoiceTypeItem(invoiceTypeItemGet)
+ invoiceItemProduct (invoiceItemProduct)
+ batch (string): Lote do produto


### invoiceItemPost
+ totalValue: 19.99 (number,required) - valor total para esse item. Somatorio de quantity * unitValue
+ unitValue: 1.99 (number,required) - Valor unitário do produto
+ quantity: 1 (number, required) - quantidade de produtos 
+ batch (string): Lote do produto
+ invoiceItemMeasureUnit (invoiceItemMeasureUnitPost)
+ invoiceItemProduct (invoiceItemProductPost)
+ salesOrder (salesOrderPost)
+ invoiceTypeItem(invoiceTypeItem)


### invoiceType
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de nota fiscal

### invoiceTypeGet
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de nota fiscal
+ createdAt: `2017-07-13T13:52:21.107Z` - Data do vinculo do tipo da nota fiscal com a nota
+ updatedAt: `2017-07-13T13:52:21.107Z` - Data da ultima atualização do vinculo do tipo da nota fiscal
+ description: Em processamento (string) - Descrição do tipo da nota fiscal
+ active: true (boolean) - Situação do tipo da nota fiscal

### invoiceTypeItem
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de nota fiscal

### invoiceTypeItemGet
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de nota fiscal
+ createdAt: `2017-07-13T13:52:21.107Z` - Data do vinculo do tipo do item da nota fiscal com a nota
+ updatedAt: `2017-07-13T13:52:21.107Z` - Data da ultima atualização do vinculo do tipo do item da nota fiscal
+ description: Em processamento (string) - Descrição do tipo da nota fiscal
+ active: true (boolean) - Situação do tipo da nota fiscal

### invoiceSituation
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - id da situação da nota fiscal

### invoiceSituationGet
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - id da situação da nota fiscal
+ createdAt: `2017-07-13T13:52:21.107Z` - Data de vinculo da situação com a nota fiscal
+ updatedAt: `2017-07-13T13:52:21.107Z` - Data da ultima atualização  da situação da nota fiscal
+ description: Em processamento (string) - Descrição da situação da nota fiscal
+ active: true (boolean) - Situação da situação da nota fiscal

### paymentTerm
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do tipo de nota fiscal

### paymentTermGet
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do tipo de nota fiscal
+ description: Nova condição de pagamento (string) - Descrição da condição de pagamento

### salesOrder
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do pedido
+ number: 6546540 - Número do pedido


### salesOrderPost
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do pedido


### updateInvoice
+ invoiceSituationId: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Id da situação da nota fiscal


### invoiceCurrency
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador da moeda do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador da moeda a ser replicada para o documento fiscal
+ description: Brazilian Real (string) - Descrição da moeda


### invoiceCustomer
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do cliente do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do cliente a ser replicada para o documento fiscal
+ name: João da Silva (string) - Nome replicado do cliente


### invoiceLocation
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador do local do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do local a ser replicada para o documento fiscal
+ description: Fazenda Silva - Descrição do local do cliente


### invoiceUser
+ id: `048d1734-4f8a-44df-be49-5612777b6535`  - Identificador do usuário do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do usuário a ser replicada para o documento fiscal
+ name:  João José (string) - Nome do usuário


### invoiceItemMeasureUnit
+ id: `048d1734-4f8a-44df-be49-5612777b6535` - Identificador da unidade de medida do item do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador da unidade de medida a ser replicada para o item do documento fiscal
+ description: quilo (string) - unidade de medida utilizada


### invoiceItemProduct
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do produto do item do documento fiscal
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do produto a ser replicado para o item do documento fiscal
+ description: produto001 (string) - Nome do produto


### invoiceCurrencyPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador da moeda a ser replicada para o documento fiscal
+ description: Brazilian Real (string) - Descrição da moeda


### invoiceCustomerPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do cliente a ser replicada para o documento fiscal
+ name: João da Silva (string) - Nome replicado do cliente


### invoiceLocationPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do local a ser replicada para o documento fiscal
+ description: Fazenda Silva - Descrição do local do cliente


### invoiceUserPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do usuário a ser replicada para o documento fiscal
+ name:  João José (string) - Nome do usuário


### invoiceItemMeasureUnitPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador da unidade de medida a ser replicada para o item do documento fiscal
+ description: quilo (string) - unidade de medida utilizada


### invoiceItemProductPost
+ replicatedId: `048d1734-4f8a-44df-be49-5612777b6535` (required)- Identificador do produto a ser replicado para o item do documento fiscal
+ description: produto001 (string) - Nome do produto



# group Specifications

## Criar uma nova nota fiscal
* Critérios de aceitação:
	* A data de faturamento da nota fiscal deve ser menor ou igual a data atual
	* O valor total da nota fiscal deve ser igual a soma do campo totalValue dos itens da nota
	* Para salvar a nota fiscal a mesma deve ter itens relacionados
	* Para calcular o valor total do produto(totalValue) : unitValue vezes quantity igual a totalValue
	* Para salvar uma nota fiscal é necessario possuir um tipo de nota fiscal
	* O tipo de nota fiscal informado na nota deve existir
	* Para salvar uma nota fiscal é necessario possuir uma situação de nota fiscal
	* A situação da nota fiscal informada na nota deve existir
	* O payment term se informado para a nota o mesmo deve existir
	* Quando informado uma unidade de medida para o item da nota a mesma deve existir
	* Quando informado um produto para o item da nota mesmo deve existir
	* Para salvar uma nota fiscal com itens o mesmo deve ter um tipo de item de nota fiscal
	* O tipo de item da nota fiscal informado para o item da nota deve existir
	* Quando informado o pedido para o item de nota fiscal o mesmo deve existir
	* O customer informado para a nota fiscal deve existir
	* Quando informado um local para a nota fiscal a mesma deve existir
	* O local quando informado para nota fiscal deve ser o mesmo do cliente
	* O usuário representante quando informado deve existir
	* A moeda quando informado para nota fiscal deve existir
	* O valor total da nota não pode ser negativo
	* O valor total do item não pode ser negativo
	* O valor unitario do item não pode ser negativo
	* A quantidade do item não pode ser negativo
	
## Atualizar nota fiscal
* Critérios de aceitação
	* A nota fiscal deve existir.
	* Permitir atualizar apenas o relacionamento entre nota fiscal e situação nota fiscal.
	* A situação informada deve existir.
	

	

