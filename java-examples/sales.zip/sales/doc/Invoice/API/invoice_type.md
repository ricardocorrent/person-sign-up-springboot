FORMAT: 1A
HOST: http://dev.sollar.com/api/v1/sales

# Invoice Type 

A API de tipo nota fiscal para definir qual o tipo de nota fiscal a fim de classificar as NF.

## Invoice type collection [/invoice-types]

### Criar um novo tipo de nota fiscal [POST]

� poss�vel criar um tipo nota fiscal usando esta a��o. 

+ Request (application/json)
    + Attributes (invoiceTypePost)

+ Response 201 (application/json)

    + Body

            {
                "id" : "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

			
### Listar todos os tipo de nota fiscal [GET]

Retorna uma lista de todas os tipos de nota fiscal no formato JSON.

+ Response 200 (application/json)
    + Attributes (array[invoiceType])
    
			
## Invoice type [/invoice-types/{id}]

### Buscar um tipo de nota fiscal [GET]

+ Parameters
    + id(required, UUID, `6fcb689a-3eef-11e7-a919-92ebcb67fe33`) ... Id tipo nota fiscal.

+ Response 200 (application/json)
    + Attributes (invoiceType)
    

### Remover um tipo de nota fiscal [DELETE]

Deleta um tipo de nota fiscal

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id do tipo de nota fiscal

+ Request (application/json) 

    + Body
    
            {
                "id": "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

+ Response 200

### Atualizar um tipo de uma nota fiscal [PUT]

 Atualiza um tipo de nota fiscal baseado na diferen�a entre as informa��es j� existentes e a informa��o enviada no formato JSON.
 
+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id do tipo da nota fiscal

+ Request (application/json)
    
    + Attributes (invoiceType)
    
+ Response 201

## Buscar tipos de notas fiscais [/invoice-types/search]

### Buscar informa��es de um tipo de nota fiscal [POST]

Busca por tipo de notas fiscais baseada nos filtros inseridos no corpo da requisi��o.

+ Request (application/json)
    
    + Attributes (invoiceType)
    
+ Response 200 (application/json)

    + Attributes (array[invoiceType])    

## Data structures

### invoiceType
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de nota fiscal
+ description: NFe (string, required) - Descri��o do tipo de nota fiscal
+ active: true (boolean,required) - Indica se o tipo est� ativo

### invoiceTypePost
+ description: NFe (string, required) - Descri��o do tipo de nota fiscal
+ active: true (boolean,required) - Indica se o tipo est� ativo