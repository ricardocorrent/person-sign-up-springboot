FORMAT: 1A
HOST: http://dev.sollar.com/api/v1/sales

# Invoice situation

A API de situa��o para nota fiscal serve para definir qual a situa��o da nota fiscal a fim definir seu status.

## Invoice situation collection [/invoice-situations]

### Criar uma nova situa��o de nota fiscal [POST]

� poss�vel criar uma situa��o para nota fiscal usando esta a��o. 

+ Request (application/json)
    + Attributes (invoiceSituationPost)

+ Response 201 (application/json)

    + Body

            {
                "id" : "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

			
### Listar todas as situa��es das notas fiscais [GET]

Retorna uma lista de todas as situa��os de nota fiscal no formato JSON.

+ Response 200 (application/json)
    + Attributes (array[invoiceSituation])
    
	
## Invoice situation [/invoice-situations/{id}]

### Buscar uma situa��o [GET]

+ Parameters
    + id(required, UUID, `6fcb689a-3eef-11e7-a919-92ebcb67fe33`) ... Id situa��o para notas fiscais.

+ Response 200 (application/json)
    + Attributes (invoiceSituation)

	
### Remover uma situa��o de nota fiscal [DELETE]

Deleta uma situa��o de nota fiscal

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id da nota fiscal

+ Request (application/json) 

    + Body
    
            {
                "id": "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

+ Response 200

### Atualizar informa��es de situa��o [PUT]

 Atualiza uma situa��o de nota fiscal baseado na diferen�a entre as informa��es j� existentes e a informa��o enviada no formato JSON.
 
+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id da nota fiscal

+ Request (application/json)
    
    + Attributes (invoiceSituation)
    
+ Response 201


## Buscar notas fiscais [/invoice-situation/search]

### Buscar informa��es de um situa��o de nota fiscal [POST]

Busca por situa��o de notas fiscais baseada nos filtros inseridos no corpo da requisi��o.

+ Request (application/json)
    
    + Attributes (invoiceSituation)
    
+ Response 200 (application/json)

    + Attributes (array[invoiceSituation])    

## Data structures

### invoiceSituation
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do situa��o de nota fiscal
+ description: Em processamento (string, required) - Descri��o do situa��o de nota fiscal
+ active: true (boolean, required) - Indica se o situa��o est� ativo

### invoiceSituationPost
+ description: Em processamento (string, required) - Descri��o do situa��o de nota fiscal
+ active: true (boolean, required) - Indica se o situa��o est� ativo