FORMAT: 1A
HOST: http://dev.sollar.com/api/v1/sales

# Invoice Type Item

A API de tipo item nota fiscal serbe para definir qual o tipo do item de nota fiscal a fim de classificar os itens da NF.


## Invoice type items collection [/invoice-type-items]

### Criar um novo tipo de item de nota fiscal [POST]

� poss�vel criar um tipo de item de nota fiscal usando esta a��o. 

+ Request (application/json)
    + Attributes (invoiceTypeItemPost)

+ Response 201 (application/json)

    + Body

            {
                "id" : "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }


### Listar todos os tipo item de nota fiscal [GET]

Retorna uma lista de todas os tipos de item de nota fiscal no formato JSON.

+ Response 200 (application/json)
    + Attributes (array[invoiceTypeItem])
    
	
## Invoice type item [/invoice-type-items/{id}]

### Buscar um tipo de item de nota fiscal [GET]

+ Parameters
    + id(required, UUID, `6fcb689a-3eef-11e7-a919-92ebcb67fe33`) ... Id tipo nota fiscal.

+ Response 200 (application/json)
    + Attributes (invoiceTypeItem)


### Remover um tipo de item de nota fiscal [DELETE]

Deleta um tipo de item de nota fiscal

+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id do item da nota fiscal

+ Request (application/json) 

    + Body
    
            {
                "id": "ad819010-8369-49b2-b8d2-dddb533fb0b3"
            }

+ Response 200


### Atualizar um item do tipo de uma nota fiscal [PUT]

 Atualiza um item de tipo de nota fiscal baseado na diferen�a entre as informa��es j� existentes e a informa��o enviada no formato JSON.
 
+ Parameters
    + id(required,UUID,`048d1734-4f8a-44df-be49-5612777b6535`) ... Id do tipo de item da nota fiscal

+ Request (application/json)
    
    + Attributes (invoiceTypeItem)
    
+ Response 201


## Buscar tipos de item das notas fiscais [/invoice-type-items/search]

### Buscar informa��es de um tipo de nota fiscal [POST]

Busca por tipo de item de notas fiscais baseada nos filtros inseridos no corpo da requisi��o.

+ Request (application/json)
    
    + Attributes (invoiceTypeItem)
    
+ Response 200 (application/json)

    + Attributes (array[invoiceTypeItem])    

	
## Data structures

### invoiceTypeItem
+ id: `048d1734-4f8a-44df-be49-5612777b6535` (required) - Identificador do tipo de item da nota fiscal
+ description: Bonifica��o (string, required) - Descri��o do tipo de item da nota fiscal
+ active: true (boolean,required) - Indica se o tipo do item est� ativo

### invoiceTypeItemPost
+ description: Bonifica��o (string, required) - Descri��o do tipo de item da nota fiscal
+ active: true (boolean,required) - Indica se o tipo do item est� ativo