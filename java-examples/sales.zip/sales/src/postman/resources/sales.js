/*!
 * Postman BDD v5.0.6 (April 8th 2018)
 * 
 * https://bigstickcarpet.github.io/postman-bdd
 * 
 * @author  James Messinger (http://bigstickcarpet.com)
 * @license MIT
 */
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.postmanBDD=f()}})(function(){var define,module,exports;return function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r}()({1:[function(require,module,exports){"use strict";var url=require("url"),cookies=require("./cookies"),ipV4Pattern=/^(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}$/,ipV6Pattern=/^(?:(?:[0-9a-fA-F:]){1,4}(?:(?::(?:[0-9a-fA-F]){1,4}|:)){2,7})+$/,contentTypes={json:"application/json",text:"text/plain",html:"text/html",xml:"application/xml"};function chaiHttp(e,t){var o=e.Assertion;o.addMethod("status",function(e){new o(this._obj).to.have.property("status");var t=this._obj.status;this.assert(t===e,"expected the response to have status code #{exp} but got #{act}","expected the response to not have status code #{act}",e,t)}),o.addProperty("headers",function(){var e=this._obj.method?"request":"response";this.assert(Object.keys(this._obj.headers||{}).length>0,"expected the "+e+" to have headers","expected the "+e+" to not have any headers")}),o.addMethod("header",function(e,t){var o=getHeader(this._obj,e),a=void 0!==o&&null!==o;arguments.length<2?this.assert(a,"expected header #{exp} to exist","expected header #{exp} to not exist",e,o):t instanceof RegExp?this.assert(a&&t.test(o),"expected header '"+e+"' to match #{exp} but got #{act}","expected header '"+e+"' to not match #{exp} but got #{act}",t,a?o:"<header-not-set>"):this.assert(a&&o===t,"expected header '"+e+"' to have value #{exp} but got #{act}","expected header '"+e+"' to not have value #{exp}",t,a?o:"<header-not-set>")}),o.addProperty("ip",function(){var e=ipV4Pattern.test(this._obj)||ipV6Pattern.test(this._obj);this.assert(e,"expected #{this} to be an ip","expected #{this} to not be an ip")}),Object.keys(contentTypes).forEach(function(e){var t=contentTypes[e];o.addProperty(e,function(){var o=getHeader(this._obj,"content-type");this.assert(o&&o.indexOf(t)>=0,"expected the response type to be #{exp} but got #{act}","expected the response type to not be #{exp} (#{act})",e,o||"<content-type-not-set>")})}),o.addProperty("redirect",function(){var e=this._obj.status;this.assert(wasRedirected(this._obj),"expected redirect status code but got "+e,"expected not to redirect but got "+e+" status")}),o.addMethod("redirectTo",function(e){var t=this._obj.redirects,o=wasRedirected(this._obj),a=this._obj.status,s=getHeader(this._obj,"location");t&&t.length?this.assert(t.indexOf(e)>-1,"expected redirect to "+e+" but got "+t.join(" then "),"expected not to redirect to "+e+" but got "+t.join(" then ")):this.assert(o&&s===e,"expected redirect to #{exp} but got #{act}","expected not to redirect to #{exp}",e,o?s:a)}),o.addProperty("params",function(){var e=url.parse(this._obj.url,!0).query;this.assert(Object.keys(e).length>0,"expected the request to have query parameters","expected the request to not have any query parameters")}),o.addMethod("param",function(e,t){var o=url.parse(this._obj.url,!0).query[e],a=void 0!==o&&null!==o;arguments.length<2?this.assert(a,"expected query parameter #{exp} to exist","expected query parameter #{exp} to not exist",e,o):t instanceof RegExp?this.assert(a&&t.test(o),"expected query parameter '"+e+"' to match #{exp} but got #{act}","expected query parameter '"+e+"' to not match #{exp} but got #{act}",t,a?o:"<parameter-does-not-exist>"):this.assert(a&&o===t,"expected query parameter '"+e+"' to have value #{exp} but got #{act}","expected query parameter '"+e+"' to not have value #{exp}",t,a?o:"<parameter-does-not-exist>")}),o.addProperty("cookies",function(){var e=this._obj.method?"request":"response",t=getCookies(this._obj);this.assert(t.length>0,"expected the "+e+" to have cookies","expected the "+e+" to not have any cookies")}),o.addMethod("cookie",function(e,t){var o=getCookie(this._obj,e)||{},a=void 0!==o.value&&null!==o.value;arguments.length<2?this.assert(a,"expected cookie #{exp} to exist","expected cookie #{exp} to not exist",e,o.value):t instanceof RegExp?this.assert(a&&t.test(o.value),"expected cookie '"+e+"' to match #{exp} but got #{act}","expected cookie '"+e+"' to not match #{exp} but got #{act}",t,a?o.value:"<cookie-not-set>"):this.assert(a&&o.value===t,"expected cookie '"+e+"' to have value #{exp} but got #{act}","expected cookie '"+e+"' to not have value #{exp}",t,a?o.value:"<cookie-not-set>")}),e.Assertion.addMethod("schema",function(e){var o=tv4.validate(this._obj,e),a=t.flag(this,"negate");if(o&&a||!o&&!a){var s=tv4.error.dataPath,r=tv4.error.schemaPath,i=tv4.error.message;if(s)i=s.substr(1).split("/").join(".")+" is invalid. "+i;var n=new SyntaxError(i);throw n.dataPath=s,n.schemaPath=r,n}})}function getHeader(e,t){if(e.getHeader)return e.getHeader(t);t=(t||"").toLowerCase();for(var o=Object.keys(e.headers),a=0;a<o.length;a++)if(o[a].toLowerCase()===t)return e.headers[o[a]]}function getCookies(e){if(e.cookies)return e.cookies;var t=getHeader(e,"cookie");return cookies.parseRequestCookies(t)}function getCookie(e,t){if(e.getCookie)return e.getCookie(t);var o=getCookies(e);return cookies.getCookie(o,t)}function wasRedirected(e){var t=e.redirects,o=e.status;return[301,302,303,307,308].indexOf(o)>=0||t&&t.length}module.exports=chaiHttp},{"./cookies":3,url:54}],2:[function(require,module,exports){"use strict";var Runnable=require("./runnable"),Hook=require("./hook"),State=require("./state");function PostmanBDD(){var t=this.state=new State;this.hooks={before:new Hook("before",t),after:new Hook("after",t),beforeEach:new Hook("beforeEach",t),afterEach:new Hook("afterEach",t)},this.before=PostmanBDD.prototype.before.bind(this),this.after=PostmanBDD.prototype.after.bind(this),this.beforeEach=PostmanBDD.prototype.beforeEach.bind(this),this.afterEach=PostmanBDD.prototype.afterEach.bind(this),this.describe=PostmanBDD.prototype.describe.bind(this),this.it=PostmanBDD.prototype.it.bind(this)}module.exports=PostmanBDD,PostmanBDD.prototype.before=function(t,e){this.hooks.before.push(t,e)},PostmanBDD.prototype.after=function(t,e){this.hooks.after.push(t,e)},PostmanBDD.prototype.beforeEach=function(t,e){this.hooks.beforeEach.push(t,e)},PostmanBDD.prototype.afterEach=function(t,e){this.hooks.afterEach.push(t,e)},PostmanBDD.prototype.describe=function(t,e){var o=new Runnable("describe",this.state,t,e);return this.state.stack.push(o),this.oneTimeInitialization(),o.run(),this.state.isFinished()&&this.hooks.after.run(),this.state.stack.pop(),this.state.results},PostmanBDD.prototype.it=function(t,e){var o=new Runnable("it",this.state,t,e);return this.state.stack.push(o),this.oneTimeInitialization(),this.hooks.beforeEach.run(),o.run(),this.hooks.afterEach.run(),this.state.stack.pop(),o.result},PostmanBDD.prototype.oneTimeInitialization=function(){this.state.isStarted()||this.hooks.before.run()}},{"./hook":4,"./runnable":9,"./state":10}],3:[function(require,module,exports){"use strict";var CookieJar=require("cookiejar").CookieJar,CookieAccessInfo=require("cookiejar").CookieAccessInfo;module.exports={getCookie:function(e,o){return o=(o||"").toLowerCase(),e.find(function(e){return e&&e.name.toLowerCase()===o})},parseRequestCookies:function(e){var o=new CookieJar;if(e){var r=e.split(";").map(function(e){return e.trim()});o.setCookies(r)}return o.getCookies(CookieAccessInfo.All)},parseResponseCookies:function(e){var o=new CookieJar;return e&&o.setCookies(e),o.getCookies(CookieAccessInfo.All)}}},{cookiejar:46}],4:[function(require,module,exports){"use strict";var Runnable=require("./runnable");function Hook(t,s){this.type=t,this.state=s,this.runnables=[]}module.exports=Hook,Hook.prototype.run=function(){var t=this;this.state.inAHook()||this.runnables.forEach(function(s){t.state.stack.push(s),s.run(),t.state.stack.pop()})},Hook.prototype.push=function(t,s){var n=new Runnable(this.type,this.state,t,s);n.isHook=!0,this.runnables.push(n)}},{"./runnable":9}],5:[function(require,module,exports){var PostmanBDD=require("./bdd"),superAgent=require("./response"),assertions=require("./assertions"),options=require("./options"),log=require("./log");function initPostmanBDD(){log.info("Using Postman BDD"),initBDD(),initSuperAgent(),initChai()}function initBDD(){var e=new PostmanBDD;before=e.before,after=e.after,beforeEach=e.beforeEach,afterEach=e.afterEach,describe=e.describe,it=e.it}function initSuperAgent(){response=new superAgent.Response}function initChai(){chai=require("chai"),assert=chai.assert,expect=chai.expect,chai.should(),chai.use(assertions)}module.exports=options,module.exports.reset=initPostmanBDD,initPostmanBDD()},{"./assertions":1,"./bdd":2,"./log":6,"./options":7,"./response":8,chai:13}],6:[function(require,module,exports){"use strict";var options=require("./options"),levels=["silent","error","warn","info","debug"],log=module.exports={isEnabled:function(e){return levels.indexOf(options.logLevel)>=levels.indexOf(e)},errorToPOJO:function(e){if(e&&"object"==typeof e)return Object.keys(e).concat(["name","message","stack"]).reduce(function(o,n){return o[n]=e[n],o},{})}};levels.forEach(function(e){log[e]=function(){if(this.isEnabled(e)){var o=console.log;"function"==typeof console[e]&&(o=console[e]),o.apply(console,arguments)}}})},{"./options":7}],7:[function(require,module,exports){"use strict";module.exports={logLevel:"warn"}},{}],8:[function(require,module,exports){"use strict";var log=require("./log"),cookies=require("./cookies");function Response(){this.status="object"==typeof responseCode?responseCode.code:0,this.statusType=Math.floor(this.status/100),this.info=1===this.statusType,this.ok=2===this.statusType,this.redirect=3===this.statusType,this.clientError=4===this.statusType,this.serverError=5===this.statusType,this.error=this.clientError||this.serverError,this.accepted=202===this.status,this.noContent=204===this.status||1223===this.status,this.badRequest=400===this.status,this.unauthorized=401===this.status,this.notAcceptable=406===this.status,this.notFound=404===this.status,this.forbidden=403===this.status,this.time="number"==typeof responseTime?responseTime:0,this.headers=this.header=parseHeaders();var e=this.getHeader("content-type")||"",s=/charset=([a-zA-Z0-9_-]+)/i.exec(e);this.type=e.split(";")[0],this.charset=s?s[1]:"",this.cookies=parseCookies(this),this.text="string"==typeof responseBody?responseBody:"",this.body=parseResponeBody(this)}function parseHeaders(){if("object"==typeof responseHeaders){var e=pojo(responseHeaders),s={};return Object.keys(e).forEach(function(t){s[t.toLowerCase()]=e[t]}),s}return{}}function parseCookies(e){if("object"==typeof responseCookies&&responseCookies.length>0)return responseCookies;var s=e.getHeader("set-cookie");return cookies.parseResponseCookies(s)}function parseResponeBody(e){if(e.type.indexOf("json")>=0)try{return JSON.parse(e.text)}catch(e){log.error("Unable to parse the response body as JSON",log.errorToPOJO(e))}if(e.type.indexOf("xml")>=0)try{return pojo(xml2Json(e.text))}catch(e){log.error("Unable to parse the response body as XML",log.errorToPOJO(e))}return e.text}function pojo(e){return JSON.parse(JSON.stringify(e))}module.exports={Response:Response},Response.prototype.getHeader=function(e){return"object"==typeof postman&&"function"==typeof postman.getResponseHeader?postman.getResponseHeader(e):(e=(e||"").toLowerCase(),this.headers[e])},Response.prototype.getCookie=function(e){return"object"==typeof postman&&"function"==typeof postman.getResponseCookie?postman.getResponseCookie(e):cookies.getCookie(this.cookies,e)}},{"./cookies":3,"./log":6}],9:[function(require,module,exports){"use strict";var log=require("./log");function Runnable(t,s,e,i){"function"==typeof e&&(i=e,e=""),s.counters[t]++;var r="it"===t?"test":t;this.type=t,this.state=s,this.isHook=!1,this.isNamed=!!e,this.title=e||r+" #"+s.counters[t],this.fn=i,this.result=null,this.error=null}module.exports=Runnable,Runnable.prototype.run=function(){var t=this.state.currentPath();log.debug("Running "+t),"describe"!==this.type&&(this.state.results[t]=null);try{this.fn(),this.success(t)}catch(s){this.failure(s,t)}},Runnable.prototype.success=function(t){log.info("passed: "+t),this.result=!0,"describe"!==this.type&&(this.state.results[t]=!0)},Runnable.prototype.failure=function(t,s){log.error("failed: "+s,log.errorToPOJO(t)),this.result=!1,this.error=t,delete this.state.results[s],this.state.results[s+" ("+t.message+")"]=!1}},{"./log":6}],10:[function(require,module,exports){"use strict";function State(){this.results=resetTests(),this.stack=[],this.counters={describe:0,it:0,before:0,after:0,beforeEach:0,afterEach:0},this._pathCounter=0}function resetTests(){if("object"!=typeof tests)throw new Error('Postman BDD can only run inside the Postman scripting runtime (the "tests" global variable is missing)');return Object.keys(tests).forEach(function(t){delete tests[t]}),tests}module.exports=State,State.prototype.currentPath=function(){var t=this.stack[this.stack.length-1],e="";if(("describe"!==t.type&&(e=++this._pathCounter+". "),"before"===t.type||"after"===t.type)&&!this.stack.some(function(t){return"describe"===t.type&&t.isNamed}))return e+t.title;return e+=this.stack.map(function(t){return t.title}).join(" - ")},State.prototype.isStarted=function(){return this._pathCounter>0},State.prototype.isFinished=function(){return 1===this.stack.length&&this.counters.describe>0},State.prototype.inAHook=function(){return this.stack.some(function(t){return t.isHook})}},{}],11:[function(require,module,exports){
/*!
 * assertion-error
 * Copyright(c) 2013 Jake Luer <jake@qualiancy.com>
 * MIT Licensed
 */
/*!
 * Return a function that will copy properties from
 * one object to another excluding any originally
 * listed. Returned function will create a new `{}`.
 *
 * @param {String} excluded properties ...
 * @return {Function}
 */
function exclude(){var r=[].slice.call(arguments);function t(t,o){Object.keys(o).forEach(function(e){~r.indexOf(e)||(t[e]=o[e])})}return function(){for(var r=[].slice.call(arguments),o=0,e={};o<r.length;o++)t(e,r[o]);return e}}function AssertionError(r,t,o){var e=exclude("name","message","stack","constructor","toJSON")(t||{});for(var s in this.message=r||"Unspecified AssertionError",this.showDiff=!1,e)this[s]=e[s];if(o=o||AssertionError,Error.captureStackTrace)Error.captureStackTrace(this,o);else try{throw new Error}catch(r){this.stack=r.stack}}
/*!
 * Inherit from Error.prototype
 */
/*!
 * Primary Exports
 */module.exports=AssertionError,AssertionError.prototype=Object.create(Error.prototype),
/*!
 * Statically set name
 */
AssertionError.prototype.name="AssertionError",
/*!
 * Ensure correct constructor
 */
AssertionError.prototype.constructor=AssertionError,AssertionError.prototype.toJSON=function(r){var t=exclude("constructor","toJSON","stack")({name:this.name},this);return!1!==r&&this.stack&&(t.stack=this.stack),t}},{}],12:[function(require,module,exports){(function(global){
/*! https://mths.be/punycode v1.4.1 by @mathias */
!function(e){var o="object"==typeof exports&&exports&&!exports.nodeType&&exports,n="object"==typeof module&&module&&!module.nodeType&&module,t="object"==typeof global&&global;t.global!==t&&t.window!==t&&t.self!==t||(e=t);var r,u,i=2147483647,f=36,c=1,l=26,s=38,d=700,p=72,a=128,h="-",v=/^xn--/,g=/[^\x20-\x7E]/,w=/[\x2E\u3002\uFF0E\uFF61]/g,x={overflow:"Overflow: input needs wider integers to process","not-basic":"Illegal input >= 0x80 (not a basic code point)","invalid-input":"Invalid input"},b=f-c,y=Math.floor,C=String.fromCharCode;function m(e){throw new RangeError(x[e])}function j(e,o){for(var n=e.length,t=[];n--;)t[n]=o(e[n]);return t}function A(e,o){var n=e.split("@"),t="";return n.length>1&&(t=n[0]+"@",e=n[1]),t+j((e=e.replace(w,".")).split("."),o).join(".")}function I(e){for(var o,n,t=[],r=0,u=e.length;r<u;)(o=e.charCodeAt(r++))>=55296&&o<=56319&&r<u?56320==(64512&(n=e.charCodeAt(r++)))?t.push(((1023&o)<<10)+(1023&n)+65536):(t.push(o),r--):t.push(o);return t}function E(e){return j(e,function(e){var o="";return e>65535&&(o+=C((e-=65536)>>>10&1023|55296),e=56320|1023&e),o+=C(e)}).join("")}function F(e,o){return e+22+75*(e<26)-((0!=o)<<5)}function O(e,o,n){var t=0;for(e=n?y(e/d):e>>1,e+=y(e/o);e>b*l>>1;t+=f)e=y(e/b);return y(t+(b+1)*e/(e+s))}function S(e){var o,n,t,r,u,s,d,v,g,w,x,b=[],C=e.length,j=0,A=a,I=p;for((n=e.lastIndexOf(h))<0&&(n=0),t=0;t<n;++t)e.charCodeAt(t)>=128&&m("not-basic"),b.push(e.charCodeAt(t));for(r=n>0?n+1:0;r<C;){for(u=j,s=1,d=f;r>=C&&m("invalid-input"),((v=(x=e.charCodeAt(r++))-48<10?x-22:x-65<26?x-65:x-97<26?x-97:f)>=f||v>y((i-j)/s))&&m("overflow"),j+=v*s,!(v<(g=d<=I?c:d>=I+l?l:d-I));d+=f)s>y(i/(w=f-g))&&m("overflow"),s*=w;I=O(j-u,o=b.length+1,0==u),y(j/o)>i-A&&m("overflow"),A+=y(j/o),j%=o,b.splice(j++,0,A)}return E(b)}function T(e){var o,n,t,r,u,s,d,v,g,w,x,b,j,A,E,S=[];for(b=(e=I(e)).length,o=a,n=0,u=p,s=0;s<b;++s)(x=e[s])<128&&S.push(C(x));for(t=r=S.length,r&&S.push(h);t<b;){for(d=i,s=0;s<b;++s)(x=e[s])>=o&&x<d&&(d=x);for(d-o>y((i-n)/(j=t+1))&&m("overflow"),n+=(d-o)*j,o=d,s=0;s<b;++s)if((x=e[s])<o&&++n>i&&m("overflow"),x==o){for(v=n,g=f;!(v<(w=g<=u?c:g>=u+l?l:g-u));g+=f)E=v-w,A=f-w,S.push(C(F(w+E%A,0))),v=y(E/A);S.push(C(F(v,0))),u=O(n,j,t==r),n=0,++t}++n,++o}return S.join("")}if(r={version:"1.4.1",ucs2:{decode:I,encode:E},decode:S,encode:T,toASCII:function(e){return A(e,function(e){return g.test(e)?"xn--"+T(e):e})},toUnicode:function(e){return A(e,function(e){return v.test(e)?S(e.slice(4).toLowerCase()):e})}},"function"==typeof define&&"object"==typeof define.amd&&define.amd)define("punycode",function(){return r});else if(o&&n)if(module.exports==o)n.exports=r;else for(u in r)r.hasOwnProperty(u)&&(o[u]=r[u]);else e.punycode=r}(this)}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],13:[function(require,module,exports){module.exports=require("./lib/chai")},{"./lib/chai":14}],14:[function(require,module,exports){
/*!
 * chai
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var used=[];
/*!
 * Chai version
 */exports.version="4.1.2",
/*!
 * Assertion Error
 */
exports.AssertionError=require("assertion-error");
/*!
 * Utils for plugins (not exported)
 */var util=require("./chai/utils");exports.use=function(e){return~used.indexOf(e)||(e(exports,util),used.push(e)),exports
/*!
 * Utility Functions
 */},exports.util=util;
/*!
 * Configuration
 */var config=require("./chai/config");exports.config=config;
/*!
 * Primary `Assertion` prototype
 */var assertion=require("./chai/assertion");exports.use(assertion);
/*!
 * Core Assertions
 */var core=require("./chai/core/assertions");exports.use(core);
/*!
 * Expect interface
 */var expect=require("./chai/interface/expect");exports.use(expect);
/*!
 * Should interface
 */var should=require("./chai/interface/should");exports.use(should);
/*!
 * Assert interface
 */var assert=require("./chai/interface/assert");exports.use(assert)},{"./chai/assertion":15,"./chai/config":16,"./chai/core/assertions":17,"./chai/interface/assert":18,"./chai/interface/expect":19,"./chai/interface/should":20,"./chai/utils":34,"assertion-error":11}],15:[function(require,module,exports){
/*!
 * chai
 * http://chaijs.com
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var config=require("./config");module.exports=function(t,e){
/*!
   * Module dependencies.
   */
var i=t.AssertionError,o=e.flag;
/*!
   * Module export.
   */
/*!
   * Assertion Constructor
   *
   * Creates object for chaining.
   *
   * `Assertion` objects contain metadata in the form of flags. Three flags can
   * be assigned during instantiation by passing arguments to this constructor:
   *
   * - `object`: This flag contains the target of the assertion. For example, in
   *   the assertion `expect(numKittens).to.equal(7);`, the `object` flag will
   *   contain `numKittens` so that the `equal` assertion can reference it when
   *   needed.
   *
   * - `message`: This flag contains an optional custom error message to be
   *   prepended to the error message that's generated by the assertion when it
   *   fails.
   *
   * - `ssfi`: This flag stands for "start stack function indicator". It
   *   contains a function reference that serves as the starting point for
   *   removing frames from the stack trace of the error that's created by the
   *   assertion when it fails. The goal is to provide a cleaner stack trace to
   *   end users by removing Chai's internal functions. Note that it only works
   *   in environments that support `Error.captureStackTrace`, and only when
   *   `Chai.config.includeStack` hasn't been set to `false`.
   *
   * - `lockSsfi`: This flag controls whether or not the given `ssfi` flag
   *   should retain its current value, even as assertions are chained off of
   *   this object. This is usually set to `true` when creating a new assertion
   *   from within another assertion. It's also temporarily set to `true` before
   *   an overwritten assertion gets called by the overwriting assertion.
   *
   * @param {Mixed} obj target of the assertion
   * @param {String} msg (optional) custom error message
   * @param {Function} ssfi (optional) starting point for removing stack frames
   * @param {Boolean} lockSsfi (optional) whether or not the ssfi flag is locked
   * @api private
   */function n(t,i,s,r){return o(this,"ssfi",s||n),o(this,"lockSsfi",r),o(this,"object",t),o(this,"message",i),e.proxify(this)}t.Assertion=n,Object.defineProperty(n,"includeStack",{get:function(){return console.warn("Assertion.includeStack is deprecated, use chai.config.includeStack instead."),config.includeStack},set:function(t){console.warn("Assertion.includeStack is deprecated, use chai.config.includeStack instead."),config.includeStack=t}}),Object.defineProperty(n,"showDiff",{get:function(){return console.warn("Assertion.showDiff is deprecated, use chai.config.showDiff instead."),config.showDiff},set:function(t){console.warn("Assertion.showDiff is deprecated, use chai.config.showDiff instead."),config.showDiff=t}}),n.addProperty=function(t,i){e.addProperty(this.prototype,t,i)},n.addMethod=function(t,i){e.addMethod(this.prototype,t,i)},n.addChainableMethod=function(t,i,o){e.addChainableMethod(this.prototype,t,i,o)},n.overwriteProperty=function(t,i){e.overwriteProperty(this.prototype,t,i)},n.overwriteMethod=function(t,i){e.overwriteMethod(this.prototype,t,i)},n.overwriteChainableMethod=function(t,i,o){e.overwriteChainableMethod(this.prototype,t,i,o)},n.prototype.assert=function(t,n,s,r,c,f){var a=e.test(this,arguments);if(!1!==f&&(f=!0),void 0===r&&void 0===c&&(f=!1),!0!==config.showDiff&&(f=!1),!a){n=e.getMessage(this,arguments);var d=e.getActual(this,arguments);throw new i(n,{actual:d,expected:r,showDiff:f},config.includeStack?this.assert:o(this,"ssfi"))}},
/*!
   * ### ._obj
   *
   * Quick reference to stored `actual` value for plugin developers.
   *
   * @api private
   */
Object.defineProperty(n.prototype,"_obj",{get:function(){return o(this,"object")},set:function(t){o(this,"object",t)}})}},{"./config":16}],16:[function(require,module,exports){module.exports={includeStack:!1,showDiff:!0,truncateThreshold:40,useProxy:!0,proxyExcludedKeys:["then","inspect","toJSON"]}},{}],17:[function(require,module,exports){
/*!
 * chai
 * http://chaijs.com
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,t){var s=e.Assertion,o=e.AssertionError,a=t.flag;function i(e,s){s&&a(this,"message",s),e=e.toLowerCase();var o=a(this,"object"),i=~["a","e","i","o","u"].indexOf(e.charAt(0))?"an ":"a ";this.assert(e===t.type(o).toLowerCase(),"expected #{this} to be "+i+e,"expected #{this} not to be "+i+e)}function r(e,s){return t.isNaN(e)&&t.isNaN(s)||e===s}function n(){a(this,"contains",!0)}function h(e,i){i&&a(this,"message",i);var n=a(this,"object"),h=t.type(n).toLowerCase(),d=a(this,"message"),c=a(this,"negate"),p=a(this,"ssfi"),l=a(this,"deep"),u=l?"deep ":"";d=d?d+": ":"";var b=!1;switch(h){case"string":b=-1!==n.indexOf(e);break;case"weakset":if(l)throw new o(d+"unable to use .deep.include with WeakSet",void 0,p);b=n.has(e);break;case"map":var f=l?t.eql:r;n.forEach(function(t){b=b||f(t,e)});break;case"set":l?n.forEach(function(s){b=b||t.eql(s,e)}):b=n.has(e);break;case"array":b=l?n.some(function(s){return t.eql(s,e)}):-1!==n.indexOf(e);break;default:if(e!==Object(e))throw new o(d+"object tested must be an array, a map, an object, a set, a string, or a weakset, but "+h+" given",void 0,p);var g=Object.keys(e),m=null,x=0;if(g.forEach(function(i){var r=new s(n);if(t.transferFlags(this,r,!0),a(r,"lockSsfi",!0),c&&1!==g.length)try{r.property(i,e[i])}catch(e){if(!t.checkError.compatibleConstructor(e,o))throw e;null===m&&(m=e),x++}else r.property(i,e[i])},this),c&&g.length>1&&x===g.length)throw m;return}this.assert(b,"expected #{this} to "+u+"include "+t.inspect(e),"expected #{this} to not "+u+"include "+t.inspect(e))}function d(){var e=a(this,"object"),s=t.type(e);this.assert("Arguments"===s,"expected #{this} to be arguments but got "+s,"expected #{this} to not be arguments")}function c(e,t){t&&a(this,"message",t);var s=a(this,"object");if(a(this,"deep"))return this.eql(e);this.assert(e===s,"expected #{this} to equal #{exp}","expected #{this} to not equal #{exp}",e,this._obj,!0)}function p(e,s){s&&a(this,"message",s),this.assert(t.eql(e,a(this,"object")),"expected #{this} to deeply equal #{exp}","expected #{this} to not deeply equal #{exp}",e,this._obj,!0)}function l(e,i){i&&a(this,"message",i);var r=a(this,"object"),n=a(this,"doLength"),h=a(this,"message"),d=h?h+": ":"",c=a(this,"ssfi"),p=t.type(r).toLowerCase(),l=t.type(e).toLowerCase(),u=!0;if(n&&new s(r,h,c,!0).to.have.property("length"),n||"date"!==p||"date"===l)if("number"===l||!n&&"number"!==p)if(n||"date"===p||"number"===p)u=!1;else{errorMessage=d+"expected "+("string"===p?"'"+r+"'":r)+" to be a number or a date"}else errorMessage=d+"the argument to above must be a number";else errorMessage=d+"the argument to above must be a date";if(u)throw new o(errorMessage,void 0,c);if(n){var b=r.length;this.assert(b>e,"expected #{this} to have a length above #{exp} but got #{act}","expected #{this} to not have a length above #{exp}",e,b)}else this.assert(r>e,"expected #{this} to be above #{exp}","expected #{this} to be at most #{exp}",e)}function u(e,i){i&&a(this,"message",i);var r=a(this,"object"),n=a(this,"doLength"),h=a(this,"message"),d=h?h+": ":"",c=a(this,"ssfi"),p=t.type(r).toLowerCase(),l=t.type(e).toLowerCase(),u=!0;if(n&&new s(r,h,c,!0).to.have.property("length"),n||"date"!==p||"date"===l)if("number"===l||!n&&"number"!==p)if(n||"date"===p||"number"===p)u=!1;else{errorMessage=d+"expected "+("string"===p?"'"+r+"'":r)+" to be a number or a date"}else errorMessage=d+"the argument to least must be a number";else errorMessage=d+"the argument to least must be a date";if(u)throw new o(errorMessage,void 0,c);if(n){var b=r.length;this.assert(b>=e,"expected #{this} to have a length at least #{exp} but got #{act}","expected #{this} to have a length below #{exp}",e,b)}else this.assert(r>=e,"expected #{this} to be at least #{exp}","expected #{this} to be below #{exp}",e)}function b(e,i){i&&a(this,"message",i);var r=a(this,"object"),n=a(this,"doLength"),h=a(this,"message"),d=h?h+": ":"",c=a(this,"ssfi"),p=t.type(r).toLowerCase(),l=t.type(e).toLowerCase(),u=!0;if(n&&new s(r,h,c,!0).to.have.property("length"),n||"date"!==p||"date"===l)if("number"===l||!n&&"number"!==p)if(n||"date"===p||"number"===p)u=!1;else{errorMessage=d+"expected "+("string"===p?"'"+r+"'":r)+" to be a number or a date"}else errorMessage=d+"the argument to below must be a number";else errorMessage=d+"the argument to below must be a date";if(u)throw new o(errorMessage,void 0,c);if(n){var b=r.length;this.assert(b<e,"expected #{this} to have a length below #{exp} but got #{act}","expected #{this} to not have a length below #{exp}",e,b)}else this.assert(r<e,"expected #{this} to be below #{exp}","expected #{this} to be at least #{exp}",e)}function f(e,i){i&&a(this,"message",i);var r=a(this,"object"),n=a(this,"doLength"),h=a(this,"message"),d=h?h+": ":"",c=a(this,"ssfi"),p=t.type(r).toLowerCase(),l=t.type(e).toLowerCase(),u=!0;if(n&&new s(r,h,c,!0).to.have.property("length"),n||"date"!==p||"date"===l)if("number"===l||!n&&"number"!==p)if(n||"date"===p||"number"===p)u=!1;else{errorMessage=d+"expected "+("string"===p?"'"+r+"'":r)+" to be a number or a date"}else errorMessage=d+"the argument to most must be a number";else errorMessage=d+"the argument to most must be a date";if(u)throw new o(errorMessage,void 0,c);if(n){var b=r.length;this.assert(b<=e,"expected #{this} to have a length at most #{exp} but got #{act}","expected #{this} to have a length above #{exp}",e,b)}else this.assert(r<=e,"expected #{this} to be at most #{exp}","expected #{this} to be above #{exp}",e)}function g(e,s){s&&a(this,"message",s);var i=a(this,"object"),r=a(this,"ssfi"),n=a(this,"message");try{var h=i instanceof e}catch(s){if(s instanceof TypeError)throw new o((n=n?n+": ":"")+"The instanceof assertion needs a constructor but "+t.type(e)+" was given.",void 0,r);throw s}var d=t.getName(e);null===d&&(d="an unnamed constructor"),this.assert(h,"expected #{this} to be an instance of "+d,"expected #{this} to not be an instance of "+d)}function m(e,s,i){i&&a(this,"message",i);var r=a(this,"nested"),n=a(this,"own"),h=a(this,"message"),d=a(this,"object"),c=a(this,"ssfi");if(r&&n)throw new o((h=h?h+": ":"")+'The "nested" and "own" flags cannot be combined.',void 0,c);if(null===d||void 0===d)throw new o((h=h?h+": ":"")+"Target cannot be null or undefined.",void 0,c);var p,l=a(this,"deep"),u=a(this,"negate"),b=r?t.getPathInfo(d,e):null,f=r?b.value:d[e],g="";l&&(g+="deep "),n&&(g+="own "),r&&(g+="nested "),g+="property ",p=n?Object.prototype.hasOwnProperty.call(d,e):r?b.exists:t.hasProperty(d,e),u&&1!==arguments.length||this.assert(p,"expected #{this} to have "+g+t.inspect(e),"expected #{this} to not have "+g+t.inspect(e)),arguments.length>1&&this.assert(p&&(l?t.eql(s,f):s===f),"expected #{this} to have "+g+t.inspect(e)+" of #{exp}, but got #{act}","expected #{this} to not have "+g+t.inspect(e)+" of #{act}",s,f),a(this,"object",f)}function x(e,t,s){a(this,"own",!0),m.apply(this,arguments)}function w(e,s,o){"string"==typeof s&&(o=s,s=null),o&&a(this,"message",o);var i=a(this,"object"),r=Object.getOwnPropertyDescriptor(Object(i),e);r&&s?this.assert(t.eql(s,r),"expected the own property descriptor for "+t.inspect(e)+" on #{this} to match "+t.inspect(s)+", got "+t.inspect(r),"expected the own property descriptor for "+t.inspect(e)+" on #{this} to not match "+t.inspect(s),s,r,!0):this.assert(r,"expected #{this} to have an own property descriptor for "+t.inspect(e),"expected #{this} to not have an own property descriptor for "+t.inspect(e)),a(this,"object",r)}function v(){a(this,"doLength",!0)}function y(e,t){t&&a(this,"message",t);var o=a(this,"object"),i=a(this,"message"),r=a(this,"ssfi");new s(o,i,r,!0).to.have.property("length");var n=o.length;this.assert(n==e,"expected #{this} to have a length of #{exp} but got #{act}","expected #{this} to not have a length of #{act}",e,n)}function M(e,t){t&&a(this,"message",t);var s=a(this,"object");this.assert(e.exec(s),"expected #{this} to match "+e,"expected #{this} not to match "+e)}function j(e){var s,i=a(this,"object"),r=t.type(i),n=t.type(e),h=a(this,"ssfi"),d=a(this,"deep"),c="",p=!0,l=a(this,"message"),u=(l=l?l+": ":"")+"when testing keys against an object or an array you must give a single Array|Object|String argument or multiple String arguments";if("Map"===r||"Set"===r)c=d?"deeply ":"",b=[],i.forEach(function(e,t){b.push(t)}),"Array"!==n&&(e=Array.prototype.slice.call(arguments));else{switch(b=t.getOwnEnumerableProperties(i),n){case"Array":if(arguments.length>1)throw new o(u,void 0,h);break;case"Object":if(arguments.length>1)throw new o(u,void 0,h);e=Object.keys(e);break;default:e=Array.prototype.slice.call(arguments)}e=e.map(function(e){return"symbol"==typeof e?e:String(e)})}if(!e.length)throw new o(l+"keys required",void 0,h);var b,f=e.length,g=a(this,"any"),m=a(this,"all"),x=e;if(g||m||(m=!0),g&&(p=x.some(function(e){return b.some(function(s){return d?t.eql(e,s):e===s})})),m&&(p=x.every(function(e){return b.some(function(s){return d?t.eql(e,s):e===s})}),a(this,"contains")||(p=p&&e.length==b.length)),f>1){var w=(e=e.map(function(e){return t.inspect(e)})).pop();m&&(s=e.join(", ")+", and "+w),g&&(s=e.join(", ")+", or "+w)}else s=t.inspect(e[0]);s=(f>1?"keys ":"key ")+s,s=(a(this,"contains")?"contain ":"have ")+s,this.assert(p,"expected #{this} to "+c+s,"expected #{this} to not "+c+s,x.slice(0).sort(t.compareByInspect),b.sort(t.compareByInspect),!0)}function k(e,o,i){i&&a(this,"message",i);var r,n=a(this,"object"),h=a(this,"ssfi"),d=a(this,"message"),c=a(this,"negate")||!1;new s(n,d,h,!0).is.a("function"),(e instanceof RegExp||"string"==typeof e)&&(o=e,e=null);try{n()}catch(e){r=e}var p=void 0===e&&void 0===o,l=Boolean(e&&o),u=!1,b=!1;if(p||!p&&!c){var f="an error";e instanceof Error?f="#{exp}":e&&(f=t.checkError.getConstructorName(e)),this.assert(r,"expected #{this} to throw "+f,"expected #{this} to not throw an error but #{act} was thrown",e&&e.toString(),r instanceof Error?r.toString():"string"==typeof r?r:r&&t.checkError.getConstructorName(r))}if(e&&r){if(e instanceof Error)t.checkError.compatibleInstance(r,e)===c&&(l&&c?u=!0:this.assert(c,"expected #{this} to throw #{exp} but #{act} was thrown","expected #{this} to not throw #{exp}"+(r&&!c?" but #{act} was thrown":""),e.toString(),r.toString()));t.checkError.compatibleConstructor(r,e)===c&&(l&&c?u=!0:this.assert(c,"expected #{this} to throw #{exp} but #{act} was thrown","expected #{this} to not throw #{exp}"+(r?" but #{act} was thrown":""),e instanceof Error?e.toString():e&&t.checkError.getConstructorName(e),r instanceof Error?r.toString():r&&t.checkError.getConstructorName(r)))}if(r&&void 0!==o&&null!==o){var g="including";o instanceof RegExp&&(g="matching"),t.checkError.compatibleMessage(r,o)===c&&(l&&c?b=!0:this.assert(c,"expected #{this} to throw error "+g+" #{exp} but got #{act}","expected #{this} to throw error not "+g+" #{exp}",o,t.checkError.getMessage(r)))}u&&b&&this.assert(c,"expected #{this} to throw #{exp} but #{act} was thrown","expected #{this} to not throw #{exp}"+(r?" but #{act} was thrown":""),e instanceof Error?e.toString():e&&t.checkError.getConstructorName(e),r instanceof Error?r.toString():r&&t.checkError.getConstructorName(r)),a(this,"object",r)}function O(e,s){s&&a(this,"message",s);var o=a(this,"object"),i=a(this,"itself"),r="function"!=typeof o||i?o[e]:o.prototype[e];this.assert("function"==typeof r,"expected #{this} to respond to "+t.inspect(e),"expected #{this} to not respond to "+t.inspect(e))}function C(e,s){s&&a(this,"message",s);var o=e(a(this,"object"));this.assert(o,"expected #{this} to satisfy "+t.objDisplay(e),"expected #{this} to not satisfy"+t.objDisplay(e),!a(this,"negate"),o)}function P(e,t,i){i&&a(this,"message",i);var r=a(this,"object"),n=a(this,"message"),h=a(this,"ssfi");if(new s(r,n,h,!0).is.a("number"),"number"!=typeof e||"number"!=typeof t)throw new o((n=n?n+": ":"")+"the arguments to closeTo or approximately must be numbers",void 0,h);this.assert(Math.abs(r-e)<=t,"expected #{this} to be close to "+e+" +/- "+t,"expected #{this} not to be close to "+e+" +/- "+t)}function E(e,t,o){o&&a(this,"message",o);var i,r=a(this,"object"),n=a(this,"message"),h=a(this,"ssfi");new s(r,n,h,!0).is.a("function"),t?(new s(e,n,h,!0).to.have.property(t),i=e[t]):(new s(e,n,h,!0).is.a("function"),i=e()),r();var d=void 0===t||null===t?e():e[t],c=void 0===t||null===t?i:"."+t;a(this,"deltaMsgObj",c),a(this,"initialDeltaValue",i),a(this,"finalDeltaValue",d),a(this,"deltaBehavior","change"),a(this,"realDelta",d!==i),this.assert(i!==d,"expected "+c+" to change","expected "+c+" to not change")}function L(e,t,o){o&&a(this,"message",o);var i,r=a(this,"object"),n=a(this,"message"),h=a(this,"ssfi");new s(r,n,h,!0).is.a("function"),t?(new s(e,n,h,!0).to.have.property(t),i=e[t]):(new s(e,n,h,!0).is.a("function"),i=e()),new s(i,n,h,!0).is.a("number"),r();var d=void 0===t||null===t?e():e[t],c=void 0===t||null===t?i:"."+t;a(this,"deltaMsgObj",c),a(this,"initialDeltaValue",i),a(this,"finalDeltaValue",d),a(this,"deltaBehavior","increase"),a(this,"realDelta",d-i),this.assert(d-i>0,"expected "+c+" to increase","expected "+c+" to not increase")}function q(e,t,o){o&&a(this,"message",o);var i,r=a(this,"object"),n=a(this,"message"),h=a(this,"ssfi");new s(r,n,h,!0).is.a("function"),t?(new s(e,n,h,!0).to.have.property(t),i=e[t]):(new s(e,n,h,!0).is.a("function"),i=e()),new s(i,n,h,!0).is.a("number"),r();var d=void 0===t||null===t?e():e[t],c=void 0===t||null===t?i:"."+t;a(this,"deltaMsgObj",c),a(this,"initialDeltaValue",i),a(this,"finalDeltaValue",d),a(this,"deltaBehavior","decrease"),a(this,"realDelta",i-d),this.assert(d-i<0,"expected "+c+" to decrease","expected "+c+" to not decrease")}["to","be","been","is","and","has","have","with","that","which","at","of","same","but","does"].forEach(function(e){s.addProperty(e)}),s.addProperty("not",function(){a(this,"negate",!0)}),s.addProperty("deep",function(){a(this,"deep",!0)}),s.addProperty("nested",function(){a(this,"nested",!0)}),s.addProperty("own",function(){a(this,"own",!0)}),s.addProperty("ordered",function(){a(this,"ordered",!0)}),s.addProperty("any",function(){a(this,"any",!0),a(this,"all",!1)}),s.addProperty("all",function(){a(this,"all",!0),a(this,"any",!1)}),s.addChainableMethod("an",i),s.addChainableMethod("a",i),s.addChainableMethod("include",h,n),s.addChainableMethod("contain",h,n),s.addChainableMethod("contains",h,n),s.addChainableMethod("includes",h,n),s.addProperty("ok",function(){this.assert(a(this,"object"),"expected #{this} to be truthy","expected #{this} to be falsy")}),s.addProperty("true",function(){this.assert(!0===a(this,"object"),"expected #{this} to be true","expected #{this} to be false",!a(this,"negate"))}),s.addProperty("false",function(){this.assert(!1===a(this,"object"),"expected #{this} to be false","expected #{this} to be true",!!a(this,"negate"))}),s.addProperty("null",function(){this.assert(null===a(this,"object"),"expected #{this} to be null","expected #{this} not to be null")}),s.addProperty("undefined",function(){this.assert(void 0===a(this,"object"),"expected #{this} to be undefined","expected #{this} not to be undefined")}),s.addProperty("NaN",function(){this.assert(t.isNaN(a(this,"object")),"expected #{this} to be NaN","expected #{this} not to be NaN")}),s.addProperty("exist",function(){var e=a(this,"object");this.assert(null!==e&&void 0!==e,"expected #{this} to exist","expected #{this} to not exist")}),s.addProperty("empty",function(){var e,s=a(this,"object"),i=a(this,"ssfi"),r=a(this,"message");switch(r=r?r+": ":"",t.type(s).toLowerCase()){case"array":case"string":e=s.length;break;case"map":case"set":e=s.size;break;case"weakmap":case"weakset":throw new o(r+".empty was passed a weak collection",void 0,i);case"function":var n=r+".empty was passed a function "+t.getName(s);throw new o(n.trim(),void 0,i);default:if(s!==Object(s))throw new o(r+".empty was passed non-string primitive "+t.inspect(s),void 0,i);e=Object.keys(s).length}this.assert(0===e,"expected #{this} to be empty","expected #{this} not to be empty")}),s.addProperty("arguments",d),s.addProperty("Arguments",d),s.addMethod("equal",c),s.addMethod("equals",c),s.addMethod("eq",c),s.addMethod("eql",p),s.addMethod("eqls",p),s.addMethod("above",l),s.addMethod("gt",l),s.addMethod("greaterThan",l),s.addMethod("least",u),s.addMethod("gte",u),s.addMethod("below",b),s.addMethod("lt",b),s.addMethod("lessThan",b),s.addMethod("most",f),s.addMethod("lte",f),s.addMethod("within",function(e,i,r){r&&a(this,"message",r);var n=a(this,"object"),h=a(this,"doLength"),d=a(this,"message"),c=d?d+": ":"",p=a(this,"ssfi"),l=t.type(n).toLowerCase(),u=t.type(e).toLowerCase(),b=t.type(i).toLowerCase(),f=!0,g="date"===u&&"date"===b?e.toUTCString()+".."+i.toUTCString():e+".."+i;if(h&&new s(n,d,p,!0).to.have.property("length"),h||"date"!==l||"date"===u&&"date"===b)if("number"===u&&"number"===b||!h&&"number"!==l)if(h||"date"===l||"number"===l)f=!1;else{errorMessage=c+"expected "+("string"===l?"'"+n+"'":n)+" to be a number or a date"}else errorMessage=c+"the arguments to within must be numbers";else errorMessage=c+"the arguments to within must be dates";if(f)throw new o(errorMessage,void 0,p);if(h){var m=n.length;this.assert(m>=e&&m<=i,"expected #{this} to have a length within "+g,"expected #{this} to not have a length within "+g)}else this.assert(n>=e&&n<=i,"expected #{this} to be within "+g,"expected #{this} to not be within "+g)}),s.addMethod("instanceof",g),s.addMethod("instanceOf",g),s.addMethod("property",m),s.addMethod("ownProperty",x),s.addMethod("haveOwnProperty",x),s.addMethod("ownPropertyDescriptor",w),s.addMethod("haveOwnPropertyDescriptor",w),s.addChainableMethod("length",y,v),s.addChainableMethod("lengthOf",y,v),s.addMethod("match",M),s.addMethod("matches",M),s.addMethod("string",function(e,o){o&&a(this,"message",o);var i=a(this,"object"),r=a(this,"message"),n=a(this,"ssfi");new s(i,r,n,!0).is.a("string"),this.assert(~i.indexOf(e),"expected #{this} to contain "+t.inspect(e),"expected #{this} to not contain "+t.inspect(e))}),s.addMethod("keys",j),s.addMethod("key",j),s.addMethod("throw",k),s.addMethod("throws",k),s.addMethod("Throw",k),s.addMethod("respondTo",O),s.addMethod("respondsTo",O),s.addProperty("itself",function(){a(this,"itself",!0)}),s.addMethod("satisfy",C),s.addMethod("satisfies",C),s.addMethod("closeTo",P),s.addMethod("approximately",P),s.addMethod("members",function(e,o){o&&a(this,"message",o);var i=a(this,"object"),r=a(this,"message"),n=a(this,"ssfi");new s(i,r,n,!0).to.be.an("array"),new s(e,r,n,!0).to.be.an("array");var h,d,c,p=a(this,"contains"),l=a(this,"ordered");p?(d="expected #{this} to be "+(h=l?"an ordered superset":"a superset")+" of #{exp}",c="expected #{this} to not be "+h+" of #{exp}"):(d="expected #{this} to have the same "+(h=l?"ordered members":"members")+" as #{exp}",c="expected #{this} to not have the same "+h+" as #{exp}");var u=a(this,"deep")?t.eql:void 0;this.assert(function(e,t,s,o,a){if(!o){if(e.length!==t.length)return!1;t=t.slice()}return e.every(function(e,i){if(a)return s?s(e,t[i]):e===t[i];if(!s){var r=t.indexOf(e);return-1!==r&&(o||t.splice(r,1),!0)}return t.some(function(a,i){return!!s(e,a)&&(o||t.splice(i,1),!0)})})}(e,i,u,p,l),d,c,e,i,!0)}),s.addMethod("oneOf",function(e,t){t&&a(this,"message",t);var o=a(this,"object"),i=a(this,"message"),r=a(this,"ssfi");new s(e,i,r,!0).to.be.an("array"),this.assert(e.indexOf(o)>-1,"expected #{this} to be one of #{exp}","expected #{this} to not be one of #{exp}",e,o)}),s.addMethod("change",E),s.addMethod("changes",E),s.addMethod("increase",L),s.addMethod("increases",L),s.addMethod("decrease",q),s.addMethod("decreases",q),s.addMethod("by",function(e,t){t&&a(this,"message",t);var s,o=a(this,"deltaMsgObj"),i=a(this,"initialDeltaValue"),r=a(this,"finalDeltaValue"),n=a(this,"deltaBehavior"),h=a(this,"realDelta");s="change"===n?Math.abs(r-i)===Math.abs(e):h===Math.abs(e),this.assert(s,"expected "+o+" to "+n+" by "+e,"expected "+o+" to not "+n+" by "+e)}),s.addProperty("extensible",function(){var e=a(this,"object"),t=e===Object(e)&&Object.isExtensible(e);this.assert(t,"expected #{this} to be extensible","expected #{this} to not be extensible")}),s.addProperty("sealed",function(){var e=a(this,"object"),t=e!==Object(e)||Object.isSealed(e);this.assert(t,"expected #{this} to be sealed","expected #{this} to not be sealed")}),s.addProperty("frozen",function(){var e=a(this,"object"),t=e!==Object(e)||Object.isFrozen(e);this.assert(t,"expected #{this} to be frozen","expected #{this} to not be frozen")}),s.addProperty("finite",function(e){var t=a(this,"object");this.assert("number"==typeof t&&isFinite(t),"expected #{this} to be a finite number","expected #{this} to not be a finite number")})}},{}],18:[function(require,module,exports){
/*!
 * chai
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,n){
/*!
   * Chai dependencies.
   */
var t=e.Assertion,o=n.flag,s=e.assert=function(n,o){new t(null,null,e.assert,!0).assert(n,o,"[ negation message unavailable ]")};
/*!
   * Module export.
   */s.fail=function(n,t,o,i){throw o=o||"assert.fail()",new e.AssertionError(o,{actual:n,expected:t,operator:i},s.fail)},s.isOk=function(e,n){new t(e,n,s.isOk,!0).is.ok},s.isNotOk=function(e,n){new t(e,n,s.isNotOk,!0).is.not.ok},s.equal=function(e,n,i){var r=new t(e,i,s.equal,!0);r.assert(n==o(r,"object"),"expected #{this} to equal #{exp}","expected #{this} to not equal #{act}",n,e,!0)},s.notEqual=function(e,n,i){var r=new t(e,i,s.notEqual,!0);r.assert(n!=o(r,"object"),"expected #{this} to not equal #{exp}","expected #{this} to equal #{act}",n,e,!0)},s.strictEqual=function(e,n,o){new t(e,o,s.strictEqual,!0).to.equal(n)},s.notStrictEqual=function(e,n,o){new t(e,o,s.notStrictEqual,!0).to.not.equal(n)},s.deepEqual=s.deepStrictEqual=function(e,n,o){new t(e,o,s.deepEqual,!0).to.eql(n)},s.notDeepEqual=function(e,n,o){new t(e,o,s.notDeepEqual,!0).to.not.eql(n)},s.isAbove=function(e,n,o){new t(e,o,s.isAbove,!0).to.be.above(n)},s.isAtLeast=function(e,n,o){new t(e,o,s.isAtLeast,!0).to.be.least(n)},s.isBelow=function(e,n,o){new t(e,o,s.isBelow,!0).to.be.below(n)},s.isAtMost=function(e,n,o){new t(e,o,s.isAtMost,!0).to.be.most(n)},s.isTrue=function(e,n){new t(e,n,s.isTrue,!0).is.true},s.isNotTrue=function(e,n){new t(e,n,s.isNotTrue,!0).to.not.equal(!0)},s.isFalse=function(e,n){new t(e,n,s.isFalse,!0).is.false},s.isNotFalse=function(e,n){new t(e,n,s.isNotFalse,!0).to.not.equal(!1)},s.isNull=function(e,n){new t(e,n,s.isNull,!0).to.equal(null)},s.isNotNull=function(e,n){new t(e,n,s.isNotNull,!0).to.not.equal(null)},s.isNaN=function(e,n){new t(e,n,s.isNaN,!0).to.be.NaN},s.isNotNaN=function(e,n){new t(e,n,s.isNotNaN,!0).not.to.be.NaN},s.exists=function(e,n){new t(e,n,s.exists,!0).to.exist},s.notExists=function(e,n){new t(e,n,s.notExists,!0).to.not.exist},s.isUndefined=function(e,n){new t(e,n,s.isUndefined,!0).to.equal(void 0)},s.isDefined=function(e,n){new t(e,n,s.isDefined,!0).to.not.equal(void 0)},s.isFunction=function(e,n){new t(e,n,s.isFunction,!0).to.be.a("function")},s.isNotFunction=function(e,n){new t(e,n,s.isNotFunction,!0).to.not.be.a("function")},s.isObject=function(e,n){new t(e,n,s.isObject,!0).to.be.a("object")},s.isNotObject=function(e,n){new t(e,n,s.isNotObject,!0).to.not.be.a("object")},s.isArray=function(e,n){new t(e,n,s.isArray,!0).to.be.an("array")},s.isNotArray=function(e,n){new t(e,n,s.isNotArray,!0).to.not.be.an("array")},s.isString=function(e,n){new t(e,n,s.isString,!0).to.be.a("string")},s.isNotString=function(e,n){new t(e,n,s.isNotString,!0).to.not.be.a("string")},s.isNumber=function(e,n){new t(e,n,s.isNumber,!0).to.be.a("number")},s.isNotNumber=function(e,n){new t(e,n,s.isNotNumber,!0).to.not.be.a("number")},s.isFinite=function(e,n){new t(e,n,s.isFinite,!0).to.be.finite},s.isBoolean=function(e,n){new t(e,n,s.isBoolean,!0).to.be.a("boolean")},s.isNotBoolean=function(e,n){new t(e,n,s.isNotBoolean,!0).to.not.be.a("boolean")},s.typeOf=function(e,n,o){new t(e,o,s.typeOf,!0).to.be.a(n)},s.notTypeOf=function(e,n,o){new t(e,o,s.notTypeOf,!0).to.not.be.a(n)},s.instanceOf=function(e,n,o){new t(e,o,s.instanceOf,!0).to.be.instanceOf(n)},s.notInstanceOf=function(e,n,o){new t(e,o,s.notInstanceOf,!0).to.not.be.instanceOf(n)},s.include=function(e,n,o){new t(e,o,s.include,!0).include(n)},s.notInclude=function(e,n,o){new t(e,o,s.notInclude,!0).not.include(n)},s.deepInclude=function(e,n,o){new t(e,o,s.deepInclude,!0).deep.include(n)},s.notDeepInclude=function(e,n,o){new t(e,o,s.notDeepInclude,!0).not.deep.include(n)},s.nestedInclude=function(e,n,o){new t(e,o,s.nestedInclude,!0).nested.include(n)},s.notNestedInclude=function(e,n,o){new t(e,o,s.notNestedInclude,!0).not.nested.include(n)},s.deepNestedInclude=function(e,n,o){new t(e,o,s.deepNestedInclude,!0).deep.nested.include(n)},s.notDeepNestedInclude=function(e,n,o){new t(e,o,s.notDeepNestedInclude,!0).not.deep.nested.include(n)},s.ownInclude=function(e,n,o){new t(e,o,s.ownInclude,!0).own.include(n)},s.notOwnInclude=function(e,n,o){new t(e,o,s.notOwnInclude,!0).not.own.include(n)},s.deepOwnInclude=function(e,n,o){new t(e,o,s.deepOwnInclude,!0).deep.own.include(n)},s.notDeepOwnInclude=function(e,n,o){new t(e,o,s.notDeepOwnInclude,!0).not.deep.own.include(n)},s.match=function(e,n,o){new t(e,o,s.match,!0).to.match(n)},s.notMatch=function(e,n,o){new t(e,o,s.notMatch,!0).to.not.match(n)},s.property=function(e,n,o){new t(e,o,s.property,!0).to.have.property(n)},s.notProperty=function(e,n,o){new t(e,o,s.notProperty,!0).to.not.have.property(n)},s.propertyVal=function(e,n,o,i){new t(e,i,s.propertyVal,!0).to.have.property(n,o)},s.notPropertyVal=function(e,n,o,i){new t(e,i,s.notPropertyVal,!0).to.not.have.property(n,o)},s.deepPropertyVal=function(e,n,o,i){new t(e,i,s.deepPropertyVal,!0).to.have.deep.property(n,o)},s.notDeepPropertyVal=function(e,n,o,i){new t(e,i,s.notDeepPropertyVal,!0).to.not.have.deep.property(n,o)},s.ownProperty=function(e,n,o){new t(e,o,s.ownProperty,!0).to.have.own.property(n)},s.notOwnProperty=function(e,n,o){new t(e,o,s.notOwnProperty,!0).to.not.have.own.property(n)},s.ownPropertyVal=function(e,n,o,i){new t(e,i,s.ownPropertyVal,!0).to.have.own.property(n,o)},s.notOwnPropertyVal=function(e,n,o,i){new t(e,i,s.notOwnPropertyVal,!0).to.not.have.own.property(n,o)},s.deepOwnPropertyVal=function(e,n,o,i){new t(e,i,s.deepOwnPropertyVal,!0).to.have.deep.own.property(n,o)},s.notDeepOwnPropertyVal=function(e,n,o,i){new t(e,i,s.notDeepOwnPropertyVal,!0).to.not.have.deep.own.property(n,o)},s.nestedProperty=function(e,n,o){new t(e,o,s.nestedProperty,!0).to.have.nested.property(n)},s.notNestedProperty=function(e,n,o){new t(e,o,s.notNestedProperty,!0).to.not.have.nested.property(n)},s.nestedPropertyVal=function(e,n,o,i){new t(e,i,s.nestedPropertyVal,!0).to.have.nested.property(n,o)},s.notNestedPropertyVal=function(e,n,o,i){new t(e,i,s.notNestedPropertyVal,!0).to.not.have.nested.property(n,o)},s.deepNestedPropertyVal=function(e,n,o,i){new t(e,i,s.deepNestedPropertyVal,!0).to.have.deep.nested.property(n,o)},s.notDeepNestedPropertyVal=function(e,n,o,i){new t(e,i,s.notDeepNestedPropertyVal,!0).to.not.have.deep.nested.property(n,o)},s.lengthOf=function(e,n,o){new t(e,o,s.lengthOf,!0).to.have.lengthOf(n)},s.hasAnyKeys=function(e,n,o){new t(e,o,s.hasAnyKeys,!0).to.have.any.keys(n)},s.hasAllKeys=function(e,n,o){new t(e,o,s.hasAllKeys,!0).to.have.all.keys(n)},s.containsAllKeys=function(e,n,o){new t(e,o,s.containsAllKeys,!0).to.contain.all.keys(n)},s.doesNotHaveAnyKeys=function(e,n,o){new t(e,o,s.doesNotHaveAnyKeys,!0).to.not.have.any.keys(n)},s.doesNotHaveAllKeys=function(e,n,o){new t(e,o,s.doesNotHaveAllKeys,!0).to.not.have.all.keys(n)},s.hasAnyDeepKeys=function(e,n,o){new t(e,o,s.hasAnyDeepKeys,!0).to.have.any.deep.keys(n)},s.hasAllDeepKeys=function(e,n,o){new t(e,o,s.hasAllDeepKeys,!0).to.have.all.deep.keys(n)},s.containsAllDeepKeys=function(e,n,o){new t(e,o,s.containsAllDeepKeys,!0).to.contain.all.deep.keys(n)},s.doesNotHaveAnyDeepKeys=function(e,n,o){new t(e,o,s.doesNotHaveAnyDeepKeys,!0).to.not.have.any.deep.keys(n)},s.doesNotHaveAllDeepKeys=function(e,n,o){new t(e,o,s.doesNotHaveAllDeepKeys,!0).to.not.have.all.deep.keys(n)},s.throws=function(e,n,i,r){("string"==typeof n||n instanceof RegExp)&&(i=n,n=null);var c=new t(e,r,s.throws,!0).to.throw(n,i);return o(c,"object")},s.doesNotThrow=function(e,n,o,i){("string"==typeof n||n instanceof RegExp)&&(o=n,n=null),new t(e,i,s.doesNotThrow,!0).to.not.throw(n,o)},s.operator=function(i,r,c,a){var u;switch(r){case"==":u=i==c;break;case"===":u=i===c;break;case">":u=i>c;break;case">=":u=i>=c;break;case"<":u=i<c;break;case"<=":u=i<=c;break;case"!=":u=i!=c;break;case"!==":u=i!==c;break;default:throw a=a?a+": ":a,new e.AssertionError(a+'Invalid operator "'+r+'"',void 0,s.operator)}var l=new t(u,a,s.operator,!0);l.assert(!0===o(l,"object"),"expected "+n.inspect(i)+" to be "+r+" "+n.inspect(c),"expected "+n.inspect(i)+" to not be "+r+" "+n.inspect(c))},s.closeTo=function(e,n,o,i){new t(e,i,s.closeTo,!0).to.be.closeTo(n,o)},s.approximately=function(e,n,o,i){new t(e,i,s.approximately,!0).to.be.approximately(n,o)},s.sameMembers=function(e,n,o){new t(e,o,s.sameMembers,!0).to.have.same.members(n)},s.notSameMembers=function(e,n,o){new t(e,o,s.notSameMembers,!0).to.not.have.same.members(n)},s.sameDeepMembers=function(e,n,o){new t(e,o,s.sameDeepMembers,!0).to.have.same.deep.members(n)},s.notSameDeepMembers=function(e,n,o){new t(e,o,s.notSameDeepMembers,!0).to.not.have.same.deep.members(n)},s.sameOrderedMembers=function(e,n,o){new t(e,o,s.sameOrderedMembers,!0).to.have.same.ordered.members(n)},s.notSameOrderedMembers=function(e,n,o){new t(e,o,s.notSameOrderedMembers,!0).to.not.have.same.ordered.members(n)},s.sameDeepOrderedMembers=function(e,n,o){new t(e,o,s.sameDeepOrderedMembers,!0).to.have.same.deep.ordered.members(n)},s.notSameDeepOrderedMembers=function(e,n,o){new t(e,o,s.notSameDeepOrderedMembers,!0).to.not.have.same.deep.ordered.members(n)},s.includeMembers=function(e,n,o){new t(e,o,s.includeMembers,!0).to.include.members(n)},s.notIncludeMembers=function(e,n,o){new t(e,o,s.notIncludeMembers,!0).to.not.include.members(n)},s.includeDeepMembers=function(e,n,o){new t(e,o,s.includeDeepMembers,!0).to.include.deep.members(n)},s.notIncludeDeepMembers=function(e,n,o){new t(e,o,s.notIncludeDeepMembers,!0).to.not.include.deep.members(n)},s.includeOrderedMembers=function(e,n,o){new t(e,o,s.includeOrderedMembers,!0).to.include.ordered.members(n)},s.notIncludeOrderedMembers=function(e,n,o){new t(e,o,s.notIncludeOrderedMembers,!0).to.not.include.ordered.members(n)},s.includeDeepOrderedMembers=function(e,n,o){new t(e,o,s.includeDeepOrderedMembers,!0).to.include.deep.ordered.members(n)},s.notIncludeDeepOrderedMembers=function(e,n,o){new t(e,o,s.notIncludeDeepOrderedMembers,!0).to.not.include.deep.ordered.members(n)},s.oneOf=function(e,n,o){new t(e,o,s.oneOf,!0).to.be.oneOf(n)},s.changes=function(e,n,o,i){3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.changes,!0).to.change(n,o)},s.changesBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.changesBy,!0).to.change(n,o).by(i)},s.doesNotChange=function(e,n,o,i){return 3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.doesNotChange,!0).to.not.change(n,o)},s.changesButNotBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.changesButNotBy,!0).to.change(n,o).but.not.by(i)},s.increases=function(e,n,o,i){return 3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.increases,!0).to.increase(n,o)},s.increasesBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.increasesBy,!0).to.increase(n,o).by(i)},s.doesNotIncrease=function(e,n,o,i){return 3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.doesNotIncrease,!0).to.not.increase(n,o)},s.increasesButNotBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.increasesButNotBy,!0).to.increase(n,o).but.not.by(i)},s.decreases=function(e,n,o,i){return 3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.decreases,!0).to.decrease(n,o)},s.decreasesBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.decreasesBy,!0).to.decrease(n,o).by(i)},s.doesNotDecrease=function(e,n,o,i){return 3===arguments.length&&"function"==typeof n&&(i=o,o=null),new t(e,i,s.doesNotDecrease,!0).to.not.decrease(n,o)},s.doesNotDecreaseBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);return new t(e,r,s.doesNotDecreaseBy,!0).to.not.decrease(n,o).by(i)},s.decreasesButNotBy=function(e,n,o,i,r){if(4===arguments.length&&"function"==typeof n){var c=i;i=o,r=c}else 3===arguments.length&&(i=o,o=null);new t(e,r,s.decreasesButNotBy,!0).to.decrease(n,o).but.not.by(i)}
/*!
   * ### .ifError(object)
   *
   * Asserts if value is not a false value, and throws if it is a true value.
   * This is added to allow for chai to be a drop-in replacement for Node's
   * assert class.
   *
   *     var err = new Error('I am a custom error');
   *     assert.ifError(err); // Rethrows err!
   *
   * @name ifError
   * @param {Object} object
   * @namespace Assert
   * @api public
   */,s.ifError=function(e){if(e)throw e},s.isExtensible=function(e,n){new t(e,n,s.isExtensible,!0).to.be.extensible},s.isNotExtensible=function(e,n){new t(e,n,s.isNotExtensible,!0).to.not.be.extensible},s.isSealed=function(e,n){new t(e,n,s.isSealed,!0).to.be.sealed},s.isNotSealed=function(e,n){new t(e,n,s.isNotSealed,!0).to.not.be.sealed},s.isFrozen=function(e,n){new t(e,n,s.isFrozen,!0).to.be.frozen},s.isNotFrozen=function(e,n){new t(e,n,s.isNotFrozen,!0).to.not.be.frozen},s.isEmpty=function(e,n){new t(e,n,s.isEmpty,!0).to.be.empty},s.isNotEmpty=function(e,n){new t(e,n,s.isNotEmpty,!0).to.not.be.empty},
/*!
   * Aliases.
   */
function e(n,t){return s[t]=s[n],e}("isOk","ok")("isNotOk","notOk")("throws","throw")("throws","Throw")("isExtensible","extensible")("isNotExtensible","notExtensible")("isSealed","sealed")("isNotSealed","notSealed")("isFrozen","frozen")("isNotFrozen","notFrozen")("isEmpty","empty")("isNotEmpty","notEmpty")}},{}],19:[function(require,module,exports){
/*!
 * chai
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,t){e.expect=function(t,n){return new e.Assertion(t,n)},e.expect.fail=function(t,n,o,r){throw o=o||"expect.fail()",new e.AssertionError(o,{actual:t,expected:n,operator:r},e.expect.fail)}}},{}],20:[function(require,module,exports){
/*!
 * chai
 * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(t,n){var o=t.Assertion;function e(){Object.defineProperty(Object.prototype,"should",{set:function(t){Object.defineProperty(this,"should",{value:t,enumerable:!0,configurable:!0,writable:!0})},get:function t(){return this instanceof String||this instanceof Number||this instanceof Boolean||"function"==typeof Symbol&&this instanceof Symbol?new o(this.valueOf(),null,t):new o(this,null,t)},configurable:!0});var n={fail:function(o,e,i,r){throw i=i||"should.fail()",new t.AssertionError(i,{actual:o,expected:e,operator:r},n.fail)},equal:function(t,n,e){new o(t,e).to.equal(n)},Throw:function(t,n,e,i){new o(t,i).to.Throw(n,e)},exist:function(t,n){new o(t,n).to.exist},not:{}};return n.not.equal=function(t,n,e){new o(t,e).to.not.equal(n)},n.not.Throw=function(t,n,e,i){new o(t,i).to.not.Throw(n,e)},n.not.exist=function(t,n){new o(t,n).to.not.exist},n.throw=n.Throw,n.not.throw=n.not.Throw,n}t.should=e,t.Should=e}},{}],21:[function(require,module,exports){
/*!
 * Chai - addChainingMethod utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependencies
 */
var addLengthGuard=require("./addLengthGuard"),chai=require("../../chai"),flag=require("./flag"),proxify=require("./proxify"),transferFlags=require("./transferFlags"),canSetPrototype="function"==typeof Object.setPrototypeOf,testFn=function(){},excludeNames=Object.getOwnPropertyNames(testFn).filter(function(e){var t=Object.getOwnPropertyDescriptor(testFn,e);return"object"!=typeof t||!t.configurable}),call=Function.prototype.call,apply=Function.prototype.apply;module.exports=function(e,t,r,a){"function"!=typeof a&&(a=function(){});var n={method:r,chainingBehavior:a};e.__methods||(e.__methods={}),e.__methods[t]=n,Object.defineProperty(e,t,{get:function(){n.chainingBehavior.call(this);var r=function(){flag(this,"lockSsfi")||flag(this,"ssfi",r);var e=n.method.apply(this,arguments);if(void 0!==e)return e;var t=new chai.Assertion;return transferFlags(this,t),t};if(addLengthGuard(r,t,!0),canSetPrototype){var a=Object.create(this);a.call=call,a.apply=apply,Object.setPrototypeOf(r,a)}else{Object.getOwnPropertyNames(e).forEach(function(t){if(-1===excludeNames.indexOf(t)){var a=Object.getOwnPropertyDescriptor(e,t);Object.defineProperty(r,t,a)}})}return transferFlags(this,r),proxify(r)},configurable:!0})}},{"../../chai":14,"./addLengthGuard":22,"./flag":27,"./proxify":42,"./transferFlags":44}],22:[function(require,module,exports){var config=require("../config"),fnLengthDesc=Object.getOwnPropertyDescriptor(function(){},"length");
/*!
 * Chai - addLengthGuard utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */module.exports=function(e,t,r){return fnLengthDesc.configurable?(Object.defineProperty(e,"length",{get:function(){if(r)throw Error("Invalid Chai property: "+t+'.length. Due to a compatibility issue, "length" cannot directly follow "'+t+'". Use "'+t+'.lengthOf" instead.');throw Error("Invalid Chai property: "+t+'.length. See docs for proper usage of "'+t+'".')}}),e):e}},{"../config":16}],23:[function(require,module,exports){
/*!
 * Chai - addMethod utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var addLengthGuard=require("./addLengthGuard"),chai=require("../../chai"),flag=require("./flag"),proxify=require("./proxify"),transferFlags=require("./transferFlags");module.exports=function(r,a,e){var i=function(){flag(this,"lockSsfi")||flag(this,"ssfi",i);var r=e.apply(this,arguments);if(void 0!==r)return r;var a=new chai.Assertion;return transferFlags(this,a),a};addLengthGuard(i,a,!1),r[a]=proxify(i,a)}},{"../../chai":14,"./addLengthGuard":22,"./flag":27,"./proxify":42,"./transferFlags":44}],24:[function(require,module,exports){
/*!
 * Chai - addProperty utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var chai=require("../../chai"),flag=require("./flag"),isProxyEnabled=require("./isProxyEnabled"),transferFlags=require("./transferFlags");module.exports=function(r,e,i){i=void 0===i?function(){}:i,Object.defineProperty(r,e,{get:function r(){isProxyEnabled()||flag(this,"lockSsfi")||flag(this,"ssfi",r);var e=i.call(this);if(void 0!==e)return e;var a=new chai.Assertion;return transferFlags(this,a),a},configurable:!0})}},{"../../chai":14,"./flag":27,"./isProxyEnabled":37,"./transferFlags":44}],25:[function(require,module,exports){
/*!
 * Chai - compareByInspect utility
 * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependancies
 */
var inspect=require("./inspect");module.exports=function(e,n){return inspect(e)<inspect(n)?-1:1}},{"./inspect":35}],26:[function(require,module,exports){
/*!
 * Chai - expectTypes utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var AssertionError=require("assertion-error"),flag=require("./flag"),type=require("type-detect");module.exports=function(e,r){var t=flag(e,"message"),o=flag(e,"ssfi");t=t?t+": ":"",e=flag(e,"object"),(r=r.map(function(e){return e.toLowerCase()})).sort();var n=r.map(function(e,t){var o=~["a","e","i","o","u"].indexOf(e.charAt(0))?"an":"a";return(r.length>1&&t===r.length-1?"or ":"")+o+" "+e}).join(", "),a=type(e).toLowerCase();if(!r.some(function(e){return a===e}))throw new AssertionError(t+"object tested must be "+n+", but "+a+" given",void 0,o)}},{"./flag":27,"assertion-error":11,"type-detect":53}],27:[function(require,module,exports){
/*!
 * Chai - flag utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,l,t){var n=e.__flags||(e.__flags=Object.create(null));if(3!==arguments.length)return n[l];n[l]=t}},{}],28:[function(require,module,exports){
/*!
 * Chai - getActual utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,n){return n.length>4?n[4]:e._obj}},{}],29:[function(require,module,exports){
/*!
 * Chai - getEnumerableProperties utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(r){var n=[];for(var o in r)n.push(o);return n}},{}],30:[function(require,module,exports){
/*!
 * Chai - message composition utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependancies
 */
var flag=require("./flag"),getActual=require("./getActual"),inspect=require("./inspect"),objDisplay=require("./objDisplay");module.exports=function(e,t){var r=flag(e,"negate"),a=flag(e,"object"),i=t[3],l=getActual(e,t),n=r?t[2]:t[1],u=flag(e,"message");return"function"==typeof n&&(n=n()),n=(n=n||"").replace(/#\{this\}/g,function(){return objDisplay(a)}).replace(/#\{act\}/g,function(){return objDisplay(l)}).replace(/#\{exp\}/g,function(){return objDisplay(i)}),u?u+": "+n:n}},{"./flag":27,"./getActual":28,"./inspect":35,"./objDisplay":38}],31:[function(require,module,exports){
/*!
 * Chai - getOwnEnumerableProperties utility
 * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependancies
 */
var getOwnEnumerablePropertySymbols=require("./getOwnEnumerablePropertySymbols");module.exports=function(e){return Object.keys(e).concat(getOwnEnumerablePropertySymbols(e))}},{"./getOwnEnumerablePropertySymbols":32}],32:[function(require,module,exports){
/*!
 * Chai - getOwnEnumerablePropertySymbols utility
 * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e){return"function"!=typeof Object.getOwnPropertySymbols?[]:Object.getOwnPropertySymbols(e).filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})}},{}],33:[function(require,module,exports){
/*!
 * Chai - getProperties utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e){var t=Object.getOwnPropertyNames(e);function r(e){-1===t.indexOf(e)&&t.push(e)}for(var o=Object.getPrototypeOf(e);null!==o;)Object.getOwnPropertyNames(o).forEach(r),o=Object.getPrototypeOf(o);return t}},{}],34:[function(require,module,exports){
/*!
 * chai
 * Copyright(c) 2011 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Dependencies that are used for multiple exports are required here only once
 */
var pathval=require("pathval");
/*!
 * test utility
 */exports.test=require("./test"),
/*!
 * type utility
 */
exports.type=require("type-detect"),
/*!
 * expectTypes utility
 */
exports.expectTypes=require("./expectTypes"),
/*!
 * message utility
 */
exports.getMessage=require("./getMessage"),
/*!
 * actual utility
 */
exports.getActual=require("./getActual"),
/*!
 * Inspect util
 */
exports.inspect=require("./inspect"),
/*!
 * Object Display util
 */
exports.objDisplay=require("./objDisplay"),
/*!
 * Flag utility
 */
exports.flag=require("./flag"),
/*!
 * Flag transferring utility
 */
exports.transferFlags=require("./transferFlags"),
/*!
 * Deep equal utility
 */
exports.eql=require("deep-eql"),
/*!
 * Deep path info
 */
exports.getPathInfo=pathval.getPathInfo,
/*!
 * Check if a property exists
 */
exports.hasProperty=pathval.hasProperty,
/*!
 * Function name
 */
exports.getName=require("get-func-name"),
/*!
 * add Property
 */
exports.addProperty=require("./addProperty"),
/*!
 * add Method
 */
exports.addMethod=require("./addMethod"),
/*!
 * overwrite Property
 */
exports.overwriteProperty=require("./overwriteProperty"),
/*!
 * overwrite Method
 */
exports.overwriteMethod=require("./overwriteMethod"),
/*!
 * Add a chainable method
 */
exports.addChainableMethod=require("./addChainableMethod"),
/*!
 * Overwrite chainable method
 */
exports.overwriteChainableMethod=require("./overwriteChainableMethod"),
/*!
 * Compare by inspect method
 */
exports.compareByInspect=require("./compareByInspect"),
/*!
 * Get own enumerable property symbols method
 */
exports.getOwnEnumerablePropertySymbols=require("./getOwnEnumerablePropertySymbols"),
/*!
 * Get own enumerable properties method
 */
exports.getOwnEnumerableProperties=require("./getOwnEnumerableProperties"),
/*!
 * Checks error against a given set of criteria
 */
exports.checkError=require("check-error"),
/*!
 * Proxify util
 */
exports.proxify=require("./proxify"),
/*!
 * addLengthGuard util
 */
exports.addLengthGuard=require("./addLengthGuard"),
/*!
 * isProxyEnabled helper
 */
exports.isProxyEnabled=require("./isProxyEnabled"),
/*!
 * isNaN method
 */
exports.isNaN=require("./isNaN")},{"./addChainableMethod":21,"./addLengthGuard":22,"./addMethod":23,"./addProperty":24,"./compareByInspect":25,"./expectTypes":26,"./flag":27,"./getActual":28,"./getMessage":30,"./getOwnEnumerableProperties":31,"./getOwnEnumerablePropertySymbols":32,"./inspect":35,"./isNaN":36,"./isProxyEnabled":37,"./objDisplay":38,"./overwriteChainableMethod":39,"./overwriteMethod":40,"./overwriteProperty":41,"./proxify":42,"./test":43,"./transferFlags":44,"check-error":45,"deep-eql":47,"get-func-name":48,pathval:49,"type-detect":53}],35:[function(require,module,exports){var getName=require("get-func-name"),getProperties=require("./getProperties"),getEnumerableProperties=require("./getEnumerableProperties"),config=require("../config");function inspect(e,t,r,n){return formatValue({showHidden:t,seen:[],stylize:function(e){return e}},e,void 0===r?2:r)}module.exports=inspect;var isDOMElement=function(e){return"object"==typeof HTMLElement?e instanceof HTMLElement:e&&"object"==typeof e&&"nodeType"in e&&1===e.nodeType&&"string"==typeof e.nodeName};function formatValue(e,t,r){if(t&&"function"==typeof t.inspect&&t.inspect!==exports.inspect&&(!t.constructor||t.constructor.prototype!==t)){var n=t.inspect(r,e);return"string"!=typeof n&&(n=formatValue(e,n,r)),n}var i=formatPrimitive(e,t);if(i)return i;if(isDOMElement(t)){if("outerHTML"in t)return t.outerHTML;try{if(document.xmlVersion)return(new XMLSerializer).serializeToString(t);var o=document.createElementNS("http://www.w3.org/1999/xhtml","_");o.appendChild(t.cloneNode(!1));var a=o.innerHTML.replace("><",">"+t.innerHTML+"<");return o.innerHTML="",a}catch(e){}}var c,u,s=getEnumerableProperties(t),l=e.showHidden?getProperties(t):s;if(0===l.length||isError(t)&&(1===l.length&&"stack"===l[0]||2===l.length&&"description"===l[0]&&"stack"===l[1])){if("function"==typeof t)return u=(c=getName(t))?": "+c:"",e.stylize("[Function"+u+"]","special");if(isRegExp(t))return e.stylize(RegExp.prototype.toString.call(t),"regexp");if(isDate(t))return e.stylize(Date.prototype.toUTCString.call(t),"date");if(isError(t))return formatError(t)}var p,f="",g=!1,y=!1,m=["{","}"];if(isTypedArray(t)&&(y=!0,m=["[","]"]),isArray(t)&&(g=!0,m=["[","]"]),"function"==typeof t&&(f=" [Function"+(u=(c=getName(t))?": "+c:"")+"]"),isRegExp(t)&&(f=" "+RegExp.prototype.toString.call(t)),isDate(t)&&(f=" "+Date.prototype.toUTCString.call(t)),isError(t))return formatError(t);if(0===l.length&&(!g||0==t.length))return m[0]+f+m[1];if(r<0)return isRegExp(t)?e.stylize(RegExp.prototype.toString.call(t),"regexp"):e.stylize("[Object]","special");if(e.seen.push(t),g)p=formatArray(e,t,r,s,l);else{if(y)return formatTypedArray(t);p=l.map(function(n){return formatProperty(e,t,r,s,n,g)})}return e.seen.pop(),reduceToSingleString(p,f,m)}function formatPrimitive(e,t){switch(typeof t){case"undefined":return e.stylize("undefined","undefined");case"string":var r="'"+JSON.stringify(t).replace(/^"|"$/g,"").replace(/'/g,"\\'").replace(/\\"/g,'"')+"'";return e.stylize(r,"string");case"number":return 0===t&&1/t==-1/0?e.stylize("-0","number"):e.stylize(""+t,"number");case"boolean":return e.stylize(""+t,"boolean");case"symbol":return e.stylize(t.toString(),"symbol")}if(null===t)return e.stylize("null","null")}function formatError(e){return"["+Error.prototype.toString.call(e)+"]"}function formatArray(e,t,r,n,i){for(var o=[],a=0,c=t.length;a<c;++a)Object.prototype.hasOwnProperty.call(t,String(a))?o.push(formatProperty(e,t,r,n,String(a),!0)):o.push("");return i.forEach(function(i){i.match(/^\d+$/)||o.push(formatProperty(e,t,r,n,i,!0))}),o}function formatTypedArray(e){for(var t="[ ",r=0;r<e.length;++r){if(t.length>=config.truncateThreshold-7){t+="...";break}t+=e[r]+", "}return-1!==(t+=" ]").indexOf(",  ]")&&(t=t.replace(",  ]"," ]")),t}function formatProperty(e,t,r,n,i,o){var a,c,u=Object.getOwnPropertyDescriptor(t,i);if(u&&(u.get?c=u.set?e.stylize("[Getter/Setter]","special"):e.stylize("[Getter]","special"):u.set&&(c=e.stylize("[Setter]","special"))),n.indexOf(i)<0&&(a="["+i+"]"),c||(e.seen.indexOf(t[i])<0?(c=formatValue(e,t[i],null===r?null:r-1)).indexOf("\n")>-1&&(c=o?c.split("\n").map(function(e){return"  "+e}).join("\n").substr(2):"\n"+c.split("\n").map(function(e){return"   "+e}).join("\n")):c=e.stylize("[Circular]","special")),void 0===a){if(o&&i.match(/^\d+$/))return c;(a=JSON.stringify(""+i)).match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)?(a=a.substr(1,a.length-2),a=e.stylize(a,"name")):(a=a.replace(/'/g,"\\'").replace(/\\"/g,'"').replace(/(^"|"$)/g,"'"),a=e.stylize(a,"string"))}return a+": "+c}function reduceToSingleString(e,t,r){return e.reduce(function(e,t){return 0,t.indexOf("\n")>=0&&0,e+t.length+1},0)>60?r[0]+(""===t?"":t+"\n ")+" "+e.join(",\n  ")+" "+r[1]:r[0]+t+" "+e.join(", ")+" "+r[1]}function isTypedArray(e){return"object"==typeof e&&/\w+Array]$/.test(objectToString(e))}function isArray(e){return Array.isArray(e)||"object"==typeof e&&"[object Array]"===objectToString(e)}function isRegExp(e){return"object"==typeof e&&"[object RegExp]"===objectToString(e)}function isDate(e){return"object"==typeof e&&"[object Date]"===objectToString(e)}function isError(e){return"object"==typeof e&&"[object Error]"===objectToString(e)}function objectToString(e){return Object.prototype.toString.call(e)}},{"../config":16,"./getEnumerableProperties":29,"./getProperties":33,"get-func-name":48}],36:[function(require,module,exports){
/*!
 * Chai - isNaN utility
 * Copyright(c) 2012-2015 Sakthipriyan Vairamani <thechargingvolcano@gmail.com>
 * MIT Licensed
 */
function isNaN(N){return N!=N}module.exports=Number.isNaN||isNaN},{}],37:[function(require,module,exports){var config=require("../config");
/*!
 * Chai - isProxyEnabled helper
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */module.exports=function(){return config.useProxy&&"undefined"!=typeof Proxy&&"undefined"!=typeof Reflect}},{"../config":16}],38:[function(require,module,exports){
/*!
 * Chai - flag utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependancies
 */
var inspect=require("./inspect"),config=require("../config");module.exports=function(e){var n=inspect(e),t=Object.prototype.toString.call(e);if(config.truncateThreshold&&n.length>=config.truncateThreshold){if("[object Function]"===t)return e.name&&""!==e.name?"[Function: "+e.name+"]":"[Function]";if("[object Array]"===t)return"[ Array("+e.length+") ]";if("[object Object]"===t){var r=Object.keys(e);return"{ Object ("+(r.length>2?r.splice(0,2).join(", ")+", ...":r.join(", "))+") }"}return n}return n}},{"../config":16,"./inspect":35}],39:[function(require,module,exports){
/*!
 * Chai - overwriteChainableMethod utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var chai=require("../../chai"),transferFlags=require("./transferFlags");module.exports=function(r,a,i,e){var n=r.__methods[a],t=n.chainingBehavior;n.chainingBehavior=function(){var r=e(t).call(this);if(void 0!==r)return r;var a=new chai.Assertion;return transferFlags(this,a),a};var s=n.method;n.method=function(){var r=i(s).apply(this,arguments);if(void 0!==r)return r;var a=new chai.Assertion;return transferFlags(this,a),a}}},{"../../chai":14,"./transferFlags":44}],40:[function(require,module,exports){
/*!
 * Chai - overwriteMethod utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var addLengthGuard=require("./addLengthGuard"),chai=require("../../chai"),flag=require("./flag"),proxify=require("./proxify"),transferFlags=require("./transferFlags");module.exports=function(r,i,a){var f=r[i],t=function(){throw new Error(i+" is not a function")};f&&"function"==typeof f&&(t=f);var e=function(){flag(this,"lockSsfi")||flag(this,"ssfi",e);var r=flag(this,"lockSsfi");flag(this,"lockSsfi",!0);var i=a(t).apply(this,arguments);if(flag(this,"lockSsfi",r),void 0!==i)return i;var f=new chai.Assertion;return transferFlags(this,f),f};addLengthGuard(e,i,!1),r[i]=proxify(e,i)}},{"../../chai":14,"./addLengthGuard":22,"./flag":27,"./proxify":42,"./transferFlags":44}],41:[function(require,module,exports){
/*!
 * Chai - overwriteProperty utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
var chai=require("../../chai"),flag=require("./flag"),isProxyEnabled=require("./isProxyEnabled"),transferFlags=require("./transferFlags");module.exports=function(r,e,i){var t=Object.getOwnPropertyDescriptor(r,e),a=function(){};t&&"function"==typeof t.get&&(a=t.get),Object.defineProperty(r,e,{get:function r(){isProxyEnabled()||flag(this,"lockSsfi")||flag(this,"ssfi",r);var e=flag(this,"lockSsfi");flag(this,"lockSsfi",!0);var t=i(a).call(this);if(flag(this,"lockSsfi",e),void 0!==t)return t;var s=new chai.Assertion;return transferFlags(this,s),s},configurable:!0})}},{"../../chai":14,"./flag":27,"./isProxyEnabled":37,"./transferFlags":44}],42:[function(require,module,exports){var config=require("../config"),flag=require("./flag"),getProperties=require("./getProperties"),isProxyEnabled=require("./isProxyEnabled"),builtins=["__flags","__methods","_obj","assert"];function stringDistance(e,t,r){if(!r){r=[];for(var n=0;n<=e.length;n++)r[n]=[]}return r[e.length]&&r[e.length][t.length]||(0===e.length||0===t.length?r[e.length][t.length]=Math.max(e.length,t.length):r[e.length][t.length]=Math.min(stringDistance(e.slice(0,-1),t,r)+1,stringDistance(e,t.slice(0,-1),r)+1,stringDistance(e.slice(0,-1),t.slice(0,-1),r)+(e.slice(-1)===t.slice(-1)?0:1))),r[e.length][t.length]}module.exports=function(e,t){return isProxyEnabled()?new Proxy(e,{get:function e(r,n){if("string"==typeof n&&-1===config.proxyExcludedKeys.indexOf(n)&&!Reflect.has(r,n)){if(t)throw Error("Invalid Chai property: "+t+"."+n+'. See docs for proper usage of "'+t+'".');var i=getProperties(r).filter(function(e){return!Object.prototype.hasOwnProperty(e)&&-1===builtins.indexOf(e)}).sort(function(e,t){return stringDistance(n,e)-stringDistance(n,t)});throw i.length&&stringDistance(i[0],n)<4?Error("Invalid Chai property: "+n+'. Did you mean "'+i[0]+'"?'):Error("Invalid Chai property: "+n)}return-1!==builtins.indexOf(n)||flag(r,"lockSsfi")||flag(r,"ssfi",e),Reflect.get(r,n)}}):e}},{"../config":16,"./flag":27,"./getProperties":33,"./isProxyEnabled":37}],43:[function(require,module,exports){
/*!
 * Chai - test utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
/*!
 * Module dependancies
 */
var flag=require("./flag");module.exports=function(e,r){var a=flag(e,"negate"),f=r[0];return a?!f:f}},{"./flag":27}],44:[function(require,module,exports){
/*!
 * Chai - transferFlags utility
 * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */
module.exports=function(e,l,s){var a=e.__flags||(e.__flags=Object.create(null));for(var _ in l.__flags||(l.__flags=Object.create(null)),s=3!==arguments.length||s,a)(s||"object"!==_&&"ssfi"!==_&&"lockSsfi"!==_&&"message"!=_)&&(l.__flags[_]=a[_])}},{}],45:[function(require,module,exports){"use strict";function compatibleInstance(t,e){return e instanceof Error&&t===e}function compatibleConstructor(t,e){return e instanceof Error?t.constructor===e.constructor||t instanceof e.constructor:(e.prototype instanceof Error||e===Error)&&(t.constructor===e||t instanceof e)}function compatibleMessage(t,e){var n="string"==typeof t?t:t.message;return e instanceof RegExp?e.test(n):"string"==typeof e&&-1!==n.indexOf(e)}var functionNameMatch=/\s*function(?:\s|\s*\/\*[^(?:*\/)]+\*\/\s*)*([^\(\/]+)/;function getFunctionName(t){var e="";if(void 0===t.name){var n=String(t).match(functionNameMatch);n&&(e=n[1])}else e=t.name;return e}function getConstructorName(t){var e=t;return t instanceof Error?e=getFunctionName(t.constructor):"function"==typeof t&&(e=getFunctionName(t).trim()||getFunctionName(new t)),e}function getMessage(t){var e="";return t&&t.message?e=t.message:"string"==typeof t&&(e=t),e}module.exports={compatibleInstance:compatibleInstance,compatibleConstructor:compatibleConstructor,compatibleMessage:compatibleMessage,getMessage:getMessage,getConstructorName:getConstructorName}},{}],46:[function(require,module,exports){!function(){"use strict";function t(i,e,n,s){return this instanceof t?(this.domain=i||void 0,this.path=e||"/",this.secure=!!n,this.script=!!s,this):new t(i,e,n,s)}function i(t,e,n){return t instanceof i?t:this instanceof i?(this.name=null,this.value=null,this.expiration_date=1/0,this.path=String(n||"/"),this.explicit_path=!1,this.domain=e||null,this.explicit_domain=!1,this.secure=!1,this.noscript=!1,t&&this.parse(t,e,n),this):new i(t,e,n)}t.All=Object.freeze(Object.create(null)),exports.CookieAccessInfo=t,exports.Cookie=i,i.prototype.toString=function(){var t=[this.name+"="+this.value];return this.expiration_date!==1/0&&t.push("expires="+new Date(this.expiration_date).toGMTString()),this.domain&&t.push("domain="+this.domain),this.path&&t.push("path="+this.path),this.secure&&t.push("secure"),this.noscript&&t.push("httponly"),t.join("; ")},i.prototype.toValueString=function(){return this.name+"="+this.value};var e=/[:](?=\s*[a-zA-Z0-9_\-]+\s*[=])/g;function n(){var t,e;return this instanceof n?(t=Object.create(null),this.setCookie=function(n,s,r){var a,o;if(a=(n=new i(n,s,r)).expiration_date<=Date.now(),void 0!==t[n.name]){for(e=t[n.name],o=0;o<e.length;o+=1)if(e[o].collidesWith(n))return a?(e.splice(o,1),0===e.length&&delete t[n.name],!1):(e[o]=n,n);return!a&&(e.push(n),n)}return!a&&(t[n.name]=[n],t[n.name])},this.getCookie=function(i,n){var s,r;if(e=t[i])for(r=0;r<e.length;r+=1)if((s=e[r]).expiration_date<=Date.now())0===e.length&&delete t[s.name];else if(s.matches(n))return s},this.getCookies=function(i){var e,n,s=[];for(e in t)(n=this.getCookie(e,i))&&s.push(n);return s.toString=function(){return s.join(":")},s.toValueString=function(){return s.map(function(t){return t.toValueString()}).join(";")},s},this):new n}i.prototype.parse=function(t,e,n){if(this instanceof i){var s,r=t.split(";").filter(function(t){return!!t}),a=r[0].match(/([^=]+)=([\s\S]*)/),o=a[1],h=a[2];for(this.name=o,this.value=h,s=1;s<r.length;s+=1)switch(o=(a=r[s].match(/([^=]+)(?:=([\s\S]*))?/))[1].trim().toLowerCase(),h=a[2],o){case"httponly":this.noscript=!0;break;case"expires":this.expiration_date=h?Number(Date.parse(h)):1/0;break;case"path":this.path=h?h.trim():"",this.explicit_path=!0;break;case"domain":this.domain=h?h.trim():"",this.explicit_domain=!!this.domain;break;case"secure":this.secure=!0}return this.explicit_path||(this.path=n||"/"),this.explicit_domain||(this.domain=e),this}return(new i).parse(t,e,n)},i.prototype.matches=function(i){return i===t.All||!(this.noscript&&i.script||this.secure&&!i.secure||!this.collidesWith(i))},i.prototype.collidesWith=function(t){if(this.path&&!t.path||this.domain&&!t.domain)return!1;if(this.path&&0!==t.path.indexOf(this.path))return!1;if(this.explicit_path&&0!==t.path.indexOf(this.path))return!1;var i=t.domain&&t.domain.replace(/^[\.]/,""),e=this.domain&&this.domain.replace(/^[\.]/,"");if(e===i)return!0;if(e){if(!this.explicit_domain)return!1;var n=i.indexOf(e);return-1!==n&&n===i.length-e.length}return!0},exports.CookieJar=n,n.prototype.setCookies=function(t,n,s){var r,a,o=[];for(t=(t=Array.isArray(t)?t:t.split(e)).map(function(t){return new i(t,n,s)}),r=0;r<t.length;r+=1)a=t[r],this.setCookie(a,n,s)&&o.push(a);return o}}()},{}],47:[function(require,module,exports){"use strict";
/*!
 * deep-eql
 * Copyright(c) 2013 Jake Luer <jake@alogicalparadox.com>
 * MIT Licensed
 */var type=require("type-detect");function FakeMap(){this._key="chai/deep-eql__"+Math.random()+Date.now()}FakeMap.prototype={get:function(e){return e[this._key]},set:function(e,r){Object.isExtensible(e)&&Object.defineProperty(e,this._key,{value:r,configurable:!0})}};var MemoizeMap="function"==typeof WeakMap?WeakMap:FakeMap;
/*!
 * Check to see if the MemoizeMap has recorded a result of the two operands
 *
 * @param {Mixed} leftHandOperand
 * @param {Mixed} rightHandOperand
 * @param {MemoizeMap} memoizeMap
 * @returns {Boolean|null} result
*/function memoizeCompare(e,r,t){if(!t||isPrimitive(e)||isPrimitive(r))return null;var n=t.get(e);if(n){var a=n.get(r);if("boolean"==typeof a)return a}return null}
/*!
 * Set the result of the equality into the MemoizeMap
 *
 * @param {Mixed} leftHandOperand
 * @param {Mixed} rightHandOperand
 * @param {MemoizeMap} memoizeMap
 * @param {Boolean} result
*/function memoizeSet(e,r,t,n){if(t&&!isPrimitive(e)&&!isPrimitive(r)){var a=t.get(e);a?a.set(r,n):((a=new MemoizeMap).set(r,n),t.set(e,a))}}
/*!
 * Primary Export
 */function deepEqual(e,r,t){if(t&&t.comparator)return extensiveDeepEqual(e,r,t);var n=simpleEqual(e,r);return null!==n?n:extensiveDeepEqual(e,r,t)}function simpleEqual(e,r){return e===r?0!==e||1/e==1/r:e!=e&&r!=r||!isPrimitive(e)&&!isPrimitive(r)&&null}
/*!
 * The main logic of the `deepEqual` function.
 *
 * @param {Mixed} leftHandOperand
 * @param {Mixed} rightHandOperand
 * @param {Object} [options] (optional) Additional options
 * @param {Array} [options.comparator] (optional) Override default algorithm, determining custom equality.
 * @param {Array} [options.memoize] (optional) Provide a custom memoization object which will cache the results of
    complex objects for a speed boost. By passing `false` you can disable memoization, but this will cause circular
    references to blow the stack.
 * @return {Boolean} equal match
*/function extensiveDeepEqual(e,r,t){(t=t||{}).memoize=!1!==t.memoize&&(t.memoize||new MemoizeMap);var n=t&&t.comparator,a=memoizeCompare(e,r,t.memoize);if(null!==a)return a;var i=memoizeCompare(r,e,t.memoize);if(null!==i)return i;if(n){var u=n(e,r);if(!1===u||!0===u)return memoizeSet(e,r,t.memoize,u),u;var o=simpleEqual(e,r);if(null!==o)return o}var l=type(e);if(l!==type(r))return memoizeSet(e,r,t.memoize,!1),!1;memoizeSet(e,r,t.memoize,!0);var s=extensiveDeepEqualByType(e,r,l,t);return memoizeSet(e,r,t.memoize,s),s}function extensiveDeepEqualByType(e,r,t,n){switch(t){case"String":case"Number":case"Boolean":case"Date":return deepEqual(e.valueOf(),r.valueOf());case"Promise":case"Symbol":case"function":case"WeakMap":case"WeakSet":case"Error":return e===r;case"Arguments":case"Int8Array":case"Uint8Array":case"Uint8ClampedArray":case"Int16Array":case"Uint16Array":case"Int32Array":case"Uint32Array":case"Float32Array":case"Float64Array":case"Array":return iterableEqual(e,r,n);case"RegExp":return regexpEqual(e,r);case"Generator":return generatorEqual(e,r,n);case"DataView":return iterableEqual(new Uint8Array(e.buffer),new Uint8Array(r.buffer),n);case"ArrayBuffer":return iterableEqual(new Uint8Array(e),new Uint8Array(r),n);case"Set":case"Map":return entriesEqual(e,r,n);default:return objectEqual(e,r,n)}}
/*!
 * Compare two Regular Expressions for equality.
 *
 * @param {RegExp} leftHandOperand
 * @param {RegExp} rightHandOperand
 * @return {Boolean} result
 */function regexpEqual(e,r){return e.toString()===r.toString()}
/*!
 * Compare two Sets/Maps for equality. Faster than other equality functions.
 *
 * @param {Set} leftHandOperand
 * @param {Set} rightHandOperand
 * @param {Object} [options] (Optional)
 * @return {Boolean} result
 */function entriesEqual(e,r,t){if(e.size!==r.size)return!1;if(0===e.size)return!0;var n=[],a=[];return e.forEach(function(e,r){n.push([e,r])}),r.forEach(function(e,r){a.push([e,r])}),iterableEqual(n.sort(),a.sort(),t)}
/*!
 * Simple equality for flat iterable objects such as Arrays, TypedArrays or Node.js buffers.
 *
 * @param {Iterable} leftHandOperand
 * @param {Iterable} rightHandOperand
 * @param {Object} [options] (Optional)
 * @return {Boolean} result
 */function iterableEqual(e,r,t){var n=e.length;if(n!==r.length)return!1;if(0===n)return!0;for(var a=-1;++a<n;)if(!1===deepEqual(e[a],r[a],t))return!1;return!0}
/*!
 * Simple equality for generator objects such as those returned by generator functions.
 *
 * @param {Iterable} leftHandOperand
 * @param {Iterable} rightHandOperand
 * @param {Object} [options] (Optional)
 * @return {Boolean} result
 */function generatorEqual(e,r,t){return iterableEqual(getGeneratorEntries(e),getGeneratorEntries(r),t)}
/*!
 * Determine if the given object has an @@iterator function.
 *
 * @param {Object} target
 * @return {Boolean} `true` if the object has an @@iterator function.
 */function hasIteratorFunction(e){return"undefined"!=typeof Symbol&&"object"==typeof e&&void 0!==Symbol.iterator&&"function"==typeof e[Symbol.iterator]}
/*!
 * Gets all iterator entries from the given Object. If the Object has no @@iterator function, returns an empty array.
 * This will consume the iterator - which could have side effects depending on the @@iterator implementation.
 *
 * @param {Object} target
 * @returns {Array} an array of entries from the @@iterator function
 */function getIteratorEntries(e){if(hasIteratorFunction(e))try{return getGeneratorEntries(e[Symbol.iterator]())}catch(e){return[]}return[]}
/*!
 * Gets all entries from a Generator. This will consume the generator - which could have side effects.
 *
 * @param {Generator} target
 * @returns {Array} an array of entries from the Generator.
 */function getGeneratorEntries(e){for(var r=e.next(),t=[r.value];!1===r.done;)r=e.next(),t.push(r.value);return t}
/*!
 * Gets all own and inherited enumerable keys from a target.
 *
 * @param {Object} target
 * @returns {Array} an array of own and inherited enumerable keys from the target.
 */function getEnumerableKeys(e){var r=[];for(var t in e)r.push(t);return r}
/*!
 * Determines if two objects have matching values, given a set of keys. Defers to deepEqual for the equality check of
 * each key. If any value of the given key is not equal, the function will return false (early).
 *
 * @param {Mixed} leftHandOperand
 * @param {Mixed} rightHandOperand
 * @param {Array} keys An array of keys to compare the values of leftHandOperand and rightHandOperand against
 * @param {Object} [options] (Optional)
 * @return {Boolean} result
 */function keysEqual(e,r,t,n){var a=t.length;if(0===a)return!0;for(var i=0;i<a;i+=1)if(!1===deepEqual(e[t[i]],r[t[i]],n))return!1;return!0}
/*!
 * Recursively check the equality of two Objects. Once basic sameness has been established it will defer to `deepEqual`
 * for each enumerable key in the object.
 *
 * @param {Mixed} leftHandOperand
 * @param {Mixed} rightHandOperand
 * @param {Object} [options] (Optional)
 * @return {Boolean} result
 */function objectEqual(e,r,t){var n=getEnumerableKeys(e),a=getEnumerableKeys(r);if(n.length&&n.length===a.length)return n.sort(),a.sort(),!1!==iterableEqual(n,a)&&keysEqual(e,r,n,t);var i=getIteratorEntries(e),u=getIteratorEntries(r);return i.length&&i.length===u.length?(i.sort(),u.sort(),iterableEqual(i,u,t)):0===n.length&&0===i.length&&0===a.length&&0===u.length}
/*!
 * Returns true if the argument is a primitive.
 *
 * This intentionally returns true for all objects that can be compared by reference,
 * including functions and symbols.
 *
 * @param {Mixed} value
 * @return {Boolean} result
 */function isPrimitive(e){return null===e||"object"!=typeof e}module.exports=deepEqual,module.exports.MemoizeMap=MemoizeMap},{"type-detect":53}],48:[function(require,module,exports){"use strict";var toString=Function.prototype.toString,functionNameMatch=/\s*function(?:\s|\s*\/\*[^(?:*\/)]+\*\/\s*)*([^\s\(\/]+)/;function getFuncName(t){if("function"!=typeof t)return null;var n="";if(void 0===Function.prototype.name&&void 0===t.name){var e=toString.call(t).match(functionNameMatch);e&&(n=e[1])}else n=t.name;return n}module.exports=getFuncName},{}],49:[function(require,module,exports){"use strict";function hasProperty(e,t){return void 0!==e&&null!==e&&t in Object(e)}function parsePath(e){return e.replace(/([^\\])\[/g,"$1.[").match(/(\\\.|[^.]+?)+/g).map(function(e){var t=/^\[(\d+)\]$/.exec(e);return t?{i:parseFloat(t[1])}:{p:e.replace(/\\([.\[\]])/g,"$1")}})}function internalGetPathValue(e,t,a){var n=e,r=null;a=void 0===a?t.length:a;for(var l=0;l<a;l++){var i=t[l];n&&(n=void 0===i.p?n[i.i]:n[i.p],l===a-1&&(r=n))}return r}function internalSetPathValue(e,t,a){for(var n=e,r=a.length,l=null,i=0;i<r;i++){var u=null,o=null;if(l=a[i],i===r-1)n[u=void 0===l.p?l.i:l.p]=t;else if(void 0!==l.p&&n[l.p])n=n[l.p];else if(void 0!==l.i&&n[l.i])n=n[l.i];else{var h=a[i+1];u=void 0===l.p?l.i:l.p,o=void 0===h.p?[]:{},n[u]=o,n=n[u]}}}function getPathInfo(e,t){var a=parsePath(t),n=a[a.length-1],r={parent:a.length>1?internalGetPathValue(e,a,a.length-1):e,name:n.p||n.i,value:internalGetPathValue(e,a)};return r.exists=hasProperty(r.parent,r.name),r}function getPathValue(e,t){return getPathInfo(e,t).value}function setPathValue(e,t,a){return internalSetPathValue(e,a,parsePath(t)),e}module.exports={hasProperty:hasProperty,getPathInfo:getPathInfo,getPathValue:getPathValue,setPathValue:setPathValue}},{}],50:[function(require,module,exports){"use strict";function hasOwnProperty(r,e){return Object.prototype.hasOwnProperty.call(r,e)}module.exports=function(r,e,t,n){e=e||"&",t=t||"=";var o={};if("string"!=typeof r||0===r.length)return o;var a=/\+/g;r=r.split(e);var s=1e3;n&&"number"==typeof n.maxKeys&&(s=n.maxKeys);var p=r.length;s>0&&p>s&&(p=s);for(var y=0;y<p;++y){var u,c,i,l,f=r[y].replace(a,"%20"),v=f.indexOf(t);v>=0?(u=f.substr(0,v),c=f.substr(v+1)):(u=f,c=""),i=decodeURIComponent(u),l=decodeURIComponent(c),hasOwnProperty(o,i)?isArray(o[i])?o[i].push(l):o[i]=[o[i],l]:o[i]=l}return o};var isArray=Array.isArray||function(r){return"[object Array]"===Object.prototype.toString.call(r)}},{}],51:[function(require,module,exports){"use strict";var stringifyPrimitive=function(r){switch(typeof r){case"string":return r;case"boolean":return r?"true":"false";case"number":return isFinite(r)?r:"";default:return""}};module.exports=function(r,e,t,n){return e=e||"&",t=t||"=",null===r&&(r=void 0),"object"==typeof r?map(objectKeys(r),function(n){var i=encodeURIComponent(stringifyPrimitive(n))+t;return isArray(r[n])?map(r[n],function(r){return i+encodeURIComponent(stringifyPrimitive(r))}).join(e):i+encodeURIComponent(stringifyPrimitive(r[n]))}).join(e):n?encodeURIComponent(stringifyPrimitive(n))+t+encodeURIComponent(stringifyPrimitive(r)):""};var isArray=Array.isArray||function(r){return"[object Array]"===Object.prototype.toString.call(r)};function map(r,e){if(r.map)return r.map(e);for(var t=[],n=0;n<r.length;n++)t.push(e(r[n],n));return t}var objectKeys=Object.keys||function(r){var e=[];for(var t in r)Object.prototype.hasOwnProperty.call(r,t)&&e.push(t);return e}},{}],52:[function(require,module,exports){"use strict";exports.decode=exports.parse=require("./decode"),exports.encode=exports.stringify=require("./encode")},{"./decode":50,"./encode":51}],53:[function(require,module,exports){(function(global){!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):e.typeDetect=t()}(this,function(){"use strict";var e="function"==typeof Promise,t="object"==typeof self?self:global,o="undefined"!=typeof Symbol,n="undefined"!=typeof Map,r="undefined"!=typeof Set,i="undefined"!=typeof WeakMap,a="undefined"!=typeof WeakSet,p="undefined"!=typeof DataView,f=o&&void 0!==Symbol.iterator,y=o&&void 0!==Symbol.toStringTag,l=r&&"function"==typeof Set.prototype.entries,u=n&&"function"==typeof Map.prototype.entries,d=l&&Object.getPrototypeOf((new Set).entries()),c=u&&Object.getPrototypeOf((new Map).entries()),w=f&&"function"==typeof Array.prototype[Symbol.iterator],m=w&&Object.getPrototypeOf([][Symbol.iterator]()),b=f&&"function"==typeof String.prototype[Symbol.iterator],g=b&&Object.getPrototypeOf(""[Symbol.iterator]()),S=8,s=-1;return function(o){var f=typeof o;if("object"!==f)return f;if(null===o)return"null";if(o===t)return"global";if(Array.isArray(o)&&(!1===y||!(Symbol.toStringTag in o)))return"Array";if("object"==typeof window&&null!==window){if("object"==typeof window.location&&o===window.location)return"Location";if("object"==typeof window.document&&o===window.document)return"Document";if("object"==typeof window.navigator){if("object"==typeof window.navigator.mimeTypes&&o===window.navigator.mimeTypes)return"MimeTypeArray";if("object"==typeof window.navigator.plugins&&o===window.navigator.plugins)return"PluginArray"}if(("function"==typeof window.HTMLElement||"object"==typeof window.HTMLElement)&&o instanceof window.HTMLElement){if("BLOCKQUOTE"===o.tagName)return"HTMLQuoteElement";if("TD"===o.tagName)return"HTMLTableDataCellElement";if("TH"===o.tagName)return"HTMLTableHeaderCellElement"}}var l=y&&o[Symbol.toStringTag];if("string"==typeof l)return l;var u=Object.getPrototypeOf(o);return u===RegExp.prototype?"RegExp":u===Date.prototype?"Date":e&&u===Promise.prototype?"Promise":r&&u===Set.prototype?"Set":n&&u===Map.prototype?"Map":a&&u===WeakSet.prototype?"WeakSet":i&&u===WeakMap.prototype?"WeakMap":p&&u===DataView.prototype?"DataView":n&&u===c?"Map Iterator":r&&u===d?"Set Iterator":w&&u===m?"Array Iterator":b&&u===g?"String Iterator":null===u?"Object":Object.prototype.toString.call(o).slice(S,s)}})}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],54:[function(require,module,exports){"use strict";var punycode=require("punycode"),util=require("./util");function Url(){this.protocol=null,this.slashes=null,this.auth=null,this.host=null,this.port=null,this.hostname=null,this.hash=null,this.search=null,this.query=null,this.pathname=null,this.path=null,this.href=null}exports.parse=urlParse,exports.resolve=urlResolve,exports.resolveObject=urlResolveObject,exports.format=urlFormat,exports.Url=Url;var protocolPattern=/^([a-z0-9.+-]+:)/i,portPattern=/:[0-9]*$/,simplePathPattern=/^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,delims=["<",">",'"',"`"," ","\r","\n","\t"],unwise=["{","}","|","\\","^","`"].concat(delims),autoEscape=["'"].concat(unwise),nonHostChars=["%","/","?",";","#"].concat(autoEscape),hostEndingChars=["/","?","#"],hostnameMaxLen=255,hostnamePartPattern=/^[+a-z0-9A-Z_-]{0,63}$/,hostnamePartStart=/^([+a-z0-9A-Z_-]{0,63})(.*)$/,unsafeProtocol={javascript:!0,"javascript:":!0},hostlessProtocol={javascript:!0,"javascript:":!0},slashedProtocol={http:!0,https:!0,ftp:!0,gopher:!0,file:!0,"http:":!0,"https:":!0,"ftp:":!0,"gopher:":!0,"file:":!0},querystring=require("querystring");function urlParse(t,s,e){if(t&&util.isObject(t)&&t instanceof Url)return t;var h=new Url;return h.parse(t,s,e),h}function urlFormat(t){return util.isString(t)&&(t=urlParse(t)),t instanceof Url?t.format():Url.prototype.format.call(t)}function urlResolve(t,s){return urlParse(t,!1,!0).resolve(s)}function urlResolveObject(t,s){return t?urlParse(t,!1,!0).resolveObject(s):s}Url.prototype.parse=function(t,s,e){if(!util.isString(t))throw new TypeError("Parameter 'url' must be a string, not "+typeof t);var h=t.indexOf("?"),r=-1!==h&&h<t.indexOf("#")?"?":"#",a=t.split(r);a[0]=a[0].replace(/\\/g,"/");var o=t=a.join(r);if(o=o.trim(),!e&&1===t.split("#").length){var n=simplePathPattern.exec(o);if(n)return this.path=o,this.href=o,this.pathname=n[1],n[2]?(this.search=n[2],this.query=s?querystring.parse(this.search.substr(1)):this.search.substr(1)):s&&(this.search="",this.query={}),this}var i=protocolPattern.exec(o);if(i){var l=(i=i[0]).toLowerCase();this.protocol=l,o=o.substr(i.length)}if(e||i||o.match(/^\/\/[^@\/]+@[^@\/]+/)){var u="//"===o.substr(0,2);!u||i&&hostlessProtocol[i]||(o=o.substr(2),this.slashes=!0)}if(!hostlessProtocol[i]&&(u||i&&!slashedProtocol[i])){for(var p,c,f=-1,m=0;m<hostEndingChars.length;m++){-1!==(v=o.indexOf(hostEndingChars[m]))&&(-1===f||v<f)&&(f=v)}-1!==(c=-1===f?o.lastIndexOf("@"):o.lastIndexOf("@",f))&&(p=o.slice(0,c),o=o.slice(c+1),this.auth=decodeURIComponent(p)),f=-1;for(m=0;m<nonHostChars.length;m++){var v;-1!==(v=o.indexOf(nonHostChars[m]))&&(-1===f||v<f)&&(f=v)}-1===f&&(f=o.length),this.host=o.slice(0,f),o=o.slice(f),this.parseHost(),this.hostname=this.hostname||"";var g="["===this.hostname[0]&&"]"===this.hostname[this.hostname.length-1];if(!g)for(var y=this.hostname.split(/\./),P=(m=0,y.length);m<P;m++){var d=y[m];if(d&&!d.match(hostnamePartPattern)){for(var b="",q=0,O=d.length;q<O;q++)d.charCodeAt(q)>127?b+="x":b+=d[q];if(!b.match(hostnamePartPattern)){var j=y.slice(0,m),x=y.slice(m+1),U=d.match(hostnamePartStart);U&&(j.push(U[1]),x.unshift(U[2])),x.length&&(o="/"+x.join(".")+o),this.hostname=j.join(".");break}}}this.hostname.length>hostnameMaxLen?this.hostname="":this.hostname=this.hostname.toLowerCase(),g||(this.hostname=punycode.toASCII(this.hostname));var C=this.port?":"+this.port:"",A=this.hostname||"";this.host=A+C,this.href+=this.host,g&&(this.hostname=this.hostname.substr(1,this.hostname.length-2),"/"!==o[0]&&(o="/"+o))}if(!unsafeProtocol[l])for(m=0,P=autoEscape.length;m<P;m++){var w=autoEscape[m];if(-1!==o.indexOf(w)){var E=encodeURIComponent(w);E===w&&(E=escape(w)),o=o.split(w).join(E)}}var I=o.indexOf("#");-1!==I&&(this.hash=o.substr(I),o=o.slice(0,I));var R=o.indexOf("?");if(-1!==R?(this.search=o.substr(R),this.query=o.substr(R+1),s&&(this.query=querystring.parse(this.query)),o=o.slice(0,R)):s&&(this.search="",this.query={}),o&&(this.pathname=o),slashedProtocol[l]&&this.hostname&&!this.pathname&&(this.pathname="/"),this.pathname||this.search){C=this.pathname||"";var S=this.search||"";this.path=C+S}return this.href=this.format(),this},Url.prototype.format=function(){var t=this.auth||"";t&&(t=(t=encodeURIComponent(t)).replace(/%3A/i,":"),t+="@");var s=this.protocol||"",e=this.pathname||"",h=this.hash||"",r=!1,a="";this.host?r=t+this.host:this.hostname&&(r=t+(-1===this.hostname.indexOf(":")?this.hostname:"["+this.hostname+"]"),this.port&&(r+=":"+this.port)),this.query&&util.isObject(this.query)&&Object.keys(this.query).length&&(a=querystring.stringify(this.query));var o=this.search||a&&"?"+a||"";return s&&":"!==s.substr(-1)&&(s+=":"),this.slashes||(!s||slashedProtocol[s])&&!1!==r?(r="//"+(r||""),e&&"/"!==e.charAt(0)&&(e="/"+e)):r||(r=""),h&&"#"!==h.charAt(0)&&(h="#"+h),o&&"?"!==o.charAt(0)&&(o="?"+o),s+r+(e=e.replace(/[?#]/g,function(t){return encodeURIComponent(t)}))+(o=o.replace("#","%23"))+h},Url.prototype.resolve=function(t){return this.resolveObject(urlParse(t,!1,!0)).format()},Url.prototype.resolveObject=function(t){if(util.isString(t)){var s=new Url;s.parse(t,!1,!0),t=s}for(var e=new Url,h=Object.keys(this),r=0;r<h.length;r++){var a=h[r];e[a]=this[a]}if(e.hash=t.hash,""===t.href)return e.href=e.format(),e;if(t.slashes&&!t.protocol){for(var o=Object.keys(t),n=0;n<o.length;n++){var i=o[n];"protocol"!==i&&(e[i]=t[i])}return slashedProtocol[e.protocol]&&e.hostname&&!e.pathname&&(e.path=e.pathname="/"),e.href=e.format(),e}if(t.protocol&&t.protocol!==e.protocol){if(!slashedProtocol[t.protocol]){for(var l=Object.keys(t),u=0;u<l.length;u++){var p=l[u];e[p]=t[p]}return e.href=e.format(),e}if(e.protocol=t.protocol,t.host||hostlessProtocol[t.protocol])e.pathname=t.pathname;else{for(var c=(t.pathname||"").split("/");c.length&&!(t.host=c.shift()););t.host||(t.host=""),t.hostname||(t.hostname=""),""!==c[0]&&c.unshift(""),c.length<2&&c.unshift(""),e.pathname=c.join("/")}if(e.search=t.search,e.query=t.query,e.host=t.host||"",e.auth=t.auth,e.hostname=t.hostname||t.host,e.port=t.port,e.pathname||e.search){var f=e.pathname||"",m=e.search||"";e.path=f+m}return e.slashes=e.slashes||t.slashes,e.href=e.format(),e}var v=e.pathname&&"/"===e.pathname.charAt(0),g=t.host||t.pathname&&"/"===t.pathname.charAt(0),y=g||v||e.host&&t.pathname,P=y,d=e.pathname&&e.pathname.split("/")||[],b=(c=t.pathname&&t.pathname.split("/")||[],e.protocol&&!slashedProtocol[e.protocol]);if(b&&(e.hostname="",e.port=null,e.host&&(""===d[0]?d[0]=e.host:d.unshift(e.host)),e.host="",t.protocol&&(t.hostname=null,t.port=null,t.host&&(""===c[0]?c[0]=t.host:c.unshift(t.host)),t.host=null),y=y&&(""===c[0]||""===d[0])),g)e.host=t.host||""===t.host?t.host:e.host,e.hostname=t.hostname||""===t.hostname?t.hostname:e.hostname,e.search=t.search,e.query=t.query,d=c;else if(c.length)d||(d=[]),d.pop(),d=d.concat(c),e.search=t.search,e.query=t.query;else if(!util.isNullOrUndefined(t.search)){if(b)e.hostname=e.host=d.shift(),(U=!!(e.host&&e.host.indexOf("@")>0)&&e.host.split("@"))&&(e.auth=U.shift(),e.host=e.hostname=U.shift());return e.search=t.search,e.query=t.query,util.isNull(e.pathname)&&util.isNull(e.search)||(e.path=(e.pathname?e.pathname:"")+(e.search?e.search:"")),e.href=e.format(),e}if(!d.length)return e.pathname=null,e.search?e.path="/"+e.search:e.path=null,e.href=e.format(),e;for(var q=d.slice(-1)[0],O=(e.host||t.host||d.length>1)&&("."===q||".."===q)||""===q,j=0,x=d.length;x>=0;x--)"."===(q=d[x])?d.splice(x,1):".."===q?(d.splice(x,1),j++):j&&(d.splice(x,1),j--);if(!y&&!P)for(;j--;j)d.unshift("..");!y||""===d[0]||d[0]&&"/"===d[0].charAt(0)||d.unshift(""),O&&"/"!==d.join("/").substr(-1)&&d.push("");var U,C=""===d[0]||d[0]&&"/"===d[0].charAt(0);b&&(e.hostname=e.host=C?"":d.length?d.shift():"",(U=!!(e.host&&e.host.indexOf("@")>0)&&e.host.split("@"))&&(e.auth=U.shift(),e.host=e.hostname=U.shift()));return(y=y||e.host&&d.length)&&!C&&d.unshift(""),d.length?e.pathname=d.join("/"):(e.pathname=null,e.path=null),util.isNull(e.pathname)&&util.isNull(e.search)||(e.path=(e.pathname?e.pathname:"")+(e.search?e.search:"")),e.auth=t.auth||e.auth,e.slashes=e.slashes||t.slashes,e.href=e.format(),e},Url.prototype.parseHost=function(){var t=this.host,s=portPattern.exec(t);s&&(":"!==(s=s[0])&&(this.port=s.substr(1)),t=t.substr(0,t.length-s.length)),t&&(this.hostname=t)}},{"./util":55,punycode:12,querystring:52}],55:[function(require,module,exports){"use strict";module.exports={isString:function(n){return"string"==typeof n},isObject:function(n){return"object"==typeof n&&null!==n},isNull:function(n){return null===n},isNullOrUndefined:function(n){return null==n}}},{}]},{},[5])(5)});
//# sourceMappingURL=postman-bdd.min.js.map
//# sourceMappingURL=postman-bdd.min.js.map