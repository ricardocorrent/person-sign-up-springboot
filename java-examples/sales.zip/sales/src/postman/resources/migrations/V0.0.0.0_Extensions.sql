create extension if not exists "uuid-ossp" schema cloudextensions;
create extension if not exists dblink schema cloudextensions;