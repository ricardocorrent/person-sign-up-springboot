const jsonServer = require('json-server');

const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

server.use(middlewares);

server.use(jsonServer.rewriter({
    '/api/v1/*': '/$1',
    '/api/v2/*': '/$1',
    '/api/v3/*': '/$1',
    '/api/v4/*': '/$1',
    '/api/v5/*': '/$1',
    '/api/v6/*': '/$1',
    '/api/v7/*': '/$1',
    '/api/v8/*': '/$1',
    '/api/v9/*': '/$1',
    '/api/v10/*': '/$1',
    '/:service/:resource': '/:resource',
    '/:service/:resource/:id': '/:resource/:id',
    '/:service/:resource/*/': '/:resource/$1/'
}));

server.use(jsonServer.bodyParser);

router.render = (req, res) => {
    let version = req.originalUrl.split('/')[2];
    let serviceName = req.originalUrl.split('/')[3];
    let resourceName = req.originalUrl.split('/')[4];
    let resourceId = req.originalUrl.split('/')[5];
    console.log('---------------------------------');
    console.log('URL ACESSADA:' + req.originalUrl);
    console.log('VERSÃO DO SERVIÇO: ' + version);
    console.log('SERVIÇO UTILIZADO: ' + serviceName);
    console.log('RECURSO UTILIZADO: ' + resourceName);
    console.log('RECURSO BUSCADO: ' + resourceId);
    
    if (resourceId === 'price-lists-by-product' || (req.method === 'GET' && resourceId === undefined)) {
	    const itens = res.locals.data.length ? res.locals.data : [];
	    res.status(200).send({
	        items: itens,
	        count: itens.length,
	        page: 0,
	        pageSize: 500
	    });
    } else if (req.method === 'POST' && resourceId === 'contains-siagri-permission') {
        res.status(200).send(true);
    } else {
        /* qualquer outra rota tem resposta padrao */
        res.send(res.locals.data);
    }
};

server.use((req, res, next) => {
	 let resourceId = req.originalUrl.split('/')[5];
	 if (req.method === 'POST' && resourceId === 'price-lists-by-product') {
		 req.method = 'GET';
		 req.url = `/price-list-items`;
		 console.log('changing URL to ***************  '+req.url)
	 }
	 next();
});

server.use(router);
server.listen(3000, () => {
  console.log('Server is running on port 3000')
});
