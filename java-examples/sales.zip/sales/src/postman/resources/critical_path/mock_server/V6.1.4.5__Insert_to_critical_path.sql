insert into order_operation(id, version, code, description, deleted, created_at, updated_at)
values('12153d6f-1b95-449c-b6c4-a12d97567f91', null, '123', 'Order operation - caminho critico', FALSE, '2018-07-13 13:43:38.538-03', '2018-07-13 13:43:38.538-03');

insert into order_warehouse(id, version, description, deleted, created_at, updated_at)
values('01b4106b-9738-4983-83b8-b9a364efdaa1', null, 'Warehouse - caminho critico',FALSE,'2018-06-11 18:00:03.026-03','2018-06-11 18:00:03.026-03');

insert into order_representative(id, version, description, deleted, created_at, updated_at)
values('1c2a100e-470c-4f58-82a3-3cb419c9f799', null, 'Order representative - caminho critico', FALSE, '2018-07-13 15:41:20.179-03', '2018-07-13 15:41:20.179-03');

insert into order_technical_consultant(id, version, description, deleted, created_at, updated_at)
values('01f978e3-a3e9-4811-a971-565dc4e6ab27', null,'Technical consultant - caminho critico',FALSE,'2018-07-13 13:45:36.436-03','2018-07-13 13:45:36.436-03');

insert into order_technical_coordinator(id, version, description, deleted, created_at, updated_at)
values('10d7cc54-d56f-45f3-9de5-8d33774b3909', null, 'Technical coordinator - caminho critico', FALSE, '2018-07-24 10:51:19.265-03', '2018-07-24 10:51:19.265-03');

insert into order_treatment(id, version, description, deleted, created_at, updated_at)
values('05aadddb-76b7-4287-bfc1-26b04bfd855d', null, 'Order treatment - caminho critico', FALSE, '2018-06-11 10:58:37.944-03', '2018-06-11 10:58:37.944-03');

insert into payment_term(id, active, standard, available_first_order, description, acronym, code, created_at, updated_at, deleted, middle_term, allow_change_due_date, max_number_instalment, days_between_instalment, instalment_number)
values('2c6eda24-ee88-4209-a9e2-1c9653a36c77', true, true, true, 'Payment-Term 1', 'PT1', 'PT1', now(), now(), false, 30, true, 5, 30, 1);

insert into situation(id, active, description, image_id, acronym, rank, icon, created_at, updated_at, deleted)
values('cf295649-ab56-4512-afec-d066bd273684', true, 'Pending', null, 'PP', null, null, now(), now(), false);
