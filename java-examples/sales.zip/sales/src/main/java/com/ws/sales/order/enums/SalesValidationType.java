package com.ws.sales.order.enums;

import com.ws.commons.server.validation.entityvalidator.IValidationFilter;

/**
 * @author Marcos Matheus de Andrade
 * @since 2017-12-20
 */
public enum SalesValidationType implements IValidationFilter {
    INSERT_HEADER,
    UPDATE_HEADER,
    INTEGRATION,
    FINALIZATION,
    COMPLEMENT,
    DELETE
}
