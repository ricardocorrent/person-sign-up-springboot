package com.ws.sales.orderinstalment;

import com.ws.commons.server.validation.exception.MessageException;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import org.apache.http.HttpStatus;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author Maykon Rissi maykon.rissi@wssim.com.br
 * @since v5.22.0 2018-05-02
 */
@Default
public class SalesOrderInstalmentLogic {

    private final SalesOrderDAO salesOrderDAO;
    private final SalesOrderInstalmentDAO salesOrderInstalmentDAO;

    @Inject
    public SalesOrderInstalmentLogic(final SalesOrderDAO salesOrderDAO,
                                     final SalesOrderInstalmentDAO salesOrderInstalmentDAO) {
        this.salesOrderDAO = salesOrderDAO;
        this.salesOrderInstalmentDAO = salesOrderInstalmentDAO;
    }

    /**
     * Return all instalments that belongs to the informed order
     * It can receive a projection for select
     *
     * @param orderId Id from the order it will generate the instalments
     * @param select  Fields for the projection
     * @return List<SalesOrderInstalment> instalments
     * @author Maykon Rissi
     */
    public List<SalesOrderInstalment> getInstalmentsFromOrder(final UUID orderId,
                                                              final String select) {

        final SalesOrderInstalmentSearch search = new SalesOrderInstalmentSearch();
        search.setOrderId(orderId);
        if (select != null) {
            search.setSelect(select);
        }

        return this.salesOrderInstalmentDAO.search(search).getItems();
    }

    /**
     * Central control for all the errors that can't be used in validator
     *
     * @param message Message for the exception
     * @author Maykon Rissi
     */
    private void throwMessageException(final String message) {
        throw new MessageException(message,
                HttpStatus.SC_UNPROCESSABLE_ENTITY);

    }

    /**
     * Returns the informed order;
     *
     * @param orderId Id from the order it will generate the instalments
     * @return SalesOrder
     * @author Maykon Rissi
     */
    public SalesOrder getSalesOrder(final UUID orderId) {
        return salesOrderDAO.findById(orderId);
    }

    /**
     * Starts the logic to create all the instalments.
     * After take the order and the values for each instalment, it will create the objects
     *
     * @param salesOrderInstalmentGenerate Object who contains the information about number of instalments and days between each one
     * @param salesOrderId                 Id from the order it will generate the instalments
     * @return LinkedList<SalesOrderInstalment> instalments
     * @author Maykon Rissi maykon.rissi@wssim.com.br
     */
    public List<SalesOrderInstalment> calculateInstalments(final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate,
                                                           final UUID salesOrderId) {

        final SalesOrder salesOrder = this.getSalesOrder(salesOrderId);

        if (salesOrder.getNetValue() == null || salesOrder.getNetValue().compareTo(BigDecimal.ZERO) <= 0) {
            return new LinkedList<>();
        }

        final BigDecimal instalmentValue = this.calculateInstalmentValue(salesOrder.getNetValue(), salesOrderInstalmentGenerate.getQuantity());

        return createInstalmentsForNewRegisters(salesOrderInstalmentGenerate, salesOrder, instalmentValue);
    }

    /**
     * Does a for, using the index to name de instalment.
     * In the last repeat, it will calculate the remaining value. This way, the value will be solid
     *
     * @param salesOrderInstalmentGenerate Object who contains the information about number of instalments and days between each one
     * @param salesOrder                   Object order previous loaded
     * @param value                        alue of each instalment
     * @return LinkedList<SalesOrderInstalment> instalments
     * @author Maykon Rissi
     */
    private List<SalesOrderInstalment> createInstalmentsForNewRegisters(final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate,
                                                                        final SalesOrder salesOrder,
                                                                        final BigDecimal value) {

        final List<SalesOrderInstalment> instalments = new LinkedList<>();
        BigDecimal instalmentValue = value;

        for (int idxInstalments = 1; idxInstalments <= salesOrderInstalmentGenerate.getQuantity(); idxInstalments++) {

            if (idxInstalments == salesOrderInstalmentGenerate.getQuantity()) {
                instalmentValue = this.calculateLastInstalment(salesOrder.getNetValue(), instalments);
            }

            instalments.add(this.createInstalment(salesOrder,
                    idxInstalments,
                    instalmentValue,
                    salesOrderInstalmentGenerate.getDaysBetween()));
        }

        return instalments;
    }

    /**
     * Calculate the value of the instalments. It will take the net value from order, divide by the number of instalments and then round
     *
     * @param salesOrderNetValue total value from the order
     * @param quantity           number of instalments
     * @return BigDecimal - Value for each instalment
     * @author Maykon Rissi
     */
    private BigDecimal calculateInstalmentValue(final BigDecimal salesOrderNetValue,
                                                final Integer quantity) {
        return salesOrderNetValue
                .divide(BigDecimal.valueOf(quantity), Constants.SCALE_INSTALMENTS, RoundingMode.HALF_EVEN);
    }

    /**
     * Calculates the value for the last instalment, using the netValue from order and the sum of all instalments
     *
     * @param salesOrderNetValue total value from the order
     * @param instalments        list of instalments loaded from database
     * @return BigDecimal - the value for the last instalment
     * @author Maykon Rissi
     */
    private BigDecimal calculateLastInstalment(final BigDecimal salesOrderNetValue,
                                               final List<SalesOrderInstalment> instalments) {
        return salesOrderNetValue
                .subtract(instalments
                        .stream()
                        .map(SalesOrderInstalment::getValue)
                        .reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
    }

    /**
     * Creates a new instalment
     *
     * @param salesOrder      Object order previous loaded
     * @param idxInstalments  index of the instalment. It will be used for fill the number of the instalment
     * @param instalmentValue Value of the instalment
     * @param daysBetween     Days between each instalment
     * @return SalesOrderInstalment
     * @author Maykon Rissi
     */
    private SalesOrderInstalment createInstalment(final SalesOrder salesOrder,
                                                  final Integer idxInstalments,
                                                  final BigDecimal instalmentValue,
                                                  final Integer daysBetween) {

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final LocalDate salesOrderCreatedAt = salesOrder.getCreatedAt().toLocalDate();

        instalment.setSalesOrder(salesOrder);
        instalment.setDueDate(salesOrderCreatedAt.plusDays(daysBetween.longValue() * idxInstalments));
        instalment.setNumber(idxInstalments);
        instalment.setValue(instalmentValue);

        return instalment;
    }

    /**
     * Core for handle the update for a single entity. If the entity has the value updated, it will
     * do all the math again.
     * If it only has the dueDate updated, it will only update the entity
     *
     * @param instalmentForUpdate Entity instalment for update
     * @param orderId             if from the order that the instalment belongs
     * @author Maykon Rissi
     */
    public List<SalesOrderInstalment> editInstalment(final SalesOrderInstalment instalmentForUpdate,
                                                     final UUID orderId) {

        final SalesOrder salesOrder = this.getSalesOrder(orderId);

        if (salesOrder.getNetValue() == null || salesOrder.getNetValue().compareTo(BigDecimal.ZERO) <= 0) {
            return new LinkedList<>();
        }

        final List<SalesOrderInstalment> instalmentsInDb = this.getInstalmentsFromOrder(orderId, null);
        List<SalesOrderInstalment> instalments;
        final SalesOrderInstalment instalmentInDb = instalmentsInDb.stream()
                .filter(entity -> entity.getId().equals(instalmentForUpdate.getId()))
                .findFirst().orElseThrow(NotFoundException::new);

        if (instalmentInDb.getValue().compareTo(instalmentForUpdate.getValue()) != 0) {
            instalments = this.handleValueUpdate(instalmentsInDb, instalmentForUpdate, salesOrder);
            this.doValidateValueIsDifferentThanOrder(instalments, salesOrder);
        } else {
            instalments = instalmentsInDb.stream()
                    .peek(entity -> {
                        if (entity.getId().equals(instalmentForUpdate.getId())) {
                            entity.setDueDate(instalmentForUpdate.getDueDate());
                        }
                    })
                    .collect(Collectors.toList());
            this.doValidateValueIsDifferentThanOrder(instalments, salesOrder);
        }
        return instalments;
    }


    /**
     * Handles the update when the value is changed.
     *
     * @param instalmentsInDb     list of all instalments in db, who belong to the order
     * @param instalmentForUpdate Entity who will be updated
     * @author Maykon Rissi
     */
    private List<SalesOrderInstalment> handleValueUpdate(final List<SalesOrderInstalment> instalmentsInDb,
                                                         final SalesOrderInstalment instalmentForUpdate,
                                                         final SalesOrder salesOrder) {

        final List<SalesOrderInstalment> instalmentsForReturn = new LinkedList<>();
        final SalesOrderInstalment originalInstalmentInDb = this.salesOrderInstalmentDAO.findById(instalmentForUpdate.getId());
        final List<SalesOrderInstalment> instalmentsWithoutUpdated = instalmentsInDb
                .stream()
                .filter(entity -> !entity.getId().equals(instalmentForUpdate.getId()))
                .collect(Collectors.toList());

        if (originalInstalmentInDb.getNumber() != instalmentsInDb.size()) {
            return handleUpdateWhenIsNotLastInstalment(salesOrder,
                    originalInstalmentInDb,
                    instalmentForUpdate,
                    instalmentsWithoutUpdated,
                    instalmentsInDb,
                    instalmentsForReturn);
        } else {
            return handleUpdateWhenIsLastInstalment(salesOrder,
                    originalInstalmentInDb,
                    instalmentForUpdate,
                    instalmentsWithoutUpdated,
                    instalmentsForReturn);
        }
    }

    /**
     * Calculates the value of each instalment when it is editing the last one.
     * It will take the net value from order, subtract by the value from the instalment you are editing and then
     * divide by the number of all others instalments.
     *
     * @param originalInstalmentInDb Entity instalment persisted, reflecting the object who will be updated
     * @param salesOrder             Entity order who the instalment belongs
     * @param instalmentForUpdate    Entity instalment who will be persisted
     * @author Maykon Rissi
     */
    private List<SalesOrderInstalment> handleUpdateWhenIsLastInstalment(final SalesOrder salesOrder,
                                                                        final SalesOrderInstalment originalInstalmentInDb,
                                                                        final SalesOrderInstalment instalmentForUpdate,
                                                                        final List<SalesOrderInstalment> instalmentsWithoutUpdated,
                                                                        final List<SalesOrderInstalment> instalmentsForReturn) {

        final BigDecimal valueForRemainingInstalments = salesOrder
                .getNetValue()
                .subtract(instalmentForUpdate.getValue());

        BigDecimal instalmentValue = this.calculateInstalmentValue(valueForRemainingInstalments, instalmentsWithoutUpdated.size());
        SalesOrderInstalment instalment;

        for (int idxInstalments = 0; idxInstalments < instalmentsWithoutUpdated.size(); idxInstalments++) {
            instalment = instalmentsWithoutUpdated.get(idxInstalments);
            if (idxInstalments == instalmentsWithoutUpdated.size() - 1) {
                instalmentValue = this.calculateLastInstalment(valueForRemainingInstalments, instalmentsForReturn);
            }
            instalment.setValue(instalmentValue);
            instalmentsForReturn.add(instalment);
        }

        originalInstalmentInDb.setValue(instalmentForUpdate.getValue());
        originalInstalmentInDb.setDueDate(instalmentForUpdate.getDueDate());
        instalmentsForReturn.add(originalInstalmentInDb);

        return instalmentsForReturn;
    }


    /**
     * Handle the update when the element isn't the last one. It will calculate the value of all instalments with lower number
     * than the one you are editing and subtract the value from the order. After that it will divide by the number of subsequents.
     * The last value is the difference between  the value from order minus the sum of all instalments
     *
     * @param originalInstalmentInDb Entity instalment persisted, reflecting the object who will be updated
     * @param salesOrder             Entity order who the instalment belongs
     * @param instalmentForUpdate    Entity instalment who will be persisted
     * @author Maykon Rissi
     */
    private List<SalesOrderInstalment> handleUpdateWhenIsNotLastInstalment(final SalesOrder salesOrder,
                                                                           final SalesOrderInstalment originalInstalmentInDb,
                                                                           final SalesOrderInstalment instalmentForUpdate,
                                                                           final List<SalesOrderInstalment> instalmentsWithoutUpdated,
                                                                           final List<SalesOrderInstalment> instalmentsInDb,
                                                                           final List<SalesOrderInstalment> instalmentsForReturn) {

        BigDecimal instalmentValue = this.getInstalmentValueForUpdateSubsequents(originalInstalmentInDb,
                salesOrder,
                instalmentForUpdate,
                instalmentsInDb);

        SalesOrderInstalment instalment;

        for (int idxInstalment = 0; idxInstalment < instalmentsWithoutUpdated.size(); idxInstalment++) {
            instalment = instalmentsWithoutUpdated.get(idxInstalment);
            // If the number from current instalment is lower than the instalment from update, it will only add in the list.
            // This way only the future instalments will change the value
            if (instalment.getNumber() > idxInstalment + 1) {
                if (idxInstalment == instalmentsWithoutUpdated.size() - 1) {
                    BigDecimal valueForRemainingInstalments = instalmentsForReturn.stream()
                            .map(SalesOrderInstalment::getValue)
                            .reduce(BigDecimal::add)
                            .orElse(BigDecimal.ZERO)
                            .add(instalmentForUpdate.getValue());
                    instalmentValue = salesOrder.getNetValue().subtract(valueForRemainingInstalments);
                }
                if (instalmentValue.compareTo(BigDecimal.ZERO) <= 0) {
                    this.throwMessageException("orderInstalment.valueWillGenerateNegativeInstalments");
                }
                instalment.setValue(instalmentValue);
            }
            instalmentsForReturn.add(instalment);
        }

        originalInstalmentInDb.setValue(instalmentForUpdate.getValue());
        originalInstalmentInDb.setDueDate(instalmentForUpdate.getDueDate());
        instalmentsForReturn.add(originalInstalmentInDb);
        return instalmentsForReturn;
    }


    /**
     * Calculates the value of each subsequent instalment. If the number is 3, it will take de value from salesOrder and subtract
     * by the sum of the values of 1, 2 and 3. After that, it will divide by the number of subsequent instalments
     *
     * @param originalInstalmentInDb Entity instalment persisted, reflecting the object who will be updated
     * @param salesOrder             Entity order who the instalment belongs
     * @param instalmentForUpdate    Entity instalment who will be persisted
     * @param instalments            List of instalments persisted in db, who belongs to the order
     * @author Maykon Rissi
     */
    private BigDecimal getInstalmentValueForUpdateSubsequents(final SalesOrderInstalment originalInstalmentInDb,
                                                              final SalesOrder salesOrder,
                                                              final SalesOrderInstalment instalmentForUpdate,
                                                              final List<SalesOrderInstalment> instalments) {
        BigDecimal valueFromPreviousInstalments = instalments.stream()
                .filter(entity -> entity.getNumber() < originalInstalmentInDb.getNumber())
                .map(SalesOrderInstalment::getValue)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
        return (salesOrder.getNetValue()
                .subtract(valueFromPreviousInstalments)
                .subtract(instalmentForUpdate.getValue()))
                .divide(BigDecimal.valueOf(instalments.size() - originalInstalmentInDb.getNumber()), Constants.SCALE_INSTALMENTS, RoundingMode.HALF_EVEN);
    }

    /**
     * Throws an exception if the value of instalments is different than the value from order
     *
     * @param instalments List of instalments persisted in db, who belongs to the order
     * @param salesOrder  Entity order who the instalment belongs
     * @author Maykon Rissi
     */
    private void doValidateValueIsDifferentThanOrder(final List<SalesOrderInstalment> instalments,
                                                     final SalesOrder salesOrder) {
        if (instalments.stream().map(SalesOrderInstalment::getValue)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO).compareTo(salesOrder.getNetValue()) != 0) {
            this.throwMessageException("OrderInstalment.instalmentsValueDifferentThanOrder");
        }
    }

    /**
     * Validate if Order Exists when try delete instalments
     *
     * @param orderId Id from the order to validate if exists
     * @author
     */
    public void doValidateOrderExists(UUID orderId) {
        salesOrderDAO.findById(orderId);
    }
}
