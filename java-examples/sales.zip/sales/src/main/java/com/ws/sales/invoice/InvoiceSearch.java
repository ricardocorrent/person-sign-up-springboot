package com.ws.sales.invoice;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.commons.server.pagination.PaginationSearch;

import java.time.LocalDate;
import java.util.UUID;

/**
 * The class InvoiceSearch it's a filter class to search a invoice, here the user can put
 * the filters to search a invoice as expected.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
public class InvoiceSearch extends PaginationSearch {

    /**
     * This field is used to filter a invoice by id.
     */
    private UUID id;

    /**
     * This field is used to filter a invoice by number.
     */
    private String number;

    /**
     * This field is used to filter a invoice by series.
     */
    private String series;

    /**
     * This field is used to filter a invoice by a period of billing date.
     */
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private LocalDate initialBillingDate;

    /**
     * This field is used to filter a invoice by a period of billing date.
     */
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private LocalDate finalBillingDate;

    /**
     * This field is used to filter a invoice by the replicated field currencyReplicatedId.
     */
    private UUID currencyReplicatedId;

    /**
     * This field is used to filter a invoice by the replicated field customerReplicatedId.
     */
    private UUID customerReplicatedId;

    /**
     * This field is used to filter a invoice by the replicated field locationReplicatedId.
     */
    private UUID locationReplicatedId;

    /**
     * This field is used to filter a invoice by the replicated field paymentTermId.
     */
    private UUID paymentTermId;

    /**
     * This field is used to filter a invoice by the replicated field userReplicatedId.
     */
    private UUID userReplicatedId;

    /**
     * This field is used to filter a invoice by the foreign key invoiceSituationId.
     */
    private UUID invoiceSituationId;

    /**
     * This field is used to filter a invoice by the description of invoice situation.
     */
    private String invoiceSituationDescription;

    /**
     * This field is used to filter a invoice by the foreign key invoiceTypeId.
     */
    private UUID invoiceTypeId;

    /**
     * This field is used to filter a invoice by the externalId.
     */
    private String externalId;

    /**
     * Gets id.
     *
     * @return the id
     */
    public UUID getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param id the id
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Gets number.
     *
     * @return the number
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets number.
     *
     * @param number the number
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * Gets series.
     *
     * @return the series
     */
    public String getSeries() {
        return series;
    }

    /**
     * Sets series.
     *
     * @param series the series
     */
    public void setSeries(String series) {
        this.series = series;
    }

    /**
     * Gets initial billing date.
     *
     * @return the initial billing date
     */
    public LocalDate getInitialBillingDate() {
        return initialBillingDate;
    }

    /**
     * Sets initial billing date.
     *
     * @param initialBillingDate the initial billing date
     */
    public void setInitialBillingDate(LocalDate initialBillingDate) {
        this.initialBillingDate = initialBillingDate;
    }

    /**
     * Gets final billing date.
     *
     * @return the final billing date
     */
    public LocalDate getFinalBillingDate() {
        return finalBillingDate;
    }

    /**
     * Sets final billing date.
     *
     * @param finalBillingDate the final billing date
     */
    public void setFinalBillingDate(LocalDate finalBillingDate) {
        this.finalBillingDate = finalBillingDate;
    }


    /**
     * Gets currency replicated id.
     *
     * @return the currency replicated id
     */
    public UUID getCurrencyReplicatedId() {
        return currencyReplicatedId;
    }


    /**
     * Sets currency replicated id.
     *
     * @param currencyReplicatedId the currency replicated id
     */
    public void setCurrencyReplicatedId(UUID currencyReplicatedId) {
        this.currencyReplicatedId = currencyReplicatedId;
    }


    /**
     * Gets customer replicated id.
     *
     * @return the customer replicated id
     */
    public UUID getCustomerReplicatedId() {
        return customerReplicatedId;
    }


    /**
     * Sets customer replicated id.
     *
     * @param customerReplicatedId the customer replicated id
     */
    public void setCustomerReplicatedId(UUID customerReplicatedId) {
        this.customerReplicatedId = customerReplicatedId;
    }


    /**
     * Gets location replicated id.
     *
     * @return the location replicated id
     */
    public UUID getLocationReplicatedId() {
        return locationReplicatedId;
    }


    /**
     * Sets location replicated id.
     *
     * @param locationReplicatedId the location replicated id
     */
    public void setLocationReplicatedId(UUID locationReplicatedId) {
        this.locationReplicatedId = locationReplicatedId;
    }

    /**
     * Gets payment term id.
     *
     * @return the payment term id
     */
    public UUID getPaymentTermId() {
        return paymentTermId;
    }

    /**
     * Sets payment term id.
     *
     * @param paymentTermId the payment term id
     */
    public void setPaymentTermId(UUID paymentTermId) {
        this.paymentTermId = paymentTermId;
    }


    /**
     * Gets user replicated id.
     *
     * @return the user replicated id
     */
    public UUID getUserReplicatedId() {
        return userReplicatedId;
    }


    /**
     * Sets user replicated id.
     *
     * @param userReplicatedId the user replicated id
     */
    public void setUserReplicatedId(UUID userReplicatedId) {
        this.userReplicatedId = userReplicatedId;
    }

    /**
     * Gets invoice situation id.
     *
     * @return the invoice situation id
     */
    public UUID getInvoiceSituationId() {
        return invoiceSituationId;
    }

    /**
     * Sets invoice situation id.
     *
     * @param invoiceSituationId the invoice situation id
     */
    public void setInvoiceSituationId(UUID invoiceSituationId) {
        this.invoiceSituationId = invoiceSituationId;
    }

    /**
     * Gets invoice situation description.
     *
     * @return the invoice situation description
     */
    public String getInvoiceSituationDescription() {
        return invoiceSituationDescription;
    }

    /**
     * Sets invoice situation description.
     *
     * @param invoiceSituationDescription the invoice situation description
     */
    public void setInvoiceSituationDescription(String invoiceSituationDescription) {
        this.invoiceSituationDescription = invoiceSituationDescription;
    }

    /**
     * Gets invoice type id.
     *
     * @return the invoice type id
     */
    public UUID getInvoiceTypeId() {
        return invoiceTypeId;
    }

    /**
     * Sets invoice type id.
     *
     * @param invoiceTypeId the invoice type id
     */
    public void setInvoiceTypeId(UUID invoiceTypeId) {
        this.invoiceTypeId = invoiceTypeId;
    }

    /**
     * Gets external id.
     *
     * @return the external id
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets external id.
     *
     * @param externalId the external id
     */
    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }
}