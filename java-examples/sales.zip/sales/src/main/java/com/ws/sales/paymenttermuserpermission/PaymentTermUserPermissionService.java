package com.ws.sales.paymenttermuserpermission;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;
import javax.servlet.http.HttpServletRequest;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermUserPermissionService extends AbstractService<PaymentTermUserPermission> {

    private final PaymentTermDAO paymentTermDAO;
    private final PaymentTermUserPermissionValidator paymentTermUserPermissionValidator;

    /**
     * @param paymentTermUserPermissionDAO       to perform entity persistence
     * @param paymentTermDAO                     to load {@link PaymentTerm}
     * @param paymentTermUserPermissionValidator to handle permission validations
     **/
    @Inject
    public PaymentTermUserPermissionService(final PaymentTermUserPermissionDAO paymentTermUserPermissionDAO, final PaymentTermDAO paymentTermDAO,
                                            final PaymentTermUserPermissionValidator paymentTermUserPermissionValidator) {
        super(paymentTermUserPermissionDAO);
        this.paymentTermDAO = paymentTermDAO;
        this.paymentTermUserPermissionValidator = paymentTermUserPermissionValidator;
    }

    /**
     * @param paymentTermUserPermissions {@link List<PaymentTermUserPermission>} to persist
     * @param paymentTermId              to get {@link PaymentTerm}
     **/
    public void insertList(final List<PaymentTermUserPermission> paymentTermUserPermissions, final UUID paymentTermId) {
        final PaymentTerm paymentTerm = paymentTermDAO.findById(paymentTermId);
        this.doValidateByBeanValidation(paymentTermUserPermissions);
        this.doValidateLogic(paymentTermUserPermissions, paymentTerm);
        this.dao.batchInsert(paymentTermUserPermissions);
    }

    /**
     * @param paymentTermId to fill the search
     * @return {@link PagedList<PaymentTermUserPermission>}
     **/
    public PagedList<PaymentTermUserPermission> getByPaymentTerm(final UUID paymentTermId, HttpServletRequest request) {
        return ((PaymentTermUserPermissionDAO) this.dao).getByPaymentTerm(paymentTermId, request.getParameterMap());
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors. After validate, it will throw the errors
     *
     * @param paymentTermUserPermissions {@link List<PaymentTermUserPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateByBeanValidation(final List<PaymentTermUserPermission> paymentTermUserPermissions) {
        IntStream.range(0, paymentTermUserPermissions.size())
                .forEach(index -> paymentTermUserPermissionValidator.validateByBeanValidation(paymentTermUserPermissions.get(index), String.valueOf(index)));
        paymentTermUserPermissionValidator.throwFoundErrors();
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors.
     *
     * @param paymentTermUserPermissions {@link List<PaymentTermUserPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateLogic(final List<PaymentTermUserPermission> paymentTermUserPermissions, final PaymentTerm paymentTerm) {
        IntStream.range(0, paymentTermUserPermissions.size())
                .forEach(index -> paymentTermUserPermissionValidator.validate(paymentTermUserPermissions.get(index),
                        paymentTerm.getUserPermissions(),
                        String.valueOf(index)));
        paymentTermUserPermissionValidator.throwFoundErrors();
    }
}
