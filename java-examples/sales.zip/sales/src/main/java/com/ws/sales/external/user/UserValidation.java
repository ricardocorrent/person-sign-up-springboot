package com.ws.sales.external.user;

import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.user.model.Hierarchy;
import com.ws.user.model.User;

import javax.inject.Inject;
import java.util.Optional;
import java.util.UUID;

/**
 * Validations for customer and location
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-18
 */
public class UserValidation {

    private final UserGateway userGateway;
    private final UserContext userContext;

    /**
     * @param userGateway to perform user gets
     * @param userContext to get logged user
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Inject
    public UserValidation(final UserGateway userGateway,
                          final UserContext userContext) {
        this.userGateway = userGateway;
        this.userContext = userContext;
    }

    /**
     * Return an error if the user does not exist or is inactive.
     *
     * @param userId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    public LogicError doValidateUserCanBeUsed(final UUID userId) {
        return Optional.ofNullable(userId).map(id -> {
            final User user = userGateway.getUser(id);
            if (user == null) {
                return new LogicError(Constants.FIELD_USER_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!user.isActive()) {
                return new LogicError(Constants.FIELD_USER_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the user professional does not exist or is inactive.
     *
     * @param professionalId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    public LogicError doValidateProfessionalCanBeUsed(final UUID professionalId) {
        return Optional.ofNullable(professionalId).map(id -> {
            final User user = userGateway.getUser(id);
            if (user == null) {
                return new LogicError(Constants.FIELD_PROFESSIONAL, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!user.isActive()) {
                return new LogicError(Constants.FIELD_PROFESSIONAL, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the professional does not belong to the logged user hierarchy
     *
     * @param userProfessionalId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    public LogicError doValidateProfessionalBelongsToUserHierarchy(final UUID userProfessionalId) {
        return Optional.ofNullable(userProfessionalId).map(professionalId -> {
            final Boolean userIsAdmin = this.isLoggedUserAdmin();
            if (!userIsAdmin) {
                final UUID userLoggedId = this.getLoggedUserId();
                if (!professionalId.equals(userLoggedId)) {
                    final Boolean userDoesNotBelongToHierarchy = this.checkIfUserDoesNotBelongToLoggedUserHierarchy(userLoggedId, professionalId);
                    return userDoesNotBelongToHierarchy ? new LogicError(Constants.FIELD_PROFESSIONAL, Constants.MESSAGE_PROFESSIONAL_USER_HIERARCHY) : null;
                }
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return if the logged user id
     *
     * @return UUID from logged user
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    private UUID getLoggedUserId() {
        return UUID.fromString((String) userContext.getSession().getAttribute(Constants.FIELD_USER_ID_CONTEXT));
    }

    /**
     * Return if the logged user is admin
     *
     * @return true if the logged user is admin
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    private Boolean isLoggedUserAdmin() {
        return (Boolean) userContext.getSession().getAttribute(Constants.FIELD_USER_ADMIN_CONTEXT);
    }

    /**
     * Return true if the user does not belong to the logged user hierarchy
     *
     * @param userLoggedId       to load the hierarchy
     * @param userProfessionalId to load entity and validate
     * @return true if it does not belong and false if it belongs
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    private Boolean checkIfUserDoesNotBelongToLoggedUserHierarchy(final UUID userLoggedId, final UUID userProfessionalId) {
        final User loggedUser = userGateway.getUser(userLoggedId);
        return Optional.ofNullable(loggedUser)
                .map(User::getUserHierarchies)
                .map(streamOfHierarchies -> streamOfHierarchies.stream()
                        .map(Hierarchy::getUpperUser)
                        .map(User::getId)
                        .noneMatch(userId -> userId.equals(userProfessionalId.toString())))
                .orElse(Boolean.TRUE);
    }

    /**
     * Add an error if the informed user is different than the logged user
     *
     * @param userId to compare with the logged user
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    public LogicError doValidateIfInformedUserIsTheSameAsLoggedUser(final UUID userId) {
        return Optional.ofNullable(userId).map(informedId -> {
            final UUID userLoggedId = this.getLoggedUserId();
            return userLoggedId.equals(informedId) ? null : new LogicError(Constants.FIELD_USER, Constants.MESSAGE_USER_NOT_SAME_AS_LOGGED);
        }).orElse(null);
    }
}
