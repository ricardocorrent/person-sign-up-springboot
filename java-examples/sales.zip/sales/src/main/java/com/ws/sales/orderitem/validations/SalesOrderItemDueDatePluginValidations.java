package com.ws.sales.orderitem.validations;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.sales.external.product.ProductService;
import com.ws.sales.validator.ValidationUtils;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.validator.GenericValidator;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;

/**
 * Validation class for due date values and plugin
 *
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-03
 */
public class SalesOrderItemDueDatePluginValidations {

    private final OrderParameterService orderParameterService;
    private final ProductService productService;

    /**
     * @param orderParameterService to check if the plugin is enabled
     * @param productService        to handle due date coefficient value from product
     */
    @Inject
    public SalesOrderItemDueDatePluginValidations(final OrderParameterService orderParameterService, final ProductService productService) {
        this.orderParameterService = orderParameterService;
        this.productService = productService;
    }

    /**
     * <p>
     * It will validate the due date if the Discount and Increase values
     * are null and if the plugin is enabled.
     * <p>
     * It wont validate if {@link SalesOrderItem} is null and if any
     * mandatory fields are not filled
     *
     * @param salesOrderItem to get {@link SalesOrderItem} and {@link com.ws.sales.order.SalesOrder} information
     * @return {@link LogicError}
     */
    public LogicError doValidateDueDate(final SalesOrderItem salesOrderItem) {
        return Optional.ofNullable(salesOrderItem)
                .map(this::isDueDateAbleToBeValidated)
                .filter(mustValidate -> mustValidate.equals(Boolean.TRUE))
                .map(canBeValidated -> this.getDueDateError(salesOrderItem))
                .orElse(null);
    }

    /**
     * @return a {@link Boolean} indicating the status of the plugin, If it is enabled or disabled
     */
    private Boolean isDueDatePluginEnabled() {
        return Boolean.valueOf(this.orderParameterService.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_PRICE).getValue());
    }

    /**
     * <p>
     * Due date is enabled to be validated if both discount and increase are null. Otherwise there will be a LogicError
     * created from {@link com.ws.sales.orderitem.SalesOrderItemValidator#doValidateDiscountAndIncrease(SalesOrderItem)}
     *
     * @param salesOrderItem to check if increase and discounts are null
     * @return {@link Boolean}
     */
    private Boolean isDueDateAbleToBeValidated(final SalesOrderItem salesOrderItem) {
        final SalesOrderItem item = Optional.ofNullable(salesOrderItem).orElse(new SalesOrderItem());
        final Boolean increaseIsNull = item.getIncreaseValue() == null && item.getIncreasePercentage() == null;
        final Boolean discountIsNull = item.getDiscountValue() == null && item.getDiscountPercentage() == null;
        return increaseIsNull && discountIsNull;
    }

    /**
     * <p>
     * Uses {@link GenericValidator#applyValidator(Function, Object, List)} to fill a list
     * of errors and link the validations.
     * <p>
     * It will return only the first error, because it will stop validations after
     * the first one.
     *
     * @param salesOrderItem to validate
     * @return {@link LogicError}
     */
    private LogicError getDueDateError(final SalesOrderItem salesOrderItem) {
        final List<LogicError> errors = new LinkedList<>();
        GenericValidator.applyValidator(this::doValidateDueDatePlugin, salesOrderItem.getDueDateValue(), errors);
        GenericValidator.applyValidator(this::doValidateDueDateValue, salesOrderItem, errors);
        return errors.stream().filter(Objects::nonNull).findFirst().orElse(null);
    }

    /**
     * <p>
     * Using the {@link this#isDueDatePluginEnabled()}, it will check if
     * the plugin is enabled and if there is a value in {@link SalesOrderItem#dueDateValue}
     *
     * @param dueDateValue to check if there is any value
     * @return {@link LogicError}
     */
    private LogicError doValidateDueDatePlugin(final BigDecimal dueDateValue) {
        final Boolean canNotInformDueDate = !this.isDueDatePluginEnabled() && dueDateValue != null;
        return canNotInformDueDate ? new LogicError(Constants.FIELD_DUE_DATE_VALUE, Constants.MESSAGE_DUE_DATE_PLUGIN_DISABLED) : null;
    }

    /**
     * <p>
     * Uses {@link SalesOrderItem#priceListId} and {@link SalesOrderItem#getSalesPrice()} to
     * check the coefficient from due date in the {@link com.ws.product.model.PriceList} using the
     * {@link ProductService#getDueDateCoefficient(UUID, LocalDate)}.
     * <p>
     * With the coefficient, it will use {@link this#doCalculateDueDateValueFromItem(BigDecimal, BigDecimal)} to check
     * the value that {@link SalesOrderItem#getDueDateValue()} must have.
     * <p>
     * Uses the {@link this#doCompareValuesAndCreateLogicError(BigDecimal, SalesOrderItem)} o calculate and create the error
     * <p>
     * If any of the values needed are null, it will return null;
     *
     * @param salesOrderItem to get item information
     * @return {@link LogicError}
     */
    private LogicError doValidateDueDateValue(final SalesOrderItem salesOrderItem) {
        if (salesOrderItem != null &&
                (salesOrderItem.getPriceListId() == null || salesOrderItem.getSalesOrder() == null || salesOrderItem.getOriginalPrice() == null
                        || salesOrderItem.getDueDateValue() == null)) {
            return null;
        }
        return Optional.ofNullable(salesOrderItem)
                .map(dueDateValue -> this.productService.getDueDateCoefficient(salesOrderItem.getPriceListId(), salesOrderItem.getSalesOrder().getDueDate()))
                .map(dueDateCoefficient -> this.doCalculateDueDateValueFromItem(dueDateCoefficient, salesOrderItem.getOriginalPrice()))
                .map(calculatedDueDateValue -> this.doCompareValuesAndCreateLogicError(calculatedDueDateValue, salesOrderItem)).orElse(null);
    }

    /**
     * <p>
     * Round both received and created values using {@link this#getValueFormatted(BigDecimal)}
     * and then compare them. If they are different, it will return an {@link LogicError}
     * otherwise it will return null
     *
     * @param calculatedDueDateValue generated dueDateValue to round and compare
     * @param salesOrderItem         to get item information
     * @return {@link LogicError}
     */
    private LogicError doCompareValuesAndCreateLogicError(final BigDecimal calculatedDueDateValue, final SalesOrderItem salesOrderItem) {
        final BigDecimal dueDateFromServer = this.getValueFormatted(salesOrderItem.getDueDateValue());
        final BigDecimal dueDateCalculated = this.getValueFormatted(calculatedDueDateValue);
        final Boolean valuesAreEqual = dueDateFromServer.compareTo(dueDateCalculated) == 0;
        return valuesAreEqual ? null : ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_VALUE,
                dueDateCalculated.toString(),
                Constants.FIELD_DUE_DATE_VALUE,
                Constants.MESSAGE_VALUE_SHOULD_BE);
    }

    /**
     * <p>
     * Format a value using {@link Constants#SCALE_DUE_DATE}. The value can not
     * be null. Must be used in this class to centralize all the rounding and
     * scale for dueDate validations
     *
     * @param value to be formatted
     * @return {@link BigDecimal}
     */
    private BigDecimal getValueFormatted(final BigDecimal value) {
        Objects.requireNonNull(value);
        return value.setScale(Constants.SCALE_DUE_DATE, RoundingMode.HALF_EVEN);
    }

    /**
     * <p>
     * Uses {@link SalesOrderItem#getSalesPrice()} and dueDateCoefficient to generate the right value for dueDateValue
     *
     * @param dueDateCoefficient to handle the multiply and generate the dueDateValue
     * @param itemOriginalPrice  to handle the multiply and generate the dueDateValue
     * @return {@link BigDecimal}
     */
    private BigDecimal doCalculateDueDateValueFromItem(final BigDecimal dueDateCoefficient, final BigDecimal itemOriginalPrice) {
        final BigDecimal itemValueWithDueDate = itemOriginalPrice.multiply(dueDateCoefficient);
        return itemValueWithDueDate.subtract(itemOriginalPrice);
    }
}
