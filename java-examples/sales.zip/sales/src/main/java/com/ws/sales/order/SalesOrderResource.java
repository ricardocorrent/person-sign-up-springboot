package com.ws.sales.order;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.interceptor.sourceannotation.ConversionProduces;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapterFactory;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.Id;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.documents.Document;
import com.ws.sales.documents.DocumentSaleCreator;
import com.ws.sales.documents.DocumentService;
import com.ws.sales.documents.requestsignature.RequestSignatureDTO;
import com.ws.sales.documents.requestsignature.RequestSignatureResponseDTO;
import com.ws.sales.documents.requestsignature.RequestSignatureService;
import com.ws.sales.order.dto.*;
import com.ws.sales.orderinstalment.SalesOrderInstalment;
import com.ws.sales.orderinstalment.SalesOrderInstalmentGenerate;
import com.ws.sales.orderinstalment.SalesOrderInstalmentSearch;
import com.ws.sales.orderinstalment.SalesOrderInstalmentService;
import com.ws.sales.orderinstalment.dto.SalesOrderInstalmentGetDTO;
import com.ws.sales.orderinstalment.dto.SalesOrderInstalmentUpdateDTO;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderitem.SalesOrderItemSearch;
import com.ws.sales.orderitem.SalesOrderItemService;
import com.ws.sales.orderitem.dto.FinishedOrderItemDTO;
import com.ws.sales.orderitem.dto.ItemGetDTO;
import com.ws.sales.orderitem.dto.ItemPersistDTO;
import com.ws.sales.orderservice.SalesOrderServiceSearch;
import com.ws.sales.orderservice.SalesOrderServiceService;
import com.ws.sales.orderservice.dto.SalesOrderServiceDTO;
import com.ws.sales.signeddocument.SalesOrderSignedDocument;
import com.ws.sales.signeddocument.SalesOrderSignedDocumentService;
import com.ws.sales.util.HateoasDtoConverter;
import com.ws.sales.util.SalesAbstractResource;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * @since v1.0.0 2016-08-31
 * @version 1.1.0 - 2019-05-03
 *
 * @author Thyago Volpatto
 * @author Ricardo Corrent
 *
 */
@Path("/orders")
public class SalesOrderResource extends SalesAbstractResource<SalesOrder, SalesOrderSearch> {

    private static final String PERMISSION_WRITE = "sales:orders:write";
    private static final String PERMISSION_DELETE = "sales:orders:delete";
    private static final String PERMISSION_READ = "sales:orders:read";
    private final SalesOrderService salesOrderService;
    private final SalesOrderItemService salesOrderItemService;
    private final SalesOrderServiceService salesOrderServiceService;
    private final SalesOrderInstalmentService instalmentService;
    private final HateoasDtoConverter hateoasDtoConverter;
    private final DocumentService documentService;
    private final SalesOrderSignedDocumentService signedDocumentService;
    private final RequestSignatureService requestSignatureService;

    @Inject
    public SalesOrderResource(final SalesOrderService service,
                              final SalesOrderItemService salesOrderItemService,
                              final SalesOrderInstalmentService instalmentService,
                              final DocumentService documentService,
                              final HateoasDtoConverter hateoasDtoConverter,
                              final SalesOrderServiceService salesOrderServiceService,
                              final SalesOrderSignedDocumentService signedDocumentService,
                              final RequestSignatureService requestSignatureService) {
        this.salesOrderService = service;
        this.salesOrderItemService = salesOrderItemService;
        this.instalmentService = instalmentService;
        this.documentService = documentService;
        this.hateoasDtoConverter = hateoasDtoConverter;
        this.salesOrderServiceService = salesOrderServiceService;
        this.signedDocumentService = signedDocumentService;
        this.requestSignatureService = requestSignatureService;
    }

    /**
     * @param parameters as {@link SalesOrderSearch}
     * @return {@link Response}
     * @see Response
     * @see SalesOrderSearch
     */
    @Override
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response search(final SalesOrderSearch parameters) {
        return Response.ok().entity(salesOrderService.search(parameters)).build();
    }

    /**
     * Validate the order.
     *
     * @param order
     * @return
     */
    @POST
    @Path("/validate-order")
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response validateOrder(@Valid final SalesOrder order) {
        return Response.ok().build();
    }

    /**
     * @param id
     * @return
     */
    @GET
    @Path("/{id}/summary")
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(OrderSummaryDTO.class)
    public Response summary(@PathParam("id") final String id) {
        return Response.ok().entity(this.salesOrderService.get(UUID.fromString(id))).build();
    }

    /**
     * Save the {@link SalesOrder} with its first step, the Header.
     *
     * @param order
     * @return
     * @throws Exception
     */
    @Override
    @ConversionConsumes(SalesOrderDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response insert(@Valid @Consumer final SalesOrder order) throws Exception {
        return Response.status(Response.Status.CREATED).entity(new Id(this.salesOrderService.insert(order))).build();
    }

    /**
     * Gets the first step of {@link SalesOrder}, the Header, filtering by id.
     *
     * @param id
     * @return
     */
    @Override
    public Response get(final UUID id) throws Exception {
        final SalesOrder salesOrder = salesOrderService.get(id);
        final SalesOrderDTO salesOrderDTO = hateoasDtoConverter.createDTO(SalesOrderDTO.class, salesOrder, id);
        return Response.ok().entity(salesOrderDTO).build();
    }

    /**
     * Updates the {@link SalesOrder} with its first step, the Header.
     *
     * @param order
     * @return
     * @throws Exception
     */
    @Override
    @ConversionConsumes(SalesOrderDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response update(final UUID id, @Consumer final SalesOrder order) throws Exception {
        order.setId(id);
        this.salesOrderService.update(order);
        return Response.ok().build();
    }

    @Override
    public Response list() throws Exception {
        final RestQueryAdapter restQueryAdapter = RestQueryAdapterFactory.fromHttpRequest(httpRequest);
        final PagedList<SalesOrder> list = salesOrderService.list(restQueryAdapter);
        final PagedList<SalesOrderDTO> salesOrderDTOList = hateoasDtoConverter.createDTO(SalesOrderDTO.class, list);
        return Response.ok().entity( salesOrderDTOList).build();
    }


    /**
     * Deprecated by update commons to 7.4.2, because the search method will not be used
     * Use {@link #list()}
     * @param params
     * @return
     */
    @Deprecated
    @POST
    @Path("/listing")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(OrderListDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response searchList(final SalesOrderSearch params) {
        return Response.ok().entity(this.salesOrderService.search(params)).build();
    }

    /**
     * ITEMS MANIPULATION BEGIN
     */
    @GET
    @Path("/{orderId}/items")
    @ConversionProduces(ItemGetDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getItems(@PathParam("orderId") final UUID orderId, final @Context HttpServletRequest request) {
        final PagedList<SalesOrderItem> items = this.salesOrderItemService.findByOrder(orderId, new HttpRestQueryAdapter(request));
        return Response.ok().entity(items).build();
    }

    @POST
    @Path("/{orderId}/items")
    @ConversionConsumes(ItemPersistDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response insertItem(@PathParam("orderId") final UUID orderId, final @Consumer SalesOrderItem item) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        item.setSalesOrder(order);
        final SalesOrderItem insertedItem = this.salesOrderItemService.insert(item);
        return Response.status(Response.Status.CREATED).entity(new Id(insertedItem)).build();
    }

    /**
     * Method for insert item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param orderId
     * @param item
     */
    @POST
    @Path("/{orderId}/items/update-finished-order")
    @ConversionConsumes(FinishedOrderItemDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response insertItemFinishedOrder(@PathParam("orderId") final UUID orderId, final @Consumer SalesOrderItem item) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        item.setSalesOrder(order);
        final SalesOrderItem insertedItem = this.salesOrderItemService.insertItemFinishOrder(item);
        return Response.status(Response.Status.CREATED).entity(new Id(insertedItem)).build();
    }

    @PUT
    @Path("/{orderId}/items/{id}")
    @ConversionConsumes(ItemPersistDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateItem(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id,
            @Consumer final SalesOrderItem item) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        item.setSalesOrder(order);
        item.setId(id);
        this.salesOrderItemService.update(item);
        return Response.ok().build();
    }

    /**
     * Method for update item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param orderId
     * @param id
     * @param item
     */
    @PUT
    @Path("/{orderId}/items/{id}/update-finished-order")
    @ConversionConsumes(ItemPersistDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateItemFinishedOrder(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id,
            @Consumer final SalesOrderItem item) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        item.setSalesOrder(order);
        item.setId(id);
        this.salesOrderItemService.updateItemFinishOrder(item);
        return Response.ok().build();
    }

    @PUT
    @Path("/{orderId}/signature")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateSignature(final @PathParam("orderId") UUID orderId, final String signatureId) throws Exception {
        SalesOrder order = new SalesOrder();
        order.setId(orderId);
        order = salesOrderService.get(order.getId());
        order.setSignatureId(signatureId != null && !"".equals(signatureId) ? UUID.fromString(signatureId) : null);
        super.update(orderId, order);
        return Response.ok().build();
    }

    @GET
    @Path("/{orderId}/signature")
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getSignature(final @PathParam("orderId") String orderId) {
        return Response.ok().entity(this.salesOrderService.get(UUID.fromString(orderId)).getSignatureId()).build();
    }

    @DELETE
    @Path("/{orderId}/items/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_DELETE)
    public Response deleteItem(@PathParam("orderId") final UUID orderId, @PathParam("id") final UUID id) throws Exception {
        this.salesOrderItemService.delete(id);
        return Response.ok().build();
    }

    /**
     * Method for delete item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param orderId
     * @param id
     */
    @DELETE
    @Path("/{orderId}/items/{id}/update-finished-order")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_DELETE)
    public Response deleteItemFinishedOrder(@PathParam("orderId") final UUID orderId, @PathParam("id") final UUID id) throws Exception {
        this.salesOrderItemService.deleteItemFinishOrder(id);
        return Response.ok().build();
    }

    @GET
    @Path("/{orderId}/items/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(ItemGetDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getItem(@PathParam("orderId") final UUID orderId, @PathParam("id") final UUID id) {
        return Response.ok().entity(this.salesOrderItemService.get(id)).build();
    }

    @POST
    @Path("/{orderId}/items/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionProduces(ItemGetDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response searchItem(@PathParam("orderId") final UUID orderId, @Consumer final SalesOrderItemSearch search) {
        search.setSalesOrderId(orderId);
        return Response.ok().entity(this.salesOrderItemService.list(search)).build();
    }

    @PUT
    @Path("/{orderId}/finalize")
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response finalize(@PathParam("orderId") final UUID orderId) throws Exception {
        this.salesOrderService.doFinalizeOrder(orderId);
        return Response.ok().build();
    }

    @PUT
    @Path("/{orderId}/complement")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderComplementDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateComplement(@PathParam("orderId") final UUID orderId, @Consumer final SalesOrder order) throws Exception {
        order.setId(orderId);
        this.salesOrderService.updateComplement(order);
        return Response.ok().build();
    }

    @GET
    @Path("/{orderId}/complement")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(OrderComplementDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getComplement(@PathParam("orderId") final UUID orderId) {
        return Response.ok().entity(salesOrderService.get(orderId)).build();
    }

    // Order instalment

    @POST
    @Path("/{orderId}/order-instalments")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionProduces(SalesOrderInstalmentGetDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response generateInstalments(@PathParam("orderId") final UUID orderId, @Consumer @Valid final SalesOrderInstalmentGenerate obj) throws Exception {
        final List<SalesOrderInstalment> instalments = this.instalmentService.generateInstalments(obj, orderId);
        return Response.status(HttpStatus.SC_CREATED).entity(instalments).build();
    }

    @PUT
    @Path("/{orderId}/order-instalments/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionProduces(SalesOrderInstalmentGetDTO.class)
    @ConversionConsumes(SalesOrderInstalmentUpdateDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateInstalments(@PathParam("orderId") final UUID orderId,
            @Consumer final SalesOrderInstalment obj,
            @PathParam("id") final UUID instalmentId) {
        obj.setId(instalmentId);
        return Response.ok(this.instalmentService.updateEntity(obj, orderId)).build();
    }

    @DELETE
    @Path("/{orderId}/order-instalments")
    @RequiresPermissions(SalesOrderResource.PERMISSION_DELETE)
    public Response deleteInstalments(@PathParam("orderId") final UUID orderId) {
        this.instalmentService.deleteByOrderId(orderId);
        return Response.ok().build();
    }

    @POST
    @Path("/{orderId}/order-instalments/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionProduces(SalesOrderInstalmentGetDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response searchInstalments(final @PathParam("orderId") UUID orderId,
            SalesOrderInstalmentSearch search) {
        if (search == null) {
            search = new SalesOrderInstalmentSearch();
        }
        search.setOrderId(orderId);
        return Response.ok(this.instalmentService.search(search)).build();
    }

    @POST
    @Path("/{orderId}/document")
    @Resource
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response generateDocument(final @PathParam("orderId") UUID orderId, @Valid final DocumentSaleCreator documentSaleCreator) throws IOException {
        final SalesOrder salesOrder = this.service.get(orderId);
        final Document document = this.documentService.createDocument(salesOrder, documentSaleCreator);
        return Response.status(HttpStatus.SC_OK)
                .entity(document.getStream())
                .header(HttpHeaders.CONTENT_DISPOSITION, document.getFilename())
                .build();
    }

    /**
     * Send the {@link RequestSignatureDTO} to be signed by customer.
     *
     * @param orderId to be used in the item register.
     * @param requestSignatureDTO with the information to be send to the sign
     * @return a {@link Response} with a status and the documentId of {@link SalesOrderSignedDocument} created.
     * @throws Exception when request params are invalids
     *
     * @since 1.0.0 2019-05-03
     *
     * @author Ricardo Corrent
     */
    @POST
    @Path("/{orderId}/document/request-signature")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response requestSignature(final @PathParam("orderId") UUID orderId,
                                     @Valid @Consumer final RequestSignatureDTO requestSignatureDTO) throws Exception {
        requestSignatureDTO.setSalesOrderId(orderId);
        final SalesOrderSignedDocument signedDocument = this.requestSignatureService.sendRequestSignature(requestSignatureDTO);
        return Response
                .status(HttpStatus.SC_CREATED)
                .entity(new RequestSignatureResponseDTO(signedDocument.getId().toString()))
                .build();
    }

    /**
     * SALESORDERSERVICE RESOURCE BEGIN
     */

    @GET
    @Path("/{orderId}/services")
    @ConversionProduces(SalesOrderServiceDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getServices(@PathParam("orderId") final UUID orderId, final @Context HttpServletRequest request) {
        final PagedList<com.ws.sales.orderservice.SalesOrderService> items = this.salesOrderServiceService.findByOrder(orderId, new HttpRestQueryAdapter(request));
        return Response.ok().entity(items).build();
    }

    @POST
    @Path("/{orderId}/services")
    @ConversionConsumes(SalesOrderServiceDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response insertService(
            @PathParam("orderId") final UUID orderId,
            final @Consumer com.ws.sales.orderservice.SalesOrderService item) throws Exception {
        item.setSalesOrder(salesOrderService.get(orderId));
        final com.ws.sales.orderservice.SalesOrderService insertedItem = this.salesOrderServiceService.insert(item);
        return Response.status(Response.Status.CREATED).entity(new Id(insertedItem)).build();
    }

    /**
     * Method for insert service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param orderId to be used in the service register.
     * @param service to persist
     * @return a {@link Response} with a status and the id of {@link SalesOrderService} created.
     * @throws Exception when request params are invalids
     */
    @POST
    @Path("/{orderId}/services/update-finished-order")
    @ConversionConsumes(SalesOrderServiceDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response insertServiceFinishedOrder(
            @PathParam("orderId") final UUID orderId,
            final @Consumer com.ws.sales.orderservice.SalesOrderService service) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        service.setSalesOrder(order);
        final com.ws.sales.orderservice.SalesOrderService insertedItem = this.salesOrderServiceService.insertServiceFinishOrder(service);
        return Response.status(Response.Status.CREATED).entity(new Id(insertedItem)).build();
    }

    @PUT
    @Path("/{orderId}/services/{id}")
    @ConversionConsumes(SalesOrderServiceDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateService(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id,
            @Consumer final com.ws.sales.orderservice.SalesOrderService item) throws Exception {
        item.setSalesOrder(salesOrderService.get(orderId));
        item.setId(id);
        this.salesOrderServiceService.update(item);
        return Response.ok().build();
    }

    /**
     * Method for update service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param orderId to be used in the service register.
     * @param id to update
     * @return a {@link Response} with a status ok
     * @throws Exception when request params are invalids
     */
    @PUT
    @Path("/{orderId}/services/{id}/update-finished-order")
    @ConversionConsumes(SalesOrderServiceDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response updateServiceFinishedOrder(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id,
            @Consumer final com.ws.sales.orderservice.SalesOrderService item) throws Exception {
        final SalesOrder order = new SalesOrder();
        order.setId(orderId);
        item.setSalesOrder(order);
        item.setId(id);
        this.salesOrderServiceService.updateFinishOrder(item);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{orderId}/services/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_DELETE)
    public Response deleteService(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id) throws Exception {
        this.salesOrderServiceService.delete(id);
        return Response.ok().build();
    }

    /**
     * Method for delete service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param orderId to be used in the service register.
     * @param id to delete
     * @return a {@link Response} with a status ok if deleted
     * @throws Exception when request params are invalids
     */
    @DELETE
    @Path("/{orderId}/services/{id}/update-finished-order")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_DELETE)
    public Response deleteServiceFinishedOrder(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id) throws Exception {
        this.salesOrderServiceService.deleteFinishedOrder(id);
        return Response.ok().build();
    }

    @GET
    @Path("/{orderId}/services/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(SalesOrderServiceDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getService(
            @PathParam("orderId") final UUID orderId,
            @PathParam("id") final UUID id) {
        return Response.ok().entity(this.salesOrderServiceService.get(id)).build();
    }

    @POST
    @Path("/{orderId}/services/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionProduces(SalesOrderServiceDTO.class)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response searchService(
            @PathParam("orderId") final UUID orderId,
            @Consumer final SalesOrderServiceSearch search) {
        return Response.ok().entity(this.salesOrderServiceService.list(search)).build();
    }

    /**
     * Gets {@link SalesOrderSignedDocument} related to an order
     *
     * @param orderId to be used in the search
     * @return a {@link Response} with a list of the {@link SalesOrderSignedDocument}
     */
    @GET
    @Path("/{orderId}/signed-documents")
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response getSignedDocuments(@PathParam("orderId") final UUID orderId) {
        final RestQueryAdapter restQueryAdapter = RestQueryAdapterFactory.fromHttpRequest(httpRequest);
        final PagedList<SalesOrderSignedDocument> items = this.signedDocumentService.findByOrder(orderId, restQueryAdapter);
        return Response.ok().entity(items).build();
    }

    /**
     * Check and update {@link SalesOrderSignedDocument}.
     *
     * @param orderId {@link UUID} used to get a list of signed documents
     * @return {@link Response} with the numbers of documents updated
     * @throws Exception if exists an error on the object update
     */
    @GET
    @Path("/{orderId}/signed-documents/check-update")
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_READ)
    public Response checkUpdates(@PathParam("orderId") final UUID orderId) throws Exception {
        final SalesOrder salesOrder = this.salesOrderService.get(orderId);
        return Response.ok().entity(this.signedDocumentService.updateDocumentsSigned(salesOrder)).build();
    }

    /**
     * Method to update a {@link SalesOrder} already completed
     *
     * @param orderId to set which {@link SalesOrder} must be used to update
     * @return a {@link Response} with the right {@link HttpStatus}
     * @author Diogo Melo
     *
     * @since v8.0.0 2019-05-30
     */
    @PUT
    @Path("/{orderId}/update-finished-order")
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderFinishedDTO.class)
    public Response updateFinishedOrder(@PathParam("orderId") final UUID orderId,
                                        @Consumer final SalesOrder order) throws Exception {
        order.setId(orderId);
        this.salesOrderService.updateFinishedOrder(order);
        return Response.ok().build();
    }

    /**
     * Send the {@link UUID} to be copied
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent

     * @param orderId {@link UUID} to be used in the copy.
     * @return a {@link Response} with a status and the id of {@link SalesOrder} copied.
     * @throws Exception when request params are invalids
     */
    @POST
    @Path("/{orderId}/copy")
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderResource.PERMISSION_WRITE)
    public Response copySalesOrder(final @PathParam("orderId") UUID orderId) throws Exception {
        return Response
                .status(HttpStatus.SC_CREATED)
                .entity(new Id(this.salesOrderService.copy(orderId)))
                .build();
    }

}
