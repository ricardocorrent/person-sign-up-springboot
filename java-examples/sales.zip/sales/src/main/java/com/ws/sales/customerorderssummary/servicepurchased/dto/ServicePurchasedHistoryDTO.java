package com.ws.sales.customerorderssummary.servicepurchased.dto;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.sales.customerorderssummary.servicepurchased.ServicePurchasedHistoryView;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * This DTO class was created to represent the purchase service one from customer.
 * This data comes from {@link ServicePurchasedHistoryView} file
 * through to the sql query
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-21
 */
@Getter
@Setter
@Entity
@Table(name = "service_purchased_history_view")
public class ServicePurchasedHistoryDTO implements IPojoConverter {

    private OffsetDateTime purchaseDate;

    private BigDecimal salesPrice;

    private BigDecimal quantity;

}