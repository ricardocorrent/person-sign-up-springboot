package com.ws.sales.orderintegration.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.administration.dto.CompanyDTO;
import com.ws.sales.external.customer.dto.CustomerDTO;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.external.product.dto.PriceListDTO;
import com.ws.sales.external.situation.SituationDTO;
import com.ws.sales.external.user.dto.UserDTO;
import com.ws.sales.ordertype.dto.OrderTypeDTO;
import com.ws.sales.paymentmethod.dto.PaymentMethodDTO;
import com.ws.sales.paymentterm.PaymentTermDTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since 8.6.0 2019-06-27
 */
@Getter
@Setter
public class SalesOrderIntegrationDTO extends BaseDTO {

    private UUID id;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "user.id", target = "userId"),
            @PojoColumnMapper(source = "user.name", target = "userName")
    })
    private UserDTO user;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "userProfessional.id", target = "userProfessionalId"),
            @PojoColumnMapper(source = "userProfessional.name", target = "userProfessionalName")
    })
    private UserDTO userProfessional;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "customer.id", target = "customerId"),
            @PojoColumnMapper(source = "customer.name", target = "customerName")
    })
    private CustomerDTO customer;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "location.id", target = "locationId"),
            @PojoColumnMapper(source = "location.description", target = "locationDescription")
    })
    private LocationDTO location;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "company.id", target = "companyId"),
            @PojoColumnMapper(source = "company.name", target = "companyName")
    })
    private CompanyDTO company;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "orderType.id", target = "orderTypeId"),
            @PojoColumnMapper(source = "orderType.description", target = "orderTypeDescription")
    })
    private OrderTypeDTO orderType;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "priceList.id", target = "priceListId"),
            @PojoColumnMapper(source = "priceList.description", target = "priceListDescription")
    })
    private PriceListDTO priceList;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "paymentTerm.id", target = "paymentTermId"),
            @PojoColumnMapper(source = "paymentTerm.description", target = "paymentTermDescription")
    })
    private PaymentTermDTO paymentTerm;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "paymentMethod.id", target = "paymentMethodId"),
            @PojoColumnMapper(source = "paymentMethod.description", target = "paymentMethodDescription")
    })
    private PaymentMethodDTO paymentMethod;

    private OrderCurrencyIntegrationDTO orderCurrency;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "situation.id", target = "situationId"),
            @PojoColumnMapper(source = "situation.description", target = "situationDescription")
    })
    private SituationDTO situation;

    private List<ProductIntegrationDTO> items;

    private List<ServiceIntegrationDTO> services;

    private BigDecimal netValue;

    private BigDecimal serviceTotalValue;

    private BigDecimal productTotalValue;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate createDate;

    private String origin;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate dueDate;

    private OffsetDateTime orderedAt;

    private OffsetDateTime exportedAt;

    private String complement;

    private Boolean draft;

    @PojoColumnMapper(target = "orderNotes")
    private String notes;

    private UUID signatureId;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "activity.id", target = "activityId"),
    })
    private String externalId;

    private String externalNumber;
}
