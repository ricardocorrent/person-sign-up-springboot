package com.ws.sales.ordertype;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;

import io.ebean.ExpressionList;
import io.ebean.Query;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class OrderTypeDAO extends AbstractDAO<OrderType> {

    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class getEntityClass() {
        return OrderType.class;
    }

    /**
     * Filter and returns a list of orders.
     *
     * @param search
     * @return PagedList<OrderType>
     */
    public PagedList<OrderType> list(final OrderTypeSearch search) {

        final Query<OrderType> query = find();

        final ExpressionList<OrderType> where = query.where();

        if (!StringUtils.isEmpty(search.getDescription())) {
            where.icontains("description", search.getDescription());
        }

        if (search.getActive() != null && search.getActive().length > 0) {
            where.eq("active", search.getActive()[0]);
        }

        if (search.getAvailableFirstOrder() != null && search.getAvailableFirstOrder().length > 0) {
            where.eq("availableFirstOrder", search.getAvailableFirstOrder()[0]);
        }

        if (search.getStandard() != null && search.getStandard().length > 0) {
            where.eq("standard", search.getStandard()[0]);
        }

        return getPagedList(query, search);

    }

    /**
     * @return a single {@link OrderType} which standard property is equals true
     * @author Sanderson silva
     * @since 1.0.0 2016-10-10
     */
    public OrderType getStandard() {
        return find().where().eq("standard", Boolean.TRUE).findOne();
    }

    /**
     * @author Marcos Matheus de andrade
     * Check if order type exists.
     */
    public boolean orderTypeExists(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("id").where().eq("id", id).findCount() > 0;
    }

    /**
     * @author Marcos Matheus de andrade
     */
    public OrderType getStateOrdertype(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("active").where().eq("id", id).findOne();
    }
}
