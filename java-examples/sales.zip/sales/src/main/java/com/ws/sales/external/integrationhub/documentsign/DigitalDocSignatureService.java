package com.ws.sales.external.integrationhub.documentsign;

import com.ws.integrationhub.model.DigitalDocSignature;
import com.ws.integrationhub.model.DigitalDocSignatureMember;
import com.ws.integrationhub.model.SignatureRole;
import com.ws.sales.documents.Document;
import com.ws.sales.documents.requestsignature.RequestSignatureDTO;
import org.apache.commons.compress.utils.IOUtils;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.io.IOException;
import java.util.Base64;

/**
 * Handle the logic to post and get documents to
 * the connector that the user has credentials.
 *
 * @since 8.3.0 2019-05-08
 *
 * @author Ricardo Corrent
 */
public class DigitalDocSignatureService {

    private static final int FILENAME_POSITION = 1;
    private static final int FILENAME_LABEL_LENGHT = 10;

    private final DigitalDocSignatureGateway digitalDocSignatureGateway;

    /**
     * Injectable constructor with need instances to attend requests.
     *
     * @param digitalDocSignatureGateway {@link DigitalDocSignatureGateway} to make calls to integration api
     */
    @Inject
    public DigitalDocSignatureService(final DigitalDocSignatureGateway digitalDocSignatureGateway) {
        this.digitalDocSignatureGateway = digitalDocSignatureGateway;
    }

    /**
     * This method is used to send the {@link DigitalDocSignature} to customer.
     *
     * @param document {@link Document}.
     * @param requestSignatureDTO {@link RequestSignatureDTO}.
     * @param base64Document {@link String}.
     * @return {@link DigitalDocSignatureResponse} with returned data of integration api.
     */
    public DigitalDocSignatureResponse sendDocumentToSign(final Document document,
                                                          final RequestSignatureDTO requestSignatureDTO) throws IOException {
        final DigitalDocSignature digitalDocSignature = new DigitalDocSignature();
        digitalDocSignature.setDocumentName(document.getFilename()
                .split(";")[FILENAME_POSITION]
                .substring(FILENAME_LABEL_LENGHT)
                .replaceAll("^\"|\"$", ""));

        digitalDocSignature.setRejectable(Boolean.TRUE);
        digitalDocSignature.setEmailMessage(requestSignatureDTO.getMessage());
        digitalDocSignature.setFileBase64(this.getBase64Document(document));
        digitalDocSignature.getSignatories().add(this.returnSignatureMemberFromCustomer(requestSignatureDTO.getEmail()));

        return this.digitalDocSignatureGateway.sendDocumentToSign(digitalDocSignature);
    }

    private String getBase64Document(final Document document) throws IOException {
        return new String(Base64.getEncoder().encode(IOUtils.toByteArray(document.getStream())));
    }

    /**
     * This method mount a valid signature as signature api required.
     *
     * @param email {@link String} used to get a customer emails
     * @return {@link DigitalDocSignatureMember}
     */
    private DigitalDocSignatureMember returnSignatureMemberFromCustomer(final String email) {
        final DigitalDocSignatureMember memberToSign = new DigitalDocSignatureMember();
        memberToSign.setSignatureType(SignatureRole.SIGN);
        memberToSign.setEmail(email);
        return memberToSign;
    }

    /**
     * @param documentId documentId to search the doc info
     * @return {@link com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureResponse}
     */
    public com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureResponse getDocumentInfo(final String documentId) {
        return this.digitalDocSignatureGateway.getSignedDocument(documentId);
    }

}
