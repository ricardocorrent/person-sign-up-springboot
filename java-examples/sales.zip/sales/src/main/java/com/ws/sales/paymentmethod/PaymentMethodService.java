package com.ws.sales.paymentmethod;

import java.util.UUID;

import javax.inject.Inject;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class PaymentMethodService extends AbstractService<PaymentMethod> {

    private final PaymentMethodDAO dao;

    @Inject
    public PaymentMethodService(final PaymentMethodDAO dao) {
        super(dao);
        this.dao = dao;
    }

    public Boolean paymentMethodIsActive(final UUID id) {
        final PaymentMethod paymentMethod = dao.getStatePaymentMethod(id);

        if (paymentMethod != null) {
            return paymentMethod.getActive();
        }

        return Boolean.TRUE;
    }

    
    /**
     * Returns the payment methods. If there are registers at PaymentMethodsPermission must filter
     * payment terms by permissions(Not implemented yet.) else returns the active ones.
     *
     * @param search
     * @return PagedList<PaymentMethod>
     */
    public PagedList<PaymentMethod> search(final PaymentMethodSearch search) {
        return dao.list(search);
    }
}
