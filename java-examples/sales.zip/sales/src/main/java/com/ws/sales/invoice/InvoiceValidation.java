package com.ws.sales.invoice;

import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.logicvalidation.DynamicValid;
import com.ws.commons.server.validation.logicvalidation.LogicValidator;
import com.ws.commons.server.validation.logicvalidation.builderror.ListBuilderLogicError;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.external.commondata.CommonDataGateway;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.user.UserGateway;
import com.ws.sales.invoicesituation.InvoiceSituation;
import com.ws.sales.invoicesituation.InvoiceSituationDAO;
import com.ws.sales.invoicetype.InvoiceType;
import com.ws.sales.invoicetype.InvoiceTypeDAO;
import com.ws.sales.invoicetypeitem.InvoiceTypeItem;
import com.ws.sales.invoicetypeitem.InvoiceTypeItemDAO;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 * This class represents the validator of business rules of Invoice.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Default
@BeanValidationIntegrated(Invoice.class)
public class InvoiceValidation extends LogicValidator<Invoice> {

    /**
     * Message to be used when a invoice was not informed.
     */
    private static final String THE_INVOICE_MUST_BE_INFORMED = "The invoice must be informed.";

    /**
     * Message to be used when a invoice item was not informed.
     */
    private static final String THE_INVOICE_ITEM_MUST_BE_INFORMED = "The invoice item must be informed.";

    /**
     * Injects InvoiceTypeDAO class for communication between layers of InvoiceValidation
     * and InvoiceTypeDAO.
     */
    private final InvoiceTypeDAO invoiceTypeDAO;

    /**
     * Injects InvoiceTypeItemDAO class for communication between layers of InvoiceValidation
     * and InvoiceTypeItemDAO.
     */
    private final InvoiceTypeItemDAO invoiceTypeItemDAO;

    /**
     * Injects InvoiceSituationDAO class for communication between layers of InvoiceValidation
     * and InvoiceSituationDAO.
     */
    private final InvoiceSituationDAO invoiceSituationDAO;

    /**
     * Injects PaymentTermDAO class for communication between layers of InvoiceValidation
     * and PaymentTermDAO.
     */
    private final PaymentTermDAO paymentTermDAO;

    /**
     * Injects SalesOrderDAO class for communication between layers of InvoiceValidation
     * and SalesOrderDAO.
     */
    private final SalesOrderDAO salesOrderDAO;

    /**
     * Injects UserGateway class for communication between layers of InvoiceValidation
     * and UserGateway.
     */
    private final UserGateway userGateway;

    /**
     * Injects ProductGateway class for communication between layers of InvoiceValidation
     * and ProductGateway.
     */
    private final ProductGateway productGateway;

    /**
     * Injects CustomerGateway class for communication between layers of InvoiceValidation
     * and CustomerGateway.
     */
    private final CustomerGateway customerGateway;

    /**
     * Injects CommonDataGateway class for communication between layers of InvoiceValidation
     * and CommonDataGateway.
     */
    private final CommonDataGateway commonDataGateway;

    /**
     * Injects AdministrationGateway class for communication between layers of InvoiceValidation
     * and AdministrationGateway.
     */
    private final AdministrationGateway administrationGateway;

    /**
     * Instantiates a new Invoice validation.
     *
     * @param invoiceTypeDAO        the invoice type dao
     * @param invoiceTypeItemDAO    the invoice type item dao
     * @param invoiceSituationDAO   the invoice situation dao
     * @param paymentTermDAO        the payment term dao
     * @param salesOrderDAO         the sales order dao
     * @param userGateway           the user gateway
     * @param productGateway        the product gateway
     * @param customerGateway       the customer gateway
     * @param commonDataGateway     the common data gateway
     * @param administrationGateway the administration gateway
     */
    @Inject
    public InvoiceValidation(InvoiceTypeDAO invoiceTypeDAO, InvoiceTypeItemDAO invoiceTypeItemDAO,
                             InvoiceSituationDAO invoiceSituationDAO, PaymentTermDAO paymentTermDAO, SalesOrderDAO salesOrderDAO,
                             UserGateway userGateway, ProductGateway productGateway, CustomerGateway customerGateway,
                             CommonDataGateway commonDataGateway, AdministrationGateway administrationGateway) {
        this.invoiceTypeDAO = invoiceTypeDAO;
        this.invoiceTypeItemDAO = invoiceTypeItemDAO;
        this.invoiceSituationDAO = invoiceSituationDAO;
        this.paymentTermDAO = paymentTermDAO;
        this.salesOrderDAO = salesOrderDAO;
        this.userGateway = userGateway;
        this.productGateway = productGateway;
        this.customerGateway = customerGateway;
        this.commonDataGateway = commonDataGateway;
        this.administrationGateway = administrationGateway;
    }

    /**
     * Method to validate all the business rules to insert a invoice.
     *
     * @param invoice to be validate for insert
     * @return the list builder logic error
     */
    @DynamicValid
    public ListBuilderLogicError validateInvoiceForInsert(final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        ListBuilderLogicError builder = new ListBuilderLogicError();

        validateIfBillingDateIsBeforeCurrentDate(builder, invoice);

        validateIfInvoiceItemsWasInformedForInvoice(builder, invoice);

        validateIfTotalIsPositiveForInvoice(builder, invoice);

        validateIfTotalIsConsistentForInvoice(builder, invoice);

        validateInvoiceItemsForInsert(builder, invoice);

        validateInvoiceRelationships(builder, invoice);

        validateInvoiceReplicatedFields(builder, invoice);

        return builder;
    }

    /**
     * Method to validate if billing date for invoice is before or equal the current date,
     * if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfBillingDateIsBeforeCurrentDate(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        if (invoice.getBillingDate() != null && invoice.getBillingDate().isAfter(LocalDate.now())) {
            builder.addError(new LogicError("billing date", "invoice.billingDateGreaterThanCurrentDate"));
        }
    }

    /**
     * Method to validate if invoice items was informed for invoice, if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfInvoiceItemsWasInformedForInvoice(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final List<InvoiceItem> invoiceItems = invoice.getInvoiceItems();

        if (invoiceItems == null || invoiceItems.isEmpty()) {
            builder.addError(new LogicError("invoice items", "invoice.invoiceItemWasNotInformed"));
        }
    }

    /**
     * Method do validate if total of invoice is less than zero.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfTotalIsPositiveForInvoice(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        BigDecimal totalValueInvoice = invoice.getTotal();

        if (totalValueInvoice != null && BigDecimal.ZERO.compareTo(totalValueInvoice) > 0) {
            builder.addError(new LogicError("total", "invoice.totalOfInvoiceMustBeGreaterTharZero"));
        }
    }

    /**
     * Method to validate if the total of invoice is the sum of total value of all invoice items,
     * if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfTotalIsConsistentForInvoice(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        BigDecimal totalValueInvoice = invoice.getTotal();

        BigDecimal valorTotalItem = invoice.getInvoiceItems()
                .stream()
                .filter(invoiceItem -> invoiceItem.getTotalValue() != null)
                .reduce(BigDecimal.ZERO,
                        (accumulator, invoiceItemTotal) ->
                                accumulator.add(invoiceItemTotal.getTotalValue()), BigDecimal::add);

        if (totalValueInvoice != null && totalValueInvoice.compareTo(valorTotalItem) != 0) {
            builder.addError(new LogicError("total", "invoice.totalValueItsDifferentOfSumOfItemsValues"));
        }
    }

    /**
     * Method to validate invoice items for insert.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateInvoiceItemsForInsert(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final List<InvoiceItem> invoiceItems = invoice.getInvoiceItems();

        for (InvoiceItem invoiceItem : invoiceItems) {

            validateIfTotalValueIsPositiveForInvoiceItem(builder, invoiceItem);

            validateIfUnitValueIsPositiveForInvoiceItem(builder, invoiceItem);

            validateIfQuantityIsPositiveForInvoiceItem(builder, invoiceItem);

            validateIfTotalValueIsConsistentForInvoiceItem(builder, invoiceItem);

            validateInvoiceItemRelationships(builder, invoiceItem);

            validateInvoiceItemReplicatedFields(builder, invoiceItem);
        }
    }

    /**
     * Method do validate if total value of invoice item is less than zero.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfTotalValueIsPositiveForInvoiceItem(final ListBuilderLogicError builder,
                                                              final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        BigDecimal totalValueInvoiceItem = invoiceItem.getTotalValue();

        if (totalValueInvoiceItem != null && BigDecimal.ZERO.compareTo(totalValueInvoiceItem) > 0) {
            builder.addError(new LogicError("total value", "invoice.totalValueOfInvoiceItemMustBeGreaterThanZero"));
        }
    }

    /**
     * Method do validate if unit value of invoice item is less than zero.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfUnitValueIsPositiveForInvoiceItem(final ListBuilderLogicError builder,
                                                             final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        BigDecimal unitValueInvoiceItem = invoiceItem.getUnitValue();

        if (unitValueInvoiceItem != null && BigDecimal.ZERO.compareTo(unitValueInvoiceItem) > 0) {
            builder.addError(new LogicError("unit value", "invoice.unitValueOfInvoiceItemMustBeGreaterThanZero"));
        }
    }

    /**
     * Method do validate if quantity of invoice item is less than zero.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfQuantityIsPositiveForInvoiceItem(final ListBuilderLogicError builder,
                                                            final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        BigDecimal quantityInvoiceItem = invoiceItem.getQuantity();

        if (quantityInvoiceItem != null && quantityInvoiceItem.compareTo(BigDecimal.ZERO) < 0) {
            builder.addError(new LogicError("quantity", "invoice.quantityOfInvoiceItemMustBeGreaterThanZero"));
        }
    }

    /**
     * Method to validate if total value its different from multiplication of unit value and quantity of item,
     * if yes a logic error will be added.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfTotalValueIsConsistentForInvoiceItem(final ListBuilderLogicError builder,
                                                                final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        if (invoiceItem.getUnitValue() != null && invoiceItem.getTotalValue() != null && invoiceItem.getQuantity() != null) {

            BigDecimal itemTotalValue = invoiceItem.getUnitValue().multiply(invoiceItem.getQuantity());

            if (itemTotalValue.compareTo(invoiceItem.getTotalValue()) != 0) {
                builder.addError(new LogicError("total value", "invoice.totalValueMustBeEqualUnitValueMultipliedByQuantity"));
            }
        }
    }

    /**
     * Method to validate the relationships for invoice item.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateInvoiceItemRelationships(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        validateIfInvoiceTypeItemWasInformedToInsertTheInvoiceItem(builder, invoiceItem);

        validateIfInvoiceTypeItemExists(builder, invoiceItem);

        validateIfSalesOrderExists(builder, invoiceItem);
    }

    /**
     * Method to validate invoice type item was informed for the invoice items.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfInvoiceTypeItemWasInformedToInsertTheInvoiceItem(final ListBuilderLogicError builder,
                                                                            final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        final InvoiceTypeItem invoiceTypeItem = invoiceItem.getInvoiceTypeItem();

        if (invoiceTypeItem == null || invoiceTypeItem.getId() == null) {
            builder.addError(new LogicError("invoice type item", "invoice.invoiceTypeItemMustBeInformedForInvoiceItem"));
        }
    }

    /**
     * Method to validate if invoice type item exists, this invoice situation should be exists in
     * the micro-service Sales, if not a logic error will be added.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfInvoiceTypeItemExists(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        final InvoiceTypeItem invoiceTypeItem = invoiceItem.getInvoiceTypeItem();

        if (invoiceTypeItem != null && invoiceTypeItem.getId() != null) {
            final Boolean invoiceTypeItemExists = invoiceTypeItemDAO.invoiceTypeItemExists(invoiceTypeItem.getId());

            if (!invoiceTypeItemExists) {
                builder.addError(new LogicError("invoice type item", "invoice.invoiceTypeItemNotFound"));
            }
        }
    }

    /**
     * Method to validate if sales order exists, this invoice situation should be exists in
     * the micro-service Sales, if not a logic error will be added.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfSalesOrderExists(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        final SalesOrder salesOrder = invoiceItem.getSalesOrder();

        if (salesOrder != null && salesOrder.getId() != null) {
            final Boolean salesOrderExists = salesOrderDAO.salesOrderExists(salesOrder.getId());

            if (!salesOrderExists) {
                builder.addError(new LogicError("sales order", "invoice.salesOrderNotFound"));
            }
        }
    }

    /**
     * Method to validate the replicated fields for invoice item.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateInvoiceItemReplicatedFields(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        validateIfMeasureUnitExists(builder, invoiceItem);

        validateIfProductExists(builder, invoiceItem);
    }

    /**
     * Method to validate if the Measure Unit exists, this measure unit should be exists in the micro-service
     * Administration, if not a logic error will be added.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfMeasureUnitExists(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        final InvoiceItemMeasureUnit invoiceItemMeasureUnit = invoiceItem.getInvoiceItemMeasureUnit();

        if (invoiceItemMeasureUnit != null && invoiceItemMeasureUnit.getReplicatedId() != null) {
            final Boolean measureUnitExists = administrationGateway.measureUnitExists(invoiceItemMeasureUnit.getReplicatedId());

            if (!measureUnitExists) {
                builder.addError(new LogicError("measure unit", "invoice.measureUnitNotFound"));
            }
        }
    }

    /**
     * Method to validate if the Product exists, this product should be exists in the micro-service Product,
     * if not a logic error will be added.
     *
     * @param builder     builder logic error.
     * @param invoiceItem invoice item to be validate.
     */
    private void validateIfProductExists(final ListBuilderLogicError builder, final InvoiceItem invoiceItem) {

        Objects.requireNonNull(invoiceItem, THE_INVOICE_ITEM_MUST_BE_INFORMED);

        final InvoiceItemProduct invoiceItemProduct = invoiceItem.getInvoiceItemProduct();

        if (invoiceItemProduct != null && invoiceItemProduct.getReplicatedId() != null) {
            final Boolean productExists = productGateway.productExists(invoiceItemProduct.getReplicatedId());

            if (!productExists) {
                builder.addError(new LogicError("product", "invoice.productNotFound"));
            }
        }
    }

    /**
     * Method to validate the relationships for invoice.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateInvoiceRelationships(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        validateIfInvoiceSituationWasInformedToInsertTheInvoice(builder, invoice);

        validateIfInvoiceSituationExists(builder, invoice);

        validateIfInvoiceTypeWasInformedToInsertTheInvoice(builder, invoice);

        validateIfInvoiceTypeExists(builder, invoice);

        validateIfPaymentTermExist(builder, invoice);
    }

    /**
     * Method to validate invoice situation was informed for the invoice.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfInvoiceSituationWasInformedToInsertTheInvoice(final ListBuilderLogicError builder,
                                                                         final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceSituation invoiceSituation = invoice.getInvoiceSituation();

        if (invoiceSituation == null || invoiceSituation.getId() == null) {
            builder.addError(new LogicError("invoice situation", "invoice.invoiceSituationMustBeInformedForInvoice"));
        }
    }

    /**
     * Method to validate if the Invoice exists, this invoice situation should be exists in
     * the micro-service Sales, if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfInvoiceSituationExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceSituation invoiceSituation = invoice.getInvoiceSituation();

        if (invoiceSituation != null && invoiceSituation.getId() != null) {
            final Boolean invoiceSituationExists = invoiceSituationDAO.invoiceSituationExists(invoiceSituation.getId());

            if (!invoiceSituationExists) {
                builder.addError(new LogicError("invoice situation", "invoice.invoiceSituationNotFound"));
            }
        }
    }

    /**
     * Method to validate invoice type was informed for invoice.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfInvoiceTypeWasInformedToInsertTheInvoice(final ListBuilderLogicError builder,
                                                                    final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceType invoiceType = invoice.getInvoiceType();

        if (invoiceType == null || invoiceType.getId() == null) {
            builder.addError(new LogicError("invoice type", "invoice.invoiceTypeMustBeInformedForInvoice"));
        }
    }

    /**
     * Method to validate if the Invoice Type exists, this invoice type should be exists in the micro-service
     * Sales, if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfInvoiceTypeExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceType invoiceType = invoice.getInvoiceType();

        if (invoiceType != null && invoiceType.getId() != null) {
            final Boolean invoiceTypeExists = invoiceTypeDAO.invoiceTypeExists(invoiceType.getId());

            if (!invoiceTypeExists) {
                builder.addError(new LogicError("invoice type", "invoice.invoiceTypeNotFound"));
            }
        }
    }

    /**
     * Method to validate if the Payment Term exists, this payment term should be exists in the micro-service
     * Sales, if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfPaymentTermExist(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final PaymentTerm paymentTerm = invoice.getPaymentTerm();

        if (paymentTerm != null && paymentTerm.getId() != null) {
            final boolean paymentTermExists = paymentTermDAO.paymentTermExists(paymentTerm.getId());

            if (!paymentTermExists) {
                builder.addError(new LogicError("payment term", "invoice.paymentTermNotFound"));
            }
        }
    }

    /**
     * Method to validate replicated fields for invoice.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateInvoiceReplicatedFields(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        validateIfCustomerExists(builder, invoice);

        validateIfLocationExists(builder, invoice);

        validateIfLocationIsTheSameOfCustomerLocation(builder, invoice);

        validateIfUserExists(builder, invoice);

        validateIfCurrencyExists(builder, invoice);
    }

    /**
     * Method to validate if the Customer exists, this customer should be exists in the micro-service Customer,
     * if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfCustomerExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceCustomer invoiceCustomer = invoice.getInvoiceCustomer();

        if (invoiceCustomer != null && invoiceCustomer.getReplicatedId() != null) {
            final Boolean customerExists = customerGateway.customerExists(invoiceCustomer.getReplicatedId());

            if (!customerExists) {
                builder.addError(new LogicError("customer", "invoice.customerNotFound"));
            }
        }
    }

    /**
     * Method to validate if the Location exists, this location should be exists in the micro-service Customer,
     * if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfLocationExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceLocation invoiceLocation = invoice.getInvoiceLocation();

        if (invoiceLocation != null && invoiceLocation.getReplicatedId() != null) {
            final Boolean locationExists = customerGateway.locationExists(invoiceLocation.getReplicatedId());

            if (!locationExists) {
                builder.addError(new LogicError("location", "invoice.locationNotFound"));
            }
        }
    }

    /**
     * Method to validate if the Location is same of the Customer Location, if not a logic error will be added,
     * if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfLocationIsTheSameOfCustomerLocation(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceLocation invoiceLocation = invoice.getInvoiceLocation();
        final InvoiceCustomer invoiceCustomer = invoice.getInvoiceCustomer();

        if (invoiceLocation != null && invoiceLocation.getReplicatedId() != null
                && invoiceCustomer != null && invoiceCustomer.getReplicatedId() != null) {
            final Boolean locationIsTheSameOfCustomerLocation = customerGateway.locationIsTheSameForTheCustomer(
                    invoiceLocation.getReplicatedId(), invoiceCustomer.getReplicatedId());

            if (!locationIsTheSameOfCustomerLocation) {
                builder.addError(new LogicError("location", "invoice.locationIsNotTheSameForTheCustomer"));
            }
        }
    }

    /**
     * Method to validate if the User exists, this user should be exists in the micro-service User, if not
     * a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfUserExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceUser invoiceUser = invoice.getInvoiceUser();

        if (invoiceUser != null && invoiceUser.getReplicatedId() != null) {
            final Boolean userExists = userGateway.userExists(invoiceUser.getReplicatedId());

            if (!userExists) {
                builder.addError(new LogicError("user", "invoice.userNotFound"));
            }
        }
    }

    /**
     * Method to validate if the Currency exists, this currency should be exists in the micro-service
     * Common-data or Administration, if not a logic error will be added.
     *
     * @param builder builder logic error.
     * @param invoice invoice to be validate.
     */
    private void validateIfCurrencyExists(final ListBuilderLogicError builder, final Invoice invoice) {

        Objects.requireNonNull(invoice, THE_INVOICE_MUST_BE_INFORMED);

        final InvoiceCurrency invoiceCurrency = invoice.getInvoiceCurrency();

        if (invoiceCurrency != null && invoiceCurrency.getReplicatedId() != null) {
            final boolean currencyExists = commonDataGateway.currencyExists(invoiceCurrency.getReplicatedId())
                    || administrationGateway.currencyExists(invoiceCurrency.getReplicatedId());

            if (!currencyExists) {
                builder.addError(new LogicError("currency", "invoice.currencyNotFound"));
            }
        }
    }
}