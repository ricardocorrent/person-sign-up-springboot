package com.ws.sales.invoicesituation;

import com.ws.commons.server.AbstractResource;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * This class represents the Resource of Invoice Situation, she received requisitions by REST protocol.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-28
 */
@Path("/invoice-situations")
public class InvoiceSituationResource extends AbstractResource<InvoiceSituation, InvoiceSituationSearch> {

    /**
     * Injects InvoiceSituationService class for communication between layers of InvoiceSituationResource
     * and InvoiceSituationService.
     */
    private final InvoiceSituationService invoiceSituationService;

    @Inject
    public InvoiceSituationResource(InvoiceSituationService invoiceSituationService) {
        this.invoiceSituationService = invoiceSituationService;
    }

    /**
     * Method to search a list of Invoice Situation by filter.
     *
     * @param invoiceSituationSearch represents the search for invoice situation
     * @return
     */
    @Override
    public Response search(InvoiceSituationSearch invoiceSituationSearch) {
        return Response.ok().entity(invoiceSituationService.search(invoiceSituationSearch)).build();
    }
}