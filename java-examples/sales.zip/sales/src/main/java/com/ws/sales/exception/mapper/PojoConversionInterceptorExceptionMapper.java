package com.ws.sales.exception.mapper;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ws.commons.interceptor.pojoconverter.exception.PojoConversionInterceptorException;
import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messagebundle.MessageExceptionBundle;


/**
 * 
 * @author william.santos
 * @since 2018-09-20
 * @version 1.0.0
 */
@Provider
public class PojoConversionInterceptorExceptionMapper implements ExceptionMapper<PojoConversionInterceptorException> {

    @Context
    private HttpServletRequest request;
    @Inject
    private MessageExceptionBundle bundle;

    private static final Logger LOGGER = LoggerFactory.getLogger(PojoConversionInterceptorExceptionMapper.class);

    /**
     * Map an exception to a {@link Response}. Returning
     * {@code null} results in a {@link Response.Status#NO_CONTENT}
     * response. Throwing a runtime exception results in a
     * {@link Response.Status#INTERNAL_SERVER_ERROR} response.
     *
     * @param exception the exception to map to a response.
     * @return a response mapped from the supplied exception.
     */
    @Override
    public Response toResponse(final PojoConversionInterceptorException exception) {
        PojoConversionInterceptorExceptionMapper.LOGGER.error(exception.getMessage(), exception);
        final ExceptionMessage message = this.bundle.getMessage(exception, this.request.getLocale());

        final int statusCode = processException(exception.getCause());

        return Response.status(statusCode)
                .type(MediaType.APPLICATION_JSON)
                .entity(message).build();
    }

    /**
     * Process the cause of the exception instead of the "generic" {@link PojoConversionInterceptorException}.
     * @param cause the cause of the exception.
     * @return the correct status code for the exception cause.
     */
    private int processException(Throwable cause) {
        /**
         * When json has more fields or they are not recognized (UnreconizedProperty belongs to JsonMappingException so, need to validate them first).
         */
        if (cause instanceof UnrecognizedPropertyException) {
            return HttpStatus.SC_UNPROCESSABLE_ENTITY;
        }

        /**
         * When json is invalid (missing comma or curly braces, for example) an exception is launched JacksonDatabinding throws JsonMappingException
         */
        if (cause instanceof JsonMappingException) {
            return HttpStatus.SC_BAD_REQUEST;
        }

        return HttpStatus.SC_UNPROCESSABLE_ENTITY;
    }
}
