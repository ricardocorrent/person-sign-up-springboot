package com.ws.sales.paymentterm;

import java.util.UUID;

public class PaymentTermSearchWithPriceList extends PaymentTermSearch {

    private UUID priceListId;
    private Boolean searchWithoutPermission;
    
    /**
     * Get of property {@link #priceListId}
     *
     * @return the priceListId
     */
    public final UUID getPriceListId() {
        return this.priceListId;
    }
    
    /**
     * Set of property {@link #priceListId}
     *
     * @param priceListId the priceListId
     */
    public final void setPriceListId(final UUID priceListId) {
        this.priceListId = priceListId;
    }
    
    /**
     * Get of property {@link #searchWithoutPermission}
     *
     * @return the searchWithoutPermission
     */
    public final Boolean getSearchWithoutPermission() {
        return this.searchWithoutPermission;
    }
    
    /**
     * Set of property {@link #searchWithoutPermission}
     *
     * @param searchWithoutPermission the searchWithoutPermission
     */
    public final void setSearchWithoutPermission(final Boolean searchWithoutPermission) {
        this.searchWithoutPermission = searchWithoutPermission;
    }
    
    
}
