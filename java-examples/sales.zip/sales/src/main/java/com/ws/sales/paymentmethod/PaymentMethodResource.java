package com.ws.sales.paymentmethod;

import com.ws.sales.util.SalesAbstractResource;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Path("/payment-methods")
public class PaymentMethodResource extends SalesAbstractResource<PaymentMethod, PaymentMethodSearch> {

    private final PaymentMethodService service;

    @Inject
    public PaymentMethodResource(PaymentMethodService service) {
        this.service = service;
    }

    /**
     * @param parameters as {@link PaymentMethodSearch}
     * @return {@link Response}
     * @see Response
     * @see PaymentMethodSearch
     */
    @Override
    @RequiresPermissions("sales:payment-methods:read")
    public Response search(final PaymentMethodSearch parameters) {
        return Response.ok().entity(service.search(parameters)).build();
    }

    @Override
    public Response delete(final UUID id) throws Exception {
        return Response.status(HttpStatus.SC_METHOD_NOT_ALLOWED).build();
    }
}
