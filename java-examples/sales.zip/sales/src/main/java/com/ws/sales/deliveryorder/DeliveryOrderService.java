package com.ws.sales.deliveryorder;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.order.SalesOrderService;

import javax.inject.Inject;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * @author Sergio Arantes
 * @author Maykon Rissi
 * @version v6.0.0 2018-08-13
 * @since v4.0.0
 */
public class DeliveryOrderService extends AbstractService<DeliveryOrder> {

    private final DeliveryOrderDAO deliveryOrderDAO;
    private final SalesOrderService salesOrderService;
    private final DeliveryOrderValidation deliveryOrderValidation;

    /**
     * @param deliveryOrderDAO        to perform delivery's database operation
     * @param deliveryOrderValidation to perform delivery's validations
     * @param salesOrderService       to perform update in the order's total value
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @Inject
    public DeliveryOrderService(final DeliveryOrderDAO deliveryOrderDAO, final SalesOrderService salesOrderService, final DeliveryOrderValidation deliveryOrderValidation) {
        super(deliveryOrderDAO);
        this.deliveryOrderDAO = deliveryOrderDAO;
        this.salesOrderService = salesOrderService;
        this.deliveryOrderValidation = deliveryOrderValidation;
    }

    /**
     * Performs the validation, then insert the delivery. If there isn't any error, it will update order's total
     *
     * @author Maykon Rissi
     * @see AbstractService#insert(BaseModel)
     * @since v6.0.0 2018-08-13
     */
    @Override
    public DeliveryOrder insert(final DeliveryOrder entity) throws Exception {
        this.doValidate(entity, EValidationType.INSERT);
        final DeliveryOrder orderCreated = super.insert(entity);
        this.salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
        return orderCreated;
    }

    /**
     * Performs the validation, then update the delivery. If there isn't any error, it will update order's total
     *
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v6.0.0 2018-08-13
     */
    @Override
    public void update(final DeliveryOrder entity) throws Exception {
        this.doValidate(entity, EValidationType.UPDATE);
        super.update(entity);
        this.salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
    }

    /**
     * Search the delivery using the orderId and the id. If it found one, it will remove
     *
     * @author Maykon Rissi
     * @see AbstractService#delete(UUID)
     * @since v6.0.0 2018-08-13
     */
    public void deleteDeliveryUsingOrder(final UUID orderId, final UUID id) throws Exception {
        final DeliveryOrder deliveryOrder = this.getDeliverySearchingByOrder(orderId, id);
        this.doValidate(deliveryOrder, EValidationType.DELETE);
        super.delete(id);
        salesOrderService.updateOrderTotalValue(deliveryOrder.getSalesOrder().getId());
    }

    /**
     * @param orderId to use fill the search
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    public PagedList<DeliveryOrder> findBySalesOrder(final UUID orderId) {
        final DeliveryOrderSearch search = this.doFillSearchWithOrderId(orderId, null);
        return this.deliveryOrderDAO.search(search);
    }

    /**
     * @param orderId to use fill the search
     * @return DeliveryOrderSearch to fill the query params
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private DeliveryOrderSearch doFillSearchWithOrderId(final UUID orderId, final UUID deliveryId) {
        final DeliveryOrderSearch deliveryOrderSearch = new DeliveryOrderSearch();
        deliveryOrderSearch.setId(deliveryId);
        deliveryOrderSearch.setOrderId(orderId);
        return deliveryOrderSearch;
    }

    /**
     * Validates and throw a list of {@link com.ws.commons.server.validation.exception.LogicError} if there is any errors
     * It will perform the bean validation first and throw any error. If the entity is ok, it will do the logic validations
     *
     * @param entity to validate
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doValidate(final DeliveryOrder entity, EValidationType validationType) {
        this.deliveryOrderValidation.validateByBeanValidation(entity, null);
        this.deliveryOrderValidation.throwFoundErrors();
        this.deliveryOrderValidation.validate(entity, validationType);
        this.deliveryOrderValidation.throwFoundErrors();
    }

    /**
     * Get the delivery from the paged list, if exists
     *
     * @param deliveryOrderPagedList to get the entity from the list
     * @return {@link DeliveryOrder} if it exists in the pagedList, or it will throw a {@link RegisterNotFoundException} if not
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private DeliveryOrder getDeliveryFromPagedList(final PagedList<DeliveryOrder> deliveryOrderPagedList) {
        return Optional.ofNullable(deliveryOrderPagedList)
                .map(PagedList::getItems)
                .map(Collection::stream).orElse(Stream.empty())
                .findFirst()
                .orElseThrow(RegisterNotFoundException::new);
    }

    /**
     * Search for the delivery using both the id from order and from delivery
     *
     * @param orderId to fill the search
     * @param id      to fill the search
     * @return {@link DeliveryOrder} found with the filters
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public DeliveryOrder getDeliverySearchingByOrder(final UUID orderId, final UUID id) {
        final DeliveryOrderSearch search = this.doFillSearchWithOrderId(orderId, id);
        final PagedList<DeliveryOrder> deliveryOrderPagedList = this.deliveryOrderDAO.search(search);
        return this.getDeliveryFromPagedList(deliveryOrderPagedList);
    }
}
