package com.ws.sales.customerorderssummary.servicepurchased;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;
import io.ebean.RawSql;
import io.ebean.RawSqlBuilder;

import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-21
 */
public class ServicePurchasedHistoryDAO extends AbstractDAO<ServicePurchasedHistoryView> {

    private static final String BASE_QUERY =
            "select " +
                    "customer_id, " +
                    "sales_order_id, " +
                    "service_id, " +
                    "service_description, " +
                    "updated_at, " +
                    "ordered_at, " +
                    "sales_price, " +
                    "total_quantity " +
                    "from " +
                    "service_purchased_history_view " +
                    "where " +
                    "customer_id = :customerId " +
                    "and " +
                    "service_id = :serviceId";

    /**
     * This method list the details from a service using a base sql to find it in a service view
     *
     * @param customerId {@link UUID}
     * @param serviceId {@link UUID}
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return a list of {@link ServicePurchasedHistoryView}
     */
    public PagedList<ServicePurchasedHistoryView> list(final UUID customerId,
                                                       final UUID serviceId,
                                                       final HttpRestQueryAdapter httpRestQueryAdapter) {
        final Query<ServicePurchasedHistoryView> query = ebeanServer.find(ServicePurchasedHistoryView.class);
        final RawSql rawSql = RawSqlBuilder.parse(BASE_QUERY).create();
        query.setRawSql(rawSql)
                .setParameter("customerId", customerId)
                .setParameter("serviceId", serviceId);

        return getPagedList(query, httpRestQueryAdapter);
    }

    /**
     * Returns the entity class declared in this class.
     *
     * @return The entity class declared as parameterized type at this class.
     */
    @Override
    public Class<ServicePurchasedHistoryView> getEntityClass() {
        return ServicePurchasedHistoryView.class;
    }

}
