package com.ws.sales.order.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * @author marcos.andrade
 * @since 08/12/2017
 */
public class OrderSummaryDTO extends BaseDTO implements DefaultPojoConverter {

    private String orderNumber;
    private BigDecimal netValue;
    private BigDecimal serviceTotalValue;
    private BigDecimal productTotalValue;
    private UUID signatureId;
    private OffsetDateTime orderedAt;
    private OffsetDateTime insertedAt;
    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate createDate;

    private List<OrderSummaryItemsDTO> items;

    private List<OrderSummaryServicesDTO> services;

    public List<OrderSummaryServicesDTO> getServices() {
        return services;
    }

    public void setServices(final List<OrderSummaryServicesDTO> services) {
        this.services = services;
    }

    public List<OrderSummaryItemsDTO> getItems() {
        return items;
    }

    public void setItems(final List<OrderSummaryItemsDTO> items) {
        this.items = items;
    }

    public BigDecimal getNetValue() {
        return netValue;
    }

    public void setNetValue(final BigDecimal netValue) {
        this.netValue = netValue;
    }

    public BigDecimal getServiceTotalValue() {
        return serviceTotalValue;
    }

    public void setServiceTotalValue(final BigDecimal serviceTotalValue) {
        this.serviceTotalValue = serviceTotalValue;
    }

    public BigDecimal getProductTotalValue() {
        return productTotalValue;
    }

    public void setProductTotalValue(final BigDecimal productTotalValue) {
        this.productTotalValue = productTotalValue;
    }

    public UUID getSignatureId() {
        return signatureId;
    }

    public void setSignatureId(UUID signatureId) {
        this.signatureId = signatureId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * Gets orderedAt
     *
     * @return value of orderedAt
     */
    public OffsetDateTime getOrderedAt() {
        return orderedAt;
    }

    /**
     * Sets orderedAt
     *
     * @param orderedAt the orderedAt
     */
    public void setOrderedAt(OffsetDateTime orderedAt) {
        this.orderedAt = orderedAt;
    }

    /**
     * Gets insertedAt
     *
     * @return value of insertedAt
     */
    public OffsetDateTime getInsertedAt() {
        return insertedAt;
    }

    /**
     * Sets insertedAt
     *
     * @param insertedAt the insertedAt
     */
    public void setInsertedAt(OffsetDateTime insertedAt) {
        this.insertedAt = insertedAt;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(final LocalDate createDate) {
        this.createDate = createDate;
    }
}
