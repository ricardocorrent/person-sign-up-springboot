package com.ws.sales.documents.mapper;

import java.util.List;

/**
 * @author Dante Basso <dante.basso@wwsim.com.br>
 * @version 1.0.0
 * @since 2019-03-18
 */
public class SalesOrderMapper {

    private HeaderMapper header;

    private List<ProductMapper> products;

    private List<ServiceMapper> services;

    private SummaryMapper summary;

    public HeaderMapper getHeader() {
        return header;
    }

    public void setHeader(HeaderMapper header) {
        this.header = header;
    }

    public List<ProductMapper> getProducts() {
        return products;
    }

    public void setProducts(List<ProductMapper> products) {
        this.products = products;
    }

    public List<ServiceMapper> getServices() {
        return services;
    }

    public void setServices(List<ServiceMapper> services) {
        this.services = services;
    }

    public SummaryMapper getSummary() {
        return summary;
    }

    public void setSummary(SummaryMapper summary) {
        this.summary = summary;
    }
}
