package com.ws.sales.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Objects;

import com.ws.commons.message.EDefaultMessage;

/**
 * Specific format for some values
 * 
 * @author william.santos
 * @since 2018-08-21
 * @version 1.0.0
 */
public final class Formatter {

    private Formatter() {
    }

    /**
     * Format decimal to Brasil money, use only two decimals. Example of use:
     * 
     * <pre>
     *          final BigDecimal decimal = BigDecimal.TEN;
     *          final String formatted = Formatter.brazilianMoney(decimal);
     *          formatted == "R$ 10,00"
     * </pre>
     * 
     * @param decimal
     * @return
     */
    public static String brazilianMoney(final BigDecimal decimal) {
        Objects.requireNonNull(decimal, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("decimal"));
        final DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator(',');
        formatSymbols.setGroupingSeparator('.');
        final DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(Locale.US);
        decimalFormat.setDecimalFormatSymbols(formatSymbols);
        decimalFormat.applyPattern("R$ ###,###,###,##0.00");
        return decimalFormat.format(decimal);
    }

    /**
     * Format date to Brasil pattern. Example of use:
     * 
     * <pre>
     *          final LocalDate now = LocalDate.now();
     *          final String formatted = Formatter.brazilianDate(now);
     *          formatted == "18/01/2001"
     * </pre>
     * 
     * @param decimal
     * @return
     */
    public static String brazilianDate(final LocalDate date) {
        Objects.requireNonNull(date, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("date"));
        final DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return date.format(format);
    }
    
    /**
     * Format decimal to Brasil amount, use only two decimals. Example of use:
     * 
     * <pre>
     *          final BigDecimal decimal = BigDecimal.TEN;
     *          final String formatted = Formatter.brazilianAmount(decimal);
     *          formatted == "10,00"
     * </pre>
     * 
     * @param decimal
     * @return
     */
    public static String brazilianAmount(final BigDecimal value) {
        Objects.requireNonNull(value, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("decimal"));
        final DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator(',');
        formatSymbols.setGroupingSeparator('.');
        final DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(Locale.US);
        decimalFormat.setDecimalFormatSymbols(formatSymbols);
        decimalFormat.applyPattern("###,###,###,###,##0.00");
        return decimalFormat.format(value);
    }
    
}
