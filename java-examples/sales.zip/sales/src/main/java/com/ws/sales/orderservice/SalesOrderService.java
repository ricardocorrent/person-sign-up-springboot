package com.ws.sales.orderservice;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.sales.order.SalesOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
@Entity
@PreventRecycling
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SalesOrderService extends PhysicalDeleteBaseEntity implements Serializable, DefaultPojoConverter {

    @NotNull
    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    @PojoColumnFilter(value = { "id" })
    private SalesOrder salesOrder;

    @NotNull
    @PojoColumnMapper(target = "service.id")
    private UUID serviceId;

    @NotEmpty
    @Size(max = 255)
    @PojoColumnMapper(target = "service.description")
    private String serviceDescription;

    @Size(max = 40)
    @PojoColumnMapper(target = "service.code")
    private String serviceCode;

    @Enumerated(value = EnumType.STRING)
    @PojoColumnMapper(source = "recurrenceType", target = "recurrenceType")
    private ERecurrenceType recurrenceType;

    @NotNull
    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal originalPrice;

    @NotNull
    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal salesPrice;

    @NotNull
    @DecimalMin(value = "0.000001", message = "quantity.validation.min.value.greater.than.zero")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal quantity;

    @NotNull
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal repetitions;

    @NotNull
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal totalQuantity;

    @NotNull
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal totalValue;

    @PojoColumnMapper(target = "discountValue")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal discount;

    @DecimalMin("0")
    @DecimalMax("100")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal discountPercentage;

    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal increaseValue;

    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal increasePercentage;

    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    public UUID getServiceId() {
        return serviceId;
    }

    public void setServiceId(final UUID serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceDescription() {
        return serviceDescription;
    }

    public void setServiceDescription(final String serviceDescription) {
        this.serviceDescription = serviceDescription;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(final String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public ERecurrenceType getRecurrenceType() {
        return recurrenceType;
    }

    public void setRecurrenceType(final ERecurrenceType recurrenceType) {
        this.recurrenceType =  recurrenceType;
    }

    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(final BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(final BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(final BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getRepetitions() {
        return repetitions;
    }

    public void setRepetitions(final BigDecimal repetitions) {
        this.repetitions = repetitions;
    }

    public BigDecimal getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(final BigDecimal totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public BigDecimal getTotalValue() {
        return totalValue;
    }

    public void setTotalValue(final BigDecimal totalValue) {
        this.totalValue = totalValue;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(final BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(final BigDecimal discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public BigDecimal getIncreaseValue() {
        return increaseValue;
    }

    public void setIncreaseValue(final BigDecimal increaseValue) {
        this.increaseValue = increaseValue;
    }

    public BigDecimal getIncreasePercentage() {
        return increasePercentage;
    }

    public void setIncreasePercentage(final BigDecimal increasePercentage) {
        this.increasePercentage = increasePercentage;
    }

}
