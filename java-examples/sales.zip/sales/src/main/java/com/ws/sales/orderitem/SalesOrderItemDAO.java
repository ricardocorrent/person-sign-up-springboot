package com.ws.sales.orderitem;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
public class SalesOrderItemDAO extends AbstractDAO<SalesOrderItem> {
    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class<SalesOrderItem> getEntityClass() {
        return SalesOrderItem.class;
    }

    /**
     * Returns a list of orders items.
     *
     * @param search
     * @return PagedList<SalesOrder>
     */
    public PagedList<SalesOrderItem> list(final SalesOrderItemSearch search) {

        final Query<SalesOrderItem> query = find();

        final ExpressionList<SalesOrderItem> where = query.where();

        if (!StringUtils.isEmpty(search.getOrderNumber())) {
            where.icontains("salesOrder.orderNumber", search.getOrderNumber());
        }

        if (search.getSalesOrderId() != null) {
            where.in("salesOrder.id", search.getSalesOrderId());
        }

        if (search.getProductId() != null) {
            where.in("productId", search.getProductId());
        }

        if (search.getPriceListId() != null) {
            where.in("priceListId", search.getPriceListId());
        }

        return getPagedList(query, search);
    }

    public PagedList<SalesOrderItem> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        Objects.requireNonNull(restQueryAdapter, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("httpRestQueryAdapter"));

        Query<SalesOrderItem> query = this.find();
        ExpressionList<SalesOrderItem> where = query.where();
        where.eq("salesOrder.id", orderId);

        return this.getPagedList(query, restQueryAdapter);
    }
}
