package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.ws.sales.paymentterm.PaymentTerm;

import java.io.IOException;

/**
 * This class represents payment term serializer for invoice, she will serialize just the
 * fields id and description from payment term because its just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class InvoicePaymentTermSerializer extends StdSerializer<PaymentTerm> {

    /**
     * Instantiates a new invoice payment term serializer.
     */
    public InvoicePaymentTermSerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice payment term serializer.
     *
     * @param t the t
     */
    protected InvoicePaymentTermSerializer(Class<PaymentTerm> t) {
        super(t);
    }

    /**
     * This method override the serialization of PaymentTerm for Invoice class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(PaymentTerm value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setId(value.getId());
        paymentTerm.setDescription(value.getDescription());
        gen.writeObject(paymentTerm);
    }
}