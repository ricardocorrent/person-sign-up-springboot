package com.ws.sales.external.integrationhub.documentsign.get;

/**
 * Entity to represents de internal contract
 * to get a document from the gateway
 *
 * @since 1.0.0 2019-05-15
 *
 * @author Ricardo Corrent
 */
public class DigitalDocSignatureDocument {

    private String id;

    private String name;

    private Boolean rejectable;

    private String createdAt;

    private String updatedAt;

    private String publishedAt;

    private String signatureId;

    private String fileBase64;

    private String fileSignedBase64;

    private String fileUrl;

    private String fileSignedUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getRejectable() {
        return rejectable;
    }

    public void setRejectable(Boolean rejectable) {
        this.rejectable = rejectable;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(String publishedAt) {
        this.publishedAt = publishedAt;
    }

    public String getSignatureId() {
        return signatureId;
    }

    public void setSignatureId(String signatureId) {
        this.signatureId = signatureId;
    }

    public String getFileBase64() {
        return fileBase64;
    }

    public void setFileBase64(String fileBase64) {
        this.fileBase64 = fileBase64;
    }

    public String getFileSignedBase64() {
        return fileSignedBase64;
    }

    public void setFileSignedBase64(String fileSignedBase64) {
        this.fileSignedBase64 = fileSignedBase64;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getFileSignedUrl() {
        return fileSignedUrl;
    }

    public void setFileSignedUrl(String fileSignedUrl) {
        this.fileSignedUrl = fileSignedUrl;
    }
}
