package com.ws.sales;

import com.ws.commons.server.accesscontrol.RestAuthorizationRealm;
import com.ws.sales.external.user.UserGateway;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.subject.PrincipalCollection;

import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.CDI;

/**
 * Class created with the purpose to customize API call to user service and load permissions
 *
 * @author ivan.reffatti
 * @since 2017/04/20
 */
public class CustomRestAuthorizationRealm extends RestAuthorizationRealm {

    @Override
    protected SimpleAuthorizationInfo getSimpleAuthorizationInfo() {
        final UserGateway userGateway = CDI.current().select(UserGateway.class).get();
        final SimpleAuthorizationInfo simpleAuthorizationInfo = userGateway.getPermissions();
        CDI.current().destroy(userGateway);
        return simpleAuthorizationInfo;
    }

    @Override
    protected Object getAuthorizationCacheKey(final PrincipalCollection principals) {
        return "shiro_redis_permissions:" + getSessionID();
    }

}
