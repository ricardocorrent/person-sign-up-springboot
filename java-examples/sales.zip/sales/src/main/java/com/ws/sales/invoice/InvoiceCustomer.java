package com.ws.sales.invoice;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.UUID;

/**
 * This class represents the entity Invoice Customer.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
@Entity
public class InvoiceCustomer extends SoftDeleteBaseEntity implements Serializable {

    /**
     * This field represents the replicated id for the InvoiceCustomer. It represents the id from User.
     */
    @NotNull
    private UUID replicatedId;

    /**
     * This field represents the name for the InvoiceCustomer.
     */
    @Size(max = 255)
    private String name;

    /**
     * This field represents the relationship of InvoiceCustomer with Invoice.
     */
    @OneToOne
    @JoinColumn(name = "invoice_id")
    @JsonIgnore
    private Invoice invoice;

    /**
     * Gets replicated id.
     *
     * @return the replicated id
     */
    public UUID getReplicatedId() {
        return replicatedId;
    }

    /**
     * Sets replicated id.
     *
     * @param replicatedId the replicated id
     */
    public void setReplicatedId(UUID replicatedId) {
        this.replicatedId = replicatedId;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets invoice.
     *
     * @return the invoice
     */
    public Invoice getInvoice() {
        return invoice;
    }

    /**
     * Sets invoice.
     *
     * @param invoice the invoice
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
