package com.ws.sales.orderparameter;

import com.ws.commons.server.pagination.PaginationSearch;

import javax.validation.constraints.NotNull;

/**
 * The class OrderParameterSearch its a filter class to search a order parameter, here the user can put
 * the filters to search a order parameter as expected.
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-23
 */
public class OrderParameterSearch extends PaginationSearch {

    /**
     * This field is used to filter a order parameter by key.
     */
    @NotNull
    private String key;

    /**
     * This field is used to filter a order parameter by value type.
     */
    @NotNull
    private String valueType;

    /**
     * This field is used to filter a order parameter by value.
     */
    @NotNull
    private String value;

    /**
     * This field is used to filter a order parameter by minimum value.
     */
    private String minValue;

    /**
     * This field is used to filter a order parameter by maximum value.
     */
    private String maxValue;

    /**
     * This field is used to filter a order parameter by note.
     */
    private String note;

    /**
     * This field is used to filter a order parameter by general search.
     */
    private String generalSearch;

    /**
     * Gets key.
     *
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets key.
     *
     * @param key the key
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets valueType.
     *
     * @return the valueType
     */
    public String getValueType() {
        return valueType;
    }

    /**
     * Sets valueType.
     *
     * @param valueType the valueType
     */
    public void setValueType(String valueType) {
        this.valueType = valueType;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets minValue.
     *
     * @return the minValue
     */
    public String getMinValue() {
        return minValue;
    }

    /**
     * Sets minValue.
     *
     * @param minValue the minValue
     */
    public void setMinValue(String minValue) {
        this.minValue = minValue;
    }

    /**
     * Gets maxValue.
     *
     * @return the maxValue
     */
    public String getMaxValue() {
        return maxValue;
    }

    /**
     * Sets maxValue.
     *
     * @param maxValue the maxValue
     */
    public void setMaxValue(String maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * Gets note.
     *
     * @return the note
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets note.
     *
     * @param note the note
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * Gets generalSearch.
     *
     * @return the generalSearch
     */
    public String getGeneralSearch() {
        return generalSearch;
    }

    /**
     * Sets generalSearch.
     *
     * @param generalSearch the generalSearch
     */
    public void setGeneralSearch(String generalSearch) {
        this.generalSearch = generalSearch;
    }
}
