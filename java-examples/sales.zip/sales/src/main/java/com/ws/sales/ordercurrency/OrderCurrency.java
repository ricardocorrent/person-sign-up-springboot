package com.ws.sales.ordercurrency;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.orderitem.SalesOrderItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * @author Ademar Junior <ademar.junior@wssim.com.br>
 * @since v1.4.0 2016-12-20
 */
@Entity
@PreventRecycling
public class OrderCurrency extends PhysicalDeleteBaseEntity implements Serializable, DefaultPojoConverter {

    @PojoColumnMapper(target = "currency.id")
    private UUID currencyId;

    @Size(max = 255)
    @PojoColumnMapper(target = "currency.description")
    private String currencyDescription;

    @PojoColumnMapper(target = "currencyQuotation.id")
    private UUID currencyQuotationId;

    @Digits(integer = 12, fraction = 6, message = "validation.value.greater.than.allowed")
    @DecimalMin(value = "0.000000", message = "validation.min.value.greater.than.or.equal.to.zero")
    @Column(precision = 18, scale = 6)
    @PojoColumnMapper(target = "currencyQuotation.value")
    private BigDecimal currencyQuotationValue;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @PojoColumnMapper(target = "currencyQuotation.date")
    private LocalDate currencyQuotationDate;

    @Column(precision = 18, scale = 6)
    @PojoColumnMapper(target = "value")
    private BigDecimal orderItemValue;

    @OneToOne()
    @JoinColumn(name = "sales_order_item_id", referencedColumnName = "id")
    @JsonBackReference(Constants.FIELD_SALES_ORDER_ITEM)
    private SalesOrderItem salesOrderItem;

    @OneToOne()
    @JoinColumn(name = "sales_order_id", referencedColumnName = "id")
    @JsonBackReference()
    private SalesOrder salesOrder;

    /**
     * Method getter
     *
     * @return java.util.UUID
     */
    public UUID getCurrencyId() {
        return currencyId;
    }

    /**
     * Method setter
     *
     * @param currencyId
     */
    public void setCurrencyId(final UUID currencyId) {
        this.currencyId = currencyId;
    }

    /**
     * Method getter
     *
     * @return java.lang.String
     */
    public String getCurrencyDescription() {
        return currencyDescription;
    }

    /**
     * Method setter
     *
     * @param currencyDescription
     */
    public void setCurrencyDescription(final String currencyDescription) {
        this.currencyDescription = currencyDescription;
    }

    /**
     * Method getter
     *
     * @return java.util.UUID
     */
    public UUID getCurrencyQuotationId() {
        return currencyQuotationId;
    }

    /**
     * Method setter
     *
     * @param currencyQuotationId
     */
    public void setCurrencyQuotationId(final UUID currencyQuotationId) {
        this.currencyQuotationId = currencyQuotationId;
    }

    /**
     * Method getter
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getCurrencyQuotationValue() {
        return currencyQuotationValue;
    }

    /**
     * Method setter
     *
     * @param currencyQuotationValue
     */
    public void setCurrencyQuotationValue(final BigDecimal currencyQuotationValue) {
        this.currencyQuotationValue = currencyQuotationValue;
    }

    /**
     * Method getter
     *
     * @return java.time.OffsetDateTime
     */
    public LocalDate getCurrencyQuotationDate() {
        return currencyQuotationDate;
    }

    /**
     * Method setter
     *
     * @param currencyQuotationDate
     */
    public void setCurrencyQuotationDate(final LocalDate currencyQuotationDate) {
        this.currencyQuotationDate = currencyQuotationDate;
    }

    /**
     * Method getter
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getOrderItemValue() {
        return orderItemValue;
    }

    /**
     * Method setter
     *
     * @param orderItemValue
     */
    public void setOrderItemValue(final BigDecimal orderItemValue) {
        this.orderItemValue = orderItemValue;
    }

    /**
     * Method getter
     *
     * @return SalesOrderItem
     */
    public SalesOrderItem getSalesOrderItem() {
        return salesOrderItem;
    }

    /**
     * Method setter
     *
     * @param salesOrderItem
     */
    public void setSalesOrderItem(final SalesOrderItem salesOrderItem) {
        this.salesOrderItem = salesOrderItem;
    }

    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }
}
