package com.ws.sales.orderinstalment;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.validator.AbstractObjectValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
@Default
public class SalesOrderInstalmentValidator extends AbstractEntityValidator<SalesOrderInstalment> {

    private static final String DUE_DATE_FIELD = "dueDate";
    private final SalesOrderInstalmentDAO salesOrderInstalmentDAO;
    private final OrderParameterDAO orderParameterDAO;
    private final SalesOrderValidator salesOrderValidator;
    private final SalesOrderDAO salesOrderDAO;
    private final Logger logger = LoggerFactory.getLogger(SalesOrderInstalmentValidator.class);

    @Inject
    public SalesOrderInstalmentValidator(final SalesOrderInstalmentDAO salesOrderInstalmentDAO,
                                         final OrderParameterDAO orderParameterDAO,
                                         final SalesOrderValidator salesOrderValidator,
                                         final SalesOrderDAO salesOrderDAO) {
        this.salesOrderInstalmentDAO = salesOrderInstalmentDAO;
        this.orderParameterDAO = orderParameterDAO;
        this.salesOrderValidator = salesOrderValidator;
        this.salesOrderDAO = salesOrderDAO;
    }

    /**
     * validate if the instalment date is before the order's creation
     *
     * @param entity
     * @author Maykon Rissi
     */
    public void doValidateInstalmentDateBeforeOrder(final SalesOrderInstalment entity,
                                                    final SalesOrder salesOrder) {
        if (entity != null
                && entity.getDueDate() != null
                && salesOrder != null) {
            final LocalDate localDateOrderCreatedAt = salesOrder.getCreatedAt().toLocalDate();
            if (localDateOrderCreatedAt.isAfter(entity.getDueDate())) {
                addError(new LogicError(DUE_DATE_FIELD, "orderInstalment.dateLowerThanOrder"), entity);
            }
        }
    }

    /**
     * validate if the instalment date is smaller than the date from next instalment
     * If is the first instalment, it cant be before the order creation date
     *
     * @param entity
     * @author Maykon Rissi
     */
    public void doValidateDateLower(final SalesOrderInstalment entity) {

        if (entity != null && entity.getNumber() != null && entity.getSalesOrder() != null) {
            final SalesOrderInstalmentSearch search = new SalesOrderInstalmentSearch();
            search.setOrderId(entity.getSalesOrder().getId());
            search.setNumber(entity.getNumber() - 1);
            final List<SalesOrderInstalment> instalmentLower = salesOrderInstalmentDAO.search(search).getItems();

            if (!instalmentLower.isEmpty() && (entity.getDueDate().isBefore(instalmentLower.get(0).getDueDate())
                    || entity.getDueDate().isEqual(instalmentLower.get(0).getDueDate()))) {
                addError(new LogicError(DUE_DATE_FIELD, "orderInstalment.dateLowerThanLastInstalment"), entity);
            }
        }
    }

    /**
     * validate if the instalment date is bigger than the date from next instalment
     *
     * @param entity
     * @author Maykon Rissi
     */
    public void doValidateDateHigher(final SalesOrderInstalment entity) {

        if (entity != null && entity.getNumber() != null && entity.getDueDate() != null) {
            final SalesOrderInstalmentSearch search = new SalesOrderInstalmentSearch();
            search.setOrderId(entity.getSalesOrder().getId());
            search.setNumber(entity.getNumber() + 1);
            final List<SalesOrderInstalment> instalmentHigher = salesOrderInstalmentDAO.search(search).getItems();

            if (!instalmentHigher.isEmpty() && (entity.getDueDate().isAfter(instalmentHigher.get(0).getDueDate())
                    || entity.getDueDate().isEqual(instalmentHigher.get(0).getDueDate()))) {
                addError(new LogicError(DUE_DATE_FIELD, "orderInstalment.dateHigherThanNextInstalment"), entity);
            }
        }
    }

    /**
     * validate if the instalment exists and then return it
     *
     * @param entity
     * @author Maykon Rissi
     */
    public SalesOrderInstalment getInstalmentAndValidate(final SalesOrderInstalment entity) {
        SalesOrderInstalment instalment = entity;
        if (entity.getId() != null) {
            try {
                instalment = salesOrderInstalmentDAO.findById(entity.getId());
            } catch (RegisterNotFoundException ex) {
                logger.error("Error loading the entity", ex);
                return null;
            }
        }
        entity.setNumber(instalment.getNumber());
        return entity;
    }

    /**
     * Validate if the value from instalment is bigger or equal to order's value
     *
     * @param entity
     * @author Maykon Rissi
     */
    public void doValidateIfValueIsDifferentThanOrderAndIsSingleInstalment(final SalesOrderInstalment entity,
                                                                           final SalesOrder salesOrder) {
        if (salesOrder != null
                && salesOrder.getNetValue() != null
                && entity != null
                && entity.getValue() != null) {
            final SalesOrderInstalmentSearch search = new SalesOrderInstalmentSearch();
            search.setOrderId(salesOrder.getId());
            final List<SalesOrderInstalment> instalments = this.salesOrderInstalmentDAO.search(search).getItems();

            if (!instalments.isEmpty()) {
                if (instalments.size() == 1) {
                    if (entity.getValue().compareTo(salesOrder.getNetValue()) != 0) {
                        addError(new LogicError("value", "orderInstalment.instalmentsValueDifferentThanOrder"), entity);
                    }
                } else {
                    doValidateIfValueIsBiggerOrEqualThanOrderValue(entity, salesOrder);
                }
            }
        }
    }

    /**
     * Validate if the value from instalment is bigger or equal to order's value
     *
     * @param entity
     * @author Maykon Rissi
     */
    private void doValidateIfValueIsBiggerOrEqualThanOrderValue(final SalesOrderInstalment entity,
                                                                final SalesOrder salesOrder) {
        if (salesOrder != null
                && salesOrder.getNetValue() != null
                && entity != null
                && entity.getValue() != null
                && entity.getValue().compareTo(salesOrder.getNetValue()) >= 0) {
            addError(new LogicError("value", "orderInstalment.valueWillGenerateNegativeInstalments"), entity);
        }
    }

    /**
     * Validate if the plugin for instalments is active to do operations
     *
     * @param entity
     * @author Maykon Rissi
     */
    private void doValidateConfigurationForInstalmentIsEnabled(final SalesOrderInstalment entity) {
        final Boolean isOrderInstalmentEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_ENABLE_ORDER_INSTALMENT).getValue());
        if (!isOrderInstalmentEnabled) {
            this.addError(new LogicError(Constants.FIELD_ORDER_INSTALMENT, "orderInstalment.maximumNumberOfInstalments"), entity);
        }
    }

    /**
     * Validate if order exists and then return it for further purposes
     *
     * @param entity
     * @author Maykon Rissi
     */
    private SalesOrder doValidateOrderAndReturn(final SalesOrderInstalment entity) {
        if (entity != null && entity.getSalesOrder().getId() != null) {
            try {
                final SalesOrder salesOrder = this.salesOrderDAO.findById(entity.getSalesOrder().getId());
                if (!salesOrder.getDraft()) {
                    this.addError(new LogicError("orderId", "order.finalized"), entity);
                }
                return salesOrder;
            } catch (final RegisterNotFoundException ex) {
                logger.error("Error loading the entity", ex);
                this.addError(new LogicError("orderId", "order.order.notFound"), entity);
            }
        }
        return null;
    }

    /**
     * @author Maykon Rissi
     * @see AbstractObjectValidator#addError(LogicError, Object)
     * @since v6.0.0 2018-08-17
     */
    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        Optional.ofNullable(logicError).ifPresent(error -> super.addError(error, entity));
    }

    @Override
    protected void validate(final SalesOrderInstalment entity,
                            final IValidationFilter... filter) {
        final SalesOrder salesOrder = this.doValidateOrderAndReturn(entity);
        final SalesOrderInstalment instalment = getInstalmentAndValidate(entity);
        this.addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE), entity);
        doValidateInstalmentDateBeforeOrder(instalment, salesOrder);
        doValidateDateLower(instalment);
        doValidateDateHigher(instalment);
        doValidateIfValueIsDifferentThanOrderAndIsSingleInstalment(instalment, salesOrder);
        doValidateConfigurationForInstalmentIsEnabled(entity);
    }
}
