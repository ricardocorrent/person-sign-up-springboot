package com.ws.sales.signeddocument;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.util.Constants;
import java.util.UUID;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Validation class to ensure {@link SalesOrderSignedDocument} data being manipulated in CRUD operations is
 * valid and follow it business rules.
 *
 * @since v1.0.0 2019-05-03
 *
 * @author Ricardo Corrent
 */
public class SalesOrderSignedDocumentValidator extends AbstractEntityValidator<SalesOrderSignedDocument> {

    private final Logger logger = LoggerFactory.getLogger(SalesOrderSignedDocumentValidator.class);
    private final SalesOrderDAO salesOrderDAO;

    /**
     * Injectable constructor getting access to persisted data.
     *
     * @param salesOrderDAO DAO {@link SalesOrderDAO} instance
     */
    @Inject
    public SalesOrderSignedDocumentValidator(final SalesOrderDAO salesOrderDAO) {
        this.salesOrderDAO = salesOrderDAO;
    }

    /**
     * Default validation method override which will make specific inspections over the given
     * {@link SalesOrderSignedDocument} according to the given {@link IValidationFilter}
     *
     * @param entity The signed document instance to be validated
     * @param filter The validation scenario filter
     */
    @Override
    protected void validate(SalesOrderSignedDocument entity, IValidationFilter... filter) {
        super.validateByBeanValidation(entity, null);
        validateOrder(entity);
        throwFoundErrors();
    }

    /**
     * Extracts the {@link UUID} Id from the {@link SalesOrder} linked to the {@link SalesOrderSignedDocument}
     *
     * @param entity The {@link SalesOrderSignedDocument} to have its sales order Id extracted
     */
    private void validateOrder(final SalesOrderSignedDocument entity) {
        if(entity != null
                && entity.getSalesOrder() != null
                && entity.getSalesOrder().getId() != null) {
            try {
                this.salesOrderDAO.findById(entity.getSalesOrder().getId());
            } catch (final RegisterNotFoundException e) {
                logger.error("Error loading entity", e);
                addError(new LogicError(Constants.FIELD_SALES_ORDER, Constants.MESSAGE_REGISTER_NOT_FOUND), entity);
            }
        }
    }

    /**
     * Validates the {@link UUID} Id from the {@link SalesOrder} without needed to have one specified
     * {@link SalesOrderSignedDocument}
     *
     * @param orderId The {@link UUID} to find in the sales order database
     */
    public void validateOrder(final UUID orderId) {
        if(orderId != null) {
            this.salesOrderDAO.findById(orderId);
        }
    }
}
