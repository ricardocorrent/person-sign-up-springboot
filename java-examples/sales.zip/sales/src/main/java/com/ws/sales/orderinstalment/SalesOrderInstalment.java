package com.ws.sales.orderinstalment;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.persistence.model.Views;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
@Entity
@PreventRecycling
public class SalesOrderInstalment extends SoftDeleteBaseEntity implements DefaultPojoConverter {

    @NotNull
    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    @PojoColumnFilter(value = {"id"})
    private SalesOrder salesOrder;

    @Min(1)
    private Integer number;

    @NotNull
    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate dueDate;

    @NotNull
    @Column(precision = 18, scale = 6)
    @DecimalMin(value = "0.000001", message = "orderInstalment.instalmentsValueBiggerThanZero")
    @Digits(integer = 18, fraction = 6, message = Constants.MESSAGE_DECIMAL)
    private BigDecimal value;

    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(final Integer number) {
        this.number = number;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(final LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(final BigDecimal value) {
        this.value = value;
    }
}
