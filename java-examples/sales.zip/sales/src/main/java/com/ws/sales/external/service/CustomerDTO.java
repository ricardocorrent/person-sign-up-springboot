package com.ws.sales.external.service;

import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 7.1.0 2019-01-16
 */
public class CustomerDTO {

    private UUID id;
    private String name;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}