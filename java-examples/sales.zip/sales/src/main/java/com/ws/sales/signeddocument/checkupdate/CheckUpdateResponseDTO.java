package com.ws.sales.signeddocument.checkupdate;

import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * This class has been created to send a response with the quantity of documents updated
 *
 * @since 1.0.0 2019-05-15
 *
 * @author Ricardo Corrent
 */
public class CheckUpdateResponseDTO implements DefaultPojoConverter {

    private Integer updatedItems;

    public CheckUpdateResponseDTO(final Integer updatedItems) {
        this.updatedItems = updatedItems;
    }

    public Integer getUpdatedItems() {
        return updatedItems;
    }

    public void setUpdatedItems(final Integer updatedItems) {
        this.updatedItems = updatedItems;
    }
}
