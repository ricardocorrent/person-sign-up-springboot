package com.ws.sales.situation;

import com.ws.sales.util.SalesAbstractResource;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * @author thyago.volpatto
 * @since v5.1.0 19/04/2017.
 */
@Path("/situations")
public class SituationResource extends SalesAbstractResource<Situation, SituationSearch> {

    private final SituationService service;

    @Inject
    public SituationResource(SituationService service) {
        this.service = service;
    }

    @Override
    public Response search(final SituationSearch parameters) {
        return Response.ok().entity(service.search(parameters)).build();
    }
}
