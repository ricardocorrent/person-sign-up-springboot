package com.ws.sales.invoicetype;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * The class InvoiceTypeService is used to call the validator of business rules and the DAO layer(persistence layer).
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
public class InvoiceTypeService extends AbstractService<InvoiceType> {

    /**
     * Injects InvoiceTypeDAO class for communication between layers of InvoiceTypeService
     * and InvoiceTypeDAO.
     */
    private final InvoiceTypeDAO dao;

    @Inject
    public InvoiceTypeService(InvoiceTypeDAO dao) {
        super(dao);
        this.dao = dao;
    }

    /**
     * Method to search a list of Invoice Type by filter.
     *
     * @param invoiceTypeSearch the invoice type search.
     * @return the paged list of invoice type.
     */
    public PagedList<InvoiceType> search(final InvoiceTypeSearch invoiceTypeSearch) {
        return dao.search(invoiceTypeSearch);
    }
}