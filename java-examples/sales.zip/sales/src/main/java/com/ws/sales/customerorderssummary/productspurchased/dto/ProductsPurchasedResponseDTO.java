package com.ws.sales.customerorderssummary.productspurchased.dto;

import com.ws.commons.pojoconverter.IPojoConverter;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * This DTO represent the list of products that will be sent formatted to the front end
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
@Getter
@Setter
public class ProductsPurchasedResponseDTO implements Serializable, IPojoConverter {

    private List<ProductsSummaryDTO> products;

    private Integer count;

    private Integer page;

    private Integer pageSize;

}
