package com.ws.sales.orderparameter;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

/**
 * This class represents the persistence layer of Order Parameter, with she it's possible make methods to
 * interact with the database.
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-22
 */
public class OrderParameterDAO extends AbstractDAO<OrderParameter> {

    /**
     * @see AbstractDAO#getEntityClass()
     **/
    @Override
    public Class<OrderParameter> getEntityClass() {
        return OrderParameter.class;
    }

    /**
     * Method to search a list of Order Parameter by filter.
     *
     * @param orderParameterSearch the order parameter  search contains filters to apply on where clause
     * @return a paged list of order parameter
     */
    public PagedList<OrderParameter> search(final OrderParameterSearch orderParameterSearch) {

        Objects.requireNonNull(orderParameterSearch, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("orderParameterSearch"));

        final Query<OrderParameter> query = find();

        final ExpressionList<OrderParameter> where = query.where();

        if (StringUtils.isNotEmpty(orderParameterSearch.getKey())) {
            where.icontains("key", orderParameterSearch.getKey());
        }

        if (StringUtils.isNotEmpty(orderParameterSearch.getValueType())) {
            where.icontains("valueType", orderParameterSearch.getValueType());
        }

        if (StringUtils.isNotEmpty(orderParameterSearch.getValue())) {
            where.icontains("value", orderParameterSearch.getValue());
        }

        if (StringUtils.isNotEmpty(orderParameterSearch.getMinValue())) {
            where.icontains("minValue", orderParameterSearch.getMinValue());
        }

        if (StringUtils.isNotEmpty(orderParameterSearch.getMaxValue())) {
            where.icontains("maxValue", orderParameterSearch.getMaxValue());
        }

        if (StringUtils.isNotEmpty(orderParameterSearch.getNote())) {
            where.icontains("note", orderParameterSearch.getNote());
        }

        return getPagedList(query, orderParameterSearch);
    }

    /**
     * Method to search a Order Parameter by key.
     *
     * @param key the key to apply on where clause
     * @return a order parameter
     */
    public OrderParameter searchByKey(final String key) {

        final Query<OrderParameter> query = find();

        final ExpressionList<OrderParameter> where = query.where();

        where.icontains("key", key);

        return query.findOne();
    }

}
