package com.ws.sales.external.product;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.product.model.ProductPackaging;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Validations for product, price list and price list items
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-20
 */
public class ProductValidation {

    private final ProductGateway productGateway;
    private final OrderParameterService orderParameterService;

    /**
     * @param productGateway        to perform product gets
     * @param orderParameterService to load parameters
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public ProductValidation(final ProductGateway productGateway,
                             final OrderParameterService orderParameterService) {
        this.productGateway = productGateway;
        this.orderParameterService = orderParameterService;
    }

    /**
     * Return an error if the product does not exist or is inactive.
     *
     * @param productId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateProductCanBeUsed(final UUID productId) {
        return Optional.ofNullable(productId).map(id -> {
            final Product product = productGateway.getProduct(id);
            if (product == null) {
                return new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!product.isActive()) {
                return new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the price list item does not exist.
     *
     * @param priceListItemId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidatePriceListItemCanBeUsed(final UUID priceListItemId) {
        return Optional.ofNullable(priceListItemId).map(id -> {
            final PriceListItem priceListItem = productGateway.getPriceListItem(id);
            if (priceListItem == null) {
                return new LogicError(Constants.FIELD_PRICE_LIST_ITEM, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the price list item does not belong to the price list
     *
     * @param priceListItemId to compare with price list items
     * @param priceListId     to load price list
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidatePriceListItemBelongsToThePriceList(final UUID priceListItemId, final UUID priceListId) {
        if (priceListItemId != null && priceListId != null) {
            final PriceList priceList = productGateway.getPriceList(priceListId);
            return Optional.ofNullable(priceList).map(pList -> {
                final Boolean priceListContainsItem = priceList.getItems().stream().anyMatch(item -> item.getId().equals(priceListItemId.toString()));
                return !priceListContainsItem ? new LogicError(Constants.FIELD_PRICE_LIST_ITEM, Constants.MESSAGE_PRICE_LIST_ITEM_MUST_BELONG_TO_PRICE_LIST) : null;
            }).orElse(null);
        }
        return null;
    }

    /**
     * Return an error if the product does not belong to the price list item
     *
     * @param priceListItemId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateProductBelongToThePriceListItem(final UUID priceListItemId, final UUID productId) {
        if (priceListItemId != null && productId != null) {
            final PriceListItem priceListItem = productGateway.getPriceListItem(priceListItemId);
            return Optional.ofNullable(priceListItem).map(pList -> {
                final Boolean productBelongsToPriceListItem = priceListItem.getProduct().getId().equals(productId.toString());
                return !productBelongsToPriceListItem ? new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_PRODUCT_MUST_BELONG_TO_PRICE_LIST_ITEM) : null;
            }).orElse(null);
        }
        return null;
    }

    /**
     * Return an error if the price list does not exist or is inactive.
     *
     * @param priceListId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidatePriceListCanBeUsed(final UUID priceListId) {
        return Optional.ofNullable(priceListId).map(id -> {
            final PriceList priceList = productGateway.getPriceList(id);
            if (priceList == null) {
                return new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!priceList.isActive()) {
                return new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            if (ValidationUtils.isDateAfterToday(priceList.getStartOn()) || ValidationUtils.isDateBeforeToday(priceList.getEndOn())) {
                return new LogicError(Constants.FIELD_PRODUCT, Constants.MESSAGE_REGISTER_OUT_OF_DATE);
            }
            return null;
        }).orElse(null);
    }


    /**
     * Return an error if the product does not permit sell in fraction and the quantity is a fraction .
     *
     * @param productId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateProductPermitFractionSale(final BigDecimal quantity, final UUID productId) {
        final BigDecimal saleQuantity = Optional.ofNullable(quantity).orElse(BigDecimal.ZERO);
        return Optional.ofNullable(productId)
                .map(productGateway::getProduct)
                .map(product -> !product.isSaleFractioned() && saleQuantity.scale() > 0)
                .map(fractionNotAllowed
                        -> fractionNotAllowed ? new LogicError(Constants.FIELD_QUANTITY, Constants.MESSAGE_SALE_FRACTION) : null)
                .orElse(null);
    }

    /**
     * Return the selected package by loading the product and searching in the list of packages
     *
     * @param productId to load entity
     * @param packageId to search in the list of packages
     * @return productPackage
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    private ProductPackaging getPackage(final UUID productId, final UUID packageId) {
        if (productId != null && packageId != null) {
            final Product product = productGateway.getProduct(productId);
            return Optional.ofNullable(product)
                    .map(productMap -> productMap.getPackagings()
                            .stream()
                            .findFirst().orElse(null))
                    .orElse(null);
        }
        return null;
    }


    /**
     * Return an error if the package does not exist or is inactive.
     *
     * @param productId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidatePackageCanBeUsed(final UUID productId, final UUID packageId) {
        if (productId != null && packageId != null) {
            final ProductPackaging productPackaging = this.getPackage(productId, packageId);
            return productPackaging != null ? null : new LogicError(Constants.FIELD_PRODUCT_PACKAGING, Constants.MESSAGE_PACKAGE_MUST_BELONG_TO_PRODUCT);
        }
        return null;
    }

    /**
     * Return an error if the quantity of packaging is inconsistent
     *
     * @param productId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateQuantityOfPackaging(final UUID productId, final UUID packageId, final BigDecimal quantity) {
        if (productId != null && packageId != null && quantity != null) {
            final ProductPackaging productPackaging = this.getPackage(productId, packageId);
            Objects.requireNonNull(productPackaging, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(Constants.FIELD_PRODUCT_PACKAGING));
            final BigDecimal conversionFactor = Optional.ofNullable(productPackaging.getConversionFactor()).orElse(BigDecimal.ONE);
            BigDecimal remainder = quantity.remainder(conversionFactor);
            return remainder.compareTo(BigDecimal.ZERO) != 0 ? new LogicError(Constants.FIELD_QUANTITY, Constants.MESSAGE_QUANTITY_PACK_INCONSISTENT) : null;
        }
        return null;
    }

    /**
     * Return an error if the original price is different than the price list's price
     *
     * @param priceListItemId to load entity and get the price
     * @param value           to compare
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateOriginalPriceIsEqualToPriceListItemPrice(final UUID priceListItemId, final BigDecimal value) {
        final BigDecimal saleValue = Optional.ofNullable(value).orElse(BigDecimal.ZERO);
        return Optional.ofNullable(priceListItemId)
                .map(productGateway::getPriceListItem)
                .map(PriceListItem::getSalesPrice)
                .map(price -> price.compareTo(saleValue) != 0)
                .map(isDifferent -> isDifferent ? new LogicError(Constants.FIELD_ORIGINAL_PRICE, Constants.MESSAGE_ORIGINAL_PRICE_INCONSISTENT) : null)
                .orElse(null);
    }

    /**
     * Return an error if the price is lower than the minimum price
     *
     * @param priceListItemId to load entity and get the price
     * @param value           to compare
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public LogicError doValidateMinimumPrice(final UUID priceListItemId, final BigDecimal value) {
        final Boolean pluginMinimumPrice = Boolean.valueOf(this.orderParameterService.searchByKey(Constants.FIELD_PARAMETER_MINIMUM_PRICE).getValue());
        if (pluginMinimumPrice) {
            final BigDecimal saleValue = Optional.ofNullable(value).orElse(BigDecimal.ZERO);
            return Optional.ofNullable(priceListItemId)
                    .map(productGateway::getPriceListItem)
                    .map(PriceListItem::getMinimumPrice)
                    .map(price -> saleValue.compareTo(price) < 0 ? ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MINIMUM_PRICE,
                            price.toString(),
                            Constants.FIELD_SALES_PRICE,
                            Constants.MESSAGE_PRICE_LOWER_THAN_MINIMUM) : null)
                    .orElse(null);
        }
        return null;
    }
}
