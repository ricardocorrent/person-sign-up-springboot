package com.ws.sales.orderintegration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.product.dto.PackagingDTO;
import com.ws.sales.external.product.dto.ProductDTO;
import com.ws.sales.external.product.dto.ServiceDTO;
import com.ws.sales.orderservice.ERecurrenceType;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since 8.6.0 2019-06-27
 */
@Getter
@Setter
public class ServiceIntegrationDTO extends BaseDTO {

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "service.id", target = "serviceId"),
            @PojoColumnMapper(source = "service.description", target = "serviceDescription"),
    })
    private ServiceDTO service;

    private BigDecimal quantity;

    @Enumerated(value = EnumType.STRING)
    private ERecurrenceType recurrenceType;

    private BigDecimal repetitions;

    private BigDecimal originalPrice;

    private BigDecimal salesPrice;

    private BigDecimal totalValue;

    private BigDecimal totalQuantity;

    private BigDecimal discount;

    private BigDecimal discountPercentage;

    private BigDecimal increaseValue;

    private BigDecimal increasePercentage;

    private String externalId;

}
