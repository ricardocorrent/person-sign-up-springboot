package com.ws.sales.paymenttermlocationpermission;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermLocationPermissionService extends AbstractService<PaymentTermLocationPermission> {

    private final PaymentTermDAO paymentTermDAO;
    private final PaymentTermLocationPermissionValidator paymentTermLocationPermissionValidator;

    /**
     * @param paymentTermLocationPermissionDAO       to perform entity persistence
     * @param paymentTermDAO                         to load {@link PaymentTerm}
     * @param paymentTermLocationPermissionValidator to handle permission validations
     **/
    @Inject
    public PaymentTermLocationPermissionService(final PaymentTermLocationPermissionDAO paymentTermLocationPermissionDAO, final PaymentTermDAO paymentTermDAO,
                                                final PaymentTermLocationPermissionValidator paymentTermLocationPermissionValidator) {
        super(paymentTermLocationPermissionDAO);
        this.paymentTermDAO = paymentTermDAO;
        this.paymentTermLocationPermissionValidator = paymentTermLocationPermissionValidator;
    }

    /**
     * @param paymentTermLocationPermissions {@link List<PaymentTermLocationPermission>} to persist
     * @param paymentTermId                  to get {@link PaymentTerm}
     **/
    public void insertList(final List<PaymentTermLocationPermission> paymentTermLocationPermissions, final UUID paymentTermId) {
        final PaymentTerm paymentTerm = paymentTermDAO.findById(paymentTermId);
        this.doValidateByBeanValidation(paymentTermLocationPermissions);
        this.doValidateLogic(paymentTermLocationPermissions, paymentTerm);
        this.dao.batchInsert(paymentTermLocationPermissions);
    }

    /**
     * @param paymentTermId to fill the search
     * @return {@link PagedList<PaymentTermLocationPermission>}
     **/
    public PagedList<PaymentTermLocationPermission> getByPaymentTerm(final UUID paymentTermId) {
        return ((PaymentTermLocationPermissionDAO) this.dao).getByPaymentTerm(paymentTermId);
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors. After validate, it will throw the errors
     *
     * @param paymentTermLocationPermissions {@link List<PaymentTermLocationPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateByBeanValidation(final List<PaymentTermLocationPermission> paymentTermLocationPermissions) {
        IntStream.range(0, paymentTermLocationPermissions.size())
                .forEach(index -> paymentTermLocationPermissionValidator.validateByBeanValidation(paymentTermLocationPermissions.get(index), String.valueOf(index)));
        paymentTermLocationPermissionValidator.throwFoundErrors();
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors.
     *
     * @param paymentTermLocationPermissions {@link List<PaymentTermLocationPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateLogic(final List<PaymentTermLocationPermission> paymentTermLocationPermissions, final PaymentTerm paymentTerm) {
        IntStream.range(0, paymentTermLocationPermissions.size())
                .forEach(index -> paymentTermLocationPermissionValidator.validate(paymentTermLocationPermissions.get(index),
                        paymentTerm.getLocationPermissions(),
                        String.valueOf(index)));
        paymentTermLocationPermissionValidator.throwFoundErrors();
    }
}
