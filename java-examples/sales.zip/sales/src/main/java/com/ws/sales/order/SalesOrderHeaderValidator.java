package com.ws.sales.order;

import com.google.common.collect.Sets;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.logicvalidation.DynamicValid;
import com.ws.commons.server.validation.logicvalidation.LogicValidator;
import com.ws.commons.server.validation.logicvalidation.builderror.ListBuilderLogicError;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListPaymentTerm;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.opportunity.OpportunityGateway;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.user.UserGateway;
import com.ws.sales.order.enums.OrderOrigin;
import com.ws.sales.ordercurrency.OrderCurrencyValidator;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.ordertype.OrderTypeDAO;
import com.ws.sales.ordertype.OrderTypeService;
import com.ws.sales.paymentmethod.PaymentMethodDAO;
import com.ws.sales.paymentmethod.PaymentMethodService;
import com.ws.sales.paymentterm.PaymentTermDAO;
import com.ws.sales.paymentterm.PaymentTermService;
import com.ws.sales.situation.SituationDAO;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.GenericValidator;
import com.ws.user.model.Hierarchy;
import com.ws.user.model.User;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.session.Session;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Default
@BeanValidationIntegrated(SalesOrder.class)
public class SalesOrderHeaderValidator extends LogicValidator<SalesOrder> {



    private final SalesOrderDAO salesOrderDAO;
    private final PaymentMethodDAO paymentMethodDAO;
    private final PaymentTermDAO paymentTermDAO;
    private final SituationDAO situationDAO;
    private final PaymentMethodService paymentMethodService;
    private final PaymentTermService paymentTermService;
    private final UserGateway userGateway;
    private final ProductGateway productGateway;
    private final CustomerGateway customerGateway;
    private final AdministrationGateway administrationGateway;
    private final OrderCurrencyValidator orderCurrencyValidator;
    private final OrderTypeDAO orderTypeDAO;
    private final OrderTypeService orderTypeService;
    private final UserContext userContext;
    private final OrderParameterDAO orderParameterDAO;
    private final ListBuilderLogicError builderLogicError;
    private final SalesOrderValidator salesOrderValidator;
    private final OpportunityGateway opportunityGateway;

    /**
     * Cria um novo validator.
     * @param salesOrderDAO             the SalesOrder DAO.
     * @param paymentMethodDAO          the payment method DAO.
     * @param paymentTermDAO            the payment term DAO.
     * @param orderTypeDAO              the order type DAO.
     * @param situationDAO              the situation DAO.
     * @param paymentMethodService      the payment method service.
     * @param paymentTermService        the payment term service.
     * @param orderTypeService          the order type service.
     * @param userGateway               the access gateway to the user service.
     * @param productGateway            the access gateway to the product service.
     * @param customerGateway           the access gateway to the customer service.
     * @param administrationGateway     the access gateway to the administration service.
     * @param orderCurrencyValidator    the order currency validator.
     * @param userContext               the logged in user context.
     * @param orderParameterDAO         the order parameter DAO.
     * @param builderLogicError         the validation error builder.
     * @param salesOrderValidator       the sales order validator.
     * @param opportunityGateway        the access gateway to the opportunity service.
     */
    @Inject
    public SalesOrderHeaderValidator(final SalesOrderDAO salesOrderDAO,
                                     final PaymentMethodDAO paymentMethodDAO,
                                     final PaymentTermDAO paymentTermDAO,
                                     final OrderTypeDAO orderTypeDAO,
                                     final SituationDAO situationDAO,
                                     final PaymentMethodService paymentMethodService,
                                     final PaymentTermService paymentTermService,
                                     final OrderTypeService orderTypeService,
                                     final UserGateway userGateway,
                                     final ProductGateway productGateway,
                                     final CustomerGateway customerGateway,
                                     final AdministrationGateway administrationGateway,
                                     final OrderCurrencyValidator orderCurrencyValidator,
                                     final UserContext userContext,
                                     final OrderParameterDAO orderParameterDAO,
                                     final ListBuilderLogicError builderLogicError,
                                     final SalesOrderValidator salesOrderValidator,
                                     final OpportunityGateway opportunityGateway) {
        this.salesOrderDAO = salesOrderDAO;
        this.paymentMethodDAO = paymentMethodDAO;
        this.paymentTermDAO = paymentTermDAO;
        this.orderTypeDAO = orderTypeDAO;
        this.situationDAO = situationDAO;
        this.paymentMethodService = paymentMethodService;
        this.paymentTermService = paymentTermService;
        this.orderTypeService = orderTypeService;
        this.userGateway = userGateway;
        this.productGateway = productGateway;
        this.customerGateway = customerGateway;
        this.administrationGateway = administrationGateway;
        this.orderCurrencyValidator = orderCurrencyValidator;
        this.userContext = userContext;
        this.orderParameterDAO = orderParameterDAO;
        this.builderLogicError = builderLogicError;
        this.salesOrderValidator = salesOrderValidator;
        this.opportunityGateway = opportunityGateway;
    }


    @DynamicValid
    public ListBuilderLogicError validateHeader(final SalesOrder salesOrder) {
        Objects.requireNonNull(salesOrder);
        if (Objects.nonNull(salesOrder.getId()) && salesOrderDAO.salesOrderExists(salesOrder.getId())) {
            final SalesOrder dbOrder = salesOrderDAO.findById(salesOrder.getId());
            addError(this.doValidateIfOrderCanBeEdited(dbOrder, Boolean.FALSE));
        }

        addError(this.validateUserExists(salesOrder));
        addError(this.validateUserIsSameAsUserLogged(salesOrder));
        addError(this.validateCustomerExists(salesOrder));
        addError(this.validateLocationExists(salesOrder));
        addError(this.validatePriceListExists(salesOrder));
        addError(this.validateCompanyExists(salesOrder));
        addError(this.validatePaymentTermExists(salesOrder));
        addError(this.validatePaymentTermConditions(salesOrder));
        addError(this.validatePaymentMethodExists(salesOrder));
        addError(this.validateSituationExists(salesOrder));
        addError(this.validateOrderTypeExists(salesOrder));
        addError(this.validateActivityExists(salesOrder));
        addError(this.validateOrderTypeIsActive(salesOrder));
        addError(this.validatePaymentTermIsActive(salesOrder));
        addError(this.validatePaymentMethodIsActive(salesOrder));
        addError(this.validateCompanyIsActive(salesOrder));
        addError(this.validatePriceListIsActive(salesOrder));
        addError(this.validateUserIsActive(salesOrder));
        addError(this.validateLocationBelongsToCustomer(salesOrder));
        addError(this.validatePriceListIsOutOfDate(salesOrder));
        addError(this.validateCurrencyAvailableInPriceList(salesOrder));

        addError(this.validateCurrencyPlugin(salesOrder));

        final Boolean isDueDateEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_ENABLE_DUE_DATE_FIELD).getValue());
        final Boolean isDueDateRequired = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_FIELD_REQUIRED).getValue());
        final Boolean isDueDatePriceEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_PRICE).getValue());

        if (isDueDateRequired) {
            addError(this.validateIfDueDateIsFilled(salesOrder));
        }

        if (isDueDatePriceEnabled) {
            addError(this.validateDueDateWithPaymentTermBlocked(salesOrder));
            addError(this.validateDueDateWithLowerThanNowDate(salesOrder));
        }
        addError(this.validateDueDateWithConfOff(salesOrder, isDueDateEnabled));

        addError(this.validateProfessionalExists(salesOrder));
        addError(this.validateProfessionalIsActive(salesOrder));
        addError(this.validateIfTheInformedProfessionalBelongsToTheHierarchyLowerToUserLogged(salesOrder));

        return builderLogicError;

    }

    
    private void addError(final LogicError logicError) {
        if (Objects.nonNull(logicError)) {
            builderLogicError.addError(logicError);
        }        
    }

    private void addError(final List<LogicError> logicErrors) {
        if (Objects.nonNull(logicErrors) && !logicErrors.isEmpty()) {
            builderLogicError.addError(logicErrors);
        }
    }

    private void addError(final String field, final Set<ConstraintViolation<BaseModel>> constraintViolations) {
        if (Objects.nonNull(constraintViolations) && !constraintViolations.isEmpty()) {
            final List<LogicError> logicErrors = constraintViolations
                    .stream()
                    .map(constraint -> new LogicError(field, constraint.getMessage()))
                    .collect(Collectors.toList());
            if (!logicErrors.isEmpty()) {
                builderLogicError.addError(logicErrors);
            }
        }
    }


    /**
     * @param salesOrder to check fields and validate
     * @param isDelete for selecting the message
     * @return {@link LogicError} if there are any validations that block the order for being edited
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfOrderCanBeEdited(final SalesOrder salesOrder, final Boolean isDelete) {
        final String originError = isDelete ? Constants.MESSAGE_ORDER_CANNOT_REMOVE_BECAUSE_IS_EXTERNAL : Constants.MESSAGE_ORDER_CANNOT_EDIT_BECAUSE_IS_EXTERNAL;
        final String draftError = isDelete ? Constants.MESSAGE_ORDER_CONFIRMED_CANNOT_REMOVE : Constants.MESSAGE_ORDER_FINALIZED;
        final List<LogicError> errorsFromOrder = new LinkedList<>();
        GenericValidator.applyValidator(this::doValidateIfOrderIsDraft, salesOrder, draftError, errorsFromOrder);
        GenericValidator.applyValidator(this::doValidateIfOriginIsWeb, salesOrder, originError, errorsFromOrder);
        return errorsFromOrder.stream().findFirst().orElse(null);
    }

    /**
     * @param salesOrder to check draft and validate
     * @return {@link LogicError} if the draft is false
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private LogicError doValidateIfOrderIsDraft(final SalesOrder salesOrder, final String errorMessage) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getDraft)
                .filter(Boolean.FALSE::equals)
                .map(isNotDraft -> new LogicError(Constants.FIELD_DRAFT, errorMessage))
                .orElse(null);
    }

    /**
     * @param salesOrder to check draft and validate
     * @return {@link LogicError} if the draft is false
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private LogicError doValidateIfOriginIsWeb(final SalesOrder salesOrder, final String errorMessage) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getOrigin)
                .filter(origin -> !OrderOrigin.WEB.toString().equals(origin))
                .map(isNotFromWeb -> new LogicError(Constants.FIELD_SALES_ORDER, errorMessage))
                .orElse(null);
    }

    /**
     * Validate if situation exists
     *
     * @param order
     */
    public LogicError validateSituationExists(final SalesOrder order) {
        if (order.getSituationId() != null && !situationDAO.situationExists(order.getSituationId())) {
            return new LogicError("situationId", "order.situation.notFound");
        }
        return null;
    }

    /**
     * Validate if payment method exists
     *
     * @param order
     */
    public LogicError validatePaymentMethodExists(final SalesOrder order) {
        if (order.getPaymentMethodId() != null && !paymentMethodDAO.paymentMethodExists(order.getPaymentMethodId())) {
            return new LogicError("paymentMethod", "order.paymentMethod.notFound");
        }
        return null;
    }

    /**
     * Validate if payment term exists
     *
     * @param order
     */
    public LogicError validatePaymentTermExists(final SalesOrder order) {
        if (order.getPaymentTermId() != null && !paymentTermDAO.paymentTermExists(order.getPaymentTermId())) {
            return new LogicError("paymentTermId", "order.paymentTerm.notFound");
        }
        return null;

    }

    /**
     * Validate if payment term exists in price list
     *
     * @param priceListPaymentTerms list of payment terms to search
     * @param paymentTermId         as Payment Term Id
     * @return {@link LogicError}
     * @author Luiz Paulo Lasta Moco
     * @since 2018-06-19
     */
    public LogicError doValidatePaymentTermExistsInPriceList(final List<PriceListPaymentTerm> priceListPaymentTerms,
                                                             final UUID paymentTermId) {
        final Boolean paymentTermExistsInTheList = priceListPaymentTerms
                .stream()
                .anyMatch(priceListPaymentTerm -> priceListPaymentTerm.getPaymentTermId().equals(paymentTermId.toString()));
        return paymentTermExistsInTheList ? null :
                new LogicError(Constants.FIELD_PAYMENT_TERM_ID, Constants.MESSAGE_PAYMENT_TERM_NOT_FOUND_PRICE_LIST);
    }

    /**
     * Validate if payment term match the conditions
     *
     * @param order to validate
     * @return {@link LogicError}
     * @author Luiz Paulo Lasta Moco
     * @since 18/06/2018
     */
    public LogicError validatePaymentTermConditions(final SalesOrder order) {
        return Optional.ofNullable(order)
                .map(SalesOrder::getPriceListId)
                .map(productGateway::getPriceList)
                .map(PriceList::getPaymentTerms)
                .map(priceListPaymentTerms -> {
                    if (order.getPaymentTermId() != null) {
                        if (!priceListPaymentTerms.isEmpty()) {
                            return this.doValidatePaymentTermExistsInPriceList(priceListPaymentTerms, order.getPaymentTermId());
                        }
                    }
                    return null;
                })
                .orElse(null);
    }

    /**
     * Validate if company exists
     *
     * @param order
     */
    public LogicError validateCompanyExists(final SalesOrder order) {
        if (order.getCompanyId() != null && !administrationGateway.companyExists(order.getCompanyId())) {
            return new LogicError("companyId", "order.company.notFound");
        }
        return null;
    }

    /**
     * Validate if price list exists
     *
     * @param order
     */
    public LogicError validatePriceListExists(final SalesOrder order) {
        if (order.getPriceListId() != null && !productGateway.priceListExists(order.getPriceListId())) {
            return new LogicError(Constants.FIELD_PRICE_LIST_ID, "order.priceList.notFound");
        }
        return null;
    }

    /**
     * Validate if location exists
     *
     * @param order
     */
    public LogicError validateLocationExists(final SalesOrder order) {
        if (order.getLocationId() != null && !customerGateway.locationExists(order.getLocationId())) {
            return new LogicError(Constants.FIELD_CUSTOMER_LOCATION, "order.location.notFound");
        }
        return null;
    }

    /**
     * Validate if customer exists
     *
     * @param order
     */
    public LogicError validateCustomerExists(final SalesOrder order) {
        if (order.getCustomerId() != null && !customerGateway.customerExists(order.getCustomerId())) {
            return new LogicError(Constants.FIELD_CUSTOMER_ID, "order.customer.notFound");
        }
        return null;
    }

    /**
     * Validate if location belongs to the customer
     *
     * @param order
     */
    public LogicError validateLocationBelongsToCustomer(final SalesOrder order) {
        if (order.getCustomerId() != null && order.getLocationId() != null && !customerGateway.locationBelongsToCustomer(order.getLocationId(), order.getCustomerId())) {
            return new LogicError(Constants.FIELD_CUSTOMER_LOCATION, "order.location.notbelongs");
        }
        return null;
    }

    /**
     * Validate if user exists
     *
     * @param order
     */
    public LogicError validateUserExists(final SalesOrder order) {
        if (order.getUserId() != null && !userGateway.userExists(order.getUserId())) {
            return new LogicError("userId", "order.user.notFound");
        }
        return null;
    }

    /**
     * Validate the order user is the same as the user logged
     *
     * @param salesOrder order to validate
     * @return null or error if it does not pass for validation
     */
    public LogicError validateUserIsSameAsUserLogged(final SalesOrder salesOrder) {
        final Session session = userContext.getSession();
        final String idLoggedUserString = session != null ? (String) session.getAttribute("user_id") : null;
        final UUID userId = salesOrder.getUserId();

        if (StringUtils.isNotBlank(idLoggedUserString)
                && Objects.nonNull(userId)
                && !UUID.fromString(idLoggedUserString).equals(userId)) {
            return new LogicError("user", "order.user.userIsNotLogged");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if order type exists
     */
    public LogicError validateOrderTypeExists(final SalesOrder salesOrder) {
        if (salesOrder.getOrderTypeId() != null && !orderTypeDAO.orderTypeExists(salesOrder.getOrderTypeId())) {
            return new LogicError("orderTypeId", "order.orderType.notFound");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if payment term is active
     */
    public LogicError validatePaymentTermIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getPaymentTermId() != null && !paymentTermService.paymentTermIsActive(salesOrder.getPaymentTermId())) {
            return new LogicError("paymentTermId", "order.paymentTerm.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if payment method is active
     */
    public LogicError validatePaymentMethodIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getPaymentMethodId() != null && !paymentMethodService.paymentMethodIsActive(salesOrder.getPaymentMethodId())) {
            return new LogicError("paymentMethodId", "order.paymentMethod.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if company is active
     */
    public LogicError validateCompanyIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getCompanyId() != null && !administrationGateway.companyIsActive(salesOrder.getCompanyId())) {
            return new LogicError("companyId", "order.company.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if price list is active
     */
    public LogicError validatePriceListIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getPriceListId() != null && !productGateway.priceListIsActive(salesOrder.getPriceListId())) {
            return new LogicError(Constants.FIELD_PRICE_LIST_ID, "order.priceList.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if user is active
     */
    public LogicError validateUserIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getUserId() != null && !userGateway.userIsActive(salesOrder.getUserId())) {
            return new LogicError("userId", "order.user.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if customer is active
     */
    public LogicError validateCustomerIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getCustomerId() != null && !customerGateway.customerIsActive(salesOrder.getCustomerId())) {
            return new LogicError(Constants.FIELD_CUSTOMER_ID, "order.customer.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if location of customer is active
     */
    public LogicError validateCustomerLocationIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getLocationId() != null && !customerGateway.locationIsActive(salesOrder.getLocationId())) {
            return new LogicError(Constants.FIELD_CUSTOMER_LOCATION, "order.location.inactive");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if order type is active
     */
    public LogicError validateOrderTypeIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getOrderTypeId() != null && !orderTypeService.orderTypeIsActive(salesOrder.getOrderTypeId())) {
            return new LogicError("orderTypeId", "order.orderType.inactive");
        }
        return null;
    }

    public LogicError validateCurrencyPlugin(final SalesOrder salesOrder) {
        final Boolean isCurrencyEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_CURRENCY_PLUGIN).getValue());

        if (isCurrencyEnabled) {
            addError(this.validateCurrencyRequired(salesOrder));
            addError(this.validateCurrencyQuotationRequired(salesOrder));
        } else if (StringUtils.isNotBlank(salesOrder.getCurrency()) || salesOrder.getOrderCurrency() != null) {
            return new LogicError(Constants.FIELD_SALES_ORDER, "order.item.currencyPluginDisabled");
        }
        return null;
    }

    /**
     * This method validate if price list informed have a valid currency
     *
     * @since 8.6.0
     * @author Ricardo Corrent
     *
     * @param salesOrder {@link SalesOrder}
     * @return {@link LogicError}
     */
    public LogicError validateCurrencyRequired(final SalesOrder salesOrder) {
        final PriceList priceList = this.getPriceList(salesOrder);
        if (Objects.nonNull(salesOrder)
                && Objects.nonNull(priceList)
                && (Objects.isNull(salesOrder.getOrderCurrency()) || Objects.isNull(salesOrder.getOrderCurrency().getCurrencyId()))
                && Objects.nonNull(priceList.getCurrencyId())) {
            return new LogicError("currencyId", "javax.validation.constraints.NotNull.message");
        }
        return null;
    }

    /**
     * This method validate if currency have a quotation
     *
     * @since 8.6.0
     * @author Ricardo Corrent
     *
     * @param salesOrder {@link SalesOrder}
     * @return {@link LogicError}
     */
    public LogicError validateCurrencyQuotationRequired(final SalesOrder salesOrder) {
        if (Objects.nonNull(salesOrder)
                && Objects.nonNull(salesOrder.getOrderCurrency())
                && Objects.nonNull(salesOrder.getOrderCurrency().getCurrencyId())
                && Objects.isNull(salesOrder.getOrderCurrency().getCurrencyQuotationId())) {
            return new LogicError("currencyQuotationId", "javax.validation.constraints.NotNull.message");
        }
        return null;
    }

    /**
     * This method find a price list in product gateway
     *
     * @since 8.6.0
     * @author Ricardo Corrent
     *
     * @param salesOrder {@link SalesOrder}
     * @return {@link PriceList}
     */
    private PriceList getPriceList(final SalesOrder salesOrder) {
        return productGateway.getPriceList(salesOrder.getPriceListId());
    }

    /**
     * <p>
     * Validate if dueDate is null when DUE_DATE_PRICE or DUE_DATE_FIELD_REQUIRED parameters are on.
     *
     * @param salesOrder to check the dueDate and validate
     * @return {@link LogicError} if the dueDate is before today
     * @author Bruno Sprotte
     * @since v8.1.0 2019-03-20
     */
    public LogicError validateIfDueDateIsFilled(final SalesOrder salesOrder) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getDueDate)
                .filter(Objects::isNull)
                .map(order -> new LogicError(Constants.FIELD_DUE_DATE, Constants.MESSAGE_DUE_DATE_MUST_BE_FILLED))
                .orElse(null);
    }

    /**
     * Check if the payment term is bocked to change the dueDate and the order has the dueDate changed
     *
     * @param salesOrder to get the paymentTerm and the dueDate
     * @return {@link LogicError}
     * @author Maykon Roberto Rissi
     * @since 2018-07-17 v5.22.0
     */
    public LogicError validateDueDateWithPaymentTermBlocked(final SalesOrder salesOrder) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getPaymentTermId)
                .map(paymentTermDAO::findById)
                .map(paymentTerm -> {
                    final Boolean allowChangeDueDate = Optional.ofNullable(paymentTerm.getAllowChangeDueDate()).orElse(Boolean.FALSE);
                    if (!allowChangeDueDate && salesOrder.getDueDate() != null) {
                        final Integer middleTerm = Optional.ofNullable(paymentTerm.getMiddleTerm()).orElse(0);
                        final LocalDate dueDate = LocalDate.now().plusDays(middleTerm);
                        final Boolean isOrderDueDateCorrect = salesOrder.getDueDate().equals(dueDate);
                        return !isOrderDueDateCorrect ? new LogicError(Constants.FIELD_DUE_DATE, "order.validation.dueDateBlocked") : null;
                    }
                    return null;
                })
                .orElse(null);
    }

    public LogicError validateDueDateWithLowerThanNowDate(final SalesOrder salesOrder) {
        if (salesOrder != null && salesOrder.getDueDate() != null) {
            return LocalDate.now().isAfter(salesOrder.getDueDate()) ? new LogicError(Constants.FIELD_DUE_DATE, "order.validation.dueDateLowerThanNow") : null;
        }
        return null;
    }

    public LogicError validateDueDateWithConfOff(final SalesOrder salesOrder, final Boolean isDueDatePriceEnabled) {
        if (salesOrder != null && salesOrder.getDueDate() != null && !isDueDatePriceEnabled) {
            return new LogicError(Constants.FIELD_DUE_DATE, "order.validation.dueDateInactive");
        }
        return null;
    }

    public LogicError validateProfessionalExists(final SalesOrder salesOrder) {
        if (salesOrder.getUserProfessionalId() != null && !userGateway.userExists(salesOrder.getUserProfessionalId())) {
            return new LogicError(Constants.FIELD_PROFESSIONAL, "order.validation.professional.notFound");
        }
        return null;
    }

    public LogicError validateProfessionalIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getUserProfessionalId() != null && !userGateway.userIsActive(salesOrder.getUserProfessionalId())) {
            return new LogicError(Constants.FIELD_PROFESSIONAL, "order.validation.professional.inactive");
        }
        return null;
    }

    public LogicError validateIfTheInformedProfessionalBelongsToTheHierarchyLowerToUserLogged(final SalesOrder salesOrder) {
        final Session session = userContext.getSession();
        final Boolean userIsAdmin = (Boolean) session.getAttribute("user_administrator");
        if (salesOrder.getUserProfessionalId() != null && !userIsAdmin) {
            final UUID userLoggedId = UUID.fromString((String) session.getAttribute("user_id"));

            if (!salesOrder.getUserProfessionalId().equals(userLoggedId) && !userBelongsToLowerHierarchy(salesOrder, userLoggedId)) {
                return new LogicError(Constants.FIELD_PROFESSIONAL, "order.validation.professional.notBelongsToUser");
            }
        }
        return null;
    }

    private Boolean userBelongsToLowerHierarchy(final SalesOrder salesOrder, final UUID userLoggedId) {
        final User professional = userGateway.getUser(salesOrder.getUserProfessionalId());

        if (professional != null) {
            final List<Hierarchy> hierarchies = professional.getUserHierarchies();

            if (hierarchies != null) {
                return hierarchies.stream().anyMatch(hierarchy -> hierarchy.getUpperUser().getId().equals(userLoggedId.toString()));
            }
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    /**
     * new feature to handle dates in the method. If one of the dates is null, it will set a new minimum or maximum date.
     *
     * @author Maykon R Rissi
     * @since 2018-04-18
     */
    public LogicError validatePriceListIsOutOfDate(final SalesOrder salesOrder) {
        final PriceList priceList = productGateway.getPriceList(salesOrder.getPriceListId());

        if (priceList != null) {

            final LocalDate today = LocalDate.now();
            final LocalDate startDate = priceList.getStartOn() != null ? LocalDate.parse(priceList.getStartOn()) : LocalDate.MIN;
            final LocalDate endDate = priceList.getEndOn() != null ? LocalDate.parse(priceList.getEndOn()) : LocalDate.MAX;

            if (startDate.isAfter(today) || endDate.isBefore(today)) {
                return new LogicError(
                        Constants.FIELD_PRICE_LIST_ID,
                        "order.priceListOutOfDate",
                        null,
                        createParam("value", salesOrder.getPriceListDescription())
                );
            }
        }

        return null;
    }

    /**
     * Freight type can not be changed if there are products entered in the order.
     *
     * @param order
     * @return
     */
    public LogicError doValidateChangeIncoterms(final SalesOrder order) {
        return Optional.ofNullable(order)
                .map(SalesOrder::getId)
                .map(this.salesOrderDAO::findById)
                .filter(orderDb -> CollectionUtils.isNotEmpty(orderDb.getItems()))
                .filter(orderDb -> orderDb.getIncotermsAcronym() != order.getIncotermsAcronym())
                .map(orderDb -> new LogicError(Constants.FIELD_INCOTERMS_ACRONYM, Constants.MESSAGE_DELIVERY_CHANGE_INCOTERMS_NOT_ALLOWED))
                .orElse(null);
    }

    /**
     * Validates Currency in PriceList
     *
     * @param salesOrder
     * @return
     */
    public LogicError validateCurrencyAvailableInPriceList(final SalesOrder salesOrder) {
        final Boolean isCurrencyEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_CURRENCY_PLUGIN).getValue());

        if (   isCurrencyEnabled
                && Objects.nonNull(salesOrder.getPriceListId())
                && Objects.nonNull(salesOrder.getOrderCurrency())
                && Objects.nonNull(salesOrder.getOrderCurrency().getCurrencyId())) {

            final PriceList priceList = productGateway.getPriceList(salesOrder.getPriceListId());

            if (!priceList.getCurrencyId().equals(String.valueOf(salesOrder.getOrderCurrency().getCurrencyId()))) {
                return new LogicError("currencyId", "order.orderCurrency.doesNotBelongToPriceList");
            }
        }

        return null;
    }

    /**
     * Checks if the activity specified in the SalesOrder actually exists.
     * @param order the sales order to be validated.
     * @return a {@link LogicError} if the activity does not exist, null otherwise.
     */
    public LogicError validateActivityExists(final SalesOrder order) {

        if (order.getActivityId() != null && opportunityGateway.activityNotExists(order.getActivityId())) {
            return new LogicError(
                    "activityId",
                    "order.activity.notFound"
            );
        }

        return null;
    }

    private HashMap<String, Object> createParam(String paramKey, Object messageKey) {
        return new HashMap() {{
            put(paramKey, messageKey);
        }};
    }

    /**
     * Method to validate salesOrder and return a ConstraintViolationException and not a LogicValidation
     *
     * @since 8.6.0 2019-07-02
     * @author Peterson Schmitt
     *
     * @param salesOrder entity to validate
     */
    public void validateAndThrowFoundErrors(final SalesOrder salesOrder) {
        test(salesOrder);
        final Collection<ConstraintViolation<Object>> constraintViolations = getConstraintViolations(salesOrder);
        if (CollectionUtils.isNotEmpty(constraintViolations)) {
            throw new ConstraintViolationException(Sets.newHashSet(constraintViolations));
        }
    }
}
