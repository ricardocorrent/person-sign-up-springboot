package com.ws.sales.external.product;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.pagination.PagedList;
import com.ws.product.discount.DiscountResource;
import com.ws.product.model.*;
import com.ws.product.pricelist.PriceListResource;
import com.ws.product.pricelistitem.PriceListItemResource;
import com.ws.product.pricelistservice.PriceListServiceResource;
import com.ws.product.product.ProductResource;
import com.ws.product.service.ServiceResource;
import com.ws.sales.external.AbstractGateway;
import com.ws.sales.external.product.dto.CoefficientDTO;
import com.ws.sales.external.product.dto.DiscountDTO;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.orderitem.SalesOrderItem;
import org.apache.http.HttpStatus;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

import static java.util.Objects.nonNull;

/**
 * @author Marco Aurelio F. Schaefer
 * @since 2018-03-04 5.21.0
 */
public class ProductGateway extends AbstractGateway {

    @InjectProxy
    private PriceListResource priceListResource;

    @InjectProxy
    private PriceListItemResource priceListItemResource;

    @InjectProxy
    private PriceListServiceResource priceListServiceResource;

    @InjectProxy
    private ProductResource productResource;

    @InjectProxy
    private DiscountResource discountResource;

    @InjectProxy
    private ServiceResource serviceResource;

    /**
     * Method will search discounts on product microservice
     *
     * @param search object with filters to search
     * @return discounts
     */
    public List<DiscountDTO> searchDiscounts(final DiscountSearch search) {
        try {
            /**
             * The class {@link DiscountResource} has two search methods,
             * {@link DiscountResource#search(PaginationSearch)} and {@link DiscountResource#search2(DiscountSearch)},
             * both methods search in the same method in microservice of product.
             *
             * The difference between this methods is, {@link DiscountResource#search(PaginationSearch)}
             * expected a {@link PaginationSearch} and {@link DiscountResource#search2(DiscountSearch)}
             * exptected a {@link DiscountSearch}.
             *
             * {@link DiscountSearch} extends {@link PaginationSearch}, so it's possible use the
             * {@link DiscountResource#search(PaginationSearch)} method, but when using this method,
             * the microservice of Product, doesn't recognizes the content of the {@link DiscountSearch} object and
             * when using the {@link DiscountResource#search2(DiscountSearch)} the microservice of product recognize.
             */
            final Response response = discountResource.search2(search);

            if (response.getStatus() == HttpStatus.SC_OK) {
                final PagedList<DiscountDTO> pagedList = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<DiscountDTO>>() {
                });

                return pagedList.getItems();
            }
            return Collections.emptyList();
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * Method to get a price list from product service
     *
     * @param id id from price list
     * @return price list
     */
    public PriceList getPriceList(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(PriceList.class, id, priceListResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to get a price list item from product service
     *
     * @param id id from price list item
     * @return price list item
     */
    public PriceListItem getPriceListItem(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(PriceListItem.class, id, priceListItemResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to get a product from product service
     *
     * @param id id from product
     * @return product
     */
    public Product getProduct(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Product.class, id, productResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if price list exists
     *
     * @param id id to get price list
     * @return {@code true} if price list is exists, {@code false} otherwise
     */
    public Boolean priceListExists(final UUID id) {
        return getPriceList(id) != null;
    }

    /**
     * Method to return if product exists
     *
     * @param id id to get product
     * @return {@code true} if product is exists, {@code false} otherwise
     */
    public Boolean productExists(final UUID id) {
        return getProduct(id) != null;
    }

    /**
     * Method to return if product exists
     *
     * @since 8.5.0 2019-06-21
     * @author Ricardo Corrent
     *
     * @param id id to get service
     * @return {@code true} if service is exists, {@code false} otherwise
     */
    public Boolean serviceExists(final UUID serviceId) {
        return getService(serviceId) != null;
    }

    /**
     * Search for price list items filtering by price list, customer and company
     *
     * @param salesOrder order to get information for filters
     * @return price list items
     */
    public List<PriceListItem> findItemsPriceListById(final SalesOrder salesOrder) {
        try {
            final Response response = priceListItemResource.search(getSearchItemsPriceList(salesOrder));
            if (response.getStatus() == HttpStatus.SC_OK && response.hasEntity()) {
                final PagedList<PriceListItem> pagedList = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<PriceListItem>>() {
                });
                return pagedList.getItems();
            }
            return new ArrayList<>();
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * Search for price list items filtering by price list id and product id
     *
     * @param salesOrderItem order to get information for filters
     * @return price list items
     */
    public List<PriceListItem> findItemsPriceListById(final SalesOrderItem salesOrderItem) {
        try {
            final Response response = priceListItemResource.search(getSearchItemsPriceList(salesOrderItem));
            if (response.getStatus() == HttpStatus.SC_OK && response.hasEntity()) {
                final PagedList<PriceListItem> pagedList = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<PriceListItem>>() {});
                return pagedList.getItems();
            }
            return new ArrayList<>();
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * Mounts the filter for querying price list items
     *
     * @param salesOrderItem
     * @return
     */
    private PriceListItemSearch getSearchItemsPriceList(final SalesOrderItem salesOrderItem) {
        final PriceListItemSearch search = new PriceListItemSearch();
        //unfortunately the price list of items is being instantiated within the get method,
        // putting a if, when it is fixed will not give error
        if (Objects.nonNull(search.getPriceListIds())){
            search.getPriceListIds().add(salesOrderItem.getPriceListId().toString());
        } else {
            search.setPriceListId(salesOrderItem.getPriceListId().toString());
        }
        search.setProductId(salesOrderItem.getProductId().toString());
        search.setPageSize(5000);
        return search;
    }


    /**
     * Mounts the filter for querying price list items
     *
     * @param salesOrder
     * @return
     */
    private PriceListItemSearch getSearchItemsPriceList(final SalesOrder salesOrder) {
        final PriceListItemSearch search = new PriceListItemSearch();
        search.setPriceListId(salesOrder.getPriceListId().toString());
        search.setCustomerId(salesOrder.getCustomerId().toString());
        search.setCompanyId(salesOrder.getCompanyId().toString());
        search.setPageSize(5000);
        return search;
    }

    /**
     * Method to return if price list is active
     *
     * @param id id to get price list
     * @return {@code true} if price list is active, {@code false} otherwise
     */
    public Boolean priceListIsActive(final UUID id) {
        final PriceList priceList = this.getPriceList(id);
        if (priceList != null) {
            return priceList.isActive();
        }
        return Boolean.TRUE;
    }

    /**
     * Method to get due date value from product service
     *
     * @param priceListId        price list id to get due date coefficient
     * @param dueDateCoefficient due date coefficient to find value
     * @return due date value
     */
    public BigDecimal getDueDateValue(final String priceListId, final DueDateCoefficient dueDateCoefficient) {
        final Response response = priceListResource.getDueDateCoefficient(priceListId, dueDateCoefficient);
        if (response.getStatus() == HttpStatus.SC_OK) {
            final CoefficientDTO coefficientDTO = getEntityFromResponse(response, CoefficientDTO.class);
            return coefficientDTO != null ? coefficientDTO.getCoefficient() : BigDecimal.ONE;
        }
        return BigDecimal.ONE;
    }

    public Boolean priceListCanBeUsed(final PriceListSearch priceListSearch, final UUID priceListId) {
        try {
            final Response response = priceListResource.getPriceListsByProduct(priceListSearch);

            if (response.getStatus() == HttpStatus.SC_OK) {
                final PagedList<HashMap> pagedList = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<HashMap>>() {
                });

                return pagedList.getItems()
                        .stream()
                        .map(key -> (HashMap) key.get("priceList"))
                        .anyMatch(key -> key.get("id").equals(priceListId.toString()));
            }

            return Boolean.FALSE;
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * Gets a service from a specific price list.
     *
     * @param priceListId the id of the price list.
     * @param serviceId   the id of the service to get.
     * @return the price list service or <code>null</code> if the service does not belong to the
     * price list.
     */
    public PriceListService getServiceFromPriceList(final UUID priceListId, final UUID serviceId) {
        final PriceList priceList = getPriceList(priceListId);
        final List<PriceListService> services = priceList.getServices();

        return services
                .stream()
                .filter(service -> service.getService().getId().equals(serviceId.toString()))
                .findFirst()
                .orElse(null);
    }

    /**
     * Gets a service from the Product gateway.
     *
     * @param serviceId the id of the service to get.
     * @return the service object, parsed from the JSON returned.
     */
    public Service getService(final UUID serviceId) {
        if (serviceId != null) {
            return getEntityFromGatewayCall(Service.class, serviceId, serviceResource::get, serviceId.toString());
        }
        return null;
    }

}
