package com.ws.sales.situation;

import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.logicvalidation.LogicValidator;

/**
 * @author thyago.volpatto
 * @since v5.1.0 19/04/2017.
 */
@BeanValidationIntegrated(Situation.class)
public class SituationValidation extends LogicValidator<Situation> {

}
