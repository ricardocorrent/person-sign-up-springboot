package com.ws.sales.orderintegration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.product.dto.PackagingDTO;
import com.ws.sales.external.product.dto.ProductDTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * @author Peterson Schmitt
 * @since 8.6.0 2019-06-27
 */
@Getter
@Setter
public class ProductIntegrationDTO  extends BaseDTO {

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "product.id", target = "productId"),
    })
    private ProductDTO product;

    private BigDecimal quantity;

    private BigDecimal originalPrice;

    private BigDecimal salesPrice;

    private BigDecimal discountValue;

    private BigDecimal discountPercentage;

    private BigDecimal increaseValue;

    private BigDecimal totalItem;

    private BigDecimal increasePercentage;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "packaging.id", target = "productPackagingId"),
            @PojoColumnMapper(source = "packaging.description", target = "productPackagingDescription")
    })
    private PackagingDTO packaging;

    private String externalId;

}
