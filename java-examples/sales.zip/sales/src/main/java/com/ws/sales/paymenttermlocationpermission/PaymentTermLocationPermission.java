package com.ws.sales.paymenttermlocationpermission;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.sales.paymentterm.PaymentTerm;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
@Entity
@PreventRecycling
public class PaymentTermLocationPermission extends PhysicalDeleteBaseEntity implements IPojoConverter {

    @ManyToOne
    @JoinColumn(name = "payment_term_id")
    @JsonBackReference
    @NotNull
    private PaymentTerm paymentTerm;

    @NotNull
    @PojoColumnMapper(target = "location.id")
    private UUID locationId;

    @NotNull
    @Size(max = 255)
    @PojoColumnMapper(target = "location.description")
    private String locationDescription;

    /**
     * Get of property {@link #paymentTerm}
     *
     * @return com.ws.sales.paymentterm.PaymentTerm
     */
    public PaymentTerm getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * Set of property {@link #paymentTerm}
     *
     * @param paymentTerm field to set
     */
    public void setPaymentTerm(final PaymentTerm paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    /**
     * Get of property {@link #locationId}
     *
     * @return java.util.UUID
     */
    public UUID getLocationId() {
        return locationId;
    }

    /**
     * Set of property {@link #locationId}
     *
     * @param locationId field to set
     */
    public void setLocationId(final UUID locationId) {
        this.locationId = locationId;
    }

    /**
     * Get of property {@link #locationDescription}
     *
     * @return java.lang.String
     */
    public String getLocationDescription() {
        return locationDescription;
    }

    /**
     * Set of property {@link #locationDescription}
     *
     * @param locationDescription field to set
     */
    public void setLocationDescription(final String locationDescription) {
        this.locationDescription = locationDescription;
    }
}
