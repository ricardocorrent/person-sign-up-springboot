package com.ws.sales.external.administration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.io.Serializable;

/**
 * Created by sergio.junior on 10/13/2017.
 */
public class CompanyDTO extends BaseDTO implements DefaultPojoConverter, Serializable {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
