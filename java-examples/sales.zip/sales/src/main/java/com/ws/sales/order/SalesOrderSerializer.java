package com.ws.sales.order;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Created by thyago.volpatto on 06/03/2017.
 */
public class SalesOrderSerializer extends StdSerializer<SalesOrder> {

    /**
     * default contructor to SalesOrderSerializer
     */
    public SalesOrderSerializer() {
        this(null);
    }

    /**
     * initialize a SalesOrderSerializer with a Class param.
     *
     * @param t
     */
    protected SalesOrderSerializer(Class<SalesOrder> t) {
        super(t);
    }

    /**
     * Generates a serialized Item
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(SalesOrder value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        SalesOrder item = new SalesOrder();
        item.setId(value.getId());


        gen.writeObject(item);
    }
}
