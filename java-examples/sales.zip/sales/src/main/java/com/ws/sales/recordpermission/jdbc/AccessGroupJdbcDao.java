package com.ws.sales.recordpermission.jdbc;

import com.sollar.recordpermission.accessgroup.AccessGroup;
import io.ebean.*;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.inject.Inject;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Stream;

public class AccessGroupJdbcDao {

    private final EbeanServer ebean;

    @Inject
    public AccessGroupJdbcDao(final EbeanServer ebean) {
        this.ebean = ebean;
    }

    public void save(final AccessGroup accessGroup,
                     final boolean updateUpdatedAt) {
        final boolean exists = exists(accessGroup.getId());
        if (exists) {
            update(accessGroup, updateUpdatedAt);
        } else {
            insert(accessGroup);
        }
    }

    private void insert(final AccessGroup accessGroup) {
        final List<UUID> entityIds = accessGroup.getEntityIds();
        accessGroup.setEntityIds(Collections.emptyList());
        ebean.insert(accessGroup);
        runNativeProcedure(accessGroup.getId(), entityIds);
    }

    private void update(final AccessGroup accessGroup,
                        final boolean updateUpdatedAt) {


        final StringBuilder sql = new StringBuilder();
        final List<Object> parameters = new LinkedList<>();

        sql.append("update access_group set version = ?, group_name = ?, user_id = ?, all_records = ?, group_type = ?");
        parameters.add(accessGroup.getVersion());
        parameters.add(accessGroup.getGroupName());
        parameters.add(accessGroup.getUserId());
        parameters.add(accessGroup.getAllRecords());
        parameters.add(accessGroup.getGroupType());

        if (updateUpdatedAt) {
            sql.append(", updated_at = ?");
            parameters.add(accessGroup.getUpdatedAt());
        }

        sql.append(" where id = ?");
        parameters.add(accessGroup.getId());

        try (final PreparedStatement statement = ebean.currentTransaction().getConnection().prepareStatement(sql.toString())) {

            for (int index = 0; index < parameters.size(); index++) {
                statement.setObject(index + 1, parameters.get(index));
            }

            statement.executeUpdate();
            runNativeProcedure(accessGroup.getId(), accessGroup.getEntityIds());
        } catch (final SQLException ex) {
            ExceptionUtils.rethrow(ex);
        }

    }

    private void runNativeProcedure(final UUID id, final List<UUID> entityIds) {
        final String sql = "SELECT cloudextensions.update_access_group_entity_ids(?, ?)";
        final Connection connection = ebean.currentTransaction().getConnection();
        try (final PreparedStatement statement = connection.prepareStatement(sql)) {
            final UUID[] idsArray = Optional.ofNullable(entityIds)
                    .map(List::stream)
                    .orElse(Stream.empty())
                    .toArray(UUID[]::new);
            final Array idsJdbcArray = connection.createArrayOf("uuid", idsArray);

            statement.setObject(1, id);
            statement.setArray(2, idsJdbcArray);
            statement.execute();
        } catch (final SQLException ex) {
            ExceptionUtils.rethrow(ex);
        }

    }

    private boolean exists(final UUID id) {
        return ebean
                .createQuery(AccessGroup.class)
                .where()
                .idEq(id)
                .findCount() > 0;
    }

}
