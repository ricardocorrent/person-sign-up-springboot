package com.ws.sales.order.dto;

import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 8.3.0 2019-05-21
 */
public class IdDTO {
    private UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }
}
