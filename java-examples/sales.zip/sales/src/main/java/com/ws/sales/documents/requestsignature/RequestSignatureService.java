package com.ws.sales.documents.requestsignature;

import com.ws.commons.server.messagebundle.MessageBundle;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.documents.*;
import com.ws.sales.documents.dto.TemplateDTO;
import com.ws.sales.external.integrationhub.documentsign.DigitalDocSignatureResponse;
import com.ws.sales.external.integrationhub.documentsign.DigitalDocSignatureService;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.signeddocument.SalesOrderSignedDocument;
import com.ws.sales.signeddocument.SalesOrderSignedDocumentService;

import java.io.IOException;
import java.util.UUID;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import com.ws.sales.util.Constants;

/**
 * Service class to manage requests from external resources or services for {@link SalesOrderSignedDocument}.
 *
 * @since 8.3.0 2019-05-03
 *
 * @author Ricardo Corrent
 */
public class RequestSignatureService {

    private static final int FILENAME_POSITION = 1;
    private static final int FILENAME_LABEL_LENGHT = 10;

    private final RequestSignatureValidator requestSignatureValidator;
    private final DocumentService documentService;
    private final DigitalDocSignatureService digitalDocSignatureService;
    private final SalesOrderSignedDocumentService signedDocumentService;
    private final DocumentGateway documentGateway;
    private final MessageBundle messageBundle;
    private final SalesOrderService salesOrderService;

    @Context
    private HttpServletRequest httpServletRequest;

    /**
     * Inject constructor required to perform requests.
     *
     * @param requestSignatureValidator Instance of {@link RequestSignatureValidator} to validate the input
     * @param documentService Instance of {@link DocumentService} to create documents
     * @param digitalDocSignatureService feature that receive request to sign document
     * @param signedDocumentService used to persist the response of {@link DigitalDocSignatureService} on database
     * @param documentGateway used to make a communication between sales api and document-manager api.
     * @param messageBundle used to get a internationalized message.
     * @param salesOrderService used to get a salesOrder
     */
    @Inject
    public RequestSignatureService(final RequestSignatureValidator requestSignatureValidator,
                                   final DocumentService documentService,
                                   final DigitalDocSignatureService digitalDocSignatureService,
                                   final SalesOrderSignedDocumentService signedDocumentService,
                                   final DocumentGateway documentGateway,
                                   final MessageBundle messageBundle,
                                   final SalesOrderService salesOrderService) {
        this.requestSignatureValidator = requestSignatureValidator;
        this.documentService = documentService;
        this.digitalDocSignatureService = digitalDocSignatureService;
        this.signedDocumentService = signedDocumentService;
        this.documentGateway = documentGateway;
        this.messageBundle = messageBundle;
        this.salesOrderService = salesOrderService;
    }

    /**
     * Method used to send document to sign using integration-hub
     *
     * @param requestSignatureDTO {@link RequestSignatureDTO}
     * @return {@link SalesOrderSignedDocument} to persist in database
     * @throws Exception if send request returns error
     */
    public SalesOrderSignedDocument sendRequestSignature(final RequestSignatureDTO requestSignatureDTO) throws Exception {
        final SalesOrder salesOrder = this.getSalesOrder(requestSignatureDTO.getSalesOrderId());
        this.requestSignatureValidator.validate(requestSignatureDTO);

        if (this.requestSignatureValidator.messageIsNullOrEmpty(requestSignatureDTO)) {
            requestSignatureDTO.setMessage(this.getEmailMessage());
        }

        return insertSignedDocument(salesOrder, requestSignatureDTO);
    }

    /**
     * This method returns a valid {@link SalesOrder}
     *
     * @param orderId {@link UUID}
     * @return a valid {@link SalesOrder}
     */
    private SalesOrder getSalesOrder(final UUID orderId) {
        return this.salesOrderService.get(orderId);
    }

    /**
     * This method gets a default email message from message files
     *
     * @return {@link String} with the email message.
     */
    private String getEmailMessage() {
        return this.messageBundle.getMessage(Constants.FIELD_DOCUMENT_EMAIL_MESSAGE, httpServletRequest.getLocale()).getMessage();
    }

    /**
     * this method is used to construct a {@link Document}
     * @param salesOrder {@link UUID}
     * @param requestSignatureDTO {@link RequestSignatureDTO}
     * @return {@link Document}
     * @throws Exception if there is an error in the documentService
     */
    private Document buildDocument(final SalesOrder salesOrder, final RequestSignatureDTO requestSignatureDTO) throws Exception {
        final DocumentSaleCreator documentSaleCreator = this.buildDocumentSaleCreator(requestSignatureDTO);
        return this.documentService.createDocument(salesOrder, documentSaleCreator);
    }

    /**
     * This method is used to construct a {@link DigitalDocSignatureResponse}
     *
     * @param document {@link Document}
     * @param requestSignatureDTO {@link RequestSignatureDTO} with information about document
     * @return {@link DigitalDocSignatureResponse}
     * @throws IOException if transforming to toByteArray is an error
     */
    private DigitalDocSignatureResponse sendsDigitalDocumentToBeSigned(final Document document,
                                                                       final RequestSignatureDTO requestSignatureDTO) throws IOException {
        return this.digitalDocSignatureService.sendDocumentToSign(document, requestSignatureDTO);
    }

    /**
     * This method is used to insert a {@link SalesOrderSignedDocument}
     *
     * @param salesOrder used in {@link SalesOrderSignedDocument} instance
     * @param requestSignatureDTO used in {@link SalesOrderSignedDocument} instance
     * @return {@link SalesOrderSignedDocument} contains information about document signed
     */
    private SalesOrderSignedDocument insertSignedDocument(final SalesOrder salesOrder,final RequestSignatureDTO requestSignatureDTO) throws Exception{
        SalesOrderSignedDocument salesOrderSignedDocument = this.getSalesOrderSignedDocument(salesOrder, requestSignatureDTO);
        return this.signedDocumentService.insert(salesOrderSignedDocument);
    }


    /**
     * This method request the creation of {@link SalesOrderSignedDocument}
     *
     * @param salesOrder {@link SalesOrder}
     * @param requestSignatureDTO {@link RequestSignatureDTO}
     * @return {@link SalesOrderSignedDocument}
     * @throws Exception If an error occurred while building {@link Document}
     */
    private SalesOrderSignedDocument getSalesOrderSignedDocument(final SalesOrder salesOrder, final RequestSignatureDTO requestSignatureDTO) throws Exception {
        final Document document = this.buildDocument(salesOrder, requestSignatureDTO);
        final DigitalDocSignatureResponse digitalDocSignatureResponse = this.sendsDigitalDocumentToBeSigned(document, requestSignatureDTO);
        return this.buildSalesOrderSignedDocument(salesOrder, requestSignatureDTO, document, digitalDocSignatureResponse);
    }

    /**
     * This method build a {@link SalesOrderSignedDocument}
     *
     * @param salesOrder {@link SalesOrder}
     * @param requestSignatureDTO {@link RequestSignatureDTO}
     * @param document {@link Document}
     * @param digitalDocSignatureResponse {@link DigitalDocSignatureResponse}
     * @return a instance of {@link SalesOrderSignedDocument}
     */
    private SalesOrderSignedDocument buildSalesOrderSignedDocument(final SalesOrder salesOrder,
                                                                   final RequestSignatureDTO requestSignatureDTO,
                                                                   final Document document,
                                                                   final DigitalDocSignatureResponse digitalDocSignatureResponse) {
        final SalesOrderSignedDocument signedDocument = new SalesOrderSignedDocument();
        signedDocument.setSalesOrder(salesOrder);
        signedDocument.setDocumentId(digitalDocSignatureResponse.getDocumentId());
        signedDocument.setDocumentName(this.getDocumentName(document));
        signedDocument.setMessage(requestSignatureDTO.getMessage());
        signedDocument.setRejectable(requestSignatureDTO.getRejectable());
        signedDocument.setTemplateDescription(getTemplateDescription(requestSignatureDTO.getTemplateId()));
        return signedDocument;
    }

    /**
     * This method gets a file name from {@link Document}
     * @param document {@link Document}
     * @return a file name type {@link String}
     */
    private String getDocumentName(final Document document) {
        return document.getFilename()
                .split(";")[FILENAME_POSITION]
                .substring(FILENAME_LABEL_LENGHT)
                .replaceAll("^\"|\"$", "");
    }

    /**
     * Method used to get a template.
     *
     * @param templateId {@link UUID}
     * @return {@link String} if exists template
     */
    private String getTemplateDescription(final UUID templateId) {
        final TemplateDTO template = this.documentGateway.getTemplate(templateId);
        if (template != null && !template.getDescription().isEmpty()) {
            return template.getDescription();
        }
        throw new RegisterNotFoundException();
    }

    /**
     * Method to construct a {@link DocumentSaleCreator} to be used on construct a {@link Document}.
     *
     * @param requestSignatureDTO {@link RequestSignatureDTO} with information about document
     * @return {@link DocumentSaleCreator}
     */
    private DocumentSaleCreator buildDocumentSaleCreator(final RequestSignatureDTO requestSignatureDTO) {
        final DocumentSaleCreator documentSaleCreator = new DocumentSaleCreator();
        if (requestSignatureDTO.getFileName() != null) {
            documentSaleCreator.setName(requestSignatureDTO.getFileName());
        }
        documentSaleCreator.setTemplateId(requestSignatureDTO.getTemplateId());
        documentSaleCreator.setFormat(DocumentCreatorFormat.PDF);
        return documentSaleCreator;
    }
}
