package com.ws.sales.order;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.exception.MessageException;
import com.ws.sales.deliveryorder.DeliveryOrder;
import com.ws.sales.deliveryorder.DeliveryOrderDAO;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.external.financial.FinancialService;
import com.ws.sales.external.product.ProductService;
import com.ws.sales.external.service.ServiceDTO;
import com.ws.sales.external.service.ServiceGateway;
import com.ws.sales.order.enums.OrderOrigin;
import com.ws.sales.order.enums.SalesValidationType;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.orderinstalment.SalesOrderInstalment;
import com.ws.sales.orderinstalment.SalesOrderInstalmentDAO;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderitem.SalesOrderItemDAO;
import com.ws.sales.orderservice.SalesOrderServiceDAO;
import com.ws.sales.ordersituation.SalesOrderSituation;
import com.ws.sales.situation.Situation;
import com.ws.sales.situation.SituationDAO;
import com.ws.sales.situation.SituationSearch;
import com.ws.sales.util.Constants;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;
import org.lindberg.jpa.entitycloner.persistence.EntityCloner;

import javax.inject.Inject;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;
import java.util.*;

/**
 * @since v1.0.0 2016-08-29.
 * @version 8.5.0 2019-06-18
 *
 * @author Thyago Volpatto
 * @author Marcos Matheus de Andrade
 * @author Maykon Rissi
 * @author Ricardo Corrent
 */
public class SalesOrderService extends AbstractService<SalesOrder> {

    private final SalesOrderValidator salesOrderValidator;
    private final SituationDAO situationDAO;
    private final FinancialService financialService;
    private final ProductService productService;
    private final ServiceGateway serviceGateway;
    private final UserContext userContext;
    private final SalesOrderHeaderValidator salesOrderHeaderValidator;
    private final SalesOrderItemDAO salesOrderItemDAO;
    private final SalesOrderServiceDAO salesOrderServiceDAO;
    private final DeliveryOrderDAO deliveryOrderDAO;
    private final SalesOrderInstalmentDAO salesOrderInstalmentDAO;

    /**
     * @since v1.0.0 2016-08-29
     *
     * @author Thyago Volpatto
     * @author Marcos Matheus de Andrade
     * @author Maykon Rissi
     * @author Ricardo Corrent
     *
     * @param dao                       to handle order database operations
     * @param salesOrderValidator       to validate the order
     * @param situationDAO              to search the situations
     * @param financialService          to handle {@link com.ws.financial.model.CreditLimit} and {@link com.ws.financial.model.CreditLimitMovement} operations
     * @param productService            to handle dueDate methods
     * @param userContext               to get context
     * @param serviceGateway            to handle service
     * @param salesOrderHeaderValidator to handle header
     * @param salesOrderItemDAO         to insert items in sales order copy
     * @param salesOrderServiceDAO      to insert services in sales order copy
     * @param deliveryOrderDAO          to insert deliveries in sales order copy
     * @param salesOrderInstalmentDAO   to insert instalments in sales order copy
     */
    @Inject
    public SalesOrderService(final SalesOrderDAO dao,
                             final SalesOrderValidator salesOrderValidator,
                             final SituationDAO situationDAO,
                             final FinancialService financialService,
                             final ProductService productService,
                             final UserContext userContext,
                             final ServiceGateway serviceGateway,
                             final SalesOrderHeaderValidator salesOrderHeaderValidator,
                             final SalesOrderItemDAO salesOrderItemDAO,
                             final SalesOrderServiceDAO salesOrderServiceDAO,
                             final DeliveryOrderDAO deliveryOrderDAO,
                             final SalesOrderInstalmentDAO salesOrderInstalmentDAO) {

        super(dao);
        this.salesOrderValidator = salesOrderValidator;
        this.situationDAO = situationDAO;
        this.financialService = financialService;
        this.productService = productService;
        this.serviceGateway = serviceGateway;
        this.userContext = userContext;
        this.salesOrderHeaderValidator = salesOrderHeaderValidator;
        this.salesOrderItemDAO = salesOrderItemDAO;
        this.salesOrderServiceDAO = salesOrderServiceDAO;
        this.deliveryOrderDAO = deliveryOrderDAO;
        this.salesOrderInstalmentDAO = salesOrderInstalmentDAO;
    }

    /**
     * @param salesOrder to insert
     * @author Marcos Matheus de Andrade
     * @see AbstractService#insert(BaseModel)
     * @since v4.0.0
     */
    @Override
    public SalesOrder insert(final SalesOrder salesOrder) throws Exception {
        this.doGenerateInsertValues(salesOrder);
        final UUID userId = UUID.fromString((String) userContext.getSession().getAttribute("user_id"));
        this.linkOrderToServiceInExecution(salesOrder, userId);
        return super.insert(salesOrder);
    }

    /**
     * Checks if there is a service currently in execution and associates it to the order.
     *
     * @param salesOrder the order being created.
     * @param userId     the user that is doing the service.
     */
    private void linkOrderToServiceInExecution(final SalesOrder salesOrder, final UUID userId) throws IOException {
        final ServiceDTO serviceInExecution = serviceGateway.getServiceInExecution(userId);

        if (serviceInExecution != null) {
            // Check if the customer and location are the same too
            final UUID serviceCustomerId = serviceInExecution.getCustomer().getId();
            final UUID serviceLocationId = serviceInExecution.getLocation().getId();

            final UUID orderCustomerId = salesOrder.getCustomerId();
            final UUID orderLocationId = salesOrder.getLocationId();

            if (orderCustomerId.equals(serviceCustomerId) && orderLocationId.equals(serviceLocationId)) {
                salesOrder.setServiceId(serviceInExecution.getId());
            }
        }
    }

    /**
     * @param orderFromParam to insert
     * @author Marcos Matheus de Andrade
     * @see AbstractService#insert(BaseModel)
     * @since v5.0.0
     */
    public void updateHeader(final SalesOrder orderFromParam) throws Exception {
        final SalesOrder dbOrder = this.get(orderFromParam.getId());
        final SalesOrder orderToUpdate = doHandleCloneOfHeaderInformation(orderFromParam, dbOrder);
        this.doValidate(orderToUpdate, SalesValidationType.UPDATE_HEADER);
        this.updateItemsUsingDueDate(orderToUpdate, dbOrder);
        orderToUpdate.setDraft(Boolean.TRUE);
        super.update(orderToUpdate);
    }

    /**
     * This method wont validate the order, it will only set the origin do external and persist
     *
     * @param salesOrder to insert
     * @author Maykon Rissi
     * @see AbstractService#insert(BaseModel)
     * @since v4.0.0
     */
    public SalesOrder insertForIntegration(final SalesOrder salesOrder) throws Exception {
        doValidateIntegration(salesOrder, SalesValidationType.INTEGRATION);
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setOrderNumber(this.doGenerateNewOrderNumber(salesOrder));
        return super.insert(salesOrder);
    }

    private void doValidateIntegration(final SalesOrder salesOrder, final SalesValidationType integration) {
        salesOrderValidator.validate(salesOrder, integration);
        salesOrderValidator.throwFoundErrors();
    }

    /**
     * @param id from order to delete
     * @author Peterson Schmitt
     * @see AbstractService#delete(UUID)
     * @since v8.6.0
     */
    public void deleteForIntegration(UUID id) throws Exception {
        super.delete(id);
    }

    /**
     * @param salesOrder to update
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v4.0.0
     */
    @Override
    public void update(final SalesOrder salesOrder) throws Exception {
        salesOrderHeaderValidator.validateAndThrowFoundErrors(salesOrder);
        final SalesOrder dbOrder = this.get(salesOrder.getId());
        Objects.requireNonNull(dbOrder, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entity"));
        final SalesOrder orderToUpdate = doHandleCloneOfHeaderInformation(salesOrder, dbOrder);
        this.updateItemsUsingDueDate(orderToUpdate, dbOrder);
        orderToUpdate.setDraft(Boolean.TRUE);
        super.update(orderToUpdate);
    }

    /**
     *
     * Method for updating externalNumber, situation, externalId, exportedAt from sales order already finalized.
     *
     * @param salesOrder the order being created.
     *
     * @author Diogo Melo
     *
     * @since v8.0.0 2019-05-30
     */
    public void updateFinishedOrder(final SalesOrder salesOrder) throws Exception {
        final SalesOrder dbOrder = this.get(salesOrder.getId());
        doMergeForUpdateFinishedOrder(salesOrder, dbOrder);
        if (salesOrder.getSituationId() != null) {
            this.updateOrderSituationWithExternalSituation(salesOrder);
        }
        super.update(salesOrder);
    }

    /**
     * Method to get external situation of sales order
     *
     * @param salesOrder the order being created.
     *
     * @author Diogo Melo
     *
     * @since v8.0.0 2019-05-30
     */
    public void updateOrderSituationWithExternalSituation(final SalesOrder salesOrder) {
        final SalesOrderSituation situation = new SalesOrderSituation();
        situation.setSituationId(salesOrder.getSituationId());
        situation.setSituationDescription(salesOrder.getSituationDescription());
        this.doFillSituationsFieldsInSalesOrder(salesOrder, situation);
    }

    /**
     * This method wont validate the order, it will only persist
     *
     * @param salesOrder to update
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v4.0.0
     */
    public void updateForIntegration(final SalesOrder salesOrder, final RestQueryAdapter restQueryAdapter) throws Exception {
        doValidateIntegration(salesOrder, SalesValidationType.INTEGRATION);
        deleteSalesOrderItems(salesOrder.getId(), restQueryAdapter);
        deleteSalesOrderServices(salesOrder.getId(), restQueryAdapter);
        super.update(salesOrder);
    }

    /**
     * Delete all services before updateing
     *
     * @author Peterson Schmitt
     * @since 8.6.0 2019-06-27
     */
    private void deleteSalesOrderServices(final UUID salesOrderId, final RestQueryAdapter restQueryAdapter) {
        List<com.ws.sales.orderservice.SalesOrderService> services = salesOrderServiceDAO.findByOrder(salesOrderId, restQueryAdapter).getItems();
        if(services != null){
            services.forEach(service -> {
                salesOrderServiceDAO.delete(service.getId());
            });
        }
    }
    /**
     * Delete all items before updateing
     *
     * @author Peterson Schmitt
     * @since 8.6.0 2019-06-27
     */
    private void deleteSalesOrderItems(final UUID salesOrderId, final RestQueryAdapter restQueryAdapter) {
        List<SalesOrderItem> items = salesOrderItemDAO.findByOrder(salesOrderId, restQueryAdapter).getItems();
        if(items != null) {
            items.forEach(item -> {
                salesOrderItemDAO.delete(item.getId());
            });
        }
    }

    /**
     * @param order to update
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v4.0.0
     */
    public void updateComplement(final SalesOrder order) throws Exception {
        final SalesOrder salesOrder = super.get(order.getId());
        salesOrder.setComplement(order.getComplement());
        this.doValidate(salesOrder, SalesValidationType.COMPLEMENT);
        super.update(salesOrder);
    }

    /**
     * This method wont validate the order, it will set the external id and persist
     *
     * @param orderId    from order to update
     * @param externalId to set in the order
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v4.0.0
     */
    public void updateExternalId(final String orderId, final String externalId) throws Exception {
        final SalesOrder salesOrder = super.get(UUID.fromString(orderId));
        salesOrder.setExternalId(externalId);
        super.update(salesOrder);
    }

    /**
     * This method wont validate the order, it will set the external situation and persist
     *
     * @param orderId           from order to update
     * @param externalSituation to set in the order
     * @author Maykon Rissi
     * @see AbstractService#update(BaseModel)
     * @since v4.0.0
     */
    public void updateExternalSituation(final String orderId, final SalesOrderSituation externalSituation) throws Exception {
        final SalesOrder salesOrder = super.get(UUID.fromString(orderId));
        this.doFillSituationsFieldsInSalesOrder(salesOrder, externalSituation);
        super.update(salesOrder);
    }

    /**
     * @param id from order to finalize
     * @author Maykon Rissi
     * @see AbstractService#delete(UUID)
     * @since v4.0.0
     */
    @Override
    public void delete(UUID id) throws Exception {
        final SalesOrder salesOrder = super.get(id);
        this.doValidate(salesOrder, SalesValidationType.DELETE);
        super.delete(id);
    }

    /**
     * Handle the finalization for order. It will validate, set the situation and, if the plugin is active,
     * update the {@link com.ws.financial.model.CreditLimit} and insert a new {@link com.ws.financial.model.CreditLimitMovement}
     *
     * @since v4.0.0
     * @version v8.5.0
     *
     * @author Maykon Rissi
     * @author Hellinton Klein
     *
     * @param orderId to finalize
     */
    public void doFinalizeOrder(final UUID orderId) throws Exception {
        final SalesOrder orderToFinalize = super.get(orderId);
        this.doValidate(orderToFinalize, SalesValidationType.FINALIZATION);
        this.doHandleSituationForOrder(orderToFinalize);
        orderToFinalize.setDraft(Boolean.FALSE);
        orderToFinalize.setOrderedAt(OffsetDateTime.now());
        this.financialService.updateCreditLimit(orderToFinalize);
        super.update(orderToFinalize);
    }

    /**
     * @param parameters for the search
     * @author Maykon Rissi
     * @since v4.0.0
     */
    public PagedList<SalesOrder> search(final SalesOrderSearch parameters) {
        return ((SalesOrderDAO) this.dao).list(parameters);
    }

    /**
     * Sets the values of origin, draft, insertedAt, id and orderNumber
     *
     * @param salesOrder to set values
     * @author Maykon Roberto Rissi
     * @since v6.1.0
     */
    private void doGenerateInsertValues(final SalesOrder salesOrder) throws DecoderException {
        salesOrder.setInsertedAt(OffsetDateTime.now());
        salesOrder.setOrigin(isOrigin(salesOrder.getOrigin()));
        salesOrder.setDraft(Boolean.TRUE);
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setOrderNumber(this.doGenerateNewOrderNumber(salesOrder));
    }

    /**
     * Load the order from database, recalculate the values from items and deliveries then persist again.
     *
     * @param orderId from the order to update.
     * @author Maykon Roberto Rissi
     * @since v5.0.0
     */
    public void updateOrderTotalValue(final UUID orderId) throws Exception {
        final SalesOrder salesOrder = super.get(orderId);
        salesOrder.setProductTotalValue(this.calculateOrderProductTotalValue(salesOrder));
        salesOrder.setServiceTotalValue(this.calculateOrderServiceTotalValue(salesOrder));
        salesOrder.setNetValue(this.doCalculateOrderTotalValue(salesOrder));
        super.update(salesOrder);
    }

    /**
     * Get the pending situation from database, convert it to {@link SalesOrderSituation} and fill the order.
     *
     * @param orderToFinalize to set the situation
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-15
     */
    private void doHandleSituationForOrder(final SalesOrder orderToFinalize) {
        final Situation pendingSituation = this.getPendentSituation();
        final SalesOrderSituation pendingSalesOrderSituation = this.doGenerateSalesOrderSituation(pendingSituation);
        this.doFillSituationsFieldsInSalesOrder(orderToFinalize, pendingSalesOrderSituation);
    }

    /**
     * @param situation to fill the entity
     * @return {@link SalesOrderSituation} filled with situation values
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-15
     */
    private SalesOrderSituation doGenerateSalesOrderSituation(final Situation situation) {
        final SalesOrderSituation salesOrderSituation = new SalesOrderSituation();
        salesOrderSituation.setSituationId(situation.getId());
        salesOrderSituation.setSituationDescription(situation.getDescription());
        salesOrderSituation.setStartedOn(OffsetDateTime.now());
        return salesOrderSituation;
    }

    /**
     * Fills {@link SalesOrder#setSituationId(UUID)}, {@link SalesOrder#setSituationDescription(String)} and add in the
     * {@link SalesOrder#setSalesOrderSituations(List)} with the rank
     *
     * @param salesOrder to set the situation
     * @param situation  to get information and fill the order
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-15
     */
    private void doFillSituationsFieldsInSalesOrder(final SalesOrder salesOrder, final SalesOrderSituation situation) {
        final List<SalesOrderSituation> situationsFromOrder = salesOrder.getSalesOrderSituations();
        final BigDecimal situationRank = BigDecimal.valueOf(situationsFromOrder.size() + 1);
        situation.setRank(situationRank);
        situationsFromOrder.add(situation);
        salesOrder.setSituationId(situation.getSituationId());
        salesOrder.setSituationDescription(situation.getSituationDescription());
        salesOrder.setSalesOrderSituations(situationsFromOrder);
    }

    /**
     * @return {@link Situation} to handle Pendent
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-15
     */
    private Situation getPendentSituation() {
        final SituationSearch situationSearch = this.doGenerateSituationSearchForPendent();
        final List<Situation> situations = this.situationDAO.list(situationSearch).getItems();
        return situations.stream().findFirst().orElseThrow(() -> new MessageException("order.situationDoesNotExist", HttpStatus.SC_UNPROCESSABLE_ENTITY));
    }

    /**
     * @return {@link SituationSearch} filled to search Pendent Situation
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-15
     */
    private SituationSearch doGenerateSituationSearchForPendent() {
        final SituationSearch situationSearch = new SituationSearch();
        situationSearch.setAcronym("PP");
        return situationSearch;
    }

    /**
     * Clone order to handle child's updates.
     *
     * @param salesOrder to fill the mapping
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-29
     */
    private SalesOrder doHandleCloneOfHeaderInformation(final SalesOrder salesOrder, final SalesOrder dbOrder) {
        salesOrder.setNetValue(dbOrder.getNetValue());
        salesOrder.setDraft(dbOrder.getDraft());
        salesOrder.setOrigin(dbOrder.getOrigin());
        salesOrder.setComplement(dbOrder.getComplement());
        salesOrder.setSignatureId(dbOrder.getSignatureId());
        salesOrder.setSalesOrderSituations(dbOrder.getSalesOrderSituations());
        salesOrder.setItems(dbOrder.getItems());
        salesOrder.setServices(dbOrder.getServices());
        salesOrder.setOrderNumber(dbOrder.getOrderNumber());
        salesOrder.setInstalments(dbOrder.getInstalments());
        salesOrder.setInsertedAt(dbOrder.getInsertedAt());
        salesOrder.setDeliveryOrders(dbOrder.getDeliveryOrders());
        salesOrder.setOrderCurrency(this.doHandleCloneOfOrderCurrency(salesOrder.getOrderCurrency(), dbOrder.getOrderCurrency(), salesOrder));
        return salesOrder;
    }


    /**
     *
     * Method will merge the information from the database with
     * the information that is coming from the endpoint the clone was used
     * in this way to merge only some desired fields.
     *
     * @param salesOrder to fill the mapping
     * @author Diogo Melo
     * @since v8.0.0 2019-05-24
     */
    private void doMergeForUpdateFinishedOrder(final SalesOrder salesOrder, final SalesOrder dbOrder) {
        salesOrder.setNetValue(dbOrder.getNetValue());
        salesOrder.setOrigin(dbOrder.getOrigin());
        salesOrder.setComplement(dbOrder.getComplement());
        salesOrder.setSignatureId(dbOrder.getSignatureId());
        salesOrder.setItems(dbOrder.getItems());
        salesOrder.setSalesOrderSituations(dbOrder.getSalesOrderSituations());
        salesOrder.setServices(dbOrder.getServices());
        salesOrder.setOrderNumber(dbOrder.getOrderNumber());
        salesOrder.setInstalments(dbOrder.getInstalments());
        salesOrder.setInsertedAt(dbOrder.getInsertedAt());
        salesOrder.setDeliveryOrders(dbOrder.getDeliveryOrders());
        salesOrder.setOrderCurrency(this.doHandleCloneOfOrderCurrency(salesOrder.getOrderCurrency(), dbOrder.getOrderCurrency(), salesOrder));
    }

    /**
     * Clone the entity in database to the set the order. It must be do to handle update of order child's
     *
     * @param orderCurrency   to take the values
     * @param dbOrderCurrency to update the values
     * @param salesOrder      to fill the mapping
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-29
     */
    private OrderCurrency doHandleCloneOfOrderCurrency(final OrderCurrency orderCurrency, final OrderCurrency dbOrderCurrency, final SalesOrder salesOrder) {
        final OrderCurrency orderCurrencyFromDb = Optional.ofNullable(dbOrderCurrency).orElse(new OrderCurrency());
        return Optional.ofNullable(orderCurrency).map(
                orderCurrencyReceived -> {
                    orderCurrencyFromDb.setSalesOrder(salesOrder);
                    orderCurrencyFromDb.setCurrencyDescription(orderCurrencyReceived.getCurrencyDescription());
                    orderCurrencyFromDb.setCurrencyId(orderCurrencyReceived.getCurrencyId());
                    orderCurrencyFromDb.setCurrencyQuotationDate(orderCurrencyReceived.getCurrencyQuotationDate());
                    orderCurrencyFromDb.setCurrencyQuotationId(orderCurrencyReceived.getCurrencyQuotationId());
                    orderCurrencyFromDb.setCurrencyQuotationValue(orderCurrencyReceived.getCurrencyQuotationValue());
                    return orderCurrencyFromDb;
                }
        ).orElse(null);
    }

    /**
     * Validates and throw a list of {@link com.ws.commons.server.validation.exception.LogicError} if there is any errors
     *
     * @param salesOrder to validate
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private void doValidate(final SalesOrder salesOrder, final SalesValidationType validationType) {
        salesOrderValidator.validate(salesOrder, validationType);
        salesOrderValidator.throwFoundErrors();
    }

    /**
     * @param salesOrder to get Id and UserId
     * @return String with the order number
     * @throws DecoderException if it can not decode the hexadecimal
     * @author Thyago Volpatto
     * @since v1.0.0 2016-08-29
     */
    private String doGenerateNewOrderNumber(final SalesOrder salesOrder) throws DecoderException {
        final int startOfArray = 0;
        final int endOfSubstring = 2;
        final int positionForSubstring = 36;
        final String hexUuid = salesOrder.getId().toString().split("-")[startOfArray];
        final String hexUser = salesOrder.getUserId().toString().split("-")[startOfArray].substring(startOfArray, endOfSubstring);
        final String s = hexUser + hexUuid;
        final byte[] decoded = Hex.decodeHex(s.toCharArray());
        final BigInteger value = new BigInteger(decoded);
        final String num = value.toString(positionForSubstring);
        return num.toUpperCase();
    }

    /**
     * @param order   to get dueDate and check if the value changed
     * @param dbOrder do check if the valueChanged and get Items/Delivery
     * @author Maykon Roberto Rissi
     * @since v5.0.0
     */
    private void updateItemsUsingDueDate(final SalesOrder order, final SalesOrder dbOrder) {
        final Boolean isDueDateEnabled = this.productService.isDueDatePluginActive();
        if (CollectionUtils.isNotEmpty(dbOrder.getItems()) && isDueDateChanged(order, dbOrder) && isDueDateEnabled) {
            final BigDecimal dueDateValue = this.productService.getDueDateCoefficient(order.getPriceListId(), order.getDueDate());
            this.doChangeItemPricesUsingDueDate(order, dueDateValue);
            order.setProductTotalValue(this.calculateOrderProductTotalValue(order));
            order.setServiceTotalValue(this.calculateOrderServiceTotalValue(order));
            order.setNetValue(this.doCalculateOrderTotalValue(order));
        }
    }

    /**
     * Changes every item by setting the salesPrice with coefficient x originalPrice
     * Sets the other values to 0;
     *
     * @param salesOrder  to change de items
     * @param coefficient to multiply the items value
     * @author Maykon Roberto Rissi
     * @since v5.0.0
     */
    private void doChangeItemPricesUsingDueDate(final SalesOrder salesOrder, final BigDecimal coefficient) {
        salesOrder.getItems()
                .forEach(item -> {
                    item.setSalesPrice(item.getOriginalPrice().multiply(coefficient));
                    item.setDiscountPercentage(BigDecimal.ZERO);
                    item.setDiscountValue(BigDecimal.ZERO);
                    item.setIncreaseValue(BigDecimal.ZERO);
                    item.setIncreasePercentage(BigDecimal.ZERO);
                    item.setDueDateValue(item.getOriginalPrice().subtract(item.getSalesPrice()));
                    item.setTotalItem(item.getSalesPrice().multiply(item.getQuantity()));
                });
    }

    /**
     * Calculates the new value for the order by sum items, services and deliveries
     * The values from productTotalValue and serviceTotalValue used are inside the salesOrder param.
     *
     * @param salesOrder to get items and delivery
     * @return {@link BigDecimal} sum of items and deliveries
     * @author Maykon Roberto Rissi
     * @author Bruno Capeleto Rodrigues
     * @since v5.0.0
     * @since v8.3.0
     */
    private BigDecimal doCalculateOrderTotalValue(final SalesOrder salesOrder) {
        final BigDecimal sumOfDeliveries = this.calculateOrderDeliveryTotalValue(salesOrder);

        return sumOfDeliveries
                .add(salesOrder.getProductTotalValue())
                .add(salesOrder.getServiceTotalValue());
    }

    private BigDecimal calculateOrderProductTotalValue(final SalesOrder salesOrder) {
        return salesOrder
                .getItems()
                .stream()
                .map(SalesOrderItem::getTotalItem)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateOrderServiceTotalValue(final SalesOrder salesOrder) {
        return salesOrder
                .getServices()
                .stream()
                .map(com.ws.sales.orderservice.SalesOrderService::getTotalValue)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateOrderDeliveryTotalValue(final SalesOrder salesOrder) {
        return salesOrder
                .getDeliveryOrders()
                .stream()
                .filter(delivery -> IncotermsAcronym.CIF == delivery.getIncotermsAcronym())
                .map(DeliveryOrder::getFreightValue)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Check if the dueDate changed from de old order to the new one
     *
     * @param orderInUpdate to get the actual value from dueDate
     * @param dbOrder       to get the old value from dueDate
     * @return {@link Boolean#TRUE} if the due date changed, or the old or new orders does not have dueDate
     * @author Maykon Roberto Rissi
     * @since v5.0.0
     */
    private Boolean isDueDateChanged(final SalesOrder orderInUpdate, final SalesOrder dbOrder) {
        if (dbOrder.getDueDate() != null) {
            return Optional.ofNullable(orderInUpdate)
                    .map(SalesOrder::getDueDate)
                    .map(dueDate -> !dueDate.equals(dbOrder.getDueDate()))
                    .orElse(Boolean.TRUE);
        }
        return Boolean.TRUE;
    }

    /**
     * Check the origin of the call to create the sales order
     *
     * @param originWeb to get the actual value from salesOrder
     * @return {@link String} if the source is web within the object will be set WEB if it will not be set EXT
     * @author Diogo Melo
     * @since v1.0.0
     */
    private String isOrigin(String originWeb){
        if(originWeb != null){
            return originWeb;
        }else{
            return OrderOrigin.EXT.toString();
        }
    }

    /**
     * This method is used to copy an order using the sales order id
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param orderId {@link UUID} to get order from database
     * @return {@link SalesOrder}
     * @throws Exception if an insertion error occurs
     */
    public SalesOrder copy(final UUID orderId) throws Exception {
        final SalesOrder salesOrderCopy = this.generateSalesOrderClone(orderId);
        final UUID userId = UUID.fromString((String) userContext.getSession().getAttribute(Constants.FIELD_USER_ID_CONTEXT));
        this.doGenerateCopyValues(salesOrderCopy);
        this.linkOrderToServiceInExecution(salesOrderCopy, userId);
        return this.insertSalesOrderCopy(salesOrderCopy);
    }

    /**
     * This method is used to insert a copy order on database
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param salesOrderCopy {@link SalesOrder}
     * @return {@link SalesOrder}
     * @throws Exception if an error occurred during the insert
     */
    private SalesOrder insertSalesOrderCopy(final SalesOrder salesOrderCopy) throws Exception {
        final SalesOrder inserted = super.insert(salesOrderCopy);
        this.insertOrderChildren(inserted);
        return inserted;
    }

    /**
     * This method sets the sales order relationships for the copy one
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param salesOrderCopy {@link SalesOrder} to get lists
     */
    private void insertOrderChildren(final SalesOrder salesOrderCopy) {
        this.insertOrderItem(salesOrderCopy.getItems());
        this.insertOrderService(salesOrderCopy.getServices());
        this.insertOrderDelivery(salesOrderCopy.getDeliveryOrders());
        this.insertOrderInstalment(salesOrderCopy.getInstalments());
    }

    /**
     * This method insert the instalments for the sales order copy
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param instalments {@link SalesOrderInstalment}
     */
    private void insertOrderInstalment(final List<SalesOrderInstalment> instalments) {
        this.clearInstalments(instalments);
        this.salesOrderInstalmentDAO.batchInsert(instalments);
    }

    /**
     * This method do a clean on the fields that are not required
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param instalments {@link SalesOrderInstalment}
     */
    private void clearInstalments(final List<SalesOrderInstalment> instalments) {
        instalments.forEach(instalment -> {
            instalment.setExternalId(null);
            instalment.setCreatedAt(OffsetDateTime.now());
            instalment.setUpdatedAt(OffsetDateTime.now());
        });
    }

    /**
     * This method insert the delivery for the sales order copy
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param deliveryOrders {@link DeliveryOrder}
     */
    private void insertOrderDelivery(final List<DeliveryOrder> deliveryOrders) {
        this.clearDeliveryOrders(deliveryOrders);
        this.deliveryOrderDAO.batchInsert(deliveryOrders);
    }

    /**
     * This method do a clean on the fields that are not required
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param deliveryOrders {@link DeliveryOrder}
     */
    private void clearDeliveryOrders(final List<DeliveryOrder> deliveryOrders) {
        deliveryOrders.forEach(delivery -> {
            delivery.setExternalId(null);
            delivery.setCreatedAt(OffsetDateTime.now());
            delivery.setUpdatedAt(OffsetDateTime.now());
        });
    }

    /**
     * This method insert the services for the sales order copy
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param services {@link com.ws.sales.orderservice.SalesOrderService}
     */
    private void insertOrderService(final List<com.ws.sales.orderservice.SalesOrderService> services) {
        this.clearOrderService(services);
        this.salesOrderServiceDAO.batchInsert(services);
    }

    /**
     * This method do a clean on the fields that are not required
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param services {@link com.ws.sales.orderservice.SalesOrderService}
     */
    private void clearOrderService(final List<com.ws.sales.orderservice.SalesOrderService> services) {
        services.forEach(service -> {
            service.setExternalId(null);
            service.setCreatedAt(OffsetDateTime.now());
            service.setUpdatedAt(OffsetDateTime.now());
        });
    }

    /**
     * This method insert the items for the sales order copy
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param items {@link SalesOrderItem}
     */
    private void insertOrderItem(final List<SalesOrderItem> items) {
        this.clearOrderItems(items);
        this.salesOrderItemDAO.batchInsert(items);
    }

    /**
     * This method do a clean on the fields that are not required
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param items {@link SalesOrderItem}
     */
    private void clearOrderItems(final List<SalesOrderItem> items) {
        items.forEach(item -> {
            item.setExternalId(null);
            item.setSalesOrderItemSituationID(null);
            item.setSalesOrderItemSituationDescription(null);
            item.setCreatedAt(OffsetDateTime.now());
            item.setUpdatedAt(OffsetDateTime.now());
        });
    }

    /**
     * This method is used to cloning an order using the {@link EntityCloner}
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param orderId {@link UUID} to get order from database
     * @return a clone of the {@link SalesOrder}
     */
    private SalesOrder generateSalesOrderClone(final UUID orderId) {
        final SalesOrder salesOrderToBeCopied = this.get(orderId);
        final EntityCloner<SalesOrder> cloner = new EntityCloner<>(salesOrderToBeCopied);
        return cloner.generateClone();
    }

    /**
     * Sets the  default values in the sales order to be copied
     *
     * @since 8.5.0 2019-06-18
     * @author Ricardo Corrent
     *
     * @param salesOrderCopy {@link SalesOrder} to set values
     */
    private void doGenerateCopyValues(final SalesOrder salesOrderCopy) throws DecoderException {
        salesOrderCopy.setInsertedAt(OffsetDateTime.now());
        salesOrderCopy.setOrigin(OrderOrigin.WEB.toString());
        salesOrderCopy.setDraft(Boolean.TRUE);
        salesOrderCopy.setId(UUID.randomUUID());
        salesOrderCopy.setOrderNumber(this.doGenerateNewOrderNumber(salesOrderCopy));
        salesOrderCopy.setExternalId(null);
        salesOrderCopy.setExternalNumber(null);
        salesOrderCopy.setOrderedAt(null);
        salesOrderCopy.setExportedAt(null);
        salesOrderCopy.setSituationId(null);
        salesOrderCopy.setSituationDescription(null);
        salesOrderCopy.setSalesOrderSituations(Collections.emptyList());
    }

}
