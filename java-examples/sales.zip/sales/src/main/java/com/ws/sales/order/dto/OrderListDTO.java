package com.ws.sales.order.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.customer.dto.CustomerDTO;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.external.user.dto.UserDTO;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Created by sergio.junior on 10/13/2017.
 */
public class OrderListDTO extends BaseDTO implements DefaultPojoConverter {

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "customer.id", target = "customerId"),
            @PojoColumnMapper(source = "customer.name", target = "customerName")
    })
    private CustomerDTO customer;

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "location.id", target = "locationId"),
            @PojoColumnMapper(source = "location.description", target = "locationDescription")
    })
    private LocationDTO location;

    private Boolean draft;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime orderedAt;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime insertedAt;

    private String situationDescription;

    private String orderNumber;

    private BigDecimal netValue;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime trasmittedAt;

    /**
     * External order number
     */
    private String externalNumber;

    /**
     * Date exportation {@link com.ws.sales.order.SalesOrder} to external source
     */
    private OffsetDateTime exportedAt;

    /**
     * Origin from Order
     * @see com.ws.sales.order.enums.OrderOrigin
     */
    private String origin;

    // User from order
    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "user.id", target = "userId"),
            @PojoColumnMapper(source = "user.name", target = "userName")
    })
    private UserDTO user;

    // User professional from order
    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "userProfessional.id", target = "userProfessionalId"),
            @PojoColumnMapper(source = "userProfessional.name", target = "userProfessionalName")
    })
    private UserDTO userProfessional;

    public CustomerDTO getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDTO customer) {
        this.customer = customer;
    }

    public LocationDTO getLocation() {
        return location;
    }

    public void setLocation(LocationDTO location) {
        this.location = location;
    }

    public Boolean getDraft() {
        return draft;
    }

    public void setDraft(Boolean draft) {
        this.draft = draft;
    }

    public OffsetDateTime getOrderedAt() {
        return orderedAt;
    }

    public void setOrderedAt(OffsetDateTime orderedAt) {
        this.orderedAt = orderedAt;
    }

    public String getSituationDescription() {
        return situationDescription;
    }

    public void setSituationDescription(String situationDescription) {
        this.situationDescription = situationDescription;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public BigDecimal getNetValue() {
        return netValue;
    }

    public void setNetValue(BigDecimal netValue) {
        this.netValue = netValue;
    }

    public OffsetDateTime getTrasmittedAt() {
        return trasmittedAt;
    }

    public void setTrasmittedAt(OffsetDateTime trasmittedAt) {
        this.trasmittedAt = trasmittedAt;
    }

    /**
     * Get of property {@Link #insertedAt}
     *
     * @return OffsetDateTime
     */
    public OffsetDateTime getInsertedAt() {
        return insertedAt;
    }

    /**
     * Set of property {@Link #insertedAt}
     *
     * @param insertedAt field do set
     */
    public void setInsertedAt(OffsetDateTime insertedAt) {
        this.insertedAt = insertedAt;
    }

    /**
     * Getter of property {@link #externalNumber}
     *
     * @return java.lang.String
     */
    public String getExternalNumber() {
        return externalNumber;
    }

    /**
     * Set of property {@link #externalNumber}
     *
     * @param externalNumber field to set
     */
    public void setExternalNumber(final String externalNumber) {
        this.externalNumber = externalNumber;
    }

    /**
     * Getter of property {@link #exportedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getExportedAt() {
        return exportedAt;
    }

    /**
     * Set of property {@link #exportedAt}
     *
     * @param exportedAt field to set
     */
    public void setExportedAt(final OffsetDateTime exportedAt) {
        this.exportedAt = exportedAt;
    }

    /**
     * Getter of property {@link #origin}
     *
     * @return java.lang.String
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * Set of property {@link #origin}
     *
     * @param origin field to set
     */
    public void setOrigin(final String origin) {
        this.origin = origin;
    }

    /**
     * Getter of property {@link #user}
     *
     * @return com.ws.sales.external.user.dto.UserDTO
     */
    public UserDTO getUser() {
        return user;
    }

    /**
     * Set of property {@link #user}
     *
     * @param user field to set
     */
    public void setUser(final UserDTO user) {
        this.user = user;
    }

    /**
     * Getter of property {@link #userProfessional}
     *
     * @return com.ws.sales.external.user.dto.UserDTO
     */
    public UserDTO getUserProfessional() {
        return userProfessional;
    }

    /**
     * Set of property {@link #userProfessional}
     *
     * @param userProfessional field to set
     */
    public void setUserProfessional(final UserDTO userProfessional) {
        this.userProfessional = userProfessional;
    }
}
