package com.ws.sales.external.service;

import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 7.1.0 2019-01-16
 */
public class LocationDTO {

    private UUID id;
    private String description;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}