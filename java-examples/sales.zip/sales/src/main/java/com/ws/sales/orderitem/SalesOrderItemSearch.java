package com.ws.sales.orderitem;

import com.ws.commons.server.pagination.PaginationSearch;

import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v3.0.0 2017-03-01.
 */
public class SalesOrderItemSearch extends PaginationSearch {

    private String orderNumber;

    private UUID priceListId;

    private UUID productId;

    private UUID salesOrderId;

    /**
     * Gets the order number to be filtered
     *
     * @return java.lang.String
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Sets the order number to be filtered
     *
     * @param orderNumber
     */
    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * Gets the Customer ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getPriceListId() {
        return priceListId;
    }

    /**
     * Sets the customer ID to be filtered
     *
     * @param priceListId
     */
    public void setPriceListId(final UUID priceListId) {
        this.priceListId = priceListId;
    }


    /**
     * Gets the product ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getProductId() {
        return productId;
    }

    /**
     * Sets the product ID to be filtered
     *
     * @param productId
     */
    public void setProductId(final UUID productId) {
        this.productId = productId;
    }


    /**
     * Gets the sales order ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getSalesOrderId() {
        return salesOrderId;
    }

    /**
     * Sets the sales Order ID to be filtered
     *
     * @param salesOrderId
     */
    public void setSalesOrderId(final UUID salesOrderId) {
        this.salesOrderId = salesOrderId;
    }
}
