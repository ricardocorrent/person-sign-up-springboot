package com.ws.sales.customerorderssummary.productspurchased.dto;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.sales.customerorderssummary.productspurchased.CustomerOrderHistoryProductsView;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * This DTO class was created to represent all purchase products from customer.
 * This data comes from {@link CustomerOrderHistoryProductsView} file
 * through to the sql query
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-13
 */
@Getter
@Setter
@Entity
@Table(name = "customer_order_history_products_view")
public class ProductsSummaryDTO implements IPojoConverter {

    private UUID id;

    private String code;

    private String description;

    private BigDecimal maxQuantity;

    private BigDecimal maxValue;

    private OffsetDateTime lastPurchaseDate;

}
