package com.ws.sales.paymenttermcustomerpermission;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermCustomerPermissionService extends AbstractService<PaymentTermCustomerPermission> {

    private final PaymentTermDAO paymentTermDAO;
    private final PaymentTermCustomerPermissionValidator paymentTermCustomerPermissionValidator;

    /**
     * @param paymentTermCustomerPermissionDAO       to perform entity persistence
     * @param paymentTermDAO                         to load {@link PaymentTerm}
     * @param paymentTermCustomerPermissionValidator to handle permission validations
     **/
    @Inject
    public PaymentTermCustomerPermissionService(final PaymentTermCustomerPermissionDAO paymentTermCustomerPermissionDAO, final PaymentTermDAO paymentTermDAO,
                                                final PaymentTermCustomerPermissionValidator paymentTermCustomerPermissionValidator) {
        super(paymentTermCustomerPermissionDAO);
        this.paymentTermDAO = paymentTermDAO;
        this.paymentTermCustomerPermissionValidator = paymentTermCustomerPermissionValidator;
    }

    /**
     * @param paymentTermCustomerPermissions {@link List<PaymentTermCustomerPermission>} to persist
     * @param paymentTermId                  to get {@link PaymentTerm}
     **/
    public void insertList(final List<PaymentTermCustomerPermission> paymentTermCustomerPermissions, final UUID paymentTermId) {
        final PaymentTerm paymentTerm = paymentTermDAO.findById(paymentTermId);
        this.doValidateByBeanValidation(paymentTermCustomerPermissions);
        this.doValidateLogic(paymentTermCustomerPermissions, paymentTerm);
        this.dao.batchInsert(paymentTermCustomerPermissions);
    }

    /**
     * @param paymentTermId to fill the search
     * @return {@link PagedList<PaymentTermCustomerPermission>}
     **/
    public PagedList<PaymentTermCustomerPermission> getByPaymentTerm(final UUID paymentTermId) {
        return ((PaymentTermCustomerPermissionDAO) this.dao).getByPaymentTerm(paymentTermId);
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors. After validate, it will throw the errors
     *
     * @param paymentTermCustomerPermissions {@link List<PaymentTermCustomerPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateByBeanValidation(final List<PaymentTermCustomerPermission> paymentTermCustomerPermissions) {
        IntStream.range(0, paymentTermCustomerPermissions.size())
                .forEach(index -> paymentTermCustomerPermissionValidator.validateByBeanValidation(paymentTermCustomerPermissions.get(index), String.valueOf(index)));
        paymentTermCustomerPermissionValidator.throwFoundErrors();
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors.
     *
     * @param paymentTermCustomerPermissions {@link List<PaymentTermCustomerPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateLogic(final List<PaymentTermCustomerPermission> paymentTermCustomerPermissions, final PaymentTerm paymentTerm) {
        IntStream.range(0, paymentTermCustomerPermissions.size())
                .forEach(index -> paymentTermCustomerPermissionValidator.validate(paymentTermCustomerPermissions.get(index),
                        paymentTerm.getCustomerPermissions(),
                        String.valueOf(index)));
        paymentTermCustomerPermissionValidator.throwFoundErrors();
    }
}
