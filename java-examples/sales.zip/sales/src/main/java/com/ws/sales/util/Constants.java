package com.ws.sales.util;

import java.math.BigDecimal;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-30
 */
public final class Constants {

    public static final String ORDER_TYPE_KEY = "orderType";
    public static final String FIELD_ORDER_TYPE_STANDARD = "standard";

    public static final String FIELD_SALES_ORDER_ITEM = "salesOrderItem";

    public static final String FIELD_DOCUMENT_EMAIL_MESSAGE = "document.emailMessage";
    public static final String FIELD_PRODUCT = "product";
    public static final String FIELD_SERVICE = "service";
    public static final String FIELD_PRODUCT_DESCRIPTION = "productDescription";
    public static final String FIELD_PRODUCT_GROUP_ID = "productGroupId";
    public static final String FIELD_PRODUCT_ID = "productId";
    public static final String FIELD_ORIGINAL_PRICE = "originalPrice";
    public static final String FIELD_QUANTITY = "quantity";
    public static final String FIELD_DAYS_BETWEEN = "daysBetween";
    public static final String FIELD_PRICE_LIST = "priceList";
    public static final String FIELD_PRICE_LIST_ITEM = "priceListItem";
    public static final String FIELD_PRICE_LIST_ITEM_ID = "priceListItemId";
    public static final String FIELD_PRODUCT_PACKAGING = "productPackaging";
    public static final String FIELD_VALUE = "value";
    public static final String FIELD_MINIMUM = "min";
    public static final String FIELD_MAXIMUM= "max";
    public static final String FIELD_DISCOUNT_VALUE = "discountValue";
    public static final String FIELD_DISCOUNT = "discount";
    public static final String FIELD_MAXIMUM_DISCOUNT_VALUE = "maximumDiscountValue";
    public static final String FIELD_DISCOUNT_PERCENTAGE = "discountPercentage";
    public static final String FIELD_MAXIMUM_DISCOUNT_PERCENTAGE = "maximumDiscountPercentage";
    public static final String FIELD_ORDER_WAREHOUSE = "orderWarehouse";
    public static final String FIELD_WITHDRAWAL_COMPANY_ID = "withdrawalCompanyId";
    public static final String FIELD_WITHDRAWAL_COMPANY_NAME = "withdrawalCompanyName";
    public static final String FIELD_COMPANY_ID = "companyId";
    public static final String FIELD_ITEM_SEEDS = "salesOrderItemSeed";
    public static final String FIELD_ID = "id";
    public static final String FIELD_ORDER_ID = "orderId";
    public static final String FIELD_ORDER_SEEDS = "salesOrderSeed";
    public static final String FIELD_ORDER_TREATMENT = "orderTreatment";
    public static final String FIELD_ORDER_TREATMENT_VALUE = "treatmentPrice";
    public static final String FIELD_ORDER_TREATMENT_TOTAL_VALUE = "totalTreatmentValue";
    public static final String FIELD_ORDER_ROYALTY_TECH = "royaltyTechnology";
    public static final String FIELD_ORDER_ROYALTY_VALUE = "royaltyValue";
    public static final String FIELD_ORDER_TECHNOLOGY_VALUE = "technologyValue";
    public static final String FIELD_CUSTOMER_ID = "customerId";
    public static final String FIELD_LOCATION_ID = "locationId";
    public static final String FIELD_USER_ID = "userId";
    public static final String FIELD_USER = "user";
    public static final String FIELD_USER_ID_CONTEXT = "user_id";
    public static final String FIELD_USER_ADMIN_CONTEXT = "user_administrator";
    public static final String FIELD_CUSTOMER_LOCATION = "customerLocation";
    public static final String FIELD_PROFESSIONAL = "professional";
    public static final String FIELD_PROFESSIONAL_ID = "professionalId";
    public static final String FIELD_PROFESSIONAL_DESCRIPTION = "professionalDescription";
    public static final String FIELD_PRICE_LIST_ID = "priceListId";
    public static final String FIELD_PRICE_LIST_DESCRIPTION = "priceListDescription";
    public static final String FIELD_INCOTERMS_ID = "incotermsId";
    public static final String FIELD_OCCURRENCE = "occurrence";
    public static final String FIELD_INCOTERMS_ACRONYM = "incotermsAcronym";
    public static final String FIELD_INCOTERMS = "incoterms";
    public static final String FIELD_ORDER_INSTALMENT = "orderInstalment";
    public static final String FIELD_SALES_ORDER = "salesOrder";
    public static final String FIELD_DRAFT = "draft";
    public static final String FIELD_SALES = "sales";
    public static final String FIELD_CREDIT_LIMIT = "creditLimit";
    public static final String FIELD_SALES_PRICE = "salesPrice";
    public static final String FIELD_MINIMUM_PRICE = "minimumPrice";
    public static final String FIELD_DUE_DATE = "dueDate";
    public static final String FIELD_DUE_DATE_VALUE = "dueDateValue";
    public static final String FIELD_TAXES_ACCOUNT = "taxesAccount";
    public static final String FIELD_FREIGHT_VALUE = "freightValue";
    public static final String FIELD_INCREASE_VALUE = "increaseValue";
    public static final String FIELD_INCREASE_PERCENTAGE = "increasePercentage";
    public static final String FIELD_OVERALL_PRICE = "overallUnitPrice";
    public static final String FIELD_TOTAL_TREATMENT = "totalTreatmentValue";
    public static final String FIELD_TOTAL_QUANTITY = "totalQuantity";
    public static final String FIELD_ORDER_OPERATION = "orderOperation";
    public static final String FIELD_PAYMENT_TERM = "paymentTerm";
    public static final String FIELD_PAYMENT_TERM_ID = "paymentTermId";
    public static final String FIELD_PAYMENT_TERM_DESCRIPTION = "paymentTermDescription";
    public static final String FIELD_DELIVERY_ORDER = "deliveryOrder";
    public static final String FIELD_DELIVERY_DATE = "deliveryDate";
    public static final String FIELD_ACTIVE = "active";

    public static final String FIELD_MESSAGE_PARAMETER_MAX_NUMBER = "maxNumber";

    public static final String FIELD_PARAMETER_BLOCK_ORDER_INACTIVE_CUSTOMER = "BLOCK_ORDER_INACTIVE_CUSTOMER";
    public static final String FIELD_PARAMETER_BLOCK_ORDER_INACTIVE_LOCATION = "BLOCK_ORDER_INACTIVE_LOCATION";
    public static final String FIELD_PARAMETER_MINIMUM_PRICE = "VALIDATE_MINIMUM_PRICE";
    public static final String FIELD_PARAMETER_DISCOUNT = "VALIDATE_DISCOUNT";
    public static final String FIELD_PARAMETER_ENABLE_SEEDS_CONFIGURATOR = "ENABLE_FIELDS_SEEDS_CONFIGURATOR";
    public static final String FIELD_PARAMETER_SEED = "SEED_ORDER";
    public static final String FIELD_PARAMETER_ENABLE_DUE_DATE_FIELD = "ENABLE_DUE_DATE_FIELD";
    public static final String FIELD_PARAMETER_DUE_DATE_FIELD_REQUIRED = "DUE_DATE_FIELD_REQUIRED";
    public static final String FIELD_PARAMETER_DUE_DATE_PRICE = "DUE_DATE_PRICE";
    public static final String FIELD_PARAMETER_CREDIT_REQUIRED = "CREDIT_REQUIRED";
    public static final String FIELD_PARAMETER_CURRENCY_PLUGIN = "CURRENCY_PLUGIN";
    public static final String FIELD_PARAMETER_SIGNATURE_REQUIRED = "SIGNATURE_REQUIRED";
    public static final String FIELD_PARAMETER_ENABLE_ORDER_INSTALMENT = "ENABLE_ORDER_INSTALMENT";
    public static final String FIELD_PARAMETER_BLOCK_ORDER_NEGATIVE_CREDIT = "BLOCK_ORDER_NEGATIVE_CREDIT";
    public static final String FIELD_PARAMETER_VALIDATE_MINIMUM_PRICE = "VALIDATE_MINIMUM_PRICE";
    public static final String FIELD_PARAMETER_VALIDATE_DISCOUNT = "VALIDATE_DISCOUNT";
    public static final String FIELD_PARAMETER_ORDER_FILTER_DAYS = "ORDER_FILTER_DAYS";
    public static final String FIELD_PARAMETER_ENABLE_SEED_ROYALTY_TECHNOLOGY = "ENABLE_ROYALTY_TECHNOLOGY_VALUE_FIELDS";
    public static final String FIELD_PARAMETER_GENERATE_CONTRACT_USING_MODEL = "GENERATE_CONTRACT_USING_MODEL";
    /**
     * Represents the amount of decimal places to be used in all value operations (increase and discount calculations, etc.).
     */
    public static final String FIELD_PARAMETER_DECIMAL_PLACES = "DECIMAL_PLACES";

    public static final String FIELD_CUSTOMER = "customer";
    public static final String FIELD_CUSTOMER_DOCUMENTS = "customer.documents";
    public static final String FIELD_CUSTOMER_LOCATIONS = "customer.locations";
    public static final String FIELD_CUSTOMER_STATE_CITY = "customer.state.city";
    public static final String FIELD_CUSTOMER_EMAIL = "customer.email";
    public static final String FIELD_CUSTOMER_PHONE = "customer.phone";
    public static final String FIELD_ORDER_NUMBER = "order.number";
    public static final String FIELD_CUSTOMER_NAME = "customer.name";
    public static final String FIELD_ORDER_NET_VALUE = "order.net.value";
    public static final String FIELD_ORDER_CURRENT_DATE = "order.current.date";
    public static final String FIELD_CUSTOMER_ZIP_CODE = "customer.zip.code";
    public static final String FIELD_CURRENCY_ID = "currencyId";
    public static final String FIELD_CURRENCY_QUOTATION_ID = "currencyQuotationId";
    public static final String FIELD_MEASUREMENT_UNIT_ID = "measurementUnitId";
    public static final String FIELD_REPETITIONS = "repetitions";


    public static final BigDecimal BAG_OF_25_KG = BigDecimal.valueOf(25);
    public static final BigDecimal BAG_OF_1000_KG = BigDecimal.valueOf(1000);

    public static final String PATTERN_MM_DD_YYYY = "LLLL/dd/yyyy";
    public static final String PATTERN_LANGUAGE_EN_US = "en-US";


    public static final String[] TAXES_ACCOUNTS = {"COMPRADOR", "VENDEDOR", "BUYER", "SELLER"};

    public static final String MESSAGE_JAVAX_NOT_NULL = "javax.validation.constraints.NotNull.message";
    public static final String MESSAGE_JAVAX_MIN_VALUE = "javax.validation.constraints.Min.message";
    public static final String MESSAGE_JAVAX_MAX_VALUE = "javax.validation.constraints.Max.message";
    public static final String MESSAGE_TAXES_ACCOUNT = "orderSeeds.taxesAccount";
    public static final String MESSAGE_ROYALTY_VALUE = "orderSeeds.royaltyValue";
    public static final String MESSAGE_SEED_PLUGIN = "orderSeeds.pluginDisabled";
    public static final String MESSAGE_INSTALMENT_PLUGIN_DISABLED = "orderInstalment.pluginDisabled";
    public static final String MESSAGE_INSTALMENTS_VALUE_DIFFERENT_THAN_ORDER = "orderInstalment.instalmentsValueDifferentThanOrder";
    public static final String MESSAGE_SEED_BAG_PACKAGE = "orderSeeds.bagAndPackage";
    public static final String MESSAGE_TECH_VALUE = "orderSeeds.techValue";
    public static final String MESSAGE_TREATED_SEED_DISABLED = "orderSeeds.treatedSeedDisabled";
    public static final String MESSAGE_TREATED_SEED_VALUE_DISABLED = "orderSeeds.treatedSeedDisabledValue";
    public static final String MESSAGE_INCORRECT_CIF = "delivery.freightValue.incorrect.CIF";
    public static final String MESSAGE_INCORRECT_FOB = "delivery.freightValue.incorrect.FOB";
    public static final String MESSAGE_DISCOUNT_INCREASE = "order.service.discountAndIncreaseValues";
    public static final String MESSAGE_DISCOUNT_DUE_DATE_INCREASE = "orderSeeds.discountDueDateAndIncreaseValues";
    public static final String MESSAGE_DUE_DATE_PLUGIN_DISABLED = "order.validation.dueDateInactive";
    public static final String MESSAGE_INCREASE_PERCENTAGE = "order.item.increasePercentage.inconsistent";
    public static final String MESSAGE_INCREASE_VALUE = "order.item.increaseValue.inconsistent";
    public static final String MESSAGE_OVERALL_MESSAGE = "orderSeeds.overallUnitPrice";
    public static final String MESSAGE_TOTAL_TREATMENT = "orderSeeds.totalTreatmentValue";
    public static final String MESSAGE_ROYALTY_TECHNOLOGY = "orderSeeds.RoyaltyTechnologyPlugin";
    public static final String MESSAGE_ORDER_SEEDS_ROYALTY_TECHNOLOGY = "orderSeeds.royaltyTechnology";
    public static final String MESSAGE_DECIMAL = "validation.value.greater.than.allowed";
    public static final String MESSAGE_TREATMENT = "order.treatment.notFound";
    public static final String MESSAGE_COORDINATOR = "order.coordinator.notFound";
    public static final String MESSAGE_CONSULTANT = "order.consultant.notFound";
    public static final String MESSAGE_REPRESENTATIVE = "order.representative.notFound";
    public static final String MESSAGE_OPERATION = "order.operation.notFound";
    public static final String MESSAGE_WAREHOUSE = "order.warehouse.notFound";
    public static final String MESSAGE_WITHDRAWAL = "order.withdrawalCompany.notFound";
    public static final String MESSAGE_WITHDRAWAL_INACTIVE = "order.withdrawalCompany.inactive";
    public static final String MESSAGE_ERROR_LOADING_ENTITY = "Error loading entity";
    public static final String MESSAGE_ERROR_VALIDATING_ENTITY = "error.validating.entity";
    public static final String MESSAGE_LOCATION_DOES_NOT_BELONG_TO_CUSTOMER = "customer.LocationDoNotBelongToCustomer";
    public static final String MESSAGE_REGISTER_INACTIVE = "sales.registerInactive";
    public static final String MESSAGE_REGISTER_NOT_FOUND = "sales.registerNotFound";
    public static final String MESSAGE_REGISTER_OUT_OF_DATE = "sales.registerOutOfDate";
    public static final String MESSAGE_DATE_BEFORE_TODAY = "sales.dateBeforeToday";
    public static final String MESSAGE_DUE_DATE_MUST_BE_FILLED = "sales.dueDate.mustBeFilled";
    public static final String MESSAGE_PROFESSIONAL_USER_HIERARCHY = "order.validation.professional.notBelongsToUser";
    public static final String MESSAGE_USER_NOT_SAME_AS_LOGGED = "order.user.userIsNotLogged";
    public static final String MESSAGE_PRICE_LIST_ITEM_MUST_BELONG_TO_PRICE_LIST = "order.item.priceListItem.mustBelongsToPriceList";
    public static final String MESSAGE_PRODUCT_MUST_BELONG_TO_PRICE_LIST_ITEM = "order.item.product.mustBelongsToPriceListItem";
    public static final String MESSAGE_CAN_NOT_USE_PRICE_LIST = "order.item.cannotBeUsed";
    public static final String MESSAGE_PACKAGE_MUST_BELONG_TO_PRODUCT = "order.item.productPackaging.mustBelongsToProduct";
    public static final String MESSAGE_SALE_FRACTION = "order.item.saleFractionated";
    public static final String MESSAGE_QUANTITY_PACK_INCONSISTENT = "order.item.quantity.inconsistentPack";
    public static final String MESSAGE_ORIGINAL_PRICE_INCONSISTENT = "order.item.originalPrice.isNotSamePriceListItem";
    public static final String MESSAGE_PRICE_LOWER_THAN_MINIMUM = "order.item.minimumPrice";
    public static final String MESSAGE_PRICE_HAS_DISCOUNT_AND_IS_FIXED = "order.item.discountAndFixedPrice";
    public static final String MESSAGE_DISCOUNT_PERCENTAGE_INCONSISTENT = "order.item.discountPercentageInvalid";
    public static final String MESSAGE_DISCOUNT_VALUE_INCONSISTENT = "order.item.discountValueInvalid";
    public static final String MESSAGE_PAYMENT_TERM_NOT_FOUND_PRICE_LIST = "order.paymentTerm.siagri.linkedPriceList";
    public static final String MESSAGE_PAYMENT_TERM_DOES_NOT_HAVE_PERMISSIONS = "order.paymentTerm.notMatchCriteria";
    public static final String MESSAGE_PARAMETER_CAN_NOT_ENABLE = "parameter.could.not.enable";
    public static final String MESSAGE_PARAMETER_CAN_NOT_DISABLE = "parameter.could.not.disable";
    public static final String MESSAGE_CREDIT_LIMIT_NOT_EXISTS = "order.creditLimit.notExists";
    public static final String MESSAGE_CREDIT_LIMIT_MORE_THAN_ONE = "order.creditLimit.moreThanOneCreditLimit";
    public static final String MESSAGE_CREDIT_IS_NEGATIVE = "order.creditLimit.isNegative";
    public static final String MESSAGE_CREDIT_BECAME_NEGATIVE = "order.creditLimit.becomeNegative";
    public static final String MESSAGE_DELIVERY_DATE_INCORRECT = "delivery.date.incorrect";
    public static final String MESSAGE_ORDER_ALREADY_WITH_DELIVERY = "delivery.order.already.has.delivery";
    public static final String MESSAGE_ORDER_FINALIZED = "order.finalized";
    public static final String MESSAGE_ORDER_DOES_NOT_HAVE_VALUE = "order.does.not.have.value";
    public static final String MESSAGE_ORDER_CANNOT_EDIT_BECAUSE_IS_EXTERNAL = "order.cannot.edit.because.is.external";
    public static final String MESSAGE_ORDER_CANNOT_REMOVE_BECAUSE_IS_EXTERNAL = "order.cannot.remove.because.is.external";
    public static final String MESSAGE_ORDER_CONFIRMED_CANNOT_REMOVE = "order.confirmed.cannot.remove";
    public static final String MESSAGE_ORDER_GENERATE_CREDIT_LIMIT_ERROR = "order.generate.credit.limit.error";
    public static final String MESSAGE_ORDER_INSTALMENT_MAXIMUM_NUMBER_OF_INSTALMENTS = "orderInstalment.maximumNumberOfInstalments";
    public static final String MESSAGE_VALUE_SHOULD_BE = "value.should.be";
    public static final String MESSAGE_VALUE_STANDARD_UNIQUE_VALIDATION = "sales.orderType.standard.unique.validation";
    public static final String MESSAGE_PERMISSION_ALREADY_PERSISTED = "permission.already.persisted";
    public static final String MESSAGE_QUOTATION_DOES_NOT_BELONG_TO_CURRENCY = "order.orderCurrency.quotationDateNotBelongsToCurrency";
    public static final String MESSAGE_DELIVERY_CHANGE_INCOTERMS_NOT_ALLOWED = "delivery.change.incoterms.not.allowed";
    public static final String MESSAGE_EXCEPTION_INVALID = "exception.invalid.format";

    public static final String SALES_PERMISSION_WRITE = "sales:orders:write";
    public static final String SALES_PERMISSION_DELETE = "sales:orders:delete";
    public static final String SALES_PERMISSION_READ = "sales:orders:read";

    public static final int SCALE_INSTALMENTS = 6;
    public static final int SCALE_DUE_DATE = 6;

    public static final String RULE_PAYMENT_TERM_READ = "sales:payment-terms:read";

    private static final String[] VALIDATE_NOT_NULL_FIELDS_IN_ORDER_SEEDS = {Constants.FIELD_WITHDRAWAL_COMPANY_ID,
            Constants.FIELD_WITHDRAWAL_COMPANY_NAME,
            Constants.FIELD_ORDER_WAREHOUSE,
            Constants.FIELD_INCOTERMS_ID,
            Constants.FIELD_INCOTERMS_ACRONYM};
    private static final String[] VALIDATE_NOT_NULL_FIELDS_IN_ORDER_SEEDS_ITEM = {Constants.FIELD_WITHDRAWAL_COMPANY_ID,
            Constants.FIELD_WITHDRAWAL_COMPANY_NAME,
            Constants.FIELD_ORDER_WAREHOUSE};
    private static final String[] SEEDS_HAS_VALUE_AND_PLUGIN_IS_DISABLED = {Constants.FIELD_WITHDRAWAL_COMPANY_ID,
            Constants.FIELD_WITHDRAWAL_COMPANY_NAME,
            Constants.FIELD_ORDER_WAREHOUSE,
            Constants.FIELD_INCOTERMS_ID,
            Constants.FIELD_INCOTERMS_ACRONYM,
            Constants.FIELD_ORDER_SEEDS};
    private static final String[] SEEDS_HAS_VALUE_AND_PLUGIN_IS_DISABLED_ITEM = {Constants.FIELD_WITHDRAWAL_COMPANY_ID,
            Constants.FIELD_WITHDRAWAL_COMPANY_NAME,
            Constants.FIELD_ORDER_WAREHOUSE,
            Constants.FIELD_ITEM_SEEDS};

    private Constants() {
    }

    public static String[] getConstantsFieldsOrderSeeds() {
        return Constants.VALIDATE_NOT_NULL_FIELDS_IN_ORDER_SEEDS;
    }

    public static String[] getConstantsFieldsOrderSeedsItem() {
        return Constants.VALIDATE_NOT_NULL_FIELDS_IN_ORDER_SEEDS_ITEM;
    }

    public static String[] getConstantsFieldsOrderSeedsIsDisabled() {
        return Constants.SEEDS_HAS_VALUE_AND_PLUGIN_IS_DISABLED;
    }

    public static String[] getConstantsFieldsOrderSeedsIsDisabledItem() {
        return Constants.SEEDS_HAS_VALUE_AND_PLUGIN_IS_DISABLED_ITEM;
    }

}
