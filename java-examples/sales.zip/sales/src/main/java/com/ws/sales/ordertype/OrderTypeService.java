package com.ws.sales.ordertype;

import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class OrderTypeService extends AbstractService<OrderType> {

    private final OrderTypeDAO dao;
    private final OrderTypeValidation validator;

    @Inject
    public OrderTypeService(final OrderTypeDAO dao,
                            final OrderTypeValidation validator) {
        super(dao);
        this.dao = dao;
        this.validator = validator;
    }

    public Boolean orderTypeIsActive(final UUID id) {
        final OrderType orderType = dao.getStateOrdertype(id);
        return Optional.ofNullable(orderType)
                .map(OrderType::getActive)
                .orElse(Boolean.TRUE);
    }

    @Override
    public OrderType insert(OrderType entity) throws Exception {
        validator.validate(entity, EValidationType.INSERT);
        validator.throwFoundErrors();
        return super.insert(entity);
    }

    @Override
    public void update(OrderType entity) throws Exception {
        validator.validate(entity, EValidationType.UPDATE);
        validator.throwFoundErrors();
        super.update(entity);
    }

    /**
     * Returns the order types list. If there are registers at OrderTypePermission must filter
     * order types by permissions(Not implemented yet.) else returns the active ones.
     *
     * @param search
     * @return PagedList<OrderType>
     */
    public PagedList<OrderType> search(final OrderTypeSearch search) {
        return dao.list(search);
    }
}