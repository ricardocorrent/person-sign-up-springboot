package com.ws.sales.orderparameter;

import com.sollar.recordpermission.accessgroup.PermissionChangesQuery;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.resource.IResourceGet;
import com.ws.commons.server.resource.IResourceList;
import com.ws.commons.server.resource.IResourceUpdate;
import com.ws.sales.util.SalesAbstractInternalResource;
import io.ebean.EbeanServer;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * This class represents the Resource of Order Parameter, she received requisitions by REST protocol.
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-22
 */
@Path("/order-parameters")
public class OrderParameterResource extends SalesAbstractInternalResource<OrderParameter> implements IResourceGet<OrderParameter>,
        IResourceList<OrderParameter> {

    private final OrderParameterService service;

    @Inject
    private PermissionChangesQuery permissionChangesQuery;

    @Inject
    private EbeanServer ebeanServer;


    /**
     * Injects OrderParameterService class for communication between layers of OrderParameterResource
     * and OrderParameterService.
     */
    @Inject
    public OrderParameterResource(final OrderParameterService service) {
        this.service = service;
    }

    /**
     * Gets service.
     *
     * @return the service
     */
    @Override
    public AbstractService<OrderParameter> getService() {
        return this.service;
    }

    /**
     * Method to search a list of Order Parameter by filter.
     *
     * @param orderParameterSearch represents the search for order parameter
     * @return
     */
    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions("sales:order-parameters:read")
    public Response search(final OrderParameterSearch orderParameterSearch) throws Exception {
        return Response.ok(this.service.search(orderParameterSearch)).build();
    }


    /**
     * Method to update a Order Parameter
     *
     * @param id as sub resource entity ID.
     * @param entity as sub resource entity to be updated.
     * @return a OK {@link IResourceUpdate} after update.
     * @throws Exception if the update fails.
     */
    @PUT
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions("sales:order-parameters:write")
    public Response update(@PathParam("id") final UUID id, @Valid final OrderParameter entity) throws Exception {
        entity.setId(id);
        this.service.update(entity);
        return Response.ok().build();
    }

}
