package com.ws.sales.ordertype;

import com.ws.commons.server.pagination.PaginationSearch;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class OrderTypeSearch extends PaginationSearch {

    private Boolean[] active;

    private Boolean[] standard;

    private Boolean[] availableFirstOrder;

    private String description;

    /**
     * Gets the options to filter by active.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getActive() {
        return active;
    }

    /**
     * Set the active filter options
     * Options: [true, false]
     *
     * @param active
     */
    public void setActive(final Boolean[] active) {
        this.active = active;
    }

    /**
     * Gets the description to be filtered
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the order type description to filter
     *
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Gets the options to filter by standard.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getStandard() {
        return standard;
    }

    /**
     * Set the standard filter options
     * Options: [true, false]
     *
     * @param standard
     */
    public void setStandard(final Boolean[] standard) {
        this.standard = standard;
    }

    /**
     * Gets the options to filter by availableFirstOrder.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Set the availableFirstOrder filter options
     * Options: [true, false]
     *
     * @param availableFirstOrder
     */
    public void setAvailableFirstOrder(final Boolean[] availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }
}
