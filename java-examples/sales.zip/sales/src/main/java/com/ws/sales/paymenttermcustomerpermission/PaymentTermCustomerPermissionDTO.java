package com.ws.sales.paymenttermcustomerpermission;

import java.util.UUID;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.customer.dto.CustomerDTO;
import com.ws.sales.paymentterm.PaymentTermDTO;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermCustomerPermissionDTO implements IPojoConverter {

    private UUID id;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "customer.id", target = "customerId"),
            @PojoColumnMapper(source = "customer.name", target = "customerName")
    })
    private CustomerDTO customer;

    private PaymentTermDTO paymentTerm;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public CustomerDTO getCustomer() {
        return customer;
    }

    public void setCustomer(final CustomerDTO customer) {
        this.customer = customer;
    }

    public PaymentTermDTO getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(final PaymentTermDTO paymentTerm) {
        this.paymentTerm = paymentTerm;
    }
}
