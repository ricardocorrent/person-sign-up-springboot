package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.ws.sales.order.SalesOrder;

import java.io.IOException;

/**
 * This class represents sales order serializer for invoice item, she will be serialize just the
 * fields id and order number from sales order because it's just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class InvoiceItemSalesOrderSerializer extends StdSerializer<SalesOrder> {

    /**
     * Instantiates a new invoice item sales order serializer.
     */
    public InvoiceItemSalesOrderSerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice item sales order serializer.
     *
     * @param t the t
     */
    protected InvoiceItemSalesOrderSerializer(Class<SalesOrder> t) {
        super(t);
    }

    /**
     * This method override the serialization of SalesOrder for InvoiceItem class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(SalesOrder value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(value.getId());
        salesOrder.setOrderNumber(value.getOrderNumber());
        gen.writeObject(salesOrder);
    }
}