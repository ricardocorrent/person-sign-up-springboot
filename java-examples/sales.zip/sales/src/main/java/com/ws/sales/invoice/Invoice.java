package com.ws.sales.invoice;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.invoicesituation.InvoiceSituation;
import com.ws.sales.invoicetype.InvoiceType;
import com.ws.sales.paymentterm.PaymentTerm;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * This class represents the entity Invoice.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Entity
@PreventRecycling
public class Invoice extends SoftDeleteBaseEntity implements Serializable {

    private static final String INVOICE_NAME = "invoice";

    /**
     * This field represents the number for the Invoice.
     */
    @NotNull
    @Size(max = 20)
    private String number;

    /**
     * This field represents the series for the Invoice.
     */
    @NotNull
    @Size(max = 80)
    private String series;

    /**
     * This field represents the total for the Invoice.
     */
    @NotNull
    @Column(precision = 18, scale = 6)
    private BigDecimal total;

    /**
     * This field represents the note for the Invoice.
     */
    @Size(max = 4000)
    private String note;

    /**
     * This field represents the billing date for the Invoice.
     */
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private LocalDate billingDate;

    /**
     * This field represents the relationship of Invoice with InvoiceCurrency.
     */
    @Valid
    @OneToOne(mappedBy = INVOICE_NAME, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceCurrencySerializer.class)
    private InvoiceCurrency invoiceCurrency;

    /**
     * This field represents the relationship of Invoice with InvoiceCustomer.
     */
    @Valid
    @NotNull
    @OneToOne(mappedBy = INVOICE_NAME, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceCustomerSerializer.class)
    private InvoiceCustomer invoiceCustomer;

    /**
     * This field represents the relationship of Invoice with InvoiceLocation.
     */
    @Valid
    @OneToOne(mappedBy = INVOICE_NAME, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceLocationSerializer.class)
    private InvoiceLocation invoiceLocation;

    /**
     * This field represents the relationship of Invoice with InvoiceUser.
     */
    @Valid
    @OneToOne(mappedBy = INVOICE_NAME, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceUserSerializer.class)
    private InvoiceUser invoiceUser;

    /**
     * This field represents the relationship of Invoice with PaymentTerm.
     */
    @ManyToOne
    @JoinColumn(name = "payment_term_id")
    @JsonSerialize(using = InvoicePaymentTermSerializer.class)
    private PaymentTerm paymentTerm;

    /**
     * This field represents the relationship of Invoice with Invoice.
     */
    @NotNull
    @ManyToOne
    @JoinColumn(name = "invoice_situation_id")
    private InvoiceSituation invoiceSituation;

    /**
     * This field represents the relationship of Invoice with InvoiceItem.
     */
    @Valid
    @OneToMany(mappedBy = INVOICE_NAME, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<InvoiceItem> invoiceItems;

    /**
     * This field represents the relationship of Invoice with InvoiceType.
     */
    @NotNull
    @ManyToOne
    @JoinColumn(name = "invoice_type_id")
    private InvoiceType invoiceType;

    /**
     * Gets number.
     *
     * @return the number
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets number.
     *
     * @param number the number
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * Gets series.
     *
     * @return the series
     */
    public String getSeries() {
        return series;
    }

    /**
     * Sets series.
     *
     * @param series the series
     */
    public void setSeries(String series) {
        this.series = series;
    }

    /**
     * Gets total.
     *
     * @return the total
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Sets total.
     *
     * @param total the total
     */
    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    /**
     * Gets note.
     *
     * @return the note
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets note.
     *
     * @param note the note
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * Gets billing date.
     *
     * @return the billing date
     */
    public LocalDate getBillingDate() {
        return billingDate;
    }

    /**
     * Sets billing date.
     *
     * @param billingDate the billing date
     */
    public void setBillingDate(LocalDate billingDate) {
        this.billingDate = billingDate;
    }

    /**
     * Gets invoice currency.
     *
     * @return the invoice currency
     */
    public InvoiceCurrency getInvoiceCurrency() {
        return invoiceCurrency;
    }

    /**
     * Sets invoice currency.
     *
     * @param invoiceCurrency the invoice currency
     */
    public void setInvoiceCurrency(InvoiceCurrency invoiceCurrency) {
        this.invoiceCurrency = invoiceCurrency;
    }

    /**
     * Gets invoice customer.
     *
     * @return the invoice customer
     */
    public InvoiceCustomer getInvoiceCustomer() {
        return invoiceCustomer;
    }

    /**
     * Sets invoice customer.
     *
     * @param invoiceCustomer the invoice customer
     */
    public void setInvoiceCustomer(InvoiceCustomer invoiceCustomer) {
        this.invoiceCustomer = invoiceCustomer;
    }

    /**
     * Gets invoice location.
     *
     * @return the invoice location
     */
    public InvoiceLocation getInvoiceLocation() {
        return invoiceLocation;
    }

    /**
     * Sets invoice location.
     *
     * @param invoiceLocation the invoice location
     */
    public void setInvoiceLocation(InvoiceLocation invoiceLocation) {
        this.invoiceLocation = invoiceLocation;
    }

    /**
     * Gets invoice user.
     *
     * @return the invoice user
     */
    public InvoiceUser getInvoiceUser() {
        return invoiceUser;
    }

    /**
     * Sets invoice user.
     *
     * @param invoiceUser the invoice user
     */
    public void setInvoiceUser(InvoiceUser invoiceUser) {
        this.invoiceUser = invoiceUser;
    }

    /**
     * Gets payment term.
     *
     * @return the payment term
     */
    public PaymentTerm getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * Sets payment term.
     *
     * @param paymentTerm the payment term
     */
    public void setPaymentTerm(PaymentTerm paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    /**
     * Gets invoice situation.
     *
     * @return the invoice situation
     */
    public InvoiceSituation getInvoiceSituation() {
        return invoiceSituation;
    }

    /**
     * Sets invoice situation.
     *
     * @param invoiceSituation the invoice situation
     */
    public void setInvoiceSituation(InvoiceSituation invoiceSituation) {
        this.invoiceSituation = invoiceSituation;
    }

    /**
     * Gets invoice items.
     *
     * @return the invoice items
     */
    public List<InvoiceItem> getInvoiceItems() {
        return invoiceItems;
    }

    /**
     * Sets invoice items.
     *
     * @param invoiceItems the invoice items
     */
    public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
        this.invoiceItems = invoiceItems;
    }

    /**
     * Gets invoice type.
     *
     * @return the invoice type
     */
    public InvoiceType getInvoiceType() {
        return invoiceType;
    }

    /**
     * Sets invoice type.
     *
     * @param invoiceType the invoice type
     */
    public void setInvoiceType(InvoiceType invoiceType) {
        this.invoiceType = invoiceType;
    }
}
