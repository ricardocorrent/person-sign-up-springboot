package com.ws.sales.paymentterm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.util.Constants;

import io.ebean.ExpressionList;
import io.ebean.Query;
import io.ebean.RawSql;
import io.ebean.RawSqlBuilder;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 * 
 * @author william.santos
 * @since V7.0.0 - 2018-09-14
 * @version 2.0.0
 */
public class PaymentTermDAO extends AbstractDAO<PaymentTerm> {

    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class<PaymentTerm> getEntityClass() {
        return PaymentTerm.class;
    }

    /**
     * Filters Payment terms.
     *
     * @param search
     * @return PagedList<PaymentTerm>
     */
    public PagedList<PaymentTerm> list(final PaymentTermSearch search) {
        
        final UUID[] paymentTermIds = search.getPaymentTermIds();
        if (search.getOrderTest() && ArrayUtils.isEmpty(paymentTermIds)) {
            return new PagedList<>(new ArrayList<>(), 0, search.getPage(), search.getPageSize());
        }

        final Query<PaymentTerm> query = find();

        final ExpressionList<PaymentTerm> where = query.where();

        final String generalSearch = search.getGeneralSearch();
        if (generalSearch != null) {
            where.icontains("description", generalSearch);
        }

        this.applyFilters(where, search);

        return getPagedList(query, search);
    }
    
    public PagedList<PaymentTerm> listWithPermissions(final PaymentTermSearchWithPriceList search) {
        final String sql = "SELECT " +
                "       pt.id, pt.version, pt.external_id, pt.active, pt.standard, " +
                "       pt.available_first_order, pt.description, pt.acronym, " +
                "       pt.code, pt.created_at, pt.updated_at, pt.deleted, " +
                "       pt.middle_term, pt.allow_change_due_date " +
                "FROM payment_term pt " +
                "LEFT JOIN payment_term_company_permission cp on cp.payment_term_id = pt.id AND cp.deleted = FALSE " +
                "LEFT JOIN payment_term_location_permission lp on lp.payment_term_id = pt.id AND lp.deleted = FALSE " +
                "LEFT JOIN payment_term_user_permission up on up.payment_term_id = pt.id AND up.deleted = FALSE " +
                "WHERE ((((cp.company_id = CAST(:companyId AS UUID) AND cp.deleted = FALSE) " +
                "       AND (lp.location_id = CAST(:locationId AS UUID) AND lp.deleted = FALSE) " +
                "       AND up.id IS NULL) " +
                "OR ((up.user_id = CAST(:userId AS UUID) AND up.deleted = FALSE) " +
                "       AND (lp.location_id = CAST(:locationId AS UUID) AND lp.deleted = FALSE) " +
                "       AND cp.id IS NULL) " +
                "OR ((lp.location_id = CAST(:locationId AS UUID) AND lp.deleted = FALSE) " +
                "       AND cp.id IS NULL " +
                "       AND up.id IS NULL) " +
                "OR (lp.id IS NULL " +
                "       AND cp.id IS NULL " +
                "       AND (up.user_id = CAST(:userId AS UUID))) AND up.deleted = FALSE)) " +
                "AND (pt.active = :active) ";


        final RawSql rawSql = RawSqlBuilder.parse(sql).create();

        final Query<PaymentTerm> query = find()
                .setRawSql(rawSql)
                .setParameter(Constants.FIELD_COMPANY_ID, search.getCompanyId())
                .setParameter(Constants.FIELD_LOCATION_ID, search.getLocationId())
                .setParameter(Constants.FIELD_USER_ID, search.getUserId())
                .setParameter(Constants.FIELD_ACTIVE,
                        Optional.ofNullable(search.getActive())
                        .filter(active -> active.length > 0)
                        .map(active -> active[0])
                        .orElse(Boolean.TRUE)
                );

        this.applyFilters(query.where(), search);

        return getPagedList(query, search);
    }
    
    /**
     * Apply filters to search
     *
     * @param search {@link PaymentTermSearchWithPriceList} to filter the register
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-25
     */
    private void applyFilters(final ExpressionList<PaymentTerm> where, final PaymentTermSearchWithPriceList search) {
        this.applyDescription(where, search);
        this.applyCode(where, search);
        this.applyAcronym(where, search);
        this.applyActive(where, search);
        this.applyStandard(where, search);
        this.applyAvailableFirstOrder(where, search);
        this.applyPaymentTermIds(where, search);
        this.applySearchWithoutPermissions(where, search);

    }

    private void applyFilters(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        this.applyDescription(where, search);
        this.applyCode(where, search);
        this.applyAcronym(where, search);
        this.applyActive(where, search);
        this.applyStandard(where, search);
        this.applyAvailableFirstOrder(where, search);
        this.applyPaymentTermIds(where, search);
    }

    private void applyDescription(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final String description = search.getDescription();
        if (StringUtils.isNotEmpty(description)) {
            where.icontains("description", description);
        }
    }

    private void applyCode(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final String code = search.getCode();
        if (StringUtils.isNotEmpty(code)) {
            where.icontains("code", code);
        }
    }

    private void applyAcronym(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final String acronym = search.getAcronym();
        if (StringUtils.isNotEmpty(acronym)) {
            where.icontains("acronym", acronym);
        }
    }

    private void applyActive(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final Boolean[] active = search.getActive();
        if (ArrayUtils.isNotEmpty(active)) {
            where.eq("active", active[0]);
        }
    }

    private void applyStandard(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final Boolean[] standard = search.getStandard();
        if (ArrayUtils.isNotEmpty(standard)) {
            where.eq("standard", standard[0]);
        }
    }

    private void applyAvailableFirstOrder(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final Boolean[] availableFirstOrder = search.getAvailableFirstOrder();
        if (ArrayUtils.isNotEmpty(availableFirstOrder)) {
            where.eq("availableFirstOrder", availableFirstOrder[0]);
        }
    }

    private void applyPaymentTermIds(final ExpressionList<PaymentTerm> where, final PaymentTermSearch search) {
        final UUID[] paymentTermIds = search.getPaymentTermIds();
        if (ArrayUtils.isNotEmpty(paymentTermIds)) {
            where.in("id", Arrays.asList(paymentTermIds));
        }
    }
    
    /**
     * Set the search to get only the registers that does not have permission with anyone.
     * This filter is used in the last search for the entities.
     * It will only return entities that does not have any permissions.
     *
     * @param search {@link PaymentTermSearchWithPriceList} to filter the register
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-25
     */
    private void applySearchWithoutPermissions(final ExpressionList<PaymentTerm> where, final PaymentTermSearchWithPriceList search) {
        final Boolean searchWithoutPermission = Optional.ofNullable(search.getSearchWithoutPermission()).orElse(Boolean.FALSE);
        if (searchWithoutPermission) {
            where.eq("customerPermissions", null);
            where.eq("userPermissions", null);
            where.eq("companyPermissions", null);
            where.eq("locationPermissions", null);
        }
    }

    /**
     * @return a single {@link PaymentTerm} which standard property is equals true
     * @author Sanderson silva
     * @since 1.0.0 2016-10-11
     */
    public PaymentTerm getStandard() {
        return find().where().eq("standard", Boolean.TRUE).findOne();
    }

    /**
     * Check if Payment Term exists.
     *
     * @param id {@link PaymentTerm#id}
     * @return {@code true} or {@code false}
     * @author Diego Peliser <diego.peliser@wssim.com.br>
     */
    public boolean paymentTermExists(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("id").where().eq("id", id).findCount() > 0;
    }

    /**
     * @author Marcos Matheus de andrade
     */
    public PaymentTerm getStatePaymentTerm(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("active").where().eq("id", id).findOne();
    }

}
