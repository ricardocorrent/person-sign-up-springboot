package com.ws.sales.ordertype;

import java.util.Objects;

import javax.enterprise.inject.Default;
import javax.inject.Inject;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29
 */
@Default
public class OrderTypeValidation extends AbstractEntityValidator<OrderType> {

    private final OrderTypeDAO dao;

    @Inject
    public OrderTypeValidation(final OrderTypeDAO dao) {
        this.dao = dao;
    }

    /**
     * @return {@code error} when there isn't a standard record (or is an edition of it), or {@code null} otherwise * @author/refactor ricardo.corrent
     * @since 2019-01-17
     * @version 1.0.0
     */
    public LogicError validHasStandard(final OrderType orderType) {
        if(Objects.nonNull(orderType.getStandard()) && orderType.getStandard()) {
            final OrderType dbStandard = this.dao.getStandard();
            if (Objects.nonNull(dbStandard)) {
                if (Objects.isNull(orderType.getId()) || !orderType.getId().equals(dbStandard.getId())) {
                    return ValidationUtils.doCreateLogicErrorWithParam(Constants.ORDER_TYPE_KEY,
                            dbStandard.getDescription(),
                            Constants.FIELD_ORDER_TYPE_STANDARD,
                            Constants.MESSAGE_VALUE_STANDARD_UNIQUE_VALIDATION);
                }
            }
        }
        return null;
    }

    @Override
    protected void validate(OrderType entity, IValidationFilter... filter) {
        if (Objects.nonNull(validHasStandard(entity))) {
            addError(validHasStandard(entity), entity);
        }
    }
}
