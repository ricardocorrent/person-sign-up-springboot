package com.ws.sales.order.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * @author Bruno Capeleto Rodrigues <bruno.rodrigues@wssim.com.br>
 * @since 05-17-2019
 */
@Getter
@Setter
public class OrderSummaryServicesDTO extends BaseDTO {

    private BigDecimal quantity;

    private BigDecimal discountValue;

}
