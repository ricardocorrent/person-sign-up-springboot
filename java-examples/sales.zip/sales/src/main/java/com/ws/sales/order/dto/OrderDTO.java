package com.ws.sales.order.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * Created by sergio.junior on 11/9/2017.
 */
public class OrderDTO extends BaseDTO implements DefaultPojoConverter {
}
