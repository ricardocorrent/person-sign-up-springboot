package com.ws.sales.paymenttermcompanypermission;

import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermCompanyPermissionService extends AbstractService<PaymentTermCompanyPermission> {

    private final PaymentTermDAO paymentTermDAO;
    private final PaymentTermCompanyPermissionValidator paymentTermCompanyPermissionValidator;

    /**
     * @param paymentTermCompanyPermissionDAO       to perform entity persistence
     * @param paymentTermDAO                        to load {@link PaymentTerm}
     * @param paymentTermCompanyPermissionValidator to handle permission validations
     **/
    @Inject
    public PaymentTermCompanyPermissionService(final PaymentTermCompanyPermissionDAO paymentTermCompanyPermissionDAO, final PaymentTermDAO paymentTermDAO,
                                               final PaymentTermCompanyPermissionValidator paymentTermCompanyPermissionValidator) {
        super(paymentTermCompanyPermissionDAO);
        this.paymentTermDAO = paymentTermDAO;
        this.paymentTermCompanyPermissionValidator = paymentTermCompanyPermissionValidator;
    }

    /**
     * @param paymentTermCompanyPermissions {@link List<PaymentTermCompanyPermission>} to persist
     * @param paymentTermId                 to get {@link PaymentTerm}
     **/
    public void insertList(final List<PaymentTermCompanyPermission> paymentTermCompanyPermissions, final UUID paymentTermId) {
        final PaymentTerm paymentTerm = paymentTermDAO.findById(paymentTermId);
        this.doValidateByBeanValidation(paymentTermCompanyPermissions);
        this.doValidateLogic(paymentTermCompanyPermissions, paymentTerm);
        this.dao.batchInsert(paymentTermCompanyPermissions);
    }

    /**
     * @param paymentTermId to fill the search
     * @return {@link PagedList<PaymentTermCompanyPermission>}
     **/
    public PagedList<PaymentTermCompanyPermission> getByPaymentTerm(final UUID paymentTermId) {
        return ((PaymentTermCompanyPermissionDAO) this.dao).getByPaymentTerm(paymentTermId);
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors. After validate, it will throw the errors
     *
     * @param paymentTermCompanyPermissions {@link List<PaymentTermCompanyPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateByBeanValidation(final List<PaymentTermCompanyPermission> paymentTermCompanyPermissions) {
        IntStream.range(0, paymentTermCompanyPermissions.size())
                .forEach(index -> paymentTermCompanyPermissionValidator.validateByBeanValidation(paymentTermCompanyPermissions.get(index), String.valueOf(index)));
        paymentTermCompanyPermissionValidator.throwFoundErrors();
    }

    /**
     * <p>
     * Uses a for to handle the validations, because the position in the list is needed to
     * handle the index of the entity and group errors.
     *
     * @param paymentTermCompanyPermissions {@link List<PaymentTermCompanyPermission>} to validate
     * @throws ConstraintViolationException if there are any errors
     **/
    private void doValidateLogic(final List<PaymentTermCompanyPermission> paymentTermCompanyPermissions, final PaymentTerm paymentTerm) {
        IntStream.range(0, paymentTermCompanyPermissions.size())
                .forEach(index -> paymentTermCompanyPermissionValidator.validate(paymentTermCompanyPermissions.get(index),
                        paymentTerm.getCompanyPermissions(),
                        String.valueOf(index)));
        paymentTermCompanyPermissionValidator.throwFoundErrors();
    }
}
