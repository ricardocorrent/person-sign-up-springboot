package com.ws.sales.orderhistoric;

import com.ws.commons.persistence.AbstractDAO;

/**
 * @author Thyago Volpatto
 * @since v5.2.0 2017-04-05.
 */
public class SalesOrderHistoricDAO extends AbstractDAO<SalesOrderHistoric> {


    @Override
    public Class<SalesOrderHistoric> getEntityClass() {
        return SalesOrderHistoric.class;
    }
}