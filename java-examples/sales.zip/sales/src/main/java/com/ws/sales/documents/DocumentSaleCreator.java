package com.ws.sales.documents;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.UUID;

/**
 * Copied class to avoid to use the DocumentSaleCreator From DocumentManager Client.
 *
 * @author dante.basso <dante.basso@wssim.com.br>
 * @since 2019-03-20
 * @version 1.0.0
 */
public class DocumentSaleCreator {

    @Size(min = 0, max = 100)
    private String name;

    @NotNull
    private UUID templateId;

    private DocumentCreatorFormat format;

    /**
     * Get {@link #name}
     *
     * @return {@link String}
     */
    public String getName() {
        return name;
    }

    /**
     * Set {@link #name}
     *
     * @param name
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Get {@link #format}
     *
     * @return
     */
    public DocumentCreatorFormat getFormat() {
        return format;
    }

    /**
     * Set {@link #format}
     *
     * @param format
     */
    public void setFormat(final DocumentCreatorFormat format) {
        this.format = format;
    }

    /**
     * Get {@link #templateId}
     *
     * @return
     */
    public UUID getTemplateId() {
        return templateId;
    }

    /**
     * Set {@link #templateId}
     * @param templateId
     */
    public void setTemplateId(UUID templateId) {
        this.templateId = templateId;
    }

}
