package com.ws.sales.situation;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
@Entity
public class Situation extends SoftDeleteBaseEntity implements Serializable {

    @NotNull
    private Boolean active;

    @NotNull
    @Size(max = 255)
    private String description;

    private UUID imageId;

    @Size(max = 40)
    private String acronym;

    private BigDecimal rank;

    private String icon;

    /**
     * Check if is active
     *
     * @return java.lang.Boolean
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Define if it's  active
     *
     * @param active
     */
    public void setActive(final Boolean active) {
        this.active = active;
    }

    /**
     * Gets the description
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the situation description
     *
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Gets the image id
     *
     * @return java.util.UUID
     */
    public UUID getImageId() {
        return imageId;
    }

    /**
     * Sets the image id
     *
     * @param imageId
     */
    public void setImageId(final UUID imageId) {
        this.imageId = imageId;
    }

    /**
     * Gets the situation acronym
     *
     * @return java.lang.String
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Sets the situation acronym
     *
     * @param acronym
     */
    public void setAcronym(final String acronym) {
        this.acronym = acronym;
    }

    /**
     * Gets the rank of a  situation.
     * Used to establish the sequence between all situations.
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getRank() {
        return rank;
    }

    /**
     * Sets the rank
     *
     * @param rank
     */
    public void setRank(final BigDecimal rank) {
        this.rank = rank;
    }

    /**
     * Gets the Icon description.
     *
     * @return
     */
    public String getIcon() {
        return icon;
    }

    /**
     * Define which Icon will be shown.
     * Icons: http://fontawesome.io/icons/
     * <p>
     * Example:
     * situationIcon = "fa-envelope-open fa-2x red";
     *
     * @param icon a String  with the name and color and size of the icon
     */
    public void setIcon(final String icon) {
        this.icon = icon;
    }
}
