package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * This class represents invoice user serializer for invoice item, she will be serialize just the
 * fields id and name from invoice user because it's just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
public class InvoiceUserSerializer extends StdSerializer<InvoiceUser> {

    /**
     * Instantiates a new invoice user serializer.
     */
    public InvoiceUserSerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice user serializer.
     *
     * @param t the t
     */
    protected InvoiceUserSerializer(Class<InvoiceUser> t) {
        super(t);
    }

    /**
     * This method override the serialization of InvoiceUser for Invoice class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(InvoiceUser value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        InvoiceUser invoiceUser = new InvoiceUser();
        invoiceUser.setId(value.getId());
        invoiceUser.setReplicatedId(value.getReplicatedId());
        invoiceUser.setName(value.getName());
        gen.writeObject(invoiceUser);
    }
}