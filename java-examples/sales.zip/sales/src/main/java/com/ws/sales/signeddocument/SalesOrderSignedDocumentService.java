package com.ws.sales.signeddocument;

import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.sales.external.integrationhub.documentsign.DigitalDocSignatureService;
import com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureResponse;
import com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureSignatories;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.signeddocument.checkupdate.CheckUpdateResponseDTO;

import java.util.List;
import java.util.UUID;
import javax.inject.Inject;

/**
 * Service class to manage requests from external resources or services for {@link SalesOrderSignedDocument}.
 *
 * @since 1.0.0 2019-05-03
 *
 * @author Ricardo Corrent
 */
public class SalesOrderSignedDocumentService extends AbstractService<SalesOrderSignedDocument> {

    private final SalesOrderSignedDocumentDAO signedDocumentDAO;
    private final SalesOrderSignedDocumentValidator signedDocumentValidator;
    private final DigitalDocSignatureService digitalDocSignatureService;

    /**
     * Injectable constructor with need instances to attend requests.
     *
     * @param signedDocumentDAO DAO feature instance to CRUD operations
     * @param salesOrderSignedDocumentValidator Validator feature instance to ensure data constraint.
     */
    @Inject
    public SalesOrderSignedDocumentService(final SalesOrderSignedDocumentDAO signedDocumentDAO,
                                           final SalesOrderSignedDocumentValidator salesOrderSignedDocumentValidator,
                                           final DigitalDocSignatureService digitalDocSignatureService) {
        super(signedDocumentDAO);
        this.signedDocumentDAO = signedDocumentDAO;
        this.signedDocumentValidator = salesOrderSignedDocumentValidator;
        this.digitalDocSignatureService = digitalDocSignatureService;
    }

    /**
     * Inserts a new {@link SalesOrderSignedDocument} after providing standard information and validating it.
     *
     * @param entity The feature instance to be added.
     *
     * @return The successfully inserted feature instance id
     *
     * @throws Exception if the order Id was not found.
     */
    @Override
    public SalesOrderSignedDocument insert(final SalesOrderSignedDocument entity) throws Exception {
        this.signedDocumentValidator.validateAndThrowFoundErrors(entity, EValidationType.INSERT);
        return super.insert(entity);
    }

    /**
     * Updates an existing {@link SalesOrderSignedDocument} after validating it.
     *
     * @param entity The feature instance to have its persisted data updated.
     *
     * @throws Exception if the order Id was not found.
     */
    @Override
    public void update(final SalesOrderSignedDocument entity) throws Exception {
        this.signedDocumentValidator.validateAndThrowFoundErrors(entity, EValidationType.UPDATE);
        super.update(entity);
    }

    /**
     * Returns an existing PagedList of {@link SalesOrderSignedDocument} from an orderId.
     *
     * @param orderId salesOrderId to be recovered a list of signed documents
     * @param restQueryAdapter Translated request options to perform projection or additional filter.
     * @return a PagedList that contains a list of existing signed document in an order
     */
    public PagedList<SalesOrderSignedDocument> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        this.signedDocumentValidator.validateOrder(orderId);
        return this.signedDocumentDAO.findByOrder(orderId, restQueryAdapter);
    }

    /**
     * This method returns a list of {@link SalesOrderSignedDocument} from an orderId
     *
     * @param orderId {@link UUID}
     * @return {@link List} of {@link SalesOrderSignedDocument}
     */
    private List<SalesOrderSignedDocument> getListOfDocumentsByOrder(final UUID orderId) {
        return this.signedDocumentDAO.listByOrder(orderId);
    }

    /**
     * This method verify and update the list of {@link SalesOrderSignedDocument} from {@link SalesOrder}
     *
     * @param salesOrder {@link UUID} used to search
     * @return a number of updated documents
     * @throws Exception if during update an error occurred
     */
    public CheckUpdateResponseDTO updateDocumentsSigned(final SalesOrder salesOrder) throws Exception {
        final List<SalesOrderSignedDocument> signedDocuments = getListOfDocumentsByOrder(salesOrder.getId());
        final Integer itemsUpdated = this.countSignedDocuments(signedDocuments);
        return new CheckUpdateResponseDTO(itemsUpdated);
    }

    /**
     * This method run the {@link List} of {@link SalesOrderSignedDocument} and send to update if necessary
     *
     * @param signedDocuments {@link List}
     * @return number of documents that have been updates
     * @throws Exception is during update an error occurred
     */
    private Integer countSignedDocuments(List<SalesOrderSignedDocument> signedDocuments) throws Exception {
        int numberOrDocumentsUpdated = 0;
        for (SalesOrderSignedDocument document : signedDocuments) {
            if (document.getFileSignedUrl() == null || document.getRejected() == null) {
                final SalesOrderSignedDocument newDocument = this.doUpdateOnDocument(document);
                if (newDocument != null) {
                    numberOrDocumentsUpdated++;
                    this.update(newDocument);
                }
            }
        }
        return numberOrDocumentsUpdated;
    }

    /**
     * This method receives the {@link SalesOrderSignedDocument} and verifies which property must have updated
     *
     * @param document {@link SalesOrderSignedDocument}
     * @return a new {@link SalesOrderSignedDocument} with new values ou null if there were no updates
     */
    private SalesOrderSignedDocument doUpdateOnDocument(final SalesOrderSignedDocument document) {
        final DigitalDocSignatureResponse digitalDocSignatureResponse = digitalDocSignatureService.getDocumentInfo(document.getDocumentId());
        boolean documentUpdated = false;
        if (document.getFileSignedUrl() == null) {
            final String fileSignedUrl = this.updateFileSignedUrl(digitalDocSignatureResponse);
            if (fileSignedUrl != null) {
                document.setFileSignedUrl(fileSignedUrl);
                documentUpdated = true;
            }
        }
        if(document.getRejected() == null) {
            final Boolean rejected = this.updateRejected(digitalDocSignatureResponse);
            if(rejected != null) {
                document.setRejected(rejected);
                documentUpdated = true;
            }
        }
        if (documentUpdated) {
            return document;
        }
        return null;
    }

    /**
     * This method verify and returns true if documents are rejected, false if assigned or null if there are still no interactions
     *
     * @param digitalDocSignatureResponse {@link DigitalDocSignatureResponse}
     * @return true, false or null
     */
    private Boolean updateRejected(final DigitalDocSignatureResponse digitalDocSignatureResponse) {
        if (digitalDocSignatureResponse != null) {
            DigitalDocSignatureSignatories digitalDocSignatureSignatories =
                    digitalDocSignatureResponse
                            .getSignatories()
                            .stream()
                            .findAny()
                            .orElseGet(null);

            if (digitalDocSignatureSignatories != null) {
                if (digitalDocSignatureSignatories.getRejectedAt() != null) {
                    return true;
                }
                if (digitalDocSignatureSignatories.getSignedAt() != null) {
                    return false;
                }
            }
        }
        return null;
    }

    /**
     * This method gets a {@link String} with the file signed url to be used on document
     *
     * @param digitalDocSignatureResponse {@link DigitalDocSignatureResponse} that contains information about the signature
     * @return {@link String} if exists url or {@link null} if don't
     */
    private String updateFileSignedUrl(final DigitalDocSignatureResponse digitalDocSignatureResponse) {
        if (digitalDocSignatureResponse != null) {
                return digitalDocSignatureResponse.getDocument().getFileSignedUrl();
        }
        return null;
    }
}
