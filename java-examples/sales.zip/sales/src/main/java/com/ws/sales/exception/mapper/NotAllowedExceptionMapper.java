package com.ws.sales.exception.mapper;

import java.io.IOException;
import java.io.StringWriter;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.NotAllowedException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.codehaus.jackson.map.ObjectMapper;

import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messagebundle.MessageBundle;
import com.ws.commons.server.validation.CustomModelValidation;

/**
 * @author Frank Pilloni Tominc <frank.tominc@wssim.com.br>
 * @since 19/04/18
 * @deprecated use {@link com.ws.commons.server.validation.exception.NotAllowedExceptionMapper}
 */
@Deprecated
public class NotAllowedExceptionMapper implements ExceptionMapper<NotAllowedException> {

    private final MessageBundle bundle;
    @Context
    private HttpServletRequest request;

    @Inject
    public NotAllowedExceptionMapper(final MessageBundle bundle) {
        this.bundle = bundle;
    }


    @Override
    public Response toResponse(final NotAllowedException exception) {

        final StringWriter writer = new StringWriter();
        final ObjectMapper mapper = new ObjectMapper();
        final ExceptionMessage message = this.bundle.getMessage("orderConfig.notAllowed", this.request.getLocale());
        try {

            final CustomModelValidation customModelValidation = new CustomModelValidation(bundle);
            customModelValidation.setText(customModelValidation.getMessage());
            mapper.writeValue(writer, customModelValidation);

        } catch (final IOException e) {
            throw new RuntimeException(e);
        }

        final Response response = exception.getResponse();
        return Response.status(response.getStatus())
                .type(MediaType.APPLICATION_JSON)
                .entity(message)
                .allow(response.getAllowedMethods())
                .build();
    }
}
