package com.ws.sales.documents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import org.apache.commons.lang3.StringUtils;

/**
 * @author dante.basso <dante.basso@wssim.com.br>
 * @since 2019-01-15
 * @version 1.0.0
 */
public enum DocumentCreatorFormat {

    /**
     * format as ".docx".
     */
    DOCX("docx"),

    /**
     * format as ".pdf"
     */
    PDF("pdf"),

    /**
     * will not change the file format
     */
    ORIGINAL_FORMAT("docx"),

    /**
     * invalid format extension
     */
    INVALID("");


    /**
     * Nome of ENUM
     */
    private String name;

    /**
     * Constructor
     *
     * @param fileFormat
     */
    DocumentCreatorFormat(final String fileFormat) {
        this.name = fileFormat;
    }

    /**
     * Create a enum with case insensitive on name
     *
     * @param name
     * @return {@link DocumentCreatorFormat}
     */
    @JsonCreator
    public static DocumentCreatorFormat fromString(final String name) {
        try {
            return StringUtils.isEmpty(name) ? DocumentCreatorFormat.ORIGINAL_FORMAT : DocumentCreatorFormat.valueOf(name.trim().toUpperCase());
        } catch (final IllegalArgumentException e) {
            // Invalid value on name causes the IllegalArgumentException, returns INVALID to not causes error on Jackson JSON
            return INVALID;
        }
    }

    /**
     * the of fileFormat in lower case.
     *
     * @return String
     */
    @JsonValue
    @Override
    public String toString() {
        return this.name;
    }

    /**
     * the of fileFormat in lower case.
     *
     * @return String
     */
    public String getFileExtension() {
        final StringBuilder builder = new StringBuilder();
        builder.append('.');
        builder.append(toString());
        return builder.toString();
    }

}
