package com.ws.sales.documents.requestsignature;

import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * This class has been created to send a response with the data persisted in data base
 *
 * @since 1.0.0 2019-05-10
 *
 * @author Ricardo Corrent
 */
public class RequestSignatureResponseDTO implements DefaultPojoConverter {

    private String salesOrderSignedDocumentId;

    public RequestSignatureResponseDTO(final String salesOrderSignedDocumentId) {
        this.salesOrderSignedDocumentId = salesOrderSignedDocumentId;
    }

    public String getSalesOrderSignedDocumentId() {
        return salesOrderSignedDocumentId;
    }

    public void setSalesOrderSignedDocumentId(final String salesOrderSignedDocumentId) {
        this.salesOrderSignedDocumentId = salesOrderSignedDocumentId;
    }
}
