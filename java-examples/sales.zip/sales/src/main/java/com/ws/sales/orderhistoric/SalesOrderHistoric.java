package com.ws.sales.orderhistoric;

import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.sales.order.SalesOrder;
import io.ebean.annotation.DbJsonB;

import javax.persistence.Entity;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author thyago.volpatto
 * @since v5.2.0 04/05/2017.
 */
@Entity
@PreventRecycling
public class SalesOrderHistoric extends SoftDeleteBaseEntity implements Serializable {

    private UUID salesOrderId;

    @DbJsonB
    private SalesOrder originalOrder;

    private UUID userId;

    @Size(max = 255)
    private String username;

    /**
     * @return java.util.UUID
     */
    public UUID getSalesOrderId() {
        return salesOrderId;
    }

    /**
     * @param salesOrderId
     */
    public void setSalesOrderId(final UUID salesOrderId) {
        this.salesOrderId = salesOrderId;
    }

    /**
     * @return {@Link SalesOrder}
     */
    public SalesOrder getOriginalOrder() {
        return originalOrder;
    }

    /**
     * @param originalOrder
     */
    public void setOriginalOrder(final SalesOrder originalOrder) {
        this.originalOrder = originalOrder;
    }

    /**
     * @return java.util.UUID
     */
    public UUID getUserId() {
        return userId;
    }

    /**
     * @param userId
     */
    public void setUserId(final UUID userId) {
        this.userId = userId;
    }

    /**
     * @return java.lang.String
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(final String username) {
        this.username = username;
    }
}
