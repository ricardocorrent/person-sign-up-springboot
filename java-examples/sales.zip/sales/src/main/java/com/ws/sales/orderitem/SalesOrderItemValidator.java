package com.ws.sales.orderitem;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.annotation.PojoColumnBackReference;
import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.commons.utils.ArrayUtils;
import com.ws.product.model.*;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.product.dto.DiscountDTO;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.orderitem.validations.SalesOrderItemDueDatePluginValidations;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.GenericValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Stream;

/**
 * @author Marco Aurelio F Schaefer
 * @since v3.0.0 2017-12-13.
 */
@Default
@BeanValidationIntegrated(SalesOrderItem.class)
public class SalesOrderItemValidator extends AbstractEntityValidator<SalesOrderItem> {

    private static final BigDecimal BIG_DECIMAL_ONE_HUNDRED = new BigDecimal("100");
    private static final int SCALE = 6;
    private final Logger logger = LoggerFactory.getLogger(SalesOrderItemValidator.class);
    private final ProductGateway productGateway;
    private final SalesOrderDAO orderDAO;
    private final OrderParameterDAO orderParameterDAO;
    private final SalesOrderValidator salesOrderValidator;
    private final SalesOrderItemDueDatePluginValidations salesOrderItemDueDatePluginValidations;

    @Inject
    public SalesOrderItemValidator(final ProductGateway productGateway,
                                   final SalesOrderDAO orderDAO,
                                   final OrderParameterDAO orderParameterDAO,
                                   final SalesOrderValidator salesOrderValidator,
                                   final SalesOrderItemDueDatePluginValidations salesOrderItemDueDatePluginValidations
    ) {
        this.productGateway = productGateway;
        this.orderDAO = orderDAO;
        this.orderParameterDAO = orderParameterDAO;
        this.salesOrderValidator = salesOrderValidator;
        this.salesOrderItemDueDatePluginValidations = salesOrderItemDueDatePluginValidations;
    }

    private static <T> void back(T object) {

        final Set<Integer> ids = new HashSet<>();

        if (object instanceof Collection) {
            Collection collection = (Collection) object;
            ids.add(collection.hashCode());
            collection.forEach(SalesOrderItemValidator::back);
        } else {
            try {
                Class<?> clazz = object.getClass();
                Field[] fields = clazz.getDeclaredFields();
                for (Field field : fields) {
                    field.setAccessible(true);

                    Object valueField = field.get(object);

                    if ((!(valueField instanceof SoftDeleteBaseEntity)
                            && !(valueField instanceof Collection)
                            && !field.isAnnotationPresent(PojoColumnBackReference.class))) {
                        continue;
                    }

                    ids.add(valueField.hashCode());
                    back(valueField, object, ids);

                }
            } catch (IllegalAccessException | IllegalArgumentException e) {
                LoggerFactory.getLogger(SalesOrderItemValidator.class).error("Back reference", e);
            }
        }
    }

    private static <T, D> void back(T object, final D dad, final Set<Integer> ids) {

        if (object instanceof Collection) {
            Collection collection = (Collection) object;
            collection.forEach(obj -> back(obj, dad, ids));
        } else {
            try {
                Class<?> clazz = object.getClass();
                Field[] fields = clazz.getDeclaredFields();
                for (Field field : fields) {
                    field.setAccessible(true);

                    Object valueField = field.get(object);

                    if ((!(valueField instanceof SoftDeleteBaseEntity)
                            && !(valueField instanceof Collection)
                            && !field.isAnnotationPresent(PojoColumnBackReference.class))) {
                        continue;
                    }

                    if (field.isAnnotationPresent(PojoColumnBackReference.class)) {
                        field.set(object, dad);
                    } else {
                        if ((valueField != null && !ids.contains(valueField.hashCode()))) {
                            ids.add(valueField.hashCode());
                            back(valueField, object, ids);
                        }
                    }

                }
            } catch (IllegalAccessException | IllegalArgumentException e) {
                LoggerFactory.getLogger(SalesOrderItemValidator.class).error("Back reference", e);
            }
        }
    }

    public LogicError validateSalesOrderExists(final SalesOrderItem item, final SalesOrder salesOrder) {
        if (item != null && item.getSalesOrder() != null) {
            return salesOrder != null ? null : new LogicError("order", "order.item.order.notFound");
        }
        return null;
    }

    public LogicError validateProductExists(final SalesOrderItem item, final Product product) {
        return (product == null && item != null && item.getProductId() != null) ? new LogicError(Constants.FIELD_PRODUCT, "order.item.product.notFound") : null;
    }

    public LogicError validateProductActive(final Product product) {
        return (product != null && !product.isActive()) ? new LogicError(Constants.FIELD_PRODUCT, "order.item.product.inactive") : null;
    }

    public LogicError validatePriceListExists(final SalesOrderItem item, final PriceList priceList) {
        if (priceList == null && item != null && item.getPriceListId() != null) {
            return new LogicError(Constants.FIELD_PRICE_LIST, "order.item.priceList.notFound");
        }
        return null;
    }

    public LogicError validatePriceListActive(final PriceList priceList) {
        if (priceList != null && !priceList.isActive()) {
            return new LogicError(Constants.FIELD_PRICE_LIST, "order.item.priceList.inactive");
        }
        return null;
    }

    public LogicError validatePriceListItemExists(final SalesOrderItem item, final PriceListItem priceListItem) {
        return (priceListItem == null && item != null && item.getPriceListItemId() != null) ? new LogicError("priceListItem", "order.item.priceListItem.notFound") : null;
    }

    public LogicError validatePriceListItemBelongsPriceList(final SalesOrderItem item, final PriceListItem priceListItem) {
        if(Objects.nonNull(priceListItem) && Objects.nonNull(item) && Objects.nonNull(item.getPriceListItemId()) && !item.getProductId().toString().equals(priceListItem.getProduct().getId())) {
            return new LogicError("priceListItem", "order.item.priceListItem.mustBelongsToPriceList");
        }
        return null;
    }

    public LogicError validatePriceListItemBelongsToPriceList(final PriceList priceList, final PriceListItem priceListItem) {

        final List<PriceListItem> items = (priceList != null) ? priceList.getItems() : null;

        if (priceList != null && priceListItem != null
                && (items == null || items.stream().filter(item -> item.getId().equals(priceListItem.getId())).count() <= 0)) {
            return new LogicError(Constants.FIELD_PRODUCT, "order.item.priceListItem.mustBelongsToPriceList");
        }

        return null;
    }

    public LogicError validateProductBelongsToPriceListItem(final PriceListItem priceListItem, final Product product) {

        if (priceListItem != null && product != null
                && (priceListItem.getProduct() == null
                || !priceListItem.getProduct().getId().equals(product.getId()))) {
            return new LogicError(Constants.FIELD_PRODUCT, "order.item.product.mustBelongsToPriceListItem");
        }

        return null;
    }

    public LogicError validatePriceListCanBeUsed(final SalesOrderItem salesOrderItem, final SalesOrder salesOrder) {

        if (salesOrderItem != null
                && salesOrder != null
                && salesOrder.getUserProfessionalId() != null
                && salesOrder.getCompanyId() != null
                && salesOrder.getLocationId() != null
                && salesOrderItem.getProductId() != null
                && salesOrder.getPaymentTermId() != null
                && salesOrderItem.getPriceListId() != null) {

            PriceListSearch priceListSearch = new PriceListSearch();
            priceListSearch.setUserId(salesOrder.getUserProfessionalId().toString());
            priceListSearch.setCompanyId(salesOrder.getCompanyId().toString());
            priceListSearch.setLocationId(salesOrder.getLocationId().toString());
            priceListSearch.setProductId(salesOrderItem.getProductId().toString());
            priceListSearch.setPaymentTermId(salesOrder.getPaymentTermId().toString());

            if (!productGateway.priceListCanBeUsed(priceListSearch, salesOrderItem.getPriceListId())) {
                return new LogicError(Constants.FIELD_PRICE_LIST, "order.item.cannotBeUsed");
            }
        }

        return null;
    }

    public LogicError validatePackageExists(final SalesOrderItem item, final ProductPackaging packaging) {
        LogicError error = new LogicError(Constants.FIELD_PRODUCT_PACKAGING, "order.item.productPackaging.notFound");
        if (item != null && packaging == null && item.getProductPackagingId() != null) {
            return error;
        }
        return null;
    }

    public LogicError validatePackagingBelongsToProduct(final SalesOrderItem item, final Product product) {
        if (product != null && item != null && item.getProductPackagingId() != null) {
            final LogicError error = new LogicError(Constants.FIELD_PRODUCT_PACKAGING, "order.item.productPackaging.mustBelongsToProduct");
            final List<ProductPackaging> packagings = product.getPackagings();
            if (packagings == null || packagings.isEmpty()) {
                return error;
            } else {
                final ProductPackaging packaging = packagings
                        .stream()
                        .filter(pack -> item.getProductPackagingId().toString().equals(pack.getId()))
                        .findFirst()
                        .orElse(null);
                return (packaging == null) ? error : null;
            }
        }
        return null;
    }

    public LogicError validateProductUniqueProductInOrder(final SalesOrderItem item, final SalesOrder order, final Product product) {
        if (item != null && order != null && product != null && order.getItems() != null) {
            final Stream<UUID> idProductsOrder = order.getItems()
                    .stream()
                    .map(SalesOrderItem::getProductId)
                    .filter(id -> id.toString().equals(product.getId()));
            return (idProductsOrder.count() > 0) ? new LogicError(Constants.FIELD_PRODUCT, "order.item.product.productMustBeUnique") : null;
        }
        return null;
    }

    public LogicError validateProductPermitFractionalSale(final SalesOrderItem item, final Product product) {
        if (item != null && product != null) {
            if (!product.isSaleFractioned() && item.getQuantity() != null && (item.getQuantity().scale() > 0 || item.getQuantity().stripTrailingZeros().scale() > 0)) {
                return new LogicError("quantity", "order.item.saleFractionated");
            }
        }
        return null;
    }

    public LogicError validateQuantityOfPacking(final SalesOrderItem item, final ProductPackaging packaging) {

        if (packaging != null
                && item != null
                && item.getQuantity() != null
                && packaging.getConversionFactor() != null
                && packaging.getConversionFactor().compareTo(BigDecimal.ZERO) > 0
                && item.getQuantity().compareTo(BigDecimal.ZERO) > 0) {
            final BigDecimal conversionFactor = packaging.getConversionFactor();

            BigDecimal remainder = item.getQuantity().remainder(conversionFactor);
            return (remainder.compareTo(BigDecimal.ZERO) > 0) ? new LogicError("quantity", "order.item.quantity.inconsistentPack") : null;
        }

        return null;
    }

    public LogicError validateOriginalPriceIsEqualsPriceListItem(final SalesOrderItem item, final BigDecimal value) {
        final BigDecimal saleValue = Optional.ofNullable(value).orElse(BigDecimal.ZERO);
        return Optional.ofNullable(item.getPriceListItemId())
                .map(productGateway::getPriceListItem)
                .map(PriceListItem::getSalesPrice)
                .map(price -> price.compareTo(saleValue) != 0)
                .map(isDifferent -> isDifferent ? new LogicError(Constants.FIELD_ORIGINAL_PRICE, Constants.MESSAGE_ORIGINAL_PRICE_INCONSISTENT) : null)
                .orElse(null);
    }

    public LogicError validateDiscountValue(final SalesOrderItem item) {

        final BigDecimal itemOriginalPrice = item.getOriginalPrice();
        final BigDecimal itemSalesPrice = item.getSalesPrice();
        final BigDecimal itemDiscountValue = item.getDiscountValue();

        if (itemOriginalPrice != null
                && itemSalesPrice != null
                && itemDiscountValue != null
                && itemOriginalPrice.compareTo(BigDecimal.ZERO) > 0
                && itemSalesPrice.compareTo(BigDecimal.ZERO) >= 0
                && item.getDueDateValue() == null
                && item.getIncreaseValue() == null) {

            final BigDecimal discountValue = itemOriginalPrice.subtract(itemSalesPrice);

            if (discountValue.compareTo(itemDiscountValue) != 0) {
                final Map<String, Object> params = new HashMap<>();
                if (discountValue.compareTo(BigDecimal.ZERO) >= 0) {
                    params.put(Constants.FIELD_VALUE, discountValue);
                } else {
                    params.put(Constants.FIELD_VALUE, 0);
                }
                return new LogicError(Constants.FIELD_DISCOUNT_VALUE, "order.item.discountValue.inconsistent", null, params);
            }
        }
        return null;
    }

    /**
     * Validate if the increased value is valid
     *
     * @param item to be validate
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-30
     */
    public LogicError doValidateIncreaseValue(final SalesOrderItem item) {
        final BigDecimal itemOriginalPrice = item.getOriginalPrice();
        final BigDecimal itemSalesPrice = item.getSalesPrice();

        if (itemOriginalPrice != null
                && itemSalesPrice != null
                && item.getIncreaseValue() != null
                && itemOriginalPrice.compareTo(BigDecimal.ZERO) > 0
                && itemSalesPrice.compareTo(BigDecimal.ZERO) >= 0
                && item.getDueDateValue() == null
                && item.getDiscountValue() == null) {

            final BigDecimal itemIncreaseValue = item.getIncreaseValue() == null ? BigDecimal.ZERO : item.getIncreaseValue();
            BigDecimal increaseValue = itemSalesPrice.subtract(itemOriginalPrice);

            if (increaseValue.compareTo(itemIncreaseValue) != 0 && increaseValue.compareTo(BigDecimal.ZERO) >= 0) {
                if (increaseValue.compareTo(BigDecimal.ZERO) < 0) {
                    increaseValue = BigDecimal.ZERO;
                }
                final Map<String, Object> params = new HashMap<>();
                params.put(Constants.FIELD_VALUE, increaseValue);
                return new LogicError(Constants.FIELD_INCREASE_VALUE, Constants.MESSAGE_INCREASE_VALUE, null, params);
            }
        }
        return null;
    }


    public LogicError validateDiscountPercentage(final SalesOrderItem item) {
        if (item == null) {
            return null;
        }
        final BigDecimal itemOriginalPrice = item.getOriginalPrice();
        final BigDecimal itemSalesPrice = item.getSalesPrice();
        final BigDecimal itemDiscountPercentage = item.getDiscountPercentage();
        final BigDecimal itemDueDateValue = item.getDueDateValue() == null ? BigDecimal.ZERO : item.getDueDateValue();
        if (itemOriginalPrice != null
                && itemSalesPrice != null
                && itemDiscountPercentage != null
                && item.getOriginalPrice().compareTo(BigDecimal.ZERO) > 0
                && item.getSalesPrice().compareTo(BigDecimal.ZERO) >= 0
                && item.getIncreaseValue() == null
                && item.getDueDateValue() == null) {

            final BigDecimal discountValue = itemOriginalPrice.subtract(itemSalesPrice);
            final BigDecimal discountPercentage;
            discountPercentage = (itemOriginalPrice.compareTo(itemSalesPrice.add(itemDueDateValue)) > 0)
                    ? discountValue.multiply(BIG_DECIMAL_ONE_HUNDRED).divide(itemOriginalPrice, SCALE, RoundingMode.HALF_EVEN) : BigDecimal.ZERO;
            final Map<String, Object> params = new HashMap<>();
            params.put(Constants.FIELD_VALUE, discountPercentage.toString());
            if (discountPercentage.compareTo(itemDiscountPercentage) != 0) {
                final BigDecimal salesPrice = itemOriginalPrice.multiply(itemDiscountPercentage).divide(BIG_DECIMAL_ONE_HUNDRED, SCALE, RoundingMode.HALF_EVEN);
                if (salesPrice.compareTo(discountValue) != 0) {
                    return new LogicError("discountPercentage", "order.item.discountPercentage.inconsistent", null, params);
                }
            }
        }
        return null;
    }

    /**
     * Validate if the increased percentage is valid
     *
     * @param item to be validate
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-30
     */
    public LogicError validateIncreasePercentage(final SalesOrderItem item) {
        if (item == null) {
            return null;
        }

        final BigDecimal itemOriginalPrice = item.getOriginalPrice();
        final BigDecimal itemSalesPrice = item.getSalesPrice();
        final BigDecimal itemIncreasePercentage = item.getIncreasePercentage();
        final BigDecimal itemDueDateValue = item.getDueDateValue() == null ? BigDecimal.ZERO : item.getDueDateValue();

        if (itemOriginalPrice != null
                && itemSalesPrice != null
                && itemIncreasePercentage != null
                && item.getOriginalPrice().compareTo(BigDecimal.ZERO) > 0
                && item.getSalesPrice().compareTo(BigDecimal.ZERO) >= 0
                && (item.getDiscountValue() == null || item.getDiscountValue().compareTo(BigDecimal.ZERO) == 0)) {

            final BigDecimal increaseValue = itemSalesPrice.subtract(itemOriginalPrice);
            final BigDecimal increasePercentage;

            increasePercentage = (itemSalesPrice.compareTo(itemOriginalPrice.add(itemDueDateValue)) > 0)
                    ? increaseValue.multiply(BIG_DECIMAL_ONE_HUNDRED).divide(itemOriginalPrice, SCALE, RoundingMode.HALF_EVEN) : BigDecimal.ZERO;

            final Map<String, Object> params = new HashMap<>();
            params.put(Constants.FIELD_VALUE, increasePercentage.toString());

            if (increasePercentage.compareTo(itemIncreasePercentage) != 0) {
                final BigDecimal salesPrice = itemOriginalPrice.multiply(itemIncreasePercentage).divide(BIG_DECIMAL_ONE_HUNDRED, SCALE, RoundingMode.HALF_EVEN);
                if (salesPrice.compareTo(increaseValue) != 0) {
                    return new LogicError(Constants.FIELD_INCREASE_PERCENTAGE, Constants.MESSAGE_INCREASE_PERCENTAGE, null, params);
                }
            }
        }
        return null;
    }

    public LogicError validateMinimumPrice(final SalesOrderItem item) {
        if (item == null) {
            return null;
        }
        final Boolean isMinimumValueValidated = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_VALIDATE_MINIMUM_PRICE).getValue());
        final PriceListItem priceListItem;
        priceListItem = productGateway.getPriceListItem(item.getPriceListItemId());
        if (isMinimumValueValidated
                && priceListItem != null
                && priceListItem.getMinimumPrice() != null
                && item.getSalesPrice() != null
                && item.getSalesPrice().compareTo(priceListItem.getMinimumPrice()) < 0) {
            final Map<String, Object> params = new HashMap<>();
            params.put("minimumPrice", priceListItem.getMinimumPrice());
            return new LogicError("salesPrice", "order.item.minimumPrice", null, params);
        }
        return null;
    }

    public LogicError validateInformedDiscountAndFixedPrice(final SalesOrderItem item) {
        if (hasValue(item.getDiscountPercentage()) || hasValue(item.getDiscountValue())) {
            final PriceListItem priceListItem = productGateway.getPriceListItem(item.getPriceListItemId());

            if (priceListItem != null && priceListItem.isFixedPrice() != null && priceListItem.isFixedPrice()) {
                final Map<String, Object> params = new HashMap<>();
                params.put("productDescription", item.getProductDescription());

                return new LogicError("salesPrice", "order.item.discountAndFixedPrice", null, params);
            }
        }
        return null;
    }

    public LogicError validateDiscount(final SalesOrderItem item) {
        if (runDiscountValidation(item)) {
            final List<DiscountDTO> discounts = productGateway.searchDiscounts(getSearchDiscount(item));

            if (!discounts.isEmpty()) {
                final DiscountDTO discount = discounts.get(0);

                final LogicError discountPercentageInvalid =
                        validateDiscountPercentageGreaterThanTheMaximumAllowed(item.getDiscountPercentage(), discount.getMaximumDiscountPercentage());

                return discountPercentageInvalid != null ? discountPercentageInvalid :
                        validateDiscountValueGreaterThanTheMaximumAllowed(item.getDiscountValue(), discount.getMaximumDiscountValue());
            }
        }
        return null;
    }

    private LogicError validateDiscountPercentageGreaterThanTheMaximumAllowed(final BigDecimal discountPercentage, final BigDecimal maximumDiscountPercentage) {
        if (hasValueGreaterThanTheZero(maximumDiscountPercentage) && discountPercentage.compareTo(maximumDiscountPercentage) > 0) {

            final Map<String, Object> params = new HashMap<>();
            params.put("maximumDiscountPercentage", maximumDiscountPercentage);

            return new LogicError("discountPercentage", "order.item.discountPercentageInvalid", null, params);
        }
        return null;
    }

    private LogicError validateDiscountValueGreaterThanTheMaximumAllowed(final BigDecimal discountValue, final BigDecimal maximumDiscountValue) {
        if (hasValueGreaterThanTheZero(maximumDiscountValue) && discountValue.compareTo(maximumDiscountValue) > 0) {

            final Map<String, Object> params = new HashMap<>();
            params.put("maximumDiscountValue", maximumDiscountValue);

            return new LogicError("discountValue", "order.item.discountValueInvalid", null, params);
        }
        return null;
    }

    @Override
    protected void validate(final SalesOrderItem item, final IValidationFilter... filter) {

        final SalesOrder order = getSalesOrder(item);
        final PriceList priceList = getPriceList(item);
        final PriceListItem priceListItem = getPriceListItem(item);
        final Product product = getProduct(item);
        final ProductPackaging packaging = getProductPackaging(item, product);

        back(item);

        if (ArrayUtils.contains(filter, EValidationType.DELETE)) {
            addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(order, Boolean.FALSE), item);
        }

        if (ArrayUtils.contains(filter, EValidationType.INSERT)) {
            validateByBeanValidation(item, null);

            addError(this.validateSalesOrderExists(item, order), item);

            if (order != null) {
                addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(order, Boolean.FALSE), item);

                addError(this.validateProductExists(item, product), item);
                addError(this.validateProductActive(product), item);
                addError(this.validateProductUniqueProductInOrder(item, order, product), item);
                addError(this.validateProductPermitFractionalSale(item, product), item);

                addError(this.validatePackageExists(item, packaging), item);
                addError(this.validatePackagingBelongsToProduct(item, product), item);

                addError(this.validatePriceListExists(item, priceList), item);
                addError(this.validatePriceListActive(priceList), item);
                addError(this.validatePriceListCanBeUsed(item, order), item);

                addError(this.validatePriceListItemExists(item, priceListItem), item);
                addError(this.validatePriceListItemBelongsPriceList(item, priceListItem), item);
                addError(this.validateProductBelongsToPriceListItem(priceListItem, product), item);
                addError(this.validatePriceListItemBelongsToPriceList(priceList, priceListItem), item);

                addError(this.validateQuantityOfPacking(item, packaging), item);
                addError(this.validateOriginalPriceIsEqualsPriceListItem(item, item.getOriginalPrice()), item);

                item.setSalesOrder(order);
                validatePricesAndDiscount(item);
            }
        }

        if (ArrayUtils.contains(filter, EValidationType.UPDATE)) {
            validateByBeanValidation(item, null);

            addError(this.validateSalesOrderExists(item, order), item);

            if (order != null) {
                addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(order, Boolean.FALSE), item);

                addError(this.validateProductExists(item, product), item);
                addError(this.validateProductActive(product), item);
                addError(this.validateProductPermitFractionalSale(item, product), item);

                addError(this.validatePackageExists(item, packaging), item);
                addError(this.validatePackagingBelongsToProduct(item, product), item);

                addError(this.validatePriceListExists(item, priceList), item);
                addError(this.validatePriceListActive(priceList), item);
                addError(this.validatePriceListCanBeUsed(item, order), item);

                addError(this.validatePriceListItemExists(item, priceListItem), item);
                addError(this.validateProductBelongsToPriceListItem(priceListItem, product), item);
                addError(this.validatePriceListItemBelongsToPriceList(priceList, priceListItem), item);

                addError(this.validateQuantityOfPacking(item, packaging), item);
                addError(this.validateOriginalPriceIsEqualsPriceListItem(item, item.getOriginalPrice()), item);

                item.setSalesOrder(order);
                validatePricesAndDiscount(item);
            }
        }
    }

    private void validatePricesAndDiscount(final SalesOrderItem item) {
        final List<LogicError> errorsFromPrices = new LinkedList<>();
            addError(this.doValidateDiscountAndIncrease(item), item);
            addError(this.validateDiscountValue(item), item);
            addError(this.validateDiscountPercentage(item), item);
            addError(this.doValidateIncreaseValue(item), item);
            addError(this.validateIncreasePercentage(item), item);
            addError(this.salesOrderItemDueDatePluginValidations.doValidateDueDate(item), item);

            GenericValidator.applyValidator(this::validateMinimumPrice, item, errorsFromPrices);
            GenericValidator.applyValidator(this::validateInformedDiscountAndFixedPrice, item, errorsFromPrices);
            GenericValidator.applyValidator(this::validateDiscount, item, errorsFromPrices);

            errorsFromPrices.forEach(error -> addError(error, item));
    }

    private Boolean runDiscountValidation(final SalesOrderItem item) {
        final Boolean isDiscountEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_VALIDATE_DISCOUNT).getValue());
        return hasValue(item.getDiscountPercentage())
                && hasValue(item.getDiscountValue())
                && isDiscountEnabled
                && discountLimitTypeNotFree(item);
    }

    private Boolean discountLimitTypeNotFree(final SalesOrderItem item) {
        final Product product = productGateway.getProduct(item.getProductId());
        return product != null && product.getDiscountLimitType() != null && !"FREE".equals(product.getDiscountLimitType().toUpperCase());
    }

    private DiscountSearch getSearchDiscount(final SalesOrderItem item) {
        final DiscountSearch search = new DiscountSearch();

        final SalesOrder salesOrder = getSalesOrder(item);

        if (salesOrder != null && salesOrder.getCreatedAt() != null) {
            search.setBetweenDate(salesOrder.getCreatedAt().toLocalDate().toString());
        }

        final Product product = productGateway.getProduct(item.getProductId());
        final SalesOrder order = getSalesOrder(item);

        if (product != null && product.getDiscountLimitType() != null) {
            switch (product.getDiscountLimitType()) {
                case "COMP":
                    if (order != null && order.getCompanyId() != null) {
                        search.setCompanyId(order.getCompanyId().toString());
                    }
                    break;

                case "USER":
                    if (order != null && order.getUserProfessionalId() != null) {
                        search.setUserId(order.getUserProfessionalId().toString());
                    }
                    break;

                case "CUST":
                    if (order != null && order.getCustomerId() != null) {
                        search.setCustomerId(order.getCustomerId().toString());
                    }
                    break;

                case "LCTN":
                    if (order != null && order.getLocationId() != null) {
                        search.setLocationId(order.getLocationId().toString());
                    }
                    break;

                case "PRGR":
                    if (product.getProductGroup() != null) {
                        search.setProductGroupId(product.getProductGroup().getId());
                    }
                    break;

                case "PRCL":
                    if (item.getPriceListId() != null) {
                        search.setPriceListId(item.getPriceListId().toString());
                    }
                    break;

                case "PRLI":
                    if (item.getPriceListItemId() != null) {
                        search.setPriceListItemId(item.getPriceListItemId().toString());
                    }
                    break;

                case "PROD":
                    if (item.getProductId() != null) {
                        search.setProductId(item.getProductId().toString());
                    }
                    break;
            }
        }

        return search;
    }

    private Boolean hasValueGreaterThanTheZero(final BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) > 0;
    }

    private Boolean hasValue(final BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) != 0;
    }

    private SalesOrder getSalesOrder(final SalesOrderItem item) {
        if (item.getSalesOrder() != null && item.getSalesOrder().getId() != null) {
            try {
                return orderDAO.findById(item.getSalesOrder().getId());
            } catch (RegisterNotFoundException e) {
                logger.info("Resource order not found!", e);
            }
        }
        return null;
    }

    private PriceList getPriceList(final SalesOrderItem item) {
        if (item.getPriceListId() != null) {
            return productGateway.getPriceList(item.getPriceListId());
        }
        return null;
    }

    private PriceListItem getPriceListItem(final SalesOrderItem item) {
        if (item.getPriceListItemId() != null) {
            return productGateway.getPriceListItem(item.getPriceListItemId());
        }
        return null;
    }

    private Product getProduct(final SalesOrderItem item) {
        if (item.getProductId() != null) {
            return productGateway.getProduct(item.getProductId());
        }
        return null;
    }

    private ProductPackaging getProductPackaging(final SalesOrderItem item, Product product) {
        final List<ProductPackaging> packagings = (product != null) ? product.getPackagings() : null;
        if (packagings != null && item.getProductPackagingId() != null && !packagings.isEmpty()) {
            return packagings
                    .stream()
                    .filter(pack -> item.getProductPackagingId().toString().equals(pack.getId()))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }

    /**
     * Check if the there discount, due date and increase fields
     *
     * @param salesOrderItem to validate and add error
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-30
     */
    public LogicError doValidateDiscountAndIncrease(final SalesOrderItem salesOrderItem) {

        final Boolean hasDiscount = validateValue(salesOrderItem.getDiscountValue())
                || validateValue(salesOrderItem.getDiscountPercentage());

        final Boolean hasIncrease =  validateValue(salesOrderItem.getIncreaseValue())
                ||  validateValue(salesOrderItem.getIncreasePercentage());

        final Boolean hasDueDate = salesOrderItem.getDueDateValue() != null;

        final Boolean isDueDateEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_PRICE).getValue());
        if (isDueDateEnabled && (hasDueDate && (hasDiscount || hasIncrease))) {
            return new LogicError(Constants.FIELD_SALES_ORDER_ITEM, Constants.MESSAGE_DISCOUNT_DUE_DATE_INCREASE);
        }

        if (hasDiscount && hasIncrease) {
            return new LogicError(Constants.FIELD_SALES_ORDER_ITEM, Constants.MESSAGE_DISCOUNT_INCREASE);
        }

        return null;
    }

    /**
     * verifies that the value entered is greater than zero and non null
     *
     * @since 8.6.0 2019-07-01
     * @author Peterson Schmitt
     *
     * @param value to validated
     */
    public boolean validateValue(final BigDecimal value){
        return value != null && value.compareTo(new BigDecimal(0)) > 0;
    }

    /**
     * Adds the validation if the error is not null.
     *
     * @since 8.5.0 2019-06-19
     * @author Ricardo Corrent
     *
     * @param logicError with the error parameters
     * @param entity     that was validated
     */
    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        if (logicError != null) {
            super.addError(logicError, entity);
        }
    }

}
