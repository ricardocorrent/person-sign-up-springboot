package com.ws.sales.paymenttermcompanypermission;

import java.util.UUID;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.administration.dto.CompanyDTO;
import com.ws.sales.paymentterm.PaymentTermDTO;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermCompanyPermissionDTO implements IPojoConverter {

    private UUID id;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "company.id", target = "companyId"),
            @PojoColumnMapper(source = "company.name", target = "companyName")
    })
    private CompanyDTO company;

    private PaymentTermDTO paymentTerm;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public CompanyDTO getCompany() {
        return company;
    }

    public void setCompany(final CompanyDTO company) {
        this.company = company;
    }

    public PaymentTermDTO getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(final PaymentTermDTO paymentTerm) {
        this.paymentTerm = paymentTerm;
    }
}
