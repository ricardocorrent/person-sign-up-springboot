package com.ws.sales.paymentterm;

import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.servlet.http.HttpServletRequest;

import com.ws.commons.server.pagination.PagedList;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.interceptor.sourceannotation.ConversionProduces;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermission;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermissionDTO;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermissionService;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermissionDTO;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermissionService;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermissionDTO;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermissionService;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermission;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermissionDTO;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermissionService;
import com.ws.sales.util.Constants;
import com.ws.sales.util.SalesAbstractResource;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Path("/payment-terms")
public class PaymentTermResource extends SalesAbstractResource<PaymentTerm, PaymentTermSearch> {

    private final PaymentTermCompanyPermissionService paymentTermCompanyPermissionService;
    private final PaymentTermCustomerPermissionService paymentTermCustomerPermissionService;
    private final PaymentTermLocationPermissionService paymentTermLocationPermissionService;
    private final PaymentTermUserPermissionService paymentTermUserPermissionService;

    @Inject
    public PaymentTermResource(final PaymentTermService service,
                               final PaymentTermCompanyPermissionService paymentTermCompanyPermissionService,
                               final PaymentTermCustomerPermissionService paymentTermCustomerPermissionService,
                               final PaymentTermLocationPermissionService paymentTermLocationPermissionService,
                               final PaymentTermUserPermissionService paymentTermUserPermissionService) {
        this.service = service;
        this.paymentTermCompanyPermissionService = paymentTermCompanyPermissionService;
        this.paymentTermCustomerPermissionService = paymentTermCustomerPermissionService;
        this.paymentTermLocationPermissionService = paymentTermLocationPermissionService;
        this.paymentTermUserPermissionService = paymentTermUserPermissionService;
    }

    /**
     * @param parameters as {@link PaymentTermSearch}
     * @return {@link Response}
     * @see Response
     * @see PaymentTermSearch
     */
    @Override
    public Response search(final PaymentTermSearch parameters) {
        return Response.ok().entity(((PaymentTermService)this.service).search(parameters)).build();
    }

    /**
     * Method deprecated, use {@link #searchPaymentTermsPriceList(PaymentTermSearchWithPriceList)}
     *
     * @param search
     * @return
     */
    @POST
    @Path("/search-siagri")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Deprecated
    @RequiresPermissions(value = Constants.RULE_PAYMENT_TERM_READ)
    public Response searchPaymentTermsSiagri(final PaymentTermSearchWithPriceList search) {
        return Response.ok().entity(((PaymentTermService)this.service).search(search)).build();
    }

    @POST
    @Path("/search-with-price-list")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(value = Constants.RULE_PAYMENT_TERM_READ)
    public Response searchPaymentTermsPriceList(final PaymentTermSearchWithPriceList search) {
        return Response.ok().entity(((PaymentTermService)this.service).search(search)).build();
    }

    @POST
    @Path("{paymentTermId}/company-permissions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(PaymentTermCompanyPermissionDTO[].class)
    public Response insertCompanyPermission(@Consumer final List<PaymentTermCompanyPermission> paymentTermCompanyPermissionList,
                                            @PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        final UUID id = UUID.fromString(paymentTermId);
        this.doFillPaymentTemInTheList(paymentTermCompanyPermissionList, id);
        paymentTermCompanyPermissionService.insertList(paymentTermCompanyPermissionList, id);
        return Response.status(HttpStatus.SC_CREATED).build();
    }

    @GET
    @Path("{paymentTermId}/company-permissions")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(PaymentTermCompanyPermissionDTO.class)
    public Response listCompanyPermission(@PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        return Response.ok().entity(paymentTermCompanyPermissionService.getByPaymentTerm(UUID.fromString(paymentTermId))).build();
    }

    @POST
    @Path("{paymentTermId}/company-permissions/batch-delete")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response batchDeleteCompanyPermission(final Set<String> paymentTermCompanyIds) {
        final Set<UUID> ids = paymentTermCompanyIds.stream().map(UUID::fromString).collect(Collectors.toSet());
        paymentTermCompanyPermissionService.batchDelete(ids);
        return Response.ok().build();
    }

    @POST
    @Path("{paymentTermId}/customer-permissions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(PaymentTermCustomerPermissionDTO[].class)
    public Response insertCustomerPermissions(@Consumer final List<PaymentTermCustomerPermission> priceListCustomerPermissions,
                                              @PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        final UUID id = UUID.fromString(paymentTermId);
        this.doFillPaymentTemInTheList(priceListCustomerPermissions, id);
        paymentTermCustomerPermissionService.insertList(priceListCustomerPermissions, id);
        return Response.status(HttpStatus.SC_CREATED).build();
    }

    @GET
    @Path("{paymentTermId}/customer-permissions")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(PaymentTermCustomerPermissionDTO.class)
    public Response listCustomerPermissions(@PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        return Response.ok().entity(paymentTermCustomerPermissionService.getByPaymentTerm(UUID.fromString(paymentTermId))).build();
    }

    @POST
    @Path("{paymentTermId}/customer-permissions/batch-delete")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response batchDeleteCustomerPermissions(final Set<String> paymentTermCustomerIds) {
        final Set<UUID> ids = paymentTermCustomerIds.stream().map(UUID::fromString).collect(Collectors.toSet());
        paymentTermCustomerPermissionService.batchDelete(ids);
        return Response.ok().build();
    }

    @POST
    @Path("{paymentTermId}/location-permissions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(PaymentTermLocationPermissionDTO[].class)
    public Response insertLocationPermission(@Consumer final List<PaymentTermLocationPermission> paymentTermLocationPermissions,
                                             @PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        final UUID id = UUID.fromString(paymentTermId);
        this.doFillPaymentTemInTheList(paymentTermLocationPermissions, id);
        paymentTermLocationPermissionService.insertList(paymentTermLocationPermissions, id);
        return Response.status(HttpStatus.SC_CREATED).build();
    }

    @GET
    @Path("{paymentTermId}/location-permissions")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(PaymentTermLocationPermissionDTO.class)
    public Response listLocationPermission(@PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        return Response.ok().entity(paymentTermLocationPermissionService.getByPaymentTerm(UUID.fromString(paymentTermId))).build();
    }

    @POST
    @Path("{paymentTermId}/location-permissions/batch-delete")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response batchDeleteLocationPermission(final Set<String> paymentTermLocationIds) {
        final Set<UUID> ids = paymentTermLocationIds.stream().map(UUID::fromString).collect(Collectors.toSet());
        paymentTermLocationPermissionService.batchDelete(ids);
        return Response.ok().build();
    }

    @POST
    @Path("{paymentTermId}/user-permissions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(PaymentTermUserPermissionDTO[].class)
    public Response insertUserPermission(@Consumer final List<PaymentTermUserPermission> paymentTermUserPermissions,
                                         @PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId) {
        final UUID id = UUID.fromString(paymentTermId);
        this.doFillPaymentTemInTheList(paymentTermUserPermissions, id);
        paymentTermUserPermissionService.insertList(paymentTermUserPermissions, id);
        return Response.status(HttpStatus.SC_CREATED).build();
    }

    @GET
    @Path("{paymentTermId}/user-permissions")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(PaymentTermUserPermissionDTO.class)
    public Response listUserPermission(@PathParam(Constants.FIELD_PAYMENT_TERM_ID) final String paymentTermId, @Context HttpServletRequest httpRequest) {
        final Map<String, String[]> queryParams = httpRequest.getParameterMap();
        PagedList<PaymentTermUserPermission> list = new PagedList<>();

        if(Objects.nonNull(queryParams)){
            list = paymentTermUserPermissionService.getByPaymentTerm(UUID.fromString(paymentTermId), httpRequest);
        }

        return Response.ok().entity(list).build();
    }

    @POST
    @Path("{paymentTermId}/user-permissions/batch-delete")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response batchDeleteUserPermission(final Set<String> paymentTermUserIds) {
        final Set<UUID> ids = paymentTermUserIds.stream().map(UUID::fromString).collect(Collectors.toSet());
        paymentTermUserPermissionService.batchDelete(ids);
        return Response.ok().build();
    }

    /**
     * <p>
     * Streams the list of permissions and insert a new {@link PaymentTerm} to it,
     * to set the link between the entities
     * <p>
     * This method must be used to handle permissions from PaymentTerm
     *
     * @param objects to stream the list and update the {@link PaymentTerm}
     * @param paymentTermId to set the {@link PaymentTerm}
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-05
     */
    private <T> void doFillPaymentTemInTheList(final Collection<T> objects, final UUID paymentTermId) {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setId(paymentTermId);
        objects.forEach(permission -> {
            final Field fieldPaymentTerm = FieldReflectionHelper.fromInstance(permission).getField(Constants.FIELD_PAYMENT_TERM);
            FieldReflectionHelper.fromInstance(permission).setFieldValue(fieldPaymentTerm, paymentTerm);
        });
    }

    @Override
    public Response delete(final UUID id) throws Exception {
        return Response.status(HttpStatus.SC_METHOD_NOT_ALLOWED).build();
    }
}
