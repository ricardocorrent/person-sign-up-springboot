package com.ws.sales.recordpermission.schedulerservice;

import com.ws.sales.external.cloudmanager.CloudManagerGateway;
import com.ws.sales.external.cloudmanager.CustomerCloudManager;
import feign.RetryableException;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.List;

/**
 * Run scheduled tasks to replicate data from other services
 *
 * @author Gustavo P. Bilert
 * @since 2017-05-31
 */
@ApplicationScoped
public class SchedulerService {

    private final Logger logger = LoggerFactory.getLogger(SchedulerService.class);

    private static final String SERVICE_INTEGRATION_ENABLE = "service.integration.enable";

    private final String serviceIntegrationEnable;

    private final AccessGroupReplicator accessGroupReplicator;

    private final SchedulerServiceSessionController scheduleServiceSessionController;

    private final CloudManagerGateway cloudManagerGateway;

    /**
     * Constructor with dependency injection
     *
     * @param accessGroupReplicator The class responsible for the replication for each tenant
     * @param scheduleServiceSessionController Utility to authenticate and create a session for the request
     * @param cloudManagerGateway Gateway for CustomerCloudManager
     */
    @Inject
    public SchedulerService(@ConfigProperty(name = SERVICE_INTEGRATION_ENABLE, defaultValue = "true") final String serviceIntegrationEnable,
                            final AccessGroupReplicator accessGroupReplicator,
                            final SchedulerServiceSessionController scheduleServiceSessionController,
                            final CloudManagerGateway cloudManagerGateway) {
        this.serviceIntegrationEnable = serviceIntegrationEnable;
        this.accessGroupReplicator = accessGroupReplicator;
        this.scheduleServiceSessionController = scheduleServiceSessionController;
        this.cloudManagerGateway = cloudManagerGateway;
    }

    /**
     * Run the replication process for all configured tenants
     */
    public void run() {
        Thread.setDefaultUncaughtExceptionHandler((thread, exception) -> {
            logger.error(String.format("SchedulerService: Error in Thread %s", thread));
            logger.error(exception.getMessage(), exception);
        });

        Thread.currentThread().setName("SchedulerService Pool thread");
        final Boolean isEnabled = Boolean.valueOf(serviceIntegrationEnable);

        if (isEnabled) {

            final List<CustomerCloudManager> cloudManagerTenants = cloudManagerGateway.searchCustomers();

            cloudManagerTenants.stream().map(CustomerCloudManager::getTenant).forEach(tenant -> {
                try {
                    scheduleServiceSessionController.createSession(tenant);

                    accessGroupReplicator.replicateForTenant(tenant);
                } catch (PersistenceException | RetryableException e) {
                    logger.info(String.format("Error getting resource for tenant %s", tenant));
                    logger.debug(String.format("Error getting resource for tenant %s", tenant), e);
                } catch (final Exception e) {
                    // Catch throwable because if one tenant causes an OutOfMemoryError
                    // it would prevent the other tenants from replicating,
                    // while if we catch it, the system can garbage collect its objects
                    // and be able to handle the next tenants
                    logger.error(String.format("SchedulerService: Error replicating for tenant %s", tenant));
                    logger.error(e.getMessage(), e);
                }
            });
        }
    }
}
