package com.ws.sales.ordertreatment;

import com.ws.commons.server.pagination.PaginationSearch;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderTreatmentSearch extends PaginationSearch {

    private String description;

    /**
     * Get of property {@link #description}
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set of property {@link #description}
     *
     * @param description field to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }
}
