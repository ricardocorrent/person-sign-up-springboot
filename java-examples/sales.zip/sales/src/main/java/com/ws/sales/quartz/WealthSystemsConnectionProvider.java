package com.ws.sales.quartz;

import com.ws.commons.PersistenceProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

import javax.enterprise.context.ApplicationScoped;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.quartz.utils.ConnectionProvider;
import org.slf4j.LoggerFactory;

/**
 * Implementation to handle the connection for the quartz cluster.
 * This class will create a new {@link HikariDataSource} and limit
 * it to max 2 connections.
 *
 * Original author Maykon Rissi
 *
 * @author william.santos
 * @since V4.0.3 2019-06-14
 */
@ApplicationScoped
public class WealthSystemsConnectionProvider implements ConnectionProvider {

    private HikariDataSource dataSource;

    /**
     * Initialize the DataSource and set it as a application scoped variable,
     * so every time the quartz needs a connection it will create a new one by
     * using the same DataSource.
     */
    public WealthSystemsConnectionProvider() {
        initDataSource();
    }

    /**
     * @see ConnectionProvider#getConnection()
     */
    @Override
    public Connection getConnection() throws SQLException {
        LoggerFactory.getLogger(WealthSystemsConnectionProvider.class).debug("Creating a new Connection for quartz.");
        return this.dataSource.getConnection();
    }

    /**
     * @see ConnectionProvider#shutdown()
     */
    @Override
    public void shutdown() {
        this.dataSource.close();
    }

    /**
     * @see ConnectionProvider#initialize()
     */
    @Override
    public void initialize() {
        // do nothing, already initialized during constructor call
    }

    private void initDataSource() {
        final String dbUrl = ConfigResolver.getProjectStageAwarePropertyValue(PersistenceProperties.DB_URL, "jdbc:postgresql://postgres:5432/sales");
        final String dbUserName = ConfigResolver.getProjectStageAwarePropertyValue(PersistenceProperties.DB_USERNAME, "runner");
        final String dbPassword = ConfigResolver.getProjectStageAwarePropertyValue(PersistenceProperties.DB_PASSWORD, "123");
        // Creates a new Hikari DataSource
        final HikariConfig config = new HikariConfig();
        config.setJdbcUrl(dbUrl);
        config.setPoolName("wsquartz");
        config.setUsername(dbUserName);
        config.setPassword(dbPassword);
        // Sets only a small number of connections
        config.setMaximumPoolSize(2);
        config.setMinimumIdle(1);
        config.setConnectionInitSql("set schema 'wsquartz';");
        // Sets the DataSource for the quartz
        this.dataSource = new HikariDataSource(config);
    }
}
