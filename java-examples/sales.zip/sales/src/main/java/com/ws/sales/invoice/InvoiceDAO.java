package com.ws.sales.invoice;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * This class represents the persistence layer of Invoice, with she it's possible make methods to
 * interact with the database.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
public class InvoiceDAO extends AbstractDAO<Invoice> {

    /**
     * This method override the getEntityClass for Invoice.
     *
     * @return invoice.
     */
    @Override
    public Class getEntityClass() {
        return Invoice.class;
    }

    /**
     * Method to search a list of Invoice by filter.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @return the paged list of invoice
     */
    public PagedList<Invoice> search(final InvoiceSearch invoiceSearch) {

        final Query<Invoice> query = find();
        ExpressionList<Invoice> where = query.where();

        addIdCondition(invoiceSearch, where);

        addNumberCondition(invoiceSearch, where);

        addSeriesCondition(invoiceSearch, where);

        addInitialBillingDateCondition(invoiceSearch, where);

        addFinalBillingDateCondition(invoiceSearch, where);

        addCurrencyIdCondition(invoiceSearch, where);

        addCustomerIdCondition(invoiceSearch, where);

        addLocationIdCondition(invoiceSearch, where);

        addUserRepIdCondition(invoiceSearch, where);

        addPaymentTermIdCondition(invoiceSearch, where);

        addInvoiceSituationIdCondition(invoiceSearch, where);

        addInvoiceSituationDescriptionCondition(invoiceSearch, where);

        addInvoiceTypeIdCondition(invoiceSearch, where);

        addExternalIdCondition(invoiceSearch, where);

        return getPagedList(query, invoiceSearch);
    }

    /**
     * This method add the id condition for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getId() != null) {
            where.eq("id", invoiceSearch.getId());
        }
    }

    /**
     * This method add the number for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addNumberCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (!StringUtils.isEmpty(invoiceSearch.getNumber())) {
            where.icontains("number", invoiceSearch.getNumber());
        }
    }

    /**
     * This method add the series for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addSeriesCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (!StringUtils.isEmpty(invoiceSearch.getSeries())) {
            where.icontains("series", invoiceSearch.getSeries());
        }
    }

    /**
     * This method add the initial billing date for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addInitialBillingDateCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getInitialBillingDate() != null) {
            where.ge("billingDate", invoiceSearch.getInitialBillingDate());
        }
    }

    /**
     * This method add the final billing date for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addFinalBillingDateCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getFinalBillingDate() != null) {
            where.le("billingDate", invoiceSearch.getFinalBillingDate());
        }
    }

    /**
     * This method add the currency id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addCurrencyIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getCurrencyReplicatedId() != null) {
            where.eq("invoiceCurrency.replicatedId", invoiceSearch.getCurrencyReplicatedId());
        }
    }

    /**
     * This method add the customer id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addCustomerIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getCustomerReplicatedId() != null) {
            where.eq("invoiceCustomer.replicatedId", invoiceSearch.getCustomerReplicatedId());
        }
    }

    /**
     * This method add the location id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addLocationIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getLocationReplicatedId() != null) {
            where.eq("invoiceLocation.replicatedId", invoiceSearch.getLocationReplicatedId());
        }
    }

    /**
     * This method add the user rep id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addUserRepIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getUserReplicatedId() != null) {
            where.eq("invoiceUser.replicatedId", invoiceSearch.getUserReplicatedId());
        }
    }

    /**
     * This method add the payment term id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addPaymentTermIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getPaymentTermId() != null) {
            where.eq("paymentTerm.id", invoiceSearch.getPaymentTermId());
        }
    }

    /**
     * This method add the invoice situation id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addInvoiceSituationIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getInvoiceSituationId() != null) {
            where.eq("invoiceSituation.id", invoiceSearch.getInvoiceSituationId());
        }
    }

    /**
     * This method add the id condition for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addInvoiceSituationDescriptionCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (!StringUtils.isEmpty(invoiceSearch.getInvoiceSituationDescription())) {
            where.icontains("invoiceSituation.description", invoiceSearch.getInvoiceSituationDescription());
        }
    }

    /**
     * This method add the invoice type id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addInvoiceTypeIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (invoiceSearch.getInvoiceTypeId() != null) {
            where.eq("invoiceType.id", invoiceSearch.getInvoiceTypeId());
        }
    }

    /**
     * This method add the external id for the where clause.
     *
     * @param invoiceSearch the invoice search contains filters to apply on where clause
     * @param where         where for search
     */
    private void addExternalIdCondition(final InvoiceSearch invoiceSearch, ExpressionList<Invoice> where) {

        if (!StringUtils.isEmpty(invoiceSearch.getExternalId())) {
            where.eq("externalId", invoiceSearch.getExternalId());
        }
    }

    /**
     * Returns true if the Invoice exists or false if not.
     *
     * @param id id of invoice
     * @return true if invoice exists and false if not
     */
    public Boolean invoiceExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }
}