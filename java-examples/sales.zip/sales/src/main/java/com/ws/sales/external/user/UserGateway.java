package com.ws.sales.external.user;

import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.sales.external.AbstractGateway;
import com.ws.user.model.User;
import com.ws.user.user.UserResource;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.SimpleAuthorizationInfo;

import java.util.Optional;
import java.util.UUID;

import static java.util.Objects.nonNull;

/**
 * @author ivan.reffatti
 * @author Marco Aurelio F. Schaefer
 * @since 2017/04/19
 */
public class UserGateway extends AbstractGateway {

    @InjectProxy
    private UserResource userResource;

    /**
     * Method to get permissions from user service
     *
     * @return permissions
     */
    public SimpleAuthorizationInfo getPermissions() {
        return Optional.ofNullable(getCache(SimpleAuthorizationInfo.class, null))
                .orElseGet(() -> Optional.of(userResource.permission())
                        .filter(response -> response.getStatus() == HttpStatus.SC_OK)
                        .map(response -> putCacheWithNullKey(getEntityFromResponse(response, SimpleAuthorizationInfo.class)))
                        .orElse(null));
    }

    /**
     * Method to get a user from user service
     *
     * @param id id from user
     * @return user
     */
    public User getUser(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(User.class, id, userResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if user exists
     *
     * @param id id to get user
     * @return {@code true} if user is exists, {@code false} otherwise
     */
    public Boolean userExists(final UUID id) {
        return getUser(id) != null;
    }

    /**
     * Method to return if user is active
     *
     * @param userId id to get user
     * @return {@code true} if user is active, {@code false} otherwise
     */
    public Boolean userIsActive(final UUID userId) {
        final User user = this.getUser(userId);
        if (user != null) {
            return user.isActive();
        }
        return Boolean.TRUE;
    }
}
