package com.ws.sales.documents;

import java.io.InputStream;

/**
 *
 * @author  Dante Basso <dante.basso@wssim.com.br>
 * @since 2019-03-16
 * @version 1.0.0
 */
public class Document {

    private InputStream stream;

    private String filename;

    /**
     * Get {@link #stream}
     * @return {@link InputStream}
     */
    public InputStream getStream() {
        return stream;
    }

    /**
     * Set {@link #stream}
     *
     * @param stream
     */
    public void setStream(InputStream stream) {
        this.stream = stream;
    }

    /**
     * Get {@link #filename}
     * @return {@link String}
     */
    public String getFilename() {
        return filename;
    }

    /**
     * Set {@link #filename}
     * @param filename
     */
    public void setFilename(String filename) {
        this.filename = filename;
    }

}
