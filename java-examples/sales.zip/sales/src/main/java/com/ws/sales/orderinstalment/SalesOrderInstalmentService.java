package com.ws.sales.orderinstalment;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.exception.LogicException;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
@Default
public class SalesOrderInstalmentService extends AbstractService<SalesOrderInstalment> {

    private final SalesOrderInstalmentDAO salesOrderInstalmentDAO;
    private final SalesOrderInstalmentValidator salesOrderInstalmentValidator;
    private final SalesOrderInstalmentLogic salesOrderInstalmentLogic;
    private final SalesOrderInstalmentGenerateValidator salesOrderInstalmentGenerateValidator;

    @Inject
    public SalesOrderInstalmentService(final SalesOrderInstalmentDAO dao,
                                       final SalesOrderInstalmentValidator salesOrderInstalmentValidator,
                                       final SalesOrderInstalmentLogic salesOrderInstalmentLogic,
                                       final SalesOrderInstalmentGenerateValidator salesOrderInstalmentGenerateValidator) {
        super(dao);
        this.salesOrderInstalmentDAO = dao;
        this.salesOrderInstalmentValidator = salesOrderInstalmentValidator;
        this.salesOrderInstalmentLogic = salesOrderInstalmentLogic;
        this.salesOrderInstalmentGenerateValidator = salesOrderInstalmentGenerateValidator;
    }

    /**
     * Generate new instalments using the number of days between each instalment and the number of instalments
     * Return the objects inserted
     *
     * @param salesOrderInstalmentGenerate Object who contains the information about number of instalments and days between each one
     * @param orderId                      id from the order who the instalments belongs
     * @return List<SalesOrderInstalment> instalments
     * @author Maykon Rissi
     */
    public List<SalesOrderInstalment> generateInstalments(SalesOrderInstalmentGenerate salesOrderInstalmentGenerate, final UUID orderId) throws Exception {
        if ((salesOrderInstalmentGenerate == null
                || salesOrderInstalmentGenerate.getQuantity() == null
                || salesOrderInstalmentGenerate.getDaysBetween() == null) || salesOrderInstalmentGenerate.getQuantity().equals(0)) {
            return new LinkedList<>();
        }
        salesOrderInstalmentGenerate.setOrderId(orderId);
        salesOrderInstalmentGenerateValidator.validateByBeanValidation(salesOrderInstalmentGenerate, null);
        salesOrderInstalmentGenerateValidator.throwFoundErrors();
        salesOrderInstalmentGenerateValidator.validate(salesOrderInstalmentGenerate, EValidationType.INSERT);
        salesOrderInstalmentGenerateValidator.throwFoundErrors();
        final List<SalesOrderInstalment> instalments = salesOrderInstalmentLogic.getInstalmentsFromOrder(orderId, null);
        if (!instalments.isEmpty()) {
            final Set<UUID> idsForDelete = instalments.stream()
                    .map(SalesOrderInstalment::getId)
                    .collect(Collectors.toSet());
            this.dao.deleteAllPermanent(idsForDelete);
        }
        final List<SalesOrderInstalment> instalmentsForPersist = salesOrderInstalmentLogic.calculateInstalments(salesOrderInstalmentGenerate, orderId);
        if (instalmentsForPersist.isEmpty()) {
            throw new LogicException(new LogicError(Constants.FIELD_VALUE, Constants.MESSAGE_INSTALMENTS_VALUE_DIFFERENT_THAN_ORDER));
        }
        return this.batchInsert(instalmentsForPersist);
    }

    /**
     * Pagination search using the filters in SalesOrderInstalmentSearch
     *
     * @param search search entity
     * @author Maykon Rissi
     */
    public PagedList<SalesOrderInstalment> search(final SalesOrderInstalmentSearch search) {
        return this.salesOrderInstalmentDAO.search(search);
    }


    /**
     * Delete all of the instalments in the database that belongs to the informed Order
     *
     * @param orderId id from the order who the instalments belongs
     * @author Maykon Rissi
     */
    public void deleteByOrderId(final UUID orderId) {
        // Validate if order exists before delete instalments
        salesOrderInstalmentLogic.doValidateOrderExists(orderId);
        final List<SalesOrderInstalment> instalments = salesOrderInstalmentLogic.getInstalmentsFromOrder(orderId, "id");
        if (!instalments.isEmpty()) {
            final Set<UUID> idsForDelete = instalments.stream()
                    .map(SalesOrderInstalment::getId)
                    .collect(Collectors.toSet());
            super.batchDelete(idsForDelete);
        }
    }

    /**
     * Handles the update for a single entity
     * In the end, it will return the registers
     *
     * @param orderId id from the order who the instalments belongs
     * @author Maykon Rissi
     */
    public List<SalesOrderInstalment> updateEntity(final SalesOrderInstalment instalment,
                                                   final UUID orderId) {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(orderId);
        instalment.setSalesOrder(salesOrder);
        salesOrderInstalmentValidator.validateByBeanValidation(instalment, Constants.FIELD_ORDER_INSTALMENT);
        salesOrderInstalmentValidator.throwFoundErrors();
        salesOrderInstalmentValidator.validate(instalment, EValidationType.UPDATE);
        salesOrderInstalmentValidator.throwFoundErrors();
        instalment.setSalesOrder(salesOrderInstalmentLogic.getSalesOrder(orderId));
        final List<SalesOrderInstalment> instalments = salesOrderInstalmentLogic.editInstalment(instalment, orderId)
                .stream()
                .sorted(Comparator.comparingInt(SalesOrderInstalment::getNumber))
                .collect(Collectors.toList());
        this.dao.updateAll(instalments);
        return instalments;
    }


}
