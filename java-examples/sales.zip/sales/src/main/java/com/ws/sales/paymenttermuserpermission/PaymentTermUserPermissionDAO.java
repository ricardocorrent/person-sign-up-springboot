package com.ws.sales.paymenttermuserpermission;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.restquery.RestQueryUrl;
import com.ws.commons.persistence.restquery.RestQueryUrlParams;
import com.ws.commons.persistence.restquery.RestQueryUrlParser;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.commons.server.pagination.Sort;
import io.ebean.ExpressionList;
import io.ebean.Query;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermUserPermissionDAO extends AbstractDAO<PaymentTermUserPermission> {

    @Override
    public Class<PaymentTermUserPermission> getEntityClass() {
        return PaymentTermUserPermission.class;
    }

    public PagedList<PaymentTermUserPermission> getByPaymentTerm(UUID paymentTermId, final Map<String, String[]> queryParams) {
        final Query<PaymentTermUserPermission> query = find();
        final ExpressionList<PaymentTermUserPermission> where = query.where();
        PaginationSearch paginationSearch = new PaginationSearch();

        if (Objects.nonNull(queryParams) && queryParams.containsKey("q") && Objects.nonNull(queryParams.get("q"))) {
            final RestQueryUrlParams restQueryUrlParams = RestQueryUrlParser.parseUrl(queryParams.get("q")[0]);

            RestQueryUrl.buildQueryFilter(restQueryUrlParams, this.clazz, query);

            paginationSearch = getPaginationSearch(restQueryUrlParams);
        } else if (Objects.nonNull(queryParams)) {
            restQuery.createGETQueryFilter(queryParams, this.clazz, query);
            paginationSearch = getPaginationSearch(queryParams);
        }

        where.in("paymentTerm.id", paymentTermId);

        final Sort sort = new Sort();
        sort.setField("userName");
        sort.setDir("asc");

        paginationSearch.setSort(Collections.singletonList(sort));
        return getPagedList(query, paginationSearch);
    }

}
