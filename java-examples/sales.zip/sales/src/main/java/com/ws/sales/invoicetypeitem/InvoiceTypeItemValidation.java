package com.ws.sales.invoicetypeitem;

import com.ws.commons.server.validation.logicvalidation.LogicValidator;

/**
 * This class represents the validator of business rules of Invoice Type Item.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class InvoiceTypeItemValidation extends LogicValidator<InvoiceTypeItem> {

}