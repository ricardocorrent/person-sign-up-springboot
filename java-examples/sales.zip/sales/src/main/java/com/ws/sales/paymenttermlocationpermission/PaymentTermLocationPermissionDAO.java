package com.ws.sales.paymenttermlocationpermission;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.commons.server.pagination.Sort;
import io.ebean.ExpressionList;
import io.ebean.Query;

import java.util.Collections;
import java.util.UUID;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermLocationPermissionDAO extends AbstractDAO<PaymentTermLocationPermission> {

    @Override
    public Class<PaymentTermLocationPermission> getEntityClass() {
        return PaymentTermLocationPermission.class;
    }

    public PagedList<PaymentTermLocationPermission> getByPaymentTerm(UUID paymentTermId) {
        final Query<PaymentTermLocationPermission> query = find();
        final ExpressionList<PaymentTermLocationPermission> where = query.where();
        where.in("paymentTerm.id", paymentTermId);

        final Sort sort = new Sort();
        sort.setField("locationDescription");
        sort.setDir("asc");

        final PaginationSearch paginationSearch = new PaginationSearch();
        paginationSearch.setSort(Collections.singletonList(sort));
        return getPagedList(query, paginationSearch);
    }

}
