package com.ws.sales.documents.mapper;

import java.math.BigDecimal;

/**
 * @author Dante Basso <dante.basso@wwsim.com.br>
 * @version 1.0.0
 * @since 2019-03-18
 */
public class ProductMapper {

    private BigDecimal detailsAverageWeight;

    private BigDecimal detailsBasePrice;

    private String detailsCode;

    private BigDecimal detailsCostPrice;

    private String detailsDescription;

    private DetailsDiscountMapper detailsDiscount;

    private DetailsIncreaseMapper detailsIncrease;

    private String detailsMeasurementUnit;

    private String detailsNote;

    private String detailsPackaging;

    private String detailsPriceList;

    private String detailsProductGroup;

    private BigDecimal detailsQuantity;

    private BigDecimal detailsSalesPrice;

    private BigDecimal detailsStock;

    private BigDecimal detailsTotal;

    private BigDecimal detailsPrice;

    public BigDecimal getDetailsAverageWeight() {
        return detailsAverageWeight;
    }

    public void setDetailsAverageWeight(BigDecimal detailsAverageWeight) {
        this.detailsAverageWeight = detailsAverageWeight;
    }

    public BigDecimal getDetailsBasePrice() {
        return detailsBasePrice;
    }

    public void setDetailsBasePrice(BigDecimal detailsBasePrice) {
        this.detailsBasePrice = detailsBasePrice;
    }

    public String getDetailsCode() {
        return detailsCode;
    }

    public void setDetailsCode(String detailsCode) {
        this.detailsCode = detailsCode;
    }

    public BigDecimal getDetailsCostPrice() {
        return detailsCostPrice;
    }

    public void setDetailsCostPrice(BigDecimal detailsCostPrice) {
        this.detailsCostPrice = detailsCostPrice;
    }

    public DetailsDiscountMapper getDetailsDiscount() {
        return detailsDiscount;
    }

    public void setDetailsDiscount(DetailsDiscountMapper detailsDiscount) {
        this.detailsDiscount = detailsDiscount;
    }

    public DetailsIncreaseMapper getDetailsIncrease() {
        return detailsIncrease;
    }

    public void setDetailsIncrease(DetailsIncreaseMapper detailsIncrease) {
        this.detailsIncrease = detailsIncrease;
    }

    public String getDetailsMeasurementUnit() {
        return detailsMeasurementUnit;
    }

    public void setDetailsMeasurementUnit(String detailsMeasurementUnit) {
        this.detailsMeasurementUnit = detailsMeasurementUnit;
    }

    public String getDetailsNote() {
        return detailsNote;
    }

    public void setDetailsNote(String detailsNote) {
        this.detailsNote = detailsNote;
    }

    public String getDetailsPackaging() {
        return detailsPackaging;
    }

    public void setDetailsPackaging(String detailsPackaging) {
        this.detailsPackaging = detailsPackaging;
    }

    public String getDetailsPriceList() {
        return detailsPriceList;
    }

    public void setDetailsPriceList(String detailsPriceList) {
        this.detailsPriceList = detailsPriceList;
    }

    public String getDetailsProductGroup() {
        return detailsProductGroup;
    }

    public void setDetailsProductGroup(String detailsProductGroup) {
        this.detailsProductGroup = detailsProductGroup;
    }

    public BigDecimal getDetailsQuantity() {
        return detailsQuantity;
    }

    public void setDetailsQuantity(BigDecimal detailsQuantity) {
        this.detailsQuantity = detailsQuantity;
    }

    public BigDecimal getDetailsSalesPrice() {
        return detailsSalesPrice;
    }

    public void setDetailsSalesPrice(BigDecimal detailsSalesPrice) {
        this.detailsSalesPrice = detailsSalesPrice;
    }

    public BigDecimal getDetailsStock() {
        return detailsStock;
    }

    public void setDetailsStock(BigDecimal detailsStock) {
        this.detailsStock = detailsStock;
    }

    public BigDecimal getDetailsTotal() {
        return detailsTotal;
    }

    public void setDetailsTotal(BigDecimal detailsTotal) {
        this.detailsTotal = detailsTotal;
    }

    public String getDetailsDescription() {
        return detailsDescription;
    }

    public void setDetailsDescription(String detailsDescription) {
        this.detailsDescription = detailsDescription;
    }

    public BigDecimal getDetailsPrice() {
        return detailsPrice;
    }

    public void setDetailsPrice(BigDecimal detailsPrice) {
        this.detailsPrice = detailsPrice;
    }

}
