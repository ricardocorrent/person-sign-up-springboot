package com.ws.sales.external.cloudmanager;

import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.sales.external.ConfigEnvironment;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Gateway for cloud manager
 *
 * @author Alan J. A. Pena
 * @since 2018-10-23
 */
public class CloudManagerGateway {

    private static final Logger LOGGER = LoggerFactory.getLogger(CloudManagerGateway.class);
    private Client client;
    private final CloudManagerConfig cloudManagerConfig;
    private final ConfigEnvironment configEnvironment;

    @Inject
    public CloudManagerGateway(final CloudManagerConfig cloudManagerConfig, final ConfigEnvironment configEnvironment) {
        this.cloudManagerConfig = cloudManagerConfig;
        this.configEnvironment = configEnvironment;
    }

    /**
     * Method to search the customers from cloud manager
     *
     * @return a list of customer from cloud manager
     */
    public final List<CustomerCloudManager> searchCustomers() {
        final List<CustomerCloudManager> customerToBeReturned = new ArrayList<>();

        try {
            open();

            final String baseUrl = cloudManagerConfig.getAddress();
            final int pageSize = PaginationSearch.DEFAULT_PAGESIZE;
            int page = PaginationSearch.DEFAULT_PAGE;
            int count = Integer.MAX_VALUE;

            final String path = "/customers/search?search=active==true,environment==" + configEnvironment.getEnvironment() + "&page=%s&size=%s";

            // Checks if there is more register to search (if is not the last page).
            while (page < Math.ceil((double) count / (double) pageSize)) {
                try {
                    final String filter = String.format(path, page++, pageSize);
                    final String url = StringUtils.join(baseUrl, filter);

                    final Response response = get(url);
                    if (isSuccessful(response) && isJSON(response)) {
                        final CloudManagerPagedList<CustomerCloudManager> pagedListCloudManager = getPagedListCloudManager(response);

                        final List<CustomerCloudManager> customers = 
                                Objects.nonNull(pagedListCloudManager) ? pagedListCloudManager.getItems() : null;

                        if (CollectionUtils.isNotEmpty(customers)) {
                            customerToBeReturned.addAll(customers);
                            count = pagedListCloudManager.getCount();
                        }
                    } else {
                        LOGGER.warn("Response error {} to get customers from cloud manager using path: {}. Payload: {}",
                                response.getStatus(),
                                url,
                                response.getEntity());
                        break;
                    }
                } catch (Exception e) {
                    LOGGER.error("Cloud manager integration processing failed", e);
                    break;
                }
            }
        } finally {
            close();
        }
        return customerToBeReturned;
    }

    /**
     * Method to convert the response from cloud manager
     *
     * @param response the response's object
     * @return the paged list containing the objects found
     */
    private CloudManagerPagedList<CustomerCloudManager> getPagedListCloudManager(final Response response) {
        return response
                .readEntity(new GenericType<CloudManagerPagedList<CustomerCloudManager>>() {/*No IMPL.*/});

    }

    /**
     * Returns a [Response] from a GET request.
     */
    public Response get(final String url) {
        return client
            .target(url)
            .request(MediaType.APPLICATION_JSON_TYPE)
            .header("Authorization", "Bearer " + this.cloudManagerConfig.getToken())
            .get();
    }

    /**
     * Returns if status of the given [response] is JSON.
     */
    private Boolean isJSON(final Response response) {
        final MediaType mediaType = response.getMediaType();
        return Objects.nonNull(mediaType)
                && MediaType.APPLICATION_JSON_TYPE.getType().equals(mediaType.getType())
                && MediaType.APPLICATION_JSON_TYPE.getSubtype().equals(mediaType.getSubtype());
    }

    /**
     * Returns if the status of the given [response] is [Response.Status.Family.SUCCESSFUL].
     */
    public Boolean isSuccessful(final Response response) {
        final Response.Status.Family familyStatus = Response.Status.Family.familyOf(response.getStatus());
        return Response.Status.Family.SUCCESSFUL.compareTo(familyStatus) == 0;
    }


    /**
     * Open client instance.
     */
    public void open() {
        client = ClientBuilder.newClient();
    }

    /**
     * Close client instance.
     */
    public void close() {
        client.close();
    }
}
