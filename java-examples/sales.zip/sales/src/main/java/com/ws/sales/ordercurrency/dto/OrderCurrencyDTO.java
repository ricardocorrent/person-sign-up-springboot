package com.ws.sales.ordercurrency.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.administration.dto.CurrencyDTO;
import com.ws.sales.external.administration.dto.QuotationDTO;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Created by sergio.junior on 11/1/2017.
 */
public class OrderCurrencyDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private UUID id;

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "currency.id", target = "currencyId"),
            @PojoColumnMapper(source = "currency.description", target = "currencyDescription")
    })
    private CurrencyDTO currency;

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "currencyQuotation.id", target = "currencyQuotationId"),
            @PojoColumnMapper(source = "currencyQuotation.value", target = "currencyQuotationValue"),
            @PojoColumnMapper(source = "currencyQuotation.date", target = "currencyQuotationDate")
    })
    private QuotationDTO currencyQuotation;

    @PojoColumnMapper(source = "value", target = "orderItemValue")
    private BigDecimal value;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime createdAt;

    /**
     * Get of property {@link #id}
     *
     * @return java.util.UUID
     */
    @Override
    public UUID getId() {
        return id;
    }

    /**
     * Set of property {@link #id}
     *
     * @param id field to set
     */
    @Override
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * Get of property {@link #currency}
     *
     * @return com.ws.sales.ordercurrency.externaldto.CurrencyDTO
     */
    public CurrencyDTO getCurrency() {
        return currency;
    }

    /**
     * Set of property {@link #currency}
     *
     * @param currency field to set
     */
    public void setCurrency(final CurrencyDTO currency) {
        this.currency = currency;
    }

    /**
     * Get of property {@link #currencyQuotation}
     *
     * @return com.ws.sales.ordercurrency.externaldto.QuotationDTO
     */
    public QuotationDTO getCurrencyQuotation() {
        return currencyQuotation;
    }

    /**
     * Set of property {@link #currencyQuotation}
     *
     * @param currencyQuotation field to set
     */
    public void setCurrencyQuotation(final QuotationDTO currencyQuotation) {
        this.currencyQuotation = currencyQuotation;
    }

    /**
     * Get of property {@link #value}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Set of property {@link #value}
     *
     * @param value field to set
     */
    public void setValue(final BigDecimal value) {
        this.value = value;
    }

    /**
     * Get of property {@link #createdAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Set of property {@link #createdAt}
     *
     * @param createdAt field to set
     */
    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
