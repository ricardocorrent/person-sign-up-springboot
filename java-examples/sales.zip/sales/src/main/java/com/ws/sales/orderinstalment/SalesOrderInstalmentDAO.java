package com.ws.sales.orderinstalment;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.pagination.Sort;
import io.ebean.ExpressionList;
import io.ebean.Query;

import java.util.Collections;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
public class SalesOrderInstalmentDAO extends AbstractDAO<SalesOrderInstalment> {

    @Override
    public Class<SalesOrderInstalment> getEntityClass() {
        return SalesOrderInstalment.class;
    }

    public PagedList<SalesOrderInstalment> search(final SalesOrderInstalmentSearch search) {

        final Query<SalesOrderInstalment> query = find();

        final ExpressionList<SalesOrderInstalment> where = query.where();

        if (search.getOrderId() != null) {
            where.in("salesOrder.id", search.getOrderId());
        }

        if (search.getDueDate() != null) {
            where.eq("dueDate", search.getDueDate());
        }

        if (search.getNumber() != null) {
            where.eq("number", search.getNumber());
        }

        final Sort sort = new Sort();
        sort.setField("number");
        sort.setDir("asc");

        search.setSort(Collections.singletonList(sort));

        return getPagedList(query, search);
    }

}
