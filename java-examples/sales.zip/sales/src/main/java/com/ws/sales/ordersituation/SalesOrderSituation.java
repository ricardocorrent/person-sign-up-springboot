package com.ws.sales.ordersituation;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.situation.Situation;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
@Entity
public class SalesOrderSituation extends SoftDeleteBaseEntity implements Serializable {


    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    private SalesOrder salesOrder;

   /* @NotNull
    @Size(max = 255)
    private String salesOrderOrderNumber;*/

    @NotNull
    private UUID situationId;

    @NotNull
    @Size(max = 255)
    private String situationDescription;

    @Size(max = 255)
    private String situationIcon;

    @Column(precision = 18, scale = 6)
    private BigDecimal rank;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime startedOn;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime endedOn;

    /**
     * Gets the SalesOrder
     *
     * @return {@link SalesOrder}
     */
    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    /**
     * Sets the {@link SalesOrder}
     *
     * @param salesOrder
     */
    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    /**
     * Gets the {@link Situation} Id
     *
     * @return java.util.UUID
     */
    public UUID getSituationId() {
        return situationId;
    }

    /**
     * Sets the {@link Situation} Id
     *
     * @param situationId
     */
    public void setSituationId(final UUID situationId) {
        this.situationId = situationId;
    }

    /**
     * Gets the {@link Situation} description
     *
     * @return java.lang.String
     */
    public String getSituationDescription() {
        return situationDescription;
    }

    /**
     * Sets the {@link Situation} description
     *
     * @param situationDescription
     */
    public void setSituationDescription(final String situationDescription) {
        this.situationDescription = situationDescription;
    }

    /**
     * Gets the date when the order situation started
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getStartedOn() {
        return startedOn;
    }

    /**
     * Define when the order situation started
     *
     * @param startedOn
     */
    public void setStartedOn(final OffsetDateTime startedOn) {
        this.startedOn = startedOn;
    }

    /**
     * Gets the date when the order situation finished
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getEndedOn() {
        return endedOn;
    }

    /**
     * Define when the order situation ended
     *
     * @param endedOn
     */
    public void setEndedOn(final OffsetDateTime endedOn) {
        this.endedOn = endedOn;
    }

    /**
     * Gets the rank of a Order situation.
     * Used to establish the sequence between all situations of an order.
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getRank() {
        return rank;
    }

    /**
     * Sets the rank of a Order situation.
     * Used to establish the sequence between all situations of an order.
     *
     * @param rank
     */
    public void setRank(final BigDecimal rank) {
        this.rank = rank;
    }


    /**
     * Gets the Icon description.
     *
     * @return java.lang.String
     */
    public String getSituationIcon() {
        return situationIcon;
    }

    /**
     * Define which Icon will be shown.
     * Icons: http://fontawesome.io/icons/
     * <p>
     * Example:
     * situationIcon = "fa-envelope-open fa-2x red";
     *
     * @param situationIcon a String  with the name and color and size of the icon
     */
    public void setSituationIcon(final String situationIcon) {
        this.situationIcon = situationIcon;
    }
}
