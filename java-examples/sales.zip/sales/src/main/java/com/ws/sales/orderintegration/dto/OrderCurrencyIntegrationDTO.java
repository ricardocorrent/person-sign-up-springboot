package com.ws.sales.orderintegration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Peterson Schmitt
 * @since 8.6.0 2019-06-27
 */
@Getter
@Setter
public class OrderCurrencyIntegrationDTO extends BaseDTO {

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "currency.id", target = "currencyId"),
            @PojoColumnMapper(source = "currency.description", target = "currencyDescription"),
    })
    private CurrencyIntegrationDTO currency;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "currencyQuotation.id", target = "currencyQuotationId"),
            @PojoColumnMapper(source = "currencyQuotation.description", target = "currencyQuotationDescription"),
    })
    private CurrencyQuotationIntegrationDTO currencyQuotation;

}
