package com.ws.sales.external;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.server.json.ObjectMapperResolver;
import org.apache.http.HttpStatus;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * This class can be used to manage ObjectMapper and cache objects from gateways
 *
 * @author Marco Aurelio F. Schaefer
 * @since 2018-03-04 5.21.0
 */
public abstract class AbstractGateway {

    private static final String FUNCTION_GET_KEY_NULL_MESSAGE = "The function to getEntityFromGatewayCall key cannot be null.";
    private static final String FUNCTION_CONVERTER_KEY_NULL_MESSAGE = "The function to convert key cannot be null.";
    private static final String OBJECT_TO_CACHE_NULL_MESSAGE = "The object to be cached cannot be null.";

    private final Map<Integer, Map<Object, Object>> cache;

    private final ObjectMapper mapper;

    /**
     * Initialize and configure ObjectMapper and cache
     */
    public AbstractGateway() {
        this.mapper = ObjectMapperResolver.getInstance().createMapper();
        this.cache = new HashMap<>();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    /**
     * getEntityFromGatewayCall ObjectMapper managed
     *
     * @return object mapper configured
     */
    public ObjectMapper getMapper() {
        return mapper;
    }

    /**
     * This method can be used to cache an object grouping by its class and key returned by function
     *
     * @param <T>                  type of object to cache
     * @param <K>                  type of key to convert
     * @param functionGetKey       function to obtain data that will be used as key to cache
     * @param functionConverterKey function to convert key to another object type
     * @param object               object that will be cached
     * @return object cached
     */
    public <T, K> T putCache(final Function<T, K> functionGetKey, final Function<K, Object> functionConverterKey, final T object) {
        Objects.requireNonNull(functionGetKey, FUNCTION_GET_KEY_NULL_MESSAGE);
        Objects.requireNonNull(functionConverterKey, FUNCTION_CONVERTER_KEY_NULL_MESSAGE);
        Objects.requireNonNull(object, OBJECT_TO_CACHE_NULL_MESSAGE);

        final Map<Object, Object> mapCacheObjectById = cache.computeIfAbsent(object.getClass().hashCode(), key -> new HashMap<>());
        mapCacheObjectById.put(functionConverterKey.apply(functionGetKey.apply(object)), object);
        return object;
    }

    /**
     * This method can be used to cache objects grouping by its class and key returned by function
     *
     * @param <T>                  type of object to cache
     * @param <K>                  type of key to convert
     * @param functionGetKey       function to obtain data that will be used as key to cache
     * @param functionConverterKey function to convert key to another object type
     * @param objects              objects that will be cached
     * @return objects cached
     */
    public <T, K> List<T> putCache(final Function<T, K> functionGetKey, final Function<K, Object> functionConverterKey, final List<T> objects) {
        return objects.stream().map(object -> putCache(functionGetKey, functionConverterKey, object)).collect(Collectors.toList());
    }

    /**
     * This method can be used to cache an object grouping by its class and key
     *
     * @param <T>    type of object to cache
     * @param key    key to cache
     * @param object object that will be cached
     * @return object cached
     */
    public <T> T putCache(final Object key, final T object) {
        Objects.requireNonNull(key, FUNCTION_GET_KEY_NULL_MESSAGE);
        Objects.requireNonNull(object, OBJECT_TO_CACHE_NULL_MESSAGE);

        cache.computeIfAbsent(object.getClass().hashCode(), k -> new HashMap<>()).put(key, object);
        return object;
    }

    /**
     * This method can be used to cache an object grouping by its class and key returned by function
     *
     * @param <T>            type of object to cache
     * @param functionGetKey function to obtain data that will be used as key to cache
     * @param object         object that will be cached
     * @return object cached
     */
    public <T> T putCache(final Function<T, Object> functionGetKey, final T object) {
        Objects.requireNonNull(functionGetKey, FUNCTION_GET_KEY_NULL_MESSAGE);
        Objects.requireNonNull(object, OBJECT_TO_CACHE_NULL_MESSAGE);

        cache.computeIfAbsent(object.getClass().hashCode(), key -> new HashMap<>()).put(functionGetKey.apply(object), object);
        return object;
    }

    /**
     * This method can be used to cache objects grouping by its class and key returned by function
     *
     * @param <T>            type of object to cache
     * @param functionGetKey function to obtain data that will be used as key to cache
     * @param objects        objects that will be cached
     * @return objects cached
     */
    public <T> List<T> putCache(final Function<T, Object> functionGetKey, final List<T> objects) {
        return objects.stream().map(object -> putCache(functionGetKey, object)).collect(Collectors.toList());
    }

    /**
     * This method can be used to cache an object grouping by its class and key returned by function
     *
     * @param <T>    type of object to cache
     * @param object object that will be cached
     * @return object cached
     */
    public <T> T putCacheWithNullKey(final T object) {
        Objects.requireNonNull(object, OBJECT_TO_CACHE_NULL_MESSAGE);

        cache.computeIfAbsent(object.getClass().hashCode(), key -> new HashMap<>()).put(null, object);
        return object;
    }

    /**
     * Get object cached by class and key
     *
     * @param <T>   Type of object cached
     * @param clazz class of object cached
     * @param key   key of object cached
     * @return object cached
     */
    @SuppressWarnings({"unchecked"})
    public <T> T getCache(final Class<T> clazz, final Object key) {
        return (T) cache.getOrDefault(clazz.hashCode(), new HashMap<>()).get(key);
    }

    /**
     * This method will try to read entity from the response
     *
     * @param response      that contains the entity
     * @param expectedClazz expected class from entity
     * @param <T>           type of entity
     * @return the parsed entity
     */
    public <T> T getEntityFromResponse(final Response response, final Class<T> expectedClazz) {
        try {
            return getMapper().readValue((InputStream) response.getEntity(), expectedClazz);
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * This method will try to retrieve a cached entity. If the cached entity isn't present it will retrieve the entity from it's microservice and cache it
     *
     * @param clazz        class of entity
     * @param key          key to cache object
     * @param gatewayCall  microservice call to get entity
     * @param gatewayParam param to pass for microservice call
     * @param <E>          Entity type
     * @param <K>          Key type
     * @param <P>          Param type
     * @return entity
     */
    public <E, K, P> E getEntityFromGatewayCall(final Class<E> clazz,
                                                final K key,
                                                final Function<P, Response> gatewayCall,
                                                final P gatewayParam) {
        return Optional.ofNullable(getCache(clazz, key))
                .orElseGet(() -> Optional.of(gatewayCall.apply(gatewayParam))
                        .filter(response -> response.getStatus() == HttpStatus.SC_OK)
                        .map(response -> putCache(key, getEntityFromResponse(response, clazz)))
                        .orElse(null));
    }

}
