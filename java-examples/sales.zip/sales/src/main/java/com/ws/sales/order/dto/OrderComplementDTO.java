package com.ws.sales.order.dto;

import com.ws.commons.pojoconverter.DefaultPojoConverter;


/**
 * Created by maykon.rissi on 25-Jan-18.
 */
public class OrderComplementDTO implements DefaultPojoConverter {

    private String complement;

    public String getComplement() {
        return complement;
    }

    public void setComplement(String complement) {
        this.complement = complement;
    }
}
