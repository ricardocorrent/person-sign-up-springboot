package com.ws.sales.ordertreatment;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderTreatmentDAO extends AbstractDAO<OrderTreatment> {

    /**
     * @author Maykon Rissi
     * @see AbstractDAO#getEntityClass()
     * @since v5.22.0 2018-05-28
     */
    @Override
    public Class<OrderTreatment> getEntityClass() {
        return OrderTreatment.class;
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param search entity with attributes for pagination search
     * @return PagedList
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    public PagedList<OrderTreatment> search(final OrderTreatmentSearch search) {
        final Query<OrderTreatment> query = find();
        final ExpressionList<OrderTreatment> where = query.where();
        if (search != null && search.getDescription() != null) {
            where.ilike("description", "%" + search.getDescription() + "%");
        }
        return getPagedList(query, search);
    }
}
