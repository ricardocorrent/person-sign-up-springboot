package com.ws.sales.customerorderssummary.orderssummary;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.sales.customerorderssummary.orderssummary.dto.AllOrdersDTO;

import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
public class CustomerOrdersSummaryDAO extends AbstractDAO<AllOrdersDTO> {

    /**
     * Returns the entity class declared in this class.
     *
     * @return The entity class declared as parameterized type at this class.
     */
    @Override
    public Class<AllOrdersDTO> getEntityClass() {
        return AllOrdersDTO.class;
    }

    /**
     * This method finds all finalized orders that belongs to the customer using the database for it then
     * send the dates likes a summary
     *
     * @param customerId {@link UUID} used to find the sales order
     * @return {@link AllOrdersDTO} a summary of all orders of that customer
     */
    public AllOrdersDTO getAllSalesOrders(final UUID customerId) {
        final String sql =
                "with all_sales_orders as (\n" +
                        "    select\n" +
                        "        count(distinct soi.product_id) as product_total_quantity,\n" +
                        "        count(distinct sos.service_id) as service_total_quantity,\n" +
                        "        count(distinct so.id) as total_order_quantity       \n" +
                        "    from\n" +
                        "        sales_order so\n" +
                        "    left join\n" +
                        "        sales_order_item soi on soi.sales_order_id = so.id\n" +
                        "    left join\n" +
                        "        sales_order_service sos on sos.sales_order_id = so.id\n" +
                        "    where\n" +
                        "        so.customer_id = :customerId \n" +
                        "    and \n" +
                        "        so.draft is false\n" +
                        "    ),\n" +
                        "    orders_total_values as(\n" +
                        "        select\n" +
                        "            sum(so.net_value) as orders_total_value,\n" +
                        "            sum(so.service_total_value) as service_total_value,\n" +
                        "            sum(so.product_total_value) as product_total_value\n" +
                        "        from\n" +
                        "            sales_order so\n" +
                        "        where\n" +
                        "            so.customer_id = :customerId " +
                        "        and \n" +
                        "            so.draft is false\n" +
                        "    )\n" +
                        "select  \n" +
                        "    aso.product_total_quantity as productTotalQuantity,\n" +
                        "    aso.service_total_quantity as serviceTotalQuantity,\n" +
                        "    aso.total_order_quantity as ordersQuantities,   \n" +
                        "    otv.orders_total_value as netValue,\n" +
                        "    otv.service_total_value as serviceTotalValue,\n" +
                        "    otv.product_total_value as productTotalValue\n" +
                        "from\n" +
                        "    all_sales_orders aso, orders_total_values otv";

        return ebeanServer.findDto(AllOrdersDTO.class, sql)
                .setParameter("customerId", customerId)
                .findOne();
    }

}
