package com.ws.sales.customerorderssummary.orderssummary.dto;

import com.ws.commons.pojoconverter.DefaultPojoConverter;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * This DTO class was created to represent the last order from customer.
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
@Getter
@Setter
public class LastOrderDTO implements DefaultPojoConverter {

    private UUID salesOrderId;

    private BigDecimal netValue;

    private Integer productTotalQuantity;

    private BigDecimal productTotalValue;

    private Integer serviceTotalQuantity;

    private BigDecimal serviceTotalValue;

    protected OffsetDateTime createdAt;

    private OffsetDateTime orderedAt;

}
