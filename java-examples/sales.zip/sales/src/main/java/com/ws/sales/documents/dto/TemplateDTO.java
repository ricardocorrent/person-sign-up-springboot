package com.ws.sales.documents.dto;

import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * This class has been created to represent the information about the template received.
 *
 * @since 8.3.0 2019-05-10
 *
 * @author Ricardo Corrent
 */
public class TemplateDTO implements DefaultPojoConverter {

    private String id;
    private String description;

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}
