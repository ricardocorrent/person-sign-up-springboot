package com.ws.sales.orderinstalment;

import com.ws.commons.server.pagination.PaginationSearch;

import java.time.LocalDate;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
public class SalesOrderInstalmentSearch extends PaginationSearch {

    private Integer number;

    private LocalDate dueDate;

    private UUID orderId;

    public Integer getNumber() {
        return number;
    }

    public void setNumber(final Integer number) {
        this.number = number;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(final LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public UUID getOrderId() {
        return orderId;
    }

    public void setOrderId(final UUID orderId) {
        this.orderId = orderId;
    }
}
