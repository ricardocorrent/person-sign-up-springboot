package com.ws.sales.invoice;

import com.ws.commons.server.AbstractResource;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * This class represents the Resource of Invoice, she received requisitions by REST protocol.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Path("/invoices")
public class InvoiceResource extends AbstractResource<Invoice, InvoiceSearch> {

    /**
     * Injects InvoiceService class for communication between layers of InvoiceResource and InvoiceService.
     */
    private final InvoiceService invoiceService;

    @Inject
    public InvoiceResource(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    /**
     * Method to search a list of Invoice by filter.
     *
     * @param invoiceSearch represents the search for invoice
     * @return
     */
    @Override
    public Response search(InvoiceSearch invoiceSearch) {
        return Response.ok().entity(invoiceService.search(invoiceSearch)).build();
    }

    /**
     * Method to update the relationship between invoice and invoice situation.
     *
     * @param invoiceId       invoice id for update
     * @param updateInvoiceTO contain the invoice situation id for update
     * @return
     * @throws Exception
     */
    @POST
    @Path("/{invoiceId}/situation")
    @RequiresPermissions("sales:invoice:write")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateSituationForInvoice(@PathParam("invoiceId") final UUID invoiceId,
                                              @Valid final UpdateInvoiceTO updateInvoiceTO) {
        invoiceService.updateSituationForInvoice(invoiceId, updateInvoiceTO);
        return Response.ok().build();
    }
}