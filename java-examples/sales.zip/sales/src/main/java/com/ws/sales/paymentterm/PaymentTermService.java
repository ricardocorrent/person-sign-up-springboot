package com.ws.sales.paymentterm;

import java.util.LinkedList;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import javax.enterprise.inject.Default;
import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListPaymentTerm;
import com.ws.sales.external.product.ProductGateway;


/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Default
public class PaymentTermService extends AbstractService<PaymentTerm> {

    private final PaymentTermDAO dao;
    private final PaymentTermValidation paymentTermValidation;
    private final ProductGateway productGateway;

    @Inject
    public PaymentTermService(final PaymentTermDAO dao,
                              final PaymentTermValidation paymentTermValidation, final ProductGateway productGateway) {
        super(dao);
        this.dao = dao;
        this.paymentTermValidation = paymentTermValidation;
        this.productGateway = productGateway;
    }

    public Boolean paymentTermIsActive(final UUID id) {
        return Optional.ofNullable(id)
                .map(this.dao::getStatePaymentTerm)
                .map(PaymentTerm::getActive)
                .orElse(Boolean.TRUE);
    }

    @Override
    public PaymentTerm insert(final PaymentTerm entity) throws Exception {
        paymentTermValidation.validate(entity);
        paymentTermValidation.throwFoundErrors();
        return super.insert(entity);
    }

    @Override
    public void update(final PaymentTerm entity) throws Exception {
        paymentTermValidation.validate(entity);
        paymentTermValidation.throwFoundErrors();
        super.update(entity);
    }

    /**
     * Returns the payment terms. If there are registers at PaymentTermPermission must filter
     * payment terms by permissions(Not implemented yet.) else returns the active ones.
     *
     * @param search
     * @return PagedList<PaymentTerm>
     */
    public PagedList<PaymentTerm> search(final PaymentTermSearch search) {
        return dao.list(search);
    }
    
        /**
     * Load from db the price list and get the id from the payment terms
     *
     * @param priceListId to get price list from gateway
     * @return uuid[]
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-25
     */
    private UUID[] getPaymentTermIdsFromPriceList(final UUID priceListId) {
        return Optional.ofNullable(priceListId)
                .map(productGateway::getPriceList)
                .map(PriceList::getPaymentTerms)
                .flatMap(list -> Optional.of(list.stream()))
                .orElse(Stream.empty())
                .map(PriceListPaymentTerm::getPaymentTermId)
                .map(UUID::fromString)
                .toArray(UUID[]::new);
    }

    /**
     * Get the paymentTerms from priceList
     *
     * @param search {@link PaymentTermSearchWithPriceList} to filter the register
     * @return {@link PagedList<PaymentTerm>} paymentTerms}
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-25
     */
    public PagedList<PaymentTerm> search(final PaymentTermSearchWithPriceList search) {
        PagedList<PaymentTerm> paymentTerms = new PagedList<>(new LinkedList<>(), 0);

        final UUID[] paymentTermIds = this.getPaymentTermIdsFromPriceList(search.getPriceListId());

        if (paymentTermIds != null && paymentTermIds.length > 0) {
            final PaymentTermSearch searchCopy = new PaymentTermSearch();
            searchCopy.setActive(search.getActive());
            searchCopy.setDescription(search.getDescription());
            searchCopy.setPaymentTermIds(paymentTermIds);
            paymentTerms = dao.list(searchCopy);
        }
        if (CollectionUtils.isEmpty(paymentTerms.getItems())) {
            paymentTerms = dao.listWithPermissions(search);
        }
        if (CollectionUtils.isEmpty(paymentTerms.getItems())) {
            search.setSearchWithoutPermission(Boolean.TRUE);
            paymentTerms = dao.list(search);
        }
        return paymentTerms;
    }

    /**
     * Not found any call this method anywhere. If you found call its, remove @deprecated
     * 
     * @param search
     * @return
     */
    @Deprecated
    public PagedList<PaymentTerm> searchOnlyPermissions(final PaymentTermSearchWithPriceList search) {
        return dao.listWithPermissions(search);
    }
}
