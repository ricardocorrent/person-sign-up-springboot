package com.ws.sales.external.administration;

import com.ws.administration.company.CompanyResource;
import com.ws.administration.currency.CurrencyResource;
import com.ws.administration.exchangerate.ExchangeRateResource;
import com.ws.administration.measurementunit.MeasurementUnitResource;
import com.ws.administration.model.Company;
import com.ws.administration.model.Currency;
import com.ws.administration.model.ExchangeRate;
import com.ws.administration.model.MeasurementUnit;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.sales.external.AbstractGateway;

import java.util.UUID;

import static java.util.Objects.nonNull;

/**
 * @author Marco Aurelio F. Schaefer
 * @since 2018-03-04 5.21.0
 */
public class AdministrationGateway extends AbstractGateway {

    @InjectProxy
    private CompanyResource companyResource;

    @InjectProxy
    private MeasurementUnitResource measurementUnitResource;

    @InjectProxy
    private CurrencyResource currencyResource;

    @InjectProxy
    private ExchangeRateResource exchangeRateResource;

    /**
     * Method to get a company from administration service
     *
     * @param id id from company
     * @return company
     */
    public Company getCompany(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Company.class, id, companyResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if company exists
     *
     * @param id id to get company
     * @return {@code true} if company is exists, {@code false} otherwise
     */
    public Boolean companyExists(final UUID id) {
        return getCompany(id) != null;
    }

    /**
     * Method to return if company is active
     *
     * @param id id to get company
     * @return {@code true} if company is active, {@code false} otherwise
     */
    public Boolean companyIsActive(final UUID id) {
        final Company company = this.getCompany(id);
        if (company != null) {
            return company.isActive();
        }
        return Boolean.TRUE;
    }

    /**
     * Method to get a exchange rate from administration service
     *
     * @param id id from exchange rate
     * @return exchange rate
     */
    public ExchangeRate getExchangeRate(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(ExchangeRate.class, id, exchangeRateResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if currency quotation exists
     *
     * @param id id to get exchange rate
     * @return {@code true} if exchange rate is exists, {@code false} otherwise
     */
    public Boolean currencyQuotationExists(final UUID id) {
        return getExchangeRate(id) != null;
    }

    /**
     * Method to get a measure unit from administration service
     *
     * @param id id from measure unit
     * @return measure unit
     */
    public MeasurementUnit getMeasurementUnit(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(MeasurementUnit.class, id, measurementUnitResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if measure unit exists
     *
     * @param id id to get measure unit
     * @return {@code true} if measure unit is exists, {@code false} otherwise
     */
    public Boolean measureUnitExists(final UUID id) {
        return getMeasurementUnit(id) != null;
    }

    /**
     * Method to get a currency from administration service
     *
     * @param id id from currency
     * @return currency
     */
    public Currency getCurrency(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Currency.class, id, currencyResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if currency exists
     *
     * @param id id to get currency
     * @return {@code true} if currency is exists, {@code false} otherwise
     */
    public Boolean currencyExists(final UUID id) {
        return getCurrency(id) != null;
    }

    /**
     * Method to return if currency is active
     *
     * @param id id to get currency
     * @return {@code true} if currency is active, {@code false} otherwise
     */
    public Boolean currencyIsActive(final UUID id) {
        final Currency currency = this.getCurrency(id);
        if (currency != null) {
            return currency.isActive();
        }
        return Boolean.TRUE;
    }

}