package com.ws.sales.orderoperation;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.AbstractResource;
import com.ws.sales.util.SalesAbstractResource;
import com.ws.sales.orderoperation.dto.OrderOperationDTO;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
@Path("/order-operations")
public class OrderOperationResource extends SalesAbstractResource<OrderOperation, OrderOperationSearch> {

    private final OrderOperationService orderOperationService;

    /**
     * @param orderOperationService to perform logic and update actions
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Inject
    public OrderOperationResource(final OrderOperationService orderOperationService) {
        this.orderOperationService = orderOperationService;
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param parameters entity with attributes for pagination search
     * @return PagedList
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    @RequiresPermissions("sales:order-operations:read")
    public Response search(final OrderOperationSearch parameters) {
        return Response.status(HttpStatus.SC_OK).entity(orderOperationService.search(parameters)).build();
    }

    /**
     * @author Maykon Rissi
     * @see AbstractResource#insert(SoftDeleteBaseEntity)
     * @since v5.22.0 2018-06-18
     **/
    @POST
    @Override
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderOperationDTO.class)
    public Response insert(final @Consumer @Valid OrderOperation obj) throws Exception {
        return super.insert(obj);
    }

    /**
     * @author Maykon Rissi
     * @see AbstractResource#update(UUID, BaseModel)
     * @since v5.22.0 2018-06-18
     **/
    @PUT
    @Override
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderOperationDTO.class)
    public Response update(final @PathParam("id") UUID id,
                           final @Consumer @Valid OrderOperation obj) throws Exception {
        obj.setId(id);
        return super.update(id, obj);
    }
}
