package com.ws.sales.util.hateoas;


/**
 * Hypermedia As The Engine Of Application State (HATEOAS) rel means relationship is a component of the
 * REST application architecture that distinguishes it from other network application architectures
 *
 * @author ademar.junior<ademar.junior@wssim.com.br />
 * @since 7.1.0 2018-12-19
 */
public class HateoasRelDTO {

    /**
     * rel means relationship
     * In this case, it's a self-referencing hyperlink.
     * More complex systems might include other relationships.
     * For example, an order might have a "rel":"customer" relationship,
     * linking the order to its customer.
     */
    private String rel;
    /**
     * uri is a complete URL that uniquely defines the resource.
     */
    private String uri;


    public String getRel() {
        return rel;
    }

    public void setRel(final String rel) {
        this.rel = rel;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(final String uri) {
        this.uri = uri;
    }

}
