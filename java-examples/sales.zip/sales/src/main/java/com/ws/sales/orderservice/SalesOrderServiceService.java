package com.ws.sales.orderservice;

import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.util.Constants;

import javax.inject.Inject;
import java.math.RoundingMode;
import java.util.UUID;

import static com.ws.sales.validator.ValidationUtils.biggerThanZero;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
public class SalesOrderServiceService extends AbstractService<SalesOrderService> {

    public static final RoundingMode ROUNDING_MODE = RoundingMode.HALF_EVEN;
    public static final int FALLBACK_DECIMAL_PLACES = 2;

    private final SalesOrderServiceDAO dao;

    private final SalesOrderServiceValidator salesOrderServiceValidator;

    private final OrderParameterService orderParameterService;

    private final com.ws.sales.order.SalesOrderService salesOrderService;

    /**
     * @param dao                        to perform the persistence operations.
     * @param salesOrderServiceValidator to perform validations.
     * @param orderParameterService
     * @param salesOrderService
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-17
     */
    @Inject
    public SalesOrderServiceService(final SalesOrderServiceDAO dao,
                                    final SalesOrderServiceValidator salesOrderServiceValidator,
                                    final OrderParameterService orderParameterService,
                                    final com.ws.sales.order.SalesOrderService salesOrderService) {
        super(dao);
        this.dao = dao;
        this.salesOrderServiceValidator = salesOrderServiceValidator;
        this.orderParameterService = orderParameterService;
        this.salesOrderService = salesOrderService;
    }

    /**
     * Override default insert to handle validations.
     *
     * @param entity to persist.
     * @return SalesOrderService
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-17
     */
    @Override
    public SalesOrderService insert(final SalesOrderService entity) throws Exception {
        setSalesOrderServiceInfo(entity, getDecimalPlacesFromParameters());
        salesOrderServiceValidator.validate(entity, EValidationType.INSERT);
        salesOrderServiceValidator.throwFoundErrors();
        final SalesOrderService orderCreated = super.insert(entity);
        salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
        return orderCreated;
    }

    /**
     * Method for insert service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param entity to persist.
     * @return SalesOrderService
     */
    public SalesOrderService insertServiceFinishOrder(final SalesOrderService entity) throws Exception {
        setSalesOrderServiceInfo(entity, getDecimalPlacesFromParameters());
        final SalesOrderService orderCreated = super.insert(entity);
        salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
        return orderCreated;
    }

    /**
     * Method to change sales information of SalesOrderService
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param entity the order item updated.
     * @param decimalPlaces
     */
    private void setSalesOrderServiceInfo(final SalesOrderService entity, final int decimalPlaces) {
        calculateRepetition(entity, decimalPlaces);
        calculateTotalValue(entity, decimalPlaces);
    }

    /**
     * Override default update to handle validations
     *
     * @param entity to persist.
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-17
     */
    @Override
    public void update(final SalesOrderService entity) throws Exception {
        setSalesOrderServiceInfo(entity, getDecimalPlacesFromParameters());
        salesOrderServiceValidator.validate(entity, EValidationType.UPDATE);
        salesOrderServiceValidator.throwFoundErrors();
        super.update(entity);
        this.salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
    }

    /**
     * Method for update service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.4.0 2019-05-31
     *
     * @param entity to update.
     */
    public void updateFinishOrder(final SalesOrderService entity) throws Exception {
        setSalesOrderServiceInfo(entity, getDecimalPlacesFromParameters());
        super.update(entity);
        this.salesOrderService.updateOrderTotalValue(entity.getSalesOrder().getId());
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param search entity with attributes for pagination search
     * @return PagedList
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-17
     */
    public PagedList<SalesOrderService> list(final SalesOrderServiceSearch search) {
        return dao.list(search);
    }

    @Override
    public void delete(final UUID id) throws Exception {
        final SalesOrderService oldItem = super.get(id);
        salesOrderServiceValidator.validate(oldItem, EValidationType.DELETE);
        salesOrderServiceValidator.throwFoundErrors();
        super.delete(id);
        salesOrderService.updateOrderTotalValue(oldItem.getSalesOrder().getId());
    }

    /**
     * Method for delete service from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param id to deleted.
     */
    public void deleteFinishedOrder(final UUID id) throws Exception {
        final SalesOrderService oldItem = super.get(id);
        super.delete(id);
        salesOrderService.updateOrderTotalValue(oldItem.getSalesOrder().getId());
    }

    public PagedList<SalesOrderService> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        return this.dao.findByOrder(orderId, restQueryAdapter);
    }

    /**
     * Calculates the total value for the service
     *
     * @param item to calculate
     * @param decimalPlaces
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-22
     */
    private void calculateTotalValue(final SalesOrderService item, final int decimalPlaces) {
        if (item.getTotalQuantity() != null && item.getSalesPrice() != null) {
            item.setTotalValue(item.getTotalQuantity().multiply(item.getSalesPrice()).setScale(decimalPlaces, ROUNDING_MODE));
        }
    }

    private int getDecimalPlacesFromParameters() {
        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey(Constants.FIELD_PARAMETER_DECIMAL_PLACES);
        return decimalPlacesParameter.getValue() != null
                ? Integer.valueOf(decimalPlacesParameter.getValue())
                : FALLBACK_DECIMAL_PLACES;
    }

    /**
     * Calculates the repetition for the service
     *
     * @param item
     * @param decimalPlaces
     * @author Peterson Schmitt
     * @since v8.2.0 2019-04-22
     */
    private void calculateRepetition(final SalesOrderService item, final int decimalPlaces) {
        if (biggerThanZero(item.getTotalQuantity()) && biggerThanZero(item.getQuantity())) {
            item.setRepetitions(item.getTotalQuantity().divide(item.getQuantity(), decimalPlaces, ROUNDING_MODE));
        }
    }

}
