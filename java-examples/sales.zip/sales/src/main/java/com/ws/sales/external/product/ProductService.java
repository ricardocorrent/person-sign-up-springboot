package com.ws.sales.external.product;

import com.ws.product.model.DueDateCoefficient;
import com.ws.sales.util.Constants;
import com.ws.sales.orderparameter.OrderParameterService;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.1.0 2018-08-18.
 */
public class ProductService {

    private final ProductGateway productGateway;
    private final OrderParameterService orderParameterService;

    /**
     * @param orderParameterService to load parameters
     * @param productGateway        to search dueDate
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    @Inject
    public ProductService(final ProductGateway productGateway,
                          final OrderParameterService orderParameterService) {
        this.productGateway = productGateway;
        this.orderParameterService = orderParameterService;
    }

    /**
     * @return {@link Boolean#TRUE} if the credit limit plugin is enabled
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    public Boolean isDueDatePluginActive() {
        return Boolean.valueOf(orderParameterService.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_PRICE).getValue());
    }

    /**
     * If the dueDate is null, it will return 1 to recalculate the items
     *
     * @param dueDate     to set the search and return the dueDateCoefficient
     * @param priceListId to set the search for the priceList
     * @return {@link BigDecimal} coefficient to recalculate items
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    public BigDecimal getDueDateCoefficient(final UUID priceListId, final LocalDate dueDate) {
        Objects.requireNonNull(priceListId);
        return Optional.ofNullable(dueDate)
                .map(this::doGenerateDueDateCoefficientSearch)
                .map(dueDateCoefficient -> this.productGateway.getDueDateValue(priceListId.toString(), dueDateCoefficient))
                .orElse(BigDecimal.ONE);
    }

    /**
     * @param dueDate to set the search and return the dueDateCoefficient
     * @return {@link DueDateCoefficient} search to dueDate
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    private DueDateCoefficient doGenerateDueDateCoefficientSearch(final LocalDate dueDate) {
        final DueDateCoefficient dueDateCoefficient = new DueDateCoefficient();
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.PATTERN_MM_DD_YYYY);
        final String dateString = dueDate.format(formatter);
        dueDateCoefficient.setLanguage(Constants.PATTERN_LANGUAGE_EN_US);
        dueDateCoefficient.setDate(dateString);
        return dueDateCoefficient;
    }
}
