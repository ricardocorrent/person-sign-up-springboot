package com.ws.sales.orderoperation;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderOperationValidator extends AbstractEntityValidator<OrderOperation> {

    /**
     * @author Maykon Rissi
     * @see AbstractEntityValidator#validate(BaseModel, IValidationFilter...)
     * @since v5.22.0 2018-05-28
     */
    @Override
    protected void validate(final OrderOperation entity, final IValidationFilter... filter) {
        this.validateByBeanValidation(entity, null);
    }
}
