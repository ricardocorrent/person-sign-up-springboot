package com.ws.sales.order;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.commons.server.pagination.PaginationSearch;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
public class SalesOrderSearch extends PaginationSearch {

    private Boolean[] draft;

    private String orderNumber;

    private String externalNumber;

    private String customerNumber;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private LocalDate initialOrderedDate;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private LocalDate finalOrderedDate;

    @Deprecated
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime[] invoicedBetween;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime invoicedStartDate;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime invoicedFinalDate;

    private UUID customerId;

    private UUID userId;

    private UUID locationId;

    private String[] origin;

    private String generalSearch;

    private String language;

    private Boolean toExport;

    private Boolean enablePagination;

    /**
     * Gets the options draft.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getDraft() {
        return draft;
    }

    /**
     * Set the draft options
     * Options: [true, false]
     *
     * @param draft
     */
    public void setDraft(final Boolean[] draft) {
        this.draft = draft;
    }

    /**
     * Gets the order number to be filtered
     *
     * @return java.lang.String
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Sets the order number to be filtered
     *
     * @param orderNumber
     */
    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * Gets the external number to be filtered
     *
     * @return java.lang.String
     */
    public String getExternalNumber() {
        return externalNumber;
    }

    /**
     * Sets the external number to be filtered
     *
     * @param externalNumber
     */
    public void setExternalNumber(final String externalNumber) {
        this.externalNumber = externalNumber;
    }

    /**
     * Gets the customer number to be filtered
     *
     * @return java.lang.String
     */
    public String getCustomerNumber() {
        return customerNumber;
    }

    /**
     * Sets the external number to be filtered
     *
     * @param customerNumber
     */
    public void setCustomerNumber(final String customerNumber) {
        this.customerNumber = customerNumber;
    }

    /**
     * Gets the array of invoiced dates to be filtered.
     * the array must contains [initialDate, finalDate]
     *
     * @return java.time.OffsetDateTime[]
     */
    public OffsetDateTime[] getInvoicedBetween() {
        return invoicedBetween;
    }

    /**
     * Sets the array of invoiced dates to be filtered.
     * the array must contains [initialDate, finalDate]
     *
     * @param invoicedBetween
     */
    public void setInvoicedBetween(final OffsetDateTime[] invoicedBetween) {
        this.invoicedBetween = invoicedBetween;
    }

    /**
     * Gets the Customer ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getCustomerId() {
        return customerId;
    }

    /**
     * Sets the customer ID to be filtered
     *
     * @param customerId
     */
    public void setCustomerId(final UUID customerId) {
        this.customerId = customerId;
    }

    /**
     * Gets the Location ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getLocationId() {
        return locationId;
    }

    /**
     * Sets the customer ID to be filtered
     *
     * @param locationId
     */
    public void setLocationId(final UUID locationId) {
        this.locationId = locationId;
    }

    /**
     * Gets the User ID to be filtered
     *
     * @return java.util.UUID
     */
    public UUID getUserId() {
        return userId;
    }

    /**
     * Sets the customer ID to be filtered
     *
     * @param userId
     */
    public void setUserId(final UUID userId) {
        this.userId = userId;
    }


    /**
     * Gets the origin options to be filtered
     * Options: [QION, ERP]
     *
     * @return java.lang.String[]
     */
    public String[] getOrigin() {
        return origin;
    }

    /**
     * Sets the origin options to be filtered
     * Options: [QION, ERP]
     *
     * @param origin
     */
    public void setOrigin(final String[] origin) {
        this.origin = origin;
    }

    /**
     * Gets the inital ordered date to be filtered
     *
     * @return java.time.LocalDate
     */
    public LocalDate getInitialOrderedDate() {
        return initialOrderedDate;
    }

    /**
     * Sets the inital ordered date to be filtered
     *
     * @param initialOrderedDate
     */
    public void setInitialOrderedDate(final LocalDate initialOrderedDate) {
        this.initialOrderedDate = initialOrderedDate;
    }

    /**
     * Gets the final ordered date to be filtered
     *
     * @return java.time.LocalDate
     */
    public LocalDate getFinalOrderedDate() {
        return finalOrderedDate;
    }

    /**
     * Sets the final ordered date to be filtered
     *
     * @param finalOrderedDate
     */
    public void setFinalOrderedDate(final LocalDate finalOrderedDate) {
        this.finalOrderedDate = finalOrderedDate;
    }

    public String getGeneralSearch() {
        return generalSearch;
    }

    public void setGeneralSearch(final String generalSearch) {
        this.generalSearch = generalSearch;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(final String language) {
        this.language = language;
    }

    /**
     * @return java.lang.Boolean
     */
    public Boolean getToExport() {
        return toExport;
    }

    /**
     * To filter orders that can be exported
     *
     * @param toExport
     */
    public void setToExport(final Boolean toExport) {
        this.toExport = toExport;
    }

    public OffsetDateTime getInvoicedStartDate() {
        return invoicedStartDate;
    }

    public void setInvoicedStartDate(OffsetDateTime invoicedStartDate) {
        this.invoicedStartDate = invoicedStartDate;
    }

    public OffsetDateTime getInvoicedFinalDate() {
        return invoicedFinalDate;
    }

    public void setInvoicedFinalDate(OffsetDateTime invoicedFinalDate) {
        this.invoicedFinalDate = invoicedFinalDate;
    }

    public Boolean getEnablePagination() {
        return enablePagination;
    }

    public void setEnablePagination(Boolean enablePagination) {
        this.enablePagination = enablePagination;
    }
}
