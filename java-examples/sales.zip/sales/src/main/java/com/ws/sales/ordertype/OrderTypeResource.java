package com.ws.sales.ordertype;

import com.ws.sales.util.SalesAbstractResource;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Path("/order-types")
public class OrderTypeResource extends SalesAbstractResource<OrderType, OrderTypeSearch> {

    private final OrderTypeService service;

    @Inject
    public OrderTypeResource(OrderTypeService service) {
        this.service = service;
    }

    /**
     * @param parameters as {@link OrderTypeSearch}
     * @return {@link Response}
     * @see Response
     * @see OrderTypeSearch
     */
    @Override
    @RequiresPermissions("sales:order-types:read")
    public Response search(final OrderTypeSearch parameters) {
        return Response.ok().entity(service.search(parameters)).build();
    }
}
