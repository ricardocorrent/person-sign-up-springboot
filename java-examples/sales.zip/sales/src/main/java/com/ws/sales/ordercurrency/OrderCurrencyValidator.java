package com.ws.sales.ordercurrency;

import javax.inject.Inject;

import com.ws.administration.model.ExchangeRate;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.administration.AdministrationGateway;

/**
 * @author Thyago Volpatto
 * @author Marcos Matheus de Andrade
 * @since v3.0.0 2017-03-01.
 */
public class OrderCurrencyValidator extends AbstractEntityValidator<OrderCurrency> {

    private final AdministrationGateway administrationGateway;

    @Inject
    public OrderCurrencyValidator(final AdministrationGateway administrationGateway) {
        this.administrationGateway = administrationGateway;
    }

    @Override
    protected void validate(final OrderCurrency entity, final IValidationFilter... filter) {
        addError(this.validateCurrencyExists(entity), entity);
        addError(this.validateCurrencyQuotationIsNull(entity), entity);
        addError(this.validateCurrencyQuotationExists(entity), entity);
        addError(this.validateCurrencyIsActive(entity), entity);
        addError(this.validateQuotationBelongsToOrderCurrency(entity), entity);

    }

    /**
     * This method validate if quotation is not null
     *
     * @since 8.6.0 2019-06-25
     * @author Ricardo Corrent
     *
     * @param orderCurrency {@link OrderCurrency}
     * @return {@link LogicError} or null
     */
    private LogicError validateCurrencyQuotationIsNull(final OrderCurrency orderCurrency) {
        if (orderCurrency.getCurrencyQuotationId() == null) {
            return new LogicError("currencyQuotationId", "javax.validation.constraints.NotNull.message");
        }
        return null;
    }

    /**
     * @param orderCurrency
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if order currency exists
     */
    public LogicError validateCurrencyExists(final OrderCurrency orderCurrency) {
        if (orderCurrency.getCurrencyId() != null && !administrationGateway.currencyExists(orderCurrency.getCurrencyId())) {
            return new LogicError("currencyId", "order.orderCurrency.notFound");
        }
        return null;
    }

    /**
     * @param orderCurrency
     * @return
     * @author Marcos Matheus de Andrade
     * Validate if order currency is active
     */
    public LogicError validateCurrencyIsActive(final OrderCurrency orderCurrency) {
        if (orderCurrency.getCurrencyId() != null && !administrationGateway.currencyIsActive(orderCurrency.getCurrencyId())) {
            return new LogicError("currencyId", "order.orderCurrency.inactive");
        }
        return null;
    }

    public LogicError validateCurrencyQuotationExists(final OrderCurrency orderCurrency) {
        if (orderCurrency.getCurrencyQuotationId() != null && !administrationGateway.currencyQuotationExists(orderCurrency.getCurrencyQuotationId())) {
            return new LogicError("currencyQuotationId", "order.currencyQuotation.notFound");
        }
        return null;
    }

    public LogicError validateQuotationBelongsToOrderCurrency(final OrderCurrency orderCurrency) {
        if (orderCurrency.getCurrencyId() != null && orderCurrency.getCurrencyQuotationId() != null) {
            final ExchangeRate exchangeRate = administrationGateway.getExchangeRate(orderCurrency.getCurrencyQuotationId());

            if (exchangeRate != null && exchangeRate.getCurrency() != null &&
                    !orderCurrency.getCurrencyId().toString().equals(exchangeRate.getCurrency().getId())) {
                return new LogicError("currencyQuotationId", "order.orderCurrency.quotationDateNotBelongsToCurrency");
            }
        }
        return null;
    }

    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        if (logicError == null) {
            return;
        }
        super.addError(logicError, entity);
    }
}
