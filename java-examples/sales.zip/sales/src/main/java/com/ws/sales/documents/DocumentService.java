package com.ws.sales.documents;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.json.ObjectMapperResolver;
import com.ws.product.model.Product;
import com.ws.product.model.ProductInventory;
import com.ws.sales.documents.integration.DocumentCreator;
import com.ws.sales.documents.mapper.*;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.ordersituation.SalesOrderSituation;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

/**
 * This class will provide all necessary data to Document-Manager to generate a Document.
 *
 * @author Dante Basso <dante.basso@wssim.com.br>
 * @since 2019-03-16
 * @version 0.1.0
 */
public class DocumentService {

    private DocumentGateway documentGateway;

    private ProductGateway productGateway;

    @Inject
    public DocumentService(final DocumentGateway documentGateway, final ProductGateway productGateway) {
        this.documentGateway = documentGateway;
        this.productGateway = productGateway;
    }

    /**
     * Create Document in Document-Manager API
     *
     * @param salesOrder
     * @param documentSaleCreator
     * @return
     * @throws IOException
     */
    public Document createDocument(final SalesOrder salesOrder, final DocumentSaleCreator documentSaleCreator) throws IOException {
        Objects.requireNonNull(salesOrder, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("salesOrder"));
        Objects.requireNonNull(documentSaleCreator, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("documentSaleCreator"));
        Objects.requireNonNull(documentSaleCreator.getTemplateId(), EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("templateId"));

        final DocumentCreator documentCreator = this.getDocumentCreator(documentSaleCreator.getTemplateId(), documentSaleCreator.getName(), documentSaleCreator.getFormat(), this.getSaleOrderMapper(salesOrder));
        return this.documentGateway.create(documentCreator);
    }

    /**
     * Return Data for Generate Document in Document-Manager
     *
     * @param salesOrder
     * @return {@link SalesOrderMapper}
     */
    protected SalesOrderMapper getSaleOrderMapper(final SalesOrder salesOrder) {
        Objects.requireNonNull(salesOrder, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("salesOrder"));

        final SalesOrderMapper salesOrderMapper = new SalesOrderMapper();
        salesOrderMapper.setHeader(this.getHeader(salesOrder));
        salesOrderMapper.setProducts(this.getProducts(salesOrder));
        salesOrderMapper.setSummary(this.getSummary(salesOrder, this.getTotalDiscount(salesOrderMapper)));

        return salesOrderMapper;
    }

    /**
     * Calculate total of discount in the sales order.
     *
     * @param salesOrderMapper
     * @return {@link BigDecimal}
     */
    private BigDecimal getTotalDiscount(final SalesOrderMapper salesOrderMapper) {
        BigDecimal totalDiscount = BigDecimal.ZERO;
        BigDecimal discountPerProduct = BigDecimal.ZERO;
        for (ProductMapper productMapper: salesOrderMapper.getProducts()) {
            if (productMapper.getDetailsDiscount() != null) {
                discountPerProduct = productMapper.getDetailsQuantity().multiply(productMapper.getDetailsDiscount().getValue());
                totalDiscount = totalDiscount.add(discountPerProduct);
            }
        }
        return totalDiscount;
    }

    /**
     * Get Total os Sale Order.
     *
     * @param salesOrder
     * @return {@link BigDecimal}
     */
    private BigDecimal getTotal(final SalesOrder salesOrder) {
        BigDecimal total = BigDecimal.ZERO;
        for (SalesOrderItem salesOrderItem : salesOrder.getItems()) {
           total = total.add(salesOrderItem.getTotalItem());
        }
        return total;
    }

    /**
     *  Get Situation Of SalesOrder
     *
     * @param salesOrder
     * @return {@link SalesOrderSituation}
     */
    private SalesOrderSituation getSituation(final SalesOrder salesOrder) {
        SalesOrderSituation situation = null;
        if (salesOrder.getSituationId() != null) {
            situation = salesOrder.getSalesOrderSituations().stream()
                    .filter(salesOrderSituation -> salesOrderSituation.getId().equals(salesOrder.getSituationId()))
                    .findAny()
                    .orElse(null);
        }
        return situation;
    }

    /**
     * Get Quantity of Items in Sales Order
     *
     * @return {@link BigDecimal}
     */
    private BigDecimal getQuantityItems(final SalesOrder salesOrder) {
        BigDecimal total = BigDecimal.ZERO;

        for (SalesOrderItem salesOrderItem : salesOrder.getItems()) {
            total = total.add(salesOrderItem.getQuantity());
        }
        return total;
    }

    /**
     * Get Summary
     *
     * @param salesOrder
     * @return {@link SummaryMapper}
     */
    private SummaryMapper getSummary(final SalesOrder salesOrder, final BigDecimal totalDiscount) {
        final SummaryMapper summaryMapper = new SummaryMapper();
        summaryMapper.setCreationDate(salesOrder.getCreatedAt());
        summaryMapper.setQuantityItems(salesOrder.getItems().size());
        summaryMapper.setQuantity(this.getQuantityItems(salesOrder));
        summaryMapper.setDiscount(totalDiscount);
        summaryMapper.setNumber(salesOrder.getOrderNumber());
        summaryMapper.setTotal(this.getTotal(salesOrder));
        summaryMapper.setStatus(salesOrder.getSituationDescription());
        summaryMapper.setFinishDate(salesOrder.getOrderedAt());

        final SalesOrderSituation salesOrderSituation = this.getSituation(salesOrder);
        if (salesOrderSituation != null) {
            summaryMapper.setFinishDate(salesOrderSituation.getEndedOn());
        }
        return summaryMapper;
    }

    /**
     * Get Header
     *
     * @param salesOrder
     * @return {@link HeaderMapper}
     */
    private HeaderMapper getHeader(final SalesOrder salesOrder) {
        final HeaderMapper headerMapper = new HeaderMapper();
        headerMapper.setCompany(salesOrder.getCompanyName());
        headerMapper.setCustomer(salesOrder.getCustomerName());
        headerMapper.setProfessional(salesOrder.getUserProfessionalName());
        headerMapper.setLocation(salesOrder.getLocationDescription());
        headerMapper.setPriceListDescription(salesOrder.getPriceListDescription());
        headerMapper.setOrderType(salesOrder.getOrderTypeDescription());
        headerMapper.setDueDate(salesOrder.getDueDate());
        headerMapper.setPaymentMethod(salesOrder.getPaymentMethodDescription());
        headerMapper.setPaymentTerm(salesOrder.getPaymentTermDescription());
        return headerMapper;
    }

    /**
     * Get List of Products.
     *
     * @param salesOrder
     * @return List of {@link ProductMapper}
     */
    private List<ProductMapper> getProducts(final SalesOrder salesOrder) {
        final List<ProductMapper> products = new ArrayList<>();

        for (SalesOrderItem salesOrderItem : salesOrder.getItems()) {
            final ProductMapper productMapper = new ProductMapper();
            productMapper.setDetailsCode(salesOrderItem.getProductCode());
            productMapper.setDetailsDescription(salesOrderItem.getProductDescription());
            productMapper.setDetailsPrice(salesOrderItem.getSalesPrice());
            productMapper.setDetailsQuantity(salesOrderItem.getQuantity());
            productMapper.setDetailsDiscount(this.getDiscount(salesOrderItem));
            productMapper.setDetailsIncrease(this.getIncrease(salesOrderItem));
            productMapper.setDetailsBasePrice(salesOrderItem.getOriginalPrice());
            productMapper.setDetailsSalesPrice(salesOrderItem.getSalesPrice());
            productMapper.setDetailsPackaging(salesOrderItem.getProductPackagingDescription());
            productMapper.setDetailsTotal(salesOrderItem.getTotalItem());
            productMapper.setDetailsPackaging(salesOrderItem.getProductPackagingDescription());
            productMapper.setDetailsPriceList(salesOrderItem.getPriceListDescription());

            final Product product = this.getProduct(salesOrderItem.getProductId());
            if (product != null) {
                productMapper.setDetailsNote(product.getNote());
                productMapper.setDetailsAverageWeight(product.getWeight());
                productMapper.setDetailsCostPrice(product.getCostPrice());
                productMapper.setDetailsStock(this.calculateStock(product));
                productMapper.setDetailsMeasurementUnit(product.getMeasurementUnitDescription());

                if (product.getProductGroup() != null) {
                    productMapper.setDetailsProductGroup(product.getProductGroup().getDescription());
                }
                if (StringUtils.isEmpty(productMapper.getDetailsCode())) {
                    productMapper.setDetailsCode(product.getCode());
                }
                if (StringUtils.isEmpty(productMapper.getDetailsDescription())) {
                    productMapper.setDetailsDescription(product.getDescription());
                }
            }
            products.add(productMapper);
        }
        return products;
    }

    /**
     * Create a Increase Detail Object.
     *
     * @param salesOrderItem
     * @return {@link DetailsIncreaseMapper}
     */
    private DetailsIncreaseMapper getIncrease(final SalesOrderItem salesOrderItem) {
        DetailsIncreaseMapper increaseMapper = null;
        if (salesOrderItem.getIncreaseValue() != null) {
            increaseMapper = new DetailsIncreaseMapper();
            increaseMapper.setPercentage(salesOrderItem.getIncreasePercentage());
            increaseMapper.setValue(salesOrderItem.getIncreaseValue());
        }
        return increaseMapper;
    }

    /**
     * Create a Discount Detail Object.
     *
     * @param salesOrderItem
     * @return {@link DetailsDiscountMapper}
     */
    private DetailsDiscountMapper getDiscount(final SalesOrderItem salesOrderItem) {
        DetailsDiscountMapper discountMapper = null;
        if (salesOrderItem.getDiscountValue() != null) {
            discountMapper = new DetailsDiscountMapper();
            discountMapper.setPercentage(salesOrderItem.getDiscountPercentage());
            discountMapper.setValue(salesOrderItem.getDiscountValue());
        }
        return discountMapper;
    }

    /**
     * Calculate Stock of product.
     *
     * @param product
     * @return {@link BigDecimal}
     */
    private BigDecimal calculateStock(final Product product) {
        BigDecimal stock = BigDecimal.ZERO;
        for (ProductInventory productInventory : product.getInventories()) {
            stock = stock.add(productInventory.getQuantity());
        }

        return stock;
    }

    /**
     * Find product and all information.
     *
     * @param productId
     * @return
     */
    private Product getProduct(final UUID productId) {
        return this.productGateway.getProduct(productId);
    }

    /**
     *  Create a Document Creator to
     *
     * @param templateId
     * @param name
     * @param format
     * @param salesOrderMapper
     * @return {@link DocumentCreator}
     */
    private DocumentCreator getDocumentCreator(final UUID templateId, final String name, final DocumentCreatorFormat format, final SalesOrderMapper salesOrderMapper) throws IOException {
        final DocumentCreator documentCreator = new DocumentCreator();
        documentCreator.setFormat(format);
        documentCreator.setName(name);
        documentCreator.setTemplateId(templateId.toString());
        documentCreator.setOrigin("Sales");
        documentCreator.setValues(Collections.singletonMap("sales", this.createValues(salesOrderMapper)));
        return documentCreator;
    }

    /**
     * Create Map Object from Entity.
     *
     * @param salesOrderMapper
     * @return {@link Map<String, Object>}
     * @throws IOException
     */
    private Map<String, Object> createValues(final SalesOrderMapper salesOrderMapper) throws IOException {
        final ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();
        final String json = mapper.writeValueAsString(salesOrderMapper);
        return mapper.readValue(json, Map.class);
    }

}
