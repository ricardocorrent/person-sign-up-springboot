package com.ws.sales.external.commondata;

/**
 * Enum for delivery incoterms
 *
 * @author Maykon Rissi
 * @since 2018-05-29
 */
public enum IncotermsAcronym {
    FOB, CIF
}
