package com.ws.sales.invoicesituation;

import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.logicvalidation.LogicValidator;

import javax.enterprise.inject.Default;

/**
 * This class represents the validator of business rules of Invoice Type Item.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-28
 */
@Default
@BeanValidationIntegrated(InvoiceSituation.class)
public class InvoiceSituationValidation extends LogicValidator<InvoiceSituation> {

}