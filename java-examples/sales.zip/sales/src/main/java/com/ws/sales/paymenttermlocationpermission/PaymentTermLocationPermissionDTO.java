package com.ws.sales.paymenttermlocationpermission;

import java.util.UUID;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.paymentterm.PaymentTermDTO;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermLocationPermissionDTO implements IPojoConverter {

    private UUID id;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "location.id", target = "locationId"),
            @PojoColumnMapper(source = "location.description", target = "locationDescription")
    })
    private LocationDTO location;

    private PaymentTermDTO paymentTerm;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public LocationDTO getLocation() {
        return location;
    }

    public void setLocation(final LocationDTO location) {
        this.location = location;
    }

    public PaymentTermDTO getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(final PaymentTermDTO paymentTerm) {
        this.paymentTerm = paymentTerm;
    }
}
