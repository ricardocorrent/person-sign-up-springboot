package com.ws.sales.orderoperation;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderOperationService extends AbstractService<OrderOperation> {

    private final OrderOperationDAO orderOperationDAO;
    private final OrderOperationValidator orderOperationValidator;

    /**
     * @param orderOperationDAO       to perform the persistence operations.
     * @param orderOperationValidator to perform validations.
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Inject
    public OrderOperationService(final OrderOperationDAO orderOperationDAO,
                                 final OrderOperationValidator orderOperationValidator) {
        super(orderOperationDAO);
        this.orderOperationDAO = orderOperationDAO;
        this.orderOperationValidator = orderOperationValidator;
    }

    /**
     * Override default insert to handle validations.
     *
     * @param entity to persist.
     * @return OrderTreatment
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    public OrderOperation insert(final OrderOperation entity) throws Exception {
        orderOperationValidator.validate(entity);
        orderOperationValidator.throwFoundErrors();
        return super.insert(entity);
    }

    /**
     * Override default update to handle validations
     *
     * @param entity to persist.
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    public void update(final OrderOperation entity) throws Exception {
        orderOperationValidator.validate(entity);
        orderOperationValidator.throwFoundErrors();
        super.update(entity);
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param search entity with attributes for pagination search
     * @return PagedList
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    public PagedList<OrderOperation> search(final OrderOperationSearch search) {
        return this.orderOperationDAO.search(search);
    }
}
