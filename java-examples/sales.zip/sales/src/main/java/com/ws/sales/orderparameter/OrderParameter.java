package com.ws.sales.orderparameter;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * This class represents the entity Order Parameter
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-22
 */
@Entity
public class OrderParameter extends SoftDeleteBaseEntity {

    /**
     * This field represents the key for the OrderParameter
     */
    @Size(max = 100, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    @NotNull
    @Column(unique = true)
    private String key;

    /**
     * This field represents the Internationalization Key for the OrderParameter
     */
    @Size(max = 200, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    private String internationalizationKey;

    /**
     * This field represents the Value Type for the OrderParameter
     */
    @NotNull
    @Enumerated(value = EnumType.STRING)
    @PojoColumnMapper(source = "valueType", target = "valueType")
    private EOrderParameterValueType valueType;

    /**
     * This field represents the value for the OrderParameter
     */
    @NotNull
    @Size(max = 255, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    private String value;

    /**
     * This field represents the Minimum Value for the OrderParameter
     */
    @Size(max = 255, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    private String minValue;

    /**
     * This field represents the Maximum Value for the OrderParameter
     */
    @Size(max = 255, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    private String maxValue;

    /**
     * This field represents the note for the OrderParameter
     */
    @Size(max = 255, message = OrderParameterConstants.FIELD_SIZE_VALUE)
    private String note;


    /**
     * Gets key.
     *
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets key.
     *
     * @param key the key
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets internationalizationKey.
     *
     * @return the internationalizationKey
     */
    public String getInternationalizationKey() {
        return internationalizationKey;
    }

    /**
     * Sets internationalizationKey.
     *
     * @param internationalizationKey the internationalizationKey
     */
    public void setInternationalizationKey(String internationalizationKey) {
        this.internationalizationKey = internationalizationKey;
    }

    /**
     * Gets valueType.
     *
     * @return the valueType
     */
    public EOrderParameterValueType getValueType() {
        return valueType;
    }

    /**
     * Sets valueType.
     *
     * @param valueType the valueType
     */
    public void setValueType(EOrderParameterValueType valueType) {
        this.valueType = valueType;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets minValue.
     *
     * @return the minValue
     */
    public String getMinValue() {
        return minValue;
    }

    /**
     * Sets minValue.
     *
     * @param minValue the minValue
     */
    public void setMinValue(String minValue) {
        this.minValue = minValue;
    }

    /**
     * Gets maxValue.
     *
     * @return the maxValue
     */
    public String getMaxValue() {
        return maxValue;
    }

    /**
     * Sets maxValue.
     *
     * @param maxValue the maxValue
     */
    public void setMaxValue(String maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * Gets note.
     *
     * @return the note
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets note.
     *
     * @param note the note
     */
    public void setNote(String note) {
        this.note = note;
    }
}
