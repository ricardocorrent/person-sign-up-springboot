package com.ws.sales.invoicetype;

import com.ws.commons.server.AbstractResource;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * This class represents the Resource of Invoice Type, she received requisitions by REST protocol.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Path("/invoice-types")
public class InvoiceTypeResource extends AbstractResource<InvoiceType, InvoiceTypeSearch> {

    /**
     * Injects InvoiceTypeService class for communication between layers of InvoiceTypeResource
     * and InvoiceTypeService.
     */
    private final InvoiceTypeService invoiceTypeService;

    @Inject
    public InvoiceTypeResource(InvoiceTypeService invoiceTypeService) {
        this.invoiceTypeService = invoiceTypeService;
    }

    /**
     * Method to search a list of Invoice Situation by filter.
     *
     * @param invoiceTypeSearch represents the search for invoice type
     * @return
     */
    @Override
    public Response search(InvoiceTypeSearch invoiceTypeSearch) {
        return Response.ok().entity(invoiceTypeService.search(invoiceTypeSearch)).build();
    }
}