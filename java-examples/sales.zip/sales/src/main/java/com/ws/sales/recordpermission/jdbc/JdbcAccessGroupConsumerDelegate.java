package com.ws.sales.recordpermission.jdbc;

import com.sollar.recordpermission.accessgroup.AccessGroup;
import com.sollar.recordpermission.accessgroup.AccessGroupDAO;
import com.sollar.recordpermission.accessgroup.PermissionChanges;
import com.sollar.recordpermission.accessgroup.PermissionChangesDAO;
import org.apache.commons.collections.CollectionUtils;

import javax.inject.Inject;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author gustavo.bilert
 * @since v1.0.0-SNAPSHOT 2016-12-20
 */
public class JdbcAccessGroupConsumerDelegate {

    /**
     * Action Key to add ids to the array
     */
    public static final String ADD = "ADD";
    /**
     * Action Key to remove ids from the array
     */
    public static final String REMOVE = "REMOVE";

    /**
     * The "user" AccessGroup, used as reference for hierarchy changes
     */
    public static final String USER = "user";

    @Inject
    private AccessGroupDAO accessGroupDAO;

    @Inject
    private PermissionChangesDAO permissionChangesDAO;

    @Inject
    private AccessGroupJdbcDao jdbcDao;

    /**
     * Insert an {@link AccessGroup} in the database.
     * @param accessGroup The {@link AccessGroup} to be inserted
     * @return {@link AccessGroup}
     * @throws Exception
     */
    public AccessGroup insert(final AccessGroup accessGroup) throws Exception {
        accessGroupDAO.insert(accessGroup);
        return accessGroup;
    }

    /**
     * Updates an {@link AccessGroup}, if it does not exist in the database, it is inserted.
     * The timestamps are not updated by default.
     * @param accessGroup The {@link AccessGroup} to be updated
     * @throws Exception
     */
    public void update(final AccessGroup accessGroup) throws Exception {
        update(accessGroup, false);
    }

    /**
     * Updates an {@link AccessGroup}, if it does not exist in the database, it is inserted.
     * @param accessGroup The {@link AccessGroup} to be updated
     * @param updateModificationTime Specifies if updatedAt should be set or left as it comes
     * @throws Exception
     */
    public void update(final AccessGroup accessGroup, final boolean updateModificationTime) throws Exception {

        AccessGroup previous;
        try {
            previous = accessGroupDAO.findById(accessGroup.getId());
        } catch (MissingResourceException e) {
            previous = new AccessGroup();
            previous.setEntityIds(new ArrayList<>(0));
            previous.setUserAndSuperiors(new ArrayList<>(0));
        }


        try {
            accessGroupDAO.findById(accessGroup.getId());

            accessGroupDAO.update(accessGroup, updateModificationTime);
        } catch (MissingResourceException e) {
            // Inserts records that came as updates but do not exist in the database,
            // this is to minimize message ordering problems, also for admin users that may not have been created
            // through the normal flow
            accessGroupDAO.insert(accessGroup);
        }

        gatherPermissionChangesForUpdate(accessGroup, previous, updateModificationTime);
    }

    public void updateUsingProcedure(final AccessGroup accessGroup,
                                     final boolean updateModificationTime) {
        jdbcDao.save(accessGroup, updateModificationTime);
    }

    /**
     * Compares the existing group with the updated and saves the differences to the permission_changes table.
     *
     * @param accessGroup The updated AccessGroup
     * @param previous The previous version of the AccessGroup, retrieved from the database
     * @param updateModificationTime Specifies if AccessGroup's updatedAt should be set or left as it comes
     */
    private void gatherPermissionChangesForUpdate(final AccessGroup accessGroup, final AccessGroup previous, final boolean updateModificationTime ) {

        final List<UUID> granted = new ArrayList<>(accessGroup.getEntityIds()); // clone
        granted.removeAll(previous.getEntityIds());

        final List<UUID> revoked = new ArrayList<>(previous.getEntityIds());
        if(accessGroup.getEntityIds()!=null){
            revoked.removeAll(accessGroup.getEntityIds());
        }
        final PermissionChanges permissionChanges = createPermissionChangesForAccessGroup(accessGroup);

        permissionChanges.setGrantedEntityIds(granted);
        permissionChanges.setRevokedEntityIds(revoked);

        gatherHierarchyChanges(accessGroup, previous, updateModificationTime);


        if (!granted.isEmpty() || !revoked.isEmpty()) {
            permissionChangesDAO.insert(permissionChanges);
        }
    }

    /**
     * Detects changes to the user's hierarchy and propagates them to the user's AccessGroups,
     * generating the PermissionChanges for the supervisors
     * @param accessGroup The AccessGroup to be verified
     * @param previous The previous version of the AccessGroup, retrieved from the database
     * @param updateModificationTime Specifies if AccessGroup's updatedAt should be set or left as it comes
     */
    private void gatherHierarchyChanges(final AccessGroup accessGroup, final AccessGroup previous, final boolean updateModificationTime) {
        // Update all groups when hierarchy changes on user,as it is the reference
        if(USER.equals(accessGroup.getGroupName()) &&
                !CollectionUtils.isEqualCollection(previous.getUserAndSuperiors(), accessGroup.getUserAndSuperiors())){
            final List<UUID> newSupervisors = new ArrayList<>(accessGroup.getUserAndSuperiors());
            newSupervisors.removeAll(previous.getUserAndSuperiors());

            final List<UUID> removedSupervisors = new ArrayList<>(previous.getUserAndSuperiors());
            removedSupervisors.removeAll(accessGroup.getUserAndSuperiors());

            final List<AccessGroup> userAccessGroups = accessGroupDAO.findByUserId(accessGroup.getUserId());

            for(final AccessGroup userAccessGroup: userAccessGroups) {
                userAccessGroup.setUserAndSuperiors(accessGroup.getUserAndSuperiors());
                accessGroupDAO.update(userAccessGroup, updateModificationTime);
            }

            final Map<String, AccessGroup> userAccessGroupsMap = userAccessGroups.stream()
                    .collect(Collectors.toMap(AccessGroup::getGroupName, Function.identity()));

            final List<AccessGroup> newSupervisorsAccessGroups = accessGroupDAO.findByUsersIds(newSupervisors);
            for (final AccessGroup supervisorAccessGroup: newSupervisorsAccessGroups) {
                // Create a permission change for each new supervisor, with all the subordinate's records as granted
                final PermissionChanges supervisorPermissionChanges = createPermissionChangesForAccessGroup(supervisorAccessGroup);
                final AccessGroup userAccessGroup = userAccessGroupsMap.get(supervisorAccessGroup.getGroupName());
                // The supervisor may have an access group that the subordinate does not have, like customer accounts ('customerByRegion')
                if(userAccessGroup == null) {
                    continue;
                }
                supervisorPermissionChanges.setGrantedEntityIds(userAccessGroup.getEntityIds());
                permissionChangesDAO.insert(supervisorPermissionChanges);
            }


            final List<AccessGroup> removedSupervisorsAccessGroups = accessGroupDAO.findByUsersIds(removedSupervisors);
            for (final AccessGroup supervisorAccessGroup: removedSupervisorsAccessGroups) {
                // Create a permission change for each new supervisor, with all the subordinate's records as revoked
                final PermissionChanges supervisorPermissionChanges = createPermissionChangesForAccessGroup(supervisorAccessGroup);
                final AccessGroup userAccessGroup = userAccessGroupsMap.get(supervisorAccessGroup.getGroupName());
                // The supervisor may have an access group that the subordinate does not have, like customer accounts ('customerByRegion')
                if(userAccessGroup == null) {
                    continue;
                }
                supervisorPermissionChanges.setRevokedEntityIds(userAccessGroup.getEntityIds());
                permissionChangesDAO.insert(supervisorPermissionChanges);
            }

        }
    }

    /**
     * Creates a {@link PermissionChanges} record based on the {@link AccessGroup} information,
     * with the same user, hierarchy and group name, letting the granted and revoked ids to be set afterwards.
     * @param accessGroup The {@link AccessGroup} to use as reference
     * @return The {@link PermissionChanges}
     */
    public PermissionChanges createPermissionChangesForAccessGroup(final AccessGroup accessGroup) {
        final PermissionChanges permissionChanges = new PermissionChanges();
        permissionChanges.setId(UUID.randomUUID());
        permissionChanges.setGroupName(accessGroup.getGroupName());
        permissionChanges.setUserId(accessGroup.getUserId());
        permissionChanges.setUserAndSuperiors(accessGroup.getUserAndSuperiors());
        permissionChanges.setVersion(1L);
        return permissionChanges;
    }

    /**
     * Delete an {@link AccessGroup} from the database.
     * @param id The id of the {@link AccessGroup} to be deleted
     * @throws Exception
     */
    public void delete(final UUID id) throws Exception {
        gatherPermissionChangesForDelete(id);
        accessGroupDAO.delete(id);
    }

    /**
     * Generates permission changes for deleted access groups
     *
     * @param id The updated AccessGroup
     */
    private void gatherPermissionChangesForDelete(final UUID id) {
        AccessGroup previous = accessGroupDAO.findById(id);

        List<UUID> revoked = new ArrayList<>(previous.getEntityIds());
        PermissionChanges permissionChanges = createPermissionChangesForAccessGroup(previous);
        permissionChanges.setRevokedEntityIds(revoked);
        if (!revoked.isEmpty()) {
            permissionChangesDAO.insert(permissionChanges);
        }
    }

    /**
     * Handles the generic actions received through Kafka.
     * The supported actionKeys are:
     * - ADD: Adds the entityIds to the existing record
     * - REMOVE: Removes the entityIds from the existing record
     *
     * @param record    The AccessGroup partially populated with only the id and the enityIds which changed
     * @param actionKey ADD or REMOVE
     */
    public void handleGenericAction(final AccessGroup record, final String actionKey) {
        switch (actionKey) {
            case ADD:
                accessGroupDAO.addIdsToGroup(record.getId(), record.getEntityIds());
                gatherPermissionChangesForGenericAction(record, actionKey);
                break;
            case REMOVE:
                accessGroupDAO.removeIdFromGroup(record.getId(), record.getEntityIds());
                break;
            default:
                throw new UnsupportedOperationException("Unsupported generic action for AccessGroup consumer: "+actionKey);
        }
    }

    /**
     * Stores changes received through generic action in the permission_changes table.
     *
     * @param record
     * @param actionKey
     */
    private void gatherPermissionChangesForGenericAction(final AccessGroup record, final String actionKey) {
        // The AccessGroup comes lika a patch, with only the changed values
        AccessGroup accessGroup = accessGroupDAO.findById(record.getId());
        PermissionChanges permissionChanges = createPermissionChangesForAccessGroup(accessGroup);

        switch (actionKey) {
            case ADD:
                permissionChanges.setGrantedEntityIds(record.getEntityIds());
                break;
            case REMOVE:
                permissionChanges.setRevokedEntityIds(record.getEntityIds());
                break;
            default:
                throw new UnsupportedOperationException("Unsupported generic action for AccessGroup consumer: "+actionKey);
        }
        permissionChangesDAO.insert(permissionChanges);
    }
}