package com.ws.sales.util.hateoas;

/**
 * Type is a HTTP Request GET, POST, PUT ....
 *
 * @author ademar.junior<ademar.junior @ wssim.com.br />
 * @since 7.1.0 2018-12-26
 */
public enum HateoasType {
    DELETE, GET, POST, PUT
}

