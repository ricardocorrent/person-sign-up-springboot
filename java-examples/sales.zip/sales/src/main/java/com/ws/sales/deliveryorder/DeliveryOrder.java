package com.ws.sales.deliveryorder;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.persistence.model.Views;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.order.SalesOrder;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;


/**
 * @author Samuel Blum Vorpagel <samuel.vorpagel@wssim.com.br>
 * @since v 2017-02-20
 */

@Entity
@PreventRecycling
public class DeliveryOrder extends PhysicalDeleteBaseEntity implements Serializable, DefaultPojoConverter {

    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    @PojoColumnFilter(value = {"id"})
    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "salesOrder.id", target = "order.id")
    })
    @NotNull
    private SalesOrder salesOrder;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate shipmentDate;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate deliveryDate;

    @PojoColumnMapper(target = "location.id")
    private UUID locationId;

    @PojoColumnMapper(target = "location.description")
    private String locationDescription;

    @Size(max = 4000)
    private String observation;

    @NotNull
    @PojoColumnMapper(target = "incoterms.id")
    private UUID incotermsId;

    @NotNull
    @PojoColumnMapper(target = "incoterms.acronym")
    @Enumerated(value = EnumType.STRING)
    private IncotermsAcronym incotermsAcronym;

    @Column(precision = 18, scale = 6)
    private BigDecimal freightValue;

    /**
     * Get of property {@link #salesOrder}
     *
     * @return com.ws.sales.order.SalesOrder
     */
    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    /**
     * Set of property {@link #salesOrder}
     *
     * @param salesOrder field to set
     */
    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    /**
     * Get of property {@link #shipmentDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getShipmentDate() {
        return shipmentDate;
    }

    /**
     * Set of property {@link #shipmentDate}
     *
     * @param shipmentDate field to set
     */
    public void setShipmentDate(final LocalDate shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    /**
     * Get of property {@link #deliveryDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Set of property {@link #deliveryDate}
     *
     * @param deliveryDate field to set
     */
    public void setDeliveryDate(final LocalDate deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    /**
     * Get of property {@link #locationId}
     *
     * @return java.util.UUID
     */
    public UUID getLocationId() {
        return locationId;
    }

    /**
     * Set of property {@link #locationId}
     *
     * @param locationId field to set
     */
    public void setLocationId(final UUID locationId) {
        this.locationId = locationId;
    }

    /**
     * Get of property {@link #locationDescription}
     *
     * @return java.lang.String
     */
    public String getLocationDescription() {
        return locationDescription;
    }

    /**
     * Set of property {@link #locationDescription}
     *
     * @param locationDescription field to set
     */
    public void setLocationDescription(final String locationDescription) {
        this.locationDescription = locationDescription;
    }

    /**
     * Get of property {@link #observation}
     *
     * @return java.lang.String
     */
    public String getObservation() {
        return observation;
    }

    /**
     * Set of property {@link #observation}
     *
     * @param observation field to set
     */
    public void setObservation(final String observation) {
        this.observation = observation;
    }

    /**
     * Get of property {@link #incotermsId}
     *
     * @return java.util.UUID
     */
    public UUID getIncotermsId() {
        return incotermsId;
    }

    /**
     * Set of property {@link #incotermsId}
     *
     * @param incotermsId field to set
     */
    public void setIncotermsId(final UUID incotermsId) {
        this.incotermsId = incotermsId;
    }

    /**
     * Get of property {@link #incotermsAcronym}
     *
     * @return com.ws.sales.external.commondata.IncotermsAcronym
     */
    public IncotermsAcronym getIncotermsAcronym() {
        return incotermsAcronym;
    }

    /**
     * Set of property {@link #incotermsAcronym}
     *
     * @param incotermsAcronym field to set
     */
    public void setIncotermsAcronym(final IncotermsAcronym incotermsAcronym) {
        this.incotermsAcronym = incotermsAcronym;
    }

    /**
     * Get of property {@link #freightValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getFreightValue() {
        return freightValue;
    }

    /**
     * Set of property {@link #freightValue}
     *
     * @param freightValue field to set
     */
    public void setFreightValue(final BigDecimal freightValue) {
        this.freightValue = freightValue;
    }
}
