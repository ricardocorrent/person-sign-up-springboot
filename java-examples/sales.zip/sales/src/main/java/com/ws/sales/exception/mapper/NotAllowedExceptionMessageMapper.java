package com.ws.sales.exception.mapper;

import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messagebundle.MessageBundle;
import com.ws.commons.server.validation.CustomModelValidation;
import com.ws.sales.exception.NotAllowedExceptionMessage;
import org.apache.http.HttpStatus;
import org.codehaus.jackson.map.ObjectMapper;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import java.io.IOException;
import java.io.StringWriter;

/**
 * @author Frank Pilloni Tominc <frank.tominc@wssim.com.br>]
 * @since 19/03/18
 */
public class NotAllowedExceptionMessageMapper implements ExceptionMapper<NotAllowedExceptionMessage> {

    private final MessageBundle bundle;
    @Context
    private HttpServletRequest request;

    @Inject
    public NotAllowedExceptionMessageMapper(final MessageBundle bundle) {
        this.bundle = bundle;
    }

    @Override
    public Response toResponse(final NotAllowedExceptionMessage exception) {
        final StringWriter writer = new StringWriter();
        final ObjectMapper mapper = new ObjectMapper();
        final ExceptionMessage message = this.bundle.getMessage(exception.getMessage(), this.request.getLocale());
        try {

            final CustomModelValidation viewMessage = new CustomModelValidation(bundle);
            viewMessage.setText(message.getMessage());
            mapper.writeValue(writer, viewMessage);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return Response.status(HttpStatus.SC_METHOD_NOT_ALLOWED)
                .type(MediaType.APPLICATION_JSON)
                .entity(message)
                .allow(exception.getAllowed())
                .build();
    }

}