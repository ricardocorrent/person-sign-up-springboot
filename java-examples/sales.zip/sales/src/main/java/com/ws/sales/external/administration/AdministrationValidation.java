package com.ws.sales.external.administration;

import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import com.ws.administration.model.Company;
import com.ws.administration.model.Currency;
import com.ws.administration.model.ExchangeRate;
import com.ws.administration.model.MeasurementUnit;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.util.Constants;

/**
 * @author Maykon Roberto Rissi
 * @since 6.1.0 - 2018-08-20
 */
public class AdministrationValidation {

    private final AdministrationGateway administrationGateway;

    @Inject
    public AdministrationValidation(final AdministrationGateway administrationGateway) {
        this.administrationGateway = administrationGateway;
    }

    /**
     * gets the company and validate if it exists and is active.
     * This method can receive an fieldName to handle the error. If not, it will use the default from {@link Constants}
     *
     * @param entityId  to load entity and validate
     * @param fieldName to set the error
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Roberto Rissi
     * @since 6.1.0 2018-08-20
     */
    public LogicError doValidateCompanyCanBeUsed(final UUID entityId, final String fieldName) {
        final String nameForTheField = Optional.ofNullable(fieldName).orElse(Constants.FIELD_COMPANY_ID);
        return Optional.ofNullable(entityId).map(id -> {
            final Company entity = administrationGateway.getCompany(id);
            if (entity == null) {
                return new LogicError(nameForTheField, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!entity.isActive()) {
                return new LogicError(nameForTheField, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * @param entityId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Roberto Rissi
     * @since 6.1.0 2018-08-20
     */
    public LogicError doValidateCurrencyCanBeUsed(final UUID entityId) {
        return Optional.ofNullable(entityId).map(id -> {
            final Currency entity = administrationGateway.getCurrency(id);
            if (entity == null) {
                return new LogicError(Constants.FIELD_CURRENCY_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!entity.isActive()) {
                return new LogicError(Constants.FIELD_CURRENCY_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * @param entityId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Roberto Rissi
     * @since 6.1.0 2018-08-20
     */
    public LogicError doValidateMeasurementUnitCanBeUsed(final UUID entityId) {
        return Optional.ofNullable(entityId).map(id -> {
            final MeasurementUnit entity = administrationGateway.getMeasurementUnit(id);
            if (entity == null) {
                return new LogicError(Constants.FIELD_MEASUREMENT_UNIT_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!entity.isActive()) {
                return new LogicError(Constants.FIELD_MEASUREMENT_UNIT_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * @param entityId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Roberto Rissi
     * @since 6.1.0 2018-08-20
     */
    public LogicError doValidateExchangeRateCanBeUsed(final UUID entityId) {
        return Optional.ofNullable(entityId).map(id -> {
            final ExchangeRate entity = administrationGateway.getExchangeRate(id);
            if (entity == null) {
                return new LogicError(Constants.FIELD_CURRENCY_QUOTATION_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the location does not belong to the customer. It must have these 2 params, or it will return null
     *
     * @param currencyId     to load entity and validate
     * @param exchangeRateId to load entity and validate
     * @return {@link LogicError} if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since 6.1.0 2018-08-20
     */
    public LogicError doValidateExchangeRateBelongsToCurrency(final UUID currencyId, final UUID exchangeRateId) {
        if (currencyId != null && exchangeRateId != null) {
            final ExchangeRate exchangeRate = administrationGateway.getExchangeRate(exchangeRateId);
            final Boolean exchangeRateBelongsToCurrency = exchangeRate.getCurrency().getId().equals(currencyId.toString());
            return exchangeRateBelongsToCurrency ? null : new LogicError(Constants.FIELD_CURRENCY_QUOTATION_ID, Constants.MESSAGE_QUOTATION_DOES_NOT_BELONG_TO_CURRENCY);
        }
        return null;
    }
}
