package com.ws.sales.exception;

/**
 * @author Frank Pilloni Tominc <frank.tominc@wssim.com.br>
 * @since 22/03/18
 * @deprecated use {@link com.ws.commons.server.validation.exception.NotAllowedException}
 */
@Deprecated
public class NotAllowedExceptionMessage extends RuntimeException {

    private final String[] allowed;

    private final String message;

    /**
     * @param messageTemplate: The key to the i18n message
     * @param allowed:         A List with all the allowed methods in the requested resource
     */
    public NotAllowedExceptionMessage(final String messageTemplate, final String... allowed) {
        super(messageTemplate);
        this.allowed = allowed;
        this.message = messageTemplate;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public String[] getAllowed() {
        return allowed;
    }
}
