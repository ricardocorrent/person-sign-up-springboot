package com.ws.sales.order.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.situation.SituationDTO;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * This DTO serves for a verification of fields that come via json
 * to carry out the updates of an already finished sales order.
 *
 * @since 8.3.0 2019-05-29
 * @author Diogo Melo
 */
public class OrderFinishedDTO implements DefaultPojoConverter, Serializable {

    private OffsetDateTime exportedAt;

    private String externalId;

    private String externalNumber;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "situation.id", target = "situationId"),
            @PojoColumnMapper(source = "situation.description", target = "situationDescription")
    })
    private SituationDTO situation;

    public OffsetDateTime getExportedAt() {
        return exportedAt;
    }

    public void setExportedAt(final OffsetDateTime exportedAt) {
        this.exportedAt = exportedAt;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    public String getExternalNumber() {
        return externalNumber;
    }

    public void setExternalNumber(final String externalNumber) {
        this.externalNumber = externalNumber;
    }

    public SituationDTO getSituation() {
        return situation;
    }

    public void setSituation(final SituationDTO situation) {
        this.situation = situation;
    }

}
