package com.ws.sales.order;

import com.ws.sales.deliveryorder.DeliveryOrder;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.ordersituation.SalesOrderSituation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * @author Frank Pilloni Tominc <frank.tominc@wssim.com.br>
 * @since 09/04/18
 */
public final class SalesOrderBuilder {
    final private SalesOrder salesOrder;

    private SalesOrderBuilder() {
        salesOrder = new SalesOrder();
    }

    public static SalesOrderBuilder aSalesOrder() {
        return new SalesOrderBuilder();
    }

    public SalesOrderBuilder withPriceListId(final UUID priceListId) {
        salesOrder.setPriceListId(priceListId);
        return this;
    }

    public SalesOrderBuilder withPriceListDescription(final String priceListDescription) {
        salesOrder.setPriceListDescription(priceListDescription);
        return this;
    }

    public SalesOrderBuilder withPaymentTermId(final UUID paymentTermId) {
        salesOrder.setPaymentTermId(paymentTermId);
        return this;
    }

    public SalesOrderBuilder withPaymentTermDescription(final String paymentTermDescription) {
        salesOrder.setPaymentTermDescription(paymentTermDescription);
        return this;
    }

    public SalesOrderBuilder withOrderTypeId(final UUID orderTypeId) {
        salesOrder.setOrderTypeId(orderTypeId);
        return this;
    }

    public SalesOrderBuilder withOrderTypeDescription(final String orderTypeDescription) {
        salesOrder.setOrderTypeDescription(orderTypeDescription);
        return this;
    }

    public SalesOrderBuilder withPaymentMethodId(final UUID paymentMethodId) {
        salesOrder.setPaymentMethodId(paymentMethodId);
        return this;
    }

    public SalesOrderBuilder withPaymentMethodDescription(final String paymentMethodDescription) {
        salesOrder.setPaymentMethodDescription(paymentMethodDescription);
        return this;
    }

    public SalesOrderBuilder withUserId(final UUID userId) {
        salesOrder.setUserId(userId);
        return this;
    }

    public SalesOrderBuilder withUserName(final String userName) {
        salesOrder.setUserName(userName);
        return this;
    }

    public SalesOrderBuilder withCompanyId(final UUID companyId) {
        salesOrder.setCompanyId(companyId);
        return this;
    }

    public SalesOrderBuilder withCompanyName(final String companyName) {
        salesOrder.setCompanyName(companyName);
        return this;
    }

    public SalesOrderBuilder withCustomerId(final UUID customerId) {
        salesOrder.setCustomerId(customerId);
        return this;
    }

    public SalesOrderBuilder withCustomerImageId(final UUID customerImageId) {
        salesOrder.setCustomerImageId(customerImageId);
        return this;
    }

    public SalesOrderBuilder withCustomerName(final String customerName) {
        salesOrder.setCustomerName(customerName);
        return this;
    }

    public SalesOrderBuilder withLocationId(final UUID locationId) {
        salesOrder.setLocationId(locationId);
        return this;
    }

    public SalesOrderBuilder withLocationDescription(final String locationDescription) {
        salesOrder.setLocationDescription(locationDescription);
        return this;
    }

    public SalesOrderBuilder withLocationAddress(final String locationAddress) {
        salesOrder.setLocationAddress(locationAddress);
        return this;
    }

    public SalesOrderBuilder withDraft(final Boolean draft) {
        salesOrder.setDraft(draft);
        return this;
    }

    public SalesOrderBuilder withOrderNumber(final String orderNumber) {
        salesOrder.setOrderNumber(orderNumber);
        return this;
    }

    public SalesOrderBuilder withExternalNumber(final String externalNumber) {
        salesOrder.setExternalNumber(externalNumber);
        return this;
    }

    public SalesOrderBuilder withCustomerNumber(final String customerNumber) {
        salesOrder.setCustomerNumber(customerNumber);
        return this;
    }

    public SalesOrderBuilder withInvoiceNotes(final String invoiceNotes) {
        salesOrder.setInvoiceNotes(invoiceNotes);
        return this;
    }

    public SalesOrderBuilder withOrderNotes(final String orderNotes) {
        salesOrder.setOrderNotes(orderNotes);
        return this;
    }

    public SalesOrderBuilder withCurrency(final String currency) {
        salesOrder.setCurrency(currency);
        return this;
    }

    public SalesOrderBuilder withOrderCurrency(final OrderCurrency orderCurrency) {
        salesOrder.setOrderCurrency(orderCurrency);
        return this;
    }

    public SalesOrderBuilder withOrderedAt(final OffsetDateTime orderedAt) {
        salesOrder.setOrderedAt(orderedAt);
        return this;
    }

    public SalesOrderBuilder withInvoicedAt(final OffsetDateTime invoicedAt) {
        salesOrder.setInvoicedAt(invoicedAt);
        return this;
    }

    public SalesOrderBuilder withTransmitedAt(final OffsetDateTime transmitedAt) {
        salesOrder.setTransmitedAt(transmitedAt);
        return this;
    }

    public SalesOrderBuilder withExportedAt(final OffsetDateTime exportedAt) {
        salesOrder.setExportedAt(exportedAt);
        return this;
    }

    public SalesOrderBuilder withGrossValue(final BigDecimal grossValue) {
        salesOrder.setGrossValue(grossValue);
        return this;
    }

    public SalesOrderBuilder withNetValue(final BigDecimal netValue) {
        salesOrder.setNetValue(netValue);
        return this;
    }

    public SalesOrderBuilder withQuantity(final BigDecimal quantity) {
        salesOrder.setQuantity(quantity);
        return this;
    }

    public SalesOrderBuilder withInvoicedValue(final BigDecimal invoicedValue) {
        salesOrder.setInvoicedValue(invoicedValue);
        return this;
    }

    public SalesOrderBuilder withInvoicedQuantity(final BigDecimal invoicedQuantity) {
        salesOrder.setInvoicedQuantity(invoicedQuantity);
        return this;
    }

    public SalesOrderBuilder withItems(final List<SalesOrderItem> items) {
        salesOrder.setItems(items);
        return this;
    }
    public SalesOrderBuilder withServices(final List<com.ws.sales.orderservice.SalesOrderService> items) {
        salesOrder.setServices(items);
        return this;
    }

    public SalesOrderBuilder withItemsQuantity(final Integer itemsQuantity) {
        salesOrder.setItemsQuantity(itemsQuantity);
        return this;
    }

    public SalesOrderBuilder withSalesOrderSituations(final List<SalesOrderSituation> salesOrderSituations) {
        salesOrder.setSalesOrderSituations(salesOrderSituations);
        return this;
    }

    public SalesOrderBuilder withSituationId(final UUID situationId) {
        salesOrder.setSituationId(situationId);
        return this;
    }

    public SalesOrderBuilder withDueDate(final LocalDate dueDate) {
        salesOrder.setDueDate(dueDate);
        return this;
    }

    public SalesOrderBuilder withSituationDescription(final String situationDescription) {
        salesOrder.setSituationDescription(situationDescription);
        return this;
    }

    public SalesOrderBuilder withDeliveryOrders(final List<DeliveryOrder> deliveryOrders) {
        salesOrder.setDeliveryOrders(deliveryOrders);
        return this;
    }

    public SalesOrderBuilder withOrigin(final String origin) {
        salesOrder.setOrigin(origin);
        return this;
    }

    public SalesOrderBuilder withComplement(final String complement) {
        salesOrder.setComplement(complement);
        return this;
    }

    public SalesOrderBuilder withUserProfessionalId(final UUID userProfessionalId) {
        salesOrder.setUserProfessionalId(userProfessionalId);
        return this;
    }

    public SalesOrderBuilder withUserProfessionalName(final String userProfessionalName) {
        salesOrder.setUserProfessionalName(userProfessionalName);
        return this;
    }

    public SalesOrderBuilder withSignatureId(final UUID signatureId) {
        salesOrder.setSignatureId(signatureId);
        return this;
    }

    public SalesOrderBuilder withInitialCreditLimit(final BigDecimal initialCreditLimit) {
        salesOrder.setInitialCreditLimit(initialCreditLimit);
        return this;
    }

    public SalesOrderBuilder withId(final UUID id) {
        salesOrder.setId(id);
        return this;
    }

    public SalesOrderBuilder withCreatedAt(final OffsetDateTime createdAt) {
        salesOrder.setCreatedAt(createdAt);
        return this;
    }

    public SalesOrderBuilder withInsertedAt(final OffsetDateTime insertedAt) {
        salesOrder.setInsertedAt(insertedAt);
        return this;
    }

    public SalesOrderBuilder withUpdatedAt(final OffsetDateTime updatedAt) {
        salesOrder.setUpdatedAt(updatedAt);
        return this;
    }

    public SalesOrderBuilder withExternalId(final String externalId) {
        salesOrder.setExternalId(externalId);
        return this;
    }

    public SalesOrder build() {
        return salesOrder;
    }
}
