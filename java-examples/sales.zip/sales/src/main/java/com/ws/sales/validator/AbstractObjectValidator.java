package com.ws.sales.validator;

import com.ws.commons.server.validation.entityvalidator.IValidationFilter;

import java.util.Objects;

public abstract class AbstractObjectValidator<T extends Object> extends AbstractObjectValidatorEngine<T> {

    /**
     * @param object to be validated.
     * @param filter to perform isolated validations.
     */
    @SuppressWarnings("unchecked")
    public void validate(final T object, final IValidationFilter... filter) {
        Objects.requireNonNull(object, "The entity parameter cannot be null.");

        validateByBeanValidation(object, null);
    }
}
