package com.ws.sales.order.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

import java.math.BigDecimal;

/**
 * @author marcos.andrade
 * @since 08/12/2017
 */
public class OrderSummaryItemsDTO extends BaseDTO implements DefaultPojoConverter {

    private BigDecimal quantity;

    @PojoColumnMapper(target = "discount")
    private BigDecimal discountValue;

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getDiscountValue() {
        return discountValue;
    }

    public void setDiscountValue(BigDecimal discountValue) {
        this.discountValue = discountValue;
    }
}
