package com.ws.sales.invoicetypeitem;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * This class represents the persistence layer of Invoice Type Item, with she it's possible make methods to
 * interact with the database.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class InvoiceTypeItemDAO extends AbstractDAO<InvoiceTypeItem> {

    /**
     * This method override the getEntityClass for InvoiceTypeItem.
     *
     * @return invoice type item
     */
    @Override
    public Class getEntityClass() {
        return InvoiceTypeItem.class;
    }

    /**
     * Method to search a list of Invoice Type Item by filter.
     *
     * @param invoiceTypeItemSearch the invoice type item search contains filters to apply on where clause
     * @return a paged list of invoice type item
     */
    public PagedList<InvoiceTypeItem> search(final InvoiceTypeItemSearch invoiceTypeItemSearch) {

        final Query<InvoiceTypeItem> query = find();
        ExpressionList<InvoiceTypeItem> where = query.where();

        addIdCondition(invoiceTypeItemSearch, where);

        addDescriptionCondition(invoiceTypeItemSearch, where);

        addActiveCondition(invoiceTypeItemSearch, where);

        return getPagedList(query, invoiceTypeItemSearch);
    }

    /**
     * This method add the id condition for the where clause.
     *
     * @param invoiceTypeItemSearch the invoice type item search contains filters to apply on where clause
     * @param where                 where for search
     */
    private void addIdCondition(final InvoiceTypeItemSearch invoiceTypeItemSearch, ExpressionList<InvoiceTypeItem> where) {

        if (invoiceTypeItemSearch.getId() != null) {
            where.eq("id", invoiceTypeItemSearch.getId());
        }
    }

    /**
     * This method add the description condition for the where clause.
     *
     * @param invoiceTypeItemSearch the invoice type item search contains filters to apply on where clause
     * @param where                 where for search
     */
    private void addDescriptionCondition(final InvoiceTypeItemSearch invoiceTypeItemSearch, ExpressionList<InvoiceTypeItem> where) {

        if (!StringUtils.isEmpty(invoiceTypeItemSearch.getDescription())) {
            where.icontains("description", invoiceTypeItemSearch.getDescription());
        }
    }

    /**
     * This method add the active condition for the where clause.
     *
     * @param invoiceTypeItemSearch the invoice type item search contains filters to apply on where clause
     * @param where                 where for search
     */
    private void addActiveCondition(final InvoiceTypeItemSearch invoiceTypeItemSearch, ExpressionList<InvoiceTypeItem> where) {

        if (invoiceTypeItemSearch.getActive() != null) {
            where.eq("active", invoiceTypeItemSearch.getActive());
        }
    }

    /**
     * Returns true if the Invoice Type item exists or false if not.
     *
     * @param id invoice type item
     * @return true if invoice type item exists and false if not
     */
    public Boolean invoiceTypeItemExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }
}