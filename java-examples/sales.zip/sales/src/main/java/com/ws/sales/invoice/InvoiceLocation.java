package com.ws.sales.invoice;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.UUID;

/**
 * This class represents the entity Invoice Location.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
@Entity
public class InvoiceLocation extends SoftDeleteBaseEntity implements Serializable {

    /**
     * This field represents the replicated id for the InvoiceLocation. It represents the id from Location.
     */
    @NotNull
    private UUID replicatedId;

    /**
     * This field represents the description for the InvoiceLocation.
     */
    @Size(max = 255)
    private String description;

    /**
     * This field represents the relationship of InvoiceLocation with Invoice.
     */
    @OneToOne
    @JoinColumn(name = "invoice_id")
    @JsonIgnore
    private Invoice invoice;

    /**
     * Gets replicated id.
     *
     * @return the replicated id
     */
    public UUID getReplicatedId() {
        return replicatedId;
    }

    /**
     * Sets replicated id.
     *
     * @param replicatedId the replicated id
     */
    public void setReplicatedId(UUID replicatedId) {
        this.replicatedId = replicatedId;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets invoice.
     *
     * @return the invoice
     */
    public Invoice getInvoice() {
        return invoice;
    }

    /**
     * Sets invoice.
     *
     * @param invoice the invoice
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
