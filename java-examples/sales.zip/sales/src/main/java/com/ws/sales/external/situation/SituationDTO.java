package com.ws.sales.external.situation;

import java.util.UUID;

/**
 * @author Ademar Junior<ademar.junior@wssin.com.br/>
 * @since 7.1.0 2018-12-26.
 */
public class SituationDTO {

    private UUID id;

    private String description;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}
