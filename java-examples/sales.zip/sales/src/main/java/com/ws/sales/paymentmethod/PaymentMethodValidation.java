package com.ws.sales.paymentmethod;

import java.util.Collections;
import java.util.Optional;

import javax.inject.Inject;

import com.ws.commons.server.validation.beanvalidation.integration.BeanValidationIntegrated;
import com.ws.commons.server.validation.logicvalidation.LogicValidator;
import com.ws.commons.server.validation.logicvalidation.Valid;
import com.ws.commons.server.validation.logicvalidation.ValidObject;

/**
 * validation of {@link PaymentMethod}
 * 
 * @author william.santos
 * @since V6.1.0 - 2018-08-28
 * @version 1.0.0
 */
@BeanValidationIntegrated(PaymentMethod.class)
public class PaymentMethodValidation extends LogicValidator<PaymentMethod> {

    private final PaymentMethodDAO dao;
    
    @Inject
    public PaymentMethodValidation(final PaymentMethodDAO dao) {
        this.dao = dao;
    }

    /**
     * @return {@code true} when there isn't a standard record (or is an edition of it), or {@code false} otherwise
     * @author william.santos
     * @since V6.1.0 - 2018-08-28
     * @version 1.0.0
     */
    @Valid(field = "standard", message = "sales.paymentMethod.standard.unique.validation")
    public ValidObject validHasStandard(final PaymentMethod paymentMethod) {
        final ValidObject valid = new ValidObject();
        valid.setValid(true);
        Optional.ofNullable(paymentMethod)
                .filter(payment -> null != payment.getStandard())
                .filter(payment -> Boolean.TRUE.equals(payment.getStandard()))
                .ifPresent(payment -> {
                    Optional.ofNullable(this.dao.getStandard())
                            .filter(standard -> !standard.getId().equals(payment.getId()))
                            .ifPresent(standard -> {
                                valid.setValid(false);
                                valid.setParams(Collections.singletonMap("paymentMethod", standard.getDescription()));
                            });
                });
        return valid;
    }

}
