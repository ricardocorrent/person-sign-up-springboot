package com.ws.sales.deliveryorder;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.commondata.CommonDataValidation;
import com.ws.sales.external.customer.CustomerValidation;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.GenericValidator;
import org.apache.commons.collections4.CollectionUtils;

import javax.enterprise.inject.Default;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.0.0 2018-08-10
 */
@Default
public class DeliveryOrderValidation extends AbstractEntityValidator<DeliveryOrder> {

    private final CustomerValidation customerValidation;
    private final CommonDataValidation commonDataValidation;
    private final SalesOrderValidator salesOrderValidator;
    private final SalesOrderDAO salesOrderDAO;
    private final DeliveryOrderDAO deliveryOrderDAO;

    /**
     * @param customerValidation   to handle customer validations
     * @param commonDataValidation to handle commonData validations
     * @param salesOrderValidator  to handle order validations
     * @param salesOrderDAO        to load the order
     * @param deliveryOrderDAO     to load deliveries
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-10
     */
    @Inject
    public DeliveryOrderValidation(final CustomerValidation customerValidation,
                                   final CommonDataValidation commonDataValidation,
                                   final SalesOrderValidator salesOrderValidator,
                                   final SalesOrderDAO salesOrderDAO,
                                   final DeliveryOrderDAO deliveryOrderDAO) {
        this.customerValidation = customerValidation;
        this.commonDataValidation = commonDataValidation;
        this.salesOrderValidator = salesOrderValidator;
        this.salesOrderDAO = salesOrderDAO;
        this.deliveryOrderDAO = deliveryOrderDAO;
    }

    /**
     * @param deliveryDate {@link LocalDate} first date to compare
     * @param shipmentDate {@link LocalDate} second date to compare
     * @return {@link LogicError} if the delivery date is lower than the shipment date
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-10
     */
    public LogicError doValidateIfDeliveryDateIsLowerThanShipmentDate(final LocalDate deliveryDate, final LocalDate shipmentDate) {
        if (deliveryDate != null && shipmentDate != null) {
            return shipmentDate.isAfter(deliveryDate) ? new LogicError(Constants.FIELD_DELIVERY_DATE, Constants.MESSAGE_DELIVERY_DATE_INCORRECT) : null;
        }
        return null;
    }

    /**
     * @param salesOrderId to load deliveries by order
     * @return {@link LogicError} if the order has a delivery
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfTheOrderHasADelivery(final UUID salesOrderId) {
        final DeliveryOrderSearch search = this.doFillSearchWithOrderId(salesOrderId);
        final PagedList<DeliveryOrder> deliveries = this.deliveryOrderDAO.search(search);
        return Optional.ofNullable(deliveries)
                .map(PagedList::getItems)
                .filter(CollectionUtils::isNotEmpty)
                .map(list -> new LogicError(Constants.FIELD_DELIVERY_ORDER, Constants.MESSAGE_ORDER_ALREADY_WITH_DELIVERY))
                .orElse(null);
    }

    /**
     * @param salesOrderId to set the {@link DeliveryOrderSearch}
     * @return {@link LogicError} if the delivery date is lower than the shipment date
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-10
     */
    private DeliveryOrderSearch doFillSearchWithOrderId(final UUID salesOrderId) {
        final DeliveryOrderSearch deliveryOrderSearch = new DeliveryOrderSearch();
        deliveryOrderSearch.setOrderId(salesOrderId);
        return deliveryOrderSearch;
    }

    /**
     * Linked validations for incoterms using {@link GenericValidator}
     *
     * @param deliveryOrder to get the fields and validate
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doValidateIncoterms(final DeliveryOrder deliveryOrder) {
        final List<LogicError> errorsFromIncoterms = new LinkedList<>();
        GenericValidator.applyValidator(this.commonDataValidation::doValidateIncotermsCanBeUsed, deliveryOrder.getIncotermsId(), errorsFromIncoterms);
        GenericValidator.applyValidator(this.commonDataValidation::doValidateFreightValueCif, deliveryOrder.getIncotermsAcronym(), deliveryOrder.getFreightValue(), errorsFromIncoterms);
        GenericValidator.applyValidator(this.commonDataValidation::doValidateFreightValueFob, deliveryOrder.getIncotermsAcronym(), deliveryOrder.getFreightValue(), errorsFromIncoterms);
        errorsFromIncoterms.forEach(error -> this.addError(error, deliveryOrder));
    }

    /**
     * Linked validations for location using {@link GenericValidator}
     *
     * @param deliveryOrder to get the fields and validate
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doValidateLocation(final DeliveryOrder deliveryOrder, final SalesOrder salesOrder) {
        final List<LogicError> errorsFromCustomer = new LinkedList<>();
        GenericValidator.applyValidator(this.customerValidation::doValidateLocationCanBeUsed, deliveryOrder.getLocationId(), errorsFromCustomer);
        GenericValidator.applyValidator(this.customerValidation::doValidateLocationBelongsToCustomer, deliveryOrder.getLocationId(), salesOrder.getCustomerId(), errorsFromCustomer);
        errorsFromCustomer.forEach(error -> this.addError(error, deliveryOrder));
    }

    /**
     * Linked validations for location using {@link GenericValidator}
     *
     * @param deliveryOrder to get the fields and validate
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doValidateOrder(final DeliveryOrder deliveryOrder, final SalesOrder salesOrder) {
        final List<LogicError> errorsFromOrder = new LinkedList<>();
        GenericValidator.applyValidator(this.salesOrderValidator::doValidateIfOrderCanBeEdited, salesOrder, Boolean.FALSE, errorsFromOrder);
        GenericValidator.applyValidator(this::doValidateIfTheOrderHasADelivery, salesOrder.getId(), errorsFromOrder);
        errorsFromOrder.forEach(error -> this.addError(error, deliveryOrder));
    }

    /**
     * @author Maykon Rissi
     * @see AbstractEntityValidator#addError(LogicError, BaseModel)
     * @since v6.0.0 2018-08-13
     */
    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        Optional.ofNullable(logicError).ifPresent(error -> super.addError(error, entity));
    }

    /**
     * Handles the validations that must trigger only during the insert operation
     *
     * @param entity     to validate
     * @param salesOrder to get order data
     * @param filter     to check the operation
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doHandleValidationsOnlyForInsert(final DeliveryOrder entity, final SalesOrder salesOrder, final IValidationFilter... filter) {
        if (org.apache.commons.lang3.ArrayUtils.contains(filter, EValidationType.INSERT)) {
            this.doValidateIncoterms(entity);
            this.doValidateLocation(entity, salesOrder);
            this.doValidateOrder(entity, salesOrder);
            this.addError(this.doValidateIfDeliveryDateIsLowerThanShipmentDate(entity.getDeliveryDate(), entity.getShipmentDate()), entity);
        }
    }

    /**
     * Handles the validations that must trigger only during the update operation
     *
     * @param entity     to validate
     * @param salesOrder to get order data
     * @param filter     to check the operation
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doHandleValidationsOnlyForUpdate(final DeliveryOrder entity, final SalesOrder salesOrder, final IValidationFilter... filter) {
        if (org.apache.commons.lang3.ArrayUtils.contains(filter, EValidationType.UPDATE)) {
            this.doValidateIncoterms(entity);
            this.doValidateLocation(entity, salesOrder);
            this.addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE), entity);
            this.addError(this.doValidateIfDeliveryDateIsLowerThanShipmentDate(entity.getDeliveryDate(), entity.getShipmentDate()), entity);
        }
    }

    /**
     * Handles the validations that must trigger only during the delete operation
     *
     * @param entity     to validate
     * @param filter     to check the operation
     * @param salesOrder to get order data
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    private void doHandleValidationsOnlyForDelete(final DeliveryOrder entity, final SalesOrder salesOrder, final IValidationFilter... filter) {
        if (org.apache.commons.lang3.ArrayUtils.contains(filter, EValidationType.DELETE)) {
            this.addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE), entity);
        }
    }

    /**
     * @author Maykon Rissi
     * @see AbstractEntityValidator#validate(BaseModel, IValidationFilter...)
     * @since v6.0.0 2018-08-13
     */
    @Override
    protected void validate(final DeliveryOrder entity, final IValidationFilter... filter) {
        final SalesOrder salesOrder = this.salesOrderDAO.findById(entity.getSalesOrder().getId());
        this.doHandleValidationsOnlyForInsert(entity, salesOrder, filter);
        this.doHandleValidationsOnlyForUpdate(entity, salesOrder, filter);
        this.doHandleValidationsOnlyForDelete(entity, salesOrder, filter);
    }
}
