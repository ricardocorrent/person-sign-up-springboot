package com.ws.sales.external.financial;

import com.ws.commons.server.validation.exception.MessageException;
import com.ws.financial.model.CreditLimit;
import com.ws.financial.model.CreditLimitMovement;
import com.ws.financial.model.CreditLimitSearch;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.orderparameter.OrderParameterService;
import org.apache.http.HttpStatus;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 * @author Maykon Rissi
 * @since v6.1.0 2018-08-18.
 */
public class FinancialService {

    private final FinancialGateway financialGateway;
    private final OrderParameterService orderParameterService;

    /**
     * @param financialGateway      to make request between sales and financial
     * @param orderParameterService to load parameters
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    @Inject
    public FinancialService(final FinancialGateway financialGateway,
                            final OrderParameterService orderParameterService) {
        this.financialGateway = financialGateway;
        this.orderParameterService = orderParameterService;
    }

    /**
     * It will check if the credit limit is enabled, then it will search for the customer credit limit an generate de movement
     * If the movement could not be created, it will throw a {@link MessageException}
     *
     * @param orderToFinalize to get the data and fill the search for credit limit and the value
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    public void updateCreditLimit(final SalesOrder orderToFinalize) {
        Objects.requireNonNull(orderToFinalize);
        if (this.isCreditLimitPluginEnabled()) {
            final CreditLimit creditLimit = this.getCreditLimitFromOrder(orderToFinalize);
            final CreditLimitMovement creditLimitMovement = this.doGenerateCreditLimitMovement(orderToFinalize, creditLimit);
            final Response response = financialGateway.insertCreditLimitMovement(creditLimitMovement);
            this.doCheckReturnOfCreditLimitMovement(response);
        }
    }

    /**
     * @return {@link Boolean#TRUE} if the credit limit plugin is enabled
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    public Boolean isCreditLimitPluginEnabled() {
        return Boolean.valueOf(orderParameterService.searchByKey(Constants.FIELD_PARAMETER_CREDIT_REQUIRED).getValue());
    }

    /**
     * @param orderToFinalize to fill the search
     * @return {@link CreditLimit} from the customer
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    public CreditLimit getCreditLimitFromOrder(final SalesOrder orderToFinalize) {
        final CreditLimitSearch creditLimitSearch = this.doGenerateCreditLimitSearch(orderToFinalize);
        final List<CreditLimit> creditLimits = financialGateway.searchCreditLimit(creditLimitSearch);
        return creditLimits.stream().findFirst().orElse(null);
    }

    /**
     * @param orderToFinalize to fill the search
     * @return {@link CreditLimitSearch}
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    private CreditLimitSearch doGenerateCreditLimitSearch(final SalesOrder orderToFinalize) {
        final CreditLimitSearch creditLimitSearch = new CreditLimitSearch();
        creditLimitSearch.setCustomerId(orderToFinalize.getCustomerId().toString());
        creditLimitSearch.setLocationId(orderToFinalize.getLocationId().toString());
        creditLimitSearch.setCompanyId(orderToFinalize.getCompanyId().toString());
        return creditLimitSearch;
    }

    /**
     * @param orderToFinalize to fill the search
     * @return {@link CreditLimitMovement} for the informed creditLimit, using the value from the order
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    private CreditLimitMovement doGenerateCreditLimitMovement(final SalesOrder orderToFinalize, final CreditLimit creditLimit) {
        final CreditLimitMovement creditLimitMovement = new CreditLimitMovement();
        creditLimitMovement.setCreditLimit(creditLimit);
        creditLimitMovement.setPayday(LocalDate.now().toString());
        creditLimitMovement.setPaidValue(BigDecimal.ZERO.subtract(orderToFinalize.getNetValue()));
        creditLimitMovement.setSalesOrderId(orderToFinalize.getId().toString());
        return creditLimitMovement;
    }

    /**
     * If the status from the response is different then {@link HttpStatus#SC_CREATED}, it will throw a {@link MessageException}
     *
     * @param response to check the status
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-18.
     */
    private void doCheckReturnOfCreditLimitMovement(final Response response) {
        if (response.getStatus() != HttpStatus.SC_CREATED) {
            throw new MessageException(Constants.MESSAGE_ORDER_GENERATE_CREDIT_LIMIT_ERROR);
        }
    }
}
