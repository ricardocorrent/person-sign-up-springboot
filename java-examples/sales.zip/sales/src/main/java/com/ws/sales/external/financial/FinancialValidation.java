package com.ws.sales.external.financial;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.financial.model.CreditLimit;
import com.ws.financial.model.CreditLimitSearch;
import com.ws.sales.util.Constants;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Validations for credit limit
 *
 * @author Maykon Rissi
 * @since v6.0.0 2018-08-18
 */
public class FinancialValidation {

    private static final Integer MAX_NUMBER_OF_CREDIT_LIMITS = 1;
    private final FinancialGateway financialGateway;

    /**
     * @param financialGateway to perform financial gets
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public FinancialValidation(final FinancialGateway financialGateway) {
        this.financialGateway = financialGateway;
    }

    /**
     * Uses the param fields to get the credit limits using the filters
     *
     * @param companyId  to fill the search
     * @param customerId to fill the search
     * @param locationId to fill the search
     * @return {@link List<CreditLimit>} credit limits from the given search
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public List<CreditLimit> findCreditLimit(final UUID companyId, final UUID customerId, final UUID locationId) {
        final CreditLimitSearch creditLimitSearch = new CreditLimitSearch();
        creditLimitSearch.setCompanyId(companyId.toString());
        creditLimitSearch.setCustomerId(customerId.toString());
        creditLimitSearch.setLocationId(locationId.toString());
        return financialGateway.searchCreditLimit(creditLimitSearch);
    }

    /**
     * Return an error if there are none credit limits
     *
     * @param creditLimits to validate
     * @return {@link LogicError} if there are none credit limits, or null if it has at least one
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfCreditLimitExists(final List<CreditLimit> creditLimits) {
        return CollectionUtils.isNotEmpty(creditLimits) ? null : new LogicError(Constants.FIELD_SALES, Constants.MESSAGE_CREDIT_LIMIT_NOT_EXISTS);
    }

    /**
     * Return an error if there are more than one credit limits
     *
     * @param creditLimits to validate
     * @return {@link LogicError} if there are more then one credit limit, or null if there are only one
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfHasMoreThanOneCreditLimit(final List<CreditLimit> creditLimits) {
        return Optional.ofNullable(creditLimits)
                .filter(list -> list.size() > MAX_NUMBER_OF_CREDIT_LIMITS)
                .map(list -> new LogicError(Constants.FIELD_SALES, Constants.MESSAGE_CREDIT_LIMIT_MORE_THAN_ONE))
                .orElse(null);

    }

    /**
     * Return an error if the customer has credit limit, but no remaining value to spend
     *
     * @param creditLimits to validate
     * @return {@link LogicError}
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfCreditLimitIsNegative(final List<CreditLimit> creditLimits) {
        return Optional.ofNullable(creditLimits)
                .map(Collection::stream)
                .orElse(Stream.empty())
                .findFirst()
                .map(CreditLimit::getRemainingValue)
                .map(remainingValue -> remainingValue.compareTo(BigDecimal.ZERO) <= 0)
                .filter(Boolean.TRUE::equals)
                .map(hasNoCredit ->  new LogicError(Constants.FIELD_SALES, Constants.MESSAGE_CREDIT_IS_NEGATIVE))
                .orElse(null);
    }

    /**
     * Return an error if the customer has credit limit with a positive value and, after the sale, it become negative.
     *
     * @param creditLimits to validate
     * @param saleValue    to subtract from credit limit and validate
     * @return {@link LogicError}
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfCreditLimitBecameNegative(final List<CreditLimit> creditLimits, final BigDecimal saleValue) {
        return Optional.ofNullable(creditLimits)
                .map(Collection::stream)
                .orElse(Stream.empty())
                .findFirst()
                .map(CreditLimit::getRemainingValue)
                .map(bigDecimal -> bigDecimal.compareTo(Optional.ofNullable(saleValue).orElse(BigDecimal.ZERO)) < 0)
                .filter(Boolean.TRUE::equals)
                .map(creditIsSmallerThanSell -> new LogicError(Constants.FIELD_SALES, Constants.MESSAGE_CREDIT_BECAME_NEGATIVE))
                .orElse(null);
    }
}
