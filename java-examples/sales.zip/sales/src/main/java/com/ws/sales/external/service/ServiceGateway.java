package com.ws.sales.external.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Iterables;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.pagination.PagedList;
import com.ws.financial.model.CreditLimit;
import com.ws.financial.model.CreditLimitSearch;
import com.ws.sales.external.AbstractGateway;
import com.ws.service.model.ServiceSearch;
import com.ws.service.model.ServiceStatus;
import com.ws.service.model.UserResponsibleTO;
import com.ws.service.service.ServiceResource;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 2019-01-15 7.1.0
 */
public class ServiceGateway extends AbstractGateway {

    @InjectProxy
    private ServiceResource serviceResource;

    private final Logger logger = LoggerFactory.getLogger(ServiceGateway.class);

    /**
     * Queries the service microservice for the currently running
     * service for a specific user.
     * @param userId the user that is doing the service.
     * @return the service or null if none are found.
     */
    public ServiceDTO getServiceInExecution(final UUID userId) throws IOException {
        final ServiceSearch searchObject = new ServiceSearch();

        addUserResponsible(userId, searchObject);
        addStatus(searchObject);
        searchObject.setSelect("id,customerId,customerName,locationId,locationDescription,fullTime,times.*");

        final Response response = serviceResource.search(searchObject);

        if(response.getStatus() == 200 && response.hasEntity()) {
            final PagedList<ServiceDTO> service = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<ServiceDTO>>() {});

            final List<ServiceDTO> items = service.getItems() == null ? new ArrayList<>() : service.getItems();

            return Iterables.getOnlyElement(items, null);
        }

        return null;
    }

    private void addStatus(final ServiceSearch searchObject) {
        final ServiceStatus status = new ServiceStatus();
        status.setDescription("EXECUTION");

        searchObject.getStatus().add(status);
    }

    private void addUserResponsible(final UUID userId, final ServiceSearch searchObject) {
        final UserResponsibleTO userResponsibleTO = new UserResponsibleTO();
        userResponsibleTO.setId(userId.toString());
        searchObject.setUserResponsible(userResponsibleTO);
    }

}
