package com.ws.sales.external.integrationhub.documentsign;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.json.ObjectMapperResolver;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.server.validation.exception.LogicException;
import com.ws.integrationhub.digitaldocsignature.DigitalDocSignatureResource;
import com.ws.integrationhub.model.DigitalDocSignature;
import java.io.IOException;
import java.io.InputStream;
import javax.ws.rs.core.Response;
import org.apache.http.HttpStatus;

/**
 * Handles the requests to integration-hub
 *
 * @since 1.0.0 2019-05-08
 *
 * @author Ricardo Corrent
 */
public class DigitalDocSignatureGateway {

    @InjectProxy
    private DigitalDocSignatureResource digitalDocSignatureResource;

    private final ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();

    public DigitalDocSignatureGateway() {
        this.mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * Post the entity in the integration hub gateway. The service
     * will handle where to send, by seen the user credentials. If
     * there are any errors processing the document, or consulting
     * the credentials, it will throw an {@link Exception}
     * <p>
     * Throw an exception if the response is different than Created.
     *
     * @param digitalDocSignature digitalDocSignature to send
     * @return {@link DigitalDocSignatureResponse} with the id from the document
     */
    public DigitalDocSignatureResponse sendDocumentToSign(final DigitalDocSignature digitalDocSignature) {
        try {
            final Response response = this.digitalDocSignatureResource.postDocument(digitalDocSignature);
            if (response.getStatus() == HttpStatus.SC_CREATED) {
                try {
                    return this.mapper.readValue((InputStream) response.getEntity(), DigitalDocSignatureResponse.class);
                } catch (IOException e) {
                    throw new RuntimeException("couldn't convert the response. The request can not proceed", e);
                }
            }
        } catch (final Exception ex) {
            this.throwLogicErrorIfUserHasNotCredentials(ex);
        }
        throw new RuntimeException("Was impossible to send the document");
    }

    /**
     * Get the document info from the integration-hub
     * <p>
     * If the status is different than OK, it will throw an exception, since
     * if the document has external id, it must have info
     *
     * @param documentId documentId to perform the get
     * @return {@link Response} with the digital doc information
     */
    public com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureResponse getSignedDocument(final String documentId) {
        try {
            final Response response = this.digitalDocSignatureResource.postDocument2(documentId);
            if (response.getStatus() == HttpStatus.SC_OK) {
                try {
                    return this.mapper.readValue((InputStream) response.getEntity(), com.ws.sales.external.integrationhub.documentsign.get.DigitalDocSignatureResponse.class);
                } catch (IOException e) {
                    throw new RuntimeException("couldn't convert the response. The request can not proceed", e);
                }
            }
        } catch (final Exception ex) {
            // Handling exception from gateway, since the feign throws exceptions when the httpStatus is not from 200 family
            this.throwLogicErrorIfUserHasNotCredentials(ex);
        }
        return null;
    }

    /**
     * Method used to process the logic error when user doesn't have credentials.
     *
     * @param ex {@link Exception}
     */
    private void throwLogicErrorIfUserHasNotCredentials(final Exception ex) {
        // Handling exception from gateway, since the feign throws exceptions when the httpStatus is not from 200 family
        if (ex.getMessage().contains("credential")) {
            throw new LogicException(new LogicError("credential", "document.noCredential"));
        }
        throw new RuntimeException("There was an error sending the request", ex);
    }
}
