package com.ws.sales.orderitem;

import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.product.model.PriceList;
import com.ws.product.model.Product;
import com.ws.product.model.ProductPackaging;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.util.Constants;
import org.apache.commons.collections4.CollectionUtils;

import javax.inject.Inject;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v3.0.0 2017-03-01.
 */
public class SalesOrderItemService extends AbstractService<SalesOrderItem> {

    private final SalesOrderItemDAO dao;
    private final SalesOrderItemValidator validator;
    private final ProductGateway productGateway;
    private final SalesOrderService salesOrderService;
    private final OrderParameterService orderParameterService;

    @Inject
    public SalesOrderItemService(final SalesOrderItemDAO dao,
                                 final ProductGateway productGateway,
                                 final SalesOrderService salesOrderService,
                                 final SalesOrderItemValidator validator,
                                 final OrderParameterService orderParameterService) {
        super(dao);
        this.dao = dao;
        this.productGateway = productGateway;
        this.salesOrderService = salesOrderService;
        this.validator = validator;
        this.orderParameterService = orderParameterService;
    }

    @Override
    public SalesOrderItem insert(final SalesOrderItem item) throws Exception {
        setPriceListDescription(item);
        setProductInformation(item);
        calculateTotal(item);
        setSalesOrderItemInfo(item);
        validator.validate(item, EValidationType.INSERT);
        validator.throwFoundErrors();
        final SalesOrderItem inserted = super.insert(item);
        salesOrderService.updateOrderTotalValue(item.getSalesOrder().getId());
        return inserted;
    }

    /**
     * Method for insert item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param item the order item being created.
     */
    public SalesOrderItem insertItemFinishOrder(final SalesOrderItem item) throws Exception {
        setSalesOrderItemInfo(item);
        final SalesOrderItem inserted = super.insert(item);
        salesOrderService.updateOrderTotalValue(item.getSalesOrder().getId());
        return inserted;
    }

    /**
     * Method to change sales information of SalesOrdemItem
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param item the order item updated.
     */
    private void setSalesOrderItemInfo(final SalesOrderItem item) {
        setPriceListDescription(item);
        setProductInformation(item);
        calculateTotal(item);
    }

    @Override
    public void update(final SalesOrderItem item) throws Exception {
        setSalesOrderItemInfo(item);
        validator.validate(item, EValidationType.UPDATE);
        validator.throwFoundErrors();
        super.update(item);
        salesOrderService.updateOrderTotalValue(item.getSalesOrder().getId());
    }

    /**
     * Method for update item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param item the order item updated.
     */
    public void updateItemFinishOrder(final SalesOrderItem item) throws Exception {
        setSalesOrderItemInfo(item);
        super.update(item);
        salesOrderService.updateOrderTotalValue(item.getSalesOrder().getId());
    }

    private void setPriceListDescription(final SalesOrderItem item) {
        if (item.getPriceListId() != null
                && (item.getPriceListDescription() == null || item.getPriceListDescription().isEmpty())) {
            final PriceList priceList = getPriceList(item);
            if (priceList != null) {
                item.setPriceListDescription(priceList.getDescription());
            }
        }
    }

    private void setProductInformation(final SalesOrderItem item) {
        if (item.getProductId() != null) {
            final Product product = getProduct(item);
            if (product != null
                    && (item.getProductCode() == null || item.getProductCode().isEmpty())) {
                item.setProductCode(product.getCode());
            }

            if (product != null
                    && (item.getProductDescription() == null || item.getProductDescription().isEmpty())) {
                item.setProductDescription(product.getDescription());
            }

            if (item.getProductPackagingId() != null
                    && (item.getProductPackagingDescription() == null || item.getProductPackagingDescription().isEmpty())) {
                final ProductPackaging packaging = getProductPackaging(item, product);
                if (packaging != null) {
                    item.setProductPackagingDescription(packaging.getPackagingDescription());
                }
            }
        }
    }

    /**
     * Calculates the total value for the item
     *
     * @param item to calculate
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-07
     */
    private void calculateTotal(final SalesOrderItem item) {
        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey(Constants.FIELD_PARAMETER_DECIMAL_PLACES);
        final int decimalPlaces = decimalPlacesParameter.getValue() != null ? Integer.valueOf(decimalPlacesParameter.getValue()) : 2;
        if (item.getQuantity() != null && item.getSalesPrice() != null) {
            item.setTotalItem(item.getQuantity().multiply(item.getSalesPrice()).setScale(decimalPlaces, RoundingMode.HALF_EVEN));
        }
    }

    @Override
    public void delete(final UUID id) throws Exception {
        final SalesOrderItem oldItem = super.get(id);
        validator.validate(oldItem, EValidationType.DELETE);
        validator.throwFoundErrors();
        super.delete(id);
        salesOrderService.updateOrderTotalValue(oldItem.getSalesOrder().getId());
    }


    /**
     * Method for delete item from sales order already finalized.
     *
     * @author Peterson Schmitt
     * @since v8.0.0 2019-05-31
     *
     * @param id item delete.
     */
    public void deleteItemFinishOrder(final UUID id) throws Exception {
        final SalesOrderItem oldItem = super.get(id);
        super.delete(id);
        salesOrderService.updateOrderTotalValue(oldItem.getSalesOrder().getId());
    }

    public PagedList<SalesOrderItem> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        return this.dao.findByOrder(orderId, restQueryAdapter);
    }

    public PagedList<SalesOrderItem> list(final SalesOrderItemSearch search) {
        return dao.list(search);

    }

    private PriceList getPriceList(final SalesOrderItem item) {
        if (item.getPriceListId() != null) {
            return productGateway.getPriceList(item.getPriceListId());
        }
        return null;
    }

    private Product getProduct(final SalesOrderItem item) {
        if (item.getProductId() != null) {
            return productGateway.getProduct(item.getProductId());
        }
        return null;
    }

    private ProductPackaging getProductPackaging(final SalesOrderItem item, final Product product) {
        final UUID productPackagingId = item.getProductPackagingId();
        final List<ProductPackaging> packagings = Optional.ofNullable(product).map(Product::getPackagings).orElse(null);
        if (product != null && productPackagingId != null && CollectionUtils.isNotEmpty(packagings)) {
            return packagings
                    .stream()
                    .filter(pack -> productPackagingId.toString().equals(pack.getId()))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }
}
