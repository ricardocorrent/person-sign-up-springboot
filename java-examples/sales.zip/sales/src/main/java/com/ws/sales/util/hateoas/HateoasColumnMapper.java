package com.ws.sales.util.hateoas;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <pre>
 *  Annotation created to map the uri and type of the conversion of an attribute of the class that implements {@link HateoasColumnMapper}.
 *  This mapping should be used when the attribute name of the uri class is not the same as the type class attribute,
 *  or when they do not have the same hierarchical structure. *

 *
 * @author ademar.junior<ademar.junior@wssim.com.br />
 * @since 7.1.0 2018-12-26

 */
@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Repeatable(HateoasColumnListMapper.class)
public @interface HateoasColumnMapper  {

    /**
     * rel means relationship
     * In this case, it's a self-referencing hyperlink.
     * More complex systems might include other relationships.
     * For example, an order might have a "rel":"customer" relationship,
     * linking the order to its customer.
     */
    String rel();
    /**
     * uri is a complete URL that uniquely defines the resource.
     */
    String uri();

    /**
     * Type is a HTTP Request GET, POST, PUT ....
     */
    HateoasType type() default HateoasType.GET;
}
