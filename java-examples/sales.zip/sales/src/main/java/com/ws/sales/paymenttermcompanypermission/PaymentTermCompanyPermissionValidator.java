package com.ws.sales.paymenttermcompanypermission;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.validation.entityvalidator.AbstractIndexedEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.IndexedLogicError;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.administration.AdministrationValidation;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermCompanyPermissionValidator extends AbstractIndexedEntityValidator<PaymentTermCompanyPermission> {

    private final AdministrationValidation administrationValidation;

    /**
     * @param administrationValidation to handle validations for company
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-04
     **/
    @Inject
    public PaymentTermCompanyPermissionValidator(final AdministrationValidation administrationValidation) {
        this.administrationValidation = administrationValidation;
    }

    /**
     * <p>
     * This method will validate the company and create a new {@link IndexedLogicError}
     * It will add the error by using {@link ValidationUtils#createIndexedFromLogicError(String, LogicError)}
     * to convert the {@link LogicError} given by the validation to the indexed
     *
     * @param entity to get company and validate
     * @param index  to fill the {@link IndexedLogicError}
     **/
    private void doValidateCompany(final PaymentTermCompanyPermission entity, final String index) {
        final LogicError error = this.administrationValidation.doValidateCompanyCanBeUsed(entity.getCompanyId(), Constants.FIELD_COMPANY_ID);
        this.addError(ValidationUtils.createIndexedFromLogicError(index, error), entity);
    }

    /**
     * <p>
     * This method will validate the permission and create a new {@link IndexedLogicError}
     * It will use the entitiesInDatabase list to search if the informed permission is there
     * <p>
     * If the permission is already persisted, it will add an error.
     *
     * @param entity             to get company and validate
     * @param index              to fill the {@link IndexedLogicError}
     * @param entitiesInDatabase to check if the permission is already persisted
     **/
    public void doValidatePermission(final PaymentTermCompanyPermission entity, final String index, final List<PaymentTermCompanyPermission> entitiesInDatabase) {
        final LogicError error = this.doValidateIfPermissionExistsInDatabase(entity, index, entitiesInDatabase);
        this.addError(error, entity);
    }

    /**
     * <p>
     * Stream the list of persisted permissions to check if the informed one is
     * already persisted. It will return an {@link IndexedLogicError} if it found
     *
     * @param entity             to get company and validate
     * @param index              to fill the {@link IndexedLogicError}
     * @param entitiesInDatabase to check if the permission is already persisted
     * @return {@link IndexedLogicError}
     **/
    private IndexedLogicError doValidateIfPermissionExistsInDatabase(final PaymentTermCompanyPermission entity, final String index,
                                                                     final List<PaymentTermCompanyPermission> entitiesInDatabase) {
        return entitiesInDatabase.stream()
                .map(PaymentTermCompanyPermission::getCompanyId)
                .filter(companyId -> companyId.equals(entity.getCompanyId()))
                .map(hasPermissionInDb -> new IndexedLogicError(index, Constants.FIELD_COMPANY_ID, Constants.MESSAGE_PERMISSION_ALREADY_PERSISTED))
                .findFirst()
                .orElse(null);
    }

    /**
     * @see AbstractIndexedEntityValidator#addError(LogicError, BaseModel)
     **/
    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        Optional.ofNullable(logicError).ifPresent(error -> super.addError(error, entity));
    }

    /**
     * <p>
     * this method wont be used, because more parameters are needed to perform
     * the validations
     *
     * @see AbstractIndexedEntityValidator#validate(BaseModel, String, IValidationFilter...)
     **/
    @Override
    protected void validate(final PaymentTermCompanyPermission entity, final String index, final IValidationFilter... filter) {
        throw new UnsupportedOperationException();
    }

    /**
     * @param entity             to perform validations
     * @param entitiesInDatabase {@link List<PaymentTermCompanyPermission>} from the informed {@link com.ws.sales.paymentterm.PaymentTerm} in the database
     * @param index              to fill the {@link IndexedLogicError}
     * @see AbstractIndexedEntityValidator#validate(BaseModel, String, IValidationFilter...)
     **/
    public void validate(final PaymentTermCompanyPermission entity, final List<PaymentTermCompanyPermission> entitiesInDatabase, final String index) {
        this.doValidateCompany(entity, index);
        this.doValidatePermission(entity, index, entitiesInDatabase);
    }
}
