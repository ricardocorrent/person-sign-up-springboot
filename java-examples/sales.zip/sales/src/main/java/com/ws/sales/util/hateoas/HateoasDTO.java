package com.ws.sales.util.hateoas;


import java.util.List;

/**
 * Hypermedia As The Engine Of Application State (HATEOAS) is a component of the
 * REST application architecture that distinguishes it from other network application architectures
 *
 * @author ademar.junior<ademar.junior@wssim.com.br />
 * @since 7.1.0 2019-01-02
 */
public class HateoasDTO {

    private List<HateoasRelDTO> links;

    public List<HateoasRelDTO> getLinks() {
        return links;
    }

    public void setLinks(final List<HateoasRelDTO> links) {
        this.links = links;
    }
}
