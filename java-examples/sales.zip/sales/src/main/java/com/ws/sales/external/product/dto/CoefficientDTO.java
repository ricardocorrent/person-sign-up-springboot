package com.ws.sales.external.product.dto;

import java.math.BigDecimal;

/**
 * Created by maykon.rissi on 16-Jan-18.
 *
 * @author Marco Aurelio F. Schaefer
 */
public class CoefficientDTO {

    private BigDecimal coefficient;

    public BigDecimal getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(BigDecimal coefficient) {
        this.coefficient = coefficient;
    }
}
