package com.ws.sales.external.commondata;

import com.ws.commondata.model.Incoterms;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

/**
 * Validations for common data
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-18
 */
public class CommonDataValidation {

    private final CommonDataGateway commonDataGateway;

    /**
     * @param commonDataGateway to perform customer gets
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Inject
    public CommonDataValidation(final CommonDataGateway commonDataGateway) {
        this.commonDataGateway = commonDataGateway;
    }

    /**
     * Return an error if the incoterms does not exist or is inactive.
     *
     * @param incotermsId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    public LogicError doValidateIncotermsCanBeUsed(final UUID incotermsId) {
        return Optional.ofNullable(incotermsId).map(id -> {
            final Incoterms incoterms = commonDataGateway.getIncoterms(id);
            if (incoterms == null) {
                return new LogicError(Constants.FIELD_INCOTERMS_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!incoterms.isActive()) {
                return new LogicError(Constants.FIELD_INCOTERMS_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Check if the type of freight is FOB and the value is not null
     *
     * @param incotermsAcronym to see the type of acronym
     * @param freightValue     to validate
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-30
     */
    public LogicError doValidateFreightValueFob(final IncotermsAcronym incotermsAcronym, final BigDecimal freightValue) {
        return Optional.ofNullable(incotermsAcronym).map(acronym -> {
            if (freightValue != BigDecimal.ZERO && freightValue != null && acronym == IncotermsAcronym.FOB) {
                return new LogicError(Constants.FIELD_FREIGHT_VALUE, Constants.MESSAGE_INCORRECT_FOB);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Check if the type of freight is CIF and it doesn't have a value
     *
     * @param incotermsAcronym to see the type of acronym
     * @param freightValue     to validate
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-30
     */
    public LogicError doValidateFreightValueCif(final IncotermsAcronym incotermsAcronym, final BigDecimal freightValue) {
        return Optional.ofNullable(incotermsAcronym).map(acronym -> {
            if (acronym == IncotermsAcronym.CIF && (freightValue == null || freightValue.compareTo(BigDecimal.ZERO) == 0)) {
                return new LogicError(Constants.FIELD_FREIGHT_VALUE, Constants.MESSAGE_INCORRECT_CIF);
            }
            return null;
        }).orElse(null);
    }
}
