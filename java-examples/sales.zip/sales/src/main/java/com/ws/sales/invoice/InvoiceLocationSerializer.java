package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * This class represents invoice location serializer for invoice, she will be serialize just the
 * fields id and description from invoice location because it's just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
public class InvoiceLocationSerializer extends StdSerializer<InvoiceLocation> {

    /**
     * Instantiates a new invoice location serializer.
     */
    public InvoiceLocationSerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice location serializer.
     *
     * @param t the t
     */
    protected InvoiceLocationSerializer(Class<InvoiceLocation> t) {
        super(t);
    }

    /**
     * This method override the serialization of InvoiceLocation for Invoice class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(InvoiceLocation value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        InvoiceLocation invoiceLocation = new InvoiceLocation();
        invoiceLocation.setId(value.getId());
        invoiceLocation.setReplicatedId(value.getReplicatedId());
        invoiceLocation.setDescription(value.getDescription());
        gen.writeObject(invoiceLocation);
    }
}