package com.ws.sales.deliveryorder;

import com.ws.commons.server.pagination.PaginationSearch;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author Sergio Junior
 * @author Maykon Rissi
 * @version 6.0.0 2018-08-13
 * @since 5.0.0 2017-08-11
 */
public class DeliveryOrderSearch extends PaginationSearch {

    private UUID id;
    private UUID orderId;
    private OffsetDateTime deliveryDate;
    private OffsetDateTime shipmentDate;
    private String locationDescription;

    /**
     * Get of property {@link #id}
     *
     * @return java.util.UUID
     */
    public UUID getId() {
        return id;
    }

    /**
     * Set of property {@link #id}
     *
     * @param id field to set
     */
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * Get of property {@link #orderId}
     *
     * @return java.util.UUID
     */
    public UUID getOrderId() {
        return orderId;
    }

    /**
     * Set of property {@link #orderId}
     *
     * @param orderId field to set
     */
    public void setOrderId(final UUID orderId) {
        this.orderId = orderId;
    }

    /**
     * Get of property {@link #deliveryDate}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Set of property {@link #deliveryDate}
     *
     * @param deliveryDate field to set
     */
    public void setDeliveryDate(final OffsetDateTime deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    /**
     * Get of property {@link #shipmentDate}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getShipmentDate() {
        return shipmentDate;
    }

    /**
     * Set of property {@link #shipmentDate}
     *
     * @param shipmentDate field to set
     */
    public void setShipmentDate(final OffsetDateTime shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    /**
     * Get of property {@link #locationDescription}
     *
     * @return java.lang.String
     */
    public String getLocationDescription() {
        return locationDescription;
    }

    /**
     * Set of property {@link #locationDescription}
     *
     * @param locationDescription field to set
     */
    public void setLocationDescription(final String locationDescription) {
        this.locationDescription = locationDescription;
    }
}
