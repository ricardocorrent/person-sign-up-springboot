package com.ws.sales.paymentmethod;

import com.ws.commons.server.pagination.PaginationSearch;

import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class PaymentMethodSearch extends PaginationSearch {

    private final Boolean orderTest = Boolean.FALSE;
    private Boolean[] active;
    private Boolean[] standard;
    private Boolean[] availableFirstOrder;
    private UUID[] paymentMethodIds;
    private String description;
    private String generalSearch;

    /**
     * Gets the options to filter by active.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getActive() {
        return active;
    }

    /**
     * Set the active filter options
     * Options: [true, false]
     *
     * @param active
     */
    public void setActive(final Boolean[] active) {
        this.active = active;
    }

    /**
     * Gets the description to be filtered
     * Deprecated: use "generalSearch" instead.
     *
     * @return java.lang.String
     */
    @Deprecated
    public String getDescription() {
        return description;
    }

    /**
     * Sets the order type description to filter
     * Deprecated: use "generalSearch" instead.
     *
     * @param description
     */
    @Deprecated
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Gets the options to filter by standard.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getStandard() {
        return standard;
    }

    /**
     * Set the standard filter options
     * Options: [true, false]
     *
     * @param standard
     */
    public void setStandard(final Boolean[] standard) {
        this.standard = standard;
    }

    /**
     * Gets the options to filter by availableFirstOrder.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Set the availableFirstOrder filter options
     * Options: [true, false]
     *
     * @param availableFirstOrder
     */
    public void setAvailableFirstOrder(final Boolean[] availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }

    public UUID[] getPaymentMethodIds() {
        return paymentMethodIds;
    }

    public void setPaymentMethodIds(final UUID[] paymentMethodIds) {
        this.paymentMethodIds = paymentMethodIds;
    }

    /**
     * Check if is order filtering
     *
     * @return java.lang.Boolean
     */
    public Boolean getOrderTest() {
        return orderTest;
    }

    public String getGeneralSearch() {
        return generalSearch;
    }

    public void setGeneralSearch(final String generalSearch) {
        this.generalSearch = generalSearch;
    }
}
