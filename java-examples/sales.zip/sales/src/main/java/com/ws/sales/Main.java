package com.ws.sales;

import com.ws.commons.server.JettyServer;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public final class Main {
    /**
     * Method constructor of the Main
     */
    private Main() {
    }

    /**
     * Main instance for init application
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        JettyServer.start();
    }
}