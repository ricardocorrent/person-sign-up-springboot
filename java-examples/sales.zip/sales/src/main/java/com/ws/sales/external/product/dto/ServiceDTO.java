package com.ws.sales.external.product.dto;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.io.Serializable;
import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
public class ServiceDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private static final long serialVersionUID = -3062481907539544326L;

    private UUID id;

    private String description;

    private String code;

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(final UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }
}
