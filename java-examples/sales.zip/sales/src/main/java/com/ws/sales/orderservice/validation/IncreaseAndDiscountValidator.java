package com.ws.sales.orderservice.validation;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.orderservice.SalesOrderService;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.function.BiConsumer;

import static com.ws.sales.util.Constants.*;
import static com.ws.sales.validator.ValidationUtils.*;
import static java.math.BigDecimal.ZERO;

/**
 * @author Roberto Filho
 * @since 8.4.0 2019-05-31
 */
public class IncreaseAndDiscountValidator {

    public static final int INTERMEDIARY_OPERATION_SCALE = 30;
    public static final BigDecimal FRACTION_CONVERSION_BASE = BigDecimal.valueOf(100);
    private final BiConsumer<LogicError, SalesOrderService> addError;
    private final SalesOrderService salesOrderService;

    public IncreaseAndDiscountValidator(final BiConsumer<LogicError, SalesOrderService> addError,
                                        final SalesOrderService salesOrderService) {
        this.addError = addError;
        this.salesOrderService = salesOrderService;
    }

    /**
     * Validates the increase and the discount values of this class' SalesOrderService.
     *
     * @param decimalPlaces the number of decimal places that should be used for validation.
     */
    public void validateIncreaseAndDiscountValues(final int decimalPlaces) {
        final BigDecimal originalPrice = nullToZero(salesOrderService.getOriginalPrice());
        final BigDecimal salesPrice = nullToZero(salesOrderService.getSalesPrice());

        if (!hasIncreaseValue(salesOrderService) && !hasDiscountValue(salesOrderService)
                && salesPrice.compareTo(originalPrice) == 0) {
            return;
        } else if (hasIncreaseAndDiscountValues(salesOrderService)) {
            final String message = "order.service.discountAndIncreaseValues";

            addLogicError(FIELD_INCREASE_PERCENTAGE, message);
            addLogicError(FIELD_INCREASE_VALUE, message);
            addLogicError(FIELD_DISCOUNT_PERCENTAGE, message);
            addLogicError(FIELD_DISCOUNT, message);

            return;
        }

        if (salesPrice.compareTo(originalPrice) > 0) {
            validateIncrease(decimalPlaces, originalPrice, salesPrice);
        } else if (salesPrice.compareTo(originalPrice) < 0) {
            validateDiscount(decimalPlaces, originalPrice, salesPrice);
        } else {
            if (differentThanZero(salesOrderService.getDiscountPercentage(), salesOrderService.getDiscount())) {
                addDiscountInconsistentError(ZERO, ZERO);
            }
            if (differentThanZero(salesOrderService.getIncreasePercentage(), salesOrderService.getIncreaseValue())) {
                addIncreaseInconsistentError(ZERO, ZERO);
            }
        }
    }

    /**
     * Validates the increase value and the increase percentage according to the difference between the
     * service's original price and sales price.
     *
     * @param decimalPlaces the number of decimal places to be used for calculations.
     * @param originalPrice the service's price list price
     * @param salesPrice    the value of this item's
     */
    private void validateIncrease(final int decimalPlaces, final BigDecimal originalPrice, final BigDecimal salesPrice) {
        final BigDecimal correctIncreaseValue = negativeToZero(salesPrice.subtract(originalPrice));
        final BigDecimal correctIncreasePercentage = calculatePercentage(originalPrice, correctIncreaseValue, decimalPlaces);

        if (hasInconsistentIncreaseValues(salesOrderService, correctIncreasePercentage, correctIncreaseValue)) {
            addIncreaseInconsistentError(correctIncreaseValue, correctIncreasePercentage);
        }
    }

    /**
     * Adds validation errors when increase value/percentage are inconsistent.
     *
     * @param correctValue      the correct increase value.
     * @param correctPercentage the correct increase percentage.
     */
    private void addIncreaseInconsistentError(final BigDecimal correctValue, final BigDecimal correctPercentage) {
        addLogicError(FIELD_INCREASE_PERCENTAGE, "order.service.increasePercentage.inconsistent", correctPercentage);
        addLogicError(FIELD_INCREASE_VALUE, "order.service.increaseValue.inconsistent", correctValue);
    }

    /**
     * Validates the discount value and the discount percentage according to the difference between the
     * service's original price and sales price.
     *
     * @param decimalPlaces the number of decimal places to be used for calculations.
     * @param originalPrice the service's price list price
     * @param salesPrice    the value of this item's
     */
    private void validateDiscount(final int decimalPlaces, final BigDecimal originalPrice, final BigDecimal salesPrice) {
        final BigDecimal correctDiscountValue = negativeToZero(originalPrice.subtract(salesPrice));
        final BigDecimal correctDiscountPercentage = calculatePercentage(originalPrice, correctDiscountValue, decimalPlaces);

        if (hasInconsistentDiscountValues(salesOrderService, correctDiscountPercentage, correctDiscountValue)) {
            addDiscountInconsistentError(correctDiscountValue, correctDiscountPercentage);
        }
    }

    private void addDiscountInconsistentError(final BigDecimal correctDiscountValue, final BigDecimal correctDiscountPercentage) {
        addLogicError(FIELD_DISCOUNT_PERCENTAGE, "order.service.discountPercentage.inconsistent", correctDiscountPercentage);
        addLogicError(FIELD_DISCOUNT, "order.service.discountValue.inconsistent", correctDiscountValue);
    }

    private boolean hasIncreaseAndDiscountValues(final SalesOrderService entity) {
        return hasIncreaseValue(entity) && hasDiscountValue(entity);
    }

    /**
     * Calculates the percentage of a value.
     * This method answers this question : given a value "difference",
     * what percentage does it represent of a value "totalValue"?
     * <br />The formula is as follows: <code>difference / totalValue * 100</code>
     * <br />Intermediary operations are done using high scale for precision.
     *
     * @param totalValue    the total value from which to calculate the percentage.
     * @param difference    the value of the difference between the total and the discount/increase.
     * @param decimalPlaces how many decimal places the result should have.
     * @return the percentage (100 based).
     */
    private BigDecimal calculatePercentage(final BigDecimal totalValue, final BigDecimal difference, final int decimalPlaces) {
        return difference
                .divide(totalValue, INTERMEDIARY_OPERATION_SCALE, RoundingMode.HALF_EVEN)
                .multiply(FRACTION_CONVERSION_BASE)
                .setScale(decimalPlaces, RoundingMode.HALF_EVEN);
    }

    private boolean hasInconsistentIncreaseValues(final SalesOrderService entity,
                                                  final BigDecimal increasePercentage,
                                                  final BigDecimal increaseValue) {
        final BigDecimal actualIncreaseValue = nullToZero(entity.getIncreaseValue());
        final BigDecimal actualIncreasePercentage = nullToZero(entity.getIncreasePercentage());
        return increasePercentage.compareTo(actualIncreasePercentage) != 0
                || increaseValue.compareTo(actualIncreaseValue) != 0;
    }

    private boolean hasInconsistentDiscountValues(final SalesOrderService entity,
                                                  final BigDecimal correctDiscountPercentage,
                                                  final BigDecimal correctDiscountValue) {
        final BigDecimal actualDiscountValue = nullToZero(entity.getDiscount());
        final BigDecimal actualDiscountPercentage = nullToZero(entity.getDiscountPercentage());
        return correctDiscountPercentage.compareTo(actualDiscountPercentage) != 0
                || correctDiscountValue.compareTo(actualDiscountValue) != 0;
    }

    /**
     * Checks if an order service has increase values.
     *
     * @param entity the sales order to be checked.
     * @return true if either increaseValue or increasePercentage are non null and different than zero.
     */
    private boolean hasIncreaseValue(final SalesOrderService entity) {
        return differentThanZero(entity.getIncreaseValue()) || differentThanZero(entity.getIncreasePercentage());
    }

    /**
     * Checks if an order service has discount values.
     *
     * @param entity the entity to be checked.
     * @return true if either discount value or percentage are not null and different than zero.
     */
    private boolean hasDiscountValue(final SalesOrderService entity) {
        return differentThanZero(entity.getDiscount()) || differentThanZero(entity.getDiscountPercentage());
    }

    private void addLogicError(final String field, final String message) {
        addLogicError(field, message, null);
    }

    private void addLogicError(final String field, final String message, final Object param) {
        final HashMap<String, Object> paramMap = param == null ? null : new HashMap<String, Object>() {{
            put(field, param);
        }};

        addError.accept(new LogicError(field, message, null, paramMap), salesOrderService);
    }
}
