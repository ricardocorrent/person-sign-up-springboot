package com.ws.sales.exception;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messagebundle.MessageExceptionBundle;

/**
 * @author Rodrigo Santini
 * @since 5.18.0 2018-02-16
 */
@Provider
public class JacksonConversionInterceptorExceptionMapper implements ExceptionMapper<InvalidFormatException> {

    private static final Logger LOGGER = LoggerFactory.getLogger(JacksonConversionInterceptorExceptionMapper.class);

    @Inject
    private MessageExceptionBundle bundle;

    @Context
    private HttpServletRequest request;

    /**
     * Map an InvalidFormatException to a {@link Response}.
     * Throwing a runtime exception results in a
     * {@link Response.Status#INTERNAL_SERVER_ERROR} response.
     *
     * @param exception as {@link InvalidFormatException}.
     * @return a response mapped from the supplied exception.
     */
    @Override
    public Response toResponse(final InvalidFormatException exception) {
        JacksonConversionInterceptorExceptionMapper.LOGGER.error(exception.getMessage(), exception);

        final String exMessage = "exception.invalid.format";
        final InvalidFormatException changedException = new InvalidFormatException(null, exMessage, exception.getValue(), exception.getTargetType());

        final ExceptionMessage message = this.bundle.getMessage(changedException, this.request.getLocale());

        return Response.status(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .type(MediaType.APPLICATION_JSON)
                .entity(message).build();
    }
}
