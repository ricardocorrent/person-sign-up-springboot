package com.ws.sales.external.cloudmanager;

import com.ws.commons.server.pagination.PagedList;

import java.util.ArrayList;
import java.util.List;

/**
 * It sets the Cloud Manager data page structure. HTTP responses
 * where the Cloud Manager returns a data page can be converted to an object of this class.
 * @param <T> Object type contained on the data page.
 * @since 2018-10-01
 * @author Diego Armange Costa
 *
 * @author Alan J. A. Pena
 * @since 2018-10-23
 */
public class CloudManagerPagedList<T> {

    private List<T> items = new ArrayList<>();
    private int count;
    private int page;
    private int size;

    /**
     * @return the {@link CloudManagerPagedList}'s items
     */
    public List<T> getItems() {
        return this.items;
    }

    /**
     * @param items the {@link CloudManagerPagedList}'s items to set
     */
    public void setItems(final ArrayList<T> items) {
        this.items = items;
    }

    /**
     * @return the {@link CloudManagerPagedList}'s count
     */
    public int getCount() {
        return this.count;
    }
    /**
     * @param count the {@link CloudManagerPagedList}'s count to set
     */
    public void setCount(final int count) {
        this.count = count;
    }
    /**
     * @return the {@link CloudManagerPagedList}'s page
     */
    public int getPage() {
        return this.page;
    }

    /**
     * @param page the {@link CloudManagerPagedList}'s page to set
     */
    public void setPage(final int page) {
        this.page = page;
    }

    /**
     * @return the {@link CloudManagerPagedList}'s size
     */
    public int getSize() {
        return this.size;
    }

    /**
     * @param size the {@link CloudManagerPagedList}'s size to set
     */
    public void setSize(final int size) {
        this.size = size;
    }

    /**
     * Converts this Cloud Manager paged list to default CRM's paged list.
     * @return the converted paged list.
     */
    public PagedList<T> toPagedList() {
        return new PagedList<>(this.items, this.count, this.page, this.size);
    }
}
