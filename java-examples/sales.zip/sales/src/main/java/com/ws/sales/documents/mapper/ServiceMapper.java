package com.ws.sales.documents.mapper;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Dante Basso <dante.basso@wwsim.com.br>
 * @version 1.0.0
 * @since 2019-03-18
 */
public class ServiceMapper {

    private String code;

    private String description;

    private DetailsDiscountMapper detailsDiscount;

    private DetailsIncreaseMapper detailsIncrease;

    private String detailsPriceList;

    private Integer detailsQuantity;

    private BigDecimal salesPrice;

    private String detailsUser;

    private List<RecurrenceTypeMapper> recurrencesType;

    private BigDecimal total;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DetailsDiscountMapper getDetailsDiscount() {
        return detailsDiscount;
    }

    public void setDetailsDiscount(DetailsDiscountMapper detailsDiscount) {
        this.detailsDiscount = detailsDiscount;
    }

    public DetailsIncreaseMapper getDetailsIncrease() {
        return detailsIncrease;
    }

    public void setDetailsIncrease(DetailsIncreaseMapper detailsIncrease) {
        this.detailsIncrease = detailsIncrease;
    }

    public String getDetailsPriceList() {
        return detailsPriceList;
    }

    public void setDetailsPriceList(String detailsPriceList) {
        this.detailsPriceList = detailsPriceList;
    }

    public Integer getDetailsQuantity() {
        return detailsQuantity;
    }

    public void setDetailsQuantity(Integer detailsQuantity) {
        this.detailsQuantity = detailsQuantity;
    }

    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    public String getDetailsUser() {
        return detailsUser;
    }

    public void setDetailsUser(String detailsUser) {
        this.detailsUser = detailsUser;
    }

    public List<RecurrenceTypeMapper> getRecurrencesType() {
        return recurrencesType;
    }

    public void setRecurrencesType(List<RecurrenceTypeMapper> recurrencesType) {
        this.recurrencesType = recurrencesType;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }
}
