package com.ws.sales.validator;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.IndexedLogicError;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.utils.ArrayUtils;
import com.ws.sales.util.Constants;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static java.math.BigDecimal.ZERO;

/**
 * Utils for validations
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-21
 */
public final class ValidationUtils {

    /**
     * Default private constructor
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private ValidationUtils() {
    }

    /**
     * <p>
     * This creates a new {@link LogicError} with one param. It will mount
     * a {@link HashMap} and put the param with key and value to the error.
     *
     * @param key     string with the key for param
     * @param value   string with the value for param
     * @param field   string with the field for the message
     * @param message string with the key for the message
     * @return {@link LogicError}
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    public static LogicError doCreateLogicErrorWithParam(final String key, final String value, final String field, final String message) {
        final Map<String, Object> params = new HashMap<>();
        params.put(key, value);
        return new LogicError(field, message, null, params);
    }


    /**
     * Returns if the value valid
     *
     * @param value BigDecimal to compare
     * @return true if the value is null or zero
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    public static Boolean isValueNullOrZero(final BigDecimal value) {
        return Optional.ofNullable(value).map(mapValue -> mapValue.compareTo(BigDecimal.ZERO) <= 0).orElse(Boolean.TRUE);
    }

    /**
     * convert a string date into a LocalDate and compare with today
     *
     * @param paramDate to convert
     * @return true if the date is before today
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public static Boolean isDateBeforeToday(final String paramDate) {
        return Optional.ofNullable(paramDate).map(date -> {
            final LocalDate localDate = LocalDate.parse(date);
            return localDate.isBefore(LocalDate.now());
        }).orElse(Boolean.FALSE);
    }

    /**
     * convert a string date into a LocalDate and compare with today
     *
     * @param paramDate to convert
     * @return true if the date is after today
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public static Boolean isDateAfterToday(final String paramDate) {
        return Optional.ofNullable(paramDate).map(date -> {
            final LocalDate localDate = LocalDate.parse(date);
            return localDate.isAfter(LocalDate.now());
        }).orElse(Boolean.FALSE);
    }

    /**
     * Check if the field is null. If true, it will return an logic error with not null message.
     *
     * @param fieldName  to use in the message
     * @param fieldValue to check null
     * @return an {@link LogicError} if the value is null
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public static LogicError doValidateFieldMandatory(final String fieldName, final Object fieldValue) {
        if (fieldName != null && fieldValue == null) {
            return new LogicError(fieldName, Constants.MESSAGE_JAVAX_NOT_NULL);
        }
        return null;
    }

    /**
     * <p>
     * Uses the information from the {@link LogicError} to create a new Indexed one
     *
     * @param index to fill the {@link IndexedLogicError}
     * @param logicError to fill the {@link IndexedLogicError}
     * @return {@link IndexedLogicError}
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-04
     **/
    public static IndexedLogicError createIndexedFromLogicError(final String index, final LogicError logicError) {
        return Optional.ofNullable(logicError)
                .map(error -> new IndexedLogicError(index, error.getField(), error.getMessage()))
                .orElse(null);
    }

    /**
     * Checks if a value is bigger than 0.
     *
     * @param value the value to be checked.
     * @return <code>true</code> if the value is non null and bigger than 0.
     */
    public static boolean biggerThanZero(final BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * Checks if any of the values are non null and different than zero.
     *
     * @param values the values to be checked, can be null.
     * @return <code>true</code> if any of the values are not null and different than zero.
     */
    public static boolean differentThanZero(final BigDecimal... values) {
        return Arrays.stream(values)
                .map(ValidationUtils::nullToZero)
                .anyMatch(value -> value.compareTo(ZERO) != 0);
    }

    public static BigDecimal nullToZero(final BigDecimal value) {
        return Optional.ofNullable(value).orElse(ZERO);
    }

    public static BigDecimal negativeToZero(final BigDecimal value) {
        return value.signum() < 0 ? ZERO : value;
    }

    public static boolean isInsert(final IValidationFilter[] filter) {
        return ArrayUtils.contains(filter, EValidationType.INSERT);
    }

    public static boolean isUpdate(final IValidationFilter[] filter) {
        return ArrayUtils.contains(filter, EValidationType.UPDATE);
    }

    public static boolean isDelete(final IValidationFilter[] filter) {
        return ArrayUtils.contains(filter, EValidationType.DELETE);
    }
}
