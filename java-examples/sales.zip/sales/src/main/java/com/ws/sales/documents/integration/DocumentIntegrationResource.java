package com.ws.sales.documents.integration;


import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Class to release the Integration with Document-Manager
 *
 * @author Dante Basso <dante.basso@wssim.com.br>
 * @version 2.3.0
 * @since 1.0.0 2018-07-31
 *
 */
@Path("/api/v1/document-manager")
public interface DocumentIntegrationResource {

    @POST
    @Path("/documents/create")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_OCTET_STREAM})
    Response create(final DocumentCreator documentCreator);

}
