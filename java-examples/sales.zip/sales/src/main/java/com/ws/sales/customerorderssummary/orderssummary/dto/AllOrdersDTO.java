package com.ws.sales.customerorderssummary.orderssummary.dto;

import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import io.ebean.annotation.Sql;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import java.math.BigDecimal;

/**
 * This DTO class was created to represent all orders that belongs to the customer. This data comes to the database
 * through to the sql query
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
@Getter
@Setter
@Entity
@Sql
public class AllOrdersDTO extends PhysicalDeleteBaseEntity implements DefaultPojoConverter {

    private BigDecimal ordersQuantities;

    private BigDecimal netValue;

    private BigDecimal productTotalQuantity;

    private BigDecimal productTotalValue;

    private BigDecimal serviceTotalQuantity;

    private BigDecimal serviceTotalValue;

}
