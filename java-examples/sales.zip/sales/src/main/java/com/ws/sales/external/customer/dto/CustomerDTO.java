package com.ws.sales.external.customer.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

public class CustomerDTO extends BaseDTO implements DefaultPojoConverter {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
