package com.ws.sales.customerorderssummary;

import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.exception.MessageException;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.customerorderssummary.orderssummary.CustomerOrdersSummary;
import com.ws.sales.customerorderssummary.orderssummary.CustomerOrdersSummaryDAO;
import com.ws.sales.customerorderssummary.orderssummary.dto.AllOrdersDTO;
import com.ws.sales.customerorderssummary.orderssummary.dto.LastOrderDTO;
import com.ws.sales.customerorderssummary.productpurchased.ProductPurchasedHistoryDAO;
import com.ws.sales.customerorderssummary.productpurchased.ProductPurchasedHistoryView;
import com.ws.sales.customerorderssummary.productpurchased.dto.ProductPurchasedHistoryDTO;
import com.ws.sales.customerorderssummary.productpurchased.dto.ProductPurchasedHistoryResponseDTO;
import com.ws.sales.customerorderssummary.productspurchased.CustomerOrderHistoryProductsView;
import com.ws.sales.customerorderssummary.productspurchased.ProductsPurchasedSummaryDAO;
import com.ws.sales.customerorderssummary.productspurchased.dto.ProductsPurchasedResponseDTO;
import com.ws.sales.customerorderssummary.productspurchased.dto.ProductsSummaryDTO;
import com.ws.sales.customerorderssummary.servicepurchased.ServicePurchasedHistoryDAO;
import com.ws.sales.customerorderssummary.servicepurchased.ServicePurchasedHistoryView;
import com.ws.sales.customerorderssummary.servicepurchased.dto.ServicePurchasedHistoryDTO;
import com.ws.sales.customerorderssummary.servicepurchased.dto.ServicePurchasedHistoryResponseDTO;
import com.ws.sales.customerorderssummary.servicespurchased.CustomerOrderHistoryServicesView;
import com.ws.sales.customerorderssummary.servicespurchased.ServicesPurchasedSummaryDAO;
import com.ws.sales.customerorderssummary.servicespurchased.dto.ServicesPurchasedResponseDTO;
import com.ws.sales.customerorderssummary.servicespurchased.dto.ServicesSummaryDTO;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
public class CustomerOrdersSummaryService {

    private final CustomerOrderSummaryValidation customerOrderSummaryValidation;
    private final CustomerOrdersSummaryDAO customerOrdersSummaryDAO;
    private final SalesOrderDAO salesOrderDAO;
    private final ProductsPurchasedSummaryDAO productsDAO;
    private final ServicesPurchasedSummaryDAO servicesDAO;
    private final ProductPurchasedHistoryDAO productPurchasedHistoryDAO;
    private final ServicePurchasedHistoryDAO servicePurchasedHistoryDAO;

    @Inject
    public CustomerOrdersSummaryService(final CustomerOrderSummaryValidation customerOrderSummaryValidation,
                                        final CustomerOrdersSummaryDAO customerOrdersSummaryDAO,
                                        final SalesOrderDAO salesOrderDAO,
                                        final ProductsPurchasedSummaryDAO productsDAO,
                                        final ServicesPurchasedSummaryDAO servicesDAO,
                                        final ProductPurchasedHistoryDAO productPurchasedHistoryDAO,
                                        final ServicePurchasedHistoryDAO servicePurchasedHistoryDAO) {
        this.customerOrderSummaryValidation = customerOrderSummaryValidation;
        this.customerOrdersSummaryDAO = customerOrdersSummaryDAO;
        this.salesOrderDAO = salesOrderDAO;
        this.productsDAO = productsDAO;
        this.servicesDAO = servicesDAO;
        this.productPurchasedHistoryDAO = productPurchasedHistoryDAO;
        this.servicePurchasedHistoryDAO = servicePurchasedHistoryDAO;
    }

    /**
     * This method is used to construct a summary about customer's sales order
     *
     * @param customerId {@link UUID} used to find data
     * @return {@link CustomerOrdersSummary}
     */
    public CustomerOrdersSummary getSummary(final UUID customerId) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final CustomerOrdersSummary customerOrdersSummary = new CustomerOrdersSummary();
        this.findsAllOrders(customerOrdersSummary, customerId);
        this.findsLastOrder(customerOrdersSummary, customerId);
        return customerOrdersSummary;
    }

    /**
     * This method create the all orders entity that will be inserted in the summary
     *
     * @param customerOrdersSummary {@link CustomerOrdersSummary}
     * @param customerId {@link UUID}
     */
    private void findsAllOrders(final CustomerOrdersSummary customerOrdersSummary, final UUID customerId) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final AllOrdersDTO allOrdersDTO = this.fetchAllOrdersByCustomerId(customerId);
        if (allOrdersDTO != null) {
            customerOrdersSummary.setAllOrders(allOrdersDTO);
        }
    }

    /**
     * This method finds all finalized orders from customer
     *
     * @param customerId {@link UUID}
     * @return {@link AllOrdersDTO}
     */
    private AllOrdersDTO fetchAllOrdersByCustomerId(final UUID customerId) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        return customerOrdersSummaryDAO.getAllSalesOrders(customerId);
    }

    /**
     * This method finds the last ordered order
     *
     * @param customerOrdersSummary {@link CustomerOrdersSummary}
     * @param customerId {@link UUID} used to find
     */
    private void findsLastOrder(final CustomerOrdersSummary customerOrdersSummary, final UUID customerId) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final SalesOrder salesOrder = fetchLastOrderByCustomerId(customerId);
        if (salesOrder != null) {
            final LastOrderDTO lastOrder = new LastOrderDTO();
            this.setLastOrder(salesOrder, lastOrder);
            customerOrdersSummary.setLastOrder(lastOrder);
        }
    }

    /**
     * This method gets the last ordered order from sales order database
     *
     * @param customerId {@link UUID} used to find
     */
    private SalesOrder fetchLastOrderByCustomerId(final UUID customerId) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        return salesOrderDAO.getLastSalesOrder(customerId);
    }

    /**
     * This method receive que sales order from customer and sets the information about it in the
     * DTO class that will be returned
     *
     * @param salesOrder {@link SalesOrder}
     * @param lastOrder {@link LastOrderDTO}
     */
    private void setLastOrder(final SalesOrder salesOrder, final LastOrderDTO lastOrder) {
        lastOrder.setSalesOrderId(salesOrder.getId());
        lastOrder.setNetValue(salesOrder.getNetValue());
        lastOrder.setProductTotalQuantity(salesOrder.getItems().size());
        lastOrder.setProductTotalValue(salesOrder.getProductTotalValue());
        lastOrder.setServiceTotalQuantity(salesOrder.getServices().size());
        lastOrder.setServiceTotalValue(salesOrder.getServiceTotalValue());
    }

    /**
     * This method list all services purchased from customer and return to when request it
     *
     * @param customerId {@link UUID}
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return {@link ProductsPurchasedResponseDTO}
     */
    public ProductsPurchasedResponseDTO getProductsPurchasedResponse(final UUID customerId,
                                                                     final HttpRestQueryAdapter httpRestQueryAdapter) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final PagedList<CustomerOrderHistoryProductsView> listOfProductsFromDb = this.productsDAO.list(customerId, httpRestQueryAdapter);
        final List<ProductsSummaryDTO> products = formatProductsInformationFromView(listOfProductsFromDb);
        return getAllProductPurchasedResponseDTO(listOfProductsFromDb, products);
    }

    /**
     * This method receive a list of products from database then format informations to send it for response
     *
     * @param listOfProductsFromDb {@link CustomerOrderHistoryProductsView}
     * @return {@link ProductsSummaryDTO}
     */
    private List<ProductsSummaryDTO> formatProductsInformationFromView(final PagedList<CustomerOrderHistoryProductsView> listOfProductsFromDb) {
        return listOfProductsFromDb
                .getItems()
                .stream()
                .map(this::insertInformationInProductsSummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * This method insert data from view into products dto
     *
     * @param item {@link CustomerOrderHistoryProductsView}
     * @return {@link ProductsSummaryDTO}
     */
    private ProductsSummaryDTO insertInformationInProductsSummaryDTO(final CustomerOrderHistoryProductsView item) {
        final ProductsSummaryDTO product = new ProductsSummaryDTO();
        product.setId(item.getProductId());
        product.setCode(item.getProductCode());
        product.setDescription(item.getProductDescription());
        product.setMaxQuantity(item.getMaxQuantity());
        product.setMaxValue(item.getMaxValue());
        product.setLastPurchaseDate(item.getLastPurchaseDate());
        return product;
    }

    /**
     * This method format the response about all products purchased and the rest query params
     *
     * @param listOfProductsFromDb {@link CustomerOrderHistoryProductsView}
     * @param products {@link ProductsSummaryDTO}
     * @return {@link ProductsPurchasedResponseDTO}
     */
    private ProductsPurchasedResponseDTO getAllProductPurchasedResponseDTO(final PagedList<CustomerOrderHistoryProductsView> listOfProductsFromDb,
                                                                           final List<ProductsSummaryDTO> products) {
        final ProductsPurchasedResponseDTO productsPurchasedResponse = new ProductsPurchasedResponseDTO();
        productsPurchasedResponse.setProducts(products);
        productsPurchasedResponse.setCount(listOfProductsFromDb.getCount());
        productsPurchasedResponse.setPage(listOfProductsFromDb.getPage());
        productsPurchasedResponse.setPageSize(listOfProductsFromDb.getPageSize());
        return productsPurchasedResponse;
    }

    /**
     * This method list all services purchased from customer and return to when request it
     *
     * @param customerId {@link UUID} customer id
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return {@link ServicesPurchasedResponseDTO}
     */
    public ServicesPurchasedResponseDTO getServicesPurchasedResponse(final UUID customerId, final HttpRestQueryAdapter httpRestQueryAdapter) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final PagedList<CustomerOrderHistoryServicesView> listOfServicesFromDb = this.servicesDAO.list(customerId, httpRestQueryAdapter);
        final List<ServicesSummaryDTO> services = formatServicesInformationFromView(listOfServicesFromDb);
        return getAllServicesPurchasedResponseDTO(listOfServicesFromDb, services);
    }

    /**
     * This method format the response about all services purchased and the rest query params
     *
     * @param listOfServicesFromDb {@link CustomerOrderHistoryServicesView}
     * @param services {@link ServicesSummaryDTO}
     * @return {@link ServicesPurchasedResponseDTO}
     */
    private ServicesPurchasedResponseDTO getAllServicesPurchasedResponseDTO(final PagedList<CustomerOrderHistoryServicesView> listOfServicesFromDb,
                                                                            final List<ServicesSummaryDTO> services) {
        final ServicesPurchasedResponseDTO servicesPurchasedResponse = new ServicesPurchasedResponseDTO();
        servicesPurchasedResponse.setServices(services);
        servicesPurchasedResponse.setCount(listOfServicesFromDb.getCount());
        servicesPurchasedResponse.setPage(listOfServicesFromDb.getPage());
        servicesPurchasedResponse.setPageSize(listOfServicesFromDb.getPageSize());
        return servicesPurchasedResponse;
    }

    /**
     * This method receive a list of services from database then format informations to send it for response
     *
     * @param listOfServicesFromDb {@link PagedList} of the {@link CustomerOrderHistoryServicesView} from database
     * @return a list of {@link ServicesSummaryDTO}
     */
    private List<ServicesSummaryDTO> formatServicesInformationFromView(final PagedList<CustomerOrderHistoryServicesView> listOfServicesFromDb) {
        return listOfServicesFromDb
                .getItems()
                .stream()
                .map(this::insertInformationInServicesSummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * This method insert data from view into services dto
     *
     * @param item {@link CustomerOrderHistoryServicesView} used to get data
     * @return {@link ServicesSummaryDTO}
     */
    private ServicesSummaryDTO insertInformationInServicesSummaryDTO(final CustomerOrderHistoryServicesView item) {
        final ServicesSummaryDTO service = new ServicesSummaryDTO();
        service.setId(item.getServiceId());
        service.setCode(item.getServiceCode());
        service.setDescription(item.getServiceDescription());
        service.setMaxQuantity(item.getMaxQuantity());
        service.setMaxValue(item.getMaxValue());
        service.setLastPurchaseDate(item.getLastPurchaseDate());
        return service;
    }

    /**
     * This method is used to get details from the product view to send it to the front end
     *
     * @param customerId {@link UUID} customer id
     * @param productId {@link UUID} product id
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter} to get a rest query data
     * @return {@link ProductPurchasedHistoryResponseDTO} with product's detail
     */
    public ProductPurchasedHistoryResponseDTO getProductPurchasedHistoryResponse(final UUID customerId,
                                                                                 final UUID productId,
                                                                                 final HttpRestQueryAdapter httpRestQueryAdapter) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        if (!customerOrderSummaryValidation.productExists(productId)) {
            throw new MessageException("order.item.product.notFound", HttpStatus.SC_NOT_FOUND);
        }
        final PagedList<ProductPurchasedHistoryView> listOfProductsDetailsFromDb = this.productPurchasedHistoryDAO.list(customerId, productId, httpRestQueryAdapter);
        if (CollectionUtils.isEmpty(listOfProductsDetailsFromDb.getItems())) {
            throw new MessageException("order.item.product.notFound",  HttpStatus.SC_NOT_FOUND);
        }
        final List<ProductPurchasedHistoryDTO> productDetails = formatProductDetailsFromView(listOfProductsDetailsFromDb);
        return getAllDetailsOfProduct(listOfProductsDetailsFromDb, productDetails);
    }

    /**
     * This method is used to get details from the service view to send it to the front end
     *
     * @param customerId {@link UUID} customer id
     * @param serviceId {@link UUID} service id
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter} to get a rest query data
     * @return {@link ServicePurchasedHistoryResponseDTO} with service's details
     */
    public ServicePurchasedHistoryResponseDTO getServicePurchasedHistoryResponse(final UUID customerId,
                                                                                 final UUID serviceId,
                                                                                 final HttpRestQueryAdapter httpRestQueryAdapter) {
        if (!customerOrderSummaryValidation.customerExists(customerId)) {
            throw new MessageException("order.customer.notFound", HttpStatus.SC_NOT_FOUND);
        }
        if (!customerOrderSummaryValidation.serviceExists(serviceId)) {
            throw new MessageException("order.service.serviceNotFound", HttpStatus.SC_NOT_FOUND);
        }
        final PagedList<ServicePurchasedHistoryView> listOfServicesDetailsFromDb = this.servicePurchasedHistoryDAO.list(customerId, serviceId, httpRestQueryAdapter);
        if (CollectionUtils.isEmpty(listOfServicesDetailsFromDb.getItems())) {
            throw new MessageException("order.service.serviceNotFound",  HttpStatus.SC_NOT_FOUND);
        }
        final List<ServicePurchasedHistoryDTO> serviceDetails = formatServiceDetailsFromView(listOfServicesDetailsFromDb);
        return getAllDetailsOfService(listOfServicesDetailsFromDb, serviceDetails);

    }

    /**
     * This method gets the lists of product details then insert into in Product Details DTO
     *
     * @param listOfProductsDetailsFromDb {@link ProductPurchasedHistoryView} that contains product's details
     * @return {@link ProductPurchasedHistoryDTO}
     */
    private List<ProductPurchasedHistoryDTO> formatProductDetailsFromView(final PagedList<ProductPurchasedHistoryView> listOfProductsDetailsFromDb) {
        return listOfProductsDetailsFromDb
                .getItems()
                .stream()
                .map(this::insertInformationInProductDetails)
                .collect(Collectors.toList());
    }

    /**
     * This method inserts information coming in from the view in the DTO class
     *
     * @param listOfServicesDetailsFromDb {@link ServicePurchasedHistoryView} that contains product's details
     * @return {@link ServicePurchasedHistoryDTO}
     */
    private List<ServicePurchasedHistoryDTO> formatServiceDetailsFromView(final PagedList<ServicePurchasedHistoryView> listOfServicesDetailsFromDb) {
        return listOfServicesDetailsFromDb
                .getItems()
                .stream()
                .map(this::insetInformationInServiceDetails)
                .collect(Collectors.toList());
    }

    /**
     * This method inserts information coming in from the view in the DTO class
     *
     * @param item {@link ProductPurchasedHistoryView}
     * @return {@link ProductPurchasedHistoryDTO}
     */
    private ProductPurchasedHistoryDTO insertInformationInProductDetails(final ProductPurchasedHistoryView item) {
        final ProductPurchasedHistoryDTO details = new ProductPurchasedHistoryDTO();
        details.setPurchaseDate(item.getOrderedAt());
        details.setSalesPrice(item.getNetValue());
        details.setQuantity(item.getQuantity());
        return details;
    }

    /**
     * This method inserts information coming in from the view in the DTO class
     *
     * @param item {@link ServicePurchasedHistoryView}
     * @return {@link ServicePurchasedHistoryDTO}
     */
    private ServicePurchasedHistoryDTO insetInformationInServiceDetails(final ServicePurchasedHistoryView item) {
        final ServicePurchasedHistoryDTO details = new ServicePurchasedHistoryDTO();
        details.setPurchaseDate(item.getOrderedAt());
        details.setSalesPrice(item.getSalesPrice());
        details.setQuantity(item.getTotalQuantity());
        return details;
    }

    /**
     * This method builds the details of product to send it for front end
     *
     * @param listOfProductsDetailsFromDb {@link ProductPurchasedHistoryView}
     * @param productDetails {@link ProductPurchasedHistoryDTO}
     * @return {@link ProductPurchasedHistoryResponseDTO}
     */
    private ProductPurchasedHistoryResponseDTO getAllDetailsOfProduct(final PagedList<ProductPurchasedHistoryView> listOfProductsDetailsFromDb,
                                                                      final List<ProductPurchasedHistoryDTO> productDetails) {
        final ProductPurchasedHistoryResponseDTO productPurchased = new ProductPurchasedHistoryResponseDTO();
        productPurchased.setId(listOfProductsDetailsFromDb.getItems().get(0).getProductId());
        productPurchased.setDescription(listOfProductsDetailsFromDb.getItems().get(0).getProductDescription());
        productPurchased.setPurchaseDetails(productDetails);
        productPurchased.setCount(listOfProductsDetailsFromDb.getCount());
        productPurchased.setPage(listOfProductsDetailsFromDb.getPage());
        productPurchased.setPageSize(listOfProductsDetailsFromDb.getPageSize());
        return productPurchased;
    }

    /**
     * This method builds the details of service to send it for front end
     *
     * @param listOfServicesDetailsFromDb {@link ServicePurchasedHistoryView}
     * @param serviceDetails {@link ServicePurchasedHistoryDTO}
     * @return {@link ServicePurchasedHistoryResponseDTO}
     */
    private ServicePurchasedHistoryResponseDTO getAllDetailsOfService(final PagedList<ServicePurchasedHistoryView> listOfServicesDetailsFromDb,
                                                                      final List<ServicePurchasedHistoryDTO> serviceDetails) {
        final ServicePurchasedHistoryResponseDTO servicePurchased = new ServicePurchasedHistoryResponseDTO();
        servicePurchased.setId(listOfServicesDetailsFromDb.getItems().get(0).getServiceId());
        servicePurchased.setDescription(listOfServicesDetailsFromDb.getItems().get(0).getServiceDescription());
        servicePurchased.setPurchaseDetails(serviceDetails);
        servicePurchased.setCount(listOfServicesDetailsFromDb.getCount());
        servicePurchased.setPage(listOfServicesDetailsFromDb.getPage());
        servicePurchased.setPageSize(listOfServicesDetailsFromDb.getPageSize());
        return servicePurchased;
    }

}
