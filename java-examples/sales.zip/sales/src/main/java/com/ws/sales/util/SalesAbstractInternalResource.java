package com.ws.sales.util;

import br.com.wealthsystems.server.resource.RecordPermissionResource;
import com.sollar.recordpermission.accessgroup.PermissionChangesQuery;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.AbstractInternalResource;
import com.ws.commons.server.resource.ResourceUtils;
import io.ebean.EbeanServer;
import org.apache.shiro.SecurityUtils;

import javax.inject.Inject;
import java.lang.reflect.ParameterizedType;
import java.util.UUID;

import static com.ws.commons.server.resource.HTTPHeaders.USER_ROLE_INTEGRATION;

/**
 * @author Ademar Junior <ademar.junior@wssim.com.br/>
 * @since 7.0.0 - 2018-12-11
 */
public abstract class SalesAbstractInternalResource <T extends BaseModel>
        extends AbstractInternalResource<T> implements RecordPermissionResource<T> {

    @Inject
    private PermissionChangesQuery permissionChangesQuery;

    @Inject
    private EbeanServer ebeanServer;


    @Override
    public PermissionChangesQuery getPermissionChangesQuery() {
        return permissionChangesQuery;
    }


    @Override
    @SuppressWarnings("unchecked")
    public Class<T> getEntityClass() {
        return (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }


    @Override
    public EbeanServer getEbeanServer() {
        return ebeanServer;
    }


    @Override
    public void checkPermission() {
        ResourceUtils.requireHeader(USER_ROLE_INTEGRATION.getHeaderName(), USER_ROLE_INTEGRATION.getHeaderValue(), httpRequest);
    }


    @Override
    public UUID getUserId() {
        final Object id = SecurityUtils.getSubject().getSession().getAttribute(Constants.FIELD_USER_ID_CONTEXT);
        return id instanceof String ? UUID.fromString((String) id) : null;
    }
}
