package com.ws.sales.orderservice.dto;

import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.product.dto.ServiceDTO;
import com.ws.sales.orderservice.ERecurrenceType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
public class SalesOrderServiceDTO implements DefaultPojoConverter, Serializable {

    private UUID id;

    @PojoColumnsMapper({
        @PojoColumnMapper(source = "service.id", target = "serviceId"),
        @PojoColumnMapper(source = "service.description", target = "serviceDescription"),
        @PojoColumnMapper(source = "service.code", target = "serviceCode"), })
    private ServiceDTO service;

    private ERecurrenceType recurrenceType;

    private BigDecimal originalPrice;

    private BigDecimal salesPrice;

    private BigDecimal quantity;

    private BigDecimal repetitions;

    private BigDecimal totalQuantity;

    private BigDecimal totalValue;

    private BigDecimal discount;

    private BigDecimal discountPercentage;

    private BigDecimal increaseValue;

    private BigDecimal increasePercentage;

    private String externalId;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public ServiceDTO getService() {
        return service;
    }

    public void setService(final ServiceDTO service) {
        this.service = service;
    }

    public ERecurrenceType getRecurrenceType() {
        return recurrenceType;
    }

    public void setRecurrenceType(final ERecurrenceType recurrenceType) {
        this.recurrenceType = recurrenceType;
    }

    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(final BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(final BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(final BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getRepetitions() {
        return repetitions;
    }

    public void setRepetitions(final BigDecimal repetitions) {
        this.repetitions = repetitions;
    }

    public BigDecimal getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(final BigDecimal totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public BigDecimal getTotalValue() {
        return totalValue;
    }

    public void setTotalValue(final BigDecimal totalValue) {
        this.totalValue = totalValue;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(final BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(final BigDecimal discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public BigDecimal getIncreaseValue() {
        return increaseValue;
    }

    public void setIncreaseValue(final BigDecimal increaseValue) {
        this.increaseValue = increaseValue;
    }

    public BigDecimal getIncreasePercentage() {
        return increasePercentage;
    }

    public void setIncreasePercentage(final BigDecimal increasePercentage) {
        this.increasePercentage = increasePercentage;
    }

}
