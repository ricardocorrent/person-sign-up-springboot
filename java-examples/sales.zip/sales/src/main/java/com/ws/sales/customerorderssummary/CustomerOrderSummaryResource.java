package com.ws.sales.customerorderssummary;

import com.ws.commons.interceptor.sourceannotation.ConversionProduces;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.sales.customerorderssummary.orderssummary.CustomerOrdersSummary;
import com.ws.sales.customerorderssummary.productpurchased.dto.ProductPurchasedHistoryResponseDTO;
import com.ws.sales.customerorderssummary.productspurchased.dto.ProductsPurchasedResponseDTO;
import com.ws.sales.customerorderssummary.servicepurchased.dto.ServicePurchasedHistoryResponseDTO;
import com.ws.sales.customerorderssummary.servicespurchased.dto.ServicesPurchasedResponseDTO;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
@Path("/customer-orders")
public class CustomerOrderSummaryResource {

    private final CustomerOrdersSummaryService customerOrdersSummaryService;

    @Inject
    public CustomerOrderSummaryResource(final CustomerOrdersSummaryService customerOrdersSummaryService) {
        this.customerOrdersSummaryService = customerOrdersSummaryService;
    }

    /**
     * This resources is used to find information about the customer's sales orders.
     * These dates are searched in the database using a sql query then mapped on SQL Entity to be returned
     *
     * @param id {@link UUID} the customer id
     * @return {@link CustomerOrdersSummary} whit the dates of sales orders from customer
     */
    @GET
    @Path("/{id}/summary")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(CustomerOrdersSummary.class)
    public Response summary(@PathParam("id") final String id) {
        return Response.ok().entity(customerOrdersSummaryService.getSummary(UUID.fromString(id))).build();
    }

    /**
     * This resource finds the customer's products purchased getting the informations about each one
     *
     * @param id {@link UUID} the customer id
     * @param restQuery {@link HttpServletRequest}
     * @return {@link ProductsPurchasedResponseDTO}
     */
    @GET
    @Path("/{id}/product-purchased-history")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(ProductsPurchasedResponseDTO.class)
    public Response summaryProducts(@PathParam("id") final String id,
                                    @Context final HttpServletRequest restQuery) {
        return Response
                .ok()
                .entity(customerOrdersSummaryService
                        .getProductsPurchasedResponse(UUID.fromString(id), new HttpRestQueryAdapter(restQuery)))
                .build();
    }

    /**
     * This resource finds the customer's product purchased getting the informations just about it
     *
     * @param id {@link UUID} the customer id
     * @param productId {@link UUID} the product id
     * @return {@link ProductPurchasedHistoryResponseDTO}
     */
    @GET
    @Path("/{id}/product-purchased-history/{productId}")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(ProductPurchasedHistoryResponseDTO.class)
    public Response summaryProduct(@PathParam("id") final String id,
                                   @PathParam("productId") final String productId,
                                   @Context final HttpServletRequest restQuery) {
        return Response
                .ok()
                .entity(customerOrdersSummaryService
                        .getProductPurchasedHistoryResponse(
                                UUID.fromString(id), UUID.fromString(productId), new HttpRestQueryAdapter(restQuery)))
                .build();
    }

    /**
     * This resource finds the customer's services purchased getting the informations about each one
     *
     * @param id {@link UUID} the customer id
     * @param restQuery {@link HttpServletRequest}
     * @return {@link ServicesPurchasedResponseDTO}
     */
    @GET
    @Path("/{id}/service-purchased-history")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(ServicesPurchasedResponseDTO.class)
    public Response summaryServices(@PathParam("id") final String id,
                                    @Context final HttpServletRequest restQuery) {
        return Response
                .ok()
                .entity(customerOrdersSummaryService
                        .getServicesPurchasedResponse(UUID.fromString(id), new HttpRestQueryAdapter(restQuery)))
                .build();
    }

    /**
     * This resource finds the customer's service purchased getting the informations just about it
     *
     * @param id {@link UUID} the customer id
     * @param serviceId {@link UUID} the service id
     * @return {@link ServicePurchasedHistoryResponseDTO}
     */
    @GET
    @Path("/{id}/service-purchased-history/{serviceId}")
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionProduces(ServicePurchasedHistoryResponseDTO.class)
    public Response summaryService(@PathParam("id") final String id,
                                   @PathParam("serviceId") final String serviceId,
                                   @Context final HttpServletRequest restQuery) {
        return Response
                .ok()
                .entity(customerOrdersSummaryService
                        .getServicePurchasedHistoryResponse(
                                UUID.fromString(id), UUID.fromString(serviceId), new HttpRestQueryAdapter(restQuery)))
                .build();
    }

}
