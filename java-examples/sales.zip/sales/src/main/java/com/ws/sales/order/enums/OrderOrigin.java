package com.ws.sales.order.enums;

/**
 * @author Maykon Rissi
 * @since 2018-05-23
 * Enum for fill order's origin
 */
public enum OrderOrigin {
    EXT, WEB
}
