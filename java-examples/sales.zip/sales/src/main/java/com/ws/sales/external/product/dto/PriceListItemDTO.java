package com.ws.sales.external.product.dto;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.io.Serializable;
import java.util.UUID;

/**
 * Created by sergio.junior on 11/6/2017.
 */
public class PriceListItemDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private static final long serialVersionUID = 7509827713457878412L;

    private UUID id;

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(UUID id) {
        this.id = id;
    }

}
