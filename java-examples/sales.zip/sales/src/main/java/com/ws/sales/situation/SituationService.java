package com.ws.sales.situation;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * @author thyago.volpatto
 * @since v5.1.0 19/04/2017.
 */
public class SituationService extends AbstractService<Situation> {

    private final SituationDAO dao;

    @Inject
    public SituationService(SituationDAO dao) {
        super(dao);
        this.dao = dao;
    }

    /**
     * Filter and returns situations.
     *
     * @param search
     * @return
     */
    public PagedList<Situation> search(SituationSearch search) {
        return dao.list(search);
    }
}
