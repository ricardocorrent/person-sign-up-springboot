package com.ws.sales.customerorderssummary.productspurchased;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;
import io.ebean.RawSql;
import io.ebean.RawSqlBuilder;

import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
public class ProductsPurchasedSummaryDAO extends AbstractDAO<CustomerOrderHistoryProductsView> {

    private static final String BASE_QUERY =
            "select " +
                    "customer_id, " +
                    "product_id, " +
                    "product_code, " +
                    "product_description, " +
                    "max_value, " +
                    "max_quantity, " +
                    "last_purchase_date " +
                    "from (" +
                    "select " +
                    "customer_id, " +
                    "product_id, " +
                    "product_code, " +
                    "product_description, " +
                    "max(item_net_value) as max_value, " +
                    "max(item_quantity) as max_quantity, " +
                    "max(last_purchase_date) as last_purchase_date " +
                    "from " +
                    "customer_order_history_products_view " +
                    "where " +
                    "customer_id = :customerId " +
                    "group by " +
                    "customer_id, " +
                    "product_id, " +
                    "product_code, " +
                    "product_description) as customer_order_history_products_view";

    /**
     * Returns the entity class declared in this class.
     *
     * @return The entity class declared as parameterized type at this class.
     */
    @Override
    public Class<CustomerOrderHistoryProductsView> getEntityClass() {
        return CustomerOrderHistoryProductsView.class;
    }

    /**
     * This method uses a sql to find on a view, informations about the customer's products
     *
     * @param customerId {@link UUID}
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return a {@link PagedList} of {@link CustomerOrderHistoryProductsView}
     */
    public PagedList<CustomerOrderHistoryProductsView> list(final UUID customerId,
                                                            final HttpRestQueryAdapter httpRestQueryAdapter) {
        final Query<CustomerOrderHistoryProductsView> query = ebeanServer.find(CustomerOrderHistoryProductsView.class);
        final RawSql rawSql = RawSqlBuilder.parse(BASE_QUERY).create();
        query.setRawSql(rawSql).setParameter("customerId", customerId);
        return getPagedList(query, httpRestQueryAdapter);
    }

}
