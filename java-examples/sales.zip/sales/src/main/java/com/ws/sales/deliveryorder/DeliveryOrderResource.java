package com.ws.sales.deliveryorder;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.interceptor.sourceannotation.ConversionProduces;
import com.ws.commons.server.Id;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.util.Constants;
import com.ws.sales.deliveryorder.dto.DeliveryDTO;
import com.ws.sales.order.SalesOrder;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * SubResource from sales to handle deliveries
 *
 * @author Maykon Rissi
 * @since v6.0.0 2018-08-18
 */
@Path("/orders/{orderId}/deliveries")
public class DeliveryOrderResource {

    private final DeliveryOrderService deliveryOrderService;

    /**
     * @param deliveryOrderService to handle delivery's logic
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Inject
    public DeliveryOrderResource(final DeliveryOrderService deliveryOrderService) {
        this.deliveryOrderService = deliveryOrderService;
    }

    /**
     * Creates a new SalesOrder and set the delivery's object to handle the entity map
     * Set the id of the object by taking the URL param
     *
     * @param deliveryOrder set the new Order as an object
     * @param orderId       to fill the orderId
     * @param deliveryId    to fill the id of the entity
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private void doSetPathParamsInDelivery(final UUID orderId, final UUID deliveryId, final DeliveryOrder deliveryOrder) {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(orderId);
        deliveryOrder.setSalesOrder(salesOrder);
        deliveryOrder.setId(deliveryId);
    }

    /**
     * POST /sales/orders/{orderId}/deliveries <br />
     * Example of a simple json to send:
     * <pre>
     *    {
     *      "location":{
     *          "id":"2e3b15dc-ec13-45a4-a9e1-f644490585a2",
     *  *       "description":"Location"
     *      },
     *      "shipmentDate":"2018-08-13",
     *      "deliveryDate":"2018-08-13",
     *      "observation":null,
     *      "incoterms":{
     *         "id":"fd17b2fe-d425-4880-aedd-0c29fdc04731",
     *         "acronym":"FOB"
     *      },
     *      "freightValue":null
     *    }
     * </pre>
     *
     * @param orderId to set the entity Order
     * @param obj     to persist
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @POST
    @ConversionConsumes(DeliveryDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(Constants.SALES_PERMISSION_WRITE)
    public Response insertDelivery(@PathParam(Constants.FIELD_ORDER_ID) final UUID orderId, @Consumer final DeliveryOrder obj) throws Exception {
        this.doSetPathParamsInDelivery(orderId, null, obj);
        return Response.status(Response.Status.CREATED).entity(new Id(this.deliveryOrderService.insert(obj))).build();
    }

    /**
     * @param orderId to check if the delivery belongs to the order
     * @param id      to get the entity
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @GET
    @Path("/{id}")
    @ConversionProduces(DeliveryDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(Constants.SALES_PERMISSION_READ)
    public Response getDelivery(@PathParam(Constants.FIELD_ORDER_ID) final UUID orderId, @PathParam(Constants.FIELD_ID) final UUID id) {
        final DeliveryOrder deliveryOrder = this.deliveryOrderService.getDeliverySearchingByOrder(orderId, id);
        return Response.ok().entity(deliveryOrder).build();
    }

    /**
     * @param orderId to check if the delivery belongs to the order
     * @param id      to delete the entity
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @DELETE
    @Path("/{id}")
    @RequiresPermissions(Constants.SALES_PERMISSION_DELETE)
    public Response delete(@PathParam(Constants.FIELD_ORDER_ID) final UUID orderId, @PathParam(Constants.FIELD_ID) final UUID id) throws Exception {
        this.deliveryOrderService.deleteDeliveryUsingOrder(orderId, id);
        return Response.ok().build();
    }

    /**
     * PUT /sales/orders/{orderId}/deliveries/{deliveryId} <br />
     * Example of a simple json to send:
     * <pre>
     *    {
     *      "location":{
     *          "id":"2e3b15dc-ec13-45a4-a9e1-f644490585a2",
     *  *       "description":"Location"
     *      },
     *      "shipmentDate":"2018-08-13",
     *      "deliveryDate":"2018-08-13",
     *      "observation":null,
     *      "incoterms":{
     *         "id":"fd17b2fe-d425-4880-aedd-0c29fdc04731",
     *         "acronym":"FOB"
     *      },
     *      "freightValue":null
     *    }
     * </pre>
     *
     * @param orderId to set the entity Order
     * @param obj     to persist
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @PUT
    @Path("/{id}")
    @ConversionConsumes(DeliveryDTO.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(Constants.SALES_PERMISSION_WRITE)
    public Response updateDelivery(@PathParam(Constants.FIELD_ORDER_ID) final UUID orderId,
                                   @PathParam(Constants.FIELD_ID) final UUID id,
                                   @Consumer final DeliveryOrder obj) throws Exception {
        this.doSetPathParamsInDelivery(orderId, id, obj);
        this.deliveryOrderService.update(obj);
        return Response.ok().build();
    }

    /**
     * @param orderId to set the search
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    @GET
    @ConversionProduces(DeliveryDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresPermissions(Constants.SALES_PERMISSION_READ)
    public Response searchDeliveryByOrder(@PathParam(Constants.FIELD_ORDER_ID) final UUID orderId) {
        final PagedList<DeliveryOrder> deliveries = this.deliveryOrderService.findBySalesOrder(orderId);
        return Response.ok().entity(deliveries).build();
    }
}
