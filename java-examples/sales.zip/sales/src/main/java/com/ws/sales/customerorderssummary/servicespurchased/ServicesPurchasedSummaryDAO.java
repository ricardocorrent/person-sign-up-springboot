package com.ws.sales.customerorderssummary.servicespurchased;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;
import io.ebean.RawSql;
import io.ebean.RawSqlBuilder;

import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
public class ServicesPurchasedSummaryDAO extends AbstractDAO<CustomerOrderHistoryServicesView> {

    private static final String BASE_QUERY =
            "select " +
                    "customer_id, " +
                    "service_id, " +
                    "service_code, " +
                    "service_description, " +
                    "max_value, " +
                    "max_quantity, " +
                    "last_purchase_date " +
                    "from (" +
                    "select " +
                    "customer_id, " +
                    "service_id, " +
                    "service_code, " +
                    "service_description, " +
                    "max(service_net_value) as max_value, " +
                    "max(service_quantity) as max_quantity, " +
                    "max(last_purchase_date) as last_purchase_date " +
                    "from " +
                    "customer_order_history_services_view " +
                    "where " +
                    "customer_id = :customerId " +
                    "group by " +
                    "customer_id, " +
                    "service_id, " +
                    "service_code, " +
                    "service_description)as customer_order_history_services_view";

    /**
     * Returns the entity class declared in this class.
     *
     * @return The entity class declared as parameterized type at this class.
     */
    @Override
    public Class<CustomerOrderHistoryServicesView> getEntityClass() {
        return CustomerOrderHistoryServicesView.class;
    }

    /**
     * This method uses a sql to find on a view, informations about the customer's services
     *
     * @param customerId {@link UUID}
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return a {@link PagedList} of {@link CustomerOrderHistoryServicesView}
     */
    public PagedList<CustomerOrderHistoryServicesView> list(final UUID customerId,
                                                            final HttpRestQueryAdapter httpRestQueryAdapter) {
        final Query<CustomerOrderHistoryServicesView> query = ebeanServer.find(CustomerOrderHistoryServicesView.class);
        final RawSql rawSql = RawSqlBuilder.parse(BASE_QUERY).create();
        query.setRawSql(rawSql).setParameter("customerId", customerId);
        return getPagedList(query, httpRestQueryAdapter);
    }

}
