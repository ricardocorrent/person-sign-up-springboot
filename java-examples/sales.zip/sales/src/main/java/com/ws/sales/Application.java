package com.ws.sales;

import org.glassfish.jersey.server.ResourceConfig;

import com.ws.commons.server.ApplicationConfig;
import com.ws.sales.exception.JacksonConversionInterceptorExceptionMapper;
import com.ws.sales.exception.mapper.NotAllowedExceptionMessageMapper;
import com.ws.sales.exception.mapper.PojoConversionInterceptorExceptionMapper;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 * @author william.santos
 * @since V7.0.0 - 2018-09-20
 * @version V 2.0.0
 */
public class Application extends ResourceConfig {

    /**
     * Method constructor
     * set jersey Configuration
     */
    public Application() {
        final ApplicationConfig config = ApplicationConfig.setResourceConfig(this);
        config.registerPackage(getClass().getPackage().getName());
        config.register(NotAllowedExceptionMessageMapper.class);
        config.register(JacksonConversionInterceptorExceptionMapper.class);
        config.register(PojoConversionInterceptorExceptionMapper.class);
        config.configureJersey();
    }
}