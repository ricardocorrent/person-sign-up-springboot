package com.ws.sales.validator;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import com.ws.sales.util.Constants;
import io.ebean.EbeanServer;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * @author Maykon Roberto Rissi {@literal maykon.rissi@wssim.com.br}
 * @since 7.0.0 - 2018-19-12
 */
public class CommonValidation {

    private final EbeanServer ebeanServer;

    /**
     * @param ebeanServer to perform search's in the database
     */
    @Inject
    public CommonValidation(final EbeanServer ebeanServer) {
        this.ebeanServer = ebeanServer;
    }

    /**
     * <p>
     * Uses {@link EbeanServer#find(Class, Object)} to perform a get in
     * the entity and validate if it exists. If it exists, it will call the
     * {@link this#doValidateIfEntityIsActive(Object, Class)} to validate
     * if it has active field and check if it is true.
     *
     * @param id    to find the entity
     * @param clazz {@link Class} from the entity
     * @return {@link LogicError}
     */
    public LogicError doValidateIfEntityCanBeUsed(final UUID id, final Class clazz) {
        Objects.requireNonNull(id);
        Objects.requireNonNull(clazz);
        final Object object = this.ebeanServer.find(clazz, id);
        if (object != null) {
            return this.doValidateIfEntityIsActive(object, clazz);
        } else {
            return new LogicError(clazz.getSimpleName(), Constants.MESSAGE_REGISTER_NOT_FOUND);
        }
    }

    /**
     * <p>
     * Uses an object and his class to check with reflection and
     * the {@link this#doCheckIfActiveFieldExists(Class)} the field active.
     * If exists, it will validate if is field is false
     *
     * @param object to get the field by reflection
     * @param clazz  {@link Class} from the entity
     * @return {@link LogicError}
     */
    public LogicError doValidateIfEntityIsActive(final Object object, final Class clazz) {
        Objects.requireNonNull(object);
        Objects.requireNonNull(clazz);
        return Optional.of(clazz)
                .filter(this::doCheckIfActiveFieldExists)
                .map(clazzWithActive -> FieldReflectionHelper.fromInstance(object).getFieldValue(Constants.FIELD_ACTIVE))
                .filter(Boolean.FALSE::equals)
                .map(isInactive -> new LogicError(clazz.getSimpleName(), Constants.MESSAGE_REGISTER_INACTIVE))
                .orElse(null);
    }

    /**
     * @param clazz {@link Class} from the entity
     * @return {@link Boolean}
     */
    private Boolean doCheckIfActiveFieldExists(final Class clazz) {
        return Arrays.stream(clazz.getDeclaredFields()).anyMatch(field -> Constants.FIELD_ACTIVE.equals(field.getName()));
    }
}
