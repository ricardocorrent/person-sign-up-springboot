package com.ws.sales.external.integrationhub.documentsign.get;

import java.util.List;

/**
 * This class has been created to implement a response coming from the integration
 * about the information of the signed document
 *
 * @since 1.0.0 2019-05-10
 *
 * @author Ricardo Corrent
 */
public class DigitalDocSignatureResponse {

    private DigitalDocSignatureDocument document;

    private List<DigitalDocSignatureSignatories> signatories;

    public DigitalDocSignatureDocument getDocument() {
        return document;
    }

    public void setDocument(DigitalDocSignatureDocument document) {
        this.document = document;
    }

    public List<DigitalDocSignatureSignatories> getSignatories() {
        return signatories;
    }

    public void setSignatories(List<DigitalDocSignatureSignatories> signatories) {
        this.signatories = signatories;
    }
}
