package com.ws.sales.deliveryorder;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;

import java.util.Optional;

/**
 * @author Samuel Blum Vorpagel
 * @author Maykon Rissi
 * @version 6.0.0 2018-08-13
 * @since 2017-02-20
 */
public class DeliveryOrderDAO extends AbstractDAO<DeliveryOrder> {

    /**
     * @author Samuel Blum Vorpagel
     * @see AbstractDAO#getEntityClass()
     * @since 2017-02-20
     */
    @Override
    public Class<DeliveryOrder> getEntityClass() {
        return DeliveryOrder.class;
    }

    /**
     * @param search to fill the query
     * @return PagedList<DeliveryOrder> of registers that match the query
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-13
     */
    public PagedList<DeliveryOrder> search(final DeliveryOrderSearch search) {
        final Query<DeliveryOrder> query = this.find();
        Optional.ofNullable(search.getId()).ifPresent(id -> query.where().eq("id", id));
        Optional.ofNullable(search.getOrderId()).ifPresent(orderId -> query.where().eq("salesOrder.id", orderId));
        return this.getPagedList(query, search);
    }
}
