package com.ws.sales.documents;

import br.com.wealthsystems.cloud.documentmanager.template.TemplateResource;
import com.ws.commons.integration.IntegrationException;
import com.ws.commons.integration.ResponseUtils;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.validation.exception.MessageException;
import com.ws.sales.documents.dto.TemplateDTO;
import com.ws.sales.documents.integration.DocumentCreator;
import com.ws.sales.documents.integration.DocumentIntegrationResource;
import java.util.UUID;

import com.ws.sales.external.AbstractGateway;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.io.InputStream;

/**
 * Gateway to DocumentManager
 *
 * @since 1.0.0 - 2019-03-18
 * @version 8.3.0 - 2019-05-08
 *
 * @author Dante Basso <dante.basso@wssim.com.br>.
 * @author ricardo.corrent
 */
public class DocumentGateway extends AbstractGateway {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    @ConfigProperty(name = "integration.address")
    private String integrationAddress;

    @InjectProxy
    private DocumentIntegrationResource documentResource;

    @InjectProxy
    private TemplateResource templateResource;

    /**
     * Create a Document in Document Manager
     *
     * @param documentCreator
     * @return {@link Document}
     */
    public Document create(final DocumentCreator documentCreator) {
        final Document document = new Document();
        try {
            final Response response = documentResource.create(documentCreator);
            final int statusCode = response.getStatus();
            if (Response.Status.Family.SUCCESSFUL != Response.Status.Family.familyOf(statusCode)) {
                final String messageError = ResponseUtils.getEntity(response, String.class);
                this.log.error("Error in request to document-manager: {}", messageError);
                throw new MessageException("document.creation.error", statusCode, messageError);
            }
            if (response.getHeaders().containsKey(HttpHeaders.CONTENT_DISPOSITION)) {
                final String filename = response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION);
                document.setFilename(filename);
            }
            final InputStream inputStream = (InputStream) response.getEntity();
            document.setStream(inputStream);
        } catch (IntegrationException integrationException) {
            final int statusCode = integrationException.status();
            final String messageError = integrationException.getMessage().substring(integrationException.getMessage().indexOf("Content") + 9);
            this.log.error("Error in request to document-manager: {}", messageError);
            throw new MessageException("document.creation.error", statusCode, messageError);

        }
        return document;
    }

    /**
     * This method get a template using {@link Response} from {@link TemplateResource}.
     *
     * @since  1.1.0 - 2019-05-10
     *
     * @author ricardo.corrent
     *
     * @param templateId {@link UUID}
     * @return {@link TemplateDTO} with id {@link UUID} and description {@link String}
     */
    public TemplateDTO getTemplate(final UUID templateId) {
        final Response response = templateResource.get(templateId.toString());
        if (response.getStatus() == HttpStatus.SC_OK) {
            return getEntityFromResponse(response, TemplateDTO.class);
        }
        if (response.getStatus() == HttpStatus.SC_NOT_FOUND) {
            return null;
        }
        throw new MessageException("document.creation.error", response.getStatus());
    }
}
