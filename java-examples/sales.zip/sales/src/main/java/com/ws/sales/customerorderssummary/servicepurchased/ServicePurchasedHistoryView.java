package com.ws.sales.customerorderssummary.servicepurchased;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
@Getter
@Setter
@Entity
@Table(name = "service_purchased_history_view")
public class ServicePurchasedHistoryView implements DefaultPojoConverter, Identification<UUID> {

    private UUID id;

    private UUID customerId;

    private UUID salesOrderId;

    private UUID serviceId;

    private String serviceDescription;

    private OffsetDateTime updatedAt;

    private OffsetDateTime orderedAt;

    private BigDecimal salesPrice;

    private BigDecimal totalQuantity;

}
