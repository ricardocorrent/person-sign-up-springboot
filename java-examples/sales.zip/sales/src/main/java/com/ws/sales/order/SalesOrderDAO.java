package com.ws.sales.order;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.pagination.Sort;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.util.Constants;
import io.ebean.ExpressionList;
import io.ebean.Junction;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
public class SalesOrderDAO extends AbstractDAO<SalesOrder> {

    private final static String EN_DATE_FORMAT = "MM/dd/yyyy";
    private final static String DATE_FORMAT = "dd/MM/yyyy";
    private final static String DRAFT = "DRAFT RASCUNHO";
    private final static String FINALIZED = "FINALIZED FINALIZADO";

    private static final String DRAFT_COLUMN = "draft";
    private static final String ORDERED_AT_COLUMN = "createdAt";

    private final Logger logger = LoggerFactory.getLogger(SalesOrderDAO.class);

    private final OrderParameterDAO orderParameterDAO;

    @Inject
    public SalesOrderDAO(final OrderParameterDAO orderParameterDAO) {
        this.orderParameterDAO = orderParameterDAO;
    }


    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class<SalesOrder> getEntityClass() {
        return SalesOrder.class;
    }

    /**
     * Returns a list of orders.
     *
     * @param search
     * @return PagedList<SalesOrder>
     */
    public PagedList<SalesOrder> list(final SalesOrderSearch search) {

        final Query<SalesOrder> query = find();

        ExpressionList<SalesOrder> where = query.where();

        this.applyGeneralSearchSituationFilters(search, where);

        Boolean export = search.getToExport();
        if (export != null && export) {
            where.eq(DRAFT_COLUMN, Boolean.FALSE).isNull("situationId");
        }

        if (!StringUtils.isEmpty(search.getOrderNumber())) {
            where.icontains("orderNumber", search.getOrderNumber());
        }

        if (!StringUtils.isEmpty(search.getCustomerNumber())) {
            where.icontains("customerNumber", search.getCustomerNumber());
        }

        if (search.getDraft() != null && search.getDraft().length > 0) {
            where.eq(DRAFT_COLUMN, search.getDraft()[0]);
        }

        configureDateFilters(where, search);

        if (search.getCustomerId() != null) {
            where.in("customerId", search.getCustomerId());
        }

        if (search.getLocationId() != null) {
            where.in("locationId", search.getLocationId());
        }

        if (search.getUserId() != null) {
            where.in("userId", search.getUserId());
        }

        final Sort sort = new Sort();
        sort.setField(ORDERED_AT_COLUMN);
        sort.setDir("desc");
        search.setSort(Collections.singletonList(sort));

        return getPagedList(query, search);
    }

    private void applyGeneralSearchSituationFilters(final SalesOrderSearch search, ExpressionList<SalesOrder> where) {
        final String generalSearch = search.getGeneralSearch();
        if (StringUtils.isNotBlank(generalSearch)) {
            final Junction<SalesOrder> or = where.or();
            if (DRAFT.contains(generalSearch.toUpperCase())) {
                or.eq(DRAFT_COLUMN, Boolean.TRUE);
            } else if (FINALIZED.contains(generalSearch.toUpperCase())) {
                or.eq(DRAFT_COLUMN, Boolean.FALSE);
            }

            or.icontains("orderNumber", generalSearch)
                    .icontains("externalNumber", generalSearch)
                    .icontains("customerName", generalSearch);

            filterByOrderedAt(generalSearch, or, search.getLanguage());
        } else {
            final Junction<SalesOrder> and = where.and();
            final Integer syncDays = Integer.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_ORDER_FILTER_DAYS).getValue());
            final OffsetDateTime nowMinusDaysForFilter = OffsetDateTime.now().minusDays(syncDays);
            and.ge(ORDERED_AT_COLUMN, nowMinusDaysForFilter);
        }
    }

    /**
     * Set the Date filter options to the query
     *
     * @param where  {@link ExpressionList}
     * @param search {@link SalesOrderSearch}
     */
    private void configureDateFilters(final ExpressionList<SalesOrder> where, final SalesOrderSearch search) {
        LocalDate initialDate = search.getInitialOrderedDate();
        LocalDate finalDate = search.getFinalOrderedDate();

        if (initialDate != null) {
            LocalDateTime dateOne = initialDate.atTime(0, 0, 0);
            where.ge(ORDERED_AT_COLUMN, dateOne);
        }
        if (finalDate != null) {
            LocalDateTime dateTwo = finalDate.atTime(23, 59, 59);
            where.le(ORDERED_AT_COLUMN, dateTwo);
        }

        OffsetDateTime invoicedStartDate = search.getInvoicedStartDate();
        OffsetDateTime invoicedFinalDate = search.getInvoicedFinalDate();

        if (invoicedStartDate != null && invoicedFinalDate != null) {
            if (invoicedStartDate.isBefore(invoicedFinalDate)) {
                where.between("invoicedAt", invoicedStartDate, invoicedFinalDate);
            }
        }
    }

    /**
     * Returns the last sale's value for this customer, location and user.
     * If one of this options is empty returns a empty list.
     *
     * @param search
     * @return PagedList<SalesOrder>
     * @author Thyago Volpatto
     * @since v1.0.0 2016-09-02.
     */
    public PagedList<SalesOrder> lastSaleValue(final SalesOrderSearch search) {
        final Query<SalesOrder> query = find();

        final ExpressionList<SalesOrder> where = query.where();

        PagedList<SalesOrder> lastSale = new PagedList<>();
        if (search.getCustomerId() != null && search.getLocationId() != null && search.getUserId() != null) {
            where.eq("customerId", search.getCustomerId()).eq("locationId", search.getLocationId())
                    .eq("userId", search.getUserId()).order().desc(ORDERED_AT_COLUMN).setMaxRows(1);
            lastSale = getPagedList(query, search);

        }
        return lastSale;

    }

    /**
     * Filter the orders by the field orderedAt
     *
     * @param dateString
     * @param or
     */
    private void filterByOrderedAt(final String dateString, final Junction<SalesOrder> or, final String language) {
        String format = EN_DATE_FORMAT;
        String ptLanguage = "pt-BR";
        if (StringUtils.isNotBlank(language) && ptLanguage.equalsIgnoreCase(language)) {
            format = DATE_FORMAT;
        }
        try {
            DateFormat df = new SimpleDateFormat(format);
            df.setLenient(false);
            Date date = df.parse(dateString);
            LocalDate orderedAt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDateTime initialDate = orderedAt.atStartOfDay();
            LocalDateTime finalDate = orderedAt.atTime(23, 59, 59);

            or.between(ORDERED_AT_COLUMN, initialDate, finalDate);
        } catch (ParseException e) {
            // isn t a valid date to filter.
            logger.info(e.getMessage());
        }
    }

    /**
     * Returns true if the Order is a valid one or false if is not.
     *
     * @param id
     * @return java.lang.Boolean
     */
    public Boolean salesOrderExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }

    /**
     * This method finds the last order from customer
     *
     * @since 8.5.0 2019-06-11
     * @author Ricardo Corrent
     *
     * @param customerId {@link UUID} used to find
     * @return {@link SalesOrder}
     */
    public SalesOrder getLastSalesOrder(final UUID customerId) {
        return find()
                .fetch("items")
                .fetch("services")
                .where().eq("customerId", customerId)
                .where().eq("draft", false)
                .order().desc("orderedAt")
                .setMaxRows(1)
                .findOne();
    }

}
