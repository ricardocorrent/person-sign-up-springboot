package com.ws.sales.external.product.dto;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.io.Serializable;
import java.util.UUID;

/**
 * Created by sergio.junior on 10/11/2017.
 */
public class PackagingDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private static final long serialVersionUID = 5805517828106770878L;

    private UUID id;

    private String description;

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
