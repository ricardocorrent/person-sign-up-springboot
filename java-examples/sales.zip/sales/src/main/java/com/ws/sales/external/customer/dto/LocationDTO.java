package com.ws.sales.external.customer.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

public class LocationDTO extends BaseDTO implements DefaultPojoConverter {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
