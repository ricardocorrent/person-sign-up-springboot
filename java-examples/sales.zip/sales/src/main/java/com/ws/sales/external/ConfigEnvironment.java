package com.ws.sales.external;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * Configuration environment.
 *
 * @author Alan J. A. Pena.
 * @since 2019-07-08.
 */
@Configuration
public interface ConfigEnvironment {

    @ConfigProperty(name = "config.environment")
    String getEnvironment();
}