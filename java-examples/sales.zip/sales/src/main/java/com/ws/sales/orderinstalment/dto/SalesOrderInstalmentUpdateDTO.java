package com.ws.sales.orderinstalment.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public class SalesOrderInstalmentUpdateDTO implements DefaultPojoConverter {

    private UUID id;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate dueDate;

    private BigDecimal value;

    private String externalId;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
}
