package com.ws.sales.invoicesituation;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * This class represents the persistence layer of Invoice Situation, with she it's possible make methods to
 * interact with the database.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-28
 */
public class InvoiceSituationDAO extends AbstractDAO<InvoiceSituation> {

    /**
     * This method override the getEntityClass for InvoiceSituation.
     *
     * @return invoice situation
     */
    @Override
    public Class getEntityClass() {
        return InvoiceSituation.class;
    }

    /**
     * Method to search a list of Invoice Situation by filter.
     *
     * @param invoiceSituationSearch the invoice situation search contains filters to apply on where clause
     * @return a paged list of invoice situation
     */
    public PagedList<InvoiceSituation> search(final InvoiceSituationSearch invoiceSituationSearch) {

        final Query<InvoiceSituation> query = find();
        ExpressionList<InvoiceSituation> where = query.where();

        addIdCondition(invoiceSituationSearch, where);

        addDescriptionCondition(invoiceSituationSearch, where);

        addActiveCondition(invoiceSituationSearch, where);

        return getPagedList(query, invoiceSituationSearch);
    }

    /**
     * This method set the id for the where clause.
     *
     * @param invoiceSituationSearch the invoice situation search contains filters to apply on where clause
     * @param where                  where for search
     */
    private void addIdCondition(final InvoiceSituationSearch invoiceSituationSearch, ExpressionList<InvoiceSituation> where) {

        if (invoiceSituationSearch.getId() != null) {
            where.eq("id", invoiceSituationSearch.getId());
        }
    }

    /**
     * This method set the description for the where clause.
     *
     * @param invoiceSituationSearch the invoice situation search contains filters to apply on where clause
     * @param where                  where for search
     */
    private void addDescriptionCondition(final InvoiceSituationSearch invoiceSituationSearch, ExpressionList<InvoiceSituation> where) {

        if (!StringUtils.isEmpty(invoiceSituationSearch.getDescription())) {
            where.icontains("description", invoiceSituationSearch.getDescription());
        }
    }

    /**
     * This method set the active for the where clause.
     *
     * @param invoiceSituationSearch the invoice situation search contains filters to apply on where clause
     * @param where                  where for search
     */
    private void addActiveCondition(final InvoiceSituationSearch invoiceSituationSearch, ExpressionList<InvoiceSituation> where) {

        if (invoiceSituationSearch.getActive() != null) {
            where.eq("active", invoiceSituationSearch.getActive());
        }
    }

    /**
     * Returns true if the Invoice Situation exists or false if not.
     *
     * @param id id of invoice situation
     * @return true if invoice situation exists and false if not
     */
    public Boolean invoiceSituationExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }
}