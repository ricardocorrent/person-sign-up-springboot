package com.ws.sales.ordertreatment;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.AbstractResource;
import com.ws.sales.util.SalesAbstractResource;
import com.ws.sales.ordertreatment.dto.OrderTreatmentDTO;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
@Path("/order-treatments")
public class OrderTreatmentResource extends SalesAbstractResource<OrderTreatment, OrderTreatmentSearch> {

    private final OrderTreatmentService orderTreatmentService;

    /**
     * @param orderTreatmentService to perform logic and update actions
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Inject
    public OrderTreatmentResource(final OrderTreatmentService orderTreatmentService) {
        this.orderTreatmentService = orderTreatmentService;
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param parameters entity with attributes for pagination search
     * @return PagedList
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    @RequiresPermissions("sales:order-treatments:read")
    public Response search(final OrderTreatmentSearch parameters) {
        return Response.status(HttpStatus.SC_OK).entity(orderTreatmentService.search(parameters)).build();
    }

    /**
     * @author Maykon Rissi
     * @see AbstractResource#insert(SoftDeleteBaseEntity)
     * @since v5.22.0 2018-06-18
     **/
    @POST
    @Override
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderTreatmentDTO.class)
    public Response insert(final @Consumer @javax.validation.Valid OrderTreatment obj) throws Exception {
        return super.insert(obj);
    }

    /**
     * @author Maykon Rissi
     * @see AbstractResource#update(UUID, BaseModel)
     * @since v5.22.0 2018-06-18
     **/
    @PUT
    @Override
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @ConversionConsumes(OrderTreatmentDTO.class)
    public Response update(final @PathParam("id") UUID id,
                           final @Consumer @Valid OrderTreatment obj) throws Exception {
        obj.setId(id);
        return super.update(id, obj);
    }
}
