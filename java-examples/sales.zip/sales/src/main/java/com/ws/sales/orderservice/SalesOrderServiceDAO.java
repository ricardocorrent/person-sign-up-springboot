package com.ws.sales.orderservice;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;

import java.util.Objects;
import java.util.UUID;

import io.ebean.ExpressionList;
import io.ebean.Query;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
public class SalesOrderServiceDAO extends AbstractDAO<SalesOrderService> {
    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class<SalesOrderService> getEntityClass() {
        return SalesOrderService.class;
    }

    /**
     * Returns a list of orders services.
     *
     * @param search
     * @return PagedList<SalesOrderService>
     */
    public PagedList<SalesOrderService> list(final SalesOrderServiceSearch search) {
        final Query<SalesOrderService> query = find();
        final ExpressionList<SalesOrderService> where = query.where();

        if (search.getSalesOrderId() != null) {
            where.in("salesOrder.id", search.getSalesOrderId());
        }

        if (search.getServiceId() != null) {
            where.in("serviceId", search.getServiceId());
        }

        return getPagedList(query, search);
    }

    public PagedList<SalesOrderService> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        Objects.requireNonNull(restQueryAdapter, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("httpRestQueryAdapter"));

        final Query<SalesOrderService> query = this.find();
        final ExpressionList<SalesOrderService> where = query.where();
        where.eq("salesOrder.id", orderId);

        return this.getPagedList(query, restQueryAdapter);
    }

    /**
     * Returns a sales orders services.
     *
     * @param salesOrderId
     * @param serviceID
     * @return SalesOrderService
     */
    public SalesOrderService findByService(final UUID salesOrderId, final UUID serviceID) {
        return find()
                .where()
                .eq("salesOrder.id", salesOrderId)
                .eq("serviceId", serviceID)
                .findOne();
    }

}
