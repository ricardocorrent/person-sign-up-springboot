package com.ws.sales.paymentterm;

import java.util.UUID;

import com.ws.commons.server.pagination.PaginationSearch;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class PaymentTermSearch extends PaginationSearch {

    private final Boolean orderTest = Boolean.FALSE;
    private Boolean[] active;
    private String description;
    private String code;
    private Boolean[] standard;
    private Boolean[] availableFirstOrder;
    private String acronym;
    private UUID[] paymentTermIds;
    private UUID locationId;

    private UUID customerId;

    private UUID userId;

    private UUID companyId;

    private String generalSearch;

    /**
     * Gets the options to filter by active.
     * Options: [true, false]
     *
     * @return java.lang.Boolean[]
     */
    public Boolean[] getActive() {
        return active;
    }

    /**
     * Set the active filter options
     * Options: [true, false]
     *
     * @param active
     */
    public void setActive(final Boolean[] active) {
        this.active = active;
    }

    /**
     * Gets the payment term description
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets te Payment term description
     *
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Gets the payment term code
     *
     * @return java.lang.String
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets te Payment term  code
     *
     * @param code
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Check if is standard
     *
     * @return java.lang.Boolean
     */
    public Boolean[] getStandard() {
        return standard;
    }

    /**
     * Define if it's  standard
     *
     * @param standard
     */
    public void setStandard(final Boolean[] standard) {
        this.standard = standard;
    }

    /**
     * Check if is available at first order
     *
     * @return java.lang.Boolean
     */
    public Boolean[] getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Define if its  available at First Order
     *
     * @param availableFirstOrder
     */
    public void setAvailableFirstOrder(final Boolean[] availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }

    /**
     * Gets the payment term  acronym
     *
     * @return java.lang.String
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Sets the Payment term acronym
     *
     * @param acronym
     */
    public void setAcronym(final String acronym) {
        this.acronym = acronym;
    }

    public UUID[] getPaymentTermIds() {
        return paymentTermIds;
    }

    public void setPaymentTermIds(final UUID[] paymentTermIds) {
        this.paymentTermIds = paymentTermIds;
    }

    /**
     * Check if is order filtering
     *
     * @return java.lang.Boolean
     */
    public Boolean getOrderTest() {
        return orderTest;
    }

    public UUID getLocationId() {
        return locationId;
    }

    public void setLocationId(final UUID locationId) {
        this.locationId = locationId;
    }

    public UUID getCustomerId() {
        return customerId;
    }

    public void setCustomerId(final UUID customerId) {
        this.customerId = customerId;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(final UUID userId) {
        this.userId = userId;
    }

    public UUID getCompanyId() {
        return companyId;
    }

    public void setCompanyId(final UUID companyId) {
        this.companyId = companyId;
    }

    public String getGeneralSearch() {
        return generalSearch;
    }

    public void setGeneralSearch(final String generalSearch) {
        this.generalSearch = generalSearch;
    }
}
