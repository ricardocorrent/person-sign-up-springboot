package com.ws.sales.ordertype;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Entity
public class OrderType extends SoftDeleteBaseEntity implements Serializable, IPojoConverter {

    @NotNull
    private Boolean active;

    @NotNull
    private Boolean standard;

    @NotNull
    private Boolean availableFirstOrder;

    @NotNull
    @Size(max = 255)
    private String description;

    @Size(max = 40)
    private String acronym;

    @Size(max = 40)
    private String code;

    /**
     * Gets the order type description
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the order type description
     *
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Check if the order type is active
     *
     * @return java.lang.Boolean
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Define if the order type is active
     *
     * @param active
     */
    public void setActive(final Boolean active) {
        this.active = active;
    }

    /**
     * Check if the order type is standard
     *
     * @return java.lang.Boolean
     */
    public Boolean getStandard() {
        return standard;
    }

    /**
     * Define if the order type is standard
     *
     * @param standard
     */
    public void setStandard(final Boolean standard) {
        this.standard = standard;
    }

    /**
     * Check if the order type is available to the first order
     *
     * @return java.lang.Boolean
     */
    public Boolean getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Define if the order type is available first order
     *
     * @param availableFirstOrder
     */
    public void setAvailableFirstOrder(final Boolean availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }

    /**
     * Gets the order type acronym
     *
     * @return java.lang.String
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Sets the order type acronym
     *
     * @param acronym
     */
    public void setAcronym(final String acronym) {
        this.acronym = acronym;
    }

    /**
     * Gets the order type code
     *
     * @return java.lang.String
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the order tpe code
     *
     * @param code
     */
    public void setCode(final String code) {
        this.code = code;
    }

}
