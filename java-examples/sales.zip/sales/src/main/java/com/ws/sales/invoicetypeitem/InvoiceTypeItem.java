package com.ws.sales.invoicetypeitem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.sales.invoice.InvoiceItem;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * This class represents the entity Invoice Type Item.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
@Entity
@PreventRecycling
public class InvoiceTypeItem extends SoftDeleteBaseEntity {

    /**
     * This field represents the description for the InvoiceTypeItem.
     */
    @NotNull
    @Size(max = 255)
    private String description;

    /**
     * This field represents if the register is active or not
     */
    @NotNull
    private Boolean active;

    /**
     * This field represents the relationship of InvoiceTypeItem with InvoiceItem
     */
    @OneToMany(mappedBy = "invoiceTypeItem")
    @JsonIgnore
    private List<InvoiceItem> invoiceItems;

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets active.
     *
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Sets active.
     *
     * @param active the active
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * Gets invoice items.
     *
     * @return the invoice items
     */
    public List<InvoiceItem> getInvoiceItems() {
        return invoiceItems;
    }

    /**
     * Sets invoice items.
     *
     * @param invoiceItems the invoice items
     */
    public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
        this.invoiceItems = invoiceItems;
    }
}
