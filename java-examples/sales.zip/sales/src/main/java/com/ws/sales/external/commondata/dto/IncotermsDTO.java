package com.ws.sales.external.commondata.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.sales.external.commondata.IncotermsAcronym;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

/**
 * Created by sergio.junior on 11/9/2017.
 */
public class IncotermsDTO extends BaseDTO implements DefaultPojoConverter {

    @Enumerated(value = EnumType.STRING)
    private IncotermsAcronym acronym;

    /**
     * Get of property {@link #acronym}
     *
     * @return com.ws.sales.external.commondata.IncotermsAcronym
     */
    public IncotermsAcronym getAcronym() {
        return acronym;
    }

    /**
     * Set of property {@link #acronym}
     *
     * @param acronym field to set
     */
    public void setAcronym(final IncotermsAcronym acronym) {
        this.acronym = acronym;
    }
}
