package com.ws.sales.paymentmethod.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * Created by sergio.junior on 10/13/2017.
 */
public class PaymentMethodDTO extends BaseDTO implements DefaultPojoConverter {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
