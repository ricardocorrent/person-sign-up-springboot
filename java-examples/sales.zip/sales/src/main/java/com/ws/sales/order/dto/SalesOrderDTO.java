package com.ws.sales.order.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.administration.dto.CompanyDTO;
import com.ws.sales.external.commondata.dto.IncotermsDTO;
import com.ws.sales.external.customer.dto.CustomerDTO;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.external.product.dto.PriceListDTO;
import com.ws.sales.external.situation.SituationDTO;
import com.ws.sales.external.user.dto.UserDTO;
import com.ws.sales.ordercurrency.dto.OrderCurrencyDTO;
import com.ws.sales.ordertype.dto.OrderTypeDTO;
import com.ws.sales.paymentmethod.dto.PaymentMethodDTO;
import com.ws.sales.paymentterm.PaymentTermDTO;
import com.ws.sales.util.hateoas.HateoasColumnMapper;
import com.ws.sales.util.hateoas.HateoasDTO;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Created by sergio.junior on 10/13/2017.
 */
public class SalesOrderDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private UUID id;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "customer.id", target = "customerId"),
            @PojoColumnMapper(source = "customer.name", target = "customerName")
    })
    private CustomerDTO customer;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "location.id", target = "locationId"),
            @PojoColumnMapper(source = "location.description", target = "locationDescription")
    })
    private LocationDTO location;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "company.id", target = "companyId"),
            @PojoColumnMapper(source = "company.name", target = "companyName")
    })
    private CompanyDTO company;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "orderType.id", target = "orderTypeId"),
            @PojoColumnMapper(source = "orderType.description", target = "orderTypeDescription")
    })
    private OrderTypeDTO orderType;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "priceList.id", target = "priceListId"),
            @PojoColumnMapper(source = "priceList.description", target = "priceListDescription")
    })
    private PriceListDTO priceList;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "paymentTerm.id", target = "paymentTermId"),
            @PojoColumnMapper(source = "paymentTerm.description", target = "paymentTermDescription")
    })
    private PaymentTermDTO paymentTerm;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "paymentMethod.id", target = "paymentMethodId"),
            @PojoColumnMapper(source = "paymentMethod.description", target = "paymentMethodDescription")
    })
    private PaymentMethodDTO paymentMethod;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "user.id", target = "userId"),
            @PojoColumnMapper(source = "user.name", target = "userName")
    })
    private UserDTO user;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "userProfessional.id", target = "userProfessionalId"),
            @PojoColumnMapper(source = "userProfessional.name", target = "userProfessionalName")
    })
    private UserDTO userProfessional;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "situation.id", target = "situationId"),
            @PojoColumnMapper(source = "situation.description", target = "situationDescription")
    })
    private SituationDTO situation;

    private String origin;

    private String externalNumber;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate dueDate;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate createDate;

    private Boolean draft;

    private BigDecimal netValue;

    private String orderNumber;

    private OrderCurrencyDTO orderCurrency;

    @PojoColumnMapper(target = "orderNotes")
    private String notes;

    private UUID signatureId;


    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "incoterms.id", target = "incotermsId"),
            @PojoColumnMapper(source = "incoterms.acronym", target = "incotermsAcronym")
    })
    private IncotermsDTO incoterms;

    private OffsetDateTime createdAt;

    private OffsetDateTime orderedAt;

    private OffsetDateTime exportedAt;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "activity.id", target = "activityId"),
    })
    private IdDTO activity;

    @HateoasColumnMapper(rel = "items", uri = "/orders/{id}/items")
    private HateoasDTO items;

    @HateoasColumnMapper(rel = "services", uri = "/orders/{id}/services")
    private HateoasDTO services;

    @HateoasColumnMapper(rel = "signature", uri = "/orders/{id}/signature")
    private HateoasDTO signature;

    @HateoasColumnMapper(rel = "complement",uri = "/orders/{id}/complement")
    private HateoasDTO complement;

    private String externalId;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    /**
     * Get of property {@link #id}
     *
     * @return java.util.UUID
     */
    @Override
    public UUID getId() {
        return id;
    }

    /**
     * Set of property {@link #id}
     *
     * @param id field to set
     */
    @Override
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * Get of property {@link #customer}
     *
     * @return com.ws.sales.deal.externaldto.CustomerDTO
     */
    public CustomerDTO getCustomer() {
        return customer;
    }

    /**
     * Set of property {@link #customer}
     *
     * @param customer field to set
     */
    public void setCustomer(final CustomerDTO customer) {
        this.customer = customer;
    }

    /**
     * Get of property {@link #location}
     *
     * @return com.ws.sales.deal.externaldto.LocationDTO
     */
    public LocationDTO getLocation() {
        return location;
    }

    /**
     * Set of property {@link #location}
     *
     * @param location field to set
     */
    public void setLocation(final LocationDTO location) {
        this.location = location;
    }

    /**
     * Get of property {@link #company}
     *
     * @return com.ws.sales.external.administration.dto.CompanyDTO
     */
    public CompanyDTO getCompany() {
        return company;
    }

    /**
     * Set of property {@link #company}
     *
     * @param company field to set
     */
    public void setCompany(final CompanyDTO company) {
        this.company = company;
    }

    /**
     * Get of property {@link #orderType}
     *
     * @return com.ws.sales.ordertype.externaldto.OrderTypeDTO
     */
    public OrderTypeDTO getOrderType() {
        return orderType;
    }

    /**
     * Set of property {@link #orderType}
     *
     * @param orderType field to set
     */
    public void setOrderType(final OrderTypeDTO orderType) {
        this.orderType = orderType;
    }

    /**
     * Get of property {@link #priceList}
     *
     * @return com.ws.sales.external.product.dto.PriceListDTO
     */
    public PriceListDTO getPriceList() {
        return priceList;
    }

    /**
     * Set of property {@link #priceList}
     *
     * @param priceList field to set
     */
    public void setPriceList(final PriceListDTO priceList) {
        this.priceList = priceList;
    }

    /**
     * Get of property {@link #paymentTerm}
     *
     * @return com.ws.sales.paymentterm.externaldto.PaymentTermDTO
     */
    public PaymentTermDTO getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * Set of property {@link #paymentTerm}
     *
     * @param paymentTerm field to set
     */
    public void setPaymentTerm(final PaymentTermDTO paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    /**
     * Get of property {@link #paymentMethod}
     *
     * @return com.ws.sales.paymentmethod.externaldto.PaymentMethodDTO
     */
    public PaymentMethodDTO getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Set of property {@link #paymentMethod}
     *
     * @param paymentMethod field to set
     */
    public void setPaymentMethod(final PaymentMethodDTO paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Get of property {@link #user}
     *
     * @return com.ws.sales.deal.externaldto.UserDTO
     */
    public UserDTO getUser() {
        return user;
    }

    /**
     * Set of property {@link #user}
     *
     * @param user field to set
     */
    public void setUser(final UserDTO user) {
        this.user = user;
    }


    /**
     * Get of property {@link #userProfessional}
     *
     * @return com.ws.sales.external.user.dto.UserDTO
     */
    public UserDTO getUserProfessional() {
        return userProfessional;
    }

    /**
     * Set of property {@link #userProfessional}
     *
     * @param userProfessional field to set
     */
    public void setUserProfessional(final UserDTO userProfessional) {
        this.userProfessional = userProfessional;
    }

    /**
     * Get of property {@link #dueDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /**
     * Set of property {@link #dueDate}
     *
     * @param dueDate field to set
     */
    public void setDueDate(final LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(final LocalDate createDate) {
        this.createDate = createDate;
    }

    /**
     * Get of property {@link #draft}
     *
     * @return java.lang.Boolean
     */
    public Boolean getDraft() {
        return draft;
    }

    /**
     * Set of property {@link #draft}
     *
     * @param draft field to set
     */
    public void setDraft(final Boolean draft) {
        this.draft = draft;
    }

    /**
     * Get of property {@link #netValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getNetValue() {
        return netValue;
    }

    /**
     * Set of property {@link #netValue}
     *
     * @param netValue field to set
     */
    public void setNetValue(final BigDecimal netValue) {
        this.netValue = netValue;
    }

    /**
     * Get of property {@link #orderNumber}
     *
     * @return java.lang.String
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Set of property {@link #orderNumber}
     *
     * @param orderNumber field to set
     */
    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * Get of property {@link #orderCurrency}
     *
     * @return com.ws.sales.ordercurrency.externaldto.OrderCurrencyDTO
     */
    public OrderCurrencyDTO getOrderCurrency() {
        return orderCurrency;
    }

    /**
     * Set of property {@link #orderCurrency}
     *
     * @param orderCurrency field to set
     */
    public void setOrderCurrency(final OrderCurrencyDTO orderCurrency) {
        this.orderCurrency = orderCurrency;
    }

    /**
     * Get of property {@link #notes}
     *
     * @return java.lang.String
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Set of property {@link #notes}
     *
     * @param notes field to set
     */
    public void setNotes(final String notes) {
        this.notes = notes;
    }

    /**
     * Get of property {@link #signatureId}
     *
     * @return java.util.UUID
     */
    public UUID getSignatureId() {
        return signatureId;
    }

    /**
     * Set of property {@link #signatureId}
     *
     * @param signatureId field to set
     */
    public void setSignatureId(final UUID signatureId) {
        this.signatureId = signatureId;
    }

    /**
     * Get of property {@link #incoterms}
     *
     * @return com.ws.sales.deliveryorder.externaldto.IncotermsDTO
     */
    public IncotermsDTO getIncoterms() {
        return incoterms;
    }

    /**
     * Set of property {@link #incoterms}
     *
     * @param incoterms field to set
     */
    public void setIncoterms(final IncotermsDTO incoterms) {
        this.incoterms = incoterms;
    }

    /**
     * Get of property {@link #createdAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Set of property {@link #createdAt}
     *
     * @param createdAt field to set
     */
    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public HateoasDTO getItems() {
        return items;
    }

    public void setItems(final HateoasDTO items) {
        this.items = items;
    }

    public HateoasDTO getServices() {
        return services;
    }

    public void setServices(final HateoasDTO services) {
        this.services = services;
    }

    public HateoasDTO getSignature() {
        return signature;
    }

    public void setSignature(final HateoasDTO signature) {
        this.signature = signature;
    }

    public HateoasDTO getComplement() {
        return complement;
    }

    public void setComplement(final HateoasDTO complement) {
        this.complement = complement;
    }

    public OffsetDateTime getOrderedAt() {
        return orderedAt;
    }

    public void setOrderedAt(final OffsetDateTime orderedAt) {
        this.orderedAt = orderedAt;
    }

    public SituationDTO getSituation() {
        return situation;
    }

    public void setSituation(final SituationDTO situation) {
        this.situation = situation;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(final String origin) {
        this.origin = origin;
    }

    public String getExternalNumber() {
        return externalNumber;
    }

    public void setExternalNumber(final String externalNumber) {
        this.externalNumber = externalNumber;
    }

    public OffsetDateTime getExportedAt() {
        return exportedAt;
    }

    public void setExportedAt(final OffsetDateTime exportedAt) {
        this.exportedAt = exportedAt;
    }

    public IdDTO getActivity() {
        return activity;
    }

    public void setActivity(final IdDTO activity) {
        this.activity = activity;
    }
}
