package com.ws.sales.orderintegration;

import com.ws.commons.interceptor.sourceannotation.Consumer;
import com.ws.commons.interceptor.sourceannotation.ConversionConsumes;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.Id;
import com.ws.commons.server.resource.*;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.orderintegration.dto.SalesOrderIntegrationDTO;
import org.apache.http.HttpStatus;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

@Path("/order-integration")
public class SalesOrderIntegrationResource implements
        IResourceUpdate<SalesOrder>,
        IResourceGet<SalesOrder>,
        IResourceList<SalesOrder>,
        IResourceDelete<SalesOrder> {

    private static final String PERMISSION_WRITE = "sales:order-integration:write";
    private static final String PERMISSION_DELETE = "sales:order-integration:delete";
    private final SalesOrderService salesOrderService;

    @Inject
    public SalesOrderIntegrationResource(final SalesOrderService salesOrderService) {
        this.salesOrderService = salesOrderService;
    }

    @Override
    public AbstractService<SalesOrder> getService() {
        return salesOrderService;
    }


    /**
     * Insert an order using integration resource. It won't validate
     *
     * @param entity order to update
     * @return {@link SalesOrder}
     */
    @POST
    @ConversionConsumes(SalesOrderIntegrationDTO.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderIntegrationResource.PERMISSION_WRITE)
    public Response insert(final SalesOrder entity) throws Exception {
        ResourceUtils.checkWritePermission(this.getClass());
        return Response.status(HttpStatus.SC_CREATED).entity(new Id(salesOrderService.insertForIntegration(entity))).build();
    }

    /**
     * Update an order using integration resource. It won't validate
     *
     * @param entity order to update
     * @return {@link SalesOrder}
     */
    @PUT
    @Path("/{orderId}")
    @ConversionConsumes(SalesOrderIntegrationDTO.class)
    @RequiresPermissions(SalesOrderIntegrationResource.PERMISSION_WRITE)
    public Response update(final @PathParam("orderId") UUID orderId,
                           final @Consumer SalesOrder entity,
                           final @Context HttpServletRequest request) throws Exception {
        entity.setId(orderId);
        this.salesOrderService.updateForIntegration(entity, new HttpRestQueryAdapter(request));
        return Response.ok().build();
    }

    /**
     * Method for delete salesOrder. It won't validate
     *
     * @author Peterson Schmitt
     * @since v8.6.0 2019-06-327
     *
     * @param orderId
     */
    @DELETE
    @Path("/{orderId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresPermissions(SalesOrderIntegrationResource.PERMISSION_DELETE)
    public Response deleteItemFinishedOrder(@PathParam("orderId") final UUID orderId) throws Exception {
        this.salesOrderService.deleteForIntegration(orderId);
        return Response.ok().build();
    }

}
