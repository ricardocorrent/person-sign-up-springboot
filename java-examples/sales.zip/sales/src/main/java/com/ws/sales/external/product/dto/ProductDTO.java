package com.ws.sales.external.product.dto;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.io.Serializable;
import java.util.UUID;

/**
 * Created by sergio.junior on 10/10/2017.
 */
public class ProductDTO implements DefaultPojoConverter, Identification<UUID>, Serializable {

    private static final long serialVersionUID = 1457232389013483395L;

    private UUID id;

    private String description;

    private String code;

    @Override
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
