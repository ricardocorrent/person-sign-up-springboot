package com.ws.sales.deliveryorder.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.external.commondata.dto.IncotermsDTO;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.order.dto.OrderDTO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Created by sergio.junior on 11/8/2017.
 */
public class DeliveryDTO implements DefaultPojoConverter {

    private UUID id;

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "order.id", target = "salesOrder.id")
    })
    private OrderDTO order;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "location.id", target = "locationId"),
            @PojoColumnMapper(source = "location.description", target = "locationDescription")
    })
    private LocationDTO location;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate shipmentDate;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate deliveryDate;

    private String observation;

    @PojoColumnsMapper(value = {
            @PojoColumnMapper(source = "incoterms.id", target = "incotermsId"),
            @PojoColumnMapper(source = "incoterms.acronym", target = "incotermsAcronym")
    })
    private IncotermsDTO incoterms;

    private BigDecimal freightValue;

    private String externalId;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    /**
     * Get of property {@link #id}
     *
     * @return java.util.UUID
     */
    public UUID getId() {
        return id;
    }

    /**
     * Set of property {@link #id}
     *
     * @param id field to set
     */
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * Get of property {@link #order}
     *
     * @return com.ws.sales.order.dto.OrderDTO
     */
    public OrderDTO getOrder() {
        return order;
    }

    /**
     * Set of property {@link #order}
     *
     * @param order field to set
     */
    public void setOrder(final OrderDTO order) {
        this.order = order;
    }

    /**
     * Get of property {@link #location}
     *
     * @return com.ws.sales.external.customer.dto.LocationDTO
     */
    public LocationDTO getLocation() {
        return location;
    }

    /**
     * Set of property {@link #location}
     *
     * @param location field to set
     */
    public void setLocation(final LocationDTO location) {
        this.location = location;
    }

    /**
     * Get of property {@link #shipmentDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getShipmentDate() {
        return shipmentDate;
    }

    /**
     * Set of property {@link #shipmentDate}
     *
     * @param shipmentDate field to set
     */
    public void setShipmentDate(final LocalDate shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    /**
     * Get of property {@link #deliveryDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Set of property {@link #deliveryDate}
     *
     * @param deliveryDate field to set
     */
    public void setDeliveryDate(final LocalDate deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    /**
     * Get of property {@link #observation}
     *
     * @return java.lang.String
     */
    public String getObservation() {
        return observation;
    }

    /**
     * Set of property {@link #observation}
     *
     * @param observation field to set
     */
    public void setObservation(final String observation) {
        this.observation = observation;
    }

    /**
     * Get of property {@link #incoterms}
     *
     * @return com.ws.sales.external.commondata.dto.IncotermsDTO
     */
    public IncotermsDTO getIncoterms() {
        return incoterms;
    }

    /**
     * Set of property {@link #incoterms}
     *
     * @param incoterms field to set
     */
    public void setIncoterms(final IncotermsDTO incoterms) {
        this.incoterms = incoterms;
    }

    /**
     * Get of property {@link #freightValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getFreightValue() {
        return freightValue;
    }

    /**
     * Set of property {@link #freightValue}
     *
     * @param freightValue field to set
     */
    public void setFreightValue(final BigDecimal freightValue) {
        this.freightValue = freightValue;
    }
}
