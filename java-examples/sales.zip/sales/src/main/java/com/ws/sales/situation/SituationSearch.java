package com.ws.sales.situation;

import com.ws.commons.server.pagination.PaginationSearch;

import java.util.UUID;

/**
 * @author thyago.volpatto
 * @since v5.1.0 19/04/2017.
 */
public class SituationSearch extends PaginationSearch {

    private UUID situationId;

    private String description;

    private String acronym;

    /**
     * @return java.util.UUID
     */
    public UUID getSituationId() {
        return situationId;
    }

    /**
     * @param situationId
     */
    public void setSituationId(final UUID situationId) {
        this.situationId = situationId;
    }

    /**
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }
}
