package com.ws.sales.recordpermission;

import com.sollar.recordpermission.queryadapter.RecordPermissionConfiguration;
import com.ws.commons.persistence.model.RecyclingEntity;
import com.ws.commons.server.context.UserContext;
import com.ws.sales.customerorderssummary.productpurchased.ProductPurchasedHistoryView;
import com.ws.sales.customerorderssummary.productspurchased.CustomerOrderHistoryProductsView;
import com.ws.sales.customerorderssummary.servicepurchased.ServicePurchasedHistoryView;
import com.ws.sales.customerorderssummary.servicespurchased.CustomerOrderHistoryServicesView;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.orderoperation.OrderOperation;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.ordersituation.SalesOrderSituation;
import com.ws.sales.ordertreatment.OrderTreatment;
import com.ws.sales.ordertype.OrderType;
import com.ws.sales.paymentmethod.PaymentMethod;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermission;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermission;
import com.ws.sales.situation.Situation;

import javax.inject.Inject;
import java.util.*;

/**
 * @author Gustavo P. Bilert
 * @since 5.1.0 2017-04-20
 */
public class SalesRecordPermissionConfiguration extends RecordPermissionConfiguration {

    static final Set<String> IGNORED_ENTITIES;

    static {
        IGNORED_ENTITIES = new TreeSet<>();
        IGNORED_ENTITIES.add(SalesOrderSituation.class.getSimpleName());
        IGNORED_ENTITIES.add(OrderType.class.getSimpleName());
        IGNORED_ENTITIES.add(Situation.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentMethod.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentTerm.class.getSimpleName());
        IGNORED_ENTITIES.add(OrderCurrency.class.getSimpleName());
        IGNORED_ENTITIES.add(Situation.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentTermCompanyPermission.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentTermCustomerPermission.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentTermLocationPermission.class.getSimpleName());
        IGNORED_ENTITIES.add(PaymentTermUserPermission.class.getSimpleName());
        IGNORED_ENTITIES.add(OrderTreatment.class.getSimpleName());
        IGNORED_ENTITIES.add(OrderOperation.class.getSimpleName());
        IGNORED_ENTITIES.add(OrderParameter.class.getSimpleName());
        IGNORED_ENTITIES.add(RecyclingEntity.class.getSimpleName());
        IGNORED_ENTITIES.add(CustomerOrderHistoryServicesView.class.getSimpleName());
        IGNORED_ENTITIES.add(CustomerOrderHistoryProductsView.class.getSimpleName());
        IGNORED_ENTITIES.add(ProductPurchasedHistoryView.class.getSimpleName());
        IGNORED_ENTITIES.add(ServicePurchasedHistoryView.class.getSimpleName());
    }

    private final UserContext userContext;

    @Inject
    public SalesRecordPermissionConfiguration(UserContext userContext) {

        this.userContext = userContext;
    }

    @Override
    public UUID currentUserId() {
        return UUID.fromString((String) userContext.getSession().getAttribute("user_id"));
    }

    @Override
    public Boolean currentUserIsAdministrator() {
        return (Boolean) userContext.getSession().getAttribute("user_administrator");
    }

    @Override
    public Set<String> ignoredEntities() {
        return IGNORED_ENTITIES;
    }

    @Override
    public List<String> accessGroupsToReplicate() {
        return Arrays.asList("user", "company", "customerByRegion");
    }
}
