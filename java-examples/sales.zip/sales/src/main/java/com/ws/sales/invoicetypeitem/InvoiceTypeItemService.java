package com.ws.sales.invoicetypeitem;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * The class InvoiceTypeItemService is used to call the validator of business rules and the DAO layer(persistence layer).
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class InvoiceTypeItemService extends AbstractService<InvoiceTypeItem> {

    /**
     * Injects InvoiceTypeItemDAO class for communication between layers of InvoiceTypeItemService
     * and InvoiceTypeItemDAO.
     */
    private final InvoiceTypeItemDAO dao;

    @Inject
    public InvoiceTypeItemService(InvoiceTypeItemDAO dao) {
        super(dao);
        this.dao = dao;
    }

    /**
     * Method to search a list of Invoice Type Item by filter.
     *
     * @param invoiceTypeItemSearch the invoice type item search.
     * @return the paged list of invoice type item.
     */
    public PagedList<InvoiceTypeItem> search(final InvoiceTypeItemSearch invoiceTypeItemSearch) {
        return dao.search(invoiceTypeItemSearch);
    }
}