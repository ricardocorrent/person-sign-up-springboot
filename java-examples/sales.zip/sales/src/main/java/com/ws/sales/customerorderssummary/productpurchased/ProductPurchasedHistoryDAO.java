package com.ws.sales.customerorderssummary.productpurchased;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.impl.HttpRestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;
import io.ebean.RawSql;
import io.ebean.RawSqlBuilder;

import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-21
 */
public class ProductPurchasedHistoryDAO extends AbstractDAO<ProductPurchasedHistoryView> {

    private static final String BASE_QUERY =
            "select " +
                    "customer_id, " +
                    "sales_order_id, " +
                    "product_id, " +
                    "product_description, " +
                    "updated_at, " +
                    "ordered_at, " +
                    "net_value, " +
                    "quantity " +
                    "from " +
                    "product_purchased_history_view " +
                    "where " +
                    "customer_id = :customerId " +
                    "and " +
                    "product_id = :productId";

    /**
     * This method list the details from a product using a base sql to find it in a product view
     *
     * @param customerId {@link UUID}
     * @param serviceId {@link UUID}
     * @param httpRestQueryAdapter {@link HttpRestQueryAdapter}
     * @return a list of {@link ProductPurchasedHistoryView}
     */
    public PagedList<ProductPurchasedHistoryView> list(final UUID customerId,
                                                       final UUID productId,
                                                       final HttpRestQueryAdapter httpRestQueryAdapter) {
        final Query<ProductPurchasedHistoryView> query = ebeanServer.find(ProductPurchasedHistoryView.class);
        final RawSql rawSql = RawSqlBuilder.parse(BASE_QUERY).create();
        query.setRawSql(rawSql)
                .setParameter("customerId", customerId)
                .setParameter("productId", productId);

        return getPagedList(query, httpRestQueryAdapter);
    }

    /**
     * Returns the entity class declared in this class.
     *
     * @return The entity class declared as parameterized type at this class.
     */
    @Override
    public Class<ProductPurchasedHistoryView> getEntityClass() {
        return ProductPurchasedHistoryView.class;
    }

}
