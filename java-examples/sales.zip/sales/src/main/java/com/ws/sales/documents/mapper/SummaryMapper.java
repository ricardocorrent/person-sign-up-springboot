package com.ws.sales.documents.mapper;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * @author Dante Basso <dante.basso@wwsim.com.br>
 * @version 1.0.0
 * @since 2019-03-18
 */
public class SummaryMapper {

    private OffsetDateTime creationDate;

    private BigDecimal discount;

    private OffsetDateTime finishDate;

    private String number;

    private BigDecimal quantity;

    private Integer quantityItems;

    private String status;

    private BigDecimal total;

    private BigDecimal quantityServices;

    private BigDecimal discountServices;

    private BigDecimal totalServices;

    public OffsetDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(OffsetDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public OffsetDateTime getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(OffsetDateTime finishDate) {
        this.finishDate = finishDate;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public Integer getQuantityItems() {
        return quantityItems;
    }

    public void setQuantityItems(Integer quantityItems) {
        this.quantityItems = quantityItems;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getQuantityServices() {
        return quantityServices;
    }

    public void setQuantityServices(BigDecimal quantityServices) {
        this.quantityServices = quantityServices;
    }

    public BigDecimal getDiscountServices() {
        return discountServices;
    }

    public void setDiscountServices(BigDecimal discountServices) {
        this.discountServices = discountServices;
    }

    public BigDecimal getTotalServices() {
        return totalServices;
    }

    public void setTotalServices(BigDecimal totalServices) {
        this.totalServices = totalServices;
    }
}
