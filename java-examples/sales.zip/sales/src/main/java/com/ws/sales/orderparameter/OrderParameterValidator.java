package com.ws.sales.orderparameter;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.Optional;

/**
 * This class represents the validator of business rules of Order parameter.
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-23
 */
public class OrderParameterValidator extends AbstractEntityValidator<OrderParameter> {

    private final OrderParameterDAO orderParameterDAO;

    /**
     * Instantiates a new Order Parameter validation
     *
     * @param orderParameterDAO
     */
    @Inject
    public OrderParameterValidator(final OrderParameterDAO orderParameterDAO) {
        this.orderParameterDAO = orderParameterDAO;
    }

    /**
     * Method to validate the business rules to insert a Order Parameter
     *
     * @param entity
     * @param filter
     */
    @Override
    protected void validate(final OrderParameter entity, final IValidationFilter... filter) {
        if (entity != null) {
            validateOrderParameterIdExists(entity);
            validateNullFields(entity);
            validateNonNegativeCreditLimitIfNotRequired(entity);
            validateNotRequiredIfNegativeCreditLimit(entity);
            validateValueIsSameValueType(entity);
        }
    }

    /**
     * Validates if credit limit plugin is valid with negative credit limit plugin
     *
     * @param orderParameter entity to validate
     * @author Luiz Paulo Lasta Moco
     */
    public void validateNonNegativeCreditLimitIfNotRequired(final OrderParameter orderParameter) {
        if (orderParameter != null && orderParameter.getKey() != null &&
                orderParameter.getKey().equalsIgnoreCase(OrderParameterConstants.BLOCK_ORDER_NEGATIVE_CREDIT) &&
                orderParameter.getValue().equalsIgnoreCase(OrderParameterConstants.TRUE)) {
            final OrderParameter orderParamCreditReq = orderParameterDAO.searchByKey(OrderParameterConstants.CREDIT_REQUIRED);
            if (orderParamCreditReq.getValue().equalsIgnoreCase(OrderParameterConstants.FALSE)) {
                addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.NEGATIVE_CREDIT_VALUE), orderParameter);
            }
        }
    }

    /**
     * Validates if credit limit plugin is valid with negative credit limit plugin
     *
     * @param orderParameter entity to validate
     * @author Luiz Paulo Lasta Moco
     */
    public void validateNotRequiredIfNegativeCreditLimit(final OrderParameter orderParameter) {
        if (orderParameter != null && orderParameter.getKey() != null &&
                orderParameter.getKey().equalsIgnoreCase(OrderParameterConstants.CREDIT_REQUIRED) &&
                orderParameter.getValue().equalsIgnoreCase(OrderParameterConstants.FALSE)) {
            final OrderParameter orderParamCreditReq = orderParameterDAO.searchByKey(OrderParameterConstants.BLOCK_ORDER_NEGATIVE_CREDIT);
            if (orderParamCreditReq.getValue().equalsIgnoreCase(OrderParameterConstants.TRUE)) {
                addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.VALIDATE_NEGATIVE_CREDIT_LIMIT), orderParameter);
            }
        }
    }

    /**
     * Validates if value is the same type of value type
     *
     * @param orderParameter entity to validate
     * @author Luiz Paulo Lasta Moco
     */
    public void validateValueIsSameValueType(final OrderParameter orderParameter) {
        final EOrderParameterValueType valueType = orderParameter.getValueType();
        final String value = orderParameter.getValue();
        final String maxValue = orderParameter.getMaxValue();
        final String minValue = orderParameter.getMinValue();
        switch (valueType) {
            case DEC:
                validateOrderParameterDecimal(orderParameter, value);
                break;
            case DTT:
                validateOrderParameterDateTime(orderParameter, value);
                break;
            case INT:
                validateOrderParameterInteger(orderParameter, value);
                break;
            case BOOL:
                // BOOL don't validate
                break;
            case DATE:
                validateOrderParameterDate(orderParameter, value);
                break;
            case PER:
                validateOrderParameterPeriod(orderParameter, maxValue, minValue);
                break;
            case TXT:
                // Text don't validate
                break;
            default:
                // default don't validate
                break;
        }
    }

    /**
     * Validates Order parameter, value type equals period
     *
     * @param orderParameter
     * @param maxValue
     * @param minValue
     */
    private void validateOrderParameterPeriod(final OrderParameter orderParameter, final String maxValue, final String minValue) {
        if (minValue != null && !isDate(minValue)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        }
        if (maxValue != null && !isDate(maxValue)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        }
    }

    /**
     * Validates Order parameter, value type equals decimal
     *
     * @param orderParameter
     * @param value
     */
    private void validateOrderParameterDecimal(final OrderParameter orderParameter, final String value) {
        if (value != null && !StringUtils.isNumeric(value)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        }
    }

    /**
     * Validates Order parameter, value type equals date time
     *
     * @param orderParameter
     * @param value
     */
    private void validateOrderParameterDateTime(final OrderParameter orderParameter, final String value) {
        if (value != null && !isDateTime(value)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        }
    }

    /**
     * Validates Order parameter, value type equals date
     *
     * @param orderParameter
     * @param value
     */
    private void validateOrderParameterDate(final OrderParameter orderParameter, final String value) {
        if (value != null && !isDate(value)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        }
    }

    /**
     * Validates Order parameter, value type equals Integer
     *
     * @param orderParameter
     * @param value
     */
    private void validateOrderParameterInteger(final OrderParameter orderParameter, final String value) {
        if (value != null && !isInteger(value)) {
            addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.INVALID_VALUE_FIELD), orderParameter);
        } else {
            this.doValidateMinValue(orderParameter);
            this.doValidateMaxValue(orderParameter);
        }
    }

    /**
     * Validates id exists
     *
     * @param orderParameter to search
     * @author Luiz Paulo Lasta Moco
     */
    public void validateOrderParameterIdExists(final OrderParameter orderParameter) {
        orderParameterDAO.findById(orderParameter.getId());
    }

    /**
     * Validates required field is null
     *
     * @param orderParameter entity to validate
     * @author Luiz Paulo Lasta Moco
     */
    public void validateNullFields(final OrderParameter orderParameter) {
        final EOrderParameterValueType valueType = orderParameter.getValueType();
        final String value = orderParameter.getValue();
        final String minValue = orderParameter.getMinValue();
        if (valueType == EOrderParameterValueType.PER) {
            if (minValue == null) {
                addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.NULL_FIELD), orderParameter);
            }
        } else {
            if (value == null) {
                addError(new LogicError(orderParameter.getKey(), OrderParameterConstants.NULL_FIELD), orderParameter);
            }
        }
    }

    /**
     * Validates if string is integer
     *
     * @param str value to validate
     * @author Luiz Paulo Lasta Moco
     */
    public boolean isInteger(final String str) {
        if (str == null) {
            return false;
        }
        try {
            Integer.valueOf(str);
        } catch (final NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Validates if integer value is bigger than the minimum
     *
     * @param entity to get the fields minimum value and value and validate
     * @author Maykon Roberto Rissi
     * @since v5.22.0 2018-06-02
     */
    private void doValidateMinValue(final OrderParameter entity) {
        final Integer valueInteger = this.getOptionalStringToInt(entity.getValue());
        final Integer minimumValueInteger = this.getOptionalStringToInt(entity.getMinValue());
        if (valueInteger < minimumValueInteger) {
            this.addError(ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MINIMUM,
                    minimumValueInteger.toString(),
                    entity.getKey(),
                    Constants.MESSAGE_JAVAX_MAX_VALUE), entity);
        }
    }

    /**
     * Validates if integer value is less than the maximum
     *
     * @param entity to get the fields maximum value and value and validate
     * @author Hellinton Eduardo Klein
     * @since v8.2.0 2019-04-23
     */
    private void doValidateMaxValue(final OrderParameter entity) {
        if (entity.getMaxValue() == null) {
            return;
        }
        final Integer valueInteger = this.getOptionalStringToInt(entity.getValue());
        final Integer maximumValueInteger = this.getOptionalStringToInt(entity.getMaxValue());
        if (valueInteger > maximumValueInteger ) {
            this.addError(ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MAXIMUM,
                    maximumValueInteger.toString(),
                    entity.getKey(),
                    Constants.MESSAGE_JAVAX_MAX_VALUE), entity);
        }
    }

    /**
     * Transform an string into integer. If it is null, it will return 0
     * Must be used after validate if the value is an Integer
     *
     * @param value to convert
     * @return new Integer
     * @author Maykon Roberto Rissi
     * @since v5.22.0 2018-06-04
     */
    private Integer getOptionalStringToInt(final String value) {
        return Optional.of(Integer.valueOf(value)).orElse(0);
    }

    /**
     * Validates if string is date: "yyyy-MM-dd"
     *
     * @param dateToValidate value to validate
     * @author Luiz Paulo Lasta Moco
     */
    public boolean isDate(final String dateToValidate) {
        if (dateToValidate == null) {
            return false;
        }
        try {
            final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            dateFormat.parse(dateToValidate);
            return true;
        } catch (final ParseException e) {
            return false;
        }
    }

    /**
     * Validates if string is datetime: "yyyy-MM-dd hh:mm:ss.704+00"
     *
     * @param dateTimeToValidate value to validate
     * @author Luiz Paulo Lasta Moco
     */
    public boolean isDateTime(final String dateTimeToValidate) {
        if (dateTimeToValidate == null) {
            return false;
        }
        try {
            OffsetDateTime.parse(dateTimeToValidate);
            return true;
        } catch (final DateTimeParseException e) {
            return false;
        }
    }
}
