package com.ws.sales.external.product;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import com.ws.product.model.DiscountSearch;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.sales.external.product.dto.DiscountDTO;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;
import com.ws.sales.orderparameter.OrderParameterService;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Validations for product, price list and price list items
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-20
 */
public class DiscountValidation {

    private final ProductGateway productGateway;
    private final OrderParameterService orderParameterService;

    /**
     * @param productGateway        to perform product gets
     * @param orderParameterService to load parameters
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-20
     */
    public DiscountValidation(final ProductGateway productGateway,
                              final OrderParameterService orderParameterService) {
        this.productGateway = productGateway;
        this.orderParameterService = orderParameterService;
    }

    /**
     * Returns an error if the discount field has value and the price is fixed
     *
     * @param productDescription to set the error, if it exists
     * @param priceListItemId    to load entity and get the price
     * @param discountPercentage to compare
     * @param discountValue      to compare
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    public LogicError doValidateDiscountAndFixedPrice(final String productDescription,
                                                      final UUID priceListItemId,
                                                      final BigDecimal discountPercentage,
                                                      final BigDecimal discountValue) {
        if (!ValidationUtils.isValueNullOrZero(discountPercentage) && !ValidationUtils.isValueNullOrZero(discountValue)) {
            return Optional.ofNullable(priceListItemId)
                    .map(productGateway::getPriceListItem)
                    .map(PriceListItem::isFixedPrice)
                    .map(fixed -> fixed ? ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_PRODUCT_DESCRIPTION,
                            productDescription,
                            Constants.FIELD_SALES_PRICE,
                            Constants.MESSAGE_PRICE_HAS_DISCOUNT_AND_IS_FIXED) : null)
                    .orElse(null);
        }
        return null;
    }

    /**
     * Validates the discount.
     *
     * @param companyId          to set search
     * @param userProfessionalId to set search
     * @param customerId         to set search
     * @param locationId         to set search
     * @param productGroupId     to set search
     * @param priceListId        to set search
     * @param productId          to set search
     * @param priceListItemId    to set search
     * @param betweenDate        to set search
     * @return {@link DiscountSearch}
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    public LogicError doValidateMaximumDiscount(final UUID companyId,
                                                final UUID userProfessionalId,
                                                final UUID customerId,
                                                final UUID locationId,
                                                final UUID productGroupId,
                                                final UUID priceListId,
                                                final UUID productId,
                                                final UUID priceListItemId,
                                                final OffsetDateTime betweenDate,
                                                final BigDecimal discountPercentage,
                                                final BigDecimal discountValue) {
        final Boolean isDiscountValidationEnabled = Boolean.valueOf(this.orderParameterService.searchByKey(Constants.FIELD_PARAMETER_DISCOUNT).getValue());
        final Product product = this.productGateway.getProduct(productId);
        if (!isProductDiscountFree(product)
                && isDiscountValidationEnabled
                && !ValidationUtils.isValueNullOrZero(discountPercentage)
                && !ValidationUtils.isValueNullOrZero(discountValue)) {
            final DiscountSearch discountSearch = this.getDiscountSearch(companyId, userProfessionalId, customerId,
                    locationId, productGroupId, priceListId, productId, priceListItemId, product.getDiscountLimitType(), betweenDate);
            final List<DiscountDTO> discounts = this.productGateway.searchDiscounts(discountSearch);
            return discounts.stream()
                    .findFirst()
                    .map(discount -> {
                        final Boolean discountValueIsInvalid = ValidationUtils.isValueNullOrZero(discount.getMaximumDiscountValue());
                        return discountValueIsInvalid ? this.doValidateDiscountPercentage(discountPercentage, discount.getMaximumDiscountPercentage())
                                : this.doValidateDiscountValue(discountValue, discount.getMaximumDiscountValue());
                    })
                    .orElse(null);
        }
        return null;
    }

    /**
     * Returns true if the discount type of the product is free
     *
     * @param product to get the discount type
     * @return true if is free
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private Boolean isProductDiscountFree(final Product product) {
        return Optional.ofNullable(product)
                .map(Product::getDiscountLimitType)
                .map(DiscountType.FREE.toString()::equals)
                .orElse(Boolean.TRUE);
    }

    /**
     * Returns an error if the discount percentage is higher than the permitted
     *
     * @param value        BigDecimal from the sale to compare
     * @param maximumValue BigDecimal from the discount to compare
     * @return {@link LogicError} if is invalid
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private LogicError doValidateDiscountPercentage(final BigDecimal value, final BigDecimal maximumValue) {
        return value.compareTo(maximumValue) > 0 ? ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MAXIMUM_DISCOUNT_PERCENTAGE,
                maximumValue.toString(),
                Constants.FIELD_DISCOUNT_PERCENTAGE,
                Constants.MESSAGE_DISCOUNT_PERCENTAGE_INCONSISTENT) : null;
    }

    /**
     * Returns an error if the discount value is higher than the permitted
     *
     * @param value        BigDecimal from the sale to compare
     * @param maximumValue BigDecimal from the discount to compare
     * @return {@link LogicError} if is invalid
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private LogicError doValidateDiscountValue(final BigDecimal value, final BigDecimal maximumValue) {
        return value.compareTo(maximumValue) > 0 ? ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MAXIMUM_DISCOUNT_VALUE,
                maximumValue.toString(),
                Constants.FIELD_DISCOUNT_VALUE,
                Constants.MESSAGE_DISCOUNT_VALUE_INCONSISTENT) : null;
    }

    /**
     * Create and fill the discount search
     *
     * @param companyId          to set search
     * @param userProfessionalId to set search
     * @param customerId         to set search
     * @param locationId         to set search
     * @param productGroupId     to set search
     * @param priceListId        to set search
     * @param productId          to set search
     * @param priceListItemId    to set search
     * @param discountType       to set search
     * @param betweenDate        to set search
     * @return {@link DiscountSearch}
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private DiscountSearch getDiscountSearch(final UUID companyId,
                                             final UUID userProfessionalId,
                                             final UUID customerId,
                                             final UUID locationId,
                                             final UUID productGroupId,
                                             final UUID priceListId,
                                             final UUID productId,
                                             final UUID priceListItemId,
                                             final String discountType,
                                             final OffsetDateTime betweenDate) {
        final DiscountSearch discountSearch = new DiscountSearch();
        discountSearch.setBetweenDate(betweenDate.toLocalDate().toString());
        Optional.ofNullable(discountType).ifPresent(type -> {
            this.doFillDiscountSearchFields(type, companyId, discountSearch, Constants.FIELD_COMPANY_ID, DiscountType.COMPANY);
            this.doFillDiscountSearchFields(type, userProfessionalId, discountSearch, Constants.FIELD_USER_ID, DiscountType.USER);
            this.doFillDiscountSearchFields(type, customerId, discountSearch, Constants.FIELD_CUSTOMER_ID, DiscountType.CUSTOMER);
            this.doFillDiscountSearchFields(type, locationId, discountSearch, Constants.FIELD_COMPANY_ID, DiscountType.LOCATION);
            this.doFillDiscountSearchFields(type, productGroupId, discountSearch, Constants.FIELD_PRODUCT_GROUP_ID, DiscountType.PRODUCT_GROUP);
            this.doFillDiscountSearchFields(type, priceListId, discountSearch, Constants.FIELD_PRICE_LIST_ID, DiscountType.PRICE_LIST);
            this.doFillDiscountSearchFields(type, productId, discountSearch, Constants.FIELD_PRODUCT_ID, DiscountType.PRODUCT);
            this.doFillDiscountSearchFields(type, priceListItemId, discountSearch, Constants.FIELD_PRICE_LIST_ITEM_ID, DiscountType.PRICE_LIST_ITEM);
        });
        return discountSearch;
    }

    /**
     * Fill the search if the entity exists and is equal to the discount type
     *
     * @param discountType   to compare with the enum
     * @param entityId       to set the search
     * @param discountSearch to be manipulated
     * @param stringField    to get the field with reflection
     * @param eDiscountType  to see if the discount type is the same as the type
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    private void doFillDiscountSearchFields(final String discountType,
                                            final UUID entityId,
                                            final DiscountSearch discountSearch,
                                            final String stringField,
                                            final DiscountType eDiscountType) {
        final Field field = FieldReflectionHelper.fromInstance(discountSearch).getField(stringField);
        if (eDiscountType.toString().equals(discountType)) {
            Optional.ofNullable(entityId).ifPresent(id -> FieldReflectionHelper.fromInstance(discountSearch).setFieldValue(field, id.toString()));
        }
    }
}
