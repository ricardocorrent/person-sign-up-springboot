package com.ws.sales.external.customer;


import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.customer.customer.CustomerResource;
import com.ws.customer.location.LocationResource;
import com.ws.customer.model.Customer;
import com.ws.customer.model.Location;
import com.ws.customer.model.LocationSearch;
import com.ws.sales.external.AbstractGateway;
import org.apache.http.HttpStatus;

import javax.ws.rs.core.Response;
import java.util.UUID;

import static java.util.Objects.nonNull;

/**
 * @author ivan.reffatti
 * @author Marco Aurelio F. Schaefer
 * @since 2017/04/19
 */
public class CustomerGateway extends AbstractGateway {

    @InjectProxy
    private LocationResource locationResource;

    @InjectProxy
    private CustomerResource customerResource;

    /**
     * This method return true if the location is the same of customer location.
     *
     * @param locationId the location id
     * @param customerId the customer id
     * @return true if locations is the same of customer location
     */
    public Boolean locationIsTheSameForTheCustomer(final UUID locationId, final UUID customerId) {
        LocationSearch locationSearch = new LocationSearch();
        locationSearch.setId(locationId.toString());
        locationSearch.getCustomerIds().add(customerId.toString());
        final Response response = locationResource.search(locationSearch);
        return response != null && response.hasEntity() && response.getStatus() == HttpStatus.SC_OK;
    }

    /**
     * Method to get a location from customer service
     *
     * @param id id from location
     * @return location
     */
    public Location getLocation(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Location.class, id, locationResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if location exists
     *
     * @param id id to get location
     * @return {@code true} if location is exists, {@code false} otherwise
     */
    public Boolean locationExists(final UUID id) {
        return getLocation(id) != null;
    }

    /**
     * Method to return if location is active
     *
     * @param id id to get location
     * @return {@code true} if location is active, {@code false} otherwise
     */
    public Boolean locationIsActive(final UUID id) {
        final Location location = this.getLocation(id);
        if (location != null) {
            return location.isActive();
        }
        return Boolean.TRUE;
    }

    /**
     * Method to check if location belongs to customer
     *
     * @param locationId location id to check
     * @param customerId customer id to get locations
     * @return {@code true} if location belongs to customer, {@code false} otherwise
     */
    public Boolean locationBelongsToCustomer(final UUID locationId, final UUID customerId) {
        Location location = getLocation(locationId);
        if (location != null) {
            return location.getCustomer() != null && location.getCustomer().getId().equals(customerId.toString());
        }
        return Boolean.TRUE;
    }

    /**
     * Method to get a customer from customer service
     *
     * @param id id from customer
     * @return customer
     */
    public Customer getCustomer(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Customer.class, id, customerResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if customer exists
     *
     * @param id id to get customer
     * @return {@code true} if customer is exists, {@code false} otherwise
     */
    public Boolean customerExists(final UUID id) {
        return getCustomer(id) != null;
    }

    /**
     * Method to return if customer is active
     *
     * @param id id to get customer
     * @return {@code true} if customer is active, {@code false} otherwise
     */
    public Boolean customerIsActive(final UUID id) {
        final Customer customer = this.getCustomer(id);
        if (customer != null) {
            return customer.isActive();
        }
        return Boolean.TRUE;
    }
}