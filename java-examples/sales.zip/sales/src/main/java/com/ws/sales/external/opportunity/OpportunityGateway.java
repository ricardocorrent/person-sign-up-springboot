package com.ws.sales.external.opportunity;

import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.opportunity.activity.ActivityResource;
import com.ws.sales.external.AbstractGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 8.3.0 2019-05-20
 */
public class OpportunityGateway extends AbstractGateway {

    @InjectProxy
    private ActivityResource resource;

    private final Logger logger = LoggerFactory.getLogger(OpportunityGateway.class);

    /**
     * Finds an activity from the opportunity service.
     * @param activityId
     * @return
     */
    public ActivityDTO getActivity(UUID activityId) {
        logger.info(String.format("Retrieving activity with id [%s] from opportunity.", activityId));
        return getEntityFromGatewayCall(ActivityDTO.class, activityId, resource::get, activityId.toString());
    }

    /**
     * Checks if an activity with the given id exists.
     * @param activityId the id of the activity to check.
     * @return true if the activity exists on the opportunity service.
     */
    public boolean activityExists(UUID activityId) {
        return getActivity(activityId) != null;
    }

    /**
     * Does the opposite of {@link #activityExists(UUID)}.
     * @param activityId the id of the activity to check.
     * @return true if the activity does not exist on the opportunity service.
     */
    public boolean activityNotExists(UUID activityId) {
        return !activityExists(activityId);
    }
}
