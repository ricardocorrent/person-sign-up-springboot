package com.ws.sales.invoicesituation;

import com.ws.commons.server.pagination.PaginationSearch;

import java.util.UUID;

/**
 * The class InvoiceSituationSearch its a filter class to search a invoice situation, here the user can put
 * the filters to search a invoice situation as expected.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-28
 */
public class InvoiceSituationSearch extends PaginationSearch {

    /**
     * This field is used to filter a invoice situation by id.
     */
    private UUID id;

    /**
     * This field is used to filter a invoice situation by description.
     */
    private String description;

    /**
     * This field is used to filter a invoice situation by active.
     */
    private Boolean active;

    /**
     * Gets id.
     *
     * @return the id
     */
    public UUID getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param id the id
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets active.
     *
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Sets active.
     *
     * @param active the active
     */
    public void setActive(Boolean active) {
        this.active = active;
    }
}