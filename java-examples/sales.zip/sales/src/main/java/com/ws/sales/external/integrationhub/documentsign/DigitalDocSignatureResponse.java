package com.ws.sales.external.integrationhub.documentsign;

/**
 * Entity to represents de internal contract
 * when responding the send of a document.
 *
 * @since 1.0.0 2019-05-08
 *
 * @author ricardo.corrent
 */
public class DigitalDocSignatureResponse {

    private String documentId;

    private String signatureId;

    private String createdAt;

    private String publishedAt;

    private Object errors;

    /**
     * Get of property {@link #documentId}
     *
     * @return java.lang.String
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Set of property {@link #documentId}
     *
     * @param documentId field to set
     */
    public void setDocumentId(final String documentId) {
        this.documentId = documentId;
    }

    /**
     * Get of property {@link #signatureId}
     *
     * @return java.lang.String
     */
    public String getSignatureId() {
        return signatureId;
    }

    /**
     * Set of property {@link #signatureId}
     *
     * @param signatureId field to set
     */
    public void setSignatureId(final String signatureId) {
        this.signatureId = signatureId;
    }

    /**
     * Get of property {@link #createdAt}
     *
     * @return java.lang.String
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Set of property {@link #createdAt}
     *
     * @param createdAt field to set
     */
    public void setCreatedAt(final String createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Get of property {@link #publishedAt}
     *
     * @return java.lang.String
     */
    public String getPublishedAt() {
        return publishedAt;
    }

    /**
     * Set of property {@link #publishedAt}
     *
     * @param publishedAt field to set
     */
    public void setPublishedAt(final String publishedAt) {
        this.publishedAt = publishedAt;
    }

    /**
     * Get of property {@link #errors}
     *
     * @return java.lang.Object
     */
    public Object getErrors() {
        return errors;
    }

    /**
     * Set of property {@link #errors}
     *
     * @param errors field to set
     */
    public void setErrors(final Object errors) {
        this.errors = errors;
    }
}
