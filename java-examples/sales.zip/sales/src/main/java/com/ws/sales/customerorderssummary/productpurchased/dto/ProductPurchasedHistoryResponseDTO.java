package com.ws.sales.customerorderssummary.productpurchased.dto;

import com.ws.commons.pojoconverter.IPojoConverter;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

/**
 * This DTO represent the list of details' product that will be sent formatted to the front end
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-21
 */
@Getter
@Setter
public class ProductPurchasedHistoryResponseDTO implements Serializable, IPojoConverter {

    private UUID id;

    private String description;

    private List<ProductPurchasedHistoryDTO> purchaseDetails;

    private Integer count;

    private Integer page;

    private Integer pageSize;
}
