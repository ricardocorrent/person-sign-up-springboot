package com.ws.sales.external.cloudmanager;

import org.apache.deltaspike.core.api.config.ConfigProperty;

import javax.inject.Inject;

/**
 * Cloud Manager related configurations
 * Copied Class - created by Alan J. A. Pena
 * https://gitlab.wssim.com.br/cloud/demand-generation/blob/development/src/main/java/com/ws/demandgeneration/gateway/CloudManagerGateway.java}
 *
 * @author Alan J. A. Pena
 * @since 2018-10-26
 */
public class CloudManagerConfig {

    private static final String INTEGRATION_TOKEN_CLOUD_MANAGER = "integration.token.cloud.manager";
    private static final String INTEGRATION_ADDRESS_CLOUD_MANAGER = "integration.address.cloud.manager";
    private static final String INTEGRATION_ADDRESS_CLOUD_MANAGER_DEFAULT_VALUE = "http://cloudmanager.wssim.com.br/api/v5/cloud-manager";

    private final String address;
    private final String token;

    @Inject
    public CloudManagerConfig(
        @ConfigProperty(
            name = INTEGRATION_ADDRESS_CLOUD_MANAGER,
            defaultValue = INTEGRATION_ADDRESS_CLOUD_MANAGER_DEFAULT_VALUE) final String address,
        @ConfigProperty(name = INTEGRATION_TOKEN_CLOUD_MANAGER) final String token) {
        this.address = address;
        this.token = token;
    }

    public String getAddress() {
        return address;
    }

    public String getToken() {
        return token;
    }
}
