package com.ws.sales.orderitem;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonView;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.persistence.model.Views;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.sales.order.SalesOrder;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29.
 */
@Entity
@PreventRecycling
public class SalesOrderItem extends PhysicalDeleteBaseEntity implements Serializable, DefaultPojoConverter {

    @NotNull
    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    @PojoColumnFilter(value = {"id"})
    private SalesOrder salesOrder;

    @NotNull
    @PojoColumnMapper(target = "product.id")
    private UUID productId;

    @Size(max = 255)
    @PojoColumnMapper(target = "product.description")
    private String productDescription;

    @Size(max = 40)
    @PojoColumnMapper(target = "product.code")
    private String productCode;

    @PojoColumnMapper(target = "priceList.id")
    private UUID priceListId;

    @Size(max = 255)
    @PojoColumnMapper(target = "priceList.description")
    private String priceListDescription;

    @PojoColumnMapper(target = "priceListItem.id")
    private UUID priceListItemId;

    @PojoColumnMapper(target = "situation.id")
    private UUID salesOrderItemSituationID;

    @Size(max = 255)
    @PojoColumnMapper(target = "situation.description")
    private String salesOrderItemSituationDescription;

    @NotNull
    @DecimalMin("0.000001")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    @Column(name = "gross_value")
    private BigDecimal originalPrice;

    @NotNull
    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    @Column(name = "net_value")
    private BigDecimal salesPrice;

    @NotNull
    @DecimalMin(value = "0.000001", message = "quantity.validation.min.value.greater.than.zero")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal quantity;

    private Integer rank;

    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal invoicedValue;

    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal invoicedQuantity;

    @PojoColumnMapper(target = "packaging.id")
    private UUID productPackagingId;

    @Size(max = 255)
    @PojoColumnMapper(target = "packaging.description")
    private String productPackagingDescription;

    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    @PojoColumnMapper(target = "total")
    private BigDecimal totalItem;

    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    @Column(name = "discount")
    private BigDecimal discountValue;

    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    @Column(name = "due_date_value")
    private BigDecimal dueDateValue;

    @DecimalMin("0")
    @DecimalMax("100")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal discountPercentage;

    @Size(max = 255)
    @JsonView(Views.Public.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String externalId;

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#getExternalId()
     */
    @Override
    public String getExternalId() {
        return externalId;
    }

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#setExternalId(java.lang.Object)
     */
    @Override
    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    /**
     * informs the value to increase in the item
     */
    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal increaseValue;

    /**
     * informs the percentage to increase
     */
    @DecimalMin("0")
    @Digits(integer = 18, fraction = 6, message = "validation.value.greater.than.allowed")
    private BigDecimal increasePercentage;

    /**
     * Get of property {@link #salesOrder}
     *
     * @return com.ws.sales.order.SalesOrder
     */
    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    /**
     * Set of property {@link #salesOrder}
     *
     * @param salesOrder field to set
     */
    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    /**
     * Get of property {@link #productId}
     *
     * @return java.util.UUID
     */
    public UUID getProductId() {
        return productId;
    }

    /**
     * Set of property {@link #productId}
     *
     * @param productId field to set
     */
    public void setProductId(final UUID productId) {
        this.productId = productId;
    }

    /**
     * Get of property {@link #productDescription}
     *
     * @return java.lang.String
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Set of property {@link #productDescription}
     *
     * @param productDescription field to set
     */
    public void setProductDescription(final String productDescription) {
        this.productDescription = productDescription;
    }

    /**
     * Get of property {@link #productCode}
     *
     * @return java.lang.String
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Set of property {@link #productCode}
     *
     * @param productCode field to set
     */
    public void setProductCode(final String productCode) {
        this.productCode = productCode;
    }

    /**
     * Get of property {@link #priceListId}
     *
     * @return java.util.UUID
     */
    public UUID getPriceListId() {
        return priceListId;
    }

    /**
     * Set of property {@link #priceListId}
     *
     * @param priceListId field to set
     */
    public void setPriceListId(final UUID priceListId) {
        this.priceListId = priceListId;
    }

    /**
     * Get of property {@link #priceListDescription}
     *
     * @return java.lang.String
     */
    public String getPriceListDescription() {
        return priceListDescription;
    }

    /**
     * Set of property {@link #priceListDescription}
     *
     * @param priceListDescription field to set
     */
    public void setPriceListDescription(final String priceListDescription) {
        this.priceListDescription = priceListDescription;
    }

    /**
     * Get of property {@link #priceListItemId}
     *
     * @return java.util.UUID
     */
    public UUID getPriceListItemId() {
        return priceListItemId;
    }

    /**
     * Set of property {@link #priceListItemId}
     *
     * @param priceListItemId field to set
     */
    public void setPriceListItemId(final UUID priceListItemId) {
        this.priceListItemId = priceListItemId;
    }

    /**
     * Get of property {@link #salesOrderItemSituationID}
     *
     * @return java.util.UUID
     */
    public UUID getSalesOrderItemSituationID() {
        return salesOrderItemSituationID;
    }

    /**
     * Set of property {@link #salesOrderItemSituationID}
     *
     * @param salesOrderItemSituationID field to set
     */
    public void setSalesOrderItemSituationID(final UUID salesOrderItemSituationID) {
        this.salesOrderItemSituationID = salesOrderItemSituationID;
    }

    /**
     * Get of property {@link #salesOrderItemSituationDescription}
     *
     * @return java.lang.String
     */
    public String getSalesOrderItemSituationDescription() {
        return salesOrderItemSituationDescription;
    }

    /**
     * Set of property {@link #salesOrderItemSituationDescription}
     *
     * @param salesOrderItemSituationDescription field to set
     */
    public void setSalesOrderItemSituationDescription(final String salesOrderItemSituationDescription) {
        this.salesOrderItemSituationDescription = salesOrderItemSituationDescription;
    }

    /**
     * Get of property {@link #originalPrice}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    /**
     * Set of property {@link #originalPrice}
     *
     * @param originalPrice field to set
     */
    public void setOriginalPrice(final BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    /**
     * Get of property {@link #salesPrice}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    /**
     * Set of property {@link #salesPrice}
     *
     * @param salesPrice field to set
     */
    public void setSalesPrice(final BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    /**
     * Get of property {@link #quantity}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getQuantity() {
        return quantity;
    }

    /**
     * Set of property {@link #quantity}
     *
     * @param quantity field to set
     */
    public void setQuantity(final BigDecimal quantity) {
        this.quantity = quantity;
    }

    /**
     * Get of property {@link #rank}
     *
     * @return java.lang.Integer
     */
    public Integer getRank() {
        return rank;
    }

    /**
     * Set of property {@link #rank}
     *
     * @param rank field to set
     */
    public void setRank(final Integer rank) {
        this.rank = rank;
    }

    /**
     * Get of property {@link #invoicedValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getInvoicedValue() {
        return invoicedValue;
    }

    /**
     * Set of property {@link #invoicedValue}
     *
     * @param invoicedValue field to set
     */
    public void setInvoicedValue(final BigDecimal invoicedValue) {
        this.invoicedValue = invoicedValue;
    }

    /**
     * Get of property {@link #invoicedQuantity}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getInvoicedQuantity() {
        return invoicedQuantity;
    }

    /**
     * Set of property {@link #invoicedQuantity}
     *
     * @param invoicedQuantity field to set
     */
    public void setInvoicedQuantity(final BigDecimal invoicedQuantity) {
        this.invoicedQuantity = invoicedQuantity;
    }

    /**
     * Get of property {@link #productPackagingId}
     *
     * @return java.util.UUID
     */
    public UUID getProductPackagingId() {
        return productPackagingId;
    }

    /**
     * Set of property {@link #productPackagingId}
     *
     * @param productPackagingId field to set
     */
    public void setProductPackagingId(final UUID productPackagingId) {
        this.productPackagingId = productPackagingId;
    }

    /**
     * Get of property {@link #productPackagingDescription}
     *
     * @return java.lang.String
     */
    public String getProductPackagingDescription() {
        return productPackagingDescription;
    }

    /**
     * Set of property {@link #productPackagingDescription}
     *
     * @param productPackagingDescription field to set
     */
    public void setProductPackagingDescription(final String productPackagingDescription) {
        this.productPackagingDescription = productPackagingDescription;
    }

    /**
     * Get of property {@link #totalItem}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getTotalItem() {
        return totalItem;
    }

    /**
     * Set of property {@link #totalItem}
     *
     * @param totalItem field to set
     */
    public void setTotalItem(final BigDecimal totalItem) {
        this.totalItem = totalItem;
    }

    /**
     * Get of property {@link #discountValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDiscountValue() {
        return discountValue;
    }

    /**
     * Set of property {@link #discountValue}
     *
     * @param discountValue field to set
     */
    public void setDiscountValue(final BigDecimal discountValue) {
        this.discountValue = discountValue;
    }

    /**
     * Get of property {@link #dueDateValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDueDateValue() {
        return dueDateValue;
    }

    /**
     * Set of property {@link #dueDateValue}
     *
     * @param dueDateValue field to set
     */
    public void setDueDateValue(final BigDecimal dueDateValue) {
        this.dueDateValue = dueDateValue;
    }

    /**
     * Get of property {@link #discountPercentage}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    /**
     * Set of property {@link #discountPercentage}
     *
     * @param discountPercentage field to set
     */
    public void setDiscountPercentage(final BigDecimal discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    /**
     * Get of property {@link #increaseValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getIncreaseValue() {
        return increaseValue;
    }

    /**
     * Set of property {@link #increaseValue}
     *
     * @param increaseValue field to set
     */
    public void setIncreaseValue(final BigDecimal increaseValue) {
        this.increaseValue = increaseValue;
    }

    /**
     * Get of property {@link #increasePercentage}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getIncreasePercentage() {
        return increasePercentage;
    }

    /**
     * Set of property {@link #increasePercentage}
     *
     * @param increasePercentage field to set
     */
    public void setIncreasePercentage(final BigDecimal increasePercentage) {
        this.increasePercentage = increasePercentage;
    }
}
