package com.ws.sales.external.product.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.sales.external.administration.dto.CompanyDTO;
import com.ws.sales.external.customer.dto.CustomerDTO;
import com.ws.sales.external.customer.dto.LocationDTO;
import com.ws.sales.external.user.dto.UserDTO;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DiscountDTO extends BaseDTO implements DefaultPojoConverter {

    private String description;

    private BigDecimal maximumDiscountValue;

    private BigDecimal maximumDiscountPercentage;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate startAt;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate endAt;

    private ProductGroupDTO productGroup;

    private PriceListDTO priceList;

    private PriceListItemSelectDTO priceListItem;

    private ProductSimpleDTO product;

    private String productDescription;

    private UserDTO user;

    private CustomerDTO customer;

    private LocationDTO location;

    private CompanyDTO company;

    public PriceListItemSelectDTO getPriceListItem() {
        return priceListItem;
    }

    public void setPriceListItem(PriceListItemSelectDTO priceListItem) {
        this.priceListItem = priceListItem;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getMaximumDiscountValue() {
        return maximumDiscountValue;
    }

    public void setMaximumDiscountValue(BigDecimal maximumDiscountValue) {
        this.maximumDiscountValue = maximumDiscountValue;
    }

    public BigDecimal getMaximumDiscountPercentage() {
        return maximumDiscountPercentage;
    }

    public void setMaximumDiscountPercentage(BigDecimal maximumDiscountPercentage) {
        this.maximumDiscountPercentage = maximumDiscountPercentage;
    }

    public LocalDate getStartAt() {
        return startAt;
    }

    public void setStartAt(LocalDate startAt) {
        this.startAt = startAt;
    }

    public LocalDate getEndAt() {
        return endAt;
    }

    public void setEndAt(LocalDate endAt) {
        this.endAt = endAt;
    }

    public ProductGroupDTO getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(ProductGroupDTO productGroup) {
        this.productGroup = productGroup;
    }

    public PriceListDTO getPriceList() {
        return priceList;
    }

    public void setPriceList(PriceListDTO priceList) {
        this.priceList = priceList;
    }

    public ProductSimpleDTO getProduct() {
        return product;
    }

    public void setProduct(ProductSimpleDTO product) {
        this.product = product;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public CustomerDTO getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDTO customer) {
        this.customer = customer;
    }

    public LocationDTO getLocation() {
        return location;
    }

    public void setLocation(LocationDTO location) {
        this.location = location;
    }

    public CompanyDTO getCompany() {
        return company;
    }

    public void setCompany(CompanyDTO company) {
        this.company = company;
    }


    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

}
