package com.ws.sales.external.product;

/**
 * Enum to handle validation types
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-21
 */
public enum DiscountType {

    /**
     * company
     */
    COMPANY("COMP"),

    /**
     * user
     */
    USER("USER"),

    /**
     * customer
     */
    CUSTOMER("CUST"),

    /**
     * location
     */
    LOCATION("LCTN"),

    /**
     * product group
     */
    PRODUCT_GROUP("PRGR"),

    /**
     * price list
     */
    PRICE_LIST("PRCL"),

    /**
     * price list item
     */
    PRICE_LIST_ITEM("PRLI"),

    /**
     * product
     */
    PRODUCT("PROD"),

    /**
     * free
     */
    FREE("FREE");

    private final String name;

    /**
     * Constructor to handle the enum names
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-26
     */
    DiscountType(final String type) {
        this.name = type;
    }
    
    /**
     * Get of property {@link #name}
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }
}
