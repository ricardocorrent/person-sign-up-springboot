package com.ws.sales.invoice;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.exception.MessageException;
import com.ws.sales.invoicesituation.InvoiceSituation;
import com.ws.sales.invoicesituation.InvoiceSituationDAO;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

/**
 * The class InvoiceService is used to call the validator of business rules and the DAO layer(persistence layer).
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
public class InvoiceService extends AbstractService<Invoice> {

    /**
     * Injects InvoiceDAO class for communication between layers of InvoiceService
     * and InvoiceDAO.
     */
    private final InvoiceDAO invoiceDAO;

    /**
     * Injects InvoiceSituationDAO class for communication between layers of InvoiceService
     * and InvoiceSituationDAO.
     */
    private final InvoiceSituationDAO invoiceSituationDAO;

    @Inject
    public InvoiceService(InvoiceDAO dao, InvoiceSituationDAO invoiceSituationDAO) {
        super(dao);
        this.invoiceDAO = dao;
        this.invoiceSituationDAO = invoiceSituationDAO;
    }

    /**
     * Method to search a list of Invoice by filter.
     *
     * @param invoiceSearch the invoice search.
     * @return the paged list of invoice.
     */
    public PagedList<Invoice> search(final InvoiceSearch invoiceSearch) {
        return invoiceDAO.search(invoiceSearch);
    }

    /**
     * Method for insert a invoice, but first its call a validator for business rules
     *
     * @param invoice invoice to be inserted.
     * @return return the inserted invoice.
     * @throws Exception
     */
    @Override
    public Invoice insert(Invoice invoice) throws Exception {
        invoiceDAO.insert(invoice);
        return invoice;
    }

    /**
     * Method to update the relationship between invoice and invoice situation, but first it will be validate all
     * the business rules for update.
     *
     * @param invoiceId       represents the id for invoice
     * @param updateInvoiceTO contain the invoice situation id for update
     */
    public void updateSituationForInvoice(final UUID invoiceId, final UpdateInvoiceTO updateInvoiceTO) {

        validateIfInvoiceExists(invoiceId);

        Objects.requireNonNull(updateInvoiceTO, "The informations to update must be informed");

        validateIfInvoiceSituationExists(updateInvoiceTO.getInvoiceSituationId());

        Invoice invoiceConsulted = invoiceDAO.findById(invoiceId);

        InvoiceSituation invoiceSituationConsulted = invoiceSituationDAO.findById(updateInvoiceTO.getInvoiceSituationId());

        updateInvoiceSituationForInvoice(invoiceConsulted, invoiceSituationConsulted);

        invoiceDAO.update(invoiceConsulted);
    }

    /**
     * Method to validate if invoice exists, if not a exception will be invoked.
     *
     * @param invoiceId invoice id to used to find the invoice
     */
    private void validateIfInvoiceExists(final UUID invoiceId) {

        if (!invoiceDAO.invoiceExists(invoiceId)) {
            throw new MessageException("invoice.invoiceNotFoundFoUpdate");
        }
    }

    /**
     * Method to validate if invoice situation exists, if not a exception will be invoked.
     *
     * @param invoiceSituationId invoice situation id to used to find the invoice situation
     */
    private void validateIfInvoiceSituationExists(final UUID invoiceSituationId) {

        if (!invoiceSituationDAO.invoiceSituationExists(invoiceSituationId)) {
            throw new MessageException("invoice.invoiceSituationNotFoundForUpdate");
        }
    }

    /**
     * Method to update the relationship between invoice and invoice situation.
     *
     * @param invoiceConsulted          invoice consulted to be updated
     * @param invoiceSituationConsulted invoice situation consulted to be used for update
     */
    private void updateInvoiceSituationForInvoice(Invoice invoiceConsulted, InvoiceSituation invoiceSituationConsulted) {

        if (invoiceSituationConsulted != null) {
            // CLEAN THE TWO SIDES OF RELATIONSHIP.
            invoiceSituationConsulted.setInvoices(null);
            invoiceConsulted.setInvoiceSituation(null);

            InvoiceSituation invoiceSituation = new InvoiceSituation();
            invoiceSituation.setId(invoiceSituationConsulted.getId());

            // SET THE TWO SIDES OF RELATIONSHIP.
            invoiceSituation.setInvoices(Arrays.asList(invoiceConsulted));
            invoiceConsulted.setInvoiceSituation(invoiceSituation);
        }
    }
}