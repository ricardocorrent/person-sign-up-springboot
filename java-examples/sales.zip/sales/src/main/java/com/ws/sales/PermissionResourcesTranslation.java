package com.ws.sales;

import com.ws.commons.ServerProperties;
import com.ws.commons.server.messagebundle.MessageBundle;
import com.ws.commons.server.resource.permissionsresource.PermissionResourcesResource;

import javax.enterprise.inject.Default;
import javax.inject.Inject;

/**
 * @author Peterson Schmitt
 * @since 2018-10-26
 */
@Default
public class PermissionResourcesTranslation extends PermissionResourcesResource {
    private final MessageBundle messageBundle;
    private final ServerProperties serverProperties;
    /**
     * Properties are required, because we need to get the {@link ServerProperties#getServiceName()} in
     *
     * @param properties server properties
     */
    @Inject
    public PermissionResourcesTranslation(final ServerProperties properties, final MessageBundle messageBundle) {
        super(properties);
        this.messageBundle = messageBundle;
        this.serverProperties = properties;
    }
    @Override
    protected String getServiceDescription() {
        return messageBundle.getDefaultMessage("permissions.service").getMessage();
    }
    @Override
    protected String getResourceDescription(final String path) {
        return messageBundle
                .getDefaultMessage("permissions." + path)
                .getMessage();
    }
}
