package com.ws.sales.situation;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.UUID;

/**
 * @author thyago.volpatto
 * @since v5.1.0 19/04/2017.
 */
public class SituationDAO extends AbstractDAO<Situation> {

    /**
     * Method return class entity
     *
     * @return Class
     */

    @Override
    public Class<Situation> getEntityClass() {
        return Situation.class;
    }


    /**
     * Search for {@link Situation} applying the filters in {@link Situation}
     *
     * @param search Filters to apply, as {@link SituationSearch}
     * @return PagedList<Situation>
     */
    public PagedList<Situation> list(final SituationSearch search) {

        final Query<Situation> query = find();

        final ExpressionList<Situation> where = query.where();

        if (search.getSituationId() != null) {
            where.eq("id", search.getSituationId());
        }

        if (search.getAcronym() != null) {
            where.eq("acronym", search.getAcronym());
        }

        if (!StringUtils.isEmpty(search.getDescription())) {
            where.contains("description", search.getDescription());
        }

        return getPagedList(query, search);
    }

    /**
     * Returns true if the situation is a valid one or false if is not.
     *
     * @param id
     * @return java.lang.Boolean
     */
    public Boolean situationExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }

    /**
     * Returns  true if all the situations are valid.
     *
     * @param ids
     * @return
     */
    public Boolean situationsExists(final List<UUID> ids) {
        List<Situation> list = find().select("id").where().in("id", ids).findIds();
        return list.size() == ids.size();
    }
}
