package com.ws.sales.orderintegration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since 8.6.0 2019-06-27
 */
@Getter
@Setter
public class CurrencyIntegrationDTO extends BaseDTO {

    private UUID id;

    private String description;

}
