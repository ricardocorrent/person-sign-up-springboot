package com.ws.sales.util;

import br.com.wealthsystems.server.resource.RecordPermissionResource;
import com.sollar.recordpermission.accessgroup.PermissionChangesQuery;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.AbstractResource;
import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.commons.server.resource.ResourceUtils;
import io.ebean.EbeanServer;
import org.apache.shiro.SecurityUtils;

import javax.inject.Inject;
import java.lang.reflect.ParameterizedType;
import java.util.UUID;

import static com.ws.commons.server.resource.HTTPHeaders.USER_ROLE_INTEGRATION;

/**
 * @author Maykon Roberto Rissi
 * @since 5.22.0 - 2018-07-30
 */
public abstract class SalesAbstractResource<T extends BaseModel, P extends PaginationSearch>
        extends AbstractResource<T, P> implements RecordPermissionResource<T> {

    @Inject
    private PermissionChangesQuery permissionChangesQuery;

    @Inject
    private EbeanServer ebeanServer;

    /**
     * @author Maykon Roberto Rissi
     * @see RecordPermissionResource#getPermissionChangesQuery()
     * @since 5.22.0 - 2018-07-30
     */
    @Override
    public PermissionChangesQuery getPermissionChangesQuery() {
        return permissionChangesQuery;
    }

    /**
     * @author Maykon Roberto Rissi
     * @see RecordPermissionResource#getEntityClass()
     * @since 5.22.0 - 2018-07-30
     */
    @Override
    @SuppressWarnings("unchecked")
    public Class<T> getEntityClass() {
        return (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    /**
     * @author Maykon Roberto Rissi
     * @see RecordPermissionResource#getEbeanServer()
     * @since 5.22.0 - 2018-07-30
     */
    @Override
    public EbeanServer getEbeanServer() {
        return ebeanServer;
    }

    /**
     * @author Maykon Roberto Rissi
     * @see RecordPermissionResource#checkPermission()
     * @since 5.22.0 - 2018-07-30
     */
    @Override
    public void checkPermission() {
        ResourceUtils.requireHeader(USER_ROLE_INTEGRATION.getHeaderName(), USER_ROLE_INTEGRATION.getHeaderValue(), httpRequest);
    }

    /**
     * @author Maykon Roberto Rissi
     * @see RecordPermissionResource#getUserId()
     * @since 5.22.0 - 2018-07-30
     */
    @Override
    public UUID getUserId() {
        final Object id = SecurityUtils.getSubject().getSession().getAttribute(Constants.FIELD_USER_ID_CONTEXT);
        return id instanceof String ? UUID.fromString((String) id) : null;
    }
}
