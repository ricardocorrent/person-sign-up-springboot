package com.ws.sales.validator;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * Exposes methods to make it easier to do linked Logic Validations
 * e.g.
 * <p>
 * Validation1
 * Validation2
 * Validation3
 * <p>
 * Given you just want to run the Validation2 if the Validation1 pass
 * And you just want to run the Validation3 if both Validations 1 and 2 passes
 * you can do something like
 * <p>
 * List<LogicError> errors = new ArrayList<>();
 * <p>
 * applyValidator(Validation1, {{ValidationParameter}}, errors)
 * applyValidator(Validation2, {{ValidationParameter}}, errors)
 * applyValidator(Validation3, {{ValidationParameter}}, errors)
 *
 * @author Frank Pilloni Tominc
 * @since 2018-05-07
 */
public final class GenericValidator {

    /**
     * applyValidator(Validation3, {{ValidationParameter}}, errors)
     *
     * @author Frank Pilloni Tominc
     * @since 2018-05-07
     */
    private GenericValidator() {
    }

    /**
     * This method calls a validation function that requires just one parameter
     *
     * @param function the validation function
     * @param value    the validation parameter
     * @param errors   the list of errors for the linked validations
     * @param <T>      the validation function parameter type
     * @param <R>      the validation function return type
     */
    public static <T, R> void applyValidator(Function<T, R> function, T value, List<R> errors) {
        if (errors.isEmpty()) {
            R returnValue = function.apply(value);
            if (returnValue != null) {
                errors.add(returnValue);
            }
        }
    }

    /**
     * This method calls a validation function that requires two parameters
     *
     * @param x      the validation function
     * @param value1 the validation first parameter
     * @param value2 the validation second parameter
     * @param errors the list of errors for the linked validations
     * @param <S>    the validation function first parameter type
     * @param <T>    the validation function second parameter type
     * @param <R>    the validation function return type
     */
    public static <S, T, R> void applyValidator(BiFunction<S, T, R> x, S value1, T value2, List<R> errors) {
        if (errors.isEmpty()) {
            R returnValue = x.apply(value1, value2);
            if (returnValue != null) {
                errors.add(returnValue);
            }
        }
    }
}