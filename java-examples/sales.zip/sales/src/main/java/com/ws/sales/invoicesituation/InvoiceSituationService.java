package com.ws.sales.invoicesituation;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * The class InvoiceSituationService is used to call the validator of business rules and the DAO layer(persistence layer).
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-28
 */
public class InvoiceSituationService extends AbstractService<InvoiceSituation> {

    /**
     * Injects InvoiceSituationDAO class for communication between layers of InvoiceSituationService
     * and InvoiceSituationDAO.
     */
    private final InvoiceSituationDAO dao;

    @Inject
    public InvoiceSituationService(InvoiceSituationDAO dao) {
        super(dao);
        this.dao = dao;
    }

    /**
     * Method to search a list of Invoice Situation by filter.
     *
     * @param invoiceSituationSearch the invoice situation search search.
     * @return the paged list of invoice situation.
     */
    public PagedList<InvoiceSituation> search(final InvoiceSituationSearch invoiceSituationSearch) {
        return dao.search(invoiceSituationSearch);
    }
}