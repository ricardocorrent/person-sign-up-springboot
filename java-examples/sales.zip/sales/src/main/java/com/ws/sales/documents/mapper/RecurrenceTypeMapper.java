package com.ws.sales.documents.mapper;

/**
 * @author Dante Basso <dante.basso@wwsim.com.br>
 * @version 1.0.0
 * @since 2019-03-18
 */
public class RecurrenceTypeMapper {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
