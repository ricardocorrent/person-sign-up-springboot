package com.ws.sales.paymenttermcustomerpermission;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.sales.paymentterm.PaymentTerm;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
@Entity
@PreventRecycling
public class PaymentTermCustomerPermission extends PhysicalDeleteBaseEntity implements IPojoConverter{

    @ManyToOne
    @JoinColumn(name = "payment_term_id")
    @JsonBackReference
    @NotNull
    private PaymentTerm paymentTerm;

    @NotNull
    @PojoColumnMapper(target = "customer.id")
    private UUID customerId;

    @NotNull
    @Size(max = 255)
    @PojoColumnMapper(target = "customer.name")
    private String customerName;

    /**
     * Get of property {@link #paymentTerm}
     *
     * @return com.ws.sales.paymentterm.PaymentTerm
     */
    public PaymentTerm getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * Set of property {@link #paymentTerm}
     *
     * @param paymentTerm field to set
     */
    public void setPaymentTerm(final PaymentTerm paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    /**
     * Get of property {@link #customerId}
     *
     * @return java.util.UUID
     */
    public UUID getCustomerId() {
        return customerId;
    }

    /**
     * Set of property {@link #customerId}
     *
     * @param customerId field to set
     */
    public void setCustomerId(final UUID customerId) {
        this.customerId = customerId;
    }

    /**
     * Get of property {@link #customerName}
     *
     * @return java.lang.String
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Set of property {@link #customerName}
     *
     * @param customerName field to set
     */
    public void setCustomerName(final String customerName) {
        this.customerName = customerName;
    }
}
