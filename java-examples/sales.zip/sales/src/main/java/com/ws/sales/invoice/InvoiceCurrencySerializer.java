package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * This class represents currency serializer for invoice, she will br serialize just the
 * fields id and description from invoice currency because it's just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
public class InvoiceCurrencySerializer extends StdSerializer<InvoiceCurrency> {

    /**
     * Instantiates a new invoice currency serializer.
     */
    public InvoiceCurrencySerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice currency serializer.
     *
     * @param t the t
     */
    protected InvoiceCurrencySerializer(Class<InvoiceCurrency> t) {
        super(t);
    }

    /**
     * This method override the serialization of InvoiceCurrency for Invoice class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(InvoiceCurrency value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        InvoiceCurrency invoiceCurrency = new InvoiceCurrency();
        invoiceCurrency.setId(value.getId());
        invoiceCurrency.setReplicatedId(value.getReplicatedId());
        invoiceCurrency.setDescription(value.getDescription());
        gen.writeObject(invoiceCurrency);
    }
}