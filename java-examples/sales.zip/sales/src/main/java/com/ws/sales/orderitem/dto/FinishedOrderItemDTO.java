package com.ws.sales.orderitem.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.sales.external.product.dto.PackagingDTO;
import com.ws.sales.external.product.dto.PriceListDTO;
import com.ws.sales.external.product.dto.PriceListItemDTO;
import com.ws.sales.external.product.dto.ProductDTO;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Fields for endpoint verification to update completed sales order item.
 *
 * @author Peterson Schmitt
 * @since 8.3.0 2019-05-31
 */
public class FinishedOrderItemDTO extends BaseDTO implements DefaultPojoConverter, Serializable {

    private static final long serialVersionUID = 5413751572582347005L;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "priceList.id", target = "priceListId"),
            @PojoColumnMapper(source = "priceList.description", target = "priceListDescription")
    })
    private PriceListDTO priceList;

    @PojoColumnMapper(source = "priceListItem.id", target = "priceListItemId")
    private PriceListItemDTO priceListItem;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "packaging.id", target = "productPackagingId"),
            @PojoColumnMapper(source = "packaging.description", target = "productPackagingDescription")
    })
    private PackagingDTO packaging;

    @PojoColumnsMapper({
            @PojoColumnMapper(source = "product.id", target = "productId"),
            @PojoColumnMapper(source = "product.description", target = "productDescription"),
            @PojoColumnMapper(source = "product.code", target = "productCode")
    })
    private ProductDTO product;

    private BigDecimal quantity;

    private BigDecimal originalPrice;

    private BigDecimal salesPrice;

    @PojoColumnMapper(target = "discount")
    private BigDecimal discountValue;

    private BigDecimal discountPercentage;

    private BigDecimal dueDateValue;

    /**
     * Get of property {@link #serialVersionUID}
     *
     * @return long
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * Get of property {@link #priceList}
     *
     * @return com.ws.sales.external.product.dto.PriceListDTO
     */
    public PriceListDTO getPriceList() {
        return priceList;
    }

    /**
     * Set of property {@link #priceList}
     *
     * @param priceList field to set
     */
    public void setPriceList(final PriceListDTO priceList) {
        this.priceList = priceList;
    }

    /**
     * Get of property {@link #priceListItem}
     *
     * @return com.ws.sales.external.product.dto.PriceListItemDTO
     */
    public PriceListItemDTO getPriceListItem() {
        return priceListItem;
    }

    /**
     * Set of property {@link #priceListItem}
     *
     * @param priceListItem field to set
     */
    public void setPriceListItem(final PriceListItemDTO priceListItem) {
        this.priceListItem = priceListItem;
    }

    /**
     * Get of property {@link #packaging}
     *
     * @return com.ws.sales.external.product.dto.PackagingDTO
     */
    public PackagingDTO getPackaging() {
        return packaging;
    }

    /**
     * Set of property {@link #packaging}
     *
     * @param packaging field to set
     */
    public void setPackaging(final PackagingDTO packaging) {
        this.packaging = packaging;
    }

    /**
     * Get of property {@link #product}
     *
     * @return com.ws.sales.external.product.dto.ProductDTO
     */
    public ProductDTO getProduct() {
        return product;
    }

    /**
     * Set of property {@link #product}
     *
     * @param product field to set
     */
    public void setProduct(final ProductDTO product) {
        this.product = product;
    }

    /**
     * Get of property {@link #originalPrice}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    /**
     * Set of property {@link #originalPrice}
     *
     * @param originalPrice field to set
     */
    public void setOriginalPrice(final BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    /**
     * Get of property {@link #salesPrice}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    /**
     * Set of property {@link #salesPrice}
     *
     * @param salesPrice field to set
     */
    public void setSalesPrice(final BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    /**
     * Get of property {@link #discountValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDiscountValue() {
        return discountValue;
    }

    /**
     * Set of property {@link #discountValue}
     *
     * @param discountValue field to set
     */
    public void setDiscountValue(final BigDecimal discountValue) {
        this.discountValue = discountValue;
    }

    /**
     * Get of property {@link #discountPercentage}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    /**
     * Set of property {@link #discountPercentage}
     *
     * @param discountPercentage field to set
     */
    public void setDiscountPercentage(final BigDecimal discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    /**
     * Get of property {@link #dueDateValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getDueDateValue() {
        return dueDateValue;
    }

    /**
     * Set of property {@link #dueDateValue}
     *
     * @param dueDateValue field to set
     */
    public void setDueDateValue(final BigDecimal dueDateValue) {
        this.dueDateValue = dueDateValue;
    }

    /**
     * Get of property {@link #quantity}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getQuantity() {
        return quantity;
    }

    /**
     * Set of property {@link #quantity}
     *
     * @param quantity field to set
     */
    public void setQuantity(final BigDecimal quantity) {
        this.quantity = quantity;
    }

}
