package com.ws.sales.customerorderssummary.productpurchased;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
@Getter
@Setter
@Entity
@Table(name = "product_purchased_history_view")
public class ProductPurchasedHistoryView implements DefaultPojoConverter, Identification<UUID> {

    private UUID id;

    private UUID customerId;

    private UUID salesOrderId;

    private UUID productId;

    private String productDescription;

    private OffsetDateTime updatedAt;

    private OffsetDateTime orderedAt;

    private BigDecimal netValue;

    private BigDecimal quantity;

}
