package com.ws.sales.order;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.financial.model.CreditLimit;
import com.ws.financial.model.CreditLimitSearch;
import com.ws.product.model.PriceListItem;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.financial.FinancialGateway;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.enums.OrderOrigin;
import com.ws.sales.order.enums.SalesValidationType;
import com.ws.sales.orderinstalment.SalesOrderInstalment;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.paymentterm.PaymentTermService;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.GenericValidator;
import com.ws.sales.validator.ValidationUtils;
import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Thyago Volpatto
 * @author Marcos Matheus de Andrade
 * @since v1.0.0 2016-08-30.
 */
public class SalesOrderValidator extends AbstractEntityValidator<SalesOrder> {

    private final SalesOrderDAO salesOrderDAO;
    private final PaymentTermService paymentTermService;
    private final ProductGateway productGateway;
    private final CustomerGateway customerGateway;
    private final FinancialGateway financialGateway;
    private final OrderParameterDAO orderParameterDAO;

    @Inject
    public SalesOrderValidator(final SalesOrderDAO salesOrderDAO,
                               final PaymentTermService paymentTermService,
                               final ProductGateway productGateway,
                               final CustomerGateway customerGateway,
                               final FinancialGateway financialGateway,
                               final OrderParameterDAO orderParameterDAO) {
        this.salesOrderDAO = salesOrderDAO;
        this.paymentTermService = paymentTermService;
        this.productGateway = productGateway;
        this.customerGateway = customerGateway;
        this.financialGateway = financialGateway;
        this.orderParameterDAO = orderParameterDAO;
    }

    @Override
    protected void validate(final SalesOrder entity, final IValidationFilter... filter) {
        validateByBeanValidation(entity, null);

        if (org.apache.commons.lang3.ArrayUtils.contains(filter, SalesValidationType.COMPLEMENT)) {
            validateComplement(entity);
        }

        if (org.apache.commons.lang3.ArrayUtils.contains(filter, SalesValidationType.FINALIZATION)) {
            validateFinalization(entity);
        }

        if (org.apache.commons.lang3.ArrayUtils.contains(filter, SalesValidationType.INTEGRATION)) {
            validateIntegration(entity);
        }

        if (org.apache.commons.lang3.ArrayUtils.contains(filter, SalesValidationType.DELETE)) {
            this.addError(this.doValidateIfOrderCanBeEdited(entity, Boolean.TRUE), entity);
        }
    }

    private void validateComplement(final SalesOrder salesOrder) {
        addError(this.validateOrderFinalized(salesOrder), salesOrder);
    }

    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        if (logicError == null) {
            return;
        }
        super.addError(logicError, entity);
    }

    /**
     * @param salesOrder
     */
    private void validateFinalization(final SalesOrder salesOrder) {

        final CreditLimitSearch creditLimitSearch = new CreditLimitSearch();
        creditLimitSearch.setCompanyId(salesOrder.getCompanyId().toString());
        creditLimitSearch.setCustomerId(salesOrder.getCustomerId().toString());
        creditLimitSearch.setLocationId(salesOrder.getLocationId().toString());

        final List<CreditLimit> creditLimits = financialGateway.searchCreditLimit(creditLimitSearch);

        addError(this.validateSalesOrderHaveItems(salesOrder), salesOrder);
        addError(this.validateSalesOrderHaveServices(salesOrder), salesOrder);
        addError(this.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE), salesOrder);
        addError(this.validateValueMoreThanZero(salesOrder), salesOrder);

        final Boolean isCreditLimitEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_CREDIT_REQUIRED).getValue());
        final Boolean isNegativeCreditBlocked = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_BLOCK_ORDER_NEGATIVE_CREDIT).getValue());

        addError(this.validateMoreThanOneCreditLimit(creditLimits, isCreditLimitEnabled), salesOrder);
        addError(this.validateExistsCreditLimit(creditLimits, isCreditLimitEnabled), salesOrder);
        addError(this.validateCreditLimitIsNegative(salesOrder, creditLimits, isNegativeCreditBlocked), salesOrder);
        addError(this.validateCreditLimitBecameNegative(salesOrder, creditLimits, isNegativeCreditBlocked), salesOrder);
        addError(this.validateIfValueOfInstalmentsIsEqualToOrderValue(salesOrder), salesOrder);
        addError(this.validateIfLocationFromDeliveryBelongsToCustomer(salesOrder), salesOrder);
        addError(this.validatePaymentTermIsActive(salesOrder), salesOrder);
        addError(this.validateCustomerInactive(salesOrder), salesOrder);
        addError(this.validateLocationInactive(salesOrder), salesOrder);

        final Boolean isDueDateEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_PRICE).getValue());
        final Boolean isDueDateRequired = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_DUE_DATE_FIELD_REQUIRED).getValue());

        if (isDueDateRequired) {
            addError(this.doValidateIfDueDateIsFilled(salesOrder), salesOrder);
        }

        if (isDueDateEnabled) {
            addError(this.doValidateIfDueDateIsBeforeToday(salesOrder), salesOrder);
        }
    }

    /**
     * @param salesOrder
     */
    private void validateIntegration(final SalesOrder salesOrder) {
        addError(this.validateUserProfessionalNotNull(salesOrder), salesOrder);
    }

    /**
     * @param salesOrder to check fields and validate
     * @param isDelete for selecting the message
     * @return {@link LogicError} if there are any validations that block the order for being edited
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    public LogicError doValidateIfOrderCanBeEdited(final SalesOrder salesOrder, final Boolean isDelete) {
        final String originError = isDelete ? Constants.MESSAGE_ORDER_CANNOT_REMOVE_BECAUSE_IS_EXTERNAL : Constants.MESSAGE_ORDER_CANNOT_EDIT_BECAUSE_IS_EXTERNAL;
        final String draftError = isDelete ? Constants.MESSAGE_ORDER_CONFIRMED_CANNOT_REMOVE : Constants.MESSAGE_ORDER_FINALIZED;
        final List<LogicError> errorsFromOrder = new LinkedList<>();
        GenericValidator.applyValidator(this::doValidateIfOrderIsDraft, salesOrder, draftError, errorsFromOrder);
        GenericValidator.applyValidator(this::doValidateIfOriginIsWeb, salesOrder, originError, errorsFromOrder);
        return errorsFromOrder.stream().findFirst().orElse(null);
    }

    /**
     * @param salesOrder to check draft and validate
     * @return {@link LogicError} if the draft is false
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private LogicError doValidateIfOrderIsDraft(final SalesOrder salesOrder, final String errorMessage) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getDraft)
                .filter(Boolean.FALSE::equals)
                .map(isNotDraft -> new LogicError(Constants.FIELD_DRAFT, errorMessage))
                .orElse(null);
    }

    /**
     * @param salesOrder to check draft and validate
     * @return {@link LogicError} if the draft is false
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private LogicError doValidateIfOriginIsWeb(final SalesOrder salesOrder, final String errorMessage) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getOrigin)
                .filter(origin -> !OrderOrigin.WEB.toString().equals(origin))
                .map(isNotFromWeb -> new LogicError(Constants.FIELD_SALES_ORDER, errorMessage))
                .orElse(null);
    }

    /**
     * @param salesOrder to check netValue and validate
     * @return {@link LogicError} if the netValue is null or zero
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-28
     */
    public LogicError doValidateOrderValue(final SalesOrder salesOrder) {
        return Optional.ofNullable(salesOrder)
                .filter(order -> ValidationUtils.isValueNullOrZero(salesOrder.getNetValue()))
                .map(order -> new LogicError(Constants.FIELD_SALES_ORDER, Constants.MESSAGE_ORDER_DOES_NOT_HAVE_VALUE))
                .orElse(null);
    }

    /**
     * <p>
     * If {@link SalesOrder#getDueDate()} is not null, it will validate if the date is after today.
     *
     * @param salesOrder to check the dueDate and validate
     * @return {@link LogicError} if the dueDate is before today
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    public LogicError doValidateIfDueDateIsFilled(final SalesOrder salesOrder) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getDueDate)
                .filter(dueDate -> Objects.isNull(dueDate))
                .map(order -> new LogicError(Constants.FIELD_DUE_DATE, Constants.MESSAGE_DUE_DATE_MUST_BE_FILLED))
                .orElse(null);
    }

    /**
     * <p>
     * If {@link SalesOrder#getDueDate()} is not null, it will validate if the date is after today.
     *
     * @param salesOrder to check the dueDate and validate
     * @return {@link LogicError} if the dueDate is before today
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    public LogicError doValidateIfDueDateIsBeforeToday(final SalesOrder salesOrder) {
        return Optional.ofNullable(salesOrder)
                .map(SalesOrder::getDueDate)
                .filter(dueDate -> LocalDate.now().isAfter(dueDate))
                .map(order -> new LogicError(Constants.FIELD_DUE_DATE, Constants.MESSAGE_DATE_BEFORE_TODAY))
                .orElse(null);
    }

    /**
     * @param salesOrder
     * @author Maykon Rissi
     * Load the order from DB to see the draft's status;
     */
    public LogicError validateOrderFinalized(final SalesOrder salesOrder) {
        if (salesOrder != null && salesOrder.getId() != null) {
            final SalesOrder dbOrder = salesOrderDAO.findById(salesOrder.getId());
            return dbOrder == null || dbOrder.getDraft() ? null : new LogicError("draft", "order.finalized");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return LogicError
     * @author Marcos Matheus de Andrade
     */
    public LogicError validateSalesOrderHaveItems(final SalesOrder salesOrder) {
        if (salesOrder != null
                && (salesOrder.getItems() == null || salesOrder.getItems().isEmpty())
                && (salesOrder.getServices() == null || salesOrder.getServices().isEmpty())) {
            return new LogicError("items", "order.without.items");
        }
        return null;
    }

    /**
     * valid if sales order have services
     *
     * @param salesOrder
     * @return LogicError
     * @author Peterson Schmitt
     */
    public LogicError validateSalesOrderHaveServices(final SalesOrder salesOrder) {
        if (salesOrder != null
                && (salesOrder.getItems() == null || salesOrder.getItems().isEmpty())
                && (salesOrder.getServices() == null || salesOrder.getServices().isEmpty())) {
            return new LogicError("services", "order.without.items");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     */
    public LogicError validateValueMoreThanZero(final SalesOrder salesOrder) {
        if (salesOrder != null && (salesOrder.getNetValue() == null || salesOrder.getNetValue().compareTo(BigDecimal.ZERO) < 1)) {
            return new LogicError("netValue", "order.without.value");
        }
        return null;
    }

    /**
     * @param creditLimits
     * @return
     */
    public LogicError validateMoreThanOneCreditLimit(final List<CreditLimit> creditLimits, final Boolean isCreditLimitEnabled) {
        if (Objects.nonNull(creditLimits) && creditLimits.size() > 1 && isCreditLimitEnabled) {
            return new LogicError(Constants.FIELD_SALES, "order.creditLimit.moreThanOneCreditLimit");
        }
        return null;
    }

    /**
     * @param creditLimits
     * @return
     */
    public LogicError validateExistsCreditLimit(final List<CreditLimit> creditLimits, final Boolean isCreditLimitEnabled) {
        if (Objects.isNull(creditLimits) || creditLimits.isEmpty() && isCreditLimitEnabled) {
            return new LogicError(Constants.FIELD_SALES, "order.creditLimit.notExists");
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     */
    public LogicError validateCreditLimitIsNegative(final SalesOrder salesOrder,
            final List<CreditLimit> creditLimits,
            final Boolean blockNegativeCreditLimit) {
        if (salesOrder != null && blockNegativeCreditLimit) {
            if (creditLimits != null && !creditLimits.isEmpty()) {
                final CreditLimit creditLimit = creditLimits.get(0);
                if (creditLimit.getRemainingValue().compareTo(BigDecimal.ZERO) <= 0) {
                    return new LogicError(Constants.FIELD_SALES, "order.creditLimit.isNegative");
                }
            }
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     */
    public LogicError validateCreditLimitBecameNegative(final SalesOrder salesOrder,
            final List<CreditLimit> creditLimits,
            final Boolean blockNegativeCreditLimit) {
        if (salesOrder != null && blockNegativeCreditLimit) {
            if (creditLimits != null && !creditLimits.isEmpty()) {
                final CreditLimit creditLimit = creditLimits.get(0);
                if (creditLimit.getRemainingValue().compareTo(BigDecimal.ZERO) > 0
                        && (creditLimit.getRemainingValue().compareTo(salesOrder.getNetValue()) < 0)) {
                    return new LogicError(Constants.FIELD_SALES, "order.creditLimit.becomeNegative");
                }
            }
        }
        return null;
    }

    /**
     * If, in the moment of finalization, the net value from order is different than the sum of
     * all instalments, it will generate an error.
     *
     * @param salesOrder
     * @return
     */
    public LogicError validateIfValueOfInstalmentsIsEqualToOrderValue(final SalesOrder salesOrder) {
        final Boolean isOrderInstalmentEnabled = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_ENABLE_ORDER_INSTALMENT).getValue());
        if (salesOrder != null
                && salesOrder.getNetValue() != null
                && isOrderInstalmentEnabled
                && !salesOrder.getInstalments().isEmpty()) {
            final BigDecimal valueOfAllInstalments = salesOrder.getInstalments().stream()
                    .map(SalesOrderInstalment::getValue)
                    .reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO);
            if (valueOfAllInstalments.compareTo(salesOrder.getNetValue()) != 0) {
                return new LogicError(Constants.FIELD_SALES, "orderInstalment.instalmentsValueDifferentThanOrder");
            }
        }
        return null;
    }

    /**
     * Is valid if the the location from delivery belongs to the customer
     *
     * @param salesOrder Order
     * @return LogicError or null
     * @author Maykon Rissi
     */
    public LogicError validateIfLocationFromDeliveryBelongsToCustomer(final SalesOrder salesOrder) {
        if (salesOrder != null
                && salesOrder.getDraft()
                && salesOrder.getDeliveryOrders() != null
                && !salesOrder.getDeliveryOrders().isEmpty()) {
            if (salesOrder.getDeliveryOrders().get(0).getLocationId() != null) {
                final Boolean belongs = customerGateway.locationBelongsToCustomer(salesOrder.getDeliveryOrders().get(0).getLocationId(), salesOrder.getCustomerId());
                if (!belongs) {
                    return new LogicError(Constants.FIELD_SALES, "delivery.location.dontBelong");
                }
            }
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     */
    public LogicError validateDraft(final SalesOrder salesOrder) {
        if (salesOrder != null && !salesOrder.getDraft()) {
            return new LogicError("draft", "order.already.finalized");
        }
        return null;
    }

    /**
     * @param salesOrder as {@link SalesOrder}
     * @return null or {@link LogicError}
     * @author Rodrigo Santini
     */
    public LogicError validateSignatureExists(final SalesOrder salesOrder) {
        final Boolean signatureRequired = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_SIGNATURE_REQUIRED).getValue());
        if (salesOrder != null && signatureRequired && salesOrder.getSignatureId() == null) {
            return new LogicError(Constants.FIELD_SALES, "order.signatureMissing");
        }
        return null;
    }

    /**
     * Validates if the order products exist in the price list informed
     *
     * @param salesOrder
     * @return
     */
    public LogicError validateProductsInPriceList(final SalesOrder salesOrder) {
        if (salesOrder.getPriceListId() != null && salesOrder.getItems() != null) {
            final List<PriceListItem> itemsPriceList = productGateway.findItemsPriceListById(salesOrder);

            for (final SalesOrderItem item : salesOrder.getItems()) {
                final boolean itemExistInPriceList =
                        itemsPriceList.stream().anyMatch(itemPl -> itemPl.getProduct().getId().equals(item.getProductId().toString()));

                if (!itemExistInPriceList) {
                    return new LogicError(null, "order.item.product.mustBelongsToPriceListItem");
                }
            }
        }
        return null;
    }

    /**
     * Validates if the order products is active in the price list informed
     *
     * @param salesOrder
     * @return
     */
    public LogicError validateProductsActiveInPriceList(final SalesOrder salesOrder) {
        if (salesOrder.getPriceListId() != null && salesOrder.getItems() != null) {
            final List<PriceListItem> itemsPriceList = productGateway.findItemsPriceListById(salesOrder);

            for (final SalesOrderItem item : salesOrder.getItems()) {

                final List<PriceListItem> priceListItems =
                        itemsPriceList.stream().filter(itemPl -> itemPl.getProduct().getId().equals(item.getProductId().toString())).collect(Collectors.toList());

                if (!priceListItems.isEmpty()) {
                    final PriceListItem priceListItem = priceListItems.get(0);

                    if (priceListItem.getProduct() != null && !priceListItem.getProduct().isActive()) {
                        return new LogicError(null, "order.itemInactiveInPriceList");
                    }
                }
            }
        }
        return null;
    }

    public LogicError validateUpdateProfessionalAndInformedItems(final SalesOrder salesOrder) {
        if (salesOrder.getId() != null) {
            final SalesOrder salesOrderDb = salesOrderDAO.findById(salesOrder.getId());

            final List<SalesOrderItem> items = salesOrderDb.getItems();

            if (items != null && !items.isEmpty() && !Objects.equals(salesOrderDb.getUserProfessionalId(), salesOrder.getUserProfessionalId())) {
                return new LogicError(Constants.FIELD_PROFESSIONAL, "order.validation.updateProfessionalWithItems");
            }
        }
        return null;
    }

    /**
     * @param salesOrder
     * @return
     * Validate if payment term is active
     */
    public LogicError validatePaymentTermIsActive(final SalesOrder salesOrder) {
        if (salesOrder.getPaymentTermId() != null && !paymentTermService.paymentTermIsActive(salesOrder.getPaymentTermId())) {
            return new LogicError("paymentTermId", "order.paymentTerm.inactive");
        }
        return null;
    }

    public LogicError validateCustomerInactive(final SalesOrder salesOrder) {
        final Boolean isBlockOrderInactiveCustomer = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_BLOCK_ORDER_INACTIVE_CUSTOMER).getValue());
        if (isBlockOrderInactiveCustomer && (salesOrder.getCustomerId() != null && !customerGateway.customerIsActive(salesOrder.getCustomerId()))) {
            return new LogicError("customerId", "order.customer.inactive");
        }
        return null;
    }

    public LogicError validateLocationInactive(final SalesOrder salesOrder) {
        final Boolean isBlockOrderInactiveLocation = Boolean.valueOf(this.orderParameterDAO.searchByKey(Constants.FIELD_PARAMETER_BLOCK_ORDER_INACTIVE_LOCATION).getValue());
        if (isBlockOrderInactiveLocation && (salesOrder.getLocationId() != null && (!customerGateway.locationIsActive(salesOrder.getLocationId())))) {
            return new LogicError("locationId", "order.location.inactive");
        }
        return null;
    }

    public LogicError validateUserProfessionalNotNull(final SalesOrder salesOrder) {
        if (salesOrder.getUserProfessionalId() == null || salesOrder.getUserProfessionalName() == null) {
            return new LogicError(Constants.FIELD_PROFESSIONAL, "javax.validation.constraints.NotNull.message");
        }
        return null;
    }
}
