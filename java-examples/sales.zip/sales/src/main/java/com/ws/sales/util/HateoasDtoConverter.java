package com.ws.sales.util;


import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import com.ws.sales.util.hateoas.HateoasColumnListMapper;
import com.ws.sales.util.hateoas.HateoasColumnMapper;
import com.ws.sales.util.hateoas.HateoasDTO;
import com.ws.sales.util.hateoas.HateoasRelDTO;
import org.apache.deltaspike.core.api.config.ConfigProperty;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Converter to HATEOAS (Hypermedia as the Engine of Application State) is a constraint of the REST application architecture
 * that keeps the RESTful style architecture unique from most other network application architectures.
 *
 *
 * @author Ademar Junior<ademar.junior@wssim.com.br/>
 * @see <a href="https://restfulapi.net/hateoas/">Hateoas</a>
 * @since 7.1.0 2018-12-26.
 */
public final class HateoasDtoConverter {

    private final String version;
    private final String serviceName;
    private final PojoConverter converter;

    @Context
    private HttpServletRequest httpRequest;

    @Inject
    public HateoasDtoConverter(final PojoConverter converter,
                               @ConfigProperty(name = "service.version") final String version,
                               @ConfigProperty(name = "service.name") final String serviceName) {
        this.converter = converter;
        this.version = version;
        this.serviceName = serviceName;
    }

    /**
     * create a PagedList DTO based on the POJO structure
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @since 7.1.0 2018-12-28.
     * @param targetClass
     * @param entityList
     * @param <L>
     * @param <R>
     * @return
     */
    public  <L extends IPojoConverter, R extends IPojoConverter> PagedList<R> createDTO(final Class<R> targetClass, final PagedList<L> entityList) {
        final List<R> list = entityList
                .getItems()
                .stream()
                .map(entity -> createDTO(targetClass, entity, ((PhysicalDeleteBaseEntity) entity).getId()))
                .collect(Collectors.toList());
        final PagedList<R> pagedList = new PagedList<R>();
        pagedList.setCount(entityList.getCount());
        pagedList.setFirstRow(entityList.getFirstRow());
        pagedList.setPage(entityList.getPage());
        pagedList.setPageSize(entityList.getPageSize());
        pagedList.setItems(list);
        return pagedList;
    }

    /**
     * create a DTO based on the POJO structure
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @since 7.1.0 2018-12-26.
     * @param targetClass
     * @param sourceObject
     * @param <L>
     * @param <R>
     * @return
     */
    public <L extends IPojoConverter, R extends IPojoConverter> R createDTO(final Class<R> targetClass, final L sourceObject) {
        return createDTO(targetClass, sourceObject, null);
    }

    /**
     * create a DTO based on the POJO structure
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @since 7.1.0 2018-12-26.
     * @param targetClass
     * @param sourceObject
     * @param id
     * @param <L>
     * @param <R>
     * @return
     */
    public <L extends IPojoConverter, R extends IPojoConverter> R createDTO(final Class<R> targetClass, final L sourceObject, final UUID id) {
        final String[] fields = getOnlyFieldPOJO(targetClass, sourceObject);
        final R convert = converter.convert(targetClass, sourceObject, fields);
        return injectHateoas(targetClass, convert, id);
    }

    /**
     * takes only fields that are of POJO type
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @param targetClass
     * @param sourceObject
     * @return
     */
    private String[] getOnlyFieldPOJO(final Class targetClass, final Object sourceObject) {
        final List<String> fieldsHateoas = FieldReflectionHelper
                .fromClass(targetClass)
                .getFields()
                .stream()
                .filter(field ->
                        Objects.nonNull(field.getAnnotation(HateoasColumnMapper.class))
                                || Objects.nonNull(field.getAnnotation(HateoasColumnListMapper.class))
                )
                .map(field -> field.getName())
                .collect(Collectors.toList());
        final FieldReflectionHelper fieldReflectionHelper = FieldReflectionHelper.fromInstance(sourceObject);
        return fieldReflectionHelper
                .getFields()
                .stream()
                .filter(field -> 
                        !fieldsHateoas.contains(field.getName())
                                && Objects.nonNull(fieldReflectionHelper.getFieldValue(field.getName()))
                )
                .map(field -> field.getName())
                .toArray(String[]::new);
    }

    /**
     * Method returns true if httpRequest has not passed the query select,
     * or if the field exists within the select that the user reported
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @since 7.1.0 2019-01-09.
     * @param field
     * @param queryParams
     * @return
     */
    public boolean isFieldsInHttpRequest(final String field, final Map<String, String[]> queryParams) {
        final String[] selects = queryParams.get("select");
        if (Objects.nonNull(selects) && Objects.nonNull(selects[0])){
               final String[] select = selects[0].split(",");
               return Arrays.asList(select).contains(field);
        }
        return true;
    }

    /**
     * Injects the Hateoas data into the DTO
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @param targetClass
     * @param convert
     * @param <L>
     * @param <R>
     * @return
     */
    private <L extends IPojoConverter, R extends IPojoConverter> R injectHateoas(final Class<R> targetClass, final R convert, final UUID id) {
        final Map<String, String[]> queryParams = httpRequest.getParameterMap();
        FieldReflectionHelper
                .fromClass(targetClass)
                .getFields()
                .stream()
                .filter(field ->
                        (Objects.nonNull(field.getAnnotation(HateoasColumnMapper.class))
                                || Objects.nonNull(field.getAnnotation(HateoasColumnListMapper.class))
                        )
                        && isFieldsInHttpRequest(field.getName(), queryParams)
                )
                .forEach(field -> insertValueIntoField(field, convert, id));

        return convert;
    }

    /**
     * inserts the Hateoas values within each DTO field
     * @author Ademar Junior<ademar.junior@wssim.com.br/>
     * @param field
     * @param convert
     * @param <L>
     * @param <R>
     * @return
     */
    private <L extends IPojoConverter, R extends IPojoConverter> R insertValueIntoField(final Field field, final R convert, final UUID id) {
        if (field.getType().isAssignableFrom(HateoasDTO.class)) {

            final HateoasDTO hateoasDTO = new HateoasDTO();
            List<HateoasRelDTO> hateoasRelDTOList = new ArrayList<>();
            if (Objects.nonNull(field.getAnnotation(HateoasColumnMapper.class))){
                final HateoasColumnMapper hateoasColumn =  field.getAnnotation(HateoasColumnMapper.class);
                hateoasRelDTOList.add(convertTOHateoasRelDTO(hateoasColumn, id));
            } else if (Objects.nonNull(field.getAnnotation(HateoasColumnListMapper.class))) {
                hateoasRelDTOList = Arrays.asList(field.getAnnotation(HateoasColumnListMapper.class)
                        .value())
                        .stream()
                        .map(hateoas -> convertTOHateoasRelDTO(hateoas, id))
                        .collect(Collectors.toList());
            }
            hateoasDTO.setLinks(hateoasRelDTOList);
            FieldReflectionHelper
                    .fromInstance(convert)
                    .setFieldValue(field, hateoasDTO);
        }
        return convert;
    }


    private HateoasRelDTO convertTOHateoasRelDTO(final HateoasColumnMapper hateoasColumn, final UUID id) {
        final HateoasRelDTO hateoasRelDTO = new HateoasRelDTO();
        hateoasRelDTO.setUri(hrefFormat(hateoasColumn.uri(), id));
        hateoasRelDTO.setRel(hateoasColumn.rel());
        return hateoasRelDTO;
    }

    /**
     * Formater id into href
     * @param href
     * @param id
     * @return
     */
    private String hrefFormat(final String href, final UUID id) {
        if (Objects.nonNull(href)) {
            final StringBuilder sbHref = new StringBuilder();
            sbHref.append("/api/");
            sbHref.append(version);
            sbHref.append("/");
            sbHref.append(serviceName);
            if (Objects.nonNull(id)) {
                sbHref.append(href.replace("{id}", id.toString()));
            } else {
                sbHref.append(href);
            }
            return sbHref.toString();
        }
        return "";
    }


}
