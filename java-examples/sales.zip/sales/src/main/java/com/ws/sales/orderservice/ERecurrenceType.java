package com.ws.sales.orderservice;

/**
 * This enum represents the Value Type for RecurrenceType
 *
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-22
 */
public enum ERecurrenceType {
    DAY, WEEK, MONTH, YEAR;
}
