package com.ws.sales.customerorderssummary.orderssummary;

import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.sales.customerorderssummary.orderssummary.dto.AllOrdersDTO;
import com.ws.sales.customerorderssummary.orderssummary.dto.LastOrderDTO;
import io.ebean.annotation.Sql;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;

/**
 *This SQL Entity was create to be used to return information about the customer's sales order
 *
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
@Getter
@Setter
@Entity
@Sql
public class CustomerOrdersSummary implements DefaultPojoConverter {

    private AllOrdersDTO allOrders;

    private LastOrderDTO lastOrder;

}
