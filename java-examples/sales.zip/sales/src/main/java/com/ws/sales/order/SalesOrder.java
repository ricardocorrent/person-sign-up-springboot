package com.ws.sales.order;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;
import com.ws.sales.deliveryorder.DeliveryOrder;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.orderinstalment.SalesOrderInstalment;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderservice.SalesOrderService;
import com.ws.sales.ordersituation.SalesOrderSituation;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;


/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-26.
 */
@Entity
public class SalesOrder extends SoftDeleteBaseEntity implements Serializable, DefaultPojoConverter {

    private final static String MAPPED_BY = "salesOrder";

    @NotNull
    @PojoColumnMapper(target = "priceList.id")
    private UUID priceListId;

    @Size(max = 255)
    @PojoColumnMapper(target = "priceList.description")
    private String priceListDescription;

    @NotNull
    @PojoColumnMapper(target = "paymentTerm.id")
    private UUID paymentTermId;

    @Size(max = 255)
    @PojoColumnMapper(target = "paymentTerm.description")
    private String paymentTermDescription;

    @NotNull
    @PojoColumnMapper(target = "orderType.id")
    private UUID orderTypeId;

    @Size(max = 255)
    @PojoColumnMapper(target = "orderType.description")
    private String orderTypeDescription;

    @PojoColumnMapper(target = "paymentMethod.id")
    private UUID paymentMethodId;

    @Size(max = 255)
    @PojoColumnMapper(target = "paymentMethod.description")
    private String paymentMethodDescription;

    @NotNull
    @PojoColumnMapper(target = "user.id")
    private UUID userId;

    @Size(max = 255)
    @PojoColumnMapper(target = "user.name")
    private String userName;

    @NotNull
    @PojoColumnMapper(target = "company.id")
    private UUID companyId;

    @Size(max = 255)
    @PojoColumnMapper(target = "company.name")
    private String companyName;

    @NotNull
    @PojoColumnMapper(target = "customer.id")
    private UUID customerId;

    @PojoColumnMapper(target = "customer.image.id")
    private UUID customerImageId;

    @Size(max = 255)
    @PojoColumnMapper(target = "customer.name")
    private String customerName;

    @NotNull
    @PojoColumnMapper(target = "location.id")
    private UUID locationId;

    @Size(max = 255)
    @PojoColumnMapper(target = "location.description")
    private String locationDescription;

    @Size(max = 255)
    private String locationAddress;

    private Boolean draft;

    @Size(max = 255)
    private String orderNumber;

    @Size(max = 255)
    private String externalNumber;

    @Size(max = 255)
    private String customerNumber;

    @Size(max = 4000)
    private String invoiceNotes;

    @Size(max = 4000)
    @PojoColumnMapper(target = "notes")
    private String orderNotes;

    @Size(max = 10)
    private String currency;

    @OneToOne(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private OrderCurrency orderCurrency;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime orderedAt;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime invoicedAt;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime transmitedAt;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime exportedAt;

    @Column(precision = 18, scale = 6)
    private BigDecimal grossValue;

    @Column(precision = 18, scale = 6)
    private BigDecimal netValue;

    @Column(precision = 18, scale = 6)
    private BigDecimal productTotalValue;

    @Column(precision = 18, scale = 6)
    private BigDecimal serviceTotalValue;

    @Column(precision = 18, scale = 6)
    private BigDecimal quantity;

    @Column(precision = 18, scale = 6)
    private BigDecimal invoicedValue;

    @Column(precision = 18, scale = 6)
    private BigDecimal invoicedQuantity;

    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private List<SalesOrderItem> items;

    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private List<SalesOrderService> services;

    private Integer itemsQuantity;

    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private List<SalesOrderSituation> salesOrderSituations;

    @PojoColumnMapper(target = "situation.id")
    private UUID situationId;

    @Size(max = 255)
    @PojoColumnMapper(target = "situation.description")
    private String situationDescription;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate dueDate;


    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private List<DeliveryOrder> deliveryOrders;

    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<SalesOrderInstalment> instalments;

    @Size(max = 20)
    private String origin;

    @Size(max = 4000)
    private String complement;

    @NotNull
    @PojoColumnMapper(target = "userProfessional.id")
    private UUID userProfessionalId;

    @Size(max = 255)
    @PojoColumnMapper(target = "userProfessional.name")
    private String userProfessionalName;

    private UUID signatureId;

    @Column(precision = 18, scale = 6)
    private BigDecimal initialCreditLimit;

    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime transmittedAt;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate createDate;

    /**
     * informs the incotermsId for delivery (When the deliveryOrder is not used)
     */
    @PojoColumnMapper(target = "incoterms.id")
    private UUID incotermsId;

    /**
     * informs the incotermsAcronym for the delivery (When the deliveryOrder is not used)
     */
    @PojoColumnMapper(target = "incoterms.acronym")
    @Enumerated(value = EnumType.STRING)
    private IncotermsAcronym incotermsAcronym;

    /**
     * informs the id from the service that was active when this order was created
     */
    private UUID serviceId;

    /**
     * informs the id from the service that was active when this order was created
     */
    @PojoColumnMapper(target = "activity.id")
    private UUID activityId;

    /**
     * Indicates when the order was created.
     */
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    @JsonSerialize(using = TemporalSerializer.class)
    private OffsetDateTime insertedAt;

    /**
     * Get of property {@link #priceListId}
     *
     * @return java.util.UUID
     */
    public UUID getPriceListId() {
        return priceListId;
    }

    /**
     * Set of property {@link #priceListId}
     *
     * @param priceListId field to set
     */
    public void setPriceListId(final UUID priceListId) {
        this.priceListId = priceListId;
    }

    /**
     * Get of property {@link #priceListDescription}
     *
     * @return java.lang.String
     */
    public String getPriceListDescription() {
        return priceListDescription;
    }

    /**
     * Set of property {@link #priceListDescription}
     *
     * @param priceListDescription field to set
     */
    public void setPriceListDescription(final String priceListDescription) {
        this.priceListDescription = priceListDescription;
    }

    /**
     * Get of property {@link #paymentTermId}
     *
     * @return java.util.UUID
     */
    public UUID getPaymentTermId() {
        return paymentTermId;
    }

    /**
     * Set of property {@link #paymentTermId}
     *
     * @param paymentTermId field to set
     */
    public void setPaymentTermId(final UUID paymentTermId) {
        this.paymentTermId = paymentTermId;
    }

    /**
     * Get of property {@link #paymentTermDescription}
     *
     * @return java.lang.String
     */
    public String getPaymentTermDescription() {
        return paymentTermDescription;
    }

    /**
     * Set of property {@link #paymentTermDescription}
     *
     * @param paymentTermDescription field to set
     */
    public void setPaymentTermDescription(final String paymentTermDescription) {
        this.paymentTermDescription = paymentTermDescription;
    }

    /**
     * Get of property {@link #orderTypeId}
     *
     * @return java.util.UUID
     */
    public UUID getOrderTypeId() {
        return orderTypeId;
    }

    /**
     * Set of property {@link #orderTypeId}
     *
     * @param orderTypeId field to set
     */
    public void setOrderTypeId(final UUID orderTypeId) {
        this.orderTypeId = orderTypeId;
    }

    /**
     * Get of property {@link #orderTypeDescription}
     *
     * @return java.lang.String
     */
    public String getOrderTypeDescription() {
        return orderTypeDescription;
    }

    /**
     * Set of property {@link #orderTypeDescription}
     *
     * @param orderTypeDescription field to set
     */
    public void setOrderTypeDescription(final String orderTypeDescription) {
        this.orderTypeDescription = orderTypeDescription;
    }

    /**
     * Get of property {@link #paymentMethodId}
     *
     * @return java.util.UUID
     */
    public UUID getPaymentMethodId() {
        return paymentMethodId;
    }

    /**
     * Set of property {@link #paymentMethodId}
     *
     * @param paymentMethodId field to set
     */
    public void setPaymentMethodId(final UUID paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    /**
     * Get of property {@link #paymentMethodDescription}
     *
     * @return java.lang.String
     */
    public String getPaymentMethodDescription() {
        return paymentMethodDescription;
    }

    /**
     * Set of property {@link #paymentMethodDescription}
     *
     * @param paymentMethodDescription field to set
     */
    public void setPaymentMethodDescription(final String paymentMethodDescription) {
        this.paymentMethodDescription = paymentMethodDescription;
    }

    /**
     * Get of property {@link #userId}
     *
     * @return java.util.UUID
     */
    public UUID getUserId() {
        return userId;
    }

    /**
     * Set of property {@link #userId}
     *
     * @param userId field to set
     */
    public void setUserId(final UUID userId) {
        this.userId = userId;
    }

    /**
     * Get of property {@link #userName}
     *
     * @return java.lang.String
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Set of property {@link #userName}
     *
     * @param userName field to set
     */
    public void setUserName(final String userName) {
        this.userName = userName;
    }

    /**
     * Get of property {@link #companyId}
     *
     * @return java.util.UUID
     */
    public UUID getCompanyId() {
        return companyId;
    }

    /**
     * Set of property {@link #companyId}
     *
     * @param companyId field to set
     */
    public void setCompanyId(final UUID companyId) {
        this.companyId = companyId;
    }

    /**
     * Get of property {@link #companyName}
     *
     * @return java.lang.String
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Set of property {@link #companyName}
     *
     * @param companyName field to set
     */
    public void setCompanyName(final String companyName) {
        this.companyName = companyName;
    }

    /**
     * Get of property {@link #customerId}
     *
     * @return java.util.UUID
     */
    public UUID getCustomerId() {
        return customerId;
    }

    /**
     * Set of property {@link #customerId}
     *
     * @param customerId field to set
     */
    public void setCustomerId(final UUID customerId) {
        this.customerId = customerId;
    }

    /**
     * Get of property {@link #customerImageId}
     *
     * @return java.util.UUID
     */
    public UUID getCustomerImageId() {
        return customerImageId;
    }

    /**
     * Set of property {@link #customerImageId}
     *
     * @param customerImageId field to set
     */
    public void setCustomerImageId(final UUID customerImageId) {
        this.customerImageId = customerImageId;
    }

    /**
     * Get of property {@link #customerName}
     *
     * @return java.lang.String
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Set of property {@link #customerName}
     *
     * @param customerName field to set
     */
    public void setCustomerName(final String customerName) {
        this.customerName = customerName;
    }

    /**
     * Get of property {@link #locationId}
     *
     * @return java.util.UUID
     */
    public UUID getLocationId() {
        return locationId;
    }

    /**
     * Set of property {@link #locationId}
     *
     * @param locationId field to set
     */
    public void setLocationId(final UUID locationId) {
        this.locationId = locationId;
    }

    /**
     * Get of property {@link #locationDescription}
     *
     * @return java.lang.String
     */
    public String getLocationDescription() {
        return locationDescription;
    }

    /**
     * Set of property {@link #locationDescription}
     *
     * @param locationDescription field to set
     */
    public void setLocationDescription(final String locationDescription) {
        this.locationDescription = locationDescription;
    }

    /**
     * Get of property {@link #locationAddress}
     *
     * @return java.lang.String
     */
    public String getLocationAddress() {
        return locationAddress;
    }

    /**
     * Set of property {@link #locationAddress}
     *
     * @param locationAddress field to set
     */
    public void setLocationAddress(final String locationAddress) {
        this.locationAddress = locationAddress;
    }

    /**
     * Get of property {@link #draft}
     *
     * @return java.lang.Boolean
     */
    public Boolean getDraft() {
        return draft;
    }

    /**
     * Set of property {@link #draft}
     *
     * @param draft field to set
     */
    public void setDraft(final Boolean draft) {
        this.draft = draft;
    }

    /**
     * Get of property {@link #orderNumber}
     *
     * @return java.lang.String
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Set of property {@link #orderNumber}
     *
     * @param orderNumber field to set
     */
    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * Get of property {@link #externalNumber}
     *
     * @return java.lang.String
     */
    public String getExternalNumber() {
        return externalNumber;
    }

    /**
     * Set of property {@link #externalNumber}
     *
     * @param externalNumber field to set
     */
    public void setExternalNumber(final String externalNumber) {
        this.externalNumber = externalNumber;
    }

    /**
     * Get of property {@link #customerNumber}
     *
     * @return java.lang.String
     */
    public String getCustomerNumber() {
        return customerNumber;
    }

    /**
     * Set of property {@link #customerNumber}
     *
     * @param customerNumber field to set
     */
    public void setCustomerNumber(final String customerNumber) {
        this.customerNumber = customerNumber;
    }

    /**
     * Get of property {@link #invoiceNotes}
     *
     * @return java.lang.String
     */
    public String getInvoiceNotes() {
        return invoiceNotes;
    }

    /**
     * Set of property {@link #invoiceNotes}
     *
     * @param invoiceNotes field to set
     */
    public void setInvoiceNotes(final String invoiceNotes) {
        this.invoiceNotes = invoiceNotes;
    }

    /**
     * Get of property {@link #orderNotes}
     *
     * @return java.lang.String
     */
    public String getOrderNotes() {
        return orderNotes;
    }

    /**
     * Set of property {@link #orderNotes}
     *
     * @param orderNotes field to set
     */
    public void setOrderNotes(final String orderNotes) {
        this.orderNotes = orderNotes;
    }

    /**
     * Get of property {@link #currency}
     *
     * @return java.lang.String
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set of property {@link #currency}
     *
     * @param currency field to set
     */
    public void setCurrency(final String currency) {
        this.currency = currency;
    }

    /**
     * Get of property {@link #orderCurrency}
     *
     * @return com.ws.sales.ordercurrency.OrderCurrency
     */
    public OrderCurrency getOrderCurrency() {
        return orderCurrency;
    }

    /**
     * Set of property {@link #orderCurrency}
     *
     * @param orderCurrency field to set
     */
    public void setOrderCurrency(final OrderCurrency orderCurrency) {
        this.orderCurrency = orderCurrency;
    }

    /**
     * Get of property {@link #orderedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getOrderedAt() {
        return orderedAt;
    }

    /**
     * Set of property {@link #orderedAt}
     *
     * @param orderedAt field to set
     */
    public void setOrderedAt(final OffsetDateTime orderedAt) {
        this.orderedAt = orderedAt;
    }

    /**
     * Get of property {@link #invoicedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getInvoicedAt() {
        return invoicedAt;
    }

    /**
     * Set of property {@link #invoicedAt}
     *
     * @param invoicedAt field to set
     */
    public void setInvoicedAt(final OffsetDateTime invoicedAt) {
        this.invoicedAt = invoicedAt;
    }

    /**
     * Get of property {@link #transmitedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getTransmitedAt() {
        return transmitedAt;
    }

    /**
     * Set of property {@link #transmitedAt}
     *
     * @param transmitedAt field to set
     */
    public void setTransmitedAt(final OffsetDateTime transmitedAt) {
        this.transmitedAt = transmitedAt;
    }

    /**
     * Get of property {@link #exportedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getExportedAt() {
        return exportedAt;
    }

    /**
     * Set of property {@link #exportedAt}
     *
     * @param exportedAt field to set
     */
    public void setExportedAt(final OffsetDateTime exportedAt) {
        this.exportedAt = exportedAt;
    }

    /**
     * Get of property {@link #grossValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getGrossValue() {
        return grossValue;
    }

    /**
     * Set of property {@link #grossValue}
     *
     * @param grossValue field to set
     */
    public void setGrossValue(final BigDecimal grossValue) {
        this.grossValue = grossValue;
    }

    /**
     * Get of property {@link #netValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getNetValue() {
        return netValue;
    }

    /**
     * Set of property {@link #netValue}
     *
     * @param netValue field to set
     */
    public void setNetValue(final BigDecimal netValue) {
        this.netValue = netValue;
    }

    public BigDecimal getProductTotalValue() {
        return productTotalValue;
    }

    public void setProductTotalValue(final BigDecimal productTotalValue) {
        this.productTotalValue = productTotalValue;
    }

    public BigDecimal getServiceTotalValue() {
        return serviceTotalValue;
    }

    public void setServiceTotalValue(final BigDecimal serviceTotalValue) {
        this.serviceTotalValue = serviceTotalValue;
    }

    /**
     * Get of property {@link #quantity}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getQuantity() {
        return quantity;
    }

    /**
     * Set of property {@link #quantity}
     *
     * @param quantity field to set
     */
    public void setQuantity(final BigDecimal quantity) {
        this.quantity = quantity;
    }

    /**
     * Get of property {@link #invoicedValue}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getInvoicedValue() {
        return invoicedValue;
    }

    /**
     * Set of property {@link #invoicedValue}
     *
     * @param invoicedValue field to set
     */
    public void setInvoicedValue(final BigDecimal invoicedValue) {
        this.invoicedValue = invoicedValue;
    }

    /**
     * Get of property {@link #invoicedQuantity}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getInvoicedQuantity() {
        return invoicedQuantity;
    }

    /**
     * Set of property {@link #invoicedQuantity}
     *
     * @param invoicedQuantity field to set
     */
    public void setInvoicedQuantity(final BigDecimal invoicedQuantity) {
        this.invoicedQuantity = invoicedQuantity;
    }

    /**
     * Get of property {@link #items}
     *
     * @return java.util.List<com.ws.sales.orderitem.SalesOrderItem>
     */
    public List<SalesOrderItem> getItems() {
        return items;
    }

    /**
     * Set of property {@link #items}
     *
     * @param items field to set
     */
    public void setItems(final List<SalesOrderItem> items) {
        this.items = items;
    }

    /**
     * Get of property {@link #services}
     *
     * @return java.util.List<com.ws.sales.orderservice.SalesOrderService>
     */
    public List<SalesOrderService> getServices() {
        return services;
    }

    /**
     * Set of property {@link #services}
     *
     * @param services field to set
     */
    public void setServices(final List<SalesOrderService> services) {
        this.services = services;
    }

    /**
     * Get of property {@link #itemsQuantity}
     *
     * @return java.lang.Integer
     */
    public Integer getItemsQuantity() {
        return itemsQuantity;
    }

    /**
     * Set of property {@link #itemsQuantity}
     *
     * @param itemsQuantity field to set
     */
    public void setItemsQuantity(final Integer itemsQuantity) {
        this.itemsQuantity = itemsQuantity;
    }

    /**
     * Get of property {@link #salesOrderSituations}
     *
     * @return java.util.List<com.ws.sales.ordersituation.SalesOrderSituation>
     */
    public List<SalesOrderSituation> getSalesOrderSituations() {
        return salesOrderSituations;
    }

    /**
     * Set of property {@link #salesOrderSituations}
     *
     * @param salesOrderSituations field to set
     */
    public void setSalesOrderSituations(final List<SalesOrderSituation> salesOrderSituations) {
        this.salesOrderSituations = salesOrderSituations;
    }

    /**
     * Get of property {@link #situationId}
     *
     * @return java.util.UUID
     */
    public UUID getSituationId() {
        return situationId;
    }

    /**
     * Set of property {@link #situationId}
     *
     * @param situationId field to set
     */
    public void setSituationId(final UUID situationId) {
        this.situationId = situationId;
    }

    /**
     * Get of property {@link #dueDate}
     *
     * @return java.time.LocalDate
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /**
     * Set of property {@link #dueDate}
     *
     * @param dueDate field to set
     */
    public void setDueDate(final LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * Get of property {@link #situationDescription}
     *
     * @return java.lang.String
     */
    public String getSituationDescription() {
        return situationDescription;
    }

    /**
     * Set of property {@link #situationDescription}
     *
     * @param situationDescription field to set
     */
    public void setSituationDescription(final String situationDescription) {
        this.situationDescription = situationDescription;
    }

    /**
     * Get of property {@link #deliveryOrders}
     *
     * @return java.util.List<com.ws.sales.deliveryorder.DeliveryOrder>
     */
    public List<DeliveryOrder> getDeliveryOrders() {
        return deliveryOrders;
    }

    /**
     * Set of property {@link #deliveryOrders}
     *
     * @param deliveryOrders field to set
     */
    public void setDeliveryOrders(final List<DeliveryOrder> deliveryOrders) {
        this.deliveryOrders = deliveryOrders;
    }

    /**
     * Get of property {@link #instalments}
     *
     * @return java.util.List<com.ws.sales.orderinstalment.SalesOrderInstalment>
     */
    public List<SalesOrderInstalment> getInstalments() {
        return instalments;
    }

    /**
     * Set of property {@link #instalments}
     *
     * @param instalments field to set
     */
    public void setInstalments(final List<SalesOrderInstalment> instalments) {
        this.instalments = instalments;
    }

    /**
     * Get of property {@link #origin}
     *
     * @return java.lang.String
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * Set of property {@link #origin}
     *
     * @param origin field to set
     */
    public void setOrigin(final String origin) {
        this.origin = origin;
    }

    /**
     * Get of property {@link #complement}
     *
     * @return java.lang.String
     */
    public String getComplement() {
        return complement;
    }

    /**
     * Set of property {@link #complement}
     *
     * @param complement field to set
     */
    public void setComplement(final String complement) {
        this.complement = complement;
    }

    /**
     * Get of property {@link #userProfessionalId}
     *
     * @return java.util.UUID
     */
    public UUID getUserProfessionalId() {
        return userProfessionalId;
    }

    /**
     * Set of property {@link #userProfessionalId}
     *
     * @param userProfessionalId field to set
     */
    public void setUserProfessionalId(final UUID userProfessionalId) {
        this.userProfessionalId = userProfessionalId;
    }

    /**
     * Get of property {@link #userProfessionalName}
     *
     * @return java.lang.String
     */
    public String getUserProfessionalName() {
        return userProfessionalName;
    }

    /**
     * Set of property {@link #userProfessionalName}
     *
     * @param userProfessionalName field to set
     */
    public void setUserProfessionalName(final String userProfessionalName) {
        this.userProfessionalName = userProfessionalName;
    }

    /**
     * Get of property {@link #signatureId}
     *
     * @return java.util.UUID
     */
    public UUID getSignatureId() {
        return signatureId;
    }

    /**
     * Set of property {@link #signatureId}
     *
     * @param signatureId field to set
     */
    public void setSignatureId(final UUID signatureId) {
        this.signatureId = signatureId;
    }

    /**
     * Get of property {@link #initialCreditLimit}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getInitialCreditLimit() {
        return initialCreditLimit;
    }

    /**
     * Set of property {@link #initialCreditLimit}
     *
     * @param initialCreditLimit field to set
     */
    public void setInitialCreditLimit(final BigDecimal initialCreditLimit) {
        this.initialCreditLimit = initialCreditLimit;
    }

    /**
     * Get of property {@link #transmittedAt}
     *
     * @return java.time.OffsetDateTime
     */
    public OffsetDateTime getTransmittedAt() {
        return transmittedAt;
    }

    /**
     * Set of property {@link #transmittedAt}
     *
     * @param transmittedAt field to set
     */
    public void setTransmittedAt(final OffsetDateTime transmittedAt) {
        this.transmittedAt = transmittedAt;
    }

    /**
     * Get of property {@link #incotermsId}
     *
     * @return java.util.UUID
     */
    public UUID getIncotermsId() {
        return incotermsId;
    }

    /**
     * Set of property {@link #incotermsId}
     *
     * @param incotermsId field to set
     */
    public void setIncotermsId(final UUID incotermsId) {
        this.incotermsId = incotermsId;
    }

    /**
     * Get of property {@link #incotermsAcronym}
     *
     * @return com.ws.sales.external.commondata.IncotermsAcronym
     */
    public IncotermsAcronym getIncotermsAcronym() {
        return incotermsAcronym;
    }

    /**
     * Set of property {@link #incotermsAcronym}
     *
     * @param incotermsAcronym field to set
     */
    public void setIncotermsAcronym(final IncotermsAcronym incotermsAcronym) {
        this.incotermsAcronym = incotermsAcronym;
    }

    /**
     * Get of property {@link #serviceId}
     *
     * @return java.util.UUID
     */
    public UUID getServiceId() {
        return serviceId;
    }

    /**
     * Set of property {@link #serviceId}
     *
     * @param serviceId field to set
     */
    public void setServiceId(final UUID serviceId) {
        this.serviceId = serviceId;
    }

    /**
     * Get of property {@Link #insertedAt}
     *
     * @return OffsetDateTime
     */
    public OffsetDateTime getInsertedAt() {
        return insertedAt;
    }

    /**
     * Set of property {@Link #insertedAt}
     *
     * @param insertedAt field do set
     */
    public void setInsertedAt(final OffsetDateTime insertedAt) {
        this.insertedAt = insertedAt;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(final UUID activityId) {
        this.activityId = activityId;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(final LocalDate createDate) {
        this.createDate = createDate;
    }
}
