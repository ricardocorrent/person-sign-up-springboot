package com.ws.sales.documents.integration;

import com.ws.sales.documents.DocumentCreatorFormat;

import java.util.Map;

/**
 * @author dante.basso <dante.basso@wssim.com.br>
 * @since 2019-03-20
 * @version 1.0.0
 */
public class DocumentCreator {

    private String origin;

    private String templateId;

    private String name;

    private DocumentCreatorFormat format;

    private Map values;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DocumentCreatorFormat getFormat() {
        return format;
    }

    public void setFormat(DocumentCreatorFormat format) {
        this.format = format;
    }

    public Map getValues() {
        return values;
    }

    public void setValues(Map values) {
        this.values = values;
    }
}
