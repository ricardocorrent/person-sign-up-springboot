package com.ws.sales.ordertreatment.dto;

import com.ws.commons.pojoconverter.DefaultPojoConverter;

import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-08
 */
public class OrderTreatmentDTO implements DefaultPojoConverter {

    private UUID id;

    private String description;

    private String externalId;

    private Long version;

    /**
     * Get of property {@link #id}
     *
     * @return java.util.UUID
     */
    public UUID getId() {
        return id;
    }

    /**
     * Set of property {@link #id}
     *
     * @param id field to set
     */
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * Get of property {@link #description}
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set of property {@link #description}
     *
     * @param description field to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Get of property {@link #externalId}
     *
     * @return java.lang.String
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Set of property {@link #externalId}
     *
     * @param externalId field to set
     */
    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    /**
     * Get of property {@link #version}
     *
     * @return java.lang.Long
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Set of property {@link #version}
     *
     * @param version field to set
     */
    public void setVersion(final Long version) {
        this.version = version;
    }
}
