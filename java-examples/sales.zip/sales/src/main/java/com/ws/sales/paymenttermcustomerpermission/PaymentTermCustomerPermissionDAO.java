package com.ws.sales.paymenttermcustomerpermission;

import java.util.Collections;
import java.util.UUID;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.commons.server.pagination.Sort;

import io.ebean.ExpressionList;
import io.ebean.Query;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
public class PaymentTermCustomerPermissionDAO extends AbstractDAO<PaymentTermCustomerPermission> {

    @Override
    public Class<PaymentTermCustomerPermission> getEntityClass() {
        return PaymentTermCustomerPermission.class;
    }

    public PagedList<PaymentTermCustomerPermission> getByPaymentTerm(final UUID paymentTermId) {
        final Query<PaymentTermCustomerPermission> query = find();
        final ExpressionList<PaymentTermCustomerPermission> where = query.where();
        where.in("paymentTerm.id", paymentTermId);

        final Sort sort = new Sort();
        sort.setField("customerName");
        sort.setDir("asc");

        final PaginationSearch paginationSearch = new PaginationSearch();
        paginationSearch.setSort(Collections.singletonList(sort));

        return getPagedList(query, paginationSearch);
    }

}
