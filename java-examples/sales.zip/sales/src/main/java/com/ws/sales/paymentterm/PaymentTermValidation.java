package com.ws.sales.paymentterm;

import java.util.Optional;

import javax.enterprise.inject.Default;
import javax.inject.Inject;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.validator.ValidationUtils;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-29
 */
@Default
public class PaymentTermValidation extends AbstractEntityValidator<PaymentTerm> {

    private final PaymentTermDAO dao;

    @Inject
    public PaymentTermValidation(final PaymentTermDAO dao) {
        this.dao = dao;
    }

    /**
     * @author Maykon Rissi <maykon.rissi@wssim.com.br>
     * @implNote Add an error if in db has one standard item.
     * @since 5.20.0 2018-04-19
     */
    public void validHasStandard(final PaymentTerm paymentTerm) {
        Optional.ofNullable(paymentTerm)
                .filter(term -> Boolean.TRUE.equals(term.getStandard()))
                .map(term -> this.dao.getStandard())
                .filter(standard -> !standard.getId().equals(paymentTerm.getId()))
                .ifPresent(standard -> {
                        final LogicError error = ValidationUtils.doCreateLogicErrorWithParam("paymentTermDescription", standard.getDescription(), "standard", "sales.paymentTerm.standard.unique.validation");
                        addError(error, paymentTerm);
                });
    }


    @Override
    protected void validate(final PaymentTerm entity, final IValidationFilter... filter) {
        validateByBeanValidation(entity, null);
        validHasStandard(entity);
    }
}
