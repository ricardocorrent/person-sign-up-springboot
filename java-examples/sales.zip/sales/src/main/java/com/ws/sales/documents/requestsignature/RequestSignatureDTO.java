package com.ws.sales.documents.requestsignature;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.server.validation.constraints.Email;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * This class was created to represent the information about the document that will be signed
 *
 * @since 8.3.0 2019-05-10
 *
 * @author Ricardo Corrent
 */
public class RequestSignatureDTO extends BaseDTO implements DefaultPojoConverter {

    @JsonIgnore
    private UUID salesOrderId;

    @NotNull
    private UUID templateId;

    @Size(max = 100)
    private String message;

    @NotNull
    @Email
    @Size(max = 255)
    private String email;

    @NotNull
    private Boolean rejectable;

    @Size(max = 255)
    private String fileName;

    public UUID getSalesOrderId() {
        return salesOrderId;
    }

    public void setSalesOrderId(final UUID salesOrderId) {
        this.salesOrderId = salesOrderId;
    }

    public UUID getTemplateId() {
        return templateId;
    }

    public void setTemplateId(UUID templateId) {
        this.templateId = templateId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getRejectable() {
        return rejectable;
    }

    public void setRejectable(Boolean rejectable) {
        this.rejectable = rejectable;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
