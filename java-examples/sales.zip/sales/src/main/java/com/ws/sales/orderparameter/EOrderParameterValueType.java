package com.ws.sales.orderparameter;

/**
 * This enum represents the Value Type for Order Parameter
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-29
 */
public enum EOrderParameterValueType {
    /**
     * boolean
     */
    BOOL,
    /**
     * text
     */
    TXT,
    /**
     * integer value
     */
    INT,
    /**
     * date
     */
    DATE,
    /**
     * decimal value
     */
    DEC,
    /**
     * dateTime
     */
    DTT,
    /**
     * period
     */
    PER

}
