package com.ws.sales.external.cloudmanager;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Alan J. A. Pena
 * @since 2018-10-23
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerCloudManager {

    private String subDomain;
    private String tenant;

    @SuppressWarnings("javadoc")
    public CustomerCloudManager() {}

    /**
     * Creates the POJO including the sub domain and tenant as fields.
     * @param subDomain the Customer's sub domain.
     * @param tenant the Customer's tenant.
     */
    public CustomerCloudManager(final String subDomain, final String tenant) {
        this.subDomain = subDomain;
        this.tenant = tenant;
    }

    /**
     * @return the {@link CustomerCloudManager}'s subDomain
     */
    public String getSubDomain() {
        return this.subDomain;
    }

    /**
     * @param subDomain the {@link CustomerCloudManager}'s subDomain to set
     */
    public void setSubDomain(final String subDomain) {
        this.subDomain = subDomain;
    }

    /**
     * @return the {@link CustomerCloudManager}'s tenant
     */
    public String getTenant() {
        return this.tenant;
    }

    /**
     * @param tenant the {@link CustomerCloudManager}'s tenant to set
     */
    public void setTenant(final String tenant) {
        this.tenant = tenant;
    }
}
