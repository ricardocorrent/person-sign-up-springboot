package com.ws.sales.paymentmethod;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
@Entity
public class PaymentMethod extends SoftDeleteBaseEntity {


    @NotNull
    private Boolean active;

    @NotNull
    private Boolean standard;

//    @NotNull
    @Deprecated
    private Boolean availableFirstOrder;

    @NotNull
    @Size(max = 255)
    private String description;

    @Size(max = 40)
    private String acronym;

    @Size(max = 40)
    private String code;

    /**
     * Check if is active
     *
     * @return java.lang.Boolean
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Define if it's  active
     *
     * @param active
     */
    public void setActive(final Boolean active) {
        this.active = active;
    }

    /**
     * Check if is standard
     *
     * @return java.lang.Boolean
     */
    public Boolean getStandard() {
        return standard;
    }

    /**
     * Define if it's  standard
     *
     * @param standard
     */
    public void setStandard(final Boolean standard) {
        this.standard = standard;
    }

    /**
     * Check if is available at first order
     *
     * @return java.lang.Boolean
     */
    public Boolean getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Define if its  available at First Order
     *
     * @param availableFirstOrder
     */
    public void setAvailableFirstOrder(final Boolean availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }

    /**
     * Gets the payment method description
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets te Payment method description
     *
     * @param description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Gets the payment method  acronym
     *
     * @return java.lang.String
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Sets the Payment method acronym
     *
     * @param acronym
     */
    public void setAcronym(final String acronym) {
        this.acronym = acronym;
    }

    /**
     * Gets the payment method code
     *
     * @return java.lang.String
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets te Payment method  code
     *
     * @param code
     */
    public void setCode(final String code) {
        this.code = code;
    }


}
