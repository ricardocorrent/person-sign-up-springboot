package com.ws.sales.documents.requestsignature;

import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.customer.model.Customer;
import com.ws.customer.model.CustomerEmail;
import com.ws.sales.documents.DocumentGateway;
import com.ws.sales.documents.dto.TemplateDTO;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.util.Constants;
import org.apache.commons.collections.CollectionUtils;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Validation class to ensure {@link RequestSignatureDTO} data being manipulated operations is
 * valid and follow it business rules.
 *
 * @since 1.0.0 2019-05-08
 *
 * @author Ricardo Corrent
 */
public class RequestSignatureValidator extends AbstractEntityValidator<RequestSignatureDTO> {

    private final DocumentGateway documentGateway;
    private final SalesOrderService salesOrderService;
    private final SalesOrderValidator salesOrderValidator;
    private final CustomerGateway customerGateway;

    /**
     * Injectable constructor getting access to persisted data.
     *
     * @param documentGateway the instance of {@link DocumentGateway}.
     * @param salesOrderService the instance of {@link SalesOrderService}.
     * @param customerGateway the instance of {@link CustomerGateway}.
     */
    @Inject
    public RequestSignatureValidator(final DocumentGateway documentGateway,
                                     final SalesOrderService salesOrderService,
                                     final SalesOrderValidator salesOrderValidator,
                                     final CustomerGateway customerGateway) {
        this.documentGateway = documentGateway;
        this.salesOrderService = salesOrderService;
        this.salesOrderValidator = salesOrderValidator;
        this.customerGateway = customerGateway;
    }

    /**
     * Default validation method override which will make specific inspections over the given
     * {@link RequestSignatureDTO} according to the given {@link IValidationFilter}
     *
     * @param entity The signed document model instance to be validated
     * @param filter The validation scenario filter
     */
    @Override
    protected void validate(final RequestSignatureDTO entity, final IValidationFilter... filter) {
        validateTemplate(entity);
        validateIfCustomersHasEmails(entity);
        validateIfEmailBelongToTheCustomer(entity);
        throwFoundErrors();
    }

    /**
     * Validate if template exists on document-manager.
     *
     * @param entity contains information from template
     */
    private void validateTemplate(final RequestSignatureDTO entity) {
        final TemplateDTO template = this.documentGateway.getTemplate(entity.getTemplateId());
        if(template == null) {
            addError(new LogicError("templateId", Constants.MESSAGE_REGISTER_NOT_FOUND), entity);
        }
    }

    /**
     * Validate if {@link Customer} has a {@link CustomerEmail}
     *
     * @param entity contains the information about customers that belong to the order.
     */
    private void validateIfCustomersHasEmails(final RequestSignatureDTO entity) {
        final Customer customer = this.getCustomerByOrder(entity.getSalesOrderId());
        if (CollectionUtils.isEmpty(customer.getCustomerEmails())) {
            addError(new LogicError("email", "document.MemberWithoutEmail"), entity);
        }
    }

    /**
     * Validate if {@link CustomerEmail} belong to a {@link Customer}
     *
     * @param entity contains the information about the order that contains a customer.
     */
    private void validateIfEmailBelongToTheCustomer(final RequestSignatureDTO entity) {
        List<CustomerEmail> customerEmails = this.getCustomerEmails(entity.getSalesOrderId());

        final Optional<CustomerEmail> customerEmail =
                customerEmails.stream()
                .filter(email -> email.getEmail().equalsIgnoreCase(entity.getEmail()))
                .findFirst();

        if (!customerEmail.isPresent()) {
            addError(new LogicError("email", "document.emailNotBelongToCustomer"), entity);
        }
    }

    /**
     * This method find the list of emails from the customer
     *
     * @param salesOrderId {@link UUID}
     * @return a {@link List<CustomerEmail>} or an empty if doesn't exists or null
     */
    private List<CustomerEmail> getCustomerEmails(final UUID salesOrderId) {
        final Customer customerByOrder = this.getCustomerByOrder(salesOrderId);
        if (CollectionUtils.isNotEmpty(customerByOrder.getCustomerEmails())) {
            return customerByOrder.getCustomerEmails();
        }
        return Collections.emptyList();
    }

    /**
     * This method get a customer by salesOrderId
     *
     * @param salesOrderId {@link UUID}
     * @return {@link Customer}
     */
    private Customer getCustomerByOrder(final UUID salesOrderId) {
        final SalesOrder salesOrder = this.salesOrderService.get(salesOrderId);
        return this.customerGateway.getCustomer(salesOrder.getCustomerId());
    }

    /**
     * This method validates if there is a message passed through the request
     *
     * @param requestSignatureDTO {@link RequestSignatureDTO}
     * @return {@link boolean} if the message is null or empty
     */
    public boolean messageIsNullOrEmpty(final RequestSignatureDTO requestSignatureDTO) {
        return requestSignatureDTO.getMessage() == null || requestSignatureDTO.getMessage().isEmpty();
    }
}
