package com.ws.sales.external.financial;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.pagination.PagedList;
import com.ws.financial.creditlimit.CreditLimitResource;
import com.ws.financial.creditlimitmovement.CreditLimitMovementResource;
import com.ws.financial.model.CreditLimit;
import com.ws.financial.model.CreditLimitMovement;
import com.ws.financial.model.CreditLimitSearch;
import com.ws.sales.external.AbstractGateway;
import org.apache.http.HttpStatus;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Marco Aurelio F. Schaefer
 * @since 2018-03-04 5.21.0
 */
public class FinancialGateway extends AbstractGateway {

    @InjectProxy
    private CreditLimitMovementResource creditLimitMovementResource;

    @InjectProxy
    private CreditLimitResource creditLimitResource;

    /**
     * Method to insert credit limit movement on financial microservice
     *
     * @param creditLimitMovement movement to insert
     * @return return id from movement inserted
     */
    public Response insertCreditLimitMovement(final CreditLimitMovement creditLimitMovement) {
        return creditLimitMovementResource.insert(creditLimitMovement);
    }

    /**
     * Search credit limit on financial microservice
     *
     * @param creditLimitSearch object with filters to search
     * @return credit limits
     */
    public List<CreditLimit> searchCreditLimit(final CreditLimitSearch creditLimitSearch) {
        try {
            final Response response = creditLimitResource.getCreditByFilters(creditLimitSearch);
            if (response.getStatus() == HttpStatus.SC_OK && response.hasEntity()) {
                final PagedList<CreditLimit> pagedList = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<CreditLimit>>() {
                });
                final List<CreditLimit> items = pagedList.getItems();
                return (items != null) ? items : new ArrayList<>();
            }
            return new ArrayList<>();
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

}
