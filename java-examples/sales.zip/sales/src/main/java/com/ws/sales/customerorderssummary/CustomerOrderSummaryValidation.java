package com.ws.sales.customerorderssummary;

import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.product.ProductGateway;

import javax.inject.Inject;
import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-11
 */
public class CustomerOrderSummaryValidation {

    private final CustomerGateway customerGateway;
    private final ProductGateway productGateway;

    @Inject
    public CustomerOrderSummaryValidation(final CustomerGateway customerGateway,
                                          final ProductGateway productGateway) {
        this.customerGateway = customerGateway;
        this.productGateway = productGateway;
    }

    /**
     * This method just verify if the customer exists
     *
     * @param customerId {@link UUID} used to find
     * @return {@link Boolean} if exists or not
     */
    public boolean customerExists(final UUID customerId) {
        return customerGateway.customerExists(customerId);
    }

    /**
     * Method to return if product exists
     *
     * @param productId {@link UUID}
     * @return {@link Boolean}
     */
    public boolean productExists(final UUID productId) {
        return productGateway.productExists(productId);
    }

    /**
     * Method to return if service exists
     *
     * @param serviceId {@link UUID}
     * @return {@link Boolean}
     */
    public boolean serviceExists(final UUID serviceId) {
        return productGateway.serviceExists(serviceId);
    }

}
