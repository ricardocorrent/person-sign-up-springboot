package com.ws.sales.signeddocument;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.sales.order.SalesOrder;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @since 1.0.0 2019-05-03
 *
 * @author Ricardo Corrent
 */
@Entity
public class SalesOrderSignedDocument extends PhysicalDeleteBaseEntity {

    @NotNull
    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonBackReference
    @PojoColumnFilter(value = {"id"})
    private SalesOrder salesOrder;

    @NotNull
    @Size(max = 255)
    private String documentId;

    @NotNull
    @Size(max = 255)
    private String templateDescription;

    @Size(max = 255)
    private String documentName;

    @Size(max = 100)
    private String message;

    @NotNull
    private Boolean rejectable;

    private Boolean rejected;

    @Size(max = 4000)
    private String fileSignedUrl;

    @JsonGetter("situation")
    public String getSituation(){
        if (this.getRejected() == null) {
            return "SENT";
        } else if (this.getRejected()) {
            return "REJECTED";
        }
        return "SIGNED";
    }
    
    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(final SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(final String documentId) {
        this.documentId = documentId;
    }

    public String getTemplateDescription() {
        return templateDescription;
    }

    public void setTemplateDescription(final String templateDescription) {
        this.templateDescription = templateDescription;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(final String documentName) {
        this.documentName = documentName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public Boolean getRejectable() {
        return rejectable;
    }

    public void setRejectable(final Boolean rejectable) {
        this.rejectable = rejectable;
    }

    public Boolean getRejected() {
        return rejected;
    }

    public void setRejected(final Boolean rejected) {
        this.rejected = rejected;
    }

    public String getFileSignedUrl() {
        return fileSignedUrl;
    }

    public void setFileSignedUrl(final String fileSignedUrl) {
        this.fileSignedUrl = fileSignedUrl;
    }
}
