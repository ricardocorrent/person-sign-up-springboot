package com.ws.sales.external.opportunity;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

/**
 * Transfer object representing an Activity (from the opportunity service).
 * @author Roberto Filho
 * @since 8.3.0 2019-05-20
 */
@Getter
@Setter
public class ActivityDTO {

    private UUID id;
    private String description;

}
