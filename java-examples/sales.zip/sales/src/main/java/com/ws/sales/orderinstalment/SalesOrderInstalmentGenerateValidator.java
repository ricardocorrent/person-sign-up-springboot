package com.ws.sales.orderinstalment;

import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermService;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.AbstractObjectValidator;
import com.ws.sales.validator.ValidationUtils;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.Optional;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 */
public class SalesOrderInstalmentGenerateValidator extends AbstractObjectValidator<SalesOrderInstalmentGenerate> {

    private final SalesOrderService salesOrderService;
    private final PaymentTermService paymentTermService;
    private final OrderParameterService orderParameterService;
    private final SalesOrderValidator salesOrderValidator;

    /**
     * @param orderParameterService to check if the plugin is enabled
     * @param salesOrderValidator   to handle order validations
     * @param salesOrderService     to handle order loads
     * @param paymentTermService    to handle paymentTerm loads
     */
    @Inject
    public SalesOrderInstalmentGenerateValidator(final SalesOrderService salesOrderService, final PaymentTermService paymentTermService,
                                                 final OrderParameterService orderParameterService, final SalesOrderValidator salesOrderValidator) {
        this.salesOrderService = salesOrderService;
        this.paymentTermService = paymentTermService;
        this.orderParameterService = orderParameterService;
        this.salesOrderValidator = salesOrderValidator;
    }

    /**
     * <p>
     * Uses the {@link PaymentTerm} to check if it has a maximum number of instalments.
     * If the maximum number of instalments in the payment term is null, it will create
     * a {@link LogicError}.
     * <p>
     * If not, it will check with {@link this#doValidateInstalmentsNumberIsBiggerThanMaximum(PaymentTerm, SalesOrderInstalmentGenerate)}
     * if the number isn't bigger than the maximum
     *
     * @param paymentTerm                  from the order
     * @param salesOrderInstalmentGenerate Entity who contains number of instalments and days between each one
     * @return {@link LogicError}
     */
    public LogicError doValidateInstalmentsNumber(final PaymentTerm paymentTerm, final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate) {
        return paymentTerm.getMaxNumberInstalment() == null ? this.createNewMaxNumberOfInstalmentsError("0")
                : this.doValidateInstalmentsNumberIsBiggerThanMaximum(paymentTerm, salesOrderInstalmentGenerate);
    }

    /**
     * <p>
     * Uses the {@link PaymentTerm} to check if it has a maximum number of instalments.
     * If the maximum number of instalments in the payment term is bigger than the
     * informed number, it will create a {@link LogicError}
     *
     * @param paymentTerm                  from the order
     * @param salesOrderInstalmentGenerate Entity who contains number of instalments and days between each one
     * @return {@link LogicError}
     */
    private LogicError doValidateInstalmentsNumberIsBiggerThanMaximum(final PaymentTerm paymentTerm, final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate) {
        if (paymentTerm.getMaxNumberInstalment().compareTo(BigDecimal.valueOf(salesOrderInstalmentGenerate.getQuantity())) < 0) {
            return this.createNewMaxNumberOfInstalmentsError(paymentTerm.getMaxNumberInstalment().toString());
        }
        return null;
    }

    /**
     * <p>
     * Uses the {@link ValidationUtils#doCreateLogicErrorWithParam(String, String, String, String)}
     * to handle the creation of a new {@link LogicError} for the maximum number of instalments
     *
     * @param maxNumberOfInstalments to set the param
     */
    private LogicError createNewMaxNumberOfInstalmentsError(final String maxNumberOfInstalments) {
        return ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MESSAGE_PARAMETER_MAX_NUMBER,
                maxNumberOfInstalments,
                Constants.FIELD_QUANTITY,
                Constants.MESSAGE_ORDER_INSTALMENT_MAXIMUM_NUMBER_OF_INSTALMENTS);
    }

    /**
     * <p>
     * Uses the {@link ValidationUtils#doCreateLogicErrorWithParam(String, String, String, String)}
     * to handle the creation of a new {@link LogicError} for the maximum number of instalments
     *
     * @param salesOrderInstalmentGenerate to validate
     * @return {@link LogicError}
     */
    public LogicError doValidateIfDaysAreZeroAndInstalmentsAreMoreThanOne(final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate) {
        if (salesOrderInstalmentGenerate.getQuantity() > 1 && salesOrderInstalmentGenerate.getDaysBetween() == 0) {
            return ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_VALUE,
                    "1",
                    Constants.FIELD_DAYS_BETWEEN,
                    Constants.MESSAGE_JAVAX_MIN_VALUE);
        }
        return null;
    }

    /**
     * @return {@link Boolean#TRUE} if the plugin is enabled
     */
    private Boolean isInstalmentPluginEnabled() {
        return Boolean.valueOf(this.orderParameterService.searchByKey(Constants.FIELD_PARAMETER_ENABLE_ORDER_INSTALMENT).getValue());
    }

    /**
     * If the parameter is disabled, it will add a {@link LogicError}
     *
     * @see AbstractObjectValidator#validateByBeanValidation(Object, String)
     */
    @Override
    public void validateByBeanValidation(final SalesOrderInstalmentGenerate entity, final String index) {
        if (isInstalmentPluginEnabled()) {
            super.validateByBeanValidation(entity, index);
        } else {
            this.addError(new LogicError(Constants.FIELD_ORDER_INSTALMENT, Constants.MESSAGE_INSTALMENT_PLUGIN_DISABLED), entity);
        }
    }

    /**
     * @see AbstractObjectValidator#addError(LogicError, Object)
     */
    @Override
    public <L extends LogicError> void addError(final L logicError, final Object entity) {
        Optional.ofNullable(logicError).ifPresent(error -> super.addError(error, entity));
    }

    /**
     * @see AbstractObjectValidator#validate(Object, IValidationFilter...)
     */
    @Override
    public void validate(final SalesOrderInstalmentGenerate object, final IValidationFilter... filter) {
        final SalesOrder salesOrder = this.salesOrderService.get(object.getOrderId());
        final PaymentTerm paymentTerm = this.paymentTermService.get(salesOrder.getPaymentTermId());
        this.addError(this.salesOrderValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE), object);
        this.addError(this.doValidateInstalmentsNumber(paymentTerm, object), object);
        this.addError(this.doValidateIfDaysAreZeroAndInstalmentsAreMoreThanOne(object), object);
    }
}
