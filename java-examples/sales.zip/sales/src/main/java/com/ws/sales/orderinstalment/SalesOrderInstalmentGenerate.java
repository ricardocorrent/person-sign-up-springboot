package com.ws.sales.orderinstalment;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 */
public class SalesOrderInstalmentGenerate {

    @Min(1)
    @NotNull
    private Integer quantity;

    @Min(0)
    @NotNull
    private Integer daysBetween;

    private UUID orderId;

    private String externalId;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    /**
     * Get of property {@link #quantity}
     *
     * @return java.lang.Integer
     */
    public Integer getQuantity() {
        return quantity;
    }

    /**
     * Set of property {@link #quantity}
     *
     * @param quantity field to set
     */
    public void setQuantity(final Integer quantity) {
        this.quantity = quantity;
    }

    /**
     * Get of property {@link #daysBetween}
     *
     * @return java.lang.Integer
     */
    public Integer getDaysBetween() {
        return daysBetween;
    }

    /**
     * Set of property {@link #daysBetween}
     *
     * @param daysBetween field to set
     */
    public void setDaysBetween(final Integer daysBetween) {
        this.daysBetween = daysBetween;
    }

    /**
     * Get of property {@link #orderId}
     *
     * @return java.util.UUID
     */
    public UUID getOrderId() {
        return orderId;
    }

    /**
     * Set of property {@link #orderId}
     *
     * @param orderId field to set
     */
    public void setOrderId(final UUID orderId) {
        this.orderId = orderId;
    }
}
