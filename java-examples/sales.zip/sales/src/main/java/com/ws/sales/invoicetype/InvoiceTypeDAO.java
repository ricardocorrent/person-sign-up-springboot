package com.ws.sales.invoicetype;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.ExpressionList;
import io.ebean.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * This class represents the persistence layer of Invoice Type, with she it's possible make methods to
 * interact with the database.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
public class InvoiceTypeDAO extends AbstractDAO<InvoiceType> {

    /**
     * This method override the getEntityClass for InvoiceType.
     *
     * @return invoice type
     */
    @Override
    public Class getEntityClass() {
        return InvoiceType.class;
    }

    /**
     * Method to search a list of Invoice Type by filter.
     *
     * @param invoiceTypeSearch the invoice type search contains filters to apply on where clause
     * @return a paged list of invoice type
     */
    public PagedList<InvoiceType> search(final InvoiceTypeSearch invoiceTypeSearch) {

        final Query<InvoiceType> query = find();
        ExpressionList<InvoiceType> where = query.where();

        addIdCondition(invoiceTypeSearch, where);

        addDescriptionCondition(invoiceTypeSearch, where);

        addActiveCondition(invoiceTypeSearch, where);

        return getPagedList(query, invoiceTypeSearch);
    }

    /**
     * This method add the id condition for the where clause.
     *
     * @param invoiceTypeSearch the invoice type search contains filters to apply on where clause
     * @param where             where for search
     */
    private void addIdCondition(final InvoiceTypeSearch invoiceTypeSearch, ExpressionList<InvoiceType> where) {

        if (invoiceTypeSearch.getId() != null) {
            where.eq("id", invoiceTypeSearch.getId());
        }
    }

    /**
     * This method add the description condition for the where clause.
     *
     * @param invoiceTypeSearch the invoice type search contains filters to apply on where clause
     * @param where             where for search
     */
    private void addDescriptionCondition(final InvoiceTypeSearch invoiceTypeSearch, ExpressionList<InvoiceType> where) {

        if (!StringUtils.isEmpty(invoiceTypeSearch.getDescription())) {
            where.icontains("description", invoiceTypeSearch.getDescription());
        }
    }

    /**
     * This method add the active condition for the where clause.
     *
     * @param invoiceTypeSearch the invoice type search contains filters to apply on where clause
     * @param where             where for search
     */
    private void addActiveCondition(final InvoiceTypeSearch invoiceTypeSearch, ExpressionList<InvoiceType> where) {

        if (invoiceTypeSearch.getActive() != null) {
            where.eq("active", invoiceTypeSearch.getActive());
        }
    }

    /**
     * Returns true if the Invoice Type exists or false if not.
     *
     * @param id id of invoice type
     * @return true if invoice type exists and false if not
     */
    public Boolean invoiceTypeExists(final UUID id) {
        return find().select("id").where().eq("id", id).findCount() > 0;
    }
}