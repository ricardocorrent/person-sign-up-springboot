package com.ws.sales.paymentterm;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermission;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermission;
import com.ws.sales.util.Constants;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */

@Entity
public class PaymentTerm extends SoftDeleteBaseEntity implements IPojoConverter {

    private final static String MAPPED_BY = "paymentTerm";

    @NotNull
    private Boolean active;

    @NotNull
    private Boolean standard;

    @NotNull
    private Boolean availableFirstOrder;

    @NotNull
    @Size(max = 255)
    private String description;

    @Size(max = 40)
    private String acronym;

    @Size(max = 40)
    private String code;

    @OneToMany(mappedBy = Constants.FIELD_PAYMENT_TERM, cascade = CascadeType.ALL)
    private List<PaymentTermCompanyPermission> companyPermissions;

    @OneToMany(mappedBy = Constants.FIELD_PAYMENT_TERM, cascade = CascadeType.ALL)
    private List<PaymentTermCustomerPermission> customerPermissions;

    @OneToMany(mappedBy = Constants.FIELD_PAYMENT_TERM, cascade = CascadeType.ALL)
    private List<PaymentTermLocationPermission> locationPermissions;

    @OneToMany(mappedBy = Constants.FIELD_PAYMENT_TERM, cascade = CascadeType.ALL)
    private List<PaymentTermUserPermission> userPermissions;

    @Min(0)
    @Digits(integer = 10, fraction = 0)
    private BigDecimal maxNumberInstalment;

    @Min(0)
    private Integer daysBetweenInstalment;

    @Min(0)
    private Integer instalmentNumber;

    @Min(0)
    private Integer middleTerm;

    private Boolean allowChangeDueDate;

    /**
     * Get of property {@link #active}
     *
     * @return java.lang.Boolean
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Set of property {@link #active}
     *
     * @param active field to set
     */
    public void setActive(final Boolean active) {
        this.active = active;
    }

    /**
     * Get of property {@link #standard}
     *
     * @return java.lang.Boolean
     */
    public Boolean getStandard() {
        return standard;
    }

    /**
     * Set of property {@link #standard}
     *
     * @param standard field to set
     */
    public void setStandard(final Boolean standard) {
        this.standard = standard;
    }

    /**
     * Get of property {@link #availableFirstOrder}
     *
     * @return java.lang.Boolean
     */
    public Boolean getAvailableFirstOrder() {
        return availableFirstOrder;
    }

    /**
     * Set of property {@link #availableFirstOrder}
     *
     * @param availableFirstOrder field to set
     */
    public void setAvailableFirstOrder(final Boolean availableFirstOrder) {
        this.availableFirstOrder = availableFirstOrder;
    }

    /**
     * Get of property {@link #description}
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set of property {@link #description}
     *
     * @param description field to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Get of property {@link #acronym}
     *
     * @return java.lang.String
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Set of property {@link #acronym}
     *
     * @param acronym field to set
     */
    public void setAcronym(final String acronym) {
        this.acronym = acronym;
    }

    /**
     * Get of property {@link #code}
     *
     * @return java.lang.String
     */
    public String getCode() {
        return code;
    }

    /**
     * Set of property {@link #code}
     *
     * @param code field to set
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Get of property {@link #companyPermissions}
     *
     * @return java.util.List<com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermission>
     */
    public List<PaymentTermCompanyPermission> getCompanyPermissions() {
        return companyPermissions;
    }

    /**
     * Set of property {@link #companyPermissions}
     *
     * @param companyPermissions field to set
     */
    public void setCompanyPermissions(final List<PaymentTermCompanyPermission> companyPermissions) {
        this.companyPermissions = companyPermissions;
    }

    /**
     * Get of property {@link #customerPermissions}
     *
     * @return java.util.List<com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission>
     */
    public List<PaymentTermCustomerPermission> getCustomerPermissions() {
        return customerPermissions;
    }

    /**
     * Set of property {@link #customerPermissions}
     *
     * @param customerPermissions field to set
     */
    public void setCustomerPermissions(final List<PaymentTermCustomerPermission> customerPermissions) {
        this.customerPermissions = customerPermissions;
    }

    /**
     * Get of property {@link #locationPermissions}
     *
     * @return java.util.List<com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission>
     */
    public List<PaymentTermLocationPermission> getLocationPermissions() {
        return locationPermissions;
    }

    /**
     * Set of property {@link #locationPermissions}
     *
     * @param locationPermissions field to set
     */
    public void setLocationPermissions(final List<PaymentTermLocationPermission> locationPermissions) {
        this.locationPermissions = locationPermissions;
    }

    /**
     * Get of property {@link #userPermissions}
     *
     * @return java.util.List<com.ws.sales.paymenttermuserpermission.PaymentTermUserPermission>
     */
    public List<PaymentTermUserPermission> getUserPermissions() {
        return userPermissions;
    }

    /**
     * Set of property {@link #userPermissions}
     *
     * @param userPermissions field to set
     */
    public void setUserPermissions(final List<PaymentTermUserPermission> userPermissions) {
        this.userPermissions = userPermissions;
    }

    /**
     * Get of property {@link #maxNumberInstalment}
     *
     * @return java.math.BigDecimal
     */
    public BigDecimal getMaxNumberInstalment() {
        return maxNumberInstalment;
    }

    /**
     * Set of property {@link #maxNumberInstalment}
     *
     * @param maxNumberInstalment field to set
     */
    public void setMaxNumberInstalment(final BigDecimal maxNumberInstalment) {
        this.maxNumberInstalment = maxNumberInstalment;
    }

    /**
     * Get of property {@link #daysBetweenInstalment}
     *
     * @return java.lang.Integer
     */
    public Integer getDaysBetweenInstalment() {
        return daysBetweenInstalment;
    }

    /**
     * Set of property {@link #daysBetweenInstalment}
     *
     * @param daysBetweenInstalment field to set
     */
    public void setDaysBetweenInstalment(final Integer daysBetweenInstalment) {
        this.daysBetweenInstalment = daysBetweenInstalment;
    }

    /**
     * Get of property {@link #instalmentNumber}
     *
     * @return java.lang.Integer
     */
    public Integer getInstalmentNumber() {
        return instalmentNumber;
    }

    /**
     * Set of property {@link #instalmentNumber}
     *
     * @param instalmentNumber field to set
     */
    public void setInstalmentNumber(final Integer instalmentNumber) {
        this.instalmentNumber = instalmentNumber;
    }

    /**
     * Get of property {@link #middleTerm}
     *
     * @return java.lang.Integer
     */
    public Integer getMiddleTerm() {
        return middleTerm;
    }

    /**
     * Set of property {@link #middleTerm}
     *
     * @param middleTerm field to set
     */
    public void setMiddleTerm(final Integer middleTerm) {
        this.middleTerm = middleTerm;
    }

    /**
     * Get of property {@link #allowChangeDueDate}
     *
     * @return java.lang.Boolean
     */
    public Boolean getAllowChangeDueDate() {
        return allowChangeDueDate;
    }

    /**
     * Set of property {@link #allowChangeDueDate}
     *
     * @param allowChangeDueDate field to set
     */
    public void setAllowChangeDueDate(final Boolean allowChangeDueDate) {
        this.allowChangeDueDate = allowChangeDueDate;
    }
}
