package com.ws.sales.paymenttermuserpermission;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.sales.paymentterm.PaymentTerm;

/**
 * Created by maykon.rissi on 16-Feb-18.
 */
@Entity
@PreventRecycling
public class PaymentTermUserPermission extends PhysicalDeleteBaseEntity implements IPojoConverter {

    @ManyToOne
    @JoinColumn(name = "payment_term_id")
    @JsonBackReference
    @NotNull
    private PaymentTerm paymentTerm;

    @NotNull
    @PojoColumnMapper(target = "user.id")
    private UUID userId;

    @NotNull
    @Size(max = 255)
    @PojoColumnMapper(target = "user.name")
    private String userName;

    /**
     * Get of property {@link #paymentTerm}
     *
     * @return com.ws.sales.paymentterm.PaymentTerm
     */
    public PaymentTerm getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * Set of property {@link #paymentTerm}
     *
     * @param paymentTerm field to set
     */
    public void setPaymentTerm(final PaymentTerm paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    /**
     * Get of property {@link #userId}
     *
     * @return java.util.UUID
     */
    public UUID getUserId() {
        return userId;
    }

    /**
     * Set of property {@link #userId}
     *
     * @param userId field to set
     */
    public void setUserId(final UUID userId) {
        this.userId = userId;
    }

    /**
     * Get of property {@link #userName}
     *
     * @return java.lang.String
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Set of property {@link #userName}
     *
     * @param userName field to set
     */
    public void setUserName(final String userName) {
        this.userName = userName;
    }
}
