package com.ws.sales.external.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;
import java.util.UUID;

/**
 * @author Roberto Filho
 * @since 7.1.0 2019-01-16
 */
public class ServiceDTO {
    private UUID id;
    private CustomerDTO customer;
    private LocationDTO location;

    private Long fullTime;
    private List<TimeDTO> times;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public CustomerDTO getCustomer() {
        return customer;
    }

    public void setCustomer(final CustomerDTO customer) {
        this.customer = customer;
    }

    public Long getFullTime() {
        return fullTime;
    }

    public void setFullTime(final Long fullTime) {
        this.fullTime = fullTime;
    }

    public List<TimeDTO> getTimes() {
        return times;
    }

    public void setTimes(final List<TimeDTO> times) {
        this.times = times;
    }

    public LocationDTO getLocation() {
        return location;
    }

    public void setLocation(final LocationDTO location) {
        this.location = location;
    }
}
