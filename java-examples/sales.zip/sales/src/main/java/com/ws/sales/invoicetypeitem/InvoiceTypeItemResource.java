package com.ws.sales.invoicetypeitem;

import com.ws.commons.server.AbstractResource;

import javax.inject.Inject;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * This class represents the Resource of Invoice Type Item, she received requisitions by REST protocol.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
@Path("/invoice-type-items")
public class InvoiceTypeItemResource extends AbstractResource<InvoiceTypeItem, InvoiceTypeItemSearch> {

    /**
     * Injects InvoiceTypeItemService class for communication between layers of InvoiceTypeItemResource
     * and InvoiceTypeItemService.
     */
    private final InvoiceTypeItemService invoiceTypeItemService;

    @Inject
    public InvoiceTypeItemResource(InvoiceTypeItemService invoiceTypeItemService) {
        this.invoiceTypeItemService = invoiceTypeItemService;
    }

    /**
     * Method to search a list of Invoice Situation by filter.
     *
     * @param invoiceTypeItemSearch represents the search for invoice type item
     * @return
     */
    @Override
    public Response search(InvoiceTypeItemSearch invoiceTypeItemSearch) {
        return Response.ok().entity(invoiceTypeItemService.search(invoiceTypeItemSearch)).build();
    }
}