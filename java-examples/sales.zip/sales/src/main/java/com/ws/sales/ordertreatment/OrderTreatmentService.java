package com.ws.sales.ordertreatment;

import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderTreatmentService extends AbstractService<OrderTreatment> {

    private final OrderTreatmentDAO orderTreatmentDAO;
    private final OrderTreatmentValidator orderTreatmentValidator;

    /**
     * @param orderTreatmentDAO       to perform the persistence operations.
     * @param orderTreatmentValidator to perform validations.
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Inject
    public OrderTreatmentService(final OrderTreatmentDAO orderTreatmentDAO,
                                 final OrderTreatmentValidator orderTreatmentValidator) {
        super(orderTreatmentDAO);
        this.orderTreatmentDAO = orderTreatmentDAO;
        this.orderTreatmentValidator = orderTreatmentValidator;
    }

    /**
     * Override default insert to handle validations.
     *
     * @param entity to persist.
     * @return OrderTreatment
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    public OrderTreatment insert(final OrderTreatment entity) throws Exception {
        orderTreatmentValidator.validate(entity);
        orderTreatmentValidator.throwFoundErrors();
        return super.insert(entity);
    }

    /**
     * Override default update to handle validations
     *
     * @param entity to persist.
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    @Override
    public void update(final OrderTreatment entity) throws Exception {
        orderTreatmentValidator.validate(entity);
        orderTreatmentValidator.throwFoundErrors();
        super.update(entity);
    }

    /**
     * Search using pagination parameters and filters
     *
     * @param search entity with attributes for pagination search
     * @return PagedList
     * @author Maykon Rissi
     * @since v5.22.0 2018-05-28
     */
    public PagedList<OrderTreatment> search(final OrderTreatmentSearch search) {
        return this.orderTreatmentDAO.search(search);
    }
}
