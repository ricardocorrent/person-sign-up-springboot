package com.ws.sales.paymentmethod;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.server.pagination.PagedList;

import io.ebean.ExpressionList;
import io.ebean.Query;

/**
 * @author Thyago Volpatto
 * @since v1.0.0 2016-08-22
 */
public class PaymentMethodDAO extends AbstractDAO<PaymentMethod> {

    /**
     * Method return class entity
     *
     * @return Class
     */
    @Override
    public Class<PaymentMethod> getEntityClass() {
        return PaymentMethod.class;
    }

    /**
     * Filter the payment methods
     *
     * @param search
     * @return PagedList<PaymentMethod>
     */
    public PagedList<PaymentMethod> list(final PaymentMethodSearch search) {

        if (search.getOrderTest() && (search.getPaymentMethodIds() == null || search.getPaymentMethodIds().length == 0)) {
            return new PagedList<>(new ArrayList<>(), 0, search.getPage(), search.getPageSize());
        }
        final Query<PaymentMethod> query = find();

        final ExpressionList<PaymentMethod> where = query.where();

        this.applyFilters(where, search);

        return getPagedList(query, search);

    }

    private void applyFilters(final ExpressionList<PaymentMethod> where, final PaymentMethodSearch search) {

        applyGeneralSearch(where, search);

        if (search.getActive() != null && search.getActive().length > 0) {
            where.eq("active", search.getActive()[0]);
        }

        if (search.getStandard() != null && search.getStandard().length > 0) {
            where.eq("standard", search.getStandard()[0]);
        }

        if (search.getAvailableFirstOrder() != null && search.getAvailableFirstOrder().length > 0) {
            where.eq("availableFirstOrder", search.getAvailableFirstOrder()[0]);
        }

        if (search.getPaymentMethodIds() != null && search.getPaymentMethodIds().length > 0) {
            where.in("id", Arrays.asList(search.getPaymentMethodIds()));
        }

    }

    private void applyGeneralSearch(final ExpressionList<PaymentMethod> where, final PaymentMethodSearch search) {
        if (!StringUtils.isEmpty(search.getDescription())) {
            where.icontains("description", search.getDescription());
        }

        if (!StringUtils.isEmpty(search.getGeneralSearch())) {
            where.icontains("description", search.getGeneralSearch());
        }
    }

    /**
     * Check if Payment Method exists.
     *
     * @param id {@link PaymentMethod#id}
     * @return {@code true} or {@code false}
     * @author Diego Peliser <diego.peliser@wssim.com.br>
     */
    public boolean paymentMethodExists(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("id").where().eq("id", id).findCount() > 0;
    }

    /**
     * @return a single {@link PaymentMethod} which standard property is equals true
     * @author Sanderson silva
     * @since 1.0.0 2016-10-11
     */
    public PaymentMethod getStandard() {
        return find().where().eq("standard", Boolean.TRUE).eq("active", Boolean.TRUE).findOne();
    }

    /**
     * @author Marcos Matheus de andrade
     */
    public PaymentMethod getStatePaymentMethod(final UUID id) {
        Validate.notNull(id, "ID cannot be null");
        return find().select("active").where().eq("id", id).findOne();
    }
}
