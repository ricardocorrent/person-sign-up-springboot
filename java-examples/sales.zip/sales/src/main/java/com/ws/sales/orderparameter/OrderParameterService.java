package com.ws.sales.orderparameter;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.pagination.PagedList;

import javax.inject.Inject;
import java.util.Optional;

/**
 * The class OrderParameterService is used to call the validator of business rules and the DAO layer(persistence layer).
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-05-22
 */
public class OrderParameterService extends AbstractService<OrderParameter> {

    private final OrderParameterDAO orderParameterDAO;
    private final OrderParameterValidator orderParameterValidator;

    /**
     * Injects OrderParameterDAO class for communication between layers of OrderParameterService
     * and OrderParameterDAO.
     */
    @Inject
    public OrderParameterService(final OrderParameterDAO orderParameterDAO, final OrderParameterValidator orderParameterValidator) {
        super(orderParameterDAO);
        this.orderParameterDAO = orderParameterDAO;
        this.orderParameterValidator = orderParameterValidator;
    }

    /**
     * Method to search a list of Order Parameter by filter.
     *
     * @param orderParameterSearch the order parameter search.
     * @return the paged list of order parameter.
     */
    public PagedList<OrderParameter> search(final OrderParameterSearch orderParameterSearch) {
        return orderParameterDAO.search(orderParameterSearch);
    }

    /**
     * @see AbstractService#update(SoftDeleteBaseEntity)
     */
    @Override
    public void update(final OrderParameter entity) throws Exception {

        orderParameterValidator.validateByBeanValidation(entity, null);
        orderParameterValidator.validate(entity);
        orderParameterValidator.throwFoundErrors();

        super.update(entity);
    }

    /**
     * Method to search a Order Parameter by key.
     *
     * @param key
     * @return order Parameter
     */
    public OrderParameter searchByKey(final String key) {
        return orderParameterDAO.searchByKey(key);
    }

    /**
     * Gets a specific parameter's value.
     * 
     * @param key the identification of the parameter.
     * @return the value of the parameter (as per 'getValue' method).
     */
    public String getValueByKey(final String key) {
        final OrderParameter orderParameter = searchByKey(key);

        return Optional.ofNullable(orderParameter)
                .map(OrderParameter::getValue)
                .orElse(null);
    }
}
