package com.ws.sales.invoice;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * This class represents the Json to be provided to update the relationship between Invoice and InvoiceSituation.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-30
 */
public class UpdateInvoiceTO implements Serializable {

    /**
     * This field is used to identified a invoice situation by id;
     */
    @NotNull
    private UUID invoiceSituationId;

    /**
     * Gets invoice situation id.
     *
     * @return the invoice situation id
     */
    public UUID getInvoiceSituationId() {
        return invoiceSituationId;
    }

    /**
     * Sets invoice situation id.
     *
     * @param invoiceSituationId the invoice situation id
     */
    public void setInvoiceSituationId(UUID invoiceSituationId) {
        this.invoiceSituationId = invoiceSituationId;
    }
}