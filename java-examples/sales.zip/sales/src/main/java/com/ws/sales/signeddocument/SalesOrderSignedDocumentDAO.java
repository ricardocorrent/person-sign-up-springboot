package com.ws.sales.signeddocument;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.adapter.RestQueryAdapter;
import com.ws.commons.server.pagination.PagedList;
import io.ebean.Query;
import java.util.List;
import java.util.UUID;

/**
 * Data access object for {@link SalesOrderSignedDocument} entities.
 *
 * @since v1.0.0 2019-05-03
 *
 * @author Ricardo Corrent
 */
public class SalesOrderSignedDocumentDAO extends AbstractDAO<SalesOrderSignedDocument> {
    @Override
    public Class<SalesOrderSignedDocument> getEntityClass() {
        return SalesOrderSignedDocument.class;
    }

    /**
     * findByOrder is a method to apply restrictions on query to return a paged list with signed documents
     * available for the order informed.
     *
     * @param queryAdapter The query adapter with the filter parameters
     * @return a paged result with signed documents available
     */
    public PagedList<SalesOrderSignedDocument> findByOrder(final UUID orderId, final RestQueryAdapter restQueryAdapter) {
        final Query<SalesOrderSignedDocument> query = this.find().where().eq("salesOrder.id", orderId).query();
        return getPagedList(query, restQueryAdapter);
    }

    /**
     * listByOrder returns a list with total signed documents that belongs to the order
     *
     * @param orderId {@link UUID}
     * @return {@link List} of {@link SalesOrderSignedDocument}
     */
    public List<SalesOrderSignedDocument> listByOrder(final UUID orderId) {
        return find().where().eq("salesOrder.id", orderId).findList();
    }
}
