package com.ws.sales.customerorderssummary.servicespurchased;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.pojoconverter.DefaultPojoConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * @author ricardo.corrent
 * @since 8.5.0 2019-06-17
 */
@Getter
@Setter
@Entity
@Table(name = "customer_order_history_services_view")
public class CustomerOrderHistoryServicesView implements DefaultPojoConverter, Identification<UUID> {

    private UUID id;

    private UUID orderId;

    private UUID customerId;

    private UUID serviceId;

    private String serviceCode;

    private String serviceDescription;

    private BigDecimal maxQuantity;

    private BigDecimal maxValue;

    private OffsetDateTime lastPurchaseDate;

    private OffsetDateTime date;

}
