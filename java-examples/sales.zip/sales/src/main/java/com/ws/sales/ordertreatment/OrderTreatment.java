package com.ws.sales.ordertreatment;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
@Entity
public class OrderTreatment extends SoftDeleteBaseEntity implements DefaultPojoConverter {

    @NotNull
    @Size(max = 255)
    private String description;

    /**
     * Get of property {@link #description}
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set of property {@link #description}
     *
     * @param description field to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }
}
