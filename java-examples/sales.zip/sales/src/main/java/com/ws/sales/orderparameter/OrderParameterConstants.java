package com.ws.sales.orderparameter;

/**
 * This class represents the constants for Order Parameter
 *
 * @author Luiz Paulo Lasta Moco
 * @since v5.22.0 2018-06-01
 */
public final class OrderParameterConstants {

    /**
     * Constant to message validation to Field Size Value
     */
    public static final String FIELD_SIZE_VALUE = "fieldSizeValue";
    /**
     * Constant to fiel validation to OrderParemter
     */
    public static final String CLASS = "OrderParameter";
    /**
     * Constant to parameter "BLOCK_ORDER_NEGATIVE_CREDIT"
     */
    public static final String BLOCK_ORDER_NEGATIVE_CREDIT = "BLOCK_ORDER_NEGATIVE_CREDIT";
    /**
     * Constant to parameter "CREDIT_REQUIRED"
     */
    public static final String CREDIT_REQUIRED = "CREDIT_REQUIRED";
    /**
     * Constant to string parameter "true"
     */
    public static final String TRUE = "true";
    /**
     * Constant to string parameter "false"
     */
    public static final String FALSE = "false";
    /**
     * Key to validation of Credit Limit
     */
    public static final String KEY_CREDIT_LIMIT = "validateNegativeCreditLimit";
    /**
     * Message to validation Negative Credit Value "orderConfig.negativeCreditValue"
     */
    public static final String NEGATIVE_CREDIT_VALUE = "orderConfig.negativeCreditValue";
    /**
     * Message to validation Negative Credit Limit "validateNegativeCreditLimit"
     */
    public static final String VALIDATE_NEGATIVE_CREDIT_LIMIT = "orderConfig.negativeCreditRequired";
    /**
     * Message to validation null value
     */
    public static final String NULL_FIELD = "javax.validation.constraints.NotNull.message";
    /**
     * Message to validation Value different ValueField "invalidValueField"
     */
    public static final String INVALID_VALUE_FIELD = "invalidValueField";
    /**
     * Message to validation url id not exist
     */
    public static final String URL_PARAMETER_NOT_FOUND = "urlParameterNotFound";
    /**
     * Key to validation of value
     */
    public static final String VALUE = "value";
    /**
     * Key to validation of minValue
     */
    public static final String MIN_VALUE = "minValue";
    /**
     * Key to validation of ID
     */
    public static final String ID = "id";
    /**
     * Key to validation of maxValue
     */
    public static final String MAX_VALUE = "maxValue";

    /**
     * Private constructor
     */
    private OrderParameterConstants() {
        // Constructor
    }

}

