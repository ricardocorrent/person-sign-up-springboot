package com.ws.sales.invoice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * This class represents invoice item measure unit serializer for invoice item, she will be serialize just the
 * fields id and description from invoice measure unit because it's just it the API needed.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-07-07
 */
public class InvoiceItemMeasureUnitSerializer extends StdSerializer<InvoiceItemMeasureUnit> {

    /**
     * Instantiates a new invoice measure unit serializer.
     */
    public InvoiceItemMeasureUnitSerializer() {
        this(null);
    }

    /**
     * Instantiates a new invoice measure unit serializer.
     *
     * @param t the t
     */
    protected InvoiceItemMeasureUnitSerializer(Class<InvoiceItemMeasureUnit> t) {
        super(t);
    }

    /**
     * This method override the serialization of InvoiceItemMeasureUnit for InvoiceItem class, just two fields will be serialized,
     * because it's just it the API needed.
     *
     * @param value
     * @param gen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(InvoiceItemMeasureUnit value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        InvoiceItemMeasureUnit invoiceItemMeasureUnit = new InvoiceItemMeasureUnit();
        invoiceItemMeasureUnit.setId(value.getId());
        invoiceItemMeasureUnit.setReplicatedId(value.getReplicatedId());
        invoiceItemMeasureUnit.setDescription(value.getDescription());
        gen.writeObject(invoiceItemMeasureUnit);
    }
}