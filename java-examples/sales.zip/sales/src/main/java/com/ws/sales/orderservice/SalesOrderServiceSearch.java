package com.ws.sales.orderservice;

import com.ws.commons.server.pagination.PaginationSearch;

import java.util.UUID;

/**
 * @author Peterson Schmitt
 * @since v8.2.0 2019-04-17
 */
public class SalesOrderServiceSearch extends PaginationSearch {

    private String serviceDescription;

    private UUID serviceId;

    private UUID salesOrderId;

    public String getServiceDescription() {
        return serviceDescription;
    }

    public void setServiceDescription(final String serviceDescription) {
        this.serviceDescription = serviceDescription;
    }

    public UUID getServiceId() {
        return serviceId;
    }

    public void setServiceId(final UUID serviceId) {
        this.serviceId = serviceId;
    }

    public UUID getSalesOrderId() {
        return salesOrderId;
    }

    public void setSalesOrderId(final UUID salesOrderId) {
        this.salesOrderId = salesOrderId;
    }
}
