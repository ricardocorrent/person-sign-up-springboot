package com.ws.sales.invoicetype;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ws.commons.persistence.annotation.PreventRecycling;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.sales.invoice.Invoice;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * This class represents the entity Invoice Type.
 * Some possible invoice types:
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Entity
@PreventRecycling
public class InvoiceType extends SoftDeleteBaseEntity implements Serializable {

    /**
     * This field represents the description for the InvoiceType.
     */
    @NotNull
    @Size(max = 255)
    private String description;

    /**
     * This field represents if the register is active or not.
     */
    @NotNull
    private Boolean active;

    /**
     * This field represents the relationship of InvoiceType with Invoice.
     */
    @OneToMany(mappedBy = "invoiceType")
    @JsonIgnore
    private List<Invoice> invoices;

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets active.
     *
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Sets active.
     *
     * @param active the active
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * Gets invoices.
     *
     * @return the invoices
     */
    public List<Invoice> getInvoices() {
        return invoices;
    }

    /**
     * Sets invoices.
     *
     * @param invoices the invoices
     */
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }
}
