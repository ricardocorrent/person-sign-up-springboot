package com.ws.sales.paymenttermcustomerpermission;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.validation.entityvalidator.AbstractIndexedEntityValidator;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.IndexedLogicError;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.customer.CustomerValidation;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 **/
public class PaymentTermCustomerPermissionValidator extends AbstractIndexedEntityValidator<PaymentTermCustomerPermission> {

    private final CustomerValidation customerValidation;

    /**
     * @param customerValidation to handle validations for customer
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-04
     **/
    @Inject
    public PaymentTermCustomerPermissionValidator(final CustomerValidation customerValidation) {
        this.customerValidation = customerValidation;
    }

    /**
     * <p>
     * This method will validate the customer and create a new {@link IndexedLogicError}
     * It will add the error by using {@link ValidationUtils#createIndexedFromLogicError(String, LogicError)}
     * to convert the {@link LogicError} given by the validation to the indexed
     *
     * @param entity to get customer and validate
     * @param index  to fill the {@link IndexedLogicError}
     **/
    private void doValidateCustomer(final PaymentTermCustomerPermission entity, final String index) {
        final LogicError error = this.customerValidation.doValidateCustomerCanBeUsed(entity.getCustomerId());
        this.addError(ValidationUtils.createIndexedFromLogicError(index, error), entity);
    }

    /**
     * <p>
     * This method will validate the permission and create a new {@link IndexedLogicError}
     * It will use the entitiesInDatabase list to search if the informed permission is there
     * <p>
     * If the permission is already persisted, it will add an error.
     *
     * @param entity             to get customer and validate
     * @param index              to fill the {@link IndexedLogicError}
     * @param entitiesInDatabase to check if the permission is already persisted
     **/
    public void doValidatePermission(final PaymentTermCustomerPermission entity, final String index, final List<PaymentTermCustomerPermission> entitiesInDatabase) {
        final LogicError error = this.doValidateIfPermissionExistsInDatabase(entity, index, entitiesInDatabase);
        this.addError(error, entity);
    }

    /**
     * <p>
     * Stream the list of persisted permissions to check if the informed one is
     * already persisted. It will return an {@link IndexedLogicError} if it found
     *
     * @param entity             to get customer and validate
     * @param index              to fill the {@link IndexedLogicError}
     * @param entitiesInDatabase to check if the permission is already persisted
     * @return {@link IndexedLogicError}
     **/
    private IndexedLogicError doValidateIfPermissionExistsInDatabase(final PaymentTermCustomerPermission entity, final String index,
                                                                     final List<PaymentTermCustomerPermission> entitiesInDatabase) {
        return entitiesInDatabase.stream()
                .map(PaymentTermCustomerPermission::getCustomerId)
                .filter(customerId -> customerId.equals(entity.getCustomerId()))
                .map(hasPermissionInDb -> new IndexedLogicError(index, Constants.FIELD_CUSTOMER_ID, Constants.MESSAGE_PERMISSION_ALREADY_PERSISTED))
                .findFirst()
                .orElse(null);
    }

    /**
     * @see AbstractIndexedEntityValidator#addError(LogicError, BaseModel)
     **/
    @Override
    public <L extends LogicError> void addError(final L logicError, final BaseModel entity) {
        Optional.ofNullable(logicError).ifPresent(error -> super.addError(error, entity));
    }

    /**
     * <p>
     * this method wont be used, because more parameters are needed to perform
     * the validations
     *
     * @see AbstractIndexedEntityValidator#validate(BaseModel, String, IValidationFilter...)
     **/
    @Override
    protected void validate(final PaymentTermCustomerPermission entity, final String index, final IValidationFilter... filter) {
        throw new UnsupportedOperationException();
    }

    /**
     * @param entity             to perform validations
     * @param entitiesInDatabase {@link List<PaymentTermCustomerPermission>} from the informed {@link com.ws.sales.paymentterm.PaymentTerm} in the database
     * @param index              to fill the {@link IndexedLogicError}
     * @see AbstractIndexedEntityValidator#validate(BaseModel, String, IValidationFilter...)
     **/
    public void validate(final PaymentTermCustomerPermission entity, final List<PaymentTermCustomerPermission> entitiesInDatabase, final String index) {
        this.doValidateCustomer(entity, index);
        this.doValidatePermission(entity, index, entitiesInDatabase);
    }
}
