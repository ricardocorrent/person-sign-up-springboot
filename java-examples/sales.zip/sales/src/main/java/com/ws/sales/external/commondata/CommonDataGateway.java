package com.ws.sales.external.commondata;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ws.administration.currency.CurrencyResource;
import com.ws.administration.model.Currency;
import com.ws.commondata.incoterms.IncotermsResource;
import com.ws.commondata.model.Incoterms;
import com.ws.commons.integration.proxytextension.InjectProxy;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.external.AbstractGateway;
import org.apache.http.HttpStatus;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import static java.util.Objects.nonNull;

/**
 * This class is a Common-data micro-service gateway.
 *
 * @author augusto.sopchuk
 * @author Marco Aurelio F. Schaefer
 * @since v5.8.0 2017-06-30
 */
public class CommonDataGateway extends AbstractGateway {

    @InjectProxy
    private CurrencyResource currencyResource;

    @InjectProxy
    private IncotermsResource incotermsResource;

    /**
     * Method to get a currency from common data service
     *
     * @param id id from currency
     * @return currency
     */
    private Currency getCurrency(final UUID id) {
        if (nonNull(id)) {
            return getEntityFromGatewayCall(Currency.class, id, currencyResource::get, id.toString());
        }
        return null;
    }

    /**
     * Method to return if currency exists
     *
     * @param id id to get currency
     * @return {@code true} if currency is exists, {@code false} otherwise
     */
    public Boolean currencyExists(final UUID id) {
        return getCurrency(id) != null;
    }

    /**
     * Method to get a incoterms from common data service
     *
     * @param id id from incoterms
     * @return incoterms
     */
    public Incoterms getIncoterms(final UUID id) {
        try {
            final Response response = incotermsResource.list();

            if (response != null && response.getStatus() == HttpStatus.SC_OK) {
                PagedList<Incoterms> incoterms = getMapper().readValue((InputStream) response.getEntity(), new TypeReference<PagedList<Incoterms>>() {
                });

                return incoterms.getItems()
                        .stream()
                        .filter(incoterm -> incoterm.getId().equals(id.toString()))
                        .findFirst()
                        .orElse(null);
            }
            return null;
        } catch (final IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }
}