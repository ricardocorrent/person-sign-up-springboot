package com.ws.sales.external.administration.dto;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.DefaultPojoConverter;

/**
 * Created by sergio.junior on 11/1/2017.
 */
public class CurrencyDTO extends BaseDTO implements DefaultPojoConverter {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
