package com.ws.sales.orderoperation;

import com.ws.commons.server.pagination.PaginationSearch;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-28
 */
public class OrderOperationSearch extends PaginationSearch {

    private String description;

    private String code;

    /**
     * Get of property {@link #description}
     *
     * @return java.lang.String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set of property {@link #description}
     *
     * @param description field to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Get of property {@link #code}
     *
     * @return java.lang.String
     */
    public String getCode() {
        return code;
    }

    /**
     * Set of property {@link #code}
     *
     * @param code field to set
     */
    public void setCode(final String code) {
        this.code = code;
    }
}
