package com.ws.sales.external.customer;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.customer.model.Customer;
import com.ws.customer.model.Location;
import com.ws.sales.util.Constants;

import javax.inject.Inject;
import java.util.Optional;
import java.util.UUID;

/**
 * Validations for customer and location
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-13
 */
public class CustomerValidation {

    private final CustomerGateway customerGateway;

    /**
     * @param customerGateway to perform customer gets
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Inject
    public CustomerValidation(final CustomerGateway customerGateway) {
        this.customerGateway = customerGateway;
    }

    /**
     * Return an error if the customer does not exist or is inactive.
     *
     * @param customerId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    public LogicError doValidateCustomerCanBeUsed(final UUID customerId) {
        return Optional.ofNullable(customerId).map(id -> {
            final Customer customer = customerGateway.getCustomer(id);
            if (customer == null) {
                return new LogicError(Constants.FIELD_CUSTOMER_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!customer.isActive()) {
                return new LogicError(Constants.FIELD_CUSTOMER_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the location does not exist or is inactive.
     *
     * @param locationId to load entity and validate
     * @return {@link LogicError}  if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    public LogicError doValidateLocationCanBeUsed(final UUID locationId) {
        return Optional.ofNullable(locationId).map(id -> {
            final Location location = customerGateway.getLocation(id);
            if (location == null) {
                return new LogicError(Constants.FIELD_LOCATION_ID, Constants.MESSAGE_REGISTER_NOT_FOUND);
            }
            if (!location.isActive()) {
                return new LogicError(Constants.FIELD_LOCATION_ID, Constants.MESSAGE_REGISTER_INACTIVE);
            }
            return null;
        }).orElse(null);
    }

    /**
     * Return an error if the location does not belong to the customer. It must have these 2 params, or it will return null
     *
     * @param locationId to load entity and validate
     * @param customerId to load entity and validate
     * @return {@link LogicError} if there is an error, or null if it is ok
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    public LogicError doValidateLocationBelongsToCustomer(final UUID locationId, final UUID customerId) {
        if (locationId != null && customerId != null) {
            final Boolean locationBelongsToCustomer = customerGateway.locationBelongsToCustomer(locationId, customerId);
            return locationBelongsToCustomer ? null : new LogicError(Constants.FIELD_LOCATION_ID, Constants.MESSAGE_LOCATION_DOES_NOT_BELONG_TO_CUSTOMER);
        }
        return null;
    }
}
