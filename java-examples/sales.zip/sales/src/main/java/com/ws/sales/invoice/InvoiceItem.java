package com.ws.sales.invoice;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.sales.invoicetypeitem.InvoiceTypeItem;
import com.ws.sales.order.SalesOrder;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * This class represents the entity Invoice item.
 *
 * @author augusto.sopchuk
 * @since v5.8.0 2017-06-26
 */
@Entity
public class InvoiceItem extends SoftDeleteBaseEntity implements Serializable {

    /**
     * This field represents the item amount for the InvoiceItem.
     */
    @NotNull
    @Column(precision = 18, scale = 6)
    private BigDecimal totalValue;

    /**
     * This field represents the location id for the InvoiceItem.
     */
    @NotNull
    @Column(precision = 18, scale = 6)
    private BigDecimal unitValue;

    /**
     * This field represents the location id for the InvoiceItem.
     */
    @NotNull
    @Column(precision = 18, scale = 6)
    private BigDecimal quantity;

    /**
     * This field represents the location id for the InvoiceItem.
     */
    @Size(max = 255)
    private String batch;

    /**
     * This field represents the relationship of InvoiceItem with InvoiceItemMeasureUnit.
     */
    @Valid
    @OneToOne(mappedBy = "invoiceItem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceItemMeasureUnitSerializer.class)
    private InvoiceItemMeasureUnit invoiceItemMeasureUnit;

    /**
     * This field represents the relationship of InvoiceItem with InvoiceItemProduct.
     */
    @Valid
    @NotNull
    @OneToOne(mappedBy = "invoiceItem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonSerialize(using = InvoiceItemProductSerializer.class)
    private InvoiceItemProduct invoiceItemProduct;

    /**
     * This field represents the relationship of InvoiceItem with SalesOrder.
     */
    @ManyToOne
    @JoinColumn(name = "sales_order_id")
    @JsonSerialize(using = InvoiceItemSalesOrderSerializer.class)
    private SalesOrder salesOrder;

    /**
     * This field represents the relationship of InvoiceItem with Invoice.
     */
    @ManyToOne
    @JoinColumn(name = "invoice_id")
    @JsonBackReference(value = "invoice")
    private Invoice invoice;

    /**
     * This field represents the relationship of InvoiceItem with InvoiceTypeItem.
     */
    @NotNull
    @ManyToOne
    @JoinColumn(name = "invoice_type_item_id")
    private InvoiceTypeItem invoiceTypeItem;

    /**
     * Gets total value.
     *
     * @return the total value
     */
    public BigDecimal getTotalValue() {
        return totalValue;
    }

    /**
     * Sets total value.
     *
     * @param totalValue the total value
     */
    public void setTotalValue(BigDecimal totalValue) {
        this.totalValue = totalValue;
    }

    /**
     * Gets unit value.
     *
     * @return the unit value
     */
    public BigDecimal getUnitValue() {
        return unitValue;
    }

    /**
     * Sets unit value.
     *
     * @param unitValue the unit value
     */
    public void setUnitValue(BigDecimal unitValue) {
        this.unitValue = unitValue;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    /**
     * Gets batch.
     *
     * @return the batch
     */
    public String getBatch() {
        return batch;
    }

    /**
     * Sets batch.
     *
     * @param batch the batch
     */
    public void setBatch(String batch) {
        this.batch = batch;
    }

    /**
     * Gets sales order.
     *
     * @return the sales order
     */
    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    /**
     * Sets sales order.
     *
     * @param salesOrder the sales order
     */
    public void setSalesOrder(SalesOrder salesOrder) {
        this.salesOrder = salesOrder;
    }

    /**
     * Gets invoice item measure unit.
     *
     * @return the invoice item measure unit
     */
    public InvoiceItemMeasureUnit getInvoiceItemMeasureUnit() {
        return invoiceItemMeasureUnit;
    }

    /**
     * Sets invoice item measure unit.
     *
     * @param invoiceItemMeasureUnit the invoice item measure unit
     */
    public void setInvoiceItemMeasureUnit(InvoiceItemMeasureUnit invoiceItemMeasureUnit) {
        this.invoiceItemMeasureUnit = invoiceItemMeasureUnit;
    }

    /**
     * Gets invoice item product.
     *
     * @return the invoice item product
     */
    public InvoiceItemProduct getInvoiceItemProduct() {
        return invoiceItemProduct;
    }

    /**
     * Sets invoice item product.
     *
     * @param invoiceItemProduct the invoice item product
     */
    public void setInvoiceItemProduct(InvoiceItemProduct invoiceItemProduct) {
        this.invoiceItemProduct = invoiceItemProduct;
    }

    /**
     * Gets invoice.
     *
     * @return the invoice
     */
    public Invoice getInvoice() {
        return invoice;
    }

    /**
     * Sets invoice.
     *
     * @param invoice the invoice
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    /**
     * Gets invoice type item.
     *
     * @return the invoice type item
     */
    public InvoiceTypeItem getInvoiceTypeItem() {
        return invoiceTypeItem;
    }

    /**
     * Sets invoice type item.
     *
     * @param invoiceTypeItem the invoice type item
     */
    public void setInvoiceTypeItem(InvoiceTypeItem invoiceTypeItem) {
        this.invoiceTypeItem = invoiceTypeItem;
    }
}
