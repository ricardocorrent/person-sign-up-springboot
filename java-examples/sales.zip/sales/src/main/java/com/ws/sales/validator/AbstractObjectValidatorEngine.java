package com.ws.sales.validator;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.server.validation.beanvalidation.integration.ConstraintViolationAdapter;
import com.ws.commons.server.validation.entityvalidator.AbstractEntityValidatorEngine;
import com.ws.commons.server.validation.entityvalidator.IValidationFilter;
import com.ws.commons.server.validation.exception.IndexedLogicError;
import com.ws.commons.server.validation.exception.LogicError;

public abstract class AbstractObjectValidatorEngine<T extends Object> {

    private final Set<ConstraintViolation<Object>> constraintViolations = new LinkedHashSet<>();
    private String indexDescriptor;

    public void validateAndThrowFoundErrors(final T object, final IValidationFilter... filter) {
        Objects.requireNonNull(object, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("object"));

        validate(object, filter);

        throwFoundErrors();
    }

    /**
     * Performs the object validation.
     *
     * @param object to be validated.
     * @param filter to perform isolated validations.
     */
    public abstract void validate(final T object, final IValidationFilter... filter);

    /**
     * Performs the bean validation.
     *
     * @param entity to be validated.
     * @param index  where the entity was located.
     */
    public void validateByBeanValidation(final T entity, final String index) {
        Objects.requireNonNull(entity, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entity"));

        final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();

        final Validator validator = factory.getValidator();

        final Set<ConstraintViolation<T>> errors = validator.validate(entity);

        errors.forEach(error -> addError(generateLogicError(index, error), entity));
    }

    private LogicError generateLogicError(final String index, final ConstraintViolation<T> error) {
        Objects.requireNonNull(error, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("error"));

        if (index == null) {
            final String invalidValue = error.getInvalidValue() != null ? error.getInvalidValue().toString() : null;

            return new LogicError(
                    getPropertyPath(error),
                    error.getMessageTemplate(),
                    error.getMessage(),
                    invalidValue,
                    getConstraintParameters(error));
        }

        return new IndexedLogicError(index, error);
    }

    private String getPropertyPath(final ConstraintViolation<T> error) {
        Objects.requireNonNull(error, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("error"));

        return error.getPropertyPath() != null ? error.getPropertyPath().toString() : null;
    }

    private Map<String, Object> getConstraintParameters(final ConstraintViolation<T> error) {
        Objects.requireNonNull(error, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("error"));

        return error.getConstraintDescriptor() != null ? error.getConstraintDescriptor().getAttributes() : null;
    }

    /**
     * Add the validation in {@link AbstractEntityValidatorEngine#constraintViolations}
     *
     * @param <L>        extends LogicError
     * @param logicError with the error parameters.
     * @param entity     that was validated.
     */
    public <L extends LogicError> void addError(final L logicError, final Object entity) {
        Objects.requireNonNull(logicError, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("logicError"));

        Objects.requireNonNull(entity, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entity"));

        constraintViolations.add(new ConstraintViolationAdapter<Object>(handleIndexDescriptor(logicError), entity));
    }

    private LogicError handleIndexDescriptor(final LogicError logicError) {

        return logicError;
    }

    /**
     * @param index                  in which the entity is located.
     * @param constraintViolationSet as errors to attach in this validation scope.
     * @param entity                 that was validated.
     */
    public void addError(final String index, final Set<ConstraintViolation<SoftDeleteBaseEntity>> constraintViolationSet, final SoftDeleteBaseEntity entity) {
        Objects.requireNonNull(constraintViolationSet, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("constraintViolationSet"));

        Objects.requireNonNull(entity, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entity"));

        constraintViolationSet.forEach(error -> {
            final IndexedLogicError indexedError = new IndexedLogicError(composeIdexDescriptor(index), error);

            constraintViolations.add(new ConstraintViolationAdapter<Object>(indexedError, entity));
        });
    }

    private String composeIdexDescriptor(final String index) {
        if (StringUtils.isNotEmpty(indexDescriptor)) {
            return StringUtils.join(indexDescriptor, "_", index);
        }

        return index;
    }

    public void throwFoundErrors() {
        if (CollectionUtils.isNotEmpty(constraintViolations)) {
            throw new ConstraintViolationException(constraintViolations);
        }
    }

    public void setIndexDescriptor(final String indexDescriptor) {
        this.indexDescriptor = indexDescriptor;
    }

    /**
     * @return The errors found.
     */
    public Set<ConstraintViolation<Object>> getConstraintViolations() {
        return Collections.unmodifiableSet(constraintViolations);
    }
}
