package com.ws.sales.order;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.deliveryorder.DeliveryOrderDAO;
import com.ws.sales.external.financial.FinancialService;
import com.ws.sales.external.product.ProductService;
import com.ws.sales.external.service.ServiceGateway;
import com.ws.sales.order.enums.OrderOrigin;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.orderinstalment.SalesOrderInstalmentDAO;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderitem.SalesOrderItemDAO;
import com.ws.sales.orderservice.SalesOrderServiceDAO;
import com.ws.sales.ordersituation.SalesOrderSituation;
import com.ws.sales.situation.Situation;
import com.ws.sales.situation.SituationDAO;
import com.ws.sales.situation.SituationSearch;
import org.apache.shiro.session.mgt.SimpleSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;

/**
 * @author Maykon Rissi
 * @since v6.1.0 2018-08-16.
 */
@RunWith(MockitoJUnitRunner.class)
public class SalesOrderServiceUnitTest {

    private SalesOrderService salesOrderService;

    @Mock
    private SalesOrderValidator salesOrderValidator;

    @Mock
    private SalesOrderDAO salesOrderDAO;

    @Mock
    private SalesOrderHeaderValidator salesOrderHeaderValidator;

    @Mock
    private SituationDAO situationDAO;

    @Mock
    private FinancialService financialService;

    @Mock
    private ProductService productService;

    @Mock
    private UserContext userContext;

    @Mock
    private ServiceGateway serviceGateway;

    @Mock
    private SalesOrderItemDAO salesOrderItemDAO;

    @Mock
    private SalesOrderServiceDAO salesOrderServiceDAO;

    @Mock
    private DeliveryOrderDAO deliveryOrderDAO;

    @Mock
    private SalesOrderInstalmentDAO salesOrderInstalmentDAO;

    private final static UUID ORDER_ID = UUID.fromString("40dfe3fc-7373-45b2-b1f9-257eac0d3291");

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Before
    public void before(){
        MockitoAnnotations.initMocks(this);
        final SimpleSession simpleSession = new SimpleSession();
        simpleSession.setAttribute("user_id", UUID.randomUUID().toString() );
        Mockito.when(userContext.getSession()).thenReturn(simpleSession);
        Whitebox.setInternalState(salesOrderHeaderValidator, "errors", new ArrayList<>());
        this.salesOrderService =
                new SalesOrderService(salesOrderDAO,
                        salesOrderValidator,
                        situationDAO,
                        financialService,
                        productService,
                        userContext,
                        serviceGateway,
                        salesOrderHeaderValidator,
                        salesOrderItemDAO,
                        salesOrderServiceDAO,
                        deliveryOrderDAO,
                        salesOrderInstalmentDAO);
    }

    public void doMockSalesFindById(final SalesOrder orderInDb) {
        Mockito.when(this.salesOrderDAO.findById(SalesOrderServiceUnitTest.ORDER_ID, (Map<String, String[]>) null)).thenReturn(orderInDb);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockSituation() {
        final Situation situation = new Situation();
        situation.setId(UUID.randomUUID());
        situation.setDescription("PENDENTE");
        situation.setAcronym("PP");

        final List<Situation> situations = new LinkedList<>();
        situations.add(situation);

        Mockito.when(this.situationDAO.list((SituationSearch) Matchers.any())).thenReturn(new PagedList<Situation>(situations, 1));
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private SalesOrder doMockHeader() {
        return SalesOrderBuilder.aSalesOrder()
                .withPriceListId(UUID.randomUUID())
                .withPriceListDescription("R$ - SAFRA 17/18")
                .withPaymentTermId(UUID.randomUUID())
                .withPaymentTermDescription("VENDA A PRAZO REAIS (R$)")
                .withOrderTypeId(UUID.randomUUID())
                .withOrderTypeDescription("VENDA NORMAL")
                .withPaymentMethodId(UUID.randomUUID())
                .withPaymentMethodDescription("CARTAO DE CREDITO")
                .withUserId(UUID.randomUUID())
                .withUserName("MARIO LUCAS ASSIS FRANCO")
                .withCompanyId(UUID.randomUUID())
                .withCompanyName("Wealth Systems")
                .withCustomerId(UUID.randomUUID())
                .withCustomerName("CUSTOMER")
                .withLocationId(UUID.randomUUID())
                .withLocationDescription("PREDIO SEDE")
                .withOrderNumber("123456")
                .withExternalNumber("123456")
                .withCurrency("BRL")
                .withDueDate(LocalDate.now())
                .withOrderCurrency(this.doMockOrderCurrency())
                .build();
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private OrderCurrency doMockOrderCurrency() {
        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(UUID.randomUUID());
        orderCurrency.setCurrencyDescription("TEST");
        orderCurrency.setCurrencyQuotationId(UUID.randomUUID());
        orderCurrency.setCurrencyQuotationValue(BigDecimal.TEN);
        orderCurrency.setCurrencyQuotationDate(LocalDate.now());
        return orderCurrency;
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private SalesOrder doMockFullOrder() throws IOException {
        return SalesOrderBuilder.aSalesOrder()
                .withId(SalesOrderServiceUnitTest.ORDER_ID)
                .withCreatedAt(OffsetDateTime.now())
                .withUpdatedAt(OffsetDateTime.now())
                .withExternalId("565#5#1")
                .withPriceListId(UUID.randomUUID())
                .withPriceListDescription("R$ - SAFRA 17/18")
                .withPaymentTermId(UUID.randomUUID())
                .withPaymentTermDescription("VENDA A PRAZO REAIS (R$)")
                .withOrderTypeId(UUID.randomUUID())
                .withOrderTypeDescription("VENDA NORMAL")
                .withPaymentMethodId(UUID.randomUUID())
                .withPaymentMethodDescription("CARTAO DE CREDITO")
                .withUserId(UUID.randomUUID())
                .withUserName("MARIO LUCAS ASSIS FRANCO")
                .withCompanyId(UUID.randomUUID())
                .withCompanyName("Wealth Systems")
                .withCustomerId(UUID.randomUUID())
                .withCustomerName("CUSTOMER")
                .withLocationId(UUID.randomUUID())
                .withLocationDescription("PREDIO SEDE")
                .withDraft(Boolean.TRUE)
                .withOrderNumber("123456")
                .withExternalNumber("123456")
                .withCurrency("BRL")
                .withOrderedAt(OffsetDateTime.now())
                .withNetValue(BigDecimal.valueOf(1))
                .withItemsQuantity(2)
                .withDueDate(LocalDate.now())
                .withSituationId(UUID.randomUUID())
                .withSituationDescription("NÃO FATURADO")
                .withDeliveryOrders(new ArrayList<>())
                .withItems(this.doMockItems())
                .withServices(this.doMockServices())
                .withSalesOrderSituations(this.doMockSituations())
                .build();
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private List<SalesOrderItem> doMockItems() throws IOException {
        final String[] items = {"{\n" +
                "            \"id\": \"eee4c223-e879-45b4-8bc9-3a109de036c8\",\n" +
                "            \"createdAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                "            \"updatedAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                "            \"externalId\": \"565#5#1#565#5#1\",\n" +
                "            \"productId\": \"ce516909-58fc-4f75-9b86-b68c1671bc07\",\n" +
                "            \"productDescription\": \"DMA 806 BR 1X20L\",\n" +
                "            \"productCode\": \"1.1.015\",\n" +
                "            \"priceListId\": \"ac136321-f1b7-4afe-8fc1-119fe6517259\",\n" +
                "            \"priceListDescription\": \"R$ - SAFRA 17/18\",\n" +
                "            \"priceListItemId\": \"ac136321-f1b7-4afe-8fc1-119fe6517259\",\n" +
                "            \"quantity\": 5,\n" +
                "            \"salesPrice\": 5,\n " +
                "            \"originalPrice\": 5,\n " +
                "            \"totalItem\": 25\n" +
                "        }",
                "{\"id\": \"4c04fc37-d7c9-4a1f-8bea-9fb9fb1ecdd4\",\n" +
                        "            \"createdAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                        "            \"updatedAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                        "            \"externalId\": \"565#5#1#565#5#1\",\n" +
                        "            \"productId\": \"3ce58e20-390c-4368-9460-4570550a1817\",\n" +
                        "            \"productDescription\": \"CLETODIM NORTOX 4X5L\",\n" +
                        "            \"productCode\": \"1.1.214\",\n" +
                        "            \"priceListId\": \"ac136321-f1b7-4afe-8fc1-119fe6517259\",\n" +
                        "            \"priceListDescription\": \"R$ - SAFRA 17/18\",\n" +
                        "            \"priceListItemId\": \"ac136321-f1b7-4afe-8fc1-119fe6517259\",\n" +
                        "            \"quantity\": 10,\n" +
                        "            \"salesPrice\": 5, \n" +
                        "            \"originalPrice\": 5,\n " +
        "            \"totalItem\": 50\n}\n"};

        final List<SalesOrderItem> myItemList = new ArrayList<>();
        final ObjectMapper mapper = new ObjectMapper();
        for (final String s : items) {
            final SalesOrderItem myItem = mapper.readValue(s, SalesOrderItem.class);
            myItemList.add(myItem);
        }
        return myItemList;
    }

    /**
     * @author Peterson Schmitt
     * @since v6.1.0 2019-05-16.
     */
    private List<com.ws.sales.orderservice.SalesOrderService> doMockServices() throws IOException {
        final String[] items = {"{\n" +
                "            \"id\": \"eee4c223-e879-45b4-8bc9-3a109de036c8\",\n" +
                "            \"createdAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                "            \"updatedAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                "            \"externalId\": \"565#5#1#565#5#1\",\n" +
                "            \"serviceId\": \"83c2b76a-ab0d-47b0-9419-373fca34927f\",\n" +
                "            \"serviceDescription\": \"Testee\",\n" +
                "            \"serviceCode\": \"CH9\",\n" +
                "            \"originalPrice\": 10,\n " +
                "            \"salesPrice\": 10,\n " +
                "            \"repetitions\": 1,\n " +
                "            \"quantity\": 1,\n" +
                "            \"discount\": 0,\n" +
                "            \"discountPercentage\": 0,\n" +
                "            \"totalQuantity\": 11,\n" +
                "            \"totalValue\": 110\n" +
        "        }"};

        final List<com.ws.sales.orderservice.SalesOrderService> myItemList = new ArrayList<>();
        final ObjectMapper mapper = new ObjectMapper();
        for (final String s : items) {
            final com.ws.sales.orderservice.SalesOrderService myItem = mapper.readValue(s, com.ws.sales.orderservice.SalesOrderService.class);
            myItemList.add(myItem);
        }
        return myItemList;
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private List<SalesOrderSituation> doMockSituations() throws IOException {
        final String[] situations = {
                "        {\n" +
                        "            \"id\": \"69ff615c-6554-4ba3-a358-4578a4dd97d6\",\n" +
                        "            \"createdAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                        "            \"updatedAt\": \"2018-01-23T18:47:36.630Z\",\n" +
                        "            \"situationId\": \"c91ed815-2ca6-477d-9f8e-58b942842494\",\n" +
                        "            \"situationDescription\": \"FATURADO\",\n" +
                        "            \"rank\": 0\n" +
                        "        }\n"
        };

        final List<SalesOrderSituation> situationList = new ArrayList<>();
        final ObjectMapper mapper = new ObjectMapper();
        for (final String s : situations) {
            final SalesOrderSituation situation = mapper.readValue(s, SalesOrderSituation.class);
            situationList.add(situation);
        }
        return situationList;
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void itemValuesChanged() throws Exception {
        final SalesOrder salesOrder = this.doMockFullOrder();
        this.doMockSalesFindById(salesOrder);
        this.salesOrderService.updateOrderTotalValue(SalesOrderServiceUnitTest.ORDER_ID);
        Assert.assertEquals(BigDecimal.valueOf(185), salesOrder.getNetValue());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void insertHeader() throws Exception {
        final SalesOrder orderHeader = this.doMockHeader();
        final SalesOrder insertedHeader = this.salesOrderService.insert(orderHeader);
        Assert.assertNotNull(insertedHeader.getDraft());
        Assert.assertNotNull(insertedHeader.getId());
        Assert.assertTrue(insertedHeader.getDraft());
        Assert.assertEquals(OrderOrigin.EXT.toString(), insertedHeader.getOrigin());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void insert() throws Exception {
        final SalesOrder orderHeader = this.doMockFullOrder();
        final SalesOrder insertedHeader = this.salesOrderService.insert(orderHeader);
        Assert.assertNotNull(insertedHeader.getDraft());
        Assert.assertNotNull(insertedHeader.getId());
        Assert.assertTrue(insertedHeader.getDraft());
        Assert.assertEquals(OrderOrigin.EXT.toString(), insertedHeader.getOrigin());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void updateHeaderWithoutDueDate() throws Exception {
        final SalesOrder orderHeader = this.doMockHeader();
        final SalesOrder fullOrder = this.doMockFullOrder();
        final UUID idForCustomer = UUID.randomUUID();
        final String nameForCustomer = "NEW NAME";
        orderHeader.setId(SalesOrderServiceUnitTest.ORDER_ID);
        orderHeader.setCustomerId(idForCustomer);
        orderHeader.setCustomerName(nameForCustomer);
        this.doMockSalesFindById(fullOrder);
        Mockito.when(this.productService.isDueDatePluginActive()).thenReturn(Boolean.FALSE);
        this.salesOrderService.update(orderHeader);
        Assert.assertTrue(orderHeader.getDraft());
        Assert.assertEquals(idForCustomer, orderHeader.getCustomerId());
        Assert.assertEquals(nameForCustomer, orderHeader.getCustomerName());
        Assert.assertNotNull(orderHeader.getItems());
        Assert.assertNotNull(orderHeader.getSalesOrderSituations());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void updateHeaderWithDueDateAndDifferentDates() throws Exception {
        final SalesOrder orderHeader = this.doMockHeader();
        final SalesOrder fullOrder = this.doMockFullOrder();
        final UUID idForCustomer = UUID.randomUUID();
        final String nameForCustomer = "NEW NAME";
        orderHeader.setId(SalesOrderServiceUnitTest.ORDER_ID);
        orderHeader.setCustomerId(idForCustomer);
        orderHeader.setCustomerName(nameForCustomer);
        orderHeader.setDueDate(LocalDate.now().plusDays(1));
        this.doMockSalesFindById(fullOrder);
        Mockito.when(this.productService.isDueDatePluginActive()).thenReturn(Boolean.TRUE);
        Mockito.when(this.productService.getDueDateCoefficient(Matchers.any(), Matchers.any())).thenReturn(BigDecimal.valueOf(0.75));
        this.salesOrderService.update(orderHeader);
        Assert.assertTrue(orderHeader.getDraft());
        Assert.assertEquals(BigDecimal.valueOf(166.25), orderHeader.getNetValue());
        Assert.assertEquals(BigDecimal.valueOf(18.75), orderHeader.getItems().get(0).getTotalItem());
        Assert.assertEquals(nameForCustomer, orderHeader.getCustomerName());
        Assert.assertNotNull(orderHeader.getItems());
        Assert.assertNotNull(orderHeader.getServices());
        Assert.assertNotNull(orderHeader.getSalesOrderSituations());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void insertIntegration() throws Exception {
        final SalesOrder order = this.doMockFullOrder();
        order.setOrigin("EXT");
        final SalesOrder inserted = this.salesOrderService.insertForIntegration(order);
        Assert.assertEquals(OrderOrigin.EXT.toString(), inserted.getOrigin());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void updateComplement() throws Exception {
        final SalesOrder order = new SalesOrder();
        final SalesOrder orderInDb = this.doMockFullOrder();
        final String complement = "COMPLEMENT";
        order.setId(SalesOrderServiceUnitTest.ORDER_ID);
        order.setComplement(complement);
        this.doMockSalesFindById(orderInDb);
        this.salesOrderService.updateComplement(order);
        Assert.assertEquals(complement, orderInDb.getComplement());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void updateExternalId() throws Exception {
        final SalesOrder orderInDb = this.doMockFullOrder();
        final String externalId = "IDNEW";
        this.doMockSalesFindById(orderInDb);
        this.salesOrderService.updateExternalId(SalesOrderServiceUnitTest.ORDER_ID.toString(), externalId);
        Assert.assertEquals(externalId, orderInDb.getExternalId());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void updateExternalSituation() throws Exception {
        final SalesOrder orderInDb = this.doMockFullOrder();
        final SalesOrderSituation salesOrderSituation = new SalesOrderSituation();
        final UUID situationId = UUID.randomUUID();
        final String situationDescription = "DESCRICAO";
        salesOrderSituation.setSituationId(situationId);
        salesOrderSituation.setSituationDescription(situationDescription);
        this.doMockSalesFindById(orderInDb);
        this.salesOrderService.updateExternalSituation(SalesOrderServiceUnitTest.ORDER_ID.toString(), salesOrderSituation);
        Assert.assertEquals(situationId, orderInDb.getSalesOrderSituations().get(1).getSituationId());
        Assert.assertEquals(situationDescription, orderInDb.getSalesOrderSituations().get(1).getSituationDescription());
        Assert.assertEquals(BigDecimal.valueOf(2), orderInDb.getSalesOrderSituations().get(1).getRank());
        Assert.assertEquals(situationId, orderInDb.getSituationId());
        Assert.assertEquals(situationDescription, orderInDb.getSituationDescription());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void finalizeOrder() throws Exception {
        this.doMockSalesFindById(this.doMockFullOrder());
        this.doMockSituation();
        this.salesOrderService.doFinalizeOrder(SalesOrderServiceUnitTest.ORDER_ID);
    }
}
