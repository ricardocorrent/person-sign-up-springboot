package com.ws.sales.paymenttermcustomerpermission;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.MockedSecurityManager;

/**
 * @author william.santos
 * @since 2018-09-17
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = { SessionScoped.class, RequestScoped.class }, projectStage = ProjectStage.IntegrationTest.class)
public class PaymentTermCustomerPermissionDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private PaymentTermCustomerPermissionDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, PaymentTermCustomerPermissionDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void getPaymentTermCustomerPermissionByPaymentTermId() {
        final UUID paymentTermId = UUID.fromString("f98724ad-85bf-4b49-ae85-b642185ab81c");
        
        final PagedList<PaymentTermCustomerPermission> terms = this.dao.getByPaymentTerm(paymentTermId);
        Assert.assertNotNull(terms);
        Assert.assertNotNull(terms.getItems());
        Assert.assertFalse(terms.getItems().isEmpty());
        
        terms.getItems().forEach(permission -> {
            Assert.assertTrue(permission.getPaymentTerm().getId().equals(paymentTermId));
        });
    }
    
    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new LinkedHashSet<>();
        files.add("payment_term.xml");
        files.add("payment_term_customer_permission.xml");
        return files;
    }
}
