package com.ws.sales.paymentterm;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.MockedSecurityManager;

/**
 * Test all methods of {@link PaymentTermDAO}
 * 
 * @author william.santos
 * @since 2018-09-14
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = { SessionScoped.class, RequestScoped.class }, projectStage = ProjectStage.IntegrationTest.class)
public class PaymentTermDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private PaymentTermDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, PaymentTermDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void listAllPaymentTerms() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setGeneralSearch("a");

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getDescription().contains("a"));
        });
    }

    @Test
    public void searchByDescriptionReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setDescription("a");

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getDescription().contains("a"));
        });
    }

    @Test
    public void searchByCodeReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setCode("tortor");

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getCode().contains("tortor"));
        });
    }

    @Test
    public void searchByAcronymReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setAcronym("dui");

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getAcronym().contains("dui"));
        });
    }

    @Test
    public void searchByActiveReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setActive(new Boolean[] { Boolean.TRUE });

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getActive());
        });
    }

    @Test
    public void searchByStandardReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setStandard(new Boolean[] { Boolean.FALSE });

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            Assert.assertFalse(term.getStandard());
        });
    }

    @Test
    public void searchByAvailableFirstOrderReturnsList() {
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setAvailableFirstOrder(new Boolean[] { Boolean.TRUE });

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            Assert.assertTrue(term.getAvailableFirstOrder());
        });
    }

    @Test
    public void searchByPaymentTermIdsReturnsList() {
        final UUID[] ids = { UUID.fromString("4d55f82f-225c-433e-a2d3-5018036a3f09"), UUID.fromString("f98724ad-85bf-4b49-ae85-b642185ab81c") };// Ids present in payment_term.xml
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setPaymentTermIds(ids);

        final PagedList<PaymentTerm> list = this.dao.list(search);
        Assert.assertNotNull(list);
        Assert.assertNotNull(list.getItems());
        Assert.assertFalse(list.getItems().isEmpty());

        list.getItems().forEach(term -> {
            final Stream<UUID> idsToSearch =  Stream.of(ids);
            Assert.assertTrue(idsToSearch.anyMatch(term.getId()::equals));
        });
    }
    
    @Test
    public void geStandardPaymentTermReturnsStandard() {
        final PaymentTerm standard = this.dao.getStandard();
        Assert.assertNotNull(standard);
        Assert.assertTrue(standard.getStandard());
        Assert.assertTrue(standard.getActive());
    }

    @Test
    public void checkExistentPaymentTermReturnsTrue() {
        final boolean exist = this.dao.paymentTermExists(UUID.fromString("1636e966-b6ec-4e67-8627-418b3cc577a0"));
        Assert.assertTrue(exist);
    }
    
    @Test
    public void checkNonexistentPaymentTermReturnsFalse() {
        final boolean exist = this.dao.paymentTermExists(UUID.randomUUID());
        Assert.assertFalse(exist);
    }
    
    @Test
    public void getPaymentTermAndReturnsYourState() {
        final PaymentTerm term = this.dao.getStatePaymentTerm(UUID.fromString("1636e966-b6ec-4e67-8627-418b3cc577a0"));
        Assert.assertNotNull(term);
        Assert.assertNotNull(term.getActive());
    }

    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new HashSet<>();
        files.add("payment_term.xml");
        return files;
    }
}
