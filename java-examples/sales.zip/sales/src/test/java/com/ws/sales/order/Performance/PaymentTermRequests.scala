import io.gatling.core.Predef._

class PaymentTermRequests extends Simulation{

  val requestBuilder = new RequestBuilder
  val constants = new Constants

  def paymentTermJsonBuilder(uuid: String ,active: Boolean, standard: Boolean, availableFirstOrder: Boolean, descriptionQtyChars: Int, acronymQtyChars: Int, codeQtyChars: Int):String = {
    s"""
        {
           "id" : "$uuid",
           "createdAt" : "2017-04-24T20:06:20.217Z",
           "updatedAt" : "2017-04-24T20:06:20.217Z",
           "active" : $active,
           "standard" : $standard,
           "availableFirstOrder" : $availableFirstOrder,
           "description" : "${constants.randomString(descriptionQtyChars)}",
           "acronym" : "${constants.randomString(acronymQtyChars)}",
           "code" : "${constants.randomString(codeQtyChars)}"
         }
    """
  }

  def searchPaymentTermBuilder(page: Int, pageSize: Int, isActive: Boolean, isntActive: Boolean, isAvailableForFirstOrder: Boolean, isntAvailableForFirstOrder: Boolean, isStandard: Boolean, isntStandard: Boolean, description: String, acronym: String, code: String): String = {
    s"""
        {
           "page" : $page,
           "pageSize" : $pageSize,
           "active" :""".concat(requestBuilder.boolJsonBuilder(isActive, isntActive))
    .concat("\"availableFirstOrder\" : " + requestBuilder.boolJsonBuilder(isAvailableForFirstOrder, isntAvailableForFirstOrder))
    .concat("\"standard\" : " + requestBuilder.boolJsonBuilder(isStandard, isntStandard))
    .concat(s"""
          "description" : "$description",
          "acronym" : "$acronym",
          "code" : "$code"
        }
    """)
  }

  def postPaymentTerm(RequestDescription: String,uuid: String, active: Boolean, standard: Boolean, availableFirstOrder: Boolean, descriptionQtyChars: Int, acronymQtyChars: Int, codeQtyChars: Int) = {
    requestBuilder.post(RequestDescription, "/api/v1/sales/payment-terms", paymentTermJsonBuilder(uuid, active, standard, availableFirstOrder, descriptionQtyChars, acronymQtyChars, codeQtyChars))
  }

  def searchPaymentTerm(page: Int, pageSize: Int, isActive: Boolean, isntActive: Boolean, isAvailableForFirstOrder: Boolean, isntAvailableForFirstOrder: Boolean, isStandard: Boolean, isntStandard: Boolean, description: String, acronym: String, code: String) = {
    requestBuilder.search("search_payment_term", "/api/v1/sales/payment-terms/search", searchPaymentTermBuilder(page, pageSize, isActive, isntActive, isAvailableForFirstOrder, isntAvailableForFirstOrder, isStandard, isntStandard, description, acronym, code))
  }
}