/**
 * 
 */
package com.ws.sales.paymentmethod;

import java.util.HashSet;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.sollar.test.util.MockedSecurityManager;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;

/**
 * @author william.santos
 * @since 2018-08-29
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = {SessionScoped.class, RequestScoped.class}, projectStage = ProjectStage.IntegrationTest.class)
public class PaymentMethodDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private PaymentMethodDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, PaymentMethodDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void getStandardWithSuccess() {
        final PaymentMethod payment = this.dao.getStandard();
        Assert.assertNotNull(payment);
        Assert.assertTrue(payment.getActive());
        Assert.assertTrue(payment.getStandard());
    }
    
    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new HashSet<>();
        files.add("payment_method.xml");
        return files;
    }

}
