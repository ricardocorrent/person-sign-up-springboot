package com.ws.sales.orderinstalment;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.order.SalesOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.testng.Assert;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

@RunWith(MockitoJUnitRunner.class)
public class OrderInstalmentValidatorUnitTest extends BaseUnitTest {

    @InjectMocks
    private SalesOrderInstalmentValidator validator;

    @Mock
    private SalesOrderInstalmentDAO salesOrderInstalmentDAO;

    @Test
    public void isValidIfDueDateIsAfterOrderDate() {

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCreatedAt(OffsetDateTime.now());

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setDueDate(LocalDate.now().plusDays(1));

        validator.doValidateInstalmentDateBeforeOrder(instalment, salesOrder);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isInvalidIfDueDateIsBeforeOrderDate() {

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCreatedAt(OffsetDateTime.now());

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setDueDate(LocalDate.now().minusDays(1));

        validator.doValidateInstalmentDateBeforeOrder(instalment, salesOrder);

        Assert.assertEquals(validator.getConstraintViolations().size(), 1);
    }

    @Test
    public void isValidWithNullDueDate() {

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCreatedAt(OffsetDateTime.now());

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setDueDate(null);

        validator.doValidateInstalmentDateBeforeOrder(instalment, salesOrder);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isValidWithNullObject() {

        final SalesOrder salesOrder = null;

        final SalesOrderInstalment instalment = null;

        validator.doValidateInstalmentDateBeforeOrder(instalment, salesOrder);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isValidIfDateIsHigherThanLastInstalment() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();
        final SalesOrderInstalment instalmentAfter = new SalesOrderInstalment();
        final SalesOrder salesOrder = new SalesOrder();

        salesOrder.setId(UUID.randomUUID());

        instalmentAfter.setDueDate(LocalDate.now().plusDays(1));
        instalmentAfter.setNumber(1);
        instalmentAfter.setSalesOrder(salesOrder);

        instalment.setDueDate(LocalDate.now());
        salesOrderInstalments.add(instalment);

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateLower(instalmentAfter);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isInvalidIfDateIsLowerThanLastInstalment() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();
        final SalesOrderInstalment instalmentAfter = new SalesOrderInstalment();
        final SalesOrder salesOrder = new SalesOrder();

        salesOrder.setId(UUID.randomUUID());

        instalmentAfter.setDueDate(LocalDate.now().minusDays(1));
        instalmentAfter.setNumber(1);
        instalmentAfter.setSalesOrder(salesOrder);

        instalment.setDueDate(LocalDate.now());
        salesOrderInstalments.add(instalment);

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateLower(instalmentAfter);

        Assert.assertEquals(validator.getConstraintViolations().size(), 1);
    }

    @Test
    public void isValidIfEntityIsNull() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();

        instalment.setDueDate(LocalDate.now());
        salesOrderInstalments.add(instalment);

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateLower(null);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isValidIfDateIsSmallerThanLastInstalment() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();
        final SalesOrderInstalment instalmentAfter = new SalesOrderInstalment();
        final SalesOrder salesOrder = new SalesOrder();

        salesOrder.setId(UUID.randomUUID());

        instalmentAfter.setDueDate(LocalDate.now().minusDays(1));
        instalmentAfter.setNumber(1);
        instalmentAfter.setSalesOrder(salesOrder);

        instalment.setDueDate(LocalDate.now());
        salesOrderInstalments.add(instalment);

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateHigher(instalmentAfter);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isInvalidIfDateIsBiggerThanLastInstalment() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();
        final SalesOrderInstalment instalmentAfter = new SalesOrderInstalment();
        final SalesOrder salesOrder = new SalesOrder();

        salesOrder.setId(UUID.randomUUID());

        instalmentAfter.setDueDate(LocalDate.now().plusDays(1));
        instalmentAfter.setNumber(1);
        instalmentAfter.setSalesOrder(salesOrder);

        instalment.setDueDate(LocalDate.now());
        salesOrderInstalments.add(instalment);

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateHigher(instalmentAfter);

        Assert.assertEquals(validator.getConstraintViolations().size(), 1);
    }

    @Test
    public void isValidIfIsFirstInstalment() {

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();
        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        final List<SalesOrderInstalment> salesOrderInstalments = new LinkedList<>();
        final SalesOrderInstalment instalmentAfter = new SalesOrderInstalment();
        final SalesOrder salesOrder = new SalesOrder();

        salesOrder.setId(UUID.randomUUID());

        instalmentAfter.setDueDate(LocalDate.now().plusDays(1));
        instalmentAfter.setNumber(1);
        instalmentAfter.setSalesOrder(salesOrder);

        instalment.setDueDate(LocalDate.now());
        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);
        validator.doValidateDateLower(instalmentAfter);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }

    @Test
    public void isValidIfInstalmentExists() {

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setId(UUID.randomUUID());
        instalment.setNumber(1);
        Mockito.when(salesOrderInstalmentDAO.findById(Mockito.any())).thenReturn(instalment);

        Assert.assertNotNull(validator.getInstalmentAndValidate(instalment));
    }

    @Test
    public void isInvalidWhenThrowException() {

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setId(UUID.randomUUID());
        instalment.setNumber(1);
        Mockito.when(salesOrderInstalmentDAO.findById(Mockito.any())).thenThrow(new RegisterNotFoundException());

        Assert.assertNull(validator.getInstalmentAndValidate(instalment));
    }

    @Test
    public void isValidIfIsUpdateOfOneInstalmentAndTheValueIsEqualToOrder() {

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.TEN);

        final SalesOrderInstalment instalment = new SalesOrderInstalment();
        instalment.setValue(BigDecimal.TEN);

        final PagedList<SalesOrderInstalment> pagedListInstalments = new PagedList<>();
        final List<SalesOrderInstalment> instalments = new LinkedList<>();
        instalments.add(instalment);
        pagedListInstalments.setItems(instalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedListInstalments);

        validator.doValidateIfValueIsDifferentThanOrderAndIsSingleInstalment(instalment, salesOrder);

        Assert.assertEquals(validator.getConstraintViolations().size(), 0);
    }
}
