package com.ws.sales.paymenttermlocationpermission;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.ConstraintViolationException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

/**
 * Test all methods of {@link PaymentTermLocationPermissionService}
 * 
 * @author william.santos
 * @since V7.0.0 - 2018-09-17
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermLocationPermissionServiceUnitTest extends BaseUnitTest {

    @Mock
    private PaymentTermLocationPermissionDAO dao;

    @Mock
    private PaymentTermDAO termDao;

    @Mock
    private PaymentTermLocationPermissionValidator validator;

    private PaymentTermLocationPermissionService service;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.service = new PaymentTermLocationPermissionService(this.dao, this.termDao, this.validator);
    }

    @Test
    public void insertInBatchWithSuccess() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermLocationPermission> permissions = new ArrayList<>();
        permissions.add(new PaymentTermLocationPermission());

        Mockito.when(this.termDao.findById(paymentTermId)).thenReturn(new PaymentTerm());
        this.service.insertList(permissions, paymentTermId);

        Mockito.verify(this.dao, Mockito.timeout(1)).batchInsert(permissions);
    }

    @Test
    public void insertInBatchWithExceptionDoNotCallSaveOnDAO() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermLocationPermission> permissions = new ArrayList<>();
        permissions.add(new PaymentTermLocationPermission());

        Mockito.doThrow(ConstraintViolationException.class).when(this.validator).throwFoundErrors();

        try {
            this.service.insertList(permissions, paymentTermId);
        } catch (final ConstraintViolationException exception) {
            // Don't nothing, exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).batchInsert(permissions);
    }

    @Test
    public void getPermissionsByPaymentTermId() {
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermLocationPermission> permissions = new PagedList<>();

        Mockito.when(this.dao.getByPaymentTerm(paymentTermId)).thenReturn(permissions);

        final PagedList<PaymentTermLocationPermission> found = this.service.getByPaymentTerm(paymentTermId);
        Assert.assertNotNull(found);
        Assert.assertEquals(permissions, found);
    }

    /**
     * Test of mapping to convert {@link PaymentTermLocationPermission} to
     * {@link PaymentTermLocationPermissionDTO}
     */
    @Test
    public void convertLocationPermissionToDto() {
        final PaymentTerm term = new PaymentTerm();
        term.setDescription("Term");
        term.setId(UUID.randomUUID());

        final PaymentTermLocationPermission permission = new PaymentTermLocationPermission();
        permission.setId(UUID.randomUUID());
        permission.setLocationId(UUID.randomUUID());
        permission.setLocationDescription("Unit-Test");
        permission.setPaymentTerm(term);
        
        final PaymentTermLocationPermissionDTO dto = new PojoConverter().convert(PaymentTermLocationPermissionDTO.class, permission);
        Assert.assertNotNull(dto);
        Assert.assertEquals(permission.getId(), dto.getId());
        Assert.assertEquals(permission.getLocationDescription(), dto.getLocation().getDescription());
        Assert.assertEquals(term.getDescription(), dto.getPaymentTerm().getDescription());
    }
}
