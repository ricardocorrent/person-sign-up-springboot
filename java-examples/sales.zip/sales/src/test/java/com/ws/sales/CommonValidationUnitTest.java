package com.ws.sales;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.orderoperation.OrderOperation;
import com.ws.sales.ordertype.OrderType;
import com.ws.sales.validator.CommonValidation;
import io.ebean.EbeanServer;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.UUID;

/**
 * @author Maykon Roberto Rissi
 * @since 6.1.0 - 2018-08-20
 */
@RunWith(MockitoJUnitRunner.class)
public class CommonValidationUnitTest {

    @InjectMocks
    private CommonValidation commonValidation;

    @Mock
    private EbeanServer ebeanServer;

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    private OrderType doMockOrderType(final Boolean isActive) {
        final OrderType orderType = new OrderType();
        orderType.setActive(isActive);
        return orderType;
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void willThrowAnErrorBecauseParamsAreNull() {
        try {
            this.commonValidation.doValidateIfEntityCanBeUsed(null, null);
        } catch (final Exception ex) {
            Assert.assertEquals(NullPointerException.class, ex.getClass());
        }
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void entityDoesNotExists() {
        Mockito.when(ebeanServer.find(Mockito.any(), Mockito.any())).thenReturn(null);
        final LogicError error = this.commonValidation.doValidateIfEntityCanBeUsed(UUID.randomUUID(), OrderOperation.class);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void entityExistsAndDoesNotHaveActiveField() {
        Mockito.when(ebeanServer.find(Mockito.any(), Mockito.any())).thenReturn(new OrderOperation());
        final LogicError error = this.commonValidation.doValidateIfEntityCanBeUsed(UUID.randomUUID(), OrderOperation.class);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void entityExistsAndIsNotActive() {
        Mockito.when(ebeanServer.find(Mockito.any(), Mockito.any())).thenReturn(this.doMockOrderType(Boolean.FALSE));
        final LogicError error = this.commonValidation.doValidateIfEntityCanBeUsed(UUID.randomUUID(), OrderType.class);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void entityExistsAndIsActive() {
        Mockito.when(ebeanServer.find(Mockito.any(), Mockito.any())).thenReturn(this.doMockOrderType(Boolean.TRUE));
        final LogicError error = this.commonValidation.doValidateIfEntityCanBeUsed(UUID.randomUUID(), OrderType.class);
        Assert.assertNull(error);
    }
}
