package com.ws.sales.external.product;

import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.1.0 2018-08-16.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductServiceUnitTest {

    @InjectMocks
    private ProductService productService;

    @Mock
    private ProductGateway productGateway;

    @Mock
    private OrderParameterService orderParameterService;

    /**
     * @param value to set the mock
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockOrderParameter(final Boolean value) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(value.toString());
        Mockito.when(this.orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    /**
     * @param value to set the mock
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockDueDateValue(final BigDecimal value) {
        Mockito.when(this.productGateway.getDueDateValue(Mockito.any(), Mockito.any())).thenReturn(value);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void dueDatePluginIsEnabled() {
        this.doMockOrderParameter(Boolean.TRUE);
        Assert.assertTrue(this.productService.isDueDatePluginActive());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void dueDatePluginIsDisabled() {
        this.doMockOrderParameter(Boolean.FALSE);
        Assert.assertFalse(this.productService.isDueDatePluginActive());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void priceListHasDueDate() {
        final BigDecimal dueDateInformed = BigDecimal.valueOf(0.78);
        this.doMockDueDateValue(dueDateInformed);
        final BigDecimal dueDateReceived = this.productService.getDueDateCoefficient(UUID.randomUUID(), LocalDate.now());
        Assert.assertEquals(dueDateReceived, dueDateInformed);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void priceListHasNoDueDateSoItWillReturnOne() {
        final BigDecimal dueDateInformed = BigDecimal.ONE;
        this.doMockDueDateValue(dueDateInformed);
        final BigDecimal dueDateReceived = this.productService.getDueDateCoefficient(UUID.randomUUID(), LocalDate.now());
        Assert.assertEquals(dueDateReceived, dueDateInformed);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void dueDateIsNullSoItWillReturnOne() {
        final BigDecimal dueDateInformed = BigDecimal.ONE;
        this.doMockDueDateValue(dueDateInformed);
        final BigDecimal dueDateReceived = this.productService.getDueDateCoefficient(UUID.randomUUID(), null);
        Assert.assertEquals(dueDateReceived, dueDateInformed);
    }

}
