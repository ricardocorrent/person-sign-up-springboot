import io.gatling.core.Predef._
import io.gatling.http.Predef._

class UserRequests {

  val doLogin =
    exec(
      http("post_login")
        .post("/api/v1/user/login")
        .body(StringBody("""{"rememberMe":false,"username":"admin@teste.com","password":"123","tenant":"dev5"} """)).asJSON
        .check(status.is(200))
    )

  val getUserProfile =
    exec(
      http("get_users_profile")
      .get("/api/v1/user/users/users-profile?select=id,name")
      .check(status.is(200))
    )

  val getProfileUser =
    exec(
      http("get_profile_user")
      .get("/api/v1/user/profiles/profile-user")
        .check(status.is(200))
    )

}