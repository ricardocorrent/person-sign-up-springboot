import io.gatling.core.Predef._
import io.gatling.http.Predef._

class AdministrationRequests extends Simulation {

  object Company {

    val postCompany =
      exec(
        http("post_company")
        .post("/api/v1/administration/companies")
        .body(StringBody(
          """
            {
                 "createdAt" : "2017-04-18T14:22:45.368Z",
                 "updatedAt" : "2017-04-18T14:24:55.061Z",
                 "companyTypes" : {
                   "id" : "7498ca1e-6bd5-41b3-9853-792ce86ac9a3",
                   "createdAt" : "2017-04-13T17:53:55.420Z",
                   "updatedAt" : "2017-04-13T17:53:55.420Z",
                   "description" : "Empresa TOP",
                   "active" : true
                 },
                 "active" : true,
                 "headOffice" : false,
                 "name" : "Wssim",
                 "tradingName" : "Wealth systems",
                 "streetAddress" : "Av Brasil",
                 "companyPhones" : [ {
                   "id" : "${uuid}",
                   "createdAt" : "2017-04-18T14:24:55.054Z",
                   "updatedAt" : "2017-04-18T14:24:55.054Z"
                 }, {
                   "id" : "${uuid}",
                   "createdAt" : "2017-04-18T14:24:55.063Z",
                   "updatedAt" : "2017-04-18T14:24:55.063Z",
                   "phoneNumber" : "99885669",
                   "phoneTypeId" : "177e7935-4224-498a-ac3d-541978295e08"
                 } ],
                 "companyEmails" : [ ],
                 "companyIdentificationDocuments" : [ ],
                 "operationalCountryId" : "1880236b-09e6-4a50-97b3-fcc1f311f1f6",
                 "operationalCountry" : "1880236b-09e6-4a50-97b3-fcc1f311f1f6"
            }
          """)).asJSON
      )

    val getCompany =
      exec(
        http("get_companies")
          .get("/api/v1/administration/companies?active=true&select=id,name")
          .check(status.is(200))
      )
  }

  object Currency {
    val getCurrency =
      exec(
        http("get_currencies")
          .get("/api/v1/administration/currencies?active=true")
          .check(status.is(200))
      )
  }
}