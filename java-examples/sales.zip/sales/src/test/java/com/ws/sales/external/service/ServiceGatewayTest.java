package com.ws.sales.external.service;

import com.ws.service.service.ServiceResource;
import org.apache.commons.io.IOUtils;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.core.Response;

import java.io.IOException;
import java.util.UUID;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * @author Roberto Filho
 * @since 7.1.0 2019-01-16
 */
@RunWith(MockitoJUnitRunner.class)
public class ServiceGatewayTest {

    @Mock
    private ServiceResource service;

    private final String serviceBody = "{\n" +
            "  \"items\": [\n" +
            "    {\n" +
            "      \"id\": \"75b533de-5c0b-4de6-9f2e-755acc60b764\",\n" +
            "      \"customer\": {\n" +
            "        \"id\": \"e16195e9-4a30-4f14-b450-2ed73bf0675e\",\n" +
            "        \"name\": \"Mariana\"\n" +
            "      },\n" +
            "      \"location\": {\n" +
            "        \"id\": \"762f592b-1d59-4879-906c-ac97ff85e615\",\n" +
            "        \"description\": \"Local da Mariana\"\n" +
            "      },\n" +
            "      \"fullTime\": 0,\n" +
            "      \"times\": [\n" +
            "        {\n" +
            "          \"id\": \"197d4a6f-b4cb-4598-9664-68729bb4fdfb\",\n" +
            "          \"startDate\": \"2019-01-16T13:22:45.054Z\"\n" +
            "        }\n" +
            "      ]\n" +
            "    }\n" +
            "  ],\n" +
            "  \"count\": 1,\n" +
            "  \"page\": 0,\n" +
            "  \"pageSize\": 500\n" +
            "}";

    private final String emptyServiceBody = "{\n" +
            "  \"count\": 0,\n" +
            "  \"page\": 0,\n" +
            "  \"pageSize\": 25\n" +
            "}";

    @InjectMocks
    private ServiceGateway serviceGateway = new ServiceGateway();

    @Test
    public void shouldReturnCurrentlyRunningServiceWhenServiceQueried() throws IOException {
        final Response response = Response.ok().entity(IOUtils.toInputStream(serviceBody)).build();
        when(service.search(any())).thenReturn(response);

        final ServiceDTO serviceInExecution = serviceGateway.getServiceInExecution(UUID.randomUUID());

        assertThat(serviceInExecution, is(notNullValue()));
        assertThat(serviceInExecution, hasProperty("id", equalTo(UUID.fromString("75b533de-5c0b-4de6-9f2e-755acc60b764"))));
        assertThat(serviceInExecution, hasProperty("customer"));
        assertThat(serviceInExecution, hasProperty("location"));
    }

    @Test
    public void shouldNotThrowExceptionWhenNoServiceCurrentlyRunning() throws IOException {
        final Response response = Response.ok().entity(IOUtils.toInputStream(emptyServiceBody)).build();
        when(service.search(any())).thenReturn(response);

        final ServiceDTO serviceInExecution = serviceGateway.getServiceInExecution(UUID.randomUUID());

        assertThat(serviceInExecution, is(nullValue()));
    }
}