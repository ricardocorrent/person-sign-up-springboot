import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.util.Random

class SalesRequests extends Simulation {

  def randomString(qtyChars: Int): String = {
    "API TEST" + Random.alphanumeric.take(qtyChars).mkString.toUpperCase
  }

  object Order {

    val postValidOrder =
      exec(
        http("post_order")
          .post("/api/v1/sales/orders")
          .body(StringBody(
            """{
               "id" : "${uuid}",
               "createdAt" : "2017-04-24T12:05:12.206Z",
               "updatedAt" : "2017-04-24T12:05:12.245Z",
               "priceListId" : "0f93b541-5b74-40c5-b90b-cd446f705f5e",
               "priceListDescription" : "SAFRINHA 2016",
               "paymentTermId" : "55efde25-6c69-4e50-a677-f146ff9b29eb",
               "paymentTermDescription" : "DEVOLUCAO DE VENDAS",
               "orderTypeId" : "927c22b2-0670-4a23-a45e-ab09b5b151d0",
               "orderTypeDescription" : "PRIMEIRA VENDA",
               "paymentMethodId" : "28863888-9788-45ed-953a-783a94c6db7e",
               "paymentMethodDescription" : "A PRAZO",
               "userId" : "7636f630-2358-4cf4-a290-2ec0b13ea47c",
               "userName" : "Administrador",
               "companyId" : "a87cee94-ca43-4291-aba0-18e896bb8aeb",
               "companyName" : "JBS",
               "customerId" : "01aa6e1f-07e3-4606-b537-04cfe29c01b5",
               "customerName" : "Maron Botley 454",
               "locationId" : "1d4c7c85-4c88-4be7-b13c-d2b7b2991305",
               "locationDescription" : "Maron Botley 454",
               "draft" : true,
               "currency" : "BRL",
               "orderedAt" : "2017-04-24T12:03:19.494Z",
               "grossValue" : 853.300000,
               "netValue" : 853.300000,
               "quantity" : 15.000000,
               "items" : [ {
                 "id" : "${uuid}",
                 "createdAt" : "2017-04-24T12:05:12.213Z",
                 "updatedAt" : "2017-04-24T12:05:12.213Z",
                 "productId" : "fb9d9460-957c-4811-df05-f8a06cc7820d",
                 "productDescription" : "2,4-D AMINOL 806 1X20L",
                 "productCode" : "1.1.081",
                 "grossValue" : 60.000000,
                 "netValue" : 60.000000,
                 "quantity" : 5.000000,
                 "totalItem" : 0.000000,
                 "discount" : 0.000000,
               }],
               "salesOrderSituations" : [ ],
               "deliveryOrder" : {
                 "id" : "${uuid}",
                 "createdAt" : "2017-04-24T12:05:12.219Z",
                 "updatedAt" : "2017-04-24T12:05:12.219Z",
                 "salesOrder" : {
                   "id" : "${uuid}",
                   "items" : [ ],
                   "salesOrderSituations" : [ ]
                 },
                 "shipmentDate" : "2017-04-24",
                 "deliveryDate" : "2017-04-30",
                 "locationId" : "1d4c7c85-4c88-4be7-b13c-d2b7b2991305",
                 "locationDescription" : "Maron Botley 454"
               },
               "cropId" : "2662b281-5255-40f6-aec0-57073892473a",
               "cropDescription" : "Safra 2017-2018",
               "cultureId" : "5e65a9aa-7652-41f4-8f7f-e46ec5cf0bb3",
               "cultureDescription" : "Cultura - soja",
               "complement" : "Este pedido está sendo gerado para validação do gatling como ferramenta para automação de teste de API."
             }""")).asJSON
        .check(jsonPath("$").saveAs("serverResponse")))
        .exec(session => {
              val serverResponse = session.get("serverResponse").asOption[String]
              println(serverResponse)
              session
        })

    val searchOrder =
      exec(
        http("search_orders")
          .post("/api/v1/sales/orders/search")
          .body(StringBody("""{"page":0,"pageSize":300}""")).asJSON
          .check(status.is(200))
      )

    val validateOrder =
      exec(
        http("validate_order")
        .post("/api/v1/sales/orders/validate-order")
        .body(StringBody("""{
               "id": null,
               "orderedAt": "2017-04-19T18:02:57.015Z",
               "items": [],
               "draft": true,
               "currency": "BRL",
               "orderNumber": null,
               "deliveryOrder": null,
               "customerId": "54091067-4fb0-4c40-9874-8301d18acb76",
               "customerName": "Super Muffato",
               "locationId": "8c5e8ff1-36ea-4691-bdc1-ff0952c499bd",
               "locationDescription": "Carlos Gomes",
               "userId": "7636f630-2358-4cf4-a290-2ec0b13ea47c",
               "userName": "Administrador",
               "companyId": "a87cee94-ca43-4291-aba0-18e896bb8aeb",
                "companyName": "JBS",
               "orderTypeId": "fe901fff-1bde-47aa-9853-bb8227d04472",
               "orderTypeDescription": "Tipo de pedido Tipo de pedido Tipo de pedido Tipo de pedido Tipo de pedido Tipo de pedido Tipo de pedido Tipo de pedidoTipo de pedido Tipo de pedido Tipo de pedido Tipo de pedido",
               "priceListId": "0f93b541-5b74-40c5-b90b-cd446f705f5e",
               "priceListDescription": "SAFRINHA 2016",
               "paymentTermId": "55efde25-6c69-4e50-a677-f146ff9b29eb",
               "paymentTermDescription": "DEVOLUCAO DE VENDAS",
               "paymentMethodId": "28863888-9788-45ed-953a-783a94c6db7e",
               "paymentMethodDescription": "A PRAZO",
               "grossValue": 0,
               "netValue": 0,
               "quantity": 0,
               "cropId": "9f7146c1-ba4f-4577-a139-4718f644eebd",
               "cropDescription": "Safra 2017-2018",
               "cultureId": "5e65a9aa-7652-41f4-8f7f-e46ec5cf0bb3",
               "cultureDescription": "Cultura - soja"
             }""")).asJSON
          .check(status.is(200))
      )
  }

  object OrderType {
    val getOrderType =
      exec(
        http("get_order_types")
          .get("/api/v1/sales/order-types?active=true&select=id,description")
          .check(status.is(200))
      )
  }

  object PaymentTerm {
    def paymentTermJsonBuilder(active: Boolean, standard: Boolean, availableFirstOrder: Boolean, descriptionQtyChars: Int, acronymQtyChars: Int, codeQtyChars: Int):String = {
       s"""
          {
             "createdAt" : "2017-04-24T20:06:20.217Z",
             "updatedAt" : "2017-04-24T20:06:20.217Z",
             "active" : $active,
             "standard" : $standard,
             "availableFirstOrder" : $availableFirstOrder,
             "description" : "${randomString(descriptionQtyChars)}",
             "acronym" : "${randomString(acronymQtyChars)}",
             "code" : "${randomString(codeQtyChars)}"
           }
      """
    }

    def postPaymentTerm(active: Boolean, standard: Boolean, availableFirstOrder: Boolean, descriptionQtyChars: Int, acronymQtyChars: Int, codeQtyChars: Int) = {
      exec(
        http("post_payment_term")
          .post("/api/v1/sales/payment-terms")
          .body(StringBody(paymentTermJsonBuilder(active, standard, availableFirstOrder, descriptionQtyChars, acronymQtyChars, codeQtyChars))).asJSON
          .check(jsonPath("$..message").saveAs("messageValidation"))
          .check(jsonPath("$...max").saveAs("maxChars"))
          .check(status.is(422).saveAs("httpStatus"))
      )
    }

    val validatePaymentTermAPITEST =
      exec(
        http("search_payment_term_api_test")
        .post("/api/v1/sales/payment-terms/search")
        .body(StringBody("""{"description":"API TEST","active":[true,false],"page":0,"pageSize":25}""")).asJSON
        .check(status.is(200))
      )

    val searchPaymentTerm =
      exec(
        http("search_payment_terms")
          .post("/api/v1/sales/payment-terms/search?select=id,description")
          .body(StringBody("""{"active":[true],"select":"id,description","orderTest":true}""")).asJSON
          .check(status.is(200))
      )
  }

  object PaymentMethod {
    val searchPaymentMethod =
      exec(
        http("search_payment_methods")
          .post("/api/v1/sales/payment-terms/search?select=id,description")
          .body(StringBody("""{"active":[true],"select":"id,description","orderTest":true}""")).asJSON
          .check(status.is(200))
      )
  }

  object OrderConfiguration {
    val getOrderConfiguration =
      exec(
        http("get_order_configuration")
          .get("/api/v1/sales/orders-configuration")
          .check(status.is(200))
      )
  }

}