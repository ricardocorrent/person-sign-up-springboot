package com.ws.sales.paymenttermcompanypermission;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.MockedSecurityManager;

/**
 * @author william.santos
 * @since 2018-09-17
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = { SessionScoped.class, RequestScoped.class }, projectStage = ProjectStage.IntegrationTest.class)
public class PaymentTermCompanyPermissionDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private PaymentTermCompanyPermissionDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, PaymentTermCompanyPermissionDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void getPaymentTermCompanyPermissionByPaymentTermId() {
        final UUID paymentTermId = UUID.fromString("4d55f82f-225c-433e-a2d3-5018036a3f09");
        
        final PagedList<PaymentTermCompanyPermission> terms = this.dao.getByPaymentTerm(paymentTermId);
        Assert.assertNotNull(terms);
        Assert.assertNotNull(terms.getItems());
        Assert.assertFalse(terms.getItems().isEmpty());
        
        terms.getItems().forEach(permission -> {
            Assert.assertTrue(permission.getPaymentTerm().getId().equals(paymentTermId));
        });
    }
    
    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Don't need nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new LinkedHashSet<>();
        files.add("payment_term.xml");
        files.add("payment_term_company_permission.xml");
        return files;
    }
}
