import io.gatling.core.Predef._
class PaymentTermSimulation extends Simulation {

  val constants = new Constants
  val paymentTermScenarios = new PaymentTermScenarios

  setUp(
    paymentTermScenarios.postAPaymentTermWithDescriptionGreaterThanAllowed.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermWithAcronymGreaterThanAllowed.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermWithCodeGreaterThanAllowed.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermWithoutDescription.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermWithoutAcronym.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermWithoutCode.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAnInactivePaymentTerm.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAStandardPaymentTerm.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAnAvailableFirstOrderPaymentTerm.inject(rampUsers(1) over 1),
    paymentTermScenarios.postAPaymentTermSuccessfully.inject(rampUsers(1) over 1),
    paymentTermScenarios.scnSearchPaymentTerm.inject(rampUsers(1) over 1)
  ).protocols(constants.httpConf)

}