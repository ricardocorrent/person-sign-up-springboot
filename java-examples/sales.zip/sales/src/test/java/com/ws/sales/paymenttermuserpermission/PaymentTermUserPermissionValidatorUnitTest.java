package com.ws.sales.paymenttermuserpermission;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermUserPermissionValidatorUnitTest {

    private static final UUID CUSTOMER_ID = UUID.randomUUID();

    @InjectMocks
    private PaymentTermUserPermissionValidator paymentTermUserPermissionValidator;

    private List<PaymentTermUserPermission> getListOfPermissionsWithGlobalId() {
        final PaymentTermUserPermission paymentTermUserPermission = new PaymentTermUserPermission();
        paymentTermUserPermission.setUserId(CUSTOMER_ID);
        final List<PaymentTermUserPermission> paymentTermUserPermissions = new LinkedList<>();
        paymentTermUserPermissions.add(paymentTermUserPermission);
        return paymentTermUserPermissions;
    }

    @Test
    public void canUsePermissionBecauseItDoesNotExistsInDatabase() {
        final PaymentTermUserPermission paymentTermUserPermission = new PaymentTermUserPermission();
        paymentTermUserPermission.setUserId(UUID.randomUUID());
        this.paymentTermUserPermissionValidator.doValidatePermission(paymentTermUserPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertTrue(this.paymentTermUserPermissionValidator.getConstraintViolations().isEmpty());
    }

    @Test
    public void canNotUsePermissionBecauseItExistsInDatabase() {
        final PaymentTermUserPermission paymentTermUserPermission = new PaymentTermUserPermission();
        paymentTermUserPermission.setUserId(CUSTOMER_ID);
        this.paymentTermUserPermissionValidator.doValidatePermission(paymentTermUserPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertFalse(this.paymentTermUserPermissionValidator.getConstraintViolations().isEmpty());
    }
}
