import java.util.UUID

import io.gatling.core.Predef._
import io.gatling.core.structure.{ChainBuilder, ScenarioBuilder}
import io.gatling.http.Predef.http
import io.gatling.http.request.ExtraInfo

import scala.util.Random

class Constants {
//  private val isDebug = System.getProperty("debug").toBoolean
  private val repeatTimes: Int = 1

  val sentHeaders = Map(
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
    "Content-Type" -> "application/json; charset=UTF-8",
    "Connection" -> "keep-alive",
    "Pragma" -> "no-cache",
    "Cache-Control" -> "no-cache",
    "Accept-Language" -> "en-US, en; q=0.5"
  )

  val baseURL = "http://dev.sollar.com"

  val httpConf = http
    .baseURL(baseURL)
    .headers(sentHeaders)

  object uuidFeeder {
    val feeder = new Feeder[String] {
      override def hasNext = true

      override def next: Map[String, String] = {
        Map(
          "uuid" -> UUID.randomUUID.toString
        )
      }
    }
  }

  def randomString(qtyChars: Int): String = {
    Random.alphanumeric.take(qtyChars).mkString.toUpperCase
  }

  def randomUUID: String = {
    UUID.randomUUID().toString
  }


  def createScenario(name: String, feed: FeederBuilder[_], chains: ChainBuilder*): ScenarioBuilder = {
    if (repeatTimes > 0) {
      scenario(name).feed(feed).repeat(repeatTimes) {
        exec(chains)
      }
    } else {
      scenario(name).feed(feed).forever() {
        exec(chains)
      }
    }
  }

  private def getExtraInfo(extraInfo: ExtraInfo): String = {
    ", URL: " + extraInfo.request.getUrl +
    "Request: " + extraInfo.request.getStringData +
    "Response: " + extraInfo.response.body.string
  }
}