import io.gatling.app.Gatling
import io.gatling.core.config.GatlingPropertiesBuilder

/**
  * This object simply provides a `main` method that wraps
  * [[io.gatling.app.Gatling]].main, which
  * allows us to do some configuration and setup before
  * Gatling launches.
  */

object GatlingRunner {

  val user = "rodrigo.senger"
  val outputDirectory = "C:\\Users\\"+ user +"\\Desktop\\logs"
  val description = "PaymentTerm API Test Runner"

  def main(args: Array[String]) {

//    val config = PuppetGatlingConfig.initialize()

    // This sets the class for the simulation we want to run.
    val simulationClass = classOf[PaymentTermSimulation].getName
//    val paymentTermRequests = classOf[PaymentTermRequests].getName
//    val requestBuilder = classOf[RequestBuilder].getName
//    val paymentTermScenarios = classOf[PaymentTermScenarios].getName
//    val constants = classOf[Constants].getName

    val props = new GatlingPropertiesBuilder
    props.sourcesDirectory("./src/main/scala")
    props.binariesDirectory("./target/scala-2.11/classes")

    props.simulationClass(simulationClass)
//    props.bodiesDirectory(constants)
//    props.binariesDirectory(paymentTermScenarios)
//    props.binariesDirectory(paymentTermRequests)
//    props.binariesDirectory(requestBuilder)

    props.runDescription(description)
    props.outputDirectoryBaseName(outputDirectory)
    Gatling.fromMap(props.build)

  }
}