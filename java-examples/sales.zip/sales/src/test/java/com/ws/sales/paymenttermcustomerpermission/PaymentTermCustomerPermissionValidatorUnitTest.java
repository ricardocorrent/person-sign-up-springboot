package com.ws.sales.paymenttermcustomerpermission;

import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermissionValidator;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermCustomerPermissionValidatorUnitTest {

    private static final UUID CUSTOMER_ID = UUID.randomUUID();

    @InjectMocks
    private PaymentTermCustomerPermissionValidator paymentTermCustomerPermissionValidator;

    private List<PaymentTermCustomerPermission> getListOfPermissionsWithGlobalId() {
        final PaymentTermCustomerPermission paymentTermCustomerPermission = new PaymentTermCustomerPermission();
        paymentTermCustomerPermission.setCustomerId(CUSTOMER_ID);
        final List<PaymentTermCustomerPermission> paymentTermCustomerPermissions = new LinkedList<>();
        paymentTermCustomerPermissions.add(paymentTermCustomerPermission);
        return paymentTermCustomerPermissions;
    }

    @Test
    public void canUsePermissionBecauseItDoesNotExistsInDatabase() {
        final PaymentTermCustomerPermission paymentTermCustomerPermission = new PaymentTermCustomerPermission();
        paymentTermCustomerPermission.setCustomerId(UUID.randomUUID());
        this.paymentTermCustomerPermissionValidator.doValidatePermission(paymentTermCustomerPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertTrue(this.paymentTermCustomerPermissionValidator.getConstraintViolations().isEmpty());
    }

    @Test
    public void canNotUsePermissionBecauseItExistsInDatabase() {
        final PaymentTermCustomerPermission paymentTermCustomerPermission = new PaymentTermCustomerPermission();
        paymentTermCustomerPermission.setCustomerId(CUSTOMER_ID);
        this.paymentTermCustomerPermissionValidator.doValidatePermission(paymentTermCustomerPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertFalse(this.paymentTermCustomerPermissionValidator.getConstraintViolations().isEmpty());
    }
}
