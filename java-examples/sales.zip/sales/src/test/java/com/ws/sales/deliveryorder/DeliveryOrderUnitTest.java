package com.ws.sales.deliveryorder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;

import javax.persistence.PersistenceException;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.Id;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import com.ws.sales.deliveryorder.dto.DeliveryDTO;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderService;

/**
 * Test all methods of {@link DeliveryOrderResource} and
 * {@link DeliveryOrderService}
 * 
 * @author william.santos
 * @since 2018-09-10
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class DeliveryOrderUnitTest extends BaseUnitTest {

    @Mock
    private DeliveryOrderDAO dao;

    @Mock
    private SalesOrderService orderService;

    @Mock
    private DeliveryOrderValidation validation;

    private DeliveryOrderService service;

    private DeliveryOrderResource resource;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.service = new DeliveryOrderService(this.dao, this.orderService, this.validation);
        this.resource = new DeliveryOrderResource(this.service);
    }

    @Test
    public void insertNewDeliveryWithSuccess() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doAnswer(invocation -> {
            final DeliveryOrder argumentAt = invocation.getArgumentAt(0, DeliveryOrder.class);
            argumentAt.setId(deliveryId);
            return argumentAt;
        }).when(this.dao).insert(delivery);

        final Response response = this.resource.insertDelivery(orderId, delivery);

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_CREATED, response.getStatus());

        Assert.assertNotNull(response.getEntity());
        final Id inserted = (Id) response.getEntity();
        Assert.assertEquals(deliveryId, inserted.getId());

        Assert.assertNotNull(delivery.getSalesOrder());
        Assert.assertEquals(orderId, delivery.getSalesOrder().getId());

        Mockito.verify(this.dao, Mockito.times(1)).beginTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).insert(delivery);
        Mockito.verify(this.dao, Mockito.times(1)).commitTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).endTransaction();
        Mockito.verify(this.orderService, Mockito.times(1)).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).validate(delivery, EValidationType.INSERT);
        Mockito.verify(this.validation, Mockito.times(2)).throwFoundErrors();
    }

    @Test
    public void insertInvalidDeliveryExpectedExpcetion() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doThrow(RuntimeException.class).when(this.dao).insert(delivery);
        Mockito.doThrow(ConstraintViolationException.class).when(this.validation).throwFoundErrors();
        try {
            this.resource.insertDelivery(orderId, delivery);
        } catch (final ConstraintViolationException exception) {
            // Do nothing, because this exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).beginTransaction();
        Mockito.verify(this.dao, Mockito.never()).insert(delivery);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.never()).endTransaction();
        Mockito.verify(this.validation, Mockito.times(1)).throwFoundErrors();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
    }

    @Test
    public void insertValidDeliveryWithExceptionOnPersistence() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doThrow(PersistenceException.class).when(this.dao).insert(delivery);

        try {
            this.resource.insertDelivery(orderId, delivery);
        } catch (final PersistenceException exception) {
            // Do nothing, because this exception is expected
        }
        Assert.assertNotNull(delivery.getSalesOrder());
        Assert.assertEquals(orderId, delivery.getSalesOrder().getId());

        Mockito.verify(this.dao, Mockito.times(1)).beginTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).insert(delivery);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).endTransaction();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).validate(delivery, EValidationType.INSERT);
        Mockito.verify(this.validation, Mockito.times(2)).throwFoundErrors();
    }

    @Test
    public void updateDeliveryWithSuccess() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        final Response response = this.resource.updateDelivery(orderId, deliveryId, delivery);

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Assert.assertNotNull(delivery.getSalesOrder());
        Assert.assertEquals(orderId, delivery.getSalesOrder().getId());
        Assert.assertEquals(deliveryId, delivery.getId());

        Mockito.verify(this.dao, Mockito.times(1)).beginTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).update(delivery);
        Mockito.verify(this.dao, Mockito.times(1)).commitTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).endTransaction();
        Mockito.verify(this.orderService, Mockito.times(1)).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).validate(delivery, EValidationType.UPDATE);
        Mockito.verify(this.validation, Mockito.times(2)).throwFoundErrors();
    }

    @Test
    public void updateInvalidDeliveryExpectedExpcetion() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doThrow(RuntimeException.class).when(this.dao).update(delivery);
        Mockito.doThrow(ConstraintViolationException.class).when(this.validation).throwFoundErrors();
        try {
            this.resource.updateDelivery(orderId, deliveryId, delivery);
        } catch (final ConstraintViolationException exception) {
            // Do nothing, because this exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).beginTransaction();
        Mockito.verify(this.dao, Mockito.never()).update(delivery);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.never()).endTransaction();
        Mockito.verify(this.validation, Mockito.times(1)).throwFoundErrors();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
    }

    @Test
    public void updateValidDeliveryWithExceptionOnPersistence() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doThrow(PersistenceException.class).when(this.dao).update(delivery);

        try {
            this.resource.updateDelivery(orderId, deliveryId, delivery);
        } catch (final PersistenceException exception) {
            // Do nothing, because this exception is expected
        }
        Assert.assertNotNull(delivery.getSalesOrder());
        Assert.assertEquals(orderId, delivery.getSalesOrder().getId());

        Mockito.verify(this.dao, Mockito.times(1)).beginTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).update(delivery);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).endTransaction();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).validate(delivery, EValidationType.UPDATE);
        Mockito.verify(this.validation, Mockito.times(2)).throwFoundErrors();
    }

    @Test
    public void deleteDeliveryWithSuccess() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doAnswer(invocation -> {
            final SalesOrder salesOrder = new SalesOrder();
            salesOrder.setId(orderId);
            delivery.setId(deliveryId);
            delivery.setSalesOrder(salesOrder);
            return new PagedList<>(Arrays.asList(delivery), 1);
        }).when(this.dao).search(Matchers.any());

        final Response response = this.resource.delete(orderId, deliveryId);

        final ArgumentCaptor<DeliveryOrderSearch> captor = ArgumentCaptor.forClass(DeliveryOrderSearch.class);
        Mockito.verify(this.dao).search(captor.capture());
        final DeliveryOrderSearch search = captor.getValue();

        Assert.assertNotNull(search);
        Assert.assertEquals(deliveryId, search.getId());
        Assert.assertEquals(orderId, search.getOrderId());

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Mockito.verify(this.dao, Mockito.times(1)).beginTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).delete(deliveryId);
        Mockito.verify(this.dao, Mockito.times(1)).commitTransaction();
        Mockito.verify(this.dao, Mockito.times(1)).endTransaction();
        Mockito.verify(this.orderService, Mockito.times(1)).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).validate(delivery, EValidationType.DELETE);
        Mockito.verify(this.validation, Mockito.times(2)).throwFoundErrors();
    }

    @Test
    public void deleteNonexistentDeliveryExpectedRegisterNotFound() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doAnswer(invocation -> {
            return new PagedList<>(Collections.emptyList(), 0);
        }).when(this.dao).search(Matchers.any());

        try {
            this.resource.delete(orderId, deliveryId);
        } catch (final RegisterNotFoundException exception) {
            // Do nothing here, this exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).beginTransaction();
        Mockito.verify(this.dao, Mockito.never()).delete(deliveryId);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.never()).endTransaction();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.never()).validate(delivery, EValidationType.DELETE);
        Mockito.verify(this.validation, Mockito.never()).throwFoundErrors();
    }

    @Test
    public void deleteDeliveryCannotBeDeletedExpectedConstraintException() throws Exception {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doAnswer(invocation -> {
            delivery.setId(deliveryId);
            return new PagedList<>(Arrays.asList(delivery), 1);
        }).when(this.dao).search(Matchers.any());

        Mockito.doThrow(ConstraintViolationException.class).when(this.validation).throwFoundErrors();
        try {
            this.resource.delete(orderId, deliveryId);
        } catch (final ConstraintViolationException exception) {
            // Do nothing here, this exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).beginTransaction();
        Mockito.verify(this.dao, Mockito.never()).delete(deliveryId);
        Mockito.verify(this.dao, Mockito.never()).commitTransaction();
        Mockito.verify(this.dao, Mockito.never()).endTransaction();
        Mockito.verify(this.orderService, Mockito.never()).updateOrderTotalValue(orderId);
        Mockito.verify(this.validation, Mockito.times(1)).validateByBeanValidation(delivery, null);
        Mockito.verify(this.validation, Mockito.times(1)).throwFoundErrors();
    }

    @Test
    public void getExistentDeliveryReturnsThem() {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();
        final DeliveryOrder delivery = new DeliveryOrder();

        Mockito.doAnswer(invocation -> {
            final SalesOrder salesOrder = new SalesOrder();
            salesOrder.setId(orderId);
            delivery.setId(deliveryId);
            delivery.setSalesOrder(salesOrder);
            return new PagedList<>(Arrays.asList(delivery), 1);
        }).when(this.dao).search(Matchers.any());

        final Response response = this.resource.getDelivery(orderId, deliveryId);

        final ArgumentCaptor<DeliveryOrderSearch> captor = ArgumentCaptor.forClass(DeliveryOrderSearch.class);
        Mockito.verify(this.dao).search(captor.capture());
        final DeliveryOrderSearch search = captor.getValue();

        Assert.assertNotNull(search);
        Assert.assertEquals(deliveryId, search.getId());
        Assert.assertEquals(orderId, search.getOrderId());

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Assert.assertNotNull(response.getEntity());
        Assert.assertEquals(delivery, response.getEntity());
    }

    @Test(expected = RegisterNotFoundException.class)
    public void getNonexistentDeliveryExpectedRegisterNotFoundException() {
        final UUID orderId = UUID.randomUUID();
        final UUID deliveryId = UUID.randomUUID();

        Mockito.doAnswer(invocation -> {
            return new PagedList<>(Collections.emptyList(), 0);
        }).when(this.dao).search(Matchers.any());

        this.resource.getDelivery(orderId, deliveryId);
    }

    @Test
    public void searchDeliveriesByOrderRetrunsThem() {
        final UUID salesOrderId = UUID.randomUUID();

        final DeliveryOrder delivery = new DeliveryOrder();
        final PagedList<DeliveryOrder> pagedList = new PagedList<>(Arrays.asList(delivery), 1);

        Mockito.doAnswer(invocation -> pagedList).when(this.dao).search(Matchers.any());

        final Response response = this.resource.searchDeliveryByOrder(salesOrderId);

        final ArgumentCaptor<DeliveryOrderSearch> captor = ArgumentCaptor.forClass(DeliveryOrderSearch.class);
        Mockito.verify(this.dao).search(captor.capture());
        final DeliveryOrderSearch search = captor.getValue();

        Assert.assertNotNull(search);
        Assert.assertNull(search.getId());
        Assert.assertEquals(salesOrderId, search.getOrderId());

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Assert.assertNotNull(response.getEntity());
        Assert.assertEquals(pagedList, response.getEntity());
    }

    @Test
    public void searchDeliveriesByOrderReturnEmptyList() {
        final UUID orderId = UUID.randomUUID();
        final PagedList<Object> pagedList = new PagedList<>(Collections.emptyList(), 0);

        Mockito.doAnswer(invocation -> pagedList).when(this.dao).search(Matchers.any());

        final Response response = this.resource.searchDeliveryByOrder(orderId);

        final ArgumentCaptor<DeliveryOrderSearch> captor = ArgumentCaptor.forClass(DeliveryOrderSearch.class);
        Mockito.verify(this.dao).search(captor.capture());
        final DeliveryOrderSearch search = captor.getValue();

        Assert.assertNotNull(search);
        Assert.assertNull(search.getId());
        Assert.assertEquals(orderId, search.getOrderId());

        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Assert.assertNotNull(response.getEntity());
        Assert.assertEquals(pagedList, response.getEntity());
    }

    /**
     * Test mapping to convert {@link DeliveryOrder} to {@link DeliveryDTO}
     */
    @Test
    public void convertToDto() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);
        delivery.setShipmentDate(LocalDate.now());
        delivery.setDeliveryDate(LocalDate.now());
        delivery.setLocationId(UUID.randomUUID());
        delivery.setLocationDescription("Unit-Test");
        delivery.setObservation("Unit-Test");
        delivery.setIncotermsId(UUID.randomUUID());
        delivery.setIncotermsAcronym(IncotermsAcronym.CIF);
        delivery.setFreightValue(BigDecimal.TEN);

        final DeliveryDTO dto = new PojoConverter().convert(DeliveryDTO.class, delivery);
        Assert.assertNotNull(dto);
        Assert.assertEquals(delivery.getId(), dto.getId());

        Assert.assertNotNull(dto.getOrder());
        Assert.assertEquals(order.getId(), dto.getOrder().getId());

        Assert.assertNotNull(dto.getLocation());
        Assert.assertEquals(delivery.getLocationId(), dto.getLocation().getId());
        Assert.assertEquals(delivery.getLocationDescription(), dto.getLocation().getDescription());

        Assert.assertNotNull(dto.getIncoterms());
        Assert.assertEquals(delivery.getIncotermsAcronym(), dto.getIncoterms().getAcronym());

        Assert.assertEquals(delivery.getShipmentDate(), dto.getShipmentDate());
        Assert.assertEquals(delivery.getDeliveryDate(), dto.getDeliveryDate());
        Assert.assertEquals(delivery.getObservation(), dto.getObservation());
        Assert.assertEquals(delivery.getFreightValue(), dto.getFreightValue());
    }
}
