package com.ws.sales.deliveryorder;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.commondata.CommonDataValidation;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.external.customer.CustomerValidation;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderValidator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintViolation;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.0.0 2018-08-18
 * 
 * @author william.santos
 * @since V7.0.0 - 2018-09-10
 * @version 1.1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class DeliveryOrderValidationUnitTest {

    @Mock
    private CustomerValidation customerValidation;

    @Mock
    private CommonDataValidation commonDataValidation;

    @Mock
    private SalesOrderValidator salesOrderValidator;

    @Mock
    private SalesOrderDAO salesOrderDAO;

    @Mock
    private DeliveryOrderDAO deliveryOrderDAO;

    private DeliveryOrderValidation deliveryOrderValidation;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.deliveryOrderValidation = new DeliveryOrderValidation(this.customerValidation, this.commonDataValidation, this.salesOrderValidator, this.salesOrderDAO, this.deliveryOrderDAO);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void deliveryDateIsLowerThanShipmentDate() {
        final LocalDate deliveryDate = LocalDate.now().plusDays(1);
        final LocalDate shipmentDate = LocalDate.now();
        final LogicError error = this.deliveryOrderValidation.doValidateIfDeliveryDateIsLowerThanShipmentDate(deliveryDate, shipmentDate);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void deliveryDateIsEqualToShipmentDate() {
        final LocalDate deliveryDate = LocalDate.now();
        final LocalDate shipmentDate = LocalDate.now();
        final LogicError error = this.deliveryOrderValidation.doValidateIfDeliveryDateIsLowerThanShipmentDate(deliveryDate, shipmentDate);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void deliveryDateIsHigherThanShipmentDate() {
        final LocalDate deliveryDate = LocalDate.now().minusDays(1);
        final LocalDate shipmentDate = LocalDate.now();
        final LogicError error = this.deliveryOrderValidation.doValidateIfDeliveryDateIsLowerThanShipmentDate(deliveryDate, shipmentDate);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void wontValidateBecauseDeliveryDateIsNull() {
        final LocalDate deliveryDate = null;
        final LocalDate shipmentDate = LocalDate.now();
        final LogicError error = this.deliveryOrderValidation.doValidateIfDeliveryDateIsLowerThanShipmentDate(deliveryDate, shipmentDate);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void theOrderHasNoDeliveryYet() {
        final List<DeliveryOrder> deliveryOrders = new LinkedList<>();
        final PagedList<DeliveryOrder> pagedList = new PagedList<>(deliveryOrders, 0);
        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(pagedList);
        final LogicError error = this.deliveryOrderValidation.doValidateIfTheOrderHasADelivery(UUID.randomUUID());
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void theOrderHasADeliveryAlready() {
        final List<DeliveryOrder> deliveryOrders = new LinkedList<>();
        deliveryOrders.add(new DeliveryOrder());
        final PagedList<DeliveryOrder> pagedList = new PagedList<>(deliveryOrders, 1);
        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(pagedList);
        final LogicError error = this.deliveryOrderValidation.doValidateIfTheOrderHasADelivery(UUID.randomUUID());
        Assert.assertNotNull(error);
    }

    @Test
    public void validDeliveryOrderToInsertReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);
        delivery.setShipmentDate(LocalDate.now());
        delivery.setDeliveryDate(LocalDate.now());
        delivery.setLocationId(UUID.randomUUID());
        delivery.setLocationDescription("Unit-Test");
        delivery.setObservation("Unit-Test");
        delivery.setIncotermsId(UUID.randomUUID());
        delivery.setIncotermsAcronym(IncotermsAcronym.CIF);
        delivery.setFreightValue(BigDecimal.TEN);
        delivery.setSalesOrder(order);

        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(null);
        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.customerValidation.doValidateLocationBelongsToCustomer(delivery.getLocationId(), order.getCustomerId())).thenReturn(null);

        this.deliveryOrderValidation.validate(delivery, EValidationType.INSERT);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidDeliveryOrderToInsertReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);
        delivery.setShipmentDate(LocalDate.now());
        delivery.setDeliveryDate(LocalDate.now());
        delivery.setLocationId(UUID.randomUUID());
        delivery.setLocationDescription("Unit-Test");
        delivery.setObservation("Unit-Test");
        delivery.setIncotermsId(UUID.randomUUID());
        delivery.setIncotermsAcronym(IncotermsAcronym.CIF);
        delivery.setFreightValue(BigDecimal.TEN);
        delivery.setSalesOrder(order);

        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(null);
        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.customerValidation.doValidateLocationBelongsToCustomer(delivery.getLocationId(), order.getCustomerId())).thenReturn(new LogicError("location", "location already exists"));

        this.deliveryOrderValidation.validate(delivery, EValidationType.INSERT);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertFalse(violations.isEmpty());
    }

    @Test
    public void validDeliveryOrderToUpdateReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);
        delivery.setShipmentDate(LocalDate.now());
        delivery.setDeliveryDate(LocalDate.now());
        delivery.setLocationId(UUID.randomUUID());
        delivery.setLocationDescription("Unit-Test");
        delivery.setObservation("Unit-Test");
        delivery.setIncotermsId(UUID.randomUUID());
        delivery.setIncotermsAcronym(IncotermsAcronym.CIF);
        delivery.setFreightValue(BigDecimal.TEN);
        delivery.setSalesOrder(order);

        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(null);
        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.customerValidation.doValidateLocationBelongsToCustomer(delivery.getLocationId(), order.getCustomerId())).thenReturn(null);

        this.deliveryOrderValidation.validate(delivery, EValidationType.UPDATE);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidDeliveryOrderToUpdateReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);

        Mockito.when(this.deliveryOrderDAO.search(Matchers.any())).thenReturn(null);
        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.customerValidation.doValidateLocationBelongsToCustomer(delivery.getLocationId(), order.getCustomerId())).thenReturn(new LogicError("location", "location already exists"));

        this.deliveryOrderValidation.validate(delivery, EValidationType.UPDATE);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertFalse(violations.isEmpty());
    }

    @Test
    public void validDeliveryOrderToDeleteReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);

        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.salesOrderValidator.doValidateIfOrderCanBeEdited(order, Boolean.FALSE)).thenReturn(null);

        this.deliveryOrderValidation.validate(delivery, EValidationType.DELETE);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidDeliveryOrderToDeleteReturnsEmptyList() {
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        order.setCustomerId(UUID.randomUUID());

        final DeliveryOrder delivery = new DeliveryOrder();
        delivery.setId(UUID.randomUUID());
        delivery.setSalesOrder(order);

        Mockito.when(this.salesOrderDAO.findById(order.getId())).thenReturn(order);
        Mockito.when(this.salesOrderValidator.doValidateIfOrderCanBeEdited(order, Boolean.FALSE)).thenReturn(new LogicError("order", "order"));

        this.deliveryOrderValidation.validate(delivery, EValidationType.DELETE);
        final Set<ConstraintViolation<BaseModel>> violations = this.deliveryOrderValidation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertFalse(violations.isEmpty());
    }
}
