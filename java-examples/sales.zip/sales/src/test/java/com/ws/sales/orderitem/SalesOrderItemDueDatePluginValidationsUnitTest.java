package com.ws.sales.orderitem;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.product.ProductService;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderBuilder;
import com.ws.sales.orderitem.validations.SalesOrderItemDueDatePluginValidations;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-03
 */
@RunWith(MockitoJUnitRunner.class)
public class SalesOrderItemDueDatePluginValidationsUnitTest {

    @InjectMocks
    private SalesOrderItemDueDatePluginValidations validations;

    @Mock
    private OrderParameterService orderParameterService;

    @Mock
    private ProductService productService;

    /**
     * <p>
     * Mocks a new {@link OrderParameter} with the paramter value
     *
     * @param value to mock the value of the parameter
     */
    private void doMockParameter(final Boolean value) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(value.toString());
        Mockito.when(this.orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    /**
     * <p>
     * Mocks the return of {@link ProductService#getDueDateCoefficient(UUID, LocalDate)} using the
     * parameter's value
     *
     * @param coefficient to mock the value of the parameter
     */
    private void doMockDueDateCoefficient(final BigDecimal coefficient) {
        Mockito.when(this.productService.getDueDateCoefficient(Mockito.any(), Mockito.any())).thenReturn(coefficient);
    }

    /**
     * <p>
     * Returns a {@link SalesOrderItem} with the required fields
     * to perform dueDate tests
     *
     * @param dueDateValue to mock the value of the dueDate in the item
     */
    private SalesOrderItem getItemWithRequiredFieldsToTest(final BigDecimal dueDateValue) {
        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        final SalesOrder salesOrder = SalesOrderBuilder.aSalesOrder().withId(UUID.randomUUID()).build();
        salesOrderItem.setSalesOrder(salesOrder);
        salesOrderItem.setPriceListId(UUID.randomUUID());
        salesOrderItem.setOriginalPrice(BigDecimal.TEN);
        salesOrderItem.setDueDateValue(dueDateValue);
        return salesOrderItem;
    }

    @Test
    public void dueDatePluginIsDisabledAndItemHasDueDateValueSoItsInvalid() {
        this.doMockParameter(Boolean.FALSE);
        this.doMockDueDateCoefficient(BigDecimal.ONE);
        final SalesOrderItem salesOrderItem = this.getItemWithRequiredFieldsToTest(BigDecimal.ZERO);
        final LogicError error = this.validations.doValidateDueDate(salesOrderItem);
        Assert.assertNotNull(error);
    }

    @Test
    public void dueDatePluginIsDisabledAndItemHasNoDueDateValueSoItsValid() {
        this.doMockParameter(Boolean.FALSE);
        this.doMockDueDateCoefficient(BigDecimal.ONE);
        final SalesOrderItem salesOrderItem = this.getItemWithRequiredFieldsToTest(null);
        final LogicError error = this.validations.doValidateDueDate(salesOrderItem);
        Assert.assertNull(error);
    }

    @Test
    public void dueDatePluginIsEnabledAndDueDateValueIsSameSoItsValid() {
        this.doMockParameter(Boolean.TRUE);
        this.doMockDueDateCoefficient(BigDecimal.ONE);
        final SalesOrderItem salesOrderItem = this.getItemWithRequiredFieldsToTest(BigDecimal.ZERO);
        final LogicError error = this.validations.doValidateDueDate(salesOrderItem);
        Assert.assertNull(error);
    }

    @Test
    public void dueDatePluginIsEnabledAndDueDateValueIsDifferentSoItsInvalid() {
        this.doMockParameter(Boolean.TRUE);
        this.doMockDueDateCoefficient(BigDecimal.valueOf(8));
        final SalesOrderItem salesOrderItem = this.getItemWithRequiredFieldsToTest(BigDecimal.ZERO);
        final LogicError error = this.validations.doValidateDueDate(salesOrderItem);
        Assert.assertNotNull(error);
    }

    @Test
    public void wontValidateWithPluginEnabledBecauseParamsAreNull() {
        this.doMockParameter(Boolean.TRUE);
        this.doMockDueDateCoefficient(BigDecimal.valueOf(8));
        final LogicError error = this.validations.doValidateDueDate(null);
        Assert.assertNull(error);
    }

}
