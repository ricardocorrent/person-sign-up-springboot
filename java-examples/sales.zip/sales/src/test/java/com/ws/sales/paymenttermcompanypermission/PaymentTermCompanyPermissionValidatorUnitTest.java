package com.ws.sales.paymenttermcompanypermission;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermCompanyPermissionValidatorUnitTest extends BaseUnitTest {

    private static final UUID CUSTOMER_ID = UUID.randomUUID();

    @InjectMocks
    private PaymentTermCompanyPermissionValidator paymentTermCompanyPermissionValidator;

    private List<PaymentTermCompanyPermission> getListOfPermissionsWithGlobalId() {
        final PaymentTermCompanyPermission paymentTermCompanyPermission = new PaymentTermCompanyPermission();
        paymentTermCompanyPermission.setCompanyId(PaymentTermCompanyPermissionValidatorUnitTest.CUSTOMER_ID);
        final List<PaymentTermCompanyPermission> paymentTermCompanyPermissions = new LinkedList<>();
        paymentTermCompanyPermissions.add(paymentTermCompanyPermission);
        return paymentTermCompanyPermissions;
    }

    @Test
    public void canUsePermissionBecauseItDoesNotExistsInDatabase() {
        final PaymentTermCompanyPermission paymentTermCompanyPermission = new PaymentTermCompanyPermission();
        paymentTermCompanyPermission.setCompanyId(UUID.randomUUID());
        this.paymentTermCompanyPermissionValidator.doValidatePermission(paymentTermCompanyPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertTrue(this.paymentTermCompanyPermissionValidator.getConstraintViolations().isEmpty());
    }

    @Test
    public void canNotUsePermissionBecauseItExistsInDatabase() {
        final PaymentTermCompanyPermission paymentTermCompanyPermission = new PaymentTermCompanyPermission();
        paymentTermCompanyPermission.setCompanyId(PaymentTermCompanyPermissionValidatorUnitTest.CUSTOMER_ID);
        this.paymentTermCompanyPermissionValidator.doValidatePermission(paymentTermCompanyPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertFalse(this.paymentTermCompanyPermissionValidator.getConstraintViolations().isEmpty());
    }
}
