package com.ws.sales.orderitem;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.product.model.ProductPackaging;
import com.ws.sales.external.product.dto.DiscountDTO;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterDAO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrderItemValidatorUnitTest extends BaseUnitTest {

    @InjectMocks
    private SalesOrderItemValidator validator;

    @Mock
    private ProductGateway productGateway;

    @Mock
    private SalesOrderDAO orderDAO;

    @Mock
    private OrderParameterDAO orderParameterDAO;

    @Test
    public void validateProductExists_withProduct() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        assertNull(validator.validateProductExists(item, product));

    }

    @Test
    public void validateProductExists_withoutItemProductId() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();

        assertNull(validator.validateProductExists(item, product));

    }

    @Test
    public void validateProductExists_withoutItem() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        assertNull(validator.validateProductExists(null, product));

    }

    @Test
    public void validateProductExists_withoutProduct() {

        final UUID idProduct = UUID.randomUUID();

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        final LogicError error = validator.validateProductExists(item, null);
        assertNotNull(error);

        assertEquals("product", error.getField());
        assertEquals("order.item.product.notFound", error.getMessageTemplate());

    }

    @Test
    public void validatePriceListExists_withPriceList() {

        final UUID idPriceList = UUID.randomUUID();
        final PriceList priceList = Mockito.mock(PriceList.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceList.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setPriceListId(idPriceList);

        assertNull(validator.validatePriceListExists(item, priceList));

    }

    @Test
    public void validatePriceListExists_withoutItemPriceListId() {

        final UUID idPriceList = UUID.randomUUID();
        final PriceList priceList = Mockito.mock(PriceList.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceList.toString());

        final SalesOrderItem item = new SalesOrderItem();

        assertNull(validator.validatePriceListExists(item, priceList));

    }

    @Test
    public void validatePriceListExists_withoutItem() {

        final UUID idPriceList = UUID.randomUUID();
        final PriceList priceList = Mockito.mock(PriceList.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceList.toString());

        assertNull(validator.validatePriceListExists(null, priceList));

    }

    @Test
    public void validatePriceListExists_withoutPriceList() {

        final UUID idPriceList = UUID.randomUUID();

        final SalesOrderItem item = new SalesOrderItem();
        item.setPriceListId(idPriceList);

        final LogicError error = validator.validatePriceListExists(item, null);
        assertNotNull(error);

        assertEquals("priceList", error.getField());
        assertEquals("order.item.priceList.notFound", error.getMessageTemplate());

    }

    @Test
    public void validatePriceListItemExists_withPriceListItem() {

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setPriceListItemId(idPriceListItem);

        assertNull(validator.validatePriceListItemExists(item, priceList));

    }

    @Test
    public void validatePriceListItemExists_withoutItemPriceListItemId() {

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());

        final SalesOrderItem item = new SalesOrderItem();

        assertNull(validator.validatePriceListItemExists(item, priceList));

    }

    @Test
    public void validatePriceListItemExists_withoutItem() {

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());

        assertNull(validator.validatePriceListItemExists(null, priceList));

    }

    @Test
    public void validatePriceListItemExists_withoutPriceListItem() {

        final UUID idPriceListItem = UUID.randomUUID();

        final SalesOrderItem item = new SalesOrderItem();
        item.setPriceListItemId(idPriceListItem);

        final LogicError error = validator.validatePriceListItemExists(item, null);
        assertNotNull(error);

        assertEquals("priceListItem", error.getField());
        assertEquals("order.item.priceListItem.notFound", error.getMessageTemplate());

    }

    @Test
    public void validateProductBelongsToPriceListItem_withProductInPriceList() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());
        Mockito.when(priceList.getProduct()).thenReturn(product);

        assertNull(validator.validateProductBelongsToPriceListItem(priceList, product));

    }

    @Test
    public void validateProductBelongsToPriceListItem_withoutProduct() {

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());

        assertNull(validator.validateProductBelongsToPriceListItem(priceList, null));

    }

    @Test
    public void validateProductBelongsToPriceListItem_withoutPriceList() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        assertNull(validator.validateProductBelongsToPriceListItem(null, product));

    }

    @Test
    public void validateProductBelongsToPriceListItem_withoutProductInPriceList() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());

        final LogicError error = validator.validateProductBelongsToPriceListItem(priceList, product);
        assertNotNull(error);

        assertEquals("product", error.getField());
        assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());

    }

    @Test
    public void validateProductBelongsToPriceListItem_withAnotherProductInPriceList() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final UUID idProductPriceList = UUID.randomUUID();
        final Product productPriceList = Mockito.mock(Product.class);
        Mockito.when(productPriceList.getId()).thenReturn(idProductPriceList.toString());

        final UUID idPriceListItem = UUID.randomUUID();
        final PriceListItem priceList = Mockito.mock(PriceListItem.class);
        Mockito.when(priceList.getId()).thenReturn(idPriceListItem.toString());
        Mockito.when(priceList.getProduct()).thenReturn(productPriceList);

        final LogicError error = validator.validateProductBelongsToPriceListItem(priceList, product);
        assertNotNull(error);

        assertEquals("product", error.getField());
        assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());

    }

    @Test
    public void validatePackagingBelongsToProduct_withPackagingInProduct() {

        final UUID idPackaging = UUID.randomUUID();
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());
        Mockito.when(product.getPackagings()).thenReturn(Arrays.asList(packaging));

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductPackagingId(idPackaging);

        assertNull(validator.validatePackagingBelongsToProduct(item, product));

    }

    @Test
    public void validatePackagingBelongsToProduct_withoutProduct() {

        final UUID idPackaging = UUID.randomUUID();

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductPackagingId(idPackaging);

        assertNull(validator.validatePackagingBelongsToProduct(item, null));

    }

    @Test
    public void validatePackagingBelongsToProduct_withoutItem() {

        final UUID idPackaging = UUID.randomUUID();
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());
        Mockito.when(product.getPackagings()).thenReturn(Arrays.asList(packaging));

        assertNull(validator.validatePackagingBelongsToProduct(null, product));

    }

    @Test
    public void validatePackagingBelongsToProduct_withItemPackagingId() {

        final UUID idPackaging = UUID.randomUUID();
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());
        Mockito.when(product.getPackagings()).thenReturn(Arrays.asList(packaging));

        final SalesOrderItem item = new SalesOrderItem();

        assertNull(validator.validatePackagingBelongsToProduct(item, product));

    }

    @Test
    public void validatePackagingBelongsToProduct_withoutProductPackagings() {

        final UUID idPackaging = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductPackagingId(idPackaging);

        final LogicError error = validator.validatePackagingBelongsToProduct(item, product);
        assertNotNull(error);

        assertEquals("productPackaging", error.getField());
        assertEquals("order.item.productPackaging.mustBelongsToProduct", error.getMessageTemplate());

    }

    @Test
    public void validatePackagingBelongsToProduct_withProductPackagingsEmpty() {

        final UUID idPackaging = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());
        Mockito.when(product.getPackagings()).thenReturn(new ArrayList<>());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductPackagingId(idPackaging);

        final LogicError error = validator.validatePackagingBelongsToProduct(item, product);
        assertNotNull(error);

        assertEquals("productPackaging", error.getField());
        assertEquals("order.item.productPackaging.mustBelongsToProduct", error.getMessageTemplate());

    }

    @Test
    public void validatePackagingBelongsToProduct_withAnotherPackagingInProduct() {

        final UUID idPackaging = UUID.randomUUID();
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());

        final UUID idProduct = UUID.randomUUID();
        final Product product = Mockito.mock(Product.class);
        Mockito.when(product.getId()).thenReturn(idProduct.toString());
        Mockito.when(product.getPackagings()).thenReturn(Arrays.asList(packaging));

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductPackagingId(UUID.randomUUID());

        final LogicError error = validator.validatePackagingBelongsToProduct(item, product);
        assertNotNull(error);

        assertEquals("productPackaging", error.getField());
        assertEquals("order.item.productPackaging.mustBelongsToProduct", error.getMessageTemplate());

    }

    @Test
    public void validateProductUniqueProductInOrder_withUniqueProduct() {

        final SalesOrder order = new SalesOrder();
        order.setItems(new ArrayList<>());

        final UUID idProduct = UUID.randomUUID();
        final Product product = new Product();
        product.setId(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        assertNull(validator.validateProductUniqueProductInOrder(item, order, product));
    }

    @Test
    public void validateProductUniqueProductInOrder_withoutItem() {

        final SalesOrder order = new SalesOrder();
        order.setItems(new ArrayList<>());

        final UUID idProduct = UUID.randomUUID();
        final Product product = new Product();
        product.setId(idProduct.toString());

        assertNull(validator.validateProductUniqueProductInOrder(null, order, product));
    }

    @Test
    public void validateProductUniqueProductInOrder_withoutOrder() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = new Product();
        product.setId(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        assertNull(validator.validateProductUniqueProductInOrder(item, null, product));
    }

    @Test
    public void validateProductUniqueProductInOrder_withoutProduct() {

        final SalesOrder order = new SalesOrder();
        order.setItems(new ArrayList<>());

        final UUID idProduct = UUID.randomUUID();

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        assertNull(validator.validateProductUniqueProductInOrder(item, order, null));
    }

    @Test
    public void validateProductUniqueProductInOrder_withoutOrderItems() {

        final SalesOrder order = new SalesOrder();
        order.setItems(null);

        final UUID idProduct = UUID.randomUUID();
        final Product product = new Product();
        product.setId(idProduct.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        assertNull(validator.validateProductUniqueProductInOrder(item, order, product));
    }

    @Test
    public void validateProductUniqueProductInOrder_withNotUniqueProduct() {

        final UUID idProduct = UUID.randomUUID();
        final Product product = new Product();
        product.setId(idProduct.toString());

        final SalesOrderItem itemOrder = new SalesOrderItem();
        itemOrder.setId(UUID.randomUUID());
        itemOrder.setProductId(idProduct);

        final SalesOrder order = new SalesOrder();
        order.setItems(Arrays.asList(itemOrder));

        final SalesOrderItem item = new SalesOrderItem();
        item.setProductId(idProduct);

        final LogicError error = validator.validateProductUniqueProductInOrder(item, order, product);
        assertNotNull(error);

        assertEquals("product", error.getField());
        assertEquals("order.item.product.productMustBeUnique", error.getMessageTemplate());
    }

    @Test
    public void validateQuantityOfPacking_withQuantity100AndPack10() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.TEN;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.TEN.multiply(BigDecimal.TEN));

        assertNull(validator.validateQuantityOfPacking(item, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withoutPackaging() {

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.TEN.multiply(BigDecimal.TEN));

        assertNull(validator.validateQuantityOfPacking(item, null));

    }

    @Test
    public void validateMinimumPriceMustBeTrue() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesPrice(BigDecimal.valueOf(5));
        mockParameter(Boolean.TRUE);
        final PriceListItem priceListItem = Mockito.mock(PriceListItem.class);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        Mockito.when(priceListItem.getMinimumPrice()).thenReturn(BigDecimal.ZERO);

        final LogicError error = validator.validateMinimumPrice(item);
        assertNull(error);
    }

    // Mocks the orderParameter with any param and returns true or false
    private void mockParameter(final Boolean returns) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(returns.toString());
        Mockito.when(orderParameterDAO.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    @Test
    public void validateMinimumPriceNull() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesPrice(BigDecimal.valueOf(5));
        mockParameter(Boolean.TRUE);
        final PriceListItem priceListItem = Mockito.mock(PriceListItem.class);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError error = validator.validateMinimumPrice(item);
        assertNull(error);
    }

    @Test
    public void validateSalesPricePriceNull() {
        final SalesOrderItem item = new SalesOrderItem();
        mockParameter(Boolean.TRUE);
        final PriceListItem priceListItem = Mockito.mock(PriceListItem.class);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        Mockito.when(priceListItem.getMinimumPrice()).thenReturn(BigDecimal.ZERO);

        final LogicError error = validator.validateMinimumPrice(item);
        assertNull(error);
    }

    @Test
    public void validateQuantityOfPacking_withoutItem() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.TEN;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        assertNull(validator.validateQuantityOfPacking(null, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withoutPackConversionFactor() {

        final UUID idPackaging = UUID.randomUUID();
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.TEN.multiply(BigDecimal.TEN));

        assertNull(validator.validateQuantityOfPacking(item, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withPackConversionFactorZero() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.ZERO;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.TEN.multiply(BigDecimal.TEN));

        assertNull(validator.validateQuantityOfPacking(item, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withoutQuantity() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.TEN;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        final SalesOrderItem item = new SalesOrderItem();

        assertNull(validator.validateQuantityOfPacking(item, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withQuantityZero() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.TEN;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.ZERO);

        assertNull(validator.validateQuantityOfPacking(item, packaging));

    }

    @Test
    public void validateQuantityOfPacking_withQuantity1AndPack10() {

        final UUID idPackaging = UUID.randomUUID();
        final BigDecimal conversionFactor = BigDecimal.TEN;
        final ProductPackaging packaging = Mockito.mock(ProductPackaging.class);
        Mockito.when(packaging.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packaging.getConversionFactor()).thenReturn(conversionFactor);

        final SalesOrderItem item = new SalesOrderItem();
        item.setQuantity(BigDecimal.ONE);

        final LogicError error = validator.validateQuantityOfPacking(item, packaging);
        assertNotNull(error);

        assertEquals("quantity", error.getField());
        assertEquals("order.item.quantity.inconsistentPack", error.getMessageTemplate());

    }

    @Test
    public void validateOriginalPriceIsEqualsPriceListItem_withSameValues() {
        final PriceListItem priceListItem = new PriceListItem();
        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesPrice(BigDecimal.TEN);
        priceListItem.setSalesPrice(BigDecimal.TEN);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = validator.validateOriginalPriceIsEqualsPriceListItem(item, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    @Test
    public void validateOriginalPriceIsEqualsPriceListItem_withoutPriceListItem() {
        final SalesOrderItem item = new SalesOrderItem();
        final LogicError logicError = validator.validateOriginalPriceIsEqualsPriceListItem(item, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    @Test
    public void validateOriginalPriceIsEqualsPriceListItem_withoutItemOriginalPrice() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setPriceListItemId(UUID.randomUUID());
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setSalesPrice(BigDecimal.ONE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = validator.validateOriginalPriceIsEqualsPriceListItem(item, null);
        Assert.assertNotNull(logicError);
    }

    @Test
    public void validateOriginalPriceIsEqualsPriceListItem_withoutPriceListItemSalesPrice() {

        final BigDecimal salesPrice = BigDecimal.TEN;

        UUID idPriceListItem = UUID.randomUUID();

        SalesOrderItem item = Mockito.mock(SalesOrderItem.class);
        item.setOriginalPrice(salesPrice);

        Mockito.when(item.getPriceListItemId()).thenReturn(idPriceListItem);

        Assert.assertNull(validator.validateOriginalPriceIsEqualsPriceListItem(item, null));
    }

    @Test
    public void validateOriginalPriceIsEqualsPriceListItem_withNotSameValues() {
        final SalesOrderItem item = new SalesOrderItem();
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setSalesPrice(BigDecimal.ONE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);

        final LogicError logicError = validator.validateOriginalPriceIsEqualsPriceListItem(item, BigDecimal.TEN);
        Assert.assertNull(logicError);

    }

    @Test
    public void validateDiscountValue_withSameValues() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(originalPrice.subtract(salesPrice));

        assertNull(validator.validateDiscountValue(item));

    }

    @Test
    public void validateDiscountValue_withoutOriginalPrice() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(originalPrice.subtract(salesPrice));

        assertNull(validator.validateDiscountValue(item));

    }

    @Test
    public void validateDiscountValue_withoutSalesPrice() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setDiscountValue(originalPrice.subtract(salesPrice));

        assertNull(validator.validateDiscountValue(item));

    }

    @Test
    public void validateDiscountValue_withoutDiscountValue() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);

        assertNull(validator.validateDiscountValue(item));

    }

    @Test
    public void validateDiscountValue_withDiscountValueInconsistent() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(originalPrice.add(salesPrice));

        final LogicError error = validator.validateDiscountValue(item);
        assertNotNull(error);

        assertEquals("discountValue", error.getField());
        assertEquals("order.item.discountValue.inconsistent", error.getMessageTemplate());

    }

    @Test
    public void validateDiscountPercentage_withoutItem() {

        assertNull(validator.validateDiscountPercentage(null));

    }

    @Test
    public void validateDiscountPercentage_withSameValues() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountPercentage(originalPrice.subtract(salesPrice).multiply(BigDecimal.TEN));

        assertNull(validator.validateDiscountPercentage(item));

    }

    @Test
    public void validateDiscountValue_withDueDateValueAndNoDiscount() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.valueOf(11);
        final BigDecimal dueDatePrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDueDateValue(dueDatePrice);
        item.setDiscountPercentage(BigDecimal.ZERO);
        item.setDiscountValue(BigDecimal.ZERO);

        assertNull(validator.validateDiscountValue(item));

    }

    @Test
    public void validateDiscountPercentage_withoutOriginalPrice() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesPrice(salesPrice);
        item.setDiscountPercentage(originalPrice.subtract(salesPrice).multiply(BigDecimal.TEN));

        assertNull(validator.validateDiscountPercentage(item));

    }

    @Test
    public void validateDiscountPercentage_withoutSalesPrice() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setDiscountPercentage(originalPrice.subtract(salesPrice).multiply(BigDecimal.TEN));

        assertNull(validator.validateDiscountPercentage(item));

    }

    @Test
    public void validateDiscountPercentage_withoutDiscountPercentage() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);

        assertNull(validator.validateDiscountPercentage(item));

    }

    @Test
    public void validateDiscountPercentage_withDiscountPercentageDifferentButConsistent() {

        final BigDecimal originalPrice = new BigDecimal("15.68");
        final BigDecimal salesPrice = new BigDecimal("0.000001");

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountPercentage(new BigDecimal("99.999996"));

        assertNull(validator.validateDiscountPercentage(item));

    }

    @Test
    public void validateDiscountPercentage_withDiscountPercentageInconsistent() {

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = BigDecimal.ONE;

        final SalesOrderItem item = new SalesOrderItem();
        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountPercentage(originalPrice.add(salesPrice).multiply(BigDecimal.TEN));

        final LogicError error = validator.validateDiscountPercentage(item);
        assertNotNull(error);

        assertEquals("discountPercentage", error.getField());
        assertEquals("order.item.discountPercentage.inconsistent", error.getMessageTemplate());

    }

    @Test
    public void validateDiscountWithPluginValidateDiscountDisabled() {
        mockParameter(Boolean.FALSE);
        assertNull(validator.validateDiscount(new SalesOrderItem()));
    }

    @Test
    public void validateDiscountWithoutDiscountValue() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountPercentage(BigDecimal.TEN);
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountWithoutDiscountPercentage() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountWithProductNotFound() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.TEN);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountWithoutDiscountLimitType() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.TEN);
        final Product product = new Product();
        product.setDiscountLimitType(null);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountWithDiscountLimitTypeFree() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.TEN);
        final Product product = new Product();
        product.setDiscountLimitType("FREE");
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountWithDiscountNotFound() {
        mockParameter(Boolean.TRUE);
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.TEN);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(UUID.randomUUID());
        final Product product = new Product();
        product.setDiscountLimitType("COMP");
        Mockito.when(orderDAO.findById(Mockito.any())).thenReturn(salesOrder);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(new ArrayList<>());
        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscount() {
        mockParameter(Boolean.TRUE);

        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.TEN);

        final Product product = new Product();
        product.setDiscountLimitType("COMP");

        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);

        final DiscountDTO discount = new DiscountDTO();
        discount.setMaximumDiscountValue(BigDecimal.TEN);
        discount.setMaximumDiscountPercentage(BigDecimal.TEN);

        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(Arrays.asList(discount));

        assertNull(validator.validateDiscount(item));
    }

    @Test
    public void validateDiscountInvalidWithDiscountPercentageGreaterThanTheDiscountPercentageRegistred() {
        mockParameter(Boolean.TRUE);

        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.TEN);
        item.setDiscountPercentage(BigDecimal.valueOf(100));

        final Product product = new Product();
        product.setDiscountLimitType("COMP");

        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);

        final DiscountDTO discount = new DiscountDTO();
        discount.setMaximumDiscountValue(BigDecimal.TEN);
        discount.setMaximumDiscountPercentage(BigDecimal.TEN);

        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(Arrays.asList(discount));

        final LogicError error = validator.validateDiscount(item);

        assertEquals("discountPercentage", error.getField());
        assertEquals(discount.getMaximumDiscountPercentage(), error.getParams().get("maximumDiscountPercentage"));
    }

    @Test
    public void validateDiscountInvalidWithDiscountValueGreaterThanTheDiscountValueRegistred() {
        mockParameter(Boolean.TRUE);

        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountValue(BigDecimal.valueOf(100));
        item.setDiscountPercentage(BigDecimal.TEN);

        final Product product = new Product();
        product.setDiscountLimitType("COMP");

        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);

        final DiscountDTO discount = new DiscountDTO();
        discount.setMaximumDiscountValue(BigDecimal.TEN);
        discount.setMaximumDiscountPercentage(BigDecimal.TEN);

        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(Arrays.asList(discount));

        final LogicError error = validator.validateDiscount(item);

        assertEquals("discountValue", error.getField());
        assertEquals("order.item.discountValueInvalid", error.getMessageTemplate());
        assertEquals(discount.getMaximumDiscountValue(), error.getParams().get("maximumDiscountValue"));
    }

    @Test
    public void validateInformedDiscountAndFixedPrice() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setProductDescription("Arroz");
        item.setDiscountPercentage(BigDecimal.TEN);
        item.setDiscountValue(BigDecimal.TEN);

        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(Boolean.TRUE);

        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);

        final LogicError error = validator.validateInformedDiscountAndFixedPrice(item);

        assertEquals("salesPrice", error.getField());
        assertEquals("order.item.discountAndFixedPrice", error.getMessageTemplate());
        assertEquals(item.getProductDescription(), error.getParams().get("productDescription"));
    }

    @Test
    public void validateInformedDiscountAndFixedPriceWithoutDiscount() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountPercentage(null);
        item.setDiscountValue(null);

        assertNull(validator.validateInformedDiscountAndFixedPrice(item));
    }

    @Test
    public void validateInformedDiscountAndFixedPriceWithoutPriceListItem() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountPercentage(BigDecimal.TEN);
        item.setDiscountValue(BigDecimal.TEN);

        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(null);

        assertNull(validator.validateInformedDiscountAndFixedPrice(item));
    }

    @Test
    public void validateInformedDiscountAndFixedPriceWithoutPriceFixed() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountPercentage(BigDecimal.TEN);
        item.setDiscountValue(BigDecimal.TEN);

        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(Boolean.FALSE);

        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);

        assertNull(validator.validateInformedDiscountAndFixedPrice(item));
    }

    @Test
    public void validateInformedDiscountAndFixedPriceWithPriceFixedEqualNull() {
        final SalesOrderItem item = new SalesOrderItem();
        item.setDiscountPercentage(BigDecimal.TEN);
        item.setDiscountValue(BigDecimal.TEN);

        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(null);

        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);

        assertNull(validator.validateInformedDiscountAndFixedPrice(item));
    }

    @Test
    public void validatePriceListCanBeUsed() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullProduct() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(null);
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullPriceList() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(null);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullProfessional() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(null);
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullCompany() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(null);
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullLocation() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(null);
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithNullPaymentTerm() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(null);

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

        assertNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

    @Test
    public void validatePriceListCanBeUsedWithInvalidData() {

        final SalesOrderItem salesOrderItem = new SalesOrderItem();
        salesOrderItem.setProductId(UUID.randomUUID());
        salesOrderItem.setPriceListId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(productGateway.priceListCanBeUsed(Mockito.any(), Mockito.any())).thenReturn(Boolean.FALSE);

        assertNotNull(validator.validatePriceListCanBeUsed(salesOrderItem, salesOrder));
    }

}
