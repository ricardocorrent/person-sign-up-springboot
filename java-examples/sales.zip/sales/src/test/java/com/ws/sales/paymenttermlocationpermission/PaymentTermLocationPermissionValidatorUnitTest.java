package com.ws.sales.paymenttermlocationpermission;

import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermissionValidator;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v6.2.0 2018-09-04
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermLocationPermissionValidatorUnitTest {

    private static final UUID CUSTOMER_ID = UUID.randomUUID();

    @InjectMocks
    private PaymentTermLocationPermissionValidator paymentTermLocationPermissionValidator;

    private List<PaymentTermLocationPermission> getListOfPermissionsWithGlobalId() {
        final PaymentTermLocationPermission paymentTermLocationPermission = new PaymentTermLocationPermission();
        paymentTermLocationPermission.setLocationId(CUSTOMER_ID);
        final List<PaymentTermLocationPermission> paymentTermLocationPermissions = new LinkedList<>();
        paymentTermLocationPermissions.add(paymentTermLocationPermission);
        return paymentTermLocationPermissions;
    }

    @Test
    public void canUsePermissionBecauseItDoesNotExistsInDatabase() {
        final PaymentTermLocationPermission paymentTermLocationPermission = new PaymentTermLocationPermission();
        paymentTermLocationPermission.setLocationId(UUID.randomUUID());
        this.paymentTermLocationPermissionValidator.doValidatePermission(paymentTermLocationPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertTrue(this.paymentTermLocationPermissionValidator.getConstraintViolations().isEmpty());
    }

    @Test
    public void canNotUsePermissionBecauseItExistsInDatabase() {
        final PaymentTermLocationPermission paymentTermLocationPermission = new PaymentTermLocationPermission();
        paymentTermLocationPermission.setLocationId(CUSTOMER_ID);
        this.paymentTermLocationPermissionValidator.doValidatePermission(paymentTermLocationPermission, "1", this.getListOfPermissionsWithGlobalId());
        Assert.assertFalse(this.paymentTermLocationPermissionValidator.getConstraintViolations().isEmpty());
    }
}
