import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.util.Random

class ProductRequests extends Simulation {

  def randomString(qtyChars: Int): String = {
    "API TEST" + Random.alphanumeric.take(qtyChars).mkString.toUpperCase
  }

  object Product {

      val postProduct =
        exec(
          http("post_product")
            .post("/api/v1/product/products")
            .body(StringBody(
                  """ {
                  "version" : 1,
                  "createdAt" : "2017-01-03T14:30:50Z",
                  "updatedAt" : "2017-02-02T11:08:51Z",
                  "suppliers" : [ ],
                  "measurementUnitId" : "cea0dea7-112e-4b0a-85af-8fd852b07845",
                  "measurementUnitAcronym" : "lt",
                  "measurementUnitDescription" : "Liter",
                  "active" : false,
                  "description" : "API TEST PRODUCT",
                  "code" : "${code}",
                  "saleAvailable" : true,
                  "saleFractioned" : false,
                  "inventories" : [ ],
                  "packagings" : [ ],
                  "images" : [ ],
                  "productUsers" : [ ],
                  "companies" : [ ],
                  "permissions" : [ ]
                }
                """)).asJSON
            .check(status.is(200))
      )
  }

  object PriceList {

    val postPriceList =
      exec(
        http("post_price_list")
        .post("/api/v1/product/price-lists")
        .body(StringBody(
          """

          """)).asJSON

      )

    val getPriceList =
      exec(
        http("search_price_lists")
          .post("/api/v1/product/price-lists/search?select=id,description,paymentMethods,paymentTerms,currencyAcronym")
          .body(StringBody(
            """
              {"active":[true],"orderTest":true,"actual":true,"customerId":"b158c63c-bbe0-4569-a43a-47f3557f6ef7","userId":null,"companyId":null,"select":"id,description,paymentMethods,paymentTerms,currencyAcronym"}"""))
          .asJSON
          .check(status.is(200))
      )

    val getPriceListItems =
      exec(
        http("get_price_list_item")
          .post("/api/v1/product/price-lists/0f93b541-5b74-40c5-b90b-cd446f705f5e/items")
          .body(StringBody(
            """{"productActive":[true],"customerId":"54091067-4fb0-4c40-9874-8301d18acb76","companyId":"a87cee94-ca43-4291-aba0-18e896bb8aeb","userId":"7636f630-2358-4cf4-a290-2ec0b13ea47c","page":0,"pageSize":5000}"""))
          .asJSON
          .check(status.is(200))
      )


  }

}
