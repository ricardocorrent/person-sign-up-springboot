package com.ws.sales.orderinstalment;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.testng.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RunWith(MockitoJUnitRunner.class)
public class OrderInstalmentLogicUnitTest extends BaseUnitTest {

    @InjectMocks
    private SalesOrderInstalmentLogic salesOrderInstalmentLogic;

    @Mock
    private SalesOrderInstalmentDAO salesOrderInstalmentDAO;

    @Mock
    private SalesOrderDAO salesOrderDAO;

    @Mock
    private PaymentTermDAO paymentTermDAO;

    @Test
    public void canGenerateInstalments() {
        final int SCALE_INSTALMENTS = 6;
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = new SalesOrderInstalmentGenerate();
        salesOrderInstalmentGenerate.setDaysBetween(30);
        salesOrderInstalmentGenerate.setQuantity(10);

        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(BigDecimal.TEN);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setCreatedAt(OffsetDateTime.now());
        salesOrder.setPaymentTermId(paymentTerm.getId());
        salesOrder.setNetValue(BigDecimal.valueOf(100));
        salesOrder.setDraft(true);

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrder);
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(paymentTerm);

        final List<SalesOrderInstalment> salesOrderInstalments = salesOrderInstalmentLogic.calculateInstalments(salesOrderInstalmentGenerate, salesOrder.getId());

        Assert.assertEquals(salesOrderInstalments.size(), 10);
        Assert.assertEquals(salesOrderInstalments.get(0).getNumber(), Integer.valueOf(1));
        Assert.assertEquals(salesOrderInstalments.get(0).getValue(), BigDecimal.TEN.setScale(SCALE_INSTALMENTS, RoundingMode.HALF_EVEN));
        Assert.assertEquals(salesOrderInstalments.get(0).getDueDate(), LocalDate.now().plusDays(salesOrderInstalmentGenerate.getDaysBetween()));
        Assert.assertEquals(salesOrderInstalments.get(9).getNumber(), Integer.valueOf(10));
        Assert.assertEquals(salesOrderInstalments.get(9).getValue(), BigDecimal.TEN.setScale(SCALE_INSTALMENTS, RoundingMode.HALF_EVEN));
        Assert.assertEquals(salesOrderInstalments.get(9).getDueDate(), LocalDate.now().plusDays(salesOrderInstalmentGenerate.getDaysBetween() * 10));

    }


    @Test
    public void canUpdateInstalmentValue() {
        final int SCALE_INSTALMENTS = 6;
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = new SalesOrderInstalmentGenerate();
        salesOrderInstalmentGenerate.setDaysBetween(30);
        salesOrderInstalmentGenerate.setQuantity(5);

        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(BigDecimal.TEN);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setCreatedAt(OffsetDateTime.now());
        salesOrder.setNetValue(BigDecimal.valueOf(100));
        salesOrder.setDraft(true);

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrder);
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(paymentTerm);

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();

        final List<SalesOrderInstalment> salesOrderInstalments
                = salesOrderInstalmentLogic.calculateInstalments(salesOrderInstalmentGenerate, salesOrder.getId())
                .stream()
                .peek(entity -> entity.setId(UUID.randomUUID()))
                .collect(Collectors.toList());

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);

        final SalesOrderInstalment instalmentToUpdate = new SalesOrderInstalment();
        final SalesOrderInstalment instalmentMock = salesOrderInstalments.get(1);

        instalmentToUpdate.setValue(BigDecimal.valueOf(50));
        instalmentToUpdate.setId(instalmentMock.getId());
        instalmentToUpdate.setDueDate(instalmentMock.getDueDate());

        Mockito.when(salesOrderInstalmentDAO.findById(Mockito.any())).thenReturn(instalmentMock);

        final List<SalesOrderInstalment> instalmentsForTest =
                salesOrderInstalmentLogic.editInstalment(instalmentToUpdate, salesOrder.getId());

        Assert.assertEquals(instalmentsForTest.stream()
                .map(SalesOrderInstalment::getValue)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO), BigDecimal.valueOf(100.00).setScale(SCALE_INSTALMENTS));
        Assert.assertEquals(salesOrderInstalments.get(0).getValue(), BigDecimal.valueOf(20).setScale(SCALE_INSTALMENTS));
        Assert.assertEquals(salesOrderInstalments.get(1).getValue(), BigDecimal.valueOf(50));
        Assert.assertEquals(salesOrderInstalments.get(4).getValue(), BigDecimal.valueOf(10).setScale(SCALE_INSTALMENTS));
        Assert.assertEquals(salesOrderInstalments.size(), 5);

    }

    @Test
    public void canUpdateLastInstalmentValue() {
        final int SCALE_INSTALMENTS = 6;
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = new SalesOrderInstalmentGenerate();
        salesOrderInstalmentGenerate.setDaysBetween(30);
        salesOrderInstalmentGenerate.setQuantity(5);

        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(BigDecimal.TEN);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setCreatedAt(OffsetDateTime.now());
        salesOrder.setNetValue(BigDecimal.valueOf(100));
        salesOrder.setDraft(true);

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrder);
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(paymentTerm);

        final PagedList<SalesOrderInstalment> pagedList = new PagedList<>();

        final List<SalesOrderInstalment> salesOrderInstalments
                = salesOrderInstalmentLogic.calculateInstalments(salesOrderInstalmentGenerate, salesOrder.getId())
                .stream()
                .peek(entity -> entity.setId(UUID.randomUUID()))
                .collect(Collectors.toList());

        pagedList.setItems(salesOrderInstalments);

        Mockito.when(salesOrderInstalmentDAO.search(Mockito.any())).thenReturn(pagedList);

        final SalesOrderInstalment instalmentToUpdate = new SalesOrderInstalment();
        final SalesOrderInstalment instalmentMock = salesOrderInstalments.get(4);

        instalmentToUpdate.setValue(BigDecimal.valueOf(50));
        instalmentToUpdate.setId(instalmentMock.getId());
        instalmentToUpdate.setDueDate(instalmentMock.getDueDate());

        Mockito.when(salesOrderInstalmentDAO.findById(Mockito.any())).thenReturn(instalmentMock);

        final List<SalesOrderInstalment> instalmentsForTest =
                salesOrderInstalmentLogic.editInstalment(instalmentToUpdate, salesOrder.getId());

        Assert.assertEquals(instalmentsForTest.stream()
                .map(SalesOrderInstalment::getValue)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO), BigDecimal.valueOf(100.00).setScale(SCALE_INSTALMENTS));
        Assert.assertEquals(salesOrderInstalments.get(0).getValue(), BigDecimal.valueOf(12.5).setScale(SCALE_INSTALMENTS));
        Assert.assertEquals(salesOrderInstalments.get(4).getValue(), BigDecimal.valueOf(50));
        Assert.assertEquals(salesOrderInstalments.size(), 5);

    }

}


