import io.gatling.core.Predef._
import io.gatling.http.Predef._

class ServiceRequests extends Simulation {

  object Service {

    val postService =
      exec(
         http("post_service")
        .post("/api/v1/service/services")
        .body(StringBody("""
             {
                "createdAt" : "2017-04-18T11:45:37.043Z",
                "updatedAt" : "2017-04-18T11:45:37.043Z",
                "customerId" : "${uuid}",
                "customerName" : "LOAD TEST",
                "customerCustomerSince" : "2017-01-25",
                "customerImageId" : "${uuid}",
                "locationCentralPointMappingId" : "${uuid}",
                "locationId" : "${uuid}",
                "locationDescription" : "Aethan 515",
                "locationTotalLocations" : 1,
                "usersIdResponsible" : "${uuid}",
                "usersResponsibleName" : "Administrador",
                "serviceType" : {
                  "id" : "95ba1b4a-653d-4ba7-926c-882310c74303",
                  "createdAt" : "2017-03-18T14:29:33.840Z",
                  "updatedAt" : "2017-03-18T14:29:33.840Z",
                  "description" : "Via email",
                  "active" : true,
                  "authenticationType" : {
                    "id" : "2440849c-1170-488a-ae9b-c9f07ad76d1b",
                    "version" : 1,
                    "createdAt" : "2017-03-18T14:28:54.160816Z",
                    "updatedAt" : "2017-03-18T14:28:54.160816Z",
                    "description" : "No validations",
                    "acronym" : "NO_VAL"
                  }
                },
                "certificate" : false,
                "serviceStatus" : "EXECUTION",
                "justifications" : [ ],
                "serviceTime" : [ {
                  "id" : "${uuid}",
                  "createdAt" : "2017-04-18T11:45:37.044Z",
                  "updatedAt" : "2017-04-18T11:45:37.044Z",
                  "startDate" : "2017-04-18T11:36:31.334Z",
                  "endDate" : "2017-04-18T11:37:48.797Z",
                  "diffSeconds" : 77
                } ],
                "serviceUsers" : [ ],
                "serviceContacts" : [ ],
                "serviceImages" : [ ],
                "serviceAuthentications" : [ ]
              } """)).asJSON
        .check(status.is(201))
      )

    val getService =
      exec(
        http("search_services")
        .post("/api/v1/service/services/search")
         .body(StringBody(""" {"usersIdResponsible":"7636f630-2358-4cf4-a290-2ec0b13ea47c","serviceStatus":["EXECUTION"]} """)).asJSON
        .check(status.is(200))
      )
  }

}