package com.ws.sales.order.SalesOrderTest;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertNull;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.financial.model.CreditLimit;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.user.UserGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderBuilder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderHeaderValidator;
import com.ws.sales.order.SalesOrderValidator;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.ordertype.OrderTypeDAO;
import com.ws.sales.ordertype.OrderTypeService;
import com.ws.sales.paymentmethod.PaymentMethodDAO;
import com.ws.sales.paymentmethod.PaymentMethodService;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;
import com.ws.sales.paymentterm.PaymentTermService;
import com.ws.sales.situation.SituationDAO;
import com.ws.user.model.Hierarchy;
import com.ws.user.model.User;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SimpleSession;
import org.apache.shiro.subject.Subject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.testng.Assert;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrderUnitTest extends BaseUnitTest {

    @Mock
    private ProductGateway productGateway;

    @Mock
    private SituationDAO situationDAO;

    @Mock
    private PaymentMethodDAO paymentMethodDAO;

    @Mock
    private PaymentTermDAO paymentTermDAO;

    @Mock
    private OrderParameterDAO orderParameterDAO;

    @Mock
    private UserGateway userGateway;

    @Mock
    private CustomerGateway customerGateway;

    @Mock
    private AdministrationGateway administrationGateway;

    @Mock
    private OrderTypeDAO orderTypeDAO;

    @Mock
    private OrderTypeService orderTypeService;

    @Mock
    private PaymentTermService paymentTermService;

    @Mock
    private PaymentMethodService paymentMethodService;

    @Mock
    private SalesOrderDAO salesOrderDAO;

    @Mock
    private UserContext userContext;

    @InjectMocks
    private SalesOrderHeaderValidator headerValidator;

    @InjectMocks
    private SalesOrderValidator validator;

    private Subject subject;

    // Mocks the orderParameter with any param and returns true or false
    private void mockParameter(final Boolean returns) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(returns.toString());
        Mockito.when(orderParameterDAO.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    @Test
    public void dueDateIsAfterTodaySoItsValid() {
        final SalesOrder salesOrder = SalesOrderBuilder.aSalesOrder().withDueDate(LocalDate.now().plusDays(1)).build();
        final LogicError error = this.validator.doValidateIfDueDateIsBeforeToday(salesOrder);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    @Test
    public void dueDateIsTodaySoItsValid() {
        final SalesOrder salesOrder = SalesOrderBuilder.aSalesOrder().withDueDate(LocalDate.now()).build();
        final LogicError error = this.validator.doValidateIfDueDateIsBeforeToday(salesOrder);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    @Test
    public void dueDateIsYesterdaySoItsNotValid() {
        final SalesOrder salesOrder = SalesOrderBuilder.aSalesOrder().withDueDate(LocalDate.now().minusDays(1)).build();
        final LogicError error = this.validator.doValidateIfDueDateIsBeforeToday(salesOrder);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    @Test
    public void wontValidateDueDateBecauseDateIsNull() {
        final SalesOrder salesOrder = SalesOrderBuilder.aSalesOrder().withDueDate(null).build();
        final LogicError error = this.validator.doValidateIfDueDateIsBeforeToday(salesOrder);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-03
     */
    @Test
    public void wontValidateDueDateBecauseOrderIsNull() {
        final LogicError error = this.validator.doValidateIfDueDateIsBeforeToday(null);
        Assert.assertNull(error);
    }

    @Test
    public void validateUserIsSameAsUserLogged_withUserLogged() {
        final UUID idUserLogged = UUID.randomUUID();

        SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Mockito.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutSession() {
        final UUID idUserLogged = UUID.randomUUID();

        Mockito.when(userContext.getSession()).thenReturn(null);

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutIdLoggedUser() {
        final UUID idUserLogged = UUID.randomUUID();

        SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutIdUserOrder() {
        final UUID idUserLogged = UUID.randomUUID();

        SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Mockito.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(null);

        assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withAnotherUserLogged() {
        final UUID idUserLogged = UUID.randomUUID();
        final UUID idUser = UUID.randomUUID();

        SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Mockito.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUser);

        final LogicError error = headerValidator.validateUserIsSameAsUserLogged(order);

        assertNotNull(error);
        assertEquals("user", error.getField());
        assertEquals("order.user.userIsNotLogged", error.getMessageTemplate());
    }

    @Test
    public void validateCurrencyPluginEnabled() {
        this.mockParameter(Boolean.TRUE);
        final String currency = "BRL";
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(currency);
        assertNull(headerValidator.validateCurrencyPlugin(salesOrder));
    }

    @Test
    public void validateCurrencyPluginDisabledWithoutCurrency() {
        mockParameter(Boolean.FALSE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(null);
        assertNull(headerValidator.validateCurrencyPlugin(salesOrder));
    }

    @Test
    public void validateCurrencyPluginDisabledWithCurrency() {
        mockParameter(Boolean.FALSE);
        final String currency = "BRL";
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(currency);
        final LogicError error = headerValidator.validateCurrencyPlugin(salesOrder);
        assertNotNull(error);
        assertEquals("salesOrder", error.getField());
        assertEquals("order.item.currencyPluginDisabled", error.getMessageTemplate());
    }

    @Test
    public void validateSituationExists() {
        final UUID situationId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSituationId(situationId);
        Mockito.when(situationDAO.situationExists(situationId)).thenReturn(Boolean.TRUE);
        assertNull(headerValidator.validateSituationExists(salesOrder));
    }

    @Test
    public void validateSituationExistsWithoutSituationId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateSituationExists(salesOrder));
    }

    @Test
    public void validateSituationNotExists() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSituationId(UUID.randomUUID());

        final LogicError error = headerValidator.validateSituationExists(salesOrder);

        assertEquals("situationId", error.getField());
        assertEquals("order.situation.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentMethodExists() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        Mockito.when(paymentMethodDAO.paymentMethodExists(paymentMethodId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePaymentMethodExists(salesOrder));
    }

    @Test
    public void validatePaymentMethodExistsWithoutPaymentMethodId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePaymentMethodExists(salesOrder));
    }

    @Test
    public void validatePaymentMethodNotExists() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        final LogicError error = headerValidator.validatePaymentMethodExists(salesOrder);

        assertEquals("paymentMethod", error.getField());
        assertEquals("order.paymentMethod.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentTermExists() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        Mockito.when(paymentTermDAO.paymentTermExists(paymentTermId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePaymentTermExists(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermBlocked() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(10));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(paymentTerm);
        assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermBlockedAndError() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());

        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(paymentTerm);

        assertNotNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermNull() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        mockParameter(Boolean.TRUE);
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(null);
        assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermOpen() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(true);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(null);
        assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithOrderNull() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(true);
        paymentTerm.setMiddleTerm(10);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        mockParameter(Boolean.TRUE);
        Mockito.when(paymentTermDAO.findById(Mockito.any())).thenReturn(null);
        assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(null));
    }

    @Test
    public void validateDueDateWithOlderThanNowDate() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().minusDays(20));
        assertNotNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDateWithNowDate() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        assertNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDateWithConfigurationFalse() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        assertNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDatePaymentTermWithConfigurationFalse() {
        mockParameter(Boolean.FALSE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithConfOff() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        assertNotNull(headerValidator.validateDueDateWithConfOff(salesOrder, Boolean.FALSE));
    }

    @Test
    public void validateDueDateWithConfOn() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        assertNull(headerValidator.validateDueDateWithConfOff(salesOrder, Boolean.TRUE));
    }

    @Test
    public void validatePaymentTermExistsWithoutPaymentTermId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePaymentTermExists(salesOrder));
    }

    @Test
    public void validatePaymentTermNotExists() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        final LogicError error = headerValidator.validatePaymentTermExists(salesOrder);

        assertEquals("paymentTermId", error.getField());
        assertEquals("order.paymentTerm.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyExists() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        Mockito.when(administrationGateway.companyExists(companyId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateCompanyExists(salesOrder));
    }

    @Test
    public void validateCompanyExistsWithoutCompanyId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateCompanyExists(salesOrder));
    }

    @Test
    public void validateCompanyNotExists() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        final LogicError error = headerValidator.validateCompanyExists(salesOrder);

        assertEquals("companyId", error.getField());
        assertEquals("order.company.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateOrderTypeExists() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        Mockito.when(orderTypeDAO.orderTypeExists(orderTypeId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateOrderTypeExists(salesOrder));
    }

    @Test
    public void validateOrderTypeExistsWithoutOrderTyprId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateOrderTypeExists(salesOrder));
    }

    @Test
    public void validateOrderTypeNotExists() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        final LogicError error = headerValidator.validateOrderTypeExists(salesOrder);

        assertEquals("orderTypeId", error.getField());
        assertEquals("order.orderType.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePriceListExists() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        Mockito.when(productGateway.priceListExists(priceListId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePriceListExists(salesOrder));
    }

    @Test
    public void validatePriceListExistsWithoutPriceListId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePriceListExists(salesOrder));
    }

    @Test
    public void validatePriceListNotExists() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        final LogicError error = headerValidator.validatePriceListExists(salesOrder);

        assertEquals("priceListId", error.getField());
        assertEquals("order.priceList.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateLocationExists() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        Mockito.when(customerGateway.locationExists(locationId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateLocationExists(salesOrder));
    }

    @Test
    public void validateLocationExistsWithoutLocationId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateLocationExists(salesOrder));
    }

    @Test
    public void validateLocationNotExists() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        final LogicError error = headerValidator.validateLocationExists(salesOrder);

        assertEquals("customerLocation", error.getField());
        assertEquals("order.location.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCustomerExists() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        Mockito.when(customerGateway.customerExists(customerId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateCustomerExists(salesOrder));
    }

    @Test
    public void validateCustomerExistsWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateCustomerExists(salesOrder));
    }

    @Test
    public void validateCustomerNotExists() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        final LogicError error = headerValidator.validateCustomerExists(salesOrder);

        assertEquals("customerId", error.getField());
        assertEquals("order.customer.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateUserExists() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        Mockito.when(userGateway.userExists(userId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateUserExists(salesOrder));
    }

    @Test
    public void validateUserExistsWithoutUserId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateUserExists(salesOrder));
    }

    @Test
    public void validateUserNotExists() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        final LogicError error = headerValidator.validateUserExists(salesOrder);

        assertEquals("userId", error.getField());
        assertEquals("order.user.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyIsActive() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        Mockito.when(administrationGateway.companyIsActive(companyId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateCompanyIsActive(salesOrder));
    }

    @Test
    public void validateCompanyInactive() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        final LogicError error = headerValidator.validateCompanyIsActive(salesOrder);

        assertEquals("companyId", error.getField());
        assertEquals("order.company.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyIsActiveWithoutCompanyId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateCompanyIsActive(salesOrder));
    }

    @Test
    public void validatePaymentTermIsActive() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        Mockito.when(paymentTermService.paymentTermIsActive(paymentTermId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePaymentTermIsActive(salesOrder));
    }

    @Test
    public void validatePaymentTermInactive() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        final LogicError error = headerValidator.validatePaymentTermIsActive(salesOrder);

        assertEquals("paymentTermId", error.getField());
        assertEquals("order.paymentTerm.inactive", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentTermIsActiveWithoutPaymentTermId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePaymentTermIsActive(salesOrder));
    }

    @Test
    public void validatePaymentMethodIsActive() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentMethodId);

        Mockito.when(paymentMethodService.paymentMethodIsActive(paymentMethodId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePaymentMethodIsActive(salesOrder));
    }

    @Test
    public void validatePaymentMethodInactive() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        final LogicError error = headerValidator.validatePaymentMethodIsActive(salesOrder);

        assertEquals("paymentMethodId", error.getField());
        assertEquals("order.paymentMethod.inactive", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentMethodIsActiveWithoutPaymentMethodId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePaymentMethodIsActive(salesOrder));
    }

    @Test
    public void validatePriceListIsActive() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        Mockito.when(productGateway.priceListIsActive(priceListId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validatePriceListIsActive(salesOrder));
    }

    @Test
    public void validatePriceListIsActiveWithoutPriceListId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validatePriceListIsActive(salesOrder));
    }

    @Test
    public void validatePriceListInactive() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        final LogicError error = headerValidator.validatePriceListIsActive(salesOrder);

        assertEquals("priceListId", error.getField());
        assertEquals("order.priceList.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateUserIsActive() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        Mockito.when(userGateway.userIsActive(userId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateUserIsActive(salesOrder));
    }

    @Test
    public void validateUserIsActiveWithoutUserId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateUserIsActive(salesOrder));
    }

    @Test
    public void validateUserInactive() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        final LogicError error = headerValidator.validateUserIsActive(salesOrder);

        assertEquals("userId", error.getField());
        assertEquals("order.user.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateCustomerIsActive() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        Mockito.when(customerGateway.customerIsActive(customerId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateCustomerIsActive(salesOrder));
    }

    @Test
    public void validateCustomerIsActiveWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateCustomerIsActive(salesOrder));
    }

    @Test
    public void validateCustomerInactive() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        final LogicError error = headerValidator.validateCustomerIsActive(salesOrder);

        assertEquals("customerId", error.getField());
        assertEquals("order.customer.inactive", error.getMessageTemplate());
    }

    @Test
    public void customerLocationIsActive() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        Mockito.when(customerGateway.locationIsActive(locationId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateCustomerLocationIsActive(salesOrder));
    }

    @Test
    public void customerLocationIsActiveWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateCustomerLocationIsActive(salesOrder));
    }

    @Test
    public void customerLocationInactive() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        final LogicError error = headerValidator.validateCustomerLocationIsActive(salesOrder);

        assertEquals("customerLocation", error.getField());
        assertEquals("order.location.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateOrderTypeIsActive() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        Mockito.when(orderTypeService.orderTypeIsActive(orderTypeId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateOrderTypeIsActive(salesOrder));
    }

    @Test
    public void validateOrderTypeIsActiveWithoutOrderTypeId() {
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(headerValidator.validateOrderTypeIsActive(salesOrder));
    }

    @Test
    public void validateOrderTypeInactive() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        final LogicError error = headerValidator.validateOrderTypeIsActive(salesOrder);

        assertEquals("orderTypeId", error.getField());
        assertEquals("order.orderType.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateSalesOrderWithProductPresentInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        assertNull(validator.validateProductsInPriceList(salesOrder));
    }

    @Test
    public void validateSalesOrderWithProductNotPresentInPriceList() {
        final UUID productIdPriceList = UUID.randomUUID();
        final UUID productIdSalesOrder = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productIdPriceList.toString());
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productIdSalesOrder);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsInPriceList(salesOrder);

        assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());
    }

    @Test
    public void validateSalesOrderWithEmptyPriceList() {
        final List<PriceListItem> itemsPriceList = new ArrayList<>();

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsInPriceList(salesOrder);

        assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());
    }

    @Test
    public void validateProductActiveInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        productPriceList.setActive(Boolean.TRUE);
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductActiveInPriceListWithSalesOrderWithoutItems() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setItems(null);

        assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductActiveInPriceListWithoutPriceList() {
        final SalesOrderItem itemSalesOrder = new SalesOrderItem();
        itemSalesOrder.setProductId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(null);
        salesOrder.setItems(Arrays.asList(itemSalesOrder));

        assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductInactiveInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        productPriceList.setActive(Boolean.FALSE);
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsActiveInPriceList(salesOrder);

        assertEquals("order.itemInactiveInPriceList", error.getMessageTemplate());
    }

    @Test
    public void validateLocationBelongsToUser() {
        final UUID customerId = UUID.randomUUID();
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);
        salesOrder.setLocationId(locationId);

        Mockito.when(customerGateway.locationBelongsToCustomer(locationId, customerId)).thenReturn(Boolean.TRUE);

        assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationBelongsToUserWithCustomerIdAndWithoutLocationId() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationBelongsToUserWithoutCustomerIdAndWithLocationId() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationDoesNotBelongsToUser() {
        final UUID customerId = UUID.randomUUID();
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);
        salesOrder.setLocationId(locationId);

        final LogicError error = headerValidator.validateLocationBelongsToCustomer(salesOrder);

        assertEquals("customerLocation", error.getField());
        assertEquals("order.location.notbelongs", error.getMessageTemplate());
    }

    @Test
    public void validateFinalizeDraftError() {
        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(true);
        assertNull(validator.validateDraft(salesOrder));
    }

    @Test
    public void validateFinalizeDraft() {
        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(false);
        assertNotNull(validator.validateDraft(salesOrder));
    }

    @Test
    public void validateFinalizeWithoutItemsError() {
        SalesOrder salesOrder = new SalesOrder();
        SalesOrderItem item = new SalesOrderItem();

        List<SalesOrderItem> itens = new LinkedList<SalesOrderItem>();
        itens.add(item);
        salesOrder.setItems(itens);

        assertNull(validator.validateSalesOrderHaveItems(salesOrder));
    }

    @Test
    public void validateFinalizeWithoutItems() {
        SalesOrder salesOrder = new SalesOrder();

        assertNotNull(validator.validateSalesOrderHaveItems(salesOrder));
    }

    @Test
    public void validateFinalizeValueError() {
        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.TEN);
        assertNull(validator.validateValueMoreThanZero(salesOrder));
    }

    @Test
    public void validateFinalizeValue() {
        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.ZERO);
        assertNotNull(validator.validateValueMoreThanZero(salesOrder));
    }

    @Test
    public void validateFinalizeWithSignatureRequiredWithoutSignature() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        final LogicError error = validator.validateSignatureExists(salesOrder);
        assertEquals("sales", error.getField());
        assertEquals("order.signatureMissing", error.getMessageTemplate());
    }

    @Test
    public void validateFinalizeWithSignatureRequiredWithSignature() {
        mockParameter(Boolean.TRUE);
        final UUID signatureId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSignatureId(signatureId);
        assertNull(validator.validateSignatureExists(salesOrder));
    }

    @Test
    public void validateFinalizeWithSignatureNotRequiredWithoutSignature() {
        mockParameter(Boolean.FALSE);
        final UUID signatureId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        assertNull(validator.validateSignatureExists(salesOrder));
    }

    @Test
    public void validateFinalizeWithSignatureNotRequiredWithSignature() {
        mockParameter(Boolean.FALSE);
        final UUID signatureId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSignatureId(signatureId);
        assertNull(validator.validateSignatureExists(salesOrder));
    }

    @Test
    public void validateUpdateProfessionalAndInformedItems() {
        final SalesOrder salesOrderDB = new SalesOrder();
        salesOrderDB.setId(UUID.randomUUID());
        salesOrderDB.setUserProfessionalId(UUID.randomUUID());
        salesOrderDB.setItems(Arrays.asList(new SalesOrderItem()));

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrderDB);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = validator.validateUpdateProfessionalAndInformedItems(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("order.validation.updateProfessionalWithItems", error.getMessage());
    }

    @Test
    public void validateUpdateProfessionalAndInformedItemsAndWithoutProfessionalInDB() {
        final SalesOrder salesOrderDB = new SalesOrder();
        salesOrderDB.setId(UUID.randomUUID());
        salesOrderDB.setUserProfessionalId(null);
        salesOrderDB.setItems(Arrays.asList(new SalesOrderItem()));

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrderDB);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = validator.validateUpdateProfessionalAndInformedItems(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("order.validation.updateProfessionalWithItems", error.getMessage());
    }

    @Test
    public void validateUpdateProfessionalWithoutItems() {
        final SalesOrder salesOrderDB = new SalesOrder();
        salesOrderDB.setId(UUID.randomUUID());
        salesOrderDB.setUserProfessionalId(null);

        Mockito.when(salesOrderDAO.findById(Mockito.any())).thenReturn(salesOrderDB);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = validator.validateUpdateProfessionalAndInformedItems(salesOrder);

        assertNull(error);
    }

    @Test
    public void validateProfessionalExists() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        Mockito.when(userGateway.userExists(Mockito.any())).thenReturn(Boolean.TRUE);

        final LogicError error = headerValidator.validateProfessionalExists(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateProfessionalExistsWithoutInformingProfessionalId() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(null);

        final LogicError error = headerValidator.validateProfessionalExists(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateProfessionalNotFound() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        Mockito.when(userGateway.userExists(Mockito.any())).thenReturn(Boolean.FALSE);

        final LogicError error = headerValidator.validateProfessionalExists(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("order.validation.professional.notFound", error.getMessage());
    }

    @Test
    public void validateProfessionalIsActive() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        Mockito.when(userGateway.userIsActive(Mockito.any())).thenReturn(Boolean.TRUE);

        final LogicError error = headerValidator.validateProfessionalIsActive(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateProfessionalIsActiveWithoutInformingProfessionalId() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(null);

        final LogicError error = headerValidator.validateProfessionalIsActive(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateProfessionalInactive() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        Mockito.when(userGateway.userIsActive(Mockito.any())).thenReturn(Boolean.FALSE);

        final LogicError error = headerValidator.validateProfessionalIsActive(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("order.validation.professional.inactive", error.getMessage());
    }

    @Test
    public void validateProfessionalBelongsToTheHierarchyLowerToUserLogged() {
        final UUID professionalLogged = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(professionalLogged);

        final Session session = new SimpleSession();
        session.setAttribute("user_administrator", false);
        session.setAttribute("user_id", professionalLogged.toString());

        Mockito.when(userContext.getSession()).thenReturn(session);

        final LogicError error = headerValidator.validateIfTheInformedProfessionalBelongsToTheHierarchyLowerToUserLogged(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateProfessionalNotBelongsToTheHierarchyOfTheUserLoggedWithIdAny() {
        final UUID professionalLogged = UUID.randomUUID();
        final UUID otherIdOfAnyProfessional = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(professionalLogged);

        final Session session = new SimpleSession();
        session.setAttribute("user_administrator", false);
        session.setAttribute("user_id", otherIdOfAnyProfessional.toString());

        Mockito.when(userContext.getSession()).thenReturn(session);

        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(new User());

        final LogicError error = headerValidator.validateIfTheInformedProfessionalBelongsToTheHierarchyLowerToUserLogged(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("order.validation.professional.notBelongsToUser", error.getMessage());
    }

    @Test
    public void validateProfessionalBelongsToTheHierarchyOfTheUserLogged() {
        final User userLogged = new User();
        userLogged.setId(UUID.randomUUID().toString());

        final Session session = new SimpleSession();
        session.setAttribute("user_id", userLogged.getId().toString());
        session.setAttribute("user_administrator", false);

        Mockito.when(userContext.getSession()).thenReturn(session);

        final Hierarchy hierarchy = new Hierarchy();
        hierarchy.setUpperUser(userLogged);

        final User professional = new User();
        professional.getUserHierarchies().add(hierarchy);

        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(professional);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = headerValidator.validateIfTheInformedProfessionalBelongsToTheHierarchyLowerToUserLogged(salesOrder);

        assertNull(error);
    }

    @Test
    public void validateCreditLimitWithValidValue() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.TEN);
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());
        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);
        List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);
        assertNull(validator.validateCreditLimitIsNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitWithInvalidValue() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.TEN);
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.ZERO);
        List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        assertNotNull(validator.validateCreditLimitIsNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitBecameNegative() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(100));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);

        List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        assertNotNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitValid() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(5));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());
        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);
        List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);
        assertNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitWithoutRegister() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(5));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());
        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);
        List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);
        assertNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateInformedProfessional() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setUserProfessionalName("professional");

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);
        assertNull(error);
    }

    @Test
    public void validateInformedProfessionalWithoutProfessionalId() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalName("professional");

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("javax.validation.constraints.NotNull.message", error.getMessage());
    }

    @Test
    public void validateInformedProfessionalWithoutProfessionalName() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);

        assertNotNull(error);
        assertEquals("professional", error.getField());
        assertEquals("javax.validation.constraints.NotNull.message", error.getMessage());
    }

    @Test
    public void validatePriceListInValidity() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().toString());
        priceList.setEndOn(LocalDate.now().plusDays(1).toString());

        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);

        assertNull(headerValidator.validatePriceListIsOutOfDate(salesOrder));
    }

    @Test
    public void validatePriceListInValidityWithoutPriceList() {
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(null);
        assertNull(headerValidator.validatePriceListIsOutOfDate(new SalesOrder()));
    }

    @Test
    public void validatePriceListInValidityWithNullDates() {

        final PriceList priceList = new PriceList();
        priceList.setStartOn(null);
        priceList.setEndOn(null);

        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        assertNull(headerValidator.validatePriceListIsOutOfDate(salesOrder));
    }

    @Test
    public void validatePriceListOutOfDateWithDateBeforeToday() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().minusDays(2).toString());
        priceList.setEndOn(LocalDate.now().minusDays(1).toString());

        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);

        final LogicError error = headerValidator.validatePriceListIsOutOfDate(salesOrder);

        assertNotNull(error);
        assertEquals("priceListId", error.getField());
        assertEquals("order.priceListOutOfDate", error.getMessage());
    }

    @Test
    public void validatePriceListOutOfDateWithDateAfterToday() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().plusDays(1).toString());
        priceList.setEndOn(LocalDate.now().plusDays(2).toString());

        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);

        final LogicError error = headerValidator.validatePriceListIsOutOfDate(salesOrder);

        assertNotNull(error);
        assertEquals("priceListId", error.getField());
        assertEquals("order.priceListOutOfDate", error.getMessage());
    }
}