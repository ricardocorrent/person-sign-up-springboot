import io.gatling.core.Predef._

class PaymentTermScenarios {
  val paymentTermReq = new PaymentTermRequests
  val constants = new Constants
  val userRequests = new UserRequests

  val postAPaymentTermSuccessfully = scenario("Post a payment term successfully")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term successfully", "${uuid}", active = true, standard = false, availableFirstOrder = false, 255, 40, 40))
    .exec(
      session => {
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val postAPaymentTermWithDescriptionGreaterThanAllowed = scenario("Post a payment term having the description greater than allowed")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term having the description greater than allowed", "${uuid}", active = true, standard = false, availableFirstOrder = false, 256, 40, 40))
    .exec(
      session => {
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        assert(httpStatus.equals("422"), "httpStatus should be 422")
        assert(serverResponse.contains("\"message\":\"{javax.validation.constraints.Size.message}\""), "Server response should contains message validator")
        assert(serverResponse.contains("\"max\":255"), "Server response should contains max chars allowed")
        session
      })

  val postAPaymentTermWithAcronymGreaterThanAllowed = scenario("Post a payment term having the acronym greater than allowed")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term having the acronym greater than allowed", "${uuid}", active = true, standard = false, availableFirstOrder = false, 255, 41, 40))
    .exec(
      session => {
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        assert(httpStatus.equals("422"))
        assert(serverResponse.contains("\"message\":\"{javax.validation.constraints.Size.message}\""))
        assert(serverResponse.contains("\"max\":40"))
        session
      })

  val postAPaymentTermWithCodeGreaterThanAllowed = scenario("Post a payment term having the code greater than allowed")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term having the code greater than allowed", "${uuid}", active = true, standard = false, availableFirstOrder = false, 255, 40, 41))
    .exec(
      session => {
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        assert(httpStatus.equals("422"))
        assert(serverResponse.contains("\"message\":\"{javax.validation.constraints.Size.message}\""))
        assert(serverResponse.contains("\"max\":40"))
        session
      })

  val postAPaymentTermWithoutDescription = scenario("Post a payment term without description")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term without description", "${uuid}", active = true, standard = false, availableFirstOrder = false, 0, 40, 40))
    .exec(
      session => {
        println("Post a payment term without description")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        assert(httpStatus.equals("422"), "Http status should be 422")
        assert(serverResponse.contains("\"message\":\"validation.notnull.message\""), "Server response should contains notnull validation message")
        session
      }
    )

  val postAPaymentTermWithoutAcronym = scenario("Post a payment term without acronym")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term without acronym", "${uuid}", active = true, standard = false, availableFirstOrder = false, 255, 0, 40))
    .exec(
      session => {
        println("Post a payment term without acronym")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val postAPaymentTermWithoutCode = scenario("Post a payment term without code")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a payment term without code", "${uuid}", active = true, standard = false, availableFirstOrder = false, 255, 40, 0))
    .exec(
      session => {
        println("Post a payment term without code")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val postAnInactivePaymentTerm = scenario("Post an inactive payment term")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post an inactive payment term", "${uuid}", active = false, standard = false, availableFirstOrder = false, 255, 40, 40))
    .exec(
      session => {
        println("Post an inactive payment term")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val postAStandardPaymentTerm = scenario("Post a standard payment term for first time")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post a standard payment term for first time", "${uuid}", active = true, standard = true, availableFirstOrder = false, 255, 40, 40))
    .exec(
      session => {
        println("Post a standard payment term for first time")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val postAnAvailableFirstOrderPaymentTerm = scenario("Post an available first order payment term")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.postPaymentTerm("Post an available first order payment term", "${uuid}", active = true, standard = false, availableFirstOrder = true, 255, 40, 40))
    .exec(
      session => {
        println("Post an available first order payment term")
        val serverResponse = session("serverResponse").as[String]
        val httpStatus = session("httpStatus").as[Int].toString
        val id = session("uuid").as[String]
        assert(httpStatus.equals("201"), "httpStatus should be 201")
        assert(serverResponse.equals("{\"id\":\"" + id + "\"}"), "ServerResponse should be {\"id\":\"" + id + "\"}")
        session
      })

  val searchForActivesPaymentTerms = scenario("Search for actives payment terms")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(paymentTermReq.searchPaymentTerm(0, 25, isActive = true, isntActive = false, isAvailableForFirstOrder = false, isntAvailableForFirstOrder = false, isStandard = false, isntStandard = false, "", "", ""))
    .foreach("${paymentTermList}", "activesPaymentTerms") {
      exec(
        session => {
          println("Search for actives payment terms")
          val activePaymentTermMap = session("activesPaymentTerms").as[Map[String, Any]]
          val active = activePaymentTermMap("active")
          assert(active.equals(true))
          session
        }
      )
    }

  val scnSearchPaymentTerm = constants.createScenario(
    "Search for actives payment terms",
    constants.uuidFeeder.feeder, userRequests.doLogin,
    paymentTermReq.searchPaymentTerm(0, 25, isActive = true, isntActive = false, isAvailableForFirstOrder = false, isntAvailableForFirstOrder = false, isStandard = false, isntStandard = false, "", "", "")
  )

}