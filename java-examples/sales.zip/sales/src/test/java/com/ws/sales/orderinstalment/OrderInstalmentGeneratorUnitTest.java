package com.ws.sales.orderinstalment;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.paymentterm.PaymentTerm;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * @author Maykon Rissi
 * @since v5.22.0 2018-05-02
 * @since v6.2.0 2018-09-04
 */
@RunWith(MockitoJUnitRunner.class)
public class OrderInstalmentGeneratorUnitTest extends BaseUnitTest {

    @InjectMocks
    private SalesOrderInstalmentGenerateValidator salesOrderInstalmentGenerateValidator;

    @Mock
    private OrderParameterService orderParameterService;

    /**
     * <p>
     * creates a new {@link OrderParameter} and set the value with the
     * informed parameter
     *
     * @param value to set return of the mock
     */
    private void doMockOrderParameter(final Boolean value) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(value.toString());
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    /**
     * <p>
     * creates a new {@link SalesOrderInstalmentGenerate} using the informed parameters.
     *
     * @param quantity    to set the new InstalmentGenerate
     * @param daysBetween to set the new InstalmentGenerate
     */
    private SalesOrderInstalmentGenerate getNewInstalmentGenerate(final Integer quantity, final Integer daysBetween) {
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = new SalesOrderInstalmentGenerate();
        salesOrderInstalmentGenerate.setQuantity(quantity);
        salesOrderInstalmentGenerate.setDaysBetween(daysBetween);
        salesOrderInstalmentGenerate.setOrderId(UUID.randomUUID());
        return salesOrderInstalmentGenerate;
    }

    @Test
    public void isValidIfInstalmentNumberIsLowerThanPaymentTermConfiguration() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(BigDecimal.TEN);
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(10, 10);
        final LogicError error = salesOrderInstalmentGenerateValidator.doValidateInstalmentsNumber(paymentTerm, salesOrderInstalmentGenerate);
        Assert.assertNull(error);
    }

    @Test
    public void isInvalidIfPaymentTermNumberOfInstalmentsIsNull() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(null);
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(10, 10);
        final LogicError error = salesOrderInstalmentGenerateValidator.doValidateInstalmentsNumber(paymentTerm, salesOrderInstalmentGenerate);
        Assert.assertNotNull(error);
    }

    @Test
    public void isInvalidIfPaymentTermInstalmentNumberIsLowerThanNumberOfInstalments() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setMaxNumberInstalment(BigDecimal.valueOf(5));
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(10, 10);
        final LogicError error = salesOrderInstalmentGenerateValidator.doValidateInstalmentsNumber(paymentTerm, salesOrderInstalmentGenerate);
        Assert.assertNotNull(error);
    }

    @Test
    public void instalmentDaysCanBeZeroIfQuantityOfInstalmentsIsOne() {
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(1, 0);
        final LogicError error = salesOrderInstalmentGenerateValidator.doValidateIfDaysAreZeroAndInstalmentsAreMoreThanOne(salesOrderInstalmentGenerate);
        Assert.assertNull(error);
    }

    @Test
    public void instalmentDaysCanNotBeZeroIfQuantityOfInstalmentsIsMoreThanOne() {
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(5, 0);
        final LogicError error = salesOrderInstalmentGenerateValidator.doValidateIfDaysAreZeroAndInstalmentsAreMoreThanOne(salesOrderInstalmentGenerate);
        Assert.assertNotNull(error);
    }

    @Test
    public void entityIsNotValidIfFieldsAreLowerThanZero() {
        this.doMockOrderParameter(Boolean.TRUE);
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(-1, -1);
        this.salesOrderInstalmentGenerateValidator.validateByBeanValidation(salesOrderInstalmentGenerate, null);
        Assert.assertEquals(2, this.salesOrderInstalmentGenerateValidator.getConstraintViolations().size());
    }

    @Test
    public void entityIsNotValidIfFieldsAreNull() {
        this.doMockOrderParameter(Boolean.TRUE);
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = new SalesOrderInstalmentGenerate();
        this.salesOrderInstalmentGenerateValidator.validateByBeanValidation(salesOrderInstalmentGenerate, null);
        Assert.assertEquals(2, this.salesOrderInstalmentGenerateValidator.getConstraintViolations().size());
    }

    @Test
    public void canNotValidateByBeanValidationBecauseParameterIsDisabled() {
        this.doMockOrderParameter(Boolean.FALSE);
        final SalesOrderInstalmentGenerate salesOrderInstalmentGenerate = this.getNewInstalmentGenerate(5, 0);
        this.salesOrderInstalmentGenerateValidator.validateByBeanValidation(salesOrderInstalmentGenerate, null);
        Assert.assertEquals(1, this.salesOrderInstalmentGenerateValidator.getConstraintViolations().size());
    }
}
