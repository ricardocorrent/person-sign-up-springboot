package com.ws.sales.externalvalidation;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.sales.util.Constants;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.administration.dto.CompanyDTO;
import com.ws.sales.external.product.dto.DiscountDTO;
import com.ws.sales.external.product.DiscountValidation;
import com.ws.sales.external.product.DiscountType;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * Tests for customer and location validations
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-22
 */
@RunWith(MockitoJUnitRunner.class)
public class DiscountValidationUnitTest {

    @InjectMocks
    private DiscountValidation discountValidation;

    @Mock
    private ProductGateway productGateway;

    @Mock
    private OrderParameterService orderParameterService;

    /**
     * Tries to inform a discount when the item does not have fixed price. It must not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-22
     */
    @Test
    public void discountIsValidBecauseFixedPriceIsFalse() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(Boolean.FALSE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = discountValidation.doValidateDiscountAndFixedPrice(Constants.FIELD_PRODUCT_DESCRIPTION, UUID.randomUUID(), BigDecimal.TEN, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to inform a discount when the item have fixed price. It must not return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-22
     */
    @Test
    public void discountIsInvalidBecauseFixedPriceIsFalse() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(Boolean.TRUE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = discountValidation.doValidateDiscountAndFixedPrice(Constants.FIELD_PRODUCT_DESCRIPTION, UUID.randomUUID(), BigDecimal.TEN, BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to inform a discount when the item have fixed price null. It must not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-22
     */
    @Test
    public void discountIsValidWithFixedPriceNull() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setFixedPrice(null);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = discountValidation.doValidateDiscountAndFixedPrice(Constants.FIELD_PRODUCT_DESCRIPTION, UUID.randomUUID(), BigDecimal.TEN, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with null params. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountAndFixedPriceMustNotValidateBecauseParamsAreNull() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        final LogicError logicError = discountValidation.doValidateDiscountAndFixedPrice(null, null, null, null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with with zero or null params. Must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void cannotValidateBecauseValuesAreZero() {
        final LogicError logicError = discountValidation.doValidateDiscountAndFixedPrice(Constants.FIELD_PRODUCT_DESCRIPTION, UUID.randomUUID(), BigDecimal.ZERO, BigDecimal.ZERO);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with with a valid discount, the plugin is true end there is a discount in DB. Must does not return a logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountValueIsValidAndPluginIsActive() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final Product product = new Product();
        product.setDiscountLimitType(DiscountType.COMPANY.toString());
        final CompanyDTO company = new CompanyDTO();
        company.setId(UUID.randomUUID());
        final DiscountDTO discount = new DiscountDTO();
        discount.setCompany(company);
        discount.setMaximumDiscountValue(BigDecimal.TEN);
        final List<DiscountDTO> discounts = new LinkedList<>();
        discounts.add(discount);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(discounts);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with with a invalid discount value, the plugin is true end there is a discount in DB. Must returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountValueIsInvalidAndPluginIsActive() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final Product product = new Product();
        product.setDiscountLimitType(DiscountType.COMPANY.toString());
        final CompanyDTO company = new CompanyDTO();
        company.setId(UUID.randomUUID());
        final DiscountDTO discount = new DiscountDTO();
        discount.setCompany(company);
        discount.setMaximumDiscountValue(BigDecimal.ONE);
        final List<DiscountDTO> discounts = new LinkedList<>();
        discounts.add(discount);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(discounts);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with with a valid discount, the plugin is true end there is a discount in DB. Must does not return a logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountPercentageIsValidAndPluginIsActive() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final Product product = new Product();
        product.setDiscountLimitType(DiscountType.COMPANY.toString());
        final CompanyDTO company = new CompanyDTO();
        company.setId(UUID.randomUUID());
        final DiscountDTO discount = new DiscountDTO();
        discount.setCompany(company);
        discount.setMaximumDiscountPercentage(BigDecimal.TEN);
        final List<DiscountDTO> discounts = new LinkedList<>();
        discounts.add(discount);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(discounts);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with with a invalid discount percentage, the plugin is true end there is a discount in DB. Must does not return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountPercentageIsInvalidAndPluginIsActive() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final Product product = new Product();
        product.setDiscountLimitType(DiscountType.COMPANY.toString());
        final CompanyDTO company = new CompanyDTO();
        company.setId(UUID.randomUUID());
        final DiscountDTO discount = new DiscountDTO();
        discount.setCompany(company);
        discount.setMaximumDiscountPercentage(BigDecimal.ONE);
        final List<DiscountDTO> discounts = new LinkedList<>();
        discounts.add(discount);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(discounts);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with with a valid discount, the plugin is true end there is no discount in DB. Must does not return a logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountIsValidPluginIsActiveAndDiscountDoesNotExist() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final Product product = new Product();
        product.setDiscountLimitType(DiscountType.COMPANY.toString());
        final CompanyDTO company = new CompanyDTO();
        company.setId(UUID.randomUUID());
        final List<DiscountDTO> discounts = new LinkedList<>();
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.searchDiscounts(Mockito.any())).thenReturn(discounts);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a the plugin false. Must does not return a logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void discountIsValidPluginIInactive() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("false");
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        final LogicError logicError = discountValidation.doValidateMaximumDiscount(UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                OffsetDateTime.now(),
                BigDecimal.TEN,
                BigDecimal.TEN);
        Assert.assertNull(logicError);
    }
}
