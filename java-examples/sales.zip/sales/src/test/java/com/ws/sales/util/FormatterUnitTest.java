package com.ws.sales.util;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.sollar.test.BaseUnitTest;

/**
 * Test all methods {@link Formatter}
 * 
 * @author william.santos
 * @since 2018-08-21
 * @version 1.0.0
 */
public class FormatterUnitTest extends BaseUnitTest {

    @Test(expected = NullPointerException.class)
    public void doNotFormatNullToBrazilianMoney() {
        Formatter.brazilianMoney(null);
    }

    @Test
    public void formatMoneyWithDecimalToBrazilianPattern() {
        final BigDecimal value = BigDecimal.valueOf(10.5);
        final String expected = "R$ 10,50";
        final String got = Formatter.brazilianMoney(value);
        Assert.assertEquals(expected, got);
    }

    @Test
    public void formatZeroToBrazilianMoney() {
        final BigDecimal zero = BigDecimal.ZERO;
        final String expected = "R$ 0,00";
        final String got = Formatter.brazilianMoney(zero);
        Assert.assertEquals(expected, got);
    }

    @Test
    public void formatNegativeToBrazilianMoney() {
        final BigDecimal zero = BigDecimal.valueOf(-10.8);
        final String expected = "-R$ 10,80";
        final String got = Formatter.brazilianMoney(zero);
        Assert.assertEquals(expected, got);
    }

    @Test(expected = NullPointerException.class)
    public void doNotFormatNullToBrazilianDate() {
        Formatter.brazilianDate(null);
    }
    
    @Test
    public void formatDateToBrazilianDate() {
        final LocalDate date = LocalDate.of(2018, 01, 18);
        final String expected = "18/01/2018";
        final String got = Formatter.brazilianDate(date);
        Assert.assertEquals(expected, got);
    }
    
        @Test(expected = NullPointerException.class)
    public void doNotFormatNullToBrazilianAmount() {
        Formatter.brazilianAmount(null);
    }

    @Test
    public void formatAmountWithDecimalToBrazilianPattern() {
        final BigDecimal value = BigDecimal.valueOf(10.5);
        final String expected = "10,50";
        final String got = Formatter.brazilianAmount(value);
        Assert.assertEquals(expected, got);
    }

    @Test
    public void formatZeroToBrazilianAmount() {
        final BigDecimal zero = BigDecimal.ZERO;
        final String expected = "0,00";
        final String got = Formatter.brazilianAmount(zero);
        Assert.assertEquals(expected, got);
    }

    @Test
    public void formatNegativeToBrazilianAmount() {
        final BigDecimal zero = BigDecimal.valueOf(-10.8);
        final String expected = "-10,80";
        final String got = Formatter.brazilianAmount(zero);
        Assert.assertEquals(expected, got);
    }
}
