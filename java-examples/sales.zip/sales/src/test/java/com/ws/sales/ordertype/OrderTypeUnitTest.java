package com.ws.sales.ordertype;

import java.util.UUID;

import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.ordertype.dto.OrderTypeDTO;

/**
 * Test all methods of {@link OrderTypeResource} and {@link OrderTypeService}
 * 
 * @author william.santos
 * @since 2018-09-11
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class OrderTypeUnitTest extends BaseUnitTest {

    @Mock
    private OrderTypeDAO dao;

    private OrderTypeService service;

    private OrderTypeResource resource;

    private OrderTypeValidation validator;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.validator = new OrderTypeValidation(this.dao);
        this.service = new OrderTypeService(this.dao, this.validator);
        this.resource = new OrderTypeResource(this.service);
    }

    @Test
    public void searchAcceptNullOnParameterReturnsList() {
        final OrderTypeSearch search = new OrderTypeSearch();
        final PagedList<OrderType> list = new PagedList<>();

        Mockito.when(this.dao.list(search)).thenReturn(list);

        final Response response = this.resource.search(search);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(list, response.getEntity());
    }

    @Test
    public void orderTypeInactiveReturnFalse() {
        final UUID orderTypeId = UUID.randomUUID();
        final OrderType orderType = new OrderType();
        orderType.setActive(Boolean.FALSE);
        orderType.setId(orderTypeId);

        Mockito.when(this.dao.getStateOrdertype(orderTypeId)).thenReturn(orderType);

        final Boolean active = this.service.orderTypeIsActive(orderTypeId);
        Assert.assertNotNull(active);
        Assert.assertEquals(Boolean.FALSE, active);
    }

    @Test
    public void orderTypeActiveReturnsTrue() {
        final UUID orderTypeId = UUID.randomUUID();
        final OrderType orderType = new OrderType();
        orderType.setActive(Boolean.TRUE);
        orderType.setId(orderTypeId);

        Mockito.when(this.dao.getStateOrdertype(orderTypeId)).thenReturn(orderType);

        final Boolean active = this.service.orderTypeIsActive(orderTypeId);
        Assert.assertNotNull(active);
        Assert.assertEquals(Boolean.TRUE, active);
    }

    @Test
    public void nullOnOrderTypeActiveReturnsTrue() {
        final UUID orderTypeId = UUID.randomUUID();

        Mockito.when(this.dao.getStateOrdertype(orderTypeId)).thenReturn(null);

        final Boolean active = this.service.orderTypeIsActive(orderTypeId);
        Assert.assertNotNull(active);
        Assert.assertEquals(Boolean.TRUE, active);
    }

    /**
     * Valid mapping to convert {@link OrderType} to {@link OrderTypeDTO}
     */
    @Test
    public void convertOrderTypeToOrderTypeDto() {
        final OrderType orderType = new OrderType();
        orderType.setId(UUID.randomUUID());
        orderType.setDescription("Unit-Test");

        final OrderTypeDTO dto = new PojoConverter().convert(OrderTypeDTO.class, orderType);
        Assert.assertNotNull(dto);
        Assert.assertEquals(orderType.getId(), dto.getId());
        Assert.assertEquals(orderType.getDescription(), dto.getDescription());
    }
}
