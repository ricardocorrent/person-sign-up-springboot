package com.ws.sales.order.SalesOrderTest;

/**
 * @author Samuel Blum Vorpagel <samuel.vorpagel@wssim.com.br>
 * @since v 2017-03-08
 */
public class SalesOrderResourceUnitTest {
}
