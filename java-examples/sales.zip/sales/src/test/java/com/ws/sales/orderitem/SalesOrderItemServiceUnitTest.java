package com.ws.sales.orderitem;

import com.sollar.test.BaseUnitTest;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.product.model.ProductPackaging;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.order.SalesOrderService;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Random;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.eq;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrderItemServiceUnitTest extends BaseUnitTest {

    @InjectMocks
    private SalesOrderItemService service;

    @Mock
    private SalesOrderDAO orderDAO;

    @Mock
    private SalesOrderItemDAO dao;

    @Mock
    private ProductGateway productGateway;

    @Mock
    private SalesOrderService salesOrderService;

    @Mock
    private SalesOrderItemValidator validator;

    @Mock
    private OrderParameterService orderParameterService;

    @Test
    public void insert_withoutDescriptions() throws Exception {

        // CONSTANTS ---------------------------------------------------------------------------------------------------
        final UUID idOrder = UUID.randomUUID();

        final UUID idPriceList = UUID.randomUUID();
        final String descriptionPriceList = "descriptionPriceList - " + idPriceList;

        final UUID idPriceListItem = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final String codeProduct = String.valueOf(new Random().nextLong());
        final String descriptionProduct = "descriptionProduct - " + idProduct;

        final UUID idPackaging = UUID.randomUUID();
        final String descriptionPackaging = "descriptionPackaging - " + idPackaging;

        final UUID idOccurrence = UUID.randomUUID();
        final String commonNameOccurrence = "commonNameOccurrence - " + idOccurrence;

        // VALUES ------------------------------------------------------------------------------------------------------

        final OrderParameter orderParameter = new OrderParameter();
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);

        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey("DECIMAL_PLACES");
        final int decimalPlaces = decimalPlacesParameter.getValue() != null ? Integer.valueOf(decimalPlacesParameter.getValue()) : 2;

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = new BigDecimal("5.5");
        final BigDecimal discountValue = new BigDecimal("4.5");
        final BigDecimal discountPercentage = new BigDecimal("45");
        final BigDecimal quantity = BigDecimal.TEN.multiply(BigDecimal.TEN).setScale(decimalPlaces, RoundingMode.HALF_EVEN);;

        // MOCKS -------------------------------------------------------------------------------------------------------

        final SalesOrder orderReturned = Mockito.mock(SalesOrder.class);
        Mockito.when(orderReturned.getId()).thenReturn(idOrder);
        Mockito.when(orderDAO.findById(Mockito.any())).thenReturn(orderReturned);

        final ProductPackaging packagingReturned = Mockito.mock(ProductPackaging.class);
        Mockito.when(packagingReturned.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packagingReturned.getPackagingDescription()).thenReturn(descriptionPackaging);

        final Product productReturned = Mockito.mock(Product.class);
        Mockito.when(productReturned.getId()).thenReturn(idProduct.toString());
        Mockito.when(productReturned.getCode()).thenReturn(codeProduct);
        Mockito.when(productReturned.getDescription()).thenReturn(descriptionProduct);
        Mockito.when(productReturned.getPackagings()).thenReturn(Arrays.asList(packagingReturned));
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(productReturned);

        final PriceList priceListReturned = Mockito.mock(PriceList.class);
        Mockito.when(priceListReturned.getId()).thenReturn(idPriceList.toString());
        Mockito.when(priceListReturned.getDescription()).thenReturn(descriptionPriceList);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceListReturned);

        final PriceListItem priceListItemReturned = Mockito.mock(PriceListItem.class);
        Mockito.when(priceListItemReturned.getId()).thenReturn(idPriceListItem.toString());
        Mockito.when(priceListItemReturned.getProduct()).thenReturn(productReturned);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItemReturned);

        // ITEM --------------------------------------------------------------------------------------------------------

        final SalesOrder order = new SalesOrder();
        order.setId(idOrder);
        order.setPriceListId(idPriceList);

        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesOrder(order);
        item.setPriceListId(idPriceList);
        item.setPriceListItemId(idPriceListItem);
        item.setProductId(idProduct);
        item.setProductPackagingId(idPackaging);

        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(discountValue);
        item.setDiscountPercentage(discountPercentage);
        item.setQuantity(quantity);

        SalesOrderItem inserted = service.insert(item);

        final BigDecimal total = salesPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN);

        assertNotNull(inserted);
        assertEquals(descriptionPriceList, inserted.getPriceListDescription());
        assertEquals(descriptionProduct, inserted.getProductDescription());
        assertEquals(codeProduct, inserted.getProductCode());
        assertEquals(descriptionPackaging, inserted.getProductPackagingDescription());
        assertEquals(total, inserted.getTotalItem());
    }

    @Test
    public void insert_withDescriptions() throws Exception {

        // CONSTANTS ---------------------------------------------------------------------------------------------------
        final UUID idOrder = UUID.randomUUID();

        final UUID idPriceList = UUID.randomUUID();
        final String descriptionPriceList = "descriptionPriceList - " + idPriceList;
        final String descriptionPriceListTest = "descriptionPriceListTest - " + idPriceList;

        final UUID idPriceListItem = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final String codeProduct = String.valueOf(new Random().nextLong());
        final String codeProductTest = String.valueOf(new Random().nextLong());
        final String descriptionProduct = "descriptionProduct - " + idProduct;
        final String descriptionProductTest = "descriptionProductTest - " + idProduct;

        final UUID idPackaging = UUID.randomUUID();
        final String descriptionPackaging = "descriptionPackaging - " + idPackaging;
        final String descriptionPackagingTest = "descriptionPackagingTest - " + idPackaging;


        // VALUES ------------------------------------------------------------------------------------------------------

        final OrderParameter orderParameter = new OrderParameter();
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);

        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey("DECIMAL_PLACES");
        final int decimalPlaces = decimalPlacesParameter.getValue() != null ? Integer.valueOf(decimalPlacesParameter.getValue()) : 2;

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = new BigDecimal("5.5");
        final BigDecimal discountValue = new BigDecimal("4.5");
        final BigDecimal discountPercentage = new BigDecimal("45");
        final BigDecimal quantity = BigDecimal.TEN.multiply(BigDecimal.TEN).setScale(decimalPlaces, RoundingMode.HALF_EVEN);

        // MOCKS -------------------------------------------------------------------------------------------------------

        final SalesOrder orderReturned = Mockito.mock(SalesOrder.class);
        Mockito.when(orderReturned.getId()).thenReturn(idOrder);
        Mockito.when(orderDAO.findById(Mockito.any())).thenReturn(orderReturned);

        // ITEM --------------------------------------------------------------------------------------------------------

        final SalesOrder order = new SalesOrder();
        order.setId(idOrder);
        order.setPriceListId(idPriceList);

        final SalesOrderItem item = new SalesOrderItem();
        item.setSalesOrder(order);
        item.setPriceListId(idPriceList);
        item.setPriceListDescription(descriptionPriceListTest);
        item.setPriceListItemId(idPriceListItem);
        item.setProductId(idProduct);
        item.setProductCode(codeProductTest);
        item.setProductDescription(descriptionProductTest);
        item.setProductPackagingId(idPackaging);
        item.setProductPackagingDescription(descriptionPackagingTest);

        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(discountValue);
        item.setDiscountPercentage(discountPercentage);
        item.setQuantity(quantity);

        SalesOrderItem inserted = service.insert(item);

        final BigDecimal total = salesPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN);

        assertNotNull(inserted);
        assertEquals(descriptionPriceListTest, inserted.getPriceListDescription());
        assertEquals(descriptionProductTest, inserted.getProductDescription());
        assertEquals(codeProductTest, inserted.getProductCode());
        assertEquals(descriptionPackagingTest, inserted.getProductPackagingDescription());
        assertEquals(total, inserted.getTotalItem());
    }

    @Test
    public void update_withoutDescriptions() throws Exception {

        // CONSTANTS ---------------------------------------------------------------------------------------------------
        final UUID idItem = UUID.randomUUID();

        final UUID idOrder = UUID.randomUUID();

        final UUID idPriceList = UUID.randomUUID();
        final String descriptionPriceList = "descriptionPriceList - " + idPriceList;

        final UUID idPriceListItem = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final String codeProduct = String.valueOf(new Random().nextLong());
        final String descriptionProduct = "descriptionProduct - " + idProduct;

        final UUID idPackaging = UUID.randomUUID();
        final String descriptionPackaging = "descriptionPackaging - " + idPackaging;

        // VALUES ------------------------------------------------------------------------------------------------------

        final OrderParameter orderParameter = new OrderParameter();
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);

        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey("DECIMAL_PLACES");
        final int decimalPlaces = decimalPlacesParameter.getValue() != null ? Integer.valueOf(decimalPlacesParameter.getValue()) : 2;

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = new BigDecimal("5.5");
        final BigDecimal discountValue = new BigDecimal("4.5");
        final BigDecimal discountPercentage = new BigDecimal("45");
        final BigDecimal quantity = BigDecimal.TEN.multiply(BigDecimal.TEN).setScale(decimalPlaces, RoundingMode.HALF_EVEN);;

        // MOCKS -------------------------------------------------------------------------------------------------------

        final SalesOrderItem oldItem = Mockito.mock(SalesOrderItem.class);
        Mockito.when(oldItem.getId()).thenReturn(idItem);
        Mockito.when(oldItem.getTotalItem()).thenReturn(originalPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN));
        Mockito.when(dao.findById(eq(idItem))).thenReturn(oldItem);

        final SalesOrder orderReturned = Mockito.mock(SalesOrder.class);
        Mockito.when(orderReturned.getId()).thenReturn(idOrder);
        Mockito.when(orderDAO.findById(Mockito.any())).thenReturn(orderReturned);

        final ProductPackaging packagingReturned = Mockito.mock(ProductPackaging.class);
        Mockito.when(packagingReturned.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packagingReturned.getPackagingDescription()).thenReturn(descriptionPackaging);

        final Product productReturned = Mockito.mock(Product.class);
        Mockito.when(productReturned.getId()).thenReturn(idProduct.toString());
        Mockito.when(productReturned.getCode()).thenReturn(codeProduct);
        Mockito.when(productReturned.getDescription()).thenReturn(descriptionProduct);
        Mockito.when(productReturned.getPackagings()).thenReturn(Arrays.asList(packagingReturned));
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(productReturned);

        final PriceList priceListReturned = Mockito.mock(PriceList.class);
        Mockito.when(priceListReturned.getId()).thenReturn(idPriceList.toString());
        Mockito.when(priceListReturned.getDescription()).thenReturn(descriptionPriceList);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceListReturned);

        final PriceListItem priceListItemReturned = Mockito.mock(PriceListItem.class);
        Mockito.when(priceListItemReturned.getId()).thenReturn(idPriceListItem.toString());
        Mockito.when(priceListItemReturned.getProduct()).thenReturn(productReturned);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItemReturned);

        // ITEM --------------------------------------------------------------------------------------------------------

        final SalesOrder order = new SalesOrder();
        order.setId(idOrder);
        order.setPriceListId(idPriceList);

        final SalesOrderItem item = new SalesOrderItem();
        item.setId(idItem);
        item.setSalesOrder(order);
        item.setPriceListId(idPriceList);
        item.setPriceListItemId(idPriceListItem);
        item.setProductId(idProduct);
        item.setProductPackagingId(idPackaging);

        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(discountValue);
        item.setDiscountPercentage(discountPercentage);
        item.setQuantity(quantity);

        service.update(item);

        final BigDecimal total = salesPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN);

        assertNotNull(item);
        assertEquals(descriptionPriceList, item.getPriceListDescription());
        assertEquals(descriptionProduct, item.getProductDescription());
        assertEquals(codeProduct, item.getProductCode());
        assertEquals(descriptionPackaging, item.getProductPackagingDescription());
        assertEquals(total, item.getTotalItem());
    }

    @Test
    public void update_withDescriptions() throws Exception {

        // CONSTANTS ---------------------------------------------------------------------------------------------------
        final UUID idItem = UUID.randomUUID();

        final UUID idOrder = UUID.randomUUID();

        final UUID idPriceList = UUID.randomUUID();
        final String descriptionPriceList = "descriptionPriceList - " + idPriceList;
        final String descriptionPriceListTest = "descriptionPriceListTest - " + idPriceList;

        final UUID idPriceListItem = UUID.randomUUID();

        final UUID idProduct = UUID.randomUUID();
        final String codeProduct = String.valueOf(new Random().nextLong());
        final String codeProductTest = String.valueOf(new Random().nextLong());
        final String descriptionProduct = "descriptionProduct - " + idProduct;
        final String descriptionProductTest = "descriptionProductTest - " + idProduct;

        final UUID idPackaging = UUID.randomUUID();
        final String descriptionPackaging = "descriptionPackaging - " + idPackaging;
        final String descriptionPackagingTest = "descriptionPackagingTest - " + idPackaging;

        // VALUES ------------------------------------------------------------------------------------------------------

        final OrderParameter orderParameter = new OrderParameter();
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);

        final OrderParameter decimalPlacesParameter = orderParameterService.searchByKey("DECIMAL_PLACES");
        final int decimalPlaces = decimalPlacesParameter.getValue() != null ? Integer.valueOf(decimalPlacesParameter.getValue()) : 2;

        final BigDecimal originalPrice = BigDecimal.TEN;
        final BigDecimal salesPrice = new BigDecimal("5.5");
        final BigDecimal discountValue = new BigDecimal("4.5");
        final BigDecimal discountPercentage = new BigDecimal("45");
        final BigDecimal quantity = BigDecimal.TEN.multiply(BigDecimal.TEN).setScale(decimalPlaces);

        // MOCKS -------------------------------------------------------------------------------------------------------

        final SalesOrderItem oldItem = Mockito.mock(SalesOrderItem.class);
        Mockito.when(oldItem.getId()).thenReturn(idItem);
        Mockito.when(oldItem.getTotalItem()).thenReturn(originalPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN));
        Mockito.when(dao.findById(eq(idItem))).thenReturn(oldItem);

        final SalesOrder orderReturned = Mockito.mock(SalesOrder.class);
        Mockito.when(orderReturned.getId()).thenReturn(idOrder);
        Mockito.when(orderDAO.findById(Mockito.any())).thenReturn(orderReturned);

        final ProductPackaging packagingReturned = Mockito.mock(ProductPackaging.class);
        Mockito.when(packagingReturned.getId()).thenReturn(idPackaging.toString());
        Mockito.when(packagingReturned.getPackagingDescription()).thenReturn(descriptionPackaging);

        final Product productReturned = Mockito.mock(Product.class);
        Mockito.when(productReturned.getId()).thenReturn(idProduct.toString());
        Mockito.when(productReturned.getCode()).thenReturn(codeProduct);
        Mockito.when(productReturned.getDescription()).thenReturn(descriptionProduct);
        Mockito.when(productReturned.getPackagings()).thenReturn(Arrays.asList(packagingReturned));
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(productReturned);

        final PriceList priceListReturned = Mockito.mock(PriceList.class);
        Mockito.when(priceListReturned.getId()).thenReturn(idPriceList.toString());
        Mockito.when(priceListReturned.getDescription()).thenReturn(descriptionPriceList);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceListReturned);

        final PriceListItem priceListItemReturned = Mockito.mock(PriceListItem.class);
        Mockito.when(priceListItemReturned.getId()).thenReturn(idPriceListItem.toString());
        Mockito.when(priceListItemReturned.getProduct()).thenReturn(productReturned);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItemReturned);

       // ITEM --------------------------------------------------------------------------------------------------------

        final SalesOrder order = new SalesOrder();
        order.setId(idOrder);
        order.setPriceListId(idPriceList);

        final SalesOrderItem item = new SalesOrderItem();
        item.setId(idItem);
        item.setSalesOrder(order);
        item.setPriceListId(idPriceList);
        item.setPriceListDescription(descriptionPriceListTest);
        item.setPriceListItemId(idPriceListItem);
        item.setProductId(idProduct);
        item.setProductCode(codeProductTest);
        item.setProductDescription(descriptionProductTest);
        item.setProductPackagingId(idPackaging);
        item.setProductPackagingDescription(descriptionPackagingTest);

        item.setOriginalPrice(originalPrice);
        item.setSalesPrice(salesPrice);
        item.setDiscountValue(discountValue);
        item.setDiscountPercentage(discountPercentage);
        item.setQuantity(quantity);

        service.update(item);

        final BigDecimal total = salesPrice.multiply(quantity).setScale(decimalPlaces, RoundingMode.HALF_EVEN);

        assertNotNull(item);
        assertEquals(descriptionPriceListTest, item.getPriceListDescription());
        assertEquals(descriptionProductTest, item.getProductDescription());
        assertEquals(codeProductTest, item.getProductCode());
        assertEquals(descriptionPackagingTest, item.getProductPackagingDescription());
        assertEquals(total, item.getTotalItem());
    }

}
