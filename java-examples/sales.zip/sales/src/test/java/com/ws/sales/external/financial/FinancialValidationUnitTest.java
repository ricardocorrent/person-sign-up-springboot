package com.ws.sales.external.financial;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.financial.model.CreditLimit;
import com.ws.sales.external.financial.FinancialGateway;
import com.ws.sales.external.financial.FinancialValidation;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * Tests for financial entities
 *
 * @author Maykon Rissi
 * @since v6.0.0 2018-08-18
 */
@RunWith(MockitoJUnitRunner.class)
public class FinancialValidationUnitTest {

    @InjectMocks
    private FinancialValidation financialValidation;

    @Mock
    private FinancialGateway financialGateway;

    /**
     * Create the mock to return one credit limit in a list
     *
     * @param createWithEmptyLimit set if the mock will use zero or ten for the credit limit's value
     * @return {@link List<CreditLimit>} mock containing one credit limit with value
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private List<CreditLimit> doMockAndReturnOneCreditLimit(final Boolean createWithEmptyLimit) {
        final List<CreditLimit> creditLimits = new LinkedList<>();
        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(createWithEmptyLimit ? BigDecimal.ZERO : BigDecimal.TEN);
        creditLimits.add(creditLimit);
        Mockito.when(this.financialGateway.searchCreditLimit(Mockito.any())).thenReturn(creditLimits);
        return this.financialValidation.findCreditLimit(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());
    }

    /**
     * Create the mock to return two credit limits in a list
     *
     * @return {@link List<CreditLimit>} mock containing two credit limits
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    private List<CreditLimit> doMockAndReturnMoreThanOneCreditLimits() {
        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(new CreditLimit());
        creditLimits.add(new CreditLimit());
        Mockito.when(this.financialGateway.searchCreditLimit(Mockito.any())).thenReturn(creditLimits);
        return this.financialValidation.findCreditLimit(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void creditLimitExist() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitExists(creditLimits);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void creditLimitDoestNotExist() {
        final List<CreditLimit> creditLimits = new LinkedList<>();
        final LogicError error = this.financialValidation.doValidateIfCreditLimitExists(creditLimits);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void parameterIsNullSoItDoesNotHaveACreditLimit() {
        final LogicError error = this.financialValidation.doValidateIfCreditLimitExists(null);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void hasOnlyOneCreditLimitSoIsValid() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitExists(creditLimits);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void hasMoreThanOneCreditLimitSoIsInvalid() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnMoreThanOneCreditLimits();
        final LogicError error = this.financialValidation.doValidateIfHasMoreThanOneCreditLimit(creditLimits);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void isNullSoItWillNotValidateIfHasMoreThanOne() {
        final LogicError error = this.financialValidation.doValidateIfHasMoreThanOneCreditLimit(null);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void hasNoneCreditLimitsSoWontValidateIfHasMoreThanOne() {
        final List<CreditLimit> creditLimits = new LinkedList<>();
        final LogicError error = this.financialValidation.doValidateIfHasMoreThanOneCreditLimit(creditLimits);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void valueOfCreditLimitIsNotNegative() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitIsNegative(creditLimits);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void valueOfCreditLimitIsNegative() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.TRUE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitIsNegative(creditLimits);
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void wontValidateIfCreditIsNegativeBecauseTheParamIsNull() {
        final LogicError error = this.financialValidation.doValidateIfCreditLimitIsNegative(null);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void hasCreditForTheSale() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitBecameNegative(creditLimits, BigDecimal.TEN);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void hasNoCreditForTheSale() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitBecameNegative(creditLimits, BigDecimal.valueOf(100));
        Assert.assertNotNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void wontValidateIfCreditBecameNegativeBecauseTheParamIsNull() {
        final LogicError error = this.financialValidation.doValidateIfCreditLimitBecameNegative(null, null);
        Assert.assertNull(error);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void theSaleValueIsNullSoItWillValidateWithZero() {
        final List<CreditLimit> creditLimits = this.doMockAndReturnOneCreditLimit(Boolean.FALSE);
        final LogicError error = this.financialValidation.doValidateIfCreditLimitBecameNegative(creditLimits, null);
        Assert.assertNull(error);
    }

}
