package com.ws.sales.paymentmethod;

import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.validation.logicvalidation.ValidObject;

/**
 * Test all methods of {@link PaymentMethodValidation}
 * 
 * @author william.santos
 * @since V6.1.0 - 2018-08-28
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentMethodValidationUnitTest extends BaseUnitTest {

    @Mock
    private PaymentMethodDAO dao;

    private PaymentMethodValidation validation;

    @Before
    public void befor() {
        MockitoAnnotations.initMocks(this);
        this.validation = new PaymentMethodValidation(this.dao);
    }

    @Test
    public void validStandardPaymentMethodWithoutOtherStandardReturnsTrue() {
        final PaymentMethod payment = new PaymentMethod();
        payment.setStandard(Boolean.TRUE);

        Mockito.when(this.dao.getStandard()).thenReturn(null);

        final ValidObject valid = this.validation.validHasStandard(payment);
        Assert.assertNotNull(valid);
        Assert.assertTrue(valid.isValid());
    }

    @Test
    public void validNullAcceptNullOnParameterReturnsTrue() {
        final ValidObject valid = this.validation.validHasStandard(null);
        Assert.assertNotNull(valid);
        Assert.assertTrue(valid.isValid());
    }

    @Test
    public void validSamePaymentMethodIsStandardReturnsTrue() {
        final UUID pamentId = UUID.randomUUID();
        final PaymentMethod paymentInDb = new PaymentMethod();
        paymentInDb.setId(pamentId);
        paymentInDb.setStandard(Boolean.TRUE);

        Mockito.when(this.dao.getStandard()).thenReturn(paymentInDb);

        final PaymentMethod payment = new PaymentMethod();
        payment.setStandard(Boolean.TRUE);
        payment.setId(pamentId);
        final ValidObject valid = this.validation.validHasStandard(payment);

        Assert.assertNotNull(valid);
        Assert.assertTrue(valid.isValid());
    }

    @Test
    public void validStandardPaymentMethodWithOtherStandardReturnsFalse() {
        final PaymentMethod paymentStandard = new PaymentMethod();
        paymentStandard.setStandard(Boolean.TRUE);
        paymentStandard.setId(UUID.randomUUID());
        paymentStandard.setDescription("Unit-Test");

        Mockito.when(this.dao.getStandard()).thenReturn(paymentStandard);

        final PaymentMethod payment = new PaymentMethod();
        payment.setStandard(Boolean.TRUE);

        final ValidObject valid = this.validation.validHasStandard(payment);
        Assert.assertNotNull(valid);
        Assert.assertFalse(valid.isValid());
    }

}
