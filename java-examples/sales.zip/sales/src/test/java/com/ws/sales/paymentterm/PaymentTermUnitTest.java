package com.ws.sales.paymentterm;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListPaymentTerm;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermission;
import com.ws.sales.paymenttermcompanypermission.PaymentTermCompanyPermissionService;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermission;
import com.ws.sales.paymenttermcustomerpermission.PaymentTermCustomerPermissionService;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermission;
import com.ws.sales.paymenttermlocationpermission.PaymentTermLocationPermissionService;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermission;
import com.ws.sales.paymenttermuserpermission.PaymentTermUserPermissionService;

import static org.mockito.Mockito.when;

/**
 * Test all method of {@link PaymentTermResource} and {@link PaymentTermService}
 * 
 * @author william.santos
 * @since 2018-09-13
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermUnitTest extends BaseUnitTest {

    @Mock
    private PaymentTermCompanyPermissionService paymentTermCompanyPermissionService;

    @Mock
    private PaymentTermCustomerPermissionService paymentTermCustomerPermissionService;

    @Mock
    private PaymentTermLocationPermissionService paymentTermLocationPermissionService;

    @Mock
    private PaymentTermUserPermissionService paymentTermUserPermissionService;

    @Mock
    private PaymentTermDAO dao;

    @Mock
    private PaymentTermValidation paymentTermValidation;

    @Mock
    private ProductGateway productGateway;

    @InjectMocks
    private PaymentTermService service;

    @InjectMocks
    private PaymentTermResource resource;

    @Mock
    private HttpServletRequest req;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.service = new PaymentTermService(this.dao, this.paymentTermValidation, this.productGateway);
        this.resource = new PaymentTermResource(this.service, this.paymentTermCompanyPermissionService, this.paymentTermCustomerPermissionService, this.paymentTermLocationPermissionService, this.paymentTermUserPermissionService);

        when(req.getParameterMap()).thenReturn(new HashMap<>());
    }

    @Test
    public void searchPaymentTermsWithSuccess() {
        final PagedList<PaymentTerm> found = new PagedList<>();
        final PaymentTermSearch search = new PaymentTermSearch();
        search.setAcronym("UNT");
        search.setActive(new Boolean[] { true });
        search.setAvailableFirstOrder(new Boolean[] { true });
        search.setCode("UNT");
        search.setCompanyId(UUID.randomUUID());
        search.setConditions("UNT");
        search.setCustomerId(UUID.randomUUID());
        search.setDescription("UNT");
        search.setLocationId(UUID.randomUUID());
        search.setPaymentTermIds(new UUID[] { UUID.randomUUID() });
        search.setStandard(new Boolean[] { true });
        search.setUserId(UUID.randomUUID());

        when(this.dao.list(search)).thenReturn(found);

        final Response response = this.resource.search(search);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(found, response.getEntity());
    }

    @Test
    public void searchPaymentTermByPriceListWithSuccess() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());

        final PriceListPaymentTerm priceTerm = new PriceListPaymentTerm();
        priceTerm.setPaymentTermId(term.getId().toString());
        priceTerm.setId(UUID.randomUUID().toString());

        final PriceList priceList = new PriceList();
        priceList.getPaymentTerms().add(priceTerm);

        final PagedList<PaymentTerm> found = new PagedList<>(Arrays.asList(term), 1);

        final PaymentTermSearchWithPriceList search = new PaymentTermSearchWithPriceList();
        search.setPriceListId(UUID.randomUUID());
        search.setSearchWithoutPermission(Boolean.FALSE);

        when(this.productGateway.getPriceList(search.getPriceListId())).thenReturn(priceList);
        when(this.dao.list(Matchers.any(PaymentTermSearch.class))).thenReturn(found);

        final Response response = this.resource.searchPaymentTermsPriceList(search);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(found, response.getEntity());

        Mockito.verify(this.dao, Mockito.never()).listWithPermissions(Matchers.any());
        Mockito.verify(this.dao, Mockito.never()).list(search);
    }

    @Test
    public void searchPaymentTermByPermissions() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());

        final PagedList<PaymentTerm> found = new PagedList<>(Arrays.asList(term), 1);

        final PaymentTermSearchWithPriceList search = new PaymentTermSearchWithPriceList();

        when(this.dao.listWithPermissions(search)).thenReturn(found);

        final Response response = this.resource.searchPaymentTermsPriceList(search);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(found, response.getEntity());

        Mockito.verify(this.dao, Mockito.never()).list(search);
    }

    @Test
    public void searchPaymentTermWithoutPermissions() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());

        final PriceListPaymentTerm priceTerm = new PriceListPaymentTerm();
        priceTerm.setPaymentTermId(term.getId().toString());
        priceTerm.setId(UUID.randomUUID().toString());

        final PagedList<PaymentTerm> found = new PagedList<>(Arrays.asList(term), 1);

        final PaymentTermSearchWithPriceList search = new PaymentTermSearchWithPriceList();
        search.setPriceListId(UUID.randomUUID());
        search.setSearchWithoutPermission(Boolean.FALSE);

        when(this.productGateway.getPriceList(search.getPriceListId())).thenReturn(null);
        when(this.dao.listWithPermissions(Matchers.any())).thenReturn(new PagedList<>());
        when(this.dao.list(search)).thenReturn(found);

        final Response response = this.resource.searchPaymentTermsPriceList(search);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(found, response.getEntity());
        Assert.assertTrue(search.getSearchWithoutPermission());
    }

    @Test
    public void insertNewCompanyPermissionWithSuccess() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermCompanyPermission> permissions = new ArrayList<>();

        final Response response = this.resource.insertCompanyPermission(permissions, paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_CREATED, response.getStatus());

        Mockito.verify(this.paymentTermCompanyPermissionService, Mockito.times(1)).insertList(permissions, paymentTermId);
    }

    @Test
    public void listCompanyPermissionsByPaymentTermId() {
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermCompanyPermission> permissions = new PagedList<>();

        when(this.paymentTermCompanyPermissionService.getByPaymentTerm(paymentTermId)).thenReturn(permissions);

        final Response response = this.resource.listCompanyPermission(paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(permissions, response.getEntity());
    }

    @Test
    public void deleteCompanyPermissionsInBatch() {
        final Set<String> ids = new HashSet<>();

        final Response response = this.resource.batchDeleteCompanyPermission(ids);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Mockito.verify(this.paymentTermCompanyPermissionService, Mockito.times(1)).batchDelete(Matchers.any());
    }

    @Test
    public void insertCustomerPermissionsInBatch() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermCustomerPermission> permissions = new ArrayList<>();

        final Response response = this.resource.insertCustomerPermissions(permissions, paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_CREATED, response.getStatus());

        Mockito.verify(this.paymentTermCustomerPermissionService, Mockito.times(1)).insertList(permissions, paymentTermId);
    }

    @Test
    public void listCustomerPermissionsByPaymentTermId() {
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermCustomerPermission> permissions = new PagedList<>();

        when(this.paymentTermCustomerPermissionService.getByPaymentTerm(paymentTermId)).thenReturn(permissions);

        final Response response = this.resource.listCustomerPermissions(paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(permissions, response.getEntity());

        Mockito.verify(this.paymentTermCustomerPermissionService, Mockito.times(1)).getByPaymentTerm(paymentTermId);
    }

    @Test
    public void deleteCustomerPermissionsInBatch() {
        final Set<String> ids = new HashSet<>();

        final Response response = this.resource.batchDeleteCustomerPermissions(ids);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Mockito.verify(this.paymentTermCustomerPermissionService, Mockito.times(1)).batchDelete(Matchers.any());
    }

    @Test
    public void insertLocationPermissionsInBatch() {
        final UUID paymentTermId = UUID.randomUUID();
        final PaymentTermLocationPermission permission = new PaymentTermLocationPermission();
        permission.setLocationId(UUID.randomUUID());
        final List<PaymentTermLocationPermission> permissions = new ArrayList<>();
        permissions.add(permission);

        final Response response = this.resource.insertLocationPermission(permissions, paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_CREATED, response.getStatus());

        Mockito.verify(this.paymentTermLocationPermissionService, Mockito.times(1)).insertList(permissions, paymentTermId);

        Assert.assertNotNull(permission.getPaymentTerm());
        Assert.assertEquals(permission.getPaymentTerm().getId(), paymentTermId);
    }

    @Test
    public void listLocationPermissionsByPaymentTermId() {
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermLocationPermission> permissions = new PagedList<>();

        when(this.paymentTermLocationPermissionService.getByPaymentTerm(paymentTermId)).thenReturn(permissions);

        final Response response = this.resource.listLocationPermission(paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
        Assert.assertEquals(permissions, response.getEntity());
    }

    @Test
    public void deleteLocationPermissionsInBatch() {
        final Set<String> ids = new HashSet<>();

        final Response response = this.resource.batchDeleteLocationPermission(ids);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Mockito.verify(this.paymentTermLocationPermissionService, Mockito.times(1)).batchDelete(Matchers.any());
    }

    @Test
    public void insertUserPermissionsInBatch() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermUserPermission> permissions = new ArrayList<>();

        final Response response = this.resource.insertUserPermission(permissions, paymentTermId.toString());
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_CREATED, response.getStatus());

        Mockito.verify(this.paymentTermUserPermissionService, Mockito.times(1)).insertList(permissions, paymentTermId);
    }

    @Test
    public void listUserPermissionsByPaymentTermId() {
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermUserPermission> permissions = new PagedList<>();

        when(this.paymentTermUserPermissionService.getByPaymentTerm(paymentTermId, req)).thenReturn(permissions);

        final Response response = this.resource.listUserPermission(paymentTermId.toString(), req);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());
    }

    @Test
    public void deleteUserLocationsPermissionsInBatch() {
        final Set<String> ids = new HashSet<>();

        final Response response = this.resource.batchDeleteUserPermission(ids);
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.SC_OK, response.getStatus());

        Mockito.verify(this.paymentTermUserPermissionService, Mockito.times(1)).batchDelete(Matchers.any());
    }

    @Test
    public void paymentTermInactiveReturnsFalse() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());
        term.setActive(Boolean.FALSE);

        when(this.dao.getStatePaymentTerm(term.getId())).thenReturn(term);

        final Boolean active = this.service.paymentTermIsActive(term.getId());
        Assert.assertNotNull(active);
        Assert.assertFalse(active);
    }

    @Test
    public void paymentTermActiveReturnsTrue() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());
        term.setActive(Boolean.TRUE);

        when(this.dao.getStatePaymentTerm(term.getId())).thenReturn(term);

        final Boolean active = this.service.paymentTermIsActive(term.getId());
        Assert.assertNotNull(active);
        Assert.assertTrue(active);
    }

    @Test
    public void paymentTermNonExistsReturnsTrue() {
        final UUID paymentTermId = UUID.randomUUID();

        when(this.dao.getStatePaymentTerm(paymentTermId)).thenReturn(null);

        final Boolean active = this.service.paymentTermIsActive(paymentTermId);
        Assert.assertNotNull(active);
        Assert.assertTrue(active);
    }

    @Test
    public void insertNewPaymentTermWithSuccess() throws Exception {
        final PaymentTerm term = new PaymentTerm();

        Mockito.doAnswer(invocation -> {
            final PaymentTerm argument = invocation.getArgumentAt(0, PaymentTerm.class);
            argument.setId(UUID.randomUUID());
            return argument;
        }).when(this.dao).insert(term);

        this.service.insert(term);
        Assert.assertNotNull(term.getId());
    }

    @Test
    public void insertNewPaymentTermWithException() throws Exception {
        final PaymentTerm term = new PaymentTerm();

        Mockito.doThrow(ConstraintViolationException.class).when(this.paymentTermValidation).throwFoundErrors();
        try {
            this.service.insert(term);
        } catch (final ConstraintViolationException e) {
            // Don't nothing, exception is expected
        }
        Mockito.verify(this.dao, Mockito.never()).insert(term);
    }

    @Test
    public void updateExistentPaymentTermWithSuccess() throws Exception {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());

        when(this.dao.findById(term.getId())).thenReturn(term);

        this.service.update(term);

        Mockito.verify(this.dao, Mockito.times(1)).update(term);
    }

    @Test
    public void updateWithInvalidPaymentTermExpectedException() throws Exception {
        final PaymentTerm term = new PaymentTerm();

        Mockito.doThrow(ConstraintViolationException.class).when(this.paymentTermValidation).throwFoundErrors();

        try {
            this.service.update(term);
        } catch (final ConstraintViolationException e) {
            // Don't nothing, exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).update(term);
    }

    /**
     * Testing of map to convert {@link PaymentTerm} to {@link PaymentTermDTO}
     */
    @Test
    public void convertPaymentTermToPaymentTermDTO() {
        final PaymentTerm term = new PaymentTerm();
        term.setId(UUID.randomUUID());
        term.setDescription("Unit-Test");

        final PaymentTermDTO dto = new PojoConverter().convert(PaymentTermDTO.class, term);
        Assert.assertNotNull(dto);
        Assert.assertEquals(term.getId(), dto.getId());
        Assert.assertEquals(term.getDescription(), dto.getDescription());
    }
}
