package com.ws.sales.ordertype;

import java.util.UUID;

import com.ws.commons.server.validation.exception.LogicError;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;

/**
 * Test all methods of {@link OrderTypeValidation}
 * 
 * @author william.santos
 * @since V7.0.0 - 2018-09-11
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class OrderTypeValidationUnitTest extends BaseUnitTest {

    @Mock
    private OrderTypeDAO dao;

    private OrderTypeValidation validation;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.validation = new OrderTypeValidation(this.dao);
    }

    @Test
    public void validStandardWithExistOtherReturnsFalse() {
        final UUID standardId = UUID.randomUUID();
        final OrderType standard = new OrderType();
        standard.setStandard(Boolean.TRUE);
        standard.setId(standardId);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final OrderType orderType = new OrderType();
        orderType.setStandard(Boolean.TRUE);

        final LogicError valid = this.validation.validHasStandard(orderType);
        Assert.assertNotNull(valid);
    }

    @Test
    public void validStandardWithNonexistOtherReturnsTrue() {
        Mockito.when(this.dao.getStandard()).thenReturn(null);

        final OrderType orderType = new OrderType();
        orderType.setStandard(Boolean.TRUE);

        final LogicError valid = this.validation.validHasStandard(orderType);
        Assert.assertNull(valid);
    }

    @Test
    public void validUpdateOnStandardReturnsTrue() {
        final UUID standardId = UUID.randomUUID();
        final OrderType standard = new OrderType();
        standard.setStandard(Boolean.TRUE);
        standard.setId(standardId);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final OrderType orderType = new OrderType();
        orderType.setId(standardId);
        orderType.setStandard(Boolean.TRUE);

        final LogicError valid = this.validation.validHasStandard(orderType);
        Assert.assertNull(valid);
    }

    @Test
    public void validNotStandardReturnsTrue() {
        final UUID standardId = UUID.randomUUID();
        final OrderType standard = new OrderType();
        standard.setStandard(Boolean.TRUE);
        standard.setId(standardId);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final OrderType orderType = new OrderType();
        orderType.setStandard(Boolean.FALSE);
        orderType.setId(standardId);

        final LogicError valid = this.validation.validHasStandard(orderType);
        Assert.assertNull(valid);
    }
}
