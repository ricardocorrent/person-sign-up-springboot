package com.ws.sales.orderservice;

import com.ws.commons.server.validation.entityvalidator.EValidationType;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.product.model.PriceListService;
import com.ws.product.model.Service;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.order.SalesOrderBuilder;
import com.ws.sales.order.SalesOrderDAO;
import com.ws.sales.orderparameter.OrderParameterService;
import com.ws.sales.util.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

/**
 * @author Roberto Filho
 * @since 8.5.0 2019-05-30
 */
@RunWith(MockitoJUnitRunner.class)
public class SalesOrderServiceValidatorUnitTest {

    @Mock private SalesOrderDAO salesOrderDAO;

    @Mock private SalesOrderServiceDAO salesOrderServiceDAO;

    @Mock private ProductGateway productGateway;

    @Mock private OrderParameterService parameterService;

    @InjectMocks
    private SalesOrderServiceValidator validator;

    private static final UUID SALES_ORDER_ID = UUID.fromString("41b4fd0b-a4f1-468d-8835-f679f9d2125e");
    private static final UUID SALES_ORDER_SERVICE_ID = UUID.fromString("c36314ab-1358-4a9f-9e46-d53c44f9cf27");
    private static final UUID PRICE_LIST_ID = UUID.fromString("5b3c8a3c-a691-4455-a7fa-f29d23a900f9");
    private static final UUID SERVICE_ID = UUID.fromString("0e9e76fb-f609-49c3-849f-570ca0ce476e");

    @Test
    public void shouldGenerateValidationErrorsOnInsertWhenIncreaseValueIsInconsistent() {
        shouldValidateIncreaseValue(EValidationType.INSERT);
    }

    @Test
    public void shouldGenerateValidationErrorsOnUpdateWhenIncreaseValueIsInconsistent() {
        shouldValidateIncreaseValue(EValidationType.UPDATE);
    }

    @Test
    public void shouldGenerateValidationErrorsOnInsertWhenDiscountValueIsInconsistent() {
        validateDiscountInconsistent(EValidationType.INSERT);
    }

    @Test
    public void shouldGenerateValidationErrorsOnUpdateWhenDiscountValueIsInconsistent() {
        validateDiscountInconsistent(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotGenerateValidationErrorsOnInsertWhenDiscountValuesAreCorrect() {
        noErrorsWhenDiscountCorrect(EValidationType.INSERT);
    }

    @Test
    public void shouldNotGenerateValidationErrorsOnUpdateWhenDiscountValuesAreCorrect() {
        noErrorsWhenDiscountCorrect(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotGenerateValidationErrorsOnInsertWhenIncreaseValuesAreCorrect() {
        noErrorsWhenIncreaseCorrect(EValidationType.INSERT);
    }

    @Test
    public void shouldNotGenerateValidationErrorsOnUpdateWhenIncreaseValuesAreCorrect() {
        noErrorsWhenIncreaseCorrect(EValidationType.UPDATE);
    }

    @Test
    public void shouldGenerateErrorsWhenBothIncreaseAndDiscountValuesAreInformedOnInsert() {
        final Consumer<Set<LogicError>> assertions = validationErrors -> {
            assertThat(validationErrors, hasSize(4));
            assertThat(validationErrors, allOf(
                    hasItem(hasProperty("field", equalTo("discount"))),
                    hasItem(hasProperty("field", equalTo("discountPercentage"))),
                    hasItem(hasProperty("field", equalTo("increaseValue"))),
                    hasItem(hasProperty("field", equalTo("increasePercentage")))
            ));
        };

        runValidationAssertions(
                EValidationType.INSERT,
                orderServiceWithIncreaseAndDiscountValues(),
                assertions
        );
    }

    @Test
    public void shouldNotAllowUpdatingFinishedOrder() {
        Supplier<SalesOrderService> finishedOrder = () -> {
            final SalesOrder order = createSalesOrder();
            order.setDraft(false);
            return orderServiceWithDefaultValues(order).build();
        };

        runValidationAssertions(EValidationType.INSERT, finishedOrder.get(), logicErrors -> {
            assertThat(logicErrors, hasSize(1));
            assertThat(logicErrors, allOf(
                    hasItem(hasProperty("field", equalTo("service"))),
                    hasItem(hasProperty("message", equalTo("order.finalized")))
            ));
        });
    }

    @Test
    public void shouldNotAllowToInsertServiceWhenServiceIsInactive() {
        validateServiceIsInactive(EValidationType.INSERT);
    }

    @Test
    public void shouldNotAllowToUpdateServiceWhenServiceIsInactive() {
        validateServiceIsInactive(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotAllowToInsertServiceWhenServiceDoesNotExist() {
        validateServiceExists(EValidationType.INSERT);
    }

    @Test
    public void shouldNotAllowToUpdateServiceWhenServiceDoesNotExist() {
        validateServiceExists(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotAllowSameServiceTwiceInTheSameOrderOnInsert() {
        notHaveTheSameServiceTwice(EValidationType.INSERT);
    }

    @Test
    public void shouldNotAllowSameServiceTwiceInTheSameOrderOnUpdate() {
        notHaveTheSameServiceTwice(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotAllowIncreaseValuesOnInsertWhenThereIsNoIncrease() {
        noIncreaseValuesWhenNoActualIncrease(EValidationType.INSERT);
    }

    @Test
    public void shouldNotAllowIncreaseValuesOnUpdateWhenThereIsNoIncrease() {
        noIncreaseValuesWhenNoActualIncrease(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotAllowDiscountValuesOnInsertWhenThereIsNoDiscount() {
        noDiscountValuesWhenNoActualDiscount(EValidationType.INSERT);
    }

    @Test
    public void shouldNotAllowDiscountValuesOnUpdateWhenThereIsNoDiscount() {
        noDiscountValuesWhenNoActualDiscount(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotErrorOnInsertWhenSalesOrderServiceIsEmpty() {
        noErrorWhenSalesOrderServiceIsEmpty(EValidationType.INSERT);
    }

    @Test
    public void shouldNotErrorOnUpdateWhenSalesOrderServiceIsEmpty() {
        noErrorWhenSalesOrderServiceIsEmpty(EValidationType.UPDATE);
    }

    @Test
    public void shouldNotErrorWhenOriginalPrice6AndSalesPrice800AndIncreasePercentage13233with333333With6decimalPlaces() {
        final Consumer<Set<LogicError>> assertions = logicErrors -> assertThat(logicErrors, emptyCollectionOf(LogicError.class));

        final SalesOrderService salesOrderService = orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(BigDecimal.valueOf(6))
                .salesPrice(BigDecimal.valueOf(800))
                .increasePercentage(new BigDecimal("13233.333333"))
                .increaseValue(BigDecimal.valueOf(794))
                .build();

        runValidationAssertions(EValidationType.INSERT, salesOrderService, assertions);
    }

    @Test
    public void shouldNotErrorWhenOriginalPrice6AndSalesPrice1pt3AndDiscountPercentage78with333333And6decimalPlaces() {
        final Consumer<Set<LogicError>> assertions = logicErrors -> assertThat(logicErrors, emptyCollectionOf(LogicError.class));

        final SalesOrderService salesOrderService = orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(BigDecimal.valueOf(6))
                .salesPrice(BigDecimal.valueOf(1.3))
                .discountPercentage(new BigDecimal("78.333333"))
                .discount(BigDecimal.valueOf(4.7))
                .build();

        runValidationAssertions(EValidationType.INSERT, salesOrderService, assertions);
    }

    private void noErrorWhenSalesOrderServiceIsEmpty(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = logicErrors -> assertThat(logicErrors, anything());

        final SalesOrderService emptySalesOrderService = SalesOrderService.builder()
                .salesOrder(createSalesOrder())
                .build();

        runValidationAssertions(insertOrUpdate, emptySalesOrderService, assertions);
    }

    private void notHaveTheSameServiceTwice(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = errorsFromValidation -> {
            assertThat(errorsFromValidation, hasSize(1));
            assertThat(errorsFromValidation, allOf(
                    hasItem(hasProperty("field", equalTo("service"))),
                    hasItem(hasProperty("message", equalTo("order.service.alreadyExist")))
            ));
        };

        final SalesOrderService dbSalesOrderService = orderServiceWithDefaultValues(createSalesOrder(), SALES_ORDER_SERVICE_ID);

        when(salesOrderServiceDAO.findByService(SALES_ORDER_ID, SERVICE_ID))
                .thenReturn(dbSalesOrderService);

        final boolean isInsert = insertOrUpdate == EValidationType.INSERT;
        runValidationAssertions(
                insertOrUpdate,
                orderServiceWithDefaultValues(createSalesOrder(), isInsert ? null : UUID.randomUUID()),
                assertions
        );
    }

    private void noDiscountValuesWhenNoActualDiscount(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = errorsFromValidation -> {
            assertThat(errorsFromValidation, hasSize(2));
            assertThat(errorsFromValidation, allOf(
                    hasItem(hasProperty("field", equalTo("discount"))),
                    hasItem(hasProperty("field", equalTo("discountPercentage")))
            ));
        };

        runValidationAssertions(
                insertOrUpdate,
                getOrderServiceWithDiscountValuesButNoDiscount(),
                assertions
        );
    }

    private void noIncreaseValuesWhenNoActualIncrease(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = errorsFromValidation -> {
            assertThat(errorsFromValidation, hasSize(2));
            assertThat(errorsFromValidation, allOf(
                    hasItem(hasProperty("field", equalTo("increaseValue"))),
                    hasItem(hasProperty("field", equalTo("increasePercentage")))
            ));
        };

        runValidationAssertions(
                insertOrUpdate,
                getOrderServiceWithIncreaseValuesButNoIncrease(),
                assertions
        );
    }

    private SalesOrderService getOrderServiceWithIncreaseValuesButNoIncrease() {
        return orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(BigDecimal.TEN)
                .salesPrice(BigDecimal.TEN)
                .increaseValue(BigDecimal.valueOf(1))
                .build();
    }

    private SalesOrderService getOrderServiceWithDiscountValuesButNoDiscount() {
        return orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(BigDecimal.TEN)
                .salesPrice(BigDecimal.TEN)
                .discountPercentage(BigDecimal.valueOf(1))
                .discount(BigDecimal.valueOf(10))
                .build();
    }

    private void validateServiceExists(final EValidationType insertOrUpdate) {
        final SalesOrder order = createSalesOrder();

        final SalesOrderService build = orderServiceWithDefaultValues(order).build();

        mockService(null);
        mockPriceList(null);
        mockSalesOrder(order);
        mockDecimalPlacesOrderParameter();

        validator.validate(build, insertOrUpdate);

        final Set<LogicError> validationErrors = validator.getValidationErrors();

        assertThat(validationErrors, hasSize(1));
        assertThat(validationErrors, allOf(
                hasItem(hasProperty("field", equalTo("service"))),
                hasItem(hasProperty("message", equalTo("order.service.serviceNotFound")))
        ));
    }

    private void validateServiceIsInactive(final EValidationType insertOrUpdate) {
        final SalesOrder order = createSalesOrder();

        final SalesOrderService build = orderServiceWithDefaultValues(order).build();

        final PriceListService priceListService = priceListServiceWithInactiveService();
        final Service service = priceListService.getService();

        mockService(service);
        mockPriceList(priceListService);
        mockSalesOrder(order);
        mockDecimalPlacesOrderParameter();

        validator.validate(build, insertOrUpdate);

        final Set<LogicError> validationErrors = validator.getValidationErrors();

        assertThat(validationErrors, hasSize(1));
        assertThat(validationErrors, allOf(
                hasItem(hasProperty("field", equalTo("service"))),
                hasItem(hasProperty("message", equalTo("order.service.inactive")))
        ));
    }

    private void validateDiscountInconsistent(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = validationErrors -> {
            assertThat(validationErrors, hasSize(2));
            assertThat(validationErrors, allOf(
                    hasItem(hasProperty("field", equalTo("discount"))),
                    hasItem(hasProperty("field", equalTo("discountPercentage")))
            ));
        };

        runValidationAssertions(
                insertOrUpdate,
                orderServiceWithInvalidDiscountValues(),
                assertions
        );
    }

    private void noErrorsWhenDiscountCorrect(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = validationErrors -> assertThat(validationErrors, hasSize(0));

        runValidationAssertions(
                insertOrUpdate,
                orderServiceWithCorrectDiscountValues(),
                assertions
        );
    }

    private void noErrorsWhenIncreaseCorrect(final EValidationType insertOrUpdate) {
        final Consumer<Set<LogicError>> assertions = validationErrors -> assertThat(validationErrors, hasSize(0));

        runValidationAssertions(
                insertOrUpdate,
                orderServiceWithCorrectIncreaseValues(),
                assertions
        );
    }

    private void shouldValidateIncreaseValue(final EValidationType validationType) {
        final Consumer<Set<LogicError>> assertions = errorsFromValidation -> {
            assertThat(errorsFromValidation, hasSize(2));
            assertThat(errorsFromValidation, allOf(
                    hasItem(hasProperty("field", equalTo("increaseValue"))),
                    hasItem(hasProperty("field", equalTo("increasePercentage")))
            ));
        };

        runValidationAssertions(
                validationType,
                getOrderServiceWithInvalidIncreaseValues(),
                assertions
        );
    }

    private PriceListService priceListServiceWithInactiveService() {
        final PriceListService priceListService = createPriceListService();
        priceListService.getService().setActive(false);
        return priceListService;
    }

    private PriceListService createPriceListService() {
        final PriceListService priceListService = new PriceListService();
        final Service service = new Service();

        service.setId(SERVICE_ID.toString());
        service.setActive(true);
        priceListService.setService(service);
        return priceListService;
    }

    private void mockDecimalPlacesOrderParameter() {
        when(parameterService.getValueByKey(Constants.FIELD_PARAMETER_DECIMAL_PLACES)).thenReturn("6");
    }

    private void mockSalesOrder(final SalesOrder order) {
        when(salesOrderDAO.findById(SALES_ORDER_ID)).thenReturn(order);
    }

    private void mockPriceList(final PriceListService priceListService) {
        when(productGateway.getServiceFromPriceList(PRICE_LIST_ID, SERVICE_ID)).thenReturn(priceListService);
    }

    private SalesOrderService getOrderServiceWithInvalidIncreaseValues() {
        final BigDecimal originalPrice = BigDecimal.valueOf(10);
        final BigDecimal salesPrice = BigDecimal.valueOf(11);
        final BigDecimal increasePercentage = BigDecimal.valueOf(11);
        final BigDecimal increaseValue = BigDecimal.valueOf(1);
        final BigDecimal totalValue = BigDecimal.valueOf(110);

        return orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(originalPrice)
                .salesPrice(salesPrice)
                .increasePercentage(increasePercentage)
                .increaseValue(increaseValue)
                .totalValue(totalValue)
                .build();
    }

    private SalesOrderService orderServiceWithInvalidDiscountValues() {
        final BigDecimal originalPrice = BigDecimal.valueOf(10);
        final BigDecimal salesPrice = BigDecimal.valueOf(9);
        final BigDecimal discountPercentage = BigDecimal.valueOf(11);
        final BigDecimal discountValue = BigDecimal.valueOf(1);
        final BigDecimal totalValue = BigDecimal.valueOf(110);

        return orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(originalPrice)
                .salesPrice(salesPrice)
                .discountPercentage(discountPercentage)
                .discount(discountValue)
                .totalValue(totalValue)
                .build();
    }

    private SalesOrderService orderServiceWithCorrectDiscountValues() {
        final BigDecimal originalPrice = BigDecimal.valueOf(10);
        final BigDecimal salesPrice = BigDecimal.valueOf(9);
        final BigDecimal discountPercentage = BigDecimal.valueOf(10);
        final BigDecimal discountValue = BigDecimal.valueOf(1);
        final BigDecimal totalValue = BigDecimal.valueOf(9);

        final SalesOrderService service = orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(originalPrice)
                .salesPrice(salesPrice)
                .discountPercentage(discountPercentage)
                .discount(discountValue)
                .totalValue(totalValue)
                .build();
        service.setId(SALES_ORDER_SERVICE_ID);
        return service;
    }

    private SalesOrderService orderServiceWithCorrectIncreaseValues() {
        final BigDecimal originalPrice = BigDecimal.valueOf(10);
        final BigDecimal salesPrice = BigDecimal.valueOf(11);
        final BigDecimal increasePercentage = BigDecimal.valueOf(10);
        final BigDecimal increaseValue = BigDecimal.valueOf(1);
        final BigDecimal totalValue = BigDecimal.valueOf(11);

        final SalesOrderService service = orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(originalPrice)
                .salesPrice(salesPrice)
                .increasePercentage(increasePercentage)
                .increaseValue(increaseValue)
                .totalValue(totalValue)
                .build();
        service.setId(SALES_ORDER_SERVICE_ID);
        return service;
    }

    private SalesOrderService orderServiceWithIncreaseAndDiscountValues() {
        final BigDecimal originalPrice = BigDecimal.valueOf(10);
        final BigDecimal salesPrice = BigDecimal.valueOf(11);
        final BigDecimal percentage = BigDecimal.valueOf(10);
        final BigDecimal value = BigDecimal.valueOf(1);
        final BigDecimal totalValue = BigDecimal.valueOf(11);

        final SalesOrderService service = orderServiceWithDefaultValues(createSalesOrder())
                .originalPrice(originalPrice)
                .salesPrice(salesPrice)
                .increasePercentage(percentage)
                .increaseValue(value)
                .discount(value)
                .discountPercentage(value)
                .totalValue(totalValue)
                .build();
        service.setId(SALES_ORDER_SERVICE_ID);
        return service;
    }

    private SalesOrderService.SalesOrderServiceBuilder orderServiceWithDefaultValues(final SalesOrder order) {
        return SalesOrderService.builder()
                .repetitions(BigDecimal.ONE)
                .quantity(BigDecimal.ONE)
                .totalQuantity(BigDecimal.ONE)
                .originalPrice(BigDecimal.TEN)
                .salesPrice(BigDecimal.TEN)
                .totalValue(BigDecimal.TEN)
                .serviceId(SERVICE_ID)
                .serviceDescription("Serviço")
                .salesOrder(order);
    }

    private SalesOrderService orderServiceWithDefaultValues(SalesOrder order, UUID id) {
        final SalesOrderService service = orderServiceWithDefaultValues(order).build();
        service.setId(id);
        return service;
    }

    private void runValidationAssertions(EValidationType insertOrUpdate, SalesOrderService salesOrderService, Consumer<Set<LogicError>> assertionLogic) {
        final PriceListService priceListService = createPriceListService();
        final Service service = priceListService.getService();

        mockService(service);
        mockPriceList(priceListService);
        mockSalesOrder(salesOrderService.getSalesOrder());
        mockDecimalPlacesOrderParameter();

        validator.validate(salesOrderService, insertOrUpdate);

        final Set<LogicError> validationErrors = validator.getValidationErrors();

        assertionLogic.accept(validationErrors);
    }

    private void mockService(final Service service) {
        when(productGateway.getService(SERVICE_ID)).thenReturn(service);
    }

    private SalesOrder createSalesOrder() {
        return SalesOrderBuilder.aSalesOrder()
                .withId(SALES_ORDER_ID)
                .withPriceListId(PRICE_LIST_ID)
                .withDraft(true)
                .build();
    }
}