package com.ws.sales.ordertype;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.MockedSecurityManager;
import com.ws.sales.ordertype.OrderType;
import com.ws.sales.ordertype.OrderTypeDAO;
import com.ws.sales.ordertype.OrderTypeSearch;

/**
 * Test all mehods of {@link OrderTypeDAO}
 * 
 * @author william.santos
 * @since 2018-09-11
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = { SessionScoped.class, RequestScoped.class }, projectStage = ProjectStage.IntegrationTest.class)
public class OrderTypeDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private OrderTypeDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, OrderTypeDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void searchByDescriptionActiveStandardAndAvailableForFirstOrderReturnsList() {
        final String descriptionToFind = "bibendum, felis sed";

        final OrderTypeSearch search = new OrderTypeSearch();
        search.setActive(new Boolean[] { true });
        search.setAvailableFirstOrder(new Boolean[] { true });
        search.setDescription(descriptionToFind);
        search.setStandard(new Boolean[] { true });

        final PagedList<OrderType> list = this.dao.list(search);
        Assert.assertNotNull(list);

        list.getItems().forEach(found -> {
            Assert.assertEquals(Boolean.TRUE, found.getActive());
            Assert.assertEquals(Boolean.TRUE, found.getAvailableFirstOrder());
            Assert.assertEquals(Boolean.TRUE, found.getStandard());
            Assert.assertTrue(found.getDescription().contains(descriptionToFind));
        });
    }

    @Test
    public void searchByDescriptionReturnsLis() {
        final OrderTypeSearch search = new OrderTypeSearch();
        search.setDescription("a");
        search.setActive(new Boolean[0]);
        search.setAvailableFirstOrder(new Boolean[0]);
        search.setStandard(new Boolean[0]);

        final PagedList<OrderType> list = this.dao.list(search);
        Assert.assertNotNull(list);

        list.getItems().forEach(found -> {
            Assert.assertTrue(found.getDescription().contains("a"));
        });
    }

    @Test
    public void searchByActiveReturnsList() {
        final OrderTypeSearch search = new OrderTypeSearch();
        search.setActive(new Boolean[] { true });

        final PagedList<OrderType> list = this.dao.list(search);
        Assert.assertNotNull(list);

        list.getItems().forEach(found -> {
            Assert.assertEquals(Boolean.TRUE, found.getActive());
        });
    }

    @Test
    public void searchByAvailableFirstOrderReturnsList() {
        final OrderTypeSearch search = new OrderTypeSearch();
        search.setAvailableFirstOrder(new Boolean[] { true });

        final PagedList<OrderType> list = this.dao.list(search);
        Assert.assertNotNull(list);

        list.getItems().forEach(found -> {
            Assert.assertEquals(Boolean.TRUE, found.getAvailableFirstOrder());
        });
    }

    @Test
    public void searchByStandardReturnsList() {
        final OrderTypeSearch search = new OrderTypeSearch();
        search.setStandard(new Boolean[] { true });

        final PagedList<OrderType> list = this.dao.list(search);
        Assert.assertNotNull(list);

        list.getItems().forEach(found -> {
            Assert.assertEquals(Boolean.TRUE, found.getStandard());
        });
    }

    @Test
    public void searchByStandardReturnsOne() {
        final OrderType orderType = this.dao.getStandard();
        Assert.assertNotNull(orderType);
        Assert.assertEquals(Boolean.TRUE, orderType.getStandard());
    }

    @Test
    public void checkNonexistentOrderTypeReturnsFalse() {
        final boolean exist = this.dao.orderTypeExists(UUID.randomUUID());
        Assert.assertFalse(exist);
    }

    @Test
    public void checkExistentOrderTypeReturnsTrue() {
        final boolean exist = this.dao.orderTypeExists(UUID.fromString("adb209fc-f1b5-425c-93c9-562727996da0"));
        Assert.assertTrue(exist);
    }

    @Test
    public void loadOnlyActiveOnOrderTypeReturnOrderType() {
        final OrderType orderType = this.dao.getStateOrdertype(UUID.fromString("adb209fc-f1b5-425c-93c9-562727996da0"));
        Assert.assertNotNull(orderType);
        Assert.assertTrue(orderType.getActive());
    }

    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new HashSet<>();
        files.add("order_type.xml");
        return files;
    }
}
