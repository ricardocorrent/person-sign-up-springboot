package com.ws.sales.externalvalidation;

import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.sales.external.user.UserValidation;
import com.ws.sales.external.user.UserGateway;
import com.ws.user.model.Hierarchy;
import com.ws.user.model.User;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SimpleSession;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.UUID;

/**
 * Tests for customer and location validations
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-18
 */
@RunWith(MockitoJUnitRunner.class)
public class UserValidationUnitTest {

    @InjectMocks
    private UserValidation userValidation;

    @Mock
    private UserGateway userGateway;

    @Mock
    private UserContext userContext;

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userExistAndIsActive() {
        final User user = new User();
        user.setActive(Boolean.TRUE);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(user);
        final LogicError logicError = userValidation.doValidateUserCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userExistAndIsInactive() {
        final User user = new User();
        user.setActive(Boolean.FALSE);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(user);
        final LogicError logicError = userValidation.doValidateUserCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userDoesNotExist() {
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(null);
        final LogicError logicError = userValidation.doValidateUserCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = userValidation.doValidateUserCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userProfessionalExistAndIsActive() {
        final User user = new User();
        user.setActive(Boolean.TRUE);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(user);
        final LogicError logicError = userValidation.doValidateProfessionalCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userProfessionalExistAndIsInactive() {
        final User user = new User();
        user.setActive(Boolean.FALSE);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(user);
        final LogicError logicError = userValidation.doValidateProfessionalCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userProfessionalDoesNotExist() {
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(null);
        final LogicError logicError = userValidation.doValidateProfessionalCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userProfessionalCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = userValidation.doValidateProfessionalCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate where userId is equal to logged user id and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void UserIsTheSameAsLoggedUser() {
        final UUID userId = UUID.randomUUID();
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, userId.toString());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Assert.assertNull(userValidation.doValidateIfInformedUserIsTheSameAsLoggedUser(userId));
    }

    /**
     * Tries to validate where userId is not equal to logged user id and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void userIsNotTheSameAsLoggedUser() {
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, UUID.randomUUID().toString());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Assert.assertNotNull(userValidation.doValidateIfInformedUserIsTheSameAsLoggedUser(UUID.randomUUID()));
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void loggedUserCanNotValidateBecauseParamIdIsNull() {
        Assert.assertNull(userValidation.doValidateIfInformedUserIsTheSameAsLoggedUser(null));
    }

    /**
     * tries to validate where the professional is an admin. It must not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void professionalAdminBelongsToUserHierarchy() {
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ADMIN_CONTEXT, true);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Assert.assertNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(UUID.randomUUID()));
    }

    /**
     * tries to validate where the professional is the logged user. It must not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void professionalIsNotAdminAndIsTheLoggedUser() {
        final Session session = new SimpleSession();
        final UUID professionalId = UUID.randomUUID();
        session.setAttribute(Constants.FIELD_USER_ADMIN_CONTEXT, false);
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, professionalId.toString());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Assert.assertNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(professionalId));
    }

    /**
     * tries to validate where the professional belongs to the logged user hierarchy. It must not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void professionalIsNotAdminIsNotTheLoggedUserAndBelongsToHierarchy() {
        final UUID professionalId = UUID.randomUUID();
        final User professional = new User();
        professional.setId(professionalId.toString());
        final User loggedUser = new User();
        loggedUser.setId(UUID.randomUUID().toString());
        loggedUser.getUserHierarchies().add(this.getHierarchy(professionalId));
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ADMIN_CONTEXT, false);
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, loggedUser.getId());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(loggedUser);
        Assert.assertNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(professionalId));
    }

    /**
     * tries to validate where the professional does not belong to the logged user. It must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void professionalIsNotAdminIsNotTheLoggedUserAndDoesNotBelongToHierarchy() {
        final UUID professionalId = UUID.randomUUID();
        final User professional = new User();
        professional.setId(professionalId.toString());
        final User loggedUser = new User();
        loggedUser.setId(UUID.randomUUID().toString());
        loggedUser.getUserHierarchies().add(this.getHierarchy(UUID.randomUUID()));
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ADMIN_CONTEXT, false);
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, loggedUser.getId());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(loggedUser);
        Assert.assertNotNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(professionalId));
    }

    /**
     * tries to validate where the logged user does not have an hierarchy. It must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void professionalIsNotAdminIsNotTheLoggedUserAndThereIsNoHierarchy() {
        final UUID professionalId = UUID.randomUUID();
        final User professional = new User();
        professional.setId(professionalId.toString());
        final User loggedUser = new User();
        loggedUser.setId(UUID.randomUUID().toString());
        loggedUser.getUserHierarchies().clear();
        final Session session = new SimpleSession();
        session.setAttribute(Constants.FIELD_USER_ADMIN_CONTEXT, false);
        session.setAttribute(Constants.FIELD_USER_ID_CONTEXT, loggedUser.getId());
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(userGateway.getUser(Mockito.any())).thenReturn(loggedUser);
        Assert.assertNotNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(professionalId));
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    @Test
    public void canNotValidateHierarchyBecauseUserIsNull() {
        Assert.assertNull(userValidation.doValidateProfessionalBelongsToUserHierarchy(null));
    }


    /**
     * Creates a new hierarchy entity
     *
     * @param professionalId to set the user entity
     * @return hierarchy entity with a new user
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-18
     */
    private Hierarchy getHierarchy(final UUID professionalId) {
        final User user = new User();
        user.setId(professionalId.toString());
        final Hierarchy hierarchy = new Hierarchy();
        hierarchy.setUpperUser(user);
        return hierarchy;
    }

}
