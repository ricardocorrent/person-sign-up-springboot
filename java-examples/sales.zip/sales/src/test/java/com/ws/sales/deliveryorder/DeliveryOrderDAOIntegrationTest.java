package com.ws.sales.deliveryorder;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.sollar.test.BaseIntegrationTest;
import com.ws.commons.PersistenceProperties;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.MockedSecurityManager;

/**
 * Test all methdos of {@link DeliveryOrderDAO}
 * 
 * @author william.santos
 * @since 2018-09-10
 * @version 1.0.0
 */
@RunWith(CdiTestRunner.class)
@TestControl(startScopes = { SessionScoped.class, RequestScoped.class }, projectStage = ProjectStage.IntegrationTest.class)
public class DeliveryOrderDAOIntegrationTest extends BaseIntegrationTest {

    private static final String DEFAULT_TENANT = "public";

    @Inject
    private DeliveryOrderDAO dao;

    /**
     * Execute before each test
     *
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        super.setUp();
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
        final Subject subject = SecurityUtils.getSubject();
        subject.getSession().setAttribute(UserContext.TENANT_ATTRIBUTE, ConfigResolver.getPropertyValue(PersistenceProperties.DB_SCHEMA, DeliveryOrderDAOIntegrationTest.DEFAULT_TENANT));
    }

    @Test
    public void searchDeliveryByOrderId() {
        final DeliveryOrderSearch search = new DeliveryOrderSearch();
        search.setOrderId(UUID.fromString("92327ae7-e1c8-4e54-9677-eb8b36e56268"));// OrderId present in delivery_order.xml

        final PagedList<DeliveryOrder> deliveries = this.dao.search(search);
        Assert.assertNotNull(deliveries);
        Assert.assertEquals(1, deliveries.getCount().intValue());
    }

    @Test
    public void searchDeliveryById() {
        final DeliveryOrderSearch search = new DeliveryOrderSearch();
        search.setId(UUID.fromString("89327eb6-6df8-467f-8907-0232e60f466d"));// Id present in delivery_order.xml

        final PagedList<DeliveryOrder> deliveries = this.dao.search(search);
        Assert.assertNotNull(deliveries);
        Assert.assertEquals(1, deliveries.getCount().intValue());
    }

    @Test
    public void searchDeliveryByOrderIdAndId() {
        final DeliveryOrderSearch search = new DeliveryOrderSearch();
        search.setOrderId(UUID.fromString("92327ae7-e1c8-4e54-9677-eb8b36e56268"));// OrderId present in delivery_order.xml
        search.setId(UUID.fromString("3b7d0742-84ef-45e7-ae6e-cc65fac6e7b5"));// Id present in delivery_order.xml

        final PagedList<DeliveryOrder> deliveries = this.dao.search(search);
        Assert.assertNotNull(deliveries);
        Assert.assertEquals(1, deliveries.getCount().intValue());
    }

    @Test
    public void searchDeliveryByNonexistentId() {
        final DeliveryOrderSearch search = new DeliveryOrderSearch();
        search.setId(UUID.randomUUID());

        final PagedList<DeliveryOrder> deliveries = this.dao.search(search);
        Assert.assertNotNull(deliveries);
        Assert.assertEquals(0, deliveries.getCount().intValue());
    }

    /**
     * @see com.sollar.test.IIntegrationTest#startServer()
     */
    @Override
    public void startServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#stopServer()
     */
    @Override
    public void stopServer() {
        // Do nothing here
    }

    /**
     * @see com.sollar.test.IIntegrationTest#getDataSetFiles()
     */
    @Override
    public Set<String> getDataSetFiles() {
        final Set<String> files = new HashSet<>();
        files.add("sales_order.xml");
        files.add("delivery_order.xml");
        return files;
    }
}
