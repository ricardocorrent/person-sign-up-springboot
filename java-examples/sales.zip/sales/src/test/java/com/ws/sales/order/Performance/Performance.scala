import io.gatling.core.Predef._

class Performance extends Simulation {

  before {
    println("Simulation is starting ...")
  }

  after {
    println("Simulation is finished!")
  }

  val serviceReq = new ServiceRequests
  val customerReq = new CustomerRequests
  val productReq = new ProductRequests
  val salesReq = new SalesRequests
  val administrationReq = new AdministrationRequests

  val products = csv("products.csv").random
  val constants = new Constants
  val userRequests = new UserRequests

  val registeringACustomerWithOneLocation = scenario("Registering a new customer with one location")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin)
    .exec(customerReq.Customer.postCustomerWithLocation)

  val registeringProduct = scenario("Registering a new product")
    .feed(products)
    .exec(userRequests.doLogin)
    .exec(productReq.Product.postProduct)

  val makingAnOrder = scenario("Saving an order with one item")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin,
          salesReq.Order.postValidOrder)

  val salesman = scenario("Salesman journey")
    .feed(constants.uuidFeeder.feeder)
    .exec(userRequests.doLogin,
        customerReq.Customer.postCustomerWithLocation,
        serviceReq.Service.postService,
        salesReq.Order.postValidOrder)

  val newOrderHeader = scenario("Accessing new order header")
    .exec(userRequests.doLogin)
    .exec(salesReq.OrderConfiguration.getOrderConfiguration)
    .exec(userRequests.getUserProfile)
    .exec(serviceReq.Service.getService)
    .exec(customerReq.Customer.getCustomer)
    .exec(administrationReq.Company.getCompany)
    .exec(salesReq.OrderType.getOrderType)
    .exec(productReq.PriceList.getPriceList)
    .exec(salesReq.PaymentTerm.searchPaymentTerm)
    .exec(salesReq.PaymentMethod.searchPaymentMethod)
    .exec(administrationReq.Currency.getCurrency)
    .exec(customerReq.Customer.getLocation)

  val accessingTheOrderList = scenario("Accessing the order list")
    .exec(userRequests.doLogin)
    .exec(salesReq.OrderConfiguration.getOrderConfiguration)
    .exec(salesReq.Order.searchOrder)
    .exec(userRequests.getUserProfile)

  val accessingItemsList = scenario("Accessing the items list in the order")
    .exec(userRequests.doLogin)
    .exec(salesReq.OrderConfiguration.getOrderConfiguration)
    .exec(salesReq.Order.validateOrder)
    .exec(productReq.PriceList.getPriceListItems)

  val postAPaymentTermWithDescriptionGreaterThanAllowed = scenario("Post a payment term having the description greater than allowed")
    .exec(userRequests.doLogin)
    .exec(salesReq.PaymentTerm.postPaymentTerm(active = true, standard = false, availableFirstOrder = false, 256, 40, 40))
    .exec(session => {
      val messageValidation = session("messageValidation").as[String]
      val httpStatus = session("httpStatus").as[Int].toString
      val maxChars = session("maxChars").as[Int].toString
      println(messageValidation)
      println(httpStatus)
      println(maxChars)
      assert(httpStatus.equals("422"))
      assert(messageValidation.equals("javax.validation.constraints.Size.message"))
      assert(maxChars.equals("255"))
      session
    })

  val postAPaymentTermWithAcronymGreaterThanAllowed = scenario("Post a payment term having the acronym greater than allowed")
    .exec(userRequests.doLogin)
    .exec(salesReq.PaymentTerm.postPaymentTerm(active = true, standard = false, availableFirstOrder = false, 255, 41, 40))
    .exec(session => {
      val messageValidation = session("messageValidation").as[String]
      val httpStatus = session("httpStatus").as[Int].toString
      val maxChars = session("maxChars").as[Int].toString
      assert(httpStatus.equals("422"))
      assert(messageValidation.equals("javax.validation.constraints.Size.message"))
      assert(maxChars.equals("40"))
      session
    })

//  setUp(scn.inject(rampUsers(120) over 30)
//      .protocols(httpConf))


//  setUp(registeringProduct.inject(constantUsersPerSec(100) during 300)).throttle(
//    reachRps(100) in 10,
//    holdFor (60),
//    jumpToRps(50),
//    holdFor(300)
//  ).protocols(httpConf);

    setUp(
      postAPaymentTermWithDescriptionGreaterThanAllowed.inject(rampUsers(1) over 1),
      postAPaymentTermWithAcronymGreaterThanAllowed.inject(rampUsers(1) over 1)
    ).protocols(constants.httpConf)
}