package com.ws.sales.recordpermission;

import org.junit.Test;

/**
 * @author Gustavo P. Bilert
 * @since 2017-06-30
 */
public class SchedulerServiceTest {

    /**
     * Check that all other tenants are executed normally when a tenant throws an exception
     */
    @Test
    public void testErrorIsolationAmongTenants() {
//        final String schedulerTenants = "t0,t1,t2,t3,t4,t5";
//        AccessGroupReplicator accessGroupReplicator = Mockito.mock(AccessGroupReplicator.class);
//        SchedulerServiceSessionController sessionController = Mockito.mock(SchedulerServiceSessionController.class);
//
//        doThrow(new RuntimeException("Test Exception on tenant t1")).when(accessGroupReplicator).replicateForTenant("t1");
//        doThrow(new OutOfMemoryError("TestError on tenant t3")).when(accessGroupReplicator).replicateForTenant("t3");
//
//        SchedulerService schedulerService = new SchedulerService(schedulerTenants, "true", accessGroupReplicator, sessionController);
//
//        schedulerService.run();
//
//        verify(accessGroupReplicator, times(6)).replicateForTenant(anyString());
//        String[] tenants = schedulerTenants.split(",");
//        for (int i = 0; i < tenants.length; i++) {
//            verify(accessGroupReplicator).replicateForTenant(tenants[i]);
//        }
    }
}
