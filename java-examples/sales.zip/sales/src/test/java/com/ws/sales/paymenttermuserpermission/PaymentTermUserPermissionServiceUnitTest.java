package com.ws.sales.paymenttermuserpermission;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.server.pagination.PagedList;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;

/**
 * Test all methods of {@link PaymentTermUserPermissionService}
 * 
 * @author william.santos
 * @since V7.0.0 - 2018-09-17
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermUserPermissionServiceUnitTest extends BaseUnitTest {

    @Mock
    private PaymentTermUserPermissionDAO dao;

    @Mock
    private PaymentTermDAO termDao;

    @Mock
    private PaymentTermUserPermissionValidator validator;

    private PaymentTermUserPermissionService service;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.service = new PaymentTermUserPermissionService(this.dao, this.termDao, this.validator);
    }

    @Test
    public void insertInBatchWithSuccess() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermUserPermission> permissions = new ArrayList<>();
        permissions.add(new PaymentTermUserPermission());

        Mockito.when(this.termDao.findById(paymentTermId)).thenReturn(new PaymentTerm());
        this.service.insertList(permissions, paymentTermId);

        Mockito.verify(this.dao, Mockito.timeout(1)).batchInsert(permissions);
    }

    @Test
    public void insertInBatchWithExceptionDoNotCallSaveOnDAO() {
        final UUID paymentTermId = UUID.randomUUID();
        final List<PaymentTermUserPermission> permissions = new ArrayList<>();
        permissions.add(new PaymentTermUserPermission());

        Mockito.doThrow(ConstraintViolationException.class).when(this.validator).throwFoundErrors();

        try {
            this.service.insertList(permissions, paymentTermId);
        } catch (final ConstraintViolationException exception) {
            // Don't nothing, exception is expected
        }

        Mockito.verify(this.dao, Mockito.never()).batchInsert(permissions);
    }

    @Test
    public void getPermissionsByPaymentTermId() {
        HttpServletRequest req = Mockito.mock(HttpServletRequest.class);
        Mockito.when(req.getParameterMap()).thenReturn(new HashMap<>());
        final UUID paymentTermId = UUID.randomUUID();
        final PagedList<PaymentTermUserPermission> permissions = new PagedList<>();

        Mockito.when(this.dao.getByPaymentTerm(paymentTermId, new HashMap<String, String[]>())).thenReturn(permissions);

        final PagedList<PaymentTermUserPermission> found = this.service.getByPaymentTerm(paymentTermId, req);
        Assert.assertNotNull(found);
        Assert.assertEquals(permissions, found);
    }

    /**
     * Test of mapping to convert {@link PaymentTermUserPermission} to
     * {@link PaymentTermUserPermissionDTO}
     */
    @Test
    public void convertUserPermissionToDto() {
        final PaymentTerm term = new PaymentTerm();
        term.setDescription("Term");
        term.setId(UUID.randomUUID());

        final PaymentTermUserPermission permission = new PaymentTermUserPermission();
        permission.setId(UUID.randomUUID());
        permission.setUserId(UUID.randomUUID());
        permission.setUserName("Unit-Test");
        permission.setPaymentTerm(term);
        
        final PaymentTermUserPermissionDTO dto = new PojoConverter().convert(PaymentTermUserPermissionDTO.class, permission);
        Assert.assertNotNull(dto);
        Assert.assertEquals(permission.getId(), dto.getId());
        Assert.assertEquals(permission.getUserName(), dto.getUser().getName());
        Assert.assertEquals(term.getDescription(), dto.getPaymentTerm().getDescription());
    }
}
