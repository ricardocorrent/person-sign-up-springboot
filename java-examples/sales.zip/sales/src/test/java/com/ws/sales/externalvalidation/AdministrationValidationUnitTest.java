package com.ws.sales.externalvalidation;

import java.util.UUID;

import com.ws.sales.external.administration.AdministrationValidation;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ws.administration.model.Company;
import com.ws.administration.model.Currency;
import com.ws.administration.model.ExchangeRate;
import com.ws.administration.model.MeasurementUnit;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.util.Constants;

/**
 * @author Maykon Roberto Rissi
 * @since 6.1.0 - 2018-08-20
 */
@RunWith(MockitoJUnitRunner.class)
public class AdministrationValidationUnitTest {

    @InjectMocks
    private AdministrationValidation administrationValidation;

    @Mock
    private AdministrationGateway administrationGateway;

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void companyExistsAndIsActive() {
        final Company entity = new Company();
        entity.setActive(Boolean.TRUE);
        Mockito.when(this.administrationGateway.getCompany(Mockito.any())).thenReturn(entity);
        final LogicError logicError = this.administrationValidation.doValidateCompanyCanBeUsed(UUID.randomUUID(), null);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void companyExistsAndIsInactive() {
        final Company entity = new Company();
        entity.setActive(Boolean.FALSE);
        Mockito.when(this.administrationGateway.getCompany(Mockito.any())).thenReturn(entity);
        final LogicError logicError = this.administrationValidation.doValidateCompanyCanBeUsed(UUID.randomUUID(), null);
        Assert.assertNotNull(logicError);
        Assert.assertEquals(Constants.FIELD_COMPANY_ID, logicError.getField());
    }

    /**
     * @author Maykon Roberto Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void companyExistsAndIsInactiveWithDifferentField() {
        final Company entity = new Company();
        entity.setActive(Boolean.FALSE);
        Mockito.when(this.administrationGateway.getCompany(Mockito.any())).thenReturn(entity);
        final LogicError logicError = this.administrationValidation.doValidateCompanyCanBeUsed(UUID.randomUUID(), Constants.FIELD_WITHDRAWAL_COMPANY_ID);
        Assert.assertNotNull(logicError);
        Assert.assertEquals(Constants.FIELD_WITHDRAWAL_COMPANY_ID, logicError.getField());
    }

    /**
     * @author Maykon Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void companyDoestNotExists() {
        Mockito.when(this.administrationGateway.getCompany(Mockito.any())).thenReturn(null);
        final LogicError logicError = this.administrationValidation.doValidateCompanyCanBeUsed(UUID.randomUUID(), null);
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void companyCanNotBeValidatedBecauseParamIdIsNull() {
        final LogicError logicError = this.administrationValidation.doValidateCompanyCanBeUsed(null, null);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void currencyExistAndIsActive() {
        final Currency currency = new Currency();
        currency.setActive(Boolean.TRUE);
        Mockito.when(administrationGateway.getCurrency(Mockito.any())).thenReturn(currency);
        final LogicError logicError = administrationValidation.doValidateCurrencyCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void currencyExistAndIsInactive() {
        final Currency currency = new Currency();
        currency.setActive(Boolean.FALSE);
        Mockito.when(administrationGateway.getCurrency(Mockito.any())).thenReturn(currency);
        final LogicError logicError = administrationValidation.doValidateCurrencyCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void currencyDoesNotExist() {
        Mockito.when(administrationGateway.getCurrency(Mockito.any())).thenReturn(null);
        final LogicError logicError = administrationValidation.doValidateCurrencyCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void currencyCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = administrationValidation.doValidateCurrencyCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void measurementUnitExistAndIsActive() {
        final MeasurementUnit measurementUnit = new MeasurementUnit();
        measurementUnit.setActive(Boolean.TRUE);
        Mockito.when(administrationGateway.getMeasurementUnit(Mockito.any())).thenReturn(measurementUnit);
        final LogicError logicError = administrationValidation.doValidateMeasurementUnitCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void measurementUnitExistAndIsInactive() {
        final MeasurementUnit measurementUnit = new MeasurementUnit();
        measurementUnit.setActive(Boolean.FALSE);
        Mockito.when(administrationGateway.getMeasurementUnit(Mockito.any())).thenReturn(measurementUnit);
        final LogicError logicError = administrationValidation.doValidateMeasurementUnitCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void measurementUnitDoesNotExist() {
        Mockito.when(administrationGateway.getMeasurementUnit(Mockito.any())).thenReturn(null);
        final LogicError logicError = administrationValidation.doValidateMeasurementUnitCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void measurementUnitCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = administrationValidation.doValidateMeasurementUnitCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void exchangeRateExists() {
        Mockito.when(administrationGateway.getExchangeRate(Mockito.any())).thenReturn(new ExchangeRate());
        final LogicError logicError = administrationValidation.doValidateExchangeRateCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void exchangeRateDoesNotExist() {
        Mockito.when(administrationGateway.getExchangeRate(Mockito.any())).thenReturn(null);
        final LogicError logicError = administrationValidation.doValidateExchangeRateCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-20
     */
    @Test
    public void exchangeRateCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = administrationValidation.doValidateExchangeRateCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void exchangeRateBelongsToTheCurrency() {
        final ExchangeRate exchangeRate = new ExchangeRate();
        final Currency currency = new Currency();
        currency.setId(UUID.randomUUID().toString());
        exchangeRate.setId(UUID.randomUUID().toString());
        exchangeRate.setCurrency(currency);
        Mockito.when(administrationGateway.getExchangeRate(Mockito.any())).thenReturn(exchangeRate);
        final LogicError logicError = administrationValidation.doValidateExchangeRateBelongsToCurrency(UUID.fromString(currency.getId()), UUID.fromString(exchangeRate.getId()));
        Assert.assertNull(logicError);
    }


    /**
     * @author Maykon Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void exchangeRateDoesNotBelongsToTheCurrency() {
        final Currency currency = new Currency();
        currency.setId(UUID.randomUUID().toString());
        final ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.setCurrency(currency);
        Mockito.when(administrationGateway.getExchangeRate(Mockito.any())).thenReturn(exchangeRate);
        final LogicError logicError = administrationValidation.doValidateExchangeRateBelongsToCurrency(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since 6.1.0 - 2018-08-20
     */
    @Test
    public void exchangeRateCanNotBeValidateBecauseParamsAreNull() {
        final LogicError logicError = administrationValidation.doValidateExchangeRateBelongsToCurrency(null, null);
        Assert.assertNull(logicError);
    }
}
