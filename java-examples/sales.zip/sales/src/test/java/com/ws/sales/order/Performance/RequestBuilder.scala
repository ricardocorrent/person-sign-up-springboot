import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.check._
import io.gatling.http.check.HttpCheck
import io.gatling.http.response.Response

class RequestBuilder extends Simulation {

  def boolJsonBuilder(trueBool: Boolean, falseBool: Boolean):String = {
    if (trueBool && falseBool) {
      "[true,false], \n"
    } else if (trueBool && !falseBool) {
      "[true], \n"
    } else if (!trueBool && falseBool) {
      "[false], \n"
    } else {
      "[], \n"
    }
  }

  def saveResponse(): HttpCheck = {
    jsonPath("$").saveAs("serverResponse")
  }

  def saveHttpStatus(): HttpCheck =  {
    status.in(100 to 600).saveAs("httpStatus")
  }

  def search(httpDescription: String, apiUrl: String, json: String) = {
    exec(
      http(httpDescription)
        .post(apiUrl)
        .body(StringBody(json)).asJSON
        .check(jsonPath("$").saveAs("serverResponse"))
        .check(jsonPath("$.items[*]").ofType[Map[String, Any]].findAll.saveAs("items"))
        .check(status.is(200).saveAs("httpStatus"))
    )
  }

  def post(httpDescription: String, apiUrl: String, json: String) = {
    exec(
        http(httpDescription)
          .post(apiUrl)
          .body(StringBody(json)).asJSON
          .check(
            jsonPath("$").saveAs("serverResponse"),
            status.in(100 to 600).saveAs("httpStatus")
          )
    )
  }
}