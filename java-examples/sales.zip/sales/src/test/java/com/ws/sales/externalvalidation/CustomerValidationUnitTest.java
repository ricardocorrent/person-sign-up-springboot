package com.ws.sales.externalvalidation;

import com.ws.commons.server.validation.exception.LogicError;
import com.ws.customer.model.Customer;
import com.ws.customer.model.Location;
import com.ws.sales.external.customer.CustomerValidation;
import com.ws.sales.external.customer.CustomerGateway;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.UUID;

/**
 * Tests for customer and location validations
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-13
 */
@RunWith(MockitoJUnitRunner.class)
public class CustomerValidationUnitTest {

    @InjectMocks
    private CustomerValidation customerValidation;

    @Mock
    private CustomerGateway customerGateway;

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void customerExistAndIsActive() {
        final Customer customer = new Customer();
        customer.setActive(Boolean.TRUE);
        Mockito.when(customerGateway.getCustomer(Mockito.any())).thenReturn(customer);
        final LogicError logicError = customerValidation.doValidateCustomerCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void customerExistAndIsInactive() {
        final Customer customer = new Customer();
        customer.setActive(Boolean.FALSE);
        Mockito.when(customerGateway.getCustomer(Mockito.any())).thenReturn(customer);
        final LogicError logicError = customerValidation.doValidateCustomerCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void customerDoesNotExist() {
        Mockito.when(customerGateway.getCustomer(Mockito.any())).thenReturn(null);
        final LogicError logicError = customerValidation.doValidateCustomerCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void customerCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = customerValidation.doValidateCustomerCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationExistAndIsActive() {
        final Location location = new Location();
        location.setActive(Boolean.TRUE);
        Mockito.when(customerGateway.getLocation(Mockito.any())).thenReturn(location);
        final LogicError logicError = customerValidation.doValidateLocationCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationExistAndIsInactive() {
        final Location location = new Location();
        location.setActive(Boolean.FALSE);
        Mockito.when(customerGateway.getLocation(Mockito.any())).thenReturn(location);
        final LogicError logicError = customerValidation.doValidateLocationCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationDoesNotExist() {
        Mockito.when(customerGateway.getLocation(Mockito.any())).thenReturn(null);
        final LogicError logicError = customerValidation.doValidateLocationCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = customerValidation.doValidateLocationCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate if the location belongs to the customer with valid registers. It must do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationBelongsToTheCustomer() {
        Mockito.when(customerGateway.locationBelongsToCustomer(Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);
        final LogicError logicError = customerValidation.doValidateLocationBelongsToCustomer(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate if the location belongs to the customer with a location that does not belong to the customer. It must do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationDoesNotBelongToTheCustomer() {
        Mockito.when(customerGateway.locationBelongsToCustomer(Mockito.any(), Mockito.any())).thenReturn(Boolean.FALSE);
        final LogicError logicError = customerValidation.doValidateLocationBelongsToCustomer(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void locationCanNotBeValidateBecauseParamsAreNull() {
        final LogicError logicError = customerValidation.doValidateLocationBelongsToCustomer(null, null);
        Assert.assertNull(logicError);
    }
}
