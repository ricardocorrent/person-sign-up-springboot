/**
 * 
 */
package com.ws.sales.paymentterm;

import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.persistence.model.BaseModel;

/**
 * Test all method of {@link PaymentTermValidation}
 * 
 * @author william.santos
 * @since 2018-09-14
 * @version 1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentTermValidationUnitTest extends BaseUnitTest {

    @Mock
    private PaymentTermDAO dao;

    private PaymentTermValidation validation;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
        this.validation = new PaymentTermValidation(this.dao);
    }

    @Test
    public void validStandardWhenExistsOtherRetrunsError() {
        final PaymentTerm standard = new PaymentTerm();
        standard.setId(UUID.randomUUID());
        standard.setStandard(Boolean.TRUE);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final PaymentTerm newStandard = new PaymentTerm();
        newStandard.setStandard(Boolean.TRUE);

        this.validation.validHasStandard(newStandard);
        final Set<ConstraintViolation<BaseModel>> violations = this.validation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertFalse(violations.isEmpty());
    }

    @Test
    public void validStandardWhenNonexistsOtherReturnsEmpty() {
        Mockito.when(this.dao.getStandard()).thenReturn(null);

        final PaymentTerm newStandard = new PaymentTerm();
        newStandard.setStandard(Boolean.TRUE);

        this.validation.validHasStandard(newStandard);
        final Set<ConstraintViolation<BaseModel>> violations = this.validation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void validNonStandardWhenExistsStandardReturnsEmtpy() {
        final PaymentTerm standard = new PaymentTerm();
        standard.setId(UUID.randomUUID());
        standard.setStandard(Boolean.TRUE);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final PaymentTerm newStandard = new PaymentTerm();
        newStandard.setStandard(Boolean.FALSE);

        this.validation.validHasStandard(newStandard);
        final Set<ConstraintViolation<BaseModel>> violations = this.validation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void validNonStandardWhenNonexistsStandardReturnsEmpty() {
        Mockito.when(this.dao.getStandard()).thenReturn(null);

        final PaymentTerm newStandard = new PaymentTerm();
        newStandard.setStandard(Boolean.TRUE);

        this.validation.validHasStandard(newStandard);
        final Set<ConstraintViolation<BaseModel>> violations = this.validation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }

    @Test
    public void validSameIsStandardPaymentTermReturnsEmpty() {
        final UUID paymentTermId = UUID.randomUUID();
        final PaymentTerm standard = new PaymentTerm();
        standard.setStandard(Boolean.TRUE);
        standard.setId(paymentTermId);

        Mockito.when(this.dao.getStandard()).thenReturn(standard);

        final PaymentTerm newStandard = new PaymentTerm();
        newStandard.setId(paymentTermId);
        newStandard.setStandard(Boolean.TRUE);

        this.validation.validHasStandard(newStandard);
        final Set<ConstraintViolation<BaseModel>> violations = this.validation.getConstraintViolations();
        Assert.assertNotNull(violations);
        Assert.assertTrue(violations.isEmpty());
    }
}
