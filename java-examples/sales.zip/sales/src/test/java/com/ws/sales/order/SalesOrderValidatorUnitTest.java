package com.ws.sales.order;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.context.UserContext;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.financial.model.CreditLimit;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.sales.deliveryorder.DeliveryOrder;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.external.commondata.IncotermsAcronym;
import com.ws.sales.external.customer.CustomerGateway;
import com.ws.sales.external.financial.FinancialGateway;
import com.ws.sales.external.product.ProductGateway;
import com.ws.sales.external.user.UserGateway;
import com.ws.sales.order.enums.OrderOrigin;
import com.ws.sales.orderitem.SalesOrderItem;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterDAO;
import com.ws.sales.ordertype.OrderTypeDAO;
import com.ws.sales.ordertype.OrderTypeService;
import com.ws.sales.paymentmethod.PaymentMethodDAO;
import com.ws.sales.paymentmethod.PaymentMethodService;
import com.ws.sales.paymentterm.PaymentTerm;
import com.ws.sales.paymentterm.PaymentTermDAO;
import com.ws.sales.paymentterm.PaymentTermService;
import com.ws.sales.situation.SituationDAO;
import com.ws.sales.util.Constants;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import com.sollar.test.util.MockedSecurityManager;
import com.ws.sales.external.opportunity.OpportunityGateway;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.mgt.SimpleSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.TestCase;

import static org.hamcrest.Matchers.*;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrderValidatorUnitTest extends BaseUnitTest {

    @Mock
    private ProductGateway productGateway;

    @Mock
    private SituationDAO situationDAO;

    @Mock
    private PaymentMethodDAO paymentMethodDAO;

    @Mock
    private PaymentTermDAO paymentTermDAO;

    @Mock
    private OrderParameterDAO orderParameterDAO;

    @Mock
    private UserGateway userGateway;

    @Mock
    private CustomerGateway customerGateway;

    @Mock
    private AdministrationGateway administrationGateway;
    
    @Mock
    private OpportunityGateway opportunityGateway;

    @Mock
    private OrderTypeDAO orderTypeDAO;

    @Mock
    private OrderTypeService orderTypeService;

    @Mock
    private PaymentTermService paymentTermService;

    @Mock
    private PaymentMethodService paymentMethodService;

    @Mock
    private SalesOrderDAO salesOrderDAO;

    @Mock
    private UserContext userContext;

    @Mock
    private FinancialGateway financialGateway;

    @InjectMocks
    private SalesOrderHeaderValidator headerValidator;

    @InjectMocks
    private SalesOrderValidator validator;

    @Before
    public void setUp() throws Exception {
        SecurityUtils.setSecurityManager(new MockedSecurityManager());
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void orderHasNetValueIsValid() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.TEN);
        final LogicError logicError = this.validator.doValidateOrderValue(salesOrder);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void orderHasNullNetValueIsInvalid() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(null);
        final LogicError logicError = this.validator.doValidateOrderValue(salesOrder);
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-28
     */
    @Test
    public void orderHasNetValueEqualsZeroIsInvalid() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.ZERO);
        final LogicError logicError = this.validator.doValidateOrderValue(salesOrder);
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-28
     */
    @Test
    public void orderIsNullSoItWontValidate() {
        final LogicError logicError = this.validator.doValidateOrderValue(null);
        Assert.assertNull(logicError);
    }


    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void originIsWebAndIsDraft() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.TRUE);
        salesOrder.setOrigin(OrderOrigin.WEB.toString());
        final LogicError logicError = this.headerValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE);
        Assert.assertNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void originIsExternalAndIsDraft() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.TRUE);
        salesOrder.setOrigin(OrderOrigin.EXT.toString());
        final LogicError logicError = this.headerValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE);
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void originIsWebAndOrderIsNotDraft() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.FALSE);
        salesOrder.setOrigin(OrderOrigin.WEB.toString());
        final LogicError logicError = this.headerValidator.doValidateIfOrderCanBeEdited(salesOrder, Boolean.FALSE);
        Assert.assertNotNull(logicError);
    }

    /**
     * @author Maykon Rissi
     * @since v6.0.0 2018-08-18
     */
    @Test
    public void wontValidateBecauseOrderIsNull() {
        final LogicError logicError = this.headerValidator.doValidateIfOrderCanBeEdited(null, Boolean.FALSE);
        Assert.assertNull(logicError);
    }

    @Test
    public void validateOrderFinalized_withDraftOldOrder() {
        final SalesOrder oldOrder = Mockito.mock(SalesOrder.class);
        Mockito.when(oldOrder.getDraft()).thenReturn(Boolean.TRUE);
        Mockito.when(salesOrderDAO.findById(Matchers.any())).thenReturn(oldOrder);

        final SalesOrder order = new SalesOrder();

        Assert.assertNull(validator.validateOrderFinalized(order));
    }

    @Test
    public void validateOrderFinalized_withoutOldOrder() {
        Mockito.when(salesOrderDAO.findById(Matchers.any())).thenReturn(null);
        final SalesOrder order = new SalesOrder();
        order.setDraft(Boolean.TRUE);

        Assert.assertNull(validator.validateOrderFinalized(order));
    }

    @Test
    public void validateOrderFinalized_withoutOrder() {
        Assert.assertNull(validator.validateOrderFinalized(null));
    }

    @Test
    public void validateOrderFinalized_withFinalizedOldOrder() {
        final SalesOrder oldOrder = new SalesOrder();
        oldOrder.setDraft(Boolean.FALSE);
        Mockito.when(salesOrderDAO.findById(Matchers.any())).thenReturn(oldOrder);
        final SalesOrder order = new SalesOrder();
        order.setId(UUID.randomUUID());
        final LogicError error = validator.validateOrderFinalized(order);
        TestCase.assertNotNull(error);
        Assert.assertEquals("draft", error.getField());
        Assert.assertEquals("order.finalized", error.getMessageTemplate());
    }

    @Test
    public void validateUserIsSameAsUserLogged_withUserLogged() {
        final UUID idUserLogged = UUID.randomUUID();

        final SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Matchers.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        Assert.assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutSession() {
        final UUID idUserLogged = UUID.randomUUID();

        Mockito.when(userContext.getSession()).thenReturn(null);

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        Assert.assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutIdLoggedUser() {
        final UUID idUserLogged = UUID.randomUUID();

        final SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUserLogged);

        Assert.assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withoutIdUserOrder() {
        final UUID idUserLogged = UUID.randomUUID();

        final SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Matchers.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(null);

        Assert.assertNull(headerValidator.validateUserIsSameAsUserLogged(order));
    }

    @Test
    public void validateUserIsSameAsUserLogged_withAnotherUserLogged() {
        final UUID idUserLogged = UUID.randomUUID();
        final UUID idUser = UUID.randomUUID();

        final SimpleSession session = Mockito.mock(SimpleSession.class);
        Mockito.when(userContext.getSession()).thenReturn(session);
        Mockito.when(session.getAttribute(Matchers.any())).thenReturn(idUserLogged.toString());

        final SalesOrder order = new SalesOrder();
        order.setUserId(idUser);

        final LogicError error = headerValidator.validateUserIsSameAsUserLogged(order);

        TestCase.assertNotNull(error);
        Assert.assertEquals("user", error.getField());
        Assert.assertEquals("order.user.userIsNotLogged", error.getMessageTemplate());
    }

    // Mocks the orderParameter with any param and returns true or false
    private void mockParameter(final Boolean returns) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(returns.toString());
        Mockito.when(orderParameterDAO.searchByKey(Matchers.any())).thenReturn(orderParameter);
    }

    @Test
    public void validateCurrencyPluginEnabled() {
        mockParameter(Boolean.TRUE);
        final String currency = "BRL";
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(currency);
        Assert.assertNull(headerValidator.validateCurrencyPlugin(salesOrder));
    }

    @Test
    public void validateCurrencyPluginDisabledWithoutCurrency() {
        mockParameter(Boolean.FALSE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(null);
        Assert.assertNull(headerValidator.validateCurrencyPlugin(salesOrder));
    }

    @Test
    public void validateCurrencyPluginDisabledWithCurrency() {
        mockParameter(Boolean.FALSE);
        final String currency = "BRL";
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCurrency(currency);
        final LogicError error = headerValidator.validateCurrencyPlugin(salesOrder);
        TestCase.assertNotNull(error);
        Assert.assertEquals("salesOrder", error.getField());
        Assert.assertEquals("order.item.currencyPluginDisabled", error.getMessageTemplate());
    }

    @Test
    public void validateSituationExists() {
        final UUID situationId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSituationId(situationId);
        Mockito.when(situationDAO.situationExists(situationId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validateSituationExists(salesOrder));
    }

    @Test
    public void validateSituationExistsWithoutSituationId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateSituationExists(salesOrder));
    }

    @Test
    public void validateSituationNotExists() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setSituationId(UUID.randomUUID());

        final LogicError error = headerValidator.validateSituationExists(salesOrder);

        Assert.assertEquals("situationId", error.getField());
        Assert.assertEquals("order.situation.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentMethodExists() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        Mockito.when(paymentMethodDAO.paymentMethodExists(paymentMethodId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validatePaymentMethodExists(salesOrder));
    }

    @Test
    public void validatePaymentMethodExistsWithoutPaymentMethodId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePaymentMethodExists(salesOrder));
    }

    @Test
    public void validatePaymentMethodNotExists() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        final LogicError error = headerValidator.validatePaymentMethodExists(salesOrder);

        Assert.assertEquals("paymentMethod", error.getField());
        Assert.assertEquals("order.paymentMethod.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentTermExists() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        Mockito.when(paymentTermDAO.paymentTermExists(paymentTermId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validatePaymentTermExists(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermBlocked() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(10));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        Mockito.when(paymentTermDAO.findById(Matchers.any())).thenReturn(paymentTerm);
        Assert.assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermBlockedAndError() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        Mockito.when(paymentTermDAO.findById(Matchers.any())).thenReturn(paymentTerm);
        TestCase.assertNotNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermNull() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(false);
        paymentTerm.setMiddleTerm(10);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        mockParameter(Boolean.TRUE);
        Mockito.when(paymentTermDAO.findById(Matchers.any())).thenReturn(null);
        Assert.assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithPaymentTermOpen() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(true);
        paymentTerm.setMiddleTerm(10);
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        Mockito.when(paymentTermDAO.findById(Matchers.any())).thenReturn(null);
        Assert.assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithOrderNull() {
        final PaymentTerm paymentTerm = new PaymentTerm();
        paymentTerm.setAllowChangeDueDate(true);
        paymentTerm.setMiddleTerm(10);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().plusDays(20));
        salesOrder.setPaymentTermId(UUID.randomUUID());
        mockParameter(Boolean.TRUE);
        Mockito.when(paymentTermDAO.findById(Matchers.any())).thenReturn(null);
        Assert.assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(null));
    }

    @Test
    public void validateDueDateWithOlderThanNowDate() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now().minusDays(20));
        TestCase.assertNotNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDateWithNowDate() {
        mockParameter(Boolean.TRUE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        Assert.assertNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDateWithConfigurationFalse() {
        mockParameter(Boolean.FALSE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        Assert.assertNull(headerValidator.validateDueDateWithLowerThanNowDate(salesOrder));
    }

    @Test
    public void validateDueDatePaymentTermWithConfigurationFalse() {
        mockParameter(Boolean.FALSE);
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        Assert.assertNull(headerValidator.validateDueDateWithPaymentTermBlocked(salesOrder));
    }

    @Test
    public void validateDueDateWithConfOff() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        TestCase.assertNotNull(headerValidator.validateDueDateWithConfOff(salesOrder, Boolean.FALSE));
    }

    @Test
    public void validateDueDateWithConfOn() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDueDate(LocalDate.now());
        Assert.assertNull(headerValidator.validateDueDateWithConfOff(salesOrder, Boolean.TRUE));
    }

    @Test
    public void validatePaymentTermExistsWithoutPaymentTermId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePaymentTermExists(salesOrder));
    }

    @Test
    public void validatePaymentTermNotExists() {
        final UUID paymentTermId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);
        final LogicError error = headerValidator.validatePaymentTermExists(salesOrder);
        Assert.assertEquals("paymentTermId", error.getField());
        Assert.assertEquals("order.paymentTerm.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyExists() {
        final UUID companyId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);
        Mockito.when(administrationGateway.companyExists(companyId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validateCompanyExists(salesOrder));
    }

    @Test
    public void validateCompanyExistsWithoutCompanyId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateCompanyExists(salesOrder));
    }

    @Test
    public void validateCompanyNotExists() {
        final UUID companyId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);
        final LogicError error = headerValidator.validateCompanyExists(salesOrder);
        Assert.assertEquals("companyId", error.getField());
        Assert.assertEquals("order.company.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateOrderTypeExists() {
        final UUID orderTypeId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);
        Mockito.when(orderTypeDAO.orderTypeExists(orderTypeId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validateOrderTypeExists(salesOrder));
    }

    @Test
    public void validateOrderTypeExistsWithoutOrderTyprId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateOrderTypeExists(salesOrder));
    }

    @Test
    public void validateOrderTypeNotExists() {
        final UUID orderTypeId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);
        final LogicError error = headerValidator.validateOrderTypeExists(salesOrder);
        Assert.assertEquals("orderTypeId", error.getField());
        Assert.assertEquals("order.orderType.notFound", error.getMessageTemplate());
    }

    @Test
    public void validatePriceListExists() {
        final UUID priceListId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);
        Mockito.when(productGateway.priceListExists(priceListId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validatePriceListExists(salesOrder));
    }

    @Test
    public void validatePriceListExistsWithoutPriceListId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePriceListExists(salesOrder));
    }

    @Test
    public void validatePriceListNotExists() {
        final UUID priceListId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);
        final LogicError error = headerValidator.validatePriceListExists(salesOrder);
        Assert.assertEquals("priceListId", error.getField());
        Assert.assertEquals("order.priceList.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateLocationExists() {
        final UUID locationId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);
        Mockito.when(customerGateway.locationExists(locationId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validateLocationExists(salesOrder));
    }

    @Test
    public void validateLocationExistsWithoutLocationId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateLocationExists(salesOrder));
    }

    @Test
    public void validateLocationNotExists() {
        final UUID locationId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);
        final LogicError error = headerValidator.validateLocationExists(salesOrder);
        Assert.assertEquals("customerLocation", error.getField());
        Assert.assertEquals("order.location.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCustomerExists() {
        final UUID customerId = UUID.randomUUID();
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);
        Mockito.when(customerGateway.customerExists(customerId)).thenReturn(Boolean.TRUE);
        Assert.assertNull(headerValidator.validateCustomerExists(salesOrder));
    }

    @Test
    public void validateCustomerExistsWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateCustomerExists(salesOrder));
    }

    @Test
    public void validateCustomerNotExists() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        final LogicError error = headerValidator.validateCustomerExists(salesOrder);

        Assert.assertEquals("customerId", error.getField());
        Assert.assertEquals("order.customer.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateUserExists() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        Mockito.when(userGateway.userExists(userId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateUserExists(salesOrder));
    }

    @Test
    public void validateUserExistsWithoutUserId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateUserExists(salesOrder));
    }

    @Test
    public void validateUserNotExists() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        final LogicError error = headerValidator.validateUserExists(salesOrder);

        Assert.assertEquals("userId", error.getField());
        Assert.assertEquals("order.user.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyIsActive() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        Mockito.when(administrationGateway.companyIsActive(companyId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateCompanyIsActive(salesOrder));
    }

    @Test
    public void validateCompanyInactive() {
        final UUID companyId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCompanyId(companyId);

        final LogicError error = headerValidator.validateCompanyIsActive(salesOrder);

        Assert.assertEquals("companyId", error.getField());
        Assert.assertEquals("order.company.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateCompanyIsActiveWithoutCompanyId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateCompanyIsActive(salesOrder));
    }

    @Test
    public void validatePaymentTermIsActive() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        Mockito.when(paymentTermService.paymentTermIsActive(paymentTermId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validatePaymentTermIsActive(salesOrder));
    }

    @Test
    public void validatePaymentTermInactive() {
        final UUID paymentTermId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentTermId);

        final LogicError error = headerValidator.validatePaymentTermIsActive(salesOrder);

        Assert.assertEquals("paymentTermId", error.getField());
        Assert.assertEquals("order.paymentTerm.inactive", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentTermIsActiveWithoutPaymentTermId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePaymentTermIsActive(salesOrder));
    }

    @Test
    public void validatePaymentMethodIsActive() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentTermId(paymentMethodId);

        Mockito.when(paymentMethodService.paymentMethodIsActive(paymentMethodId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validatePaymentMethodIsActive(salesOrder));
    }

    @Test
    public void validatePaymentMethodInactive() {
        final UUID paymentMethodId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPaymentMethodId(paymentMethodId);

        final LogicError error = headerValidator.validatePaymentMethodIsActive(salesOrder);

        Assert.assertEquals("paymentMethodId", error.getField());
        Assert.assertEquals("order.paymentMethod.inactive", error.getMessageTemplate());
    }

    @Test
    public void validatePaymentMethodIsActiveWithoutPaymentMethodId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePaymentMethodIsActive(salesOrder));
    }

    @Test
    public void validatePriceListIsActive() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        Mockito.when(productGateway.priceListIsActive(priceListId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validatePriceListIsActive(salesOrder));
    }

    @Test
    public void validatePriceListIsActiveWithoutPriceListId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validatePriceListIsActive(salesOrder));
    }

    @Test
    public void validatePriceListInactive() {
        final UUID priceListId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(priceListId);

        final LogicError error = headerValidator.validatePriceListIsActive(salesOrder);

        Assert.assertEquals("priceListId", error.getField());
        Assert.assertEquals("order.priceList.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateUserIsActive() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        Mockito.when(userGateway.userIsActive(userId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateUserIsActive(salesOrder));
    }

    @Test
    public void validateUserIsActiveWithoutUserId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateUserIsActive(salesOrder));
    }

    @Test
    public void validateUserInactive() {
        final UUID userId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserId(userId);

        final LogicError error = headerValidator.validateUserIsActive(salesOrder);

        Assert.assertEquals("userId", error.getField());
        Assert.assertEquals("order.user.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateCustomerIsActive() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        Mockito.when(customerGateway.customerIsActive(customerId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateCustomerIsActive(salesOrder));
    }

    @Test
    public void validateCustomerIsActiveWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateCustomerIsActive(salesOrder));
    }

    @Test
    public void validateCustomerInactive() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        final LogicError error = headerValidator.validateCustomerIsActive(salesOrder);

        Assert.assertEquals("customerId", error.getField());
        Assert.assertEquals("order.customer.inactive", error.getMessageTemplate());
    }

    @Test
    public void customerLocationIsActive() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        Mockito.when(customerGateway.locationIsActive(locationId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateCustomerLocationIsActive(salesOrder));
    }

    @Test
    public void customerLocationIsActiveWithoutCustomerId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateCustomerLocationIsActive(salesOrder));
    }

    @Test
    public void customerLocationInactive() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        final LogicError error = headerValidator.validateCustomerLocationIsActive(salesOrder);

        Assert.assertEquals("customerLocation", error.getField());
        Assert.assertEquals("order.location.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateOrderTypeIsActive() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        Mockito.when(orderTypeService.orderTypeIsActive(orderTypeId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateOrderTypeIsActive(salesOrder));
    }

    @Test
    public void validateOrderTypeIsActiveWithoutOrderTypeId() {
        final SalesOrder salesOrder = new SalesOrder();
        Assert.assertNull(headerValidator.validateOrderTypeIsActive(salesOrder));
    }

    @Test
    public void validateOrderTypeInactive() {
        final UUID orderTypeId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setOrderTypeId(orderTypeId);

        final LogicError error = headerValidator.validateOrderTypeIsActive(salesOrder);

        Assert.assertEquals("orderTypeId", error.getField());
        Assert.assertEquals("order.orderType.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateSalesOrderWithProductPresentInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        Assert.assertNull(validator.validateProductsInPriceList(salesOrder));
    }

    @Test
    public void validateSalesOrderWithProductNotPresentInPriceList() {
        final UUID productIdPriceList = UUID.randomUUID();
        final UUID productIdSalesOrder = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productIdPriceList.toString());
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productIdSalesOrder);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsInPriceList(salesOrder);

        Assert.assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());
    }

    @Test
    public void validateSalesOrderWithEmptyPriceList() {
        final List<PriceListItem> itemsPriceList = new ArrayList<>();

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsInPriceList(salesOrder);

        Assert.assertEquals("order.item.product.mustBelongsToPriceListItem", error.getMessageTemplate());
    }

    @Test
    public void validateProductActiveInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        productPriceList.setActive(Boolean.TRUE);
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        Assert.assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductActiveInPriceListWithSalesOrderWithoutItems() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setItems(null);

        Assert.assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductActiveInPriceListWithoutPriceList() {
        final SalesOrderItem itemSalesOrder = new SalesOrderItem();
        itemSalesOrder.setProductId(UUID.randomUUID());

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(null);
        salesOrder.setItems(Arrays.asList(itemSalesOrder));

        Assert.assertNull(validator.validateProductsActiveInPriceList(salesOrder));
    }

    @Test
    public void validateProductInactiveInPriceList() {
        final UUID productId = UUID.randomUUID();

        final PriceListItem itemPriceList = new PriceListItem();
        final Product productPriceList = new Product();
        productPriceList.setId(productId.toString());
        productPriceList.setActive(Boolean.FALSE);
        itemPriceList.setProduct(productPriceList);

        final List<PriceListItem> itemsPriceList = Arrays.asList(itemPriceList);

        final SalesOrderItem itemNotPresentInPriceList = new SalesOrderItem();
        itemNotPresentInPriceList.setProductId(productId);

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());

        salesOrder.setItems(Arrays.asList(itemNotPresentInPriceList));

        Mockito.when(productGateway.findItemsPriceListById(salesOrder)).thenReturn(itemsPriceList);

        final LogicError error = validator.validateProductsActiveInPriceList(salesOrder);

        Assert.assertEquals("order.itemInactiveInPriceList", error.getMessageTemplate());
    }

    @Test
    public void validateLocationBelongsToUser() {
        final UUID customerId = UUID.randomUUID();
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);
        salesOrder.setLocationId(locationId);

        Mockito.when(customerGateway.locationBelongsToCustomer(locationId, customerId)).thenReturn(Boolean.TRUE);

        Assert.assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationBelongsToUserWithCustomerIdAndWithoutLocationId() {
        final UUID customerId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);

        Assert.assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationBelongsToUserWithoutCustomerIdAndWithLocationId() {
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setLocationId(locationId);

        Assert.assertNull(headerValidator.validateLocationBelongsToCustomer(salesOrder));
    }

    @Test
    public void validateLocationDoesNotBelongsToUser() {
        final UUID customerId = UUID.randomUUID();
        final UUID locationId = UUID.randomUUID();

        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomerId(customerId);
        salesOrder.setLocationId(locationId);

        final LogicError error = headerValidator.validateLocationBelongsToCustomer(salesOrder);

        Assert.assertEquals("customerLocation", error.getField());
        Assert.assertEquals("order.location.notbelongs", error.getMessageTemplate());
    }

    @Test
    public void validateFinalizeDraftError() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(true);
        Assert.assertNull(validator.validateDraft(salesOrder));
    }

    @Test
    public void validateFinalizeDraft() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(false);
        TestCase.assertNotNull(validator.validateDraft(salesOrder));
    }

    @Test
    public void validateFinalizeWithoutItemsError() {
        final SalesOrder salesOrder = new SalesOrder();
        final SalesOrderItem item = new SalesOrderItem();

        final List<SalesOrderItem> itens = new LinkedList<SalesOrderItem>();
        itens.add(item);
        salesOrder.setItems(itens);

        Assert.assertNull(validator.validateSalesOrderHaveItems(salesOrder));
    }

    @Test
    public void validateFinalizeWithoutItems() {
        final SalesOrder salesOrder = new SalesOrder();

        TestCase.assertNotNull(validator.validateSalesOrderHaveItems(salesOrder));
    }

    @Test
    public void validateFinalizeValueError() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.TEN);
        Assert.assertNull(validator.validateValueMoreThanZero(salesOrder));
    }

    @Test
    public void validateFinalizeValue() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setNetValue(BigDecimal.ZERO);
        TestCase.assertNotNull(validator.validateValueMoreThanZero(salesOrder));
    }


    @Test
    public void validateMoreThanOneCreditLimit_withSingleCreditLimit() {
        final CreditLimit creditLimit = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        Assert.assertNull(validator.validateMoreThanOneCreditLimit(creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateMoreThanOneCreditLimit_withoutCreditsLimits() {
        Assert.assertNull(validator.validateMoreThanOneCreditLimit(null, Boolean.TRUE));
    }

    @Test
    public void validateMoreThanOneCreditLimit_withoutConfiguration() {
        final CreditLimit creditLimit = new CreditLimit();
        final CreditLimit creditLimitTwo = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        creditLimits.add(creditLimitTwo);
        Assert.assertNull(validator.validateMoreThanOneCreditLimit(creditLimits, Boolean.FALSE));
    }

    @Test
    public void validateMoreThanOneCreditLimit_withCreditLimitIsNotRequired() {
        final CreditLimit creditLimit = new CreditLimit();
        final CreditLimit creditLimitTwo = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        creditLimits.add(creditLimitTwo);
        Assert.assertNull(validator.validateMoreThanOneCreditLimit(creditLimits, Boolean.FALSE));
    }

    @Test
    public void validateMoreThanOneCreditLimit_withMoreThenOneCreditLimit() {
        final CreditLimit creditLimit = new CreditLimit();
        final CreditLimit creditLimitTwo = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        creditLimits.add(creditLimitTwo);
        final LogicError error = validator.validateMoreThanOneCreditLimit(creditLimits, Boolean.TRUE);
        TestCase.assertNotNull(error);
        Assert.assertEquals("sales", error.getField());
        Assert.assertEquals("order.creditLimit.moreThanOneCreditLimit", error.getMessageTemplate());
    }

    @Test
    public void validateExistsCreditLimit_withCreditLimit() {
        final CreditLimit creditLimit = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        Assert.assertNull(validator.validateExistsCreditLimit(creditLimits, Boolean.TRUE));
    }


    @Test
    public void validateExistsCreditLimit_withCreditLimitIsNotRequired() {
        final CreditLimit creditLimit = new CreditLimit();
        final List<CreditLimit> creditLimits = new ArrayList<>();
        creditLimits.add(creditLimit);
        Assert.assertNull(validator.validateExistsCreditLimit(creditLimits, Boolean.FALSE));
    }

    @Test
    public void validateExistsCreditLimit_withoutCreditsLimits() {
        final LogicError error = validator.validateExistsCreditLimit(null, Boolean.TRUE);
        TestCase.assertNotNull(error);
        Assert.assertEquals("sales", error.getField());
        Assert.assertEquals("order.creditLimit.notExists", error.getMessageTemplate());
    }

    @Test
    public void validateExistsCreditLimit_withoutCreditLimit() {
        final List<CreditLimit> creditLimits = new ArrayList<>();
        final LogicError error = validator.validateExistsCreditLimit(creditLimits, Boolean.TRUE);
        TestCase.assertNotNull(error);
        Assert.assertEquals("sales", error.getField());
        Assert.assertEquals("order.creditLimit.notExists", error.getMessageTemplate());
    }

    @Test
    public void validateCreditLimitWithValidValue() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.TEN);
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);

        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        Assert.assertNull(validator.validateCreditLimitIsNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitWithInvalidValue() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.TEN);
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.ZERO);

        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        TestCase.assertNotNull(validator.validateCreditLimitIsNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitBecameNegative() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(100));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);

        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        TestCase.assertNotNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitValid() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(5));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);

        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        Assert.assertNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateCreditLimitWithoutRegister() {
        final SalesOrder order = new SalesOrder();
        order.setNetValue(BigDecimal.valueOf(5));
        order.setCustomerId(UUID.randomUUID());
        order.setCompanyId(UUID.randomUUID());
        order.setLocationId(UUID.randomUUID());

        final CreditLimit creditLimit = new CreditLimit();
        creditLimit.setRemainingValue(BigDecimal.TEN);

        final List<CreditLimit> creditLimits = new LinkedList<>();
        creditLimits.add(creditLimit);

        Assert.assertNull(validator.validateCreditLimitBecameNegative(order, creditLimits, Boolean.TRUE));
    }

    @Test
    public void validateInformedProfessional() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());
        salesOrder.setUserProfessionalName("professional");

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);
        Assert.assertNull(error);
    }

    @Test
    public void validateInformedProfessionalWithoutProfessionalId() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalName("professional");

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("professional", error.getField());
        Assert.assertEquals("javax.validation.constraints.NotNull.message", error.getMessage());
    }

    @Test
    public void validateInformedProfessionalWithoutProfessionalName() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setUserProfessionalId(UUID.randomUUID());

        final LogicError error = validator.validateUserProfessionalNotNull(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("professional", error.getField());
        Assert.assertEquals("javax.validation.constraints.NotNull.message", error.getMessage());
    }

    @Test
    public void validatePriceListInValidity() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().toString());
        priceList.setEndOn(LocalDate.now().plusDays(1).toString());

        Mockito.when(productGateway.getPriceList(Matchers.any())).thenReturn(priceList);

        Assert.assertNull(headerValidator.validatePriceListIsOutOfDate(salesOrder));
    }

    @Test
    public void validatePriceListInValidityWithoutPriceList() {
        Mockito.when(productGateway.getPriceList(Matchers.any())).thenReturn(null);
        Assert.assertNull(headerValidator.validatePriceListIsOutOfDate(new SalesOrder()));
    }

    @Test
    public void validatePriceListOutOfDateWithDateBeforeToday() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().minusDays(2).toString());
        priceList.setEndOn(LocalDate.now().minusDays(1).toString());

        Mockito.when(productGateway.getPriceList(Matchers.any())).thenReturn(priceList);

        final LogicError error = headerValidator.validatePriceListIsOutOfDate(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("priceListId", error.getField());
        Assert.assertEquals("order.priceListOutOfDate", error.getMessage());
    }

    @Test
    public void validatePriceListOutOfDateWithDateAfterToday() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setPriceListId(UUID.randomUUID());

        final PriceList priceList = new PriceList();
        priceList.setStartOn(LocalDate.now().plusDays(1).toString());
        priceList.setEndOn(LocalDate.now().plusDays(2).toString());

        Mockito.when(productGateway.getPriceList(Matchers.any())).thenReturn(priceList);

        final LogicError error = headerValidator.validatePriceListIsOutOfDate(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("priceListId", error.getField());
        Assert.assertEquals("order.priceListOutOfDate", error.getMessage());
    }

    /**
     * is valid if the order has a delivery and the location from delivery belongs to the customer
     *
     * @author Maykon Rissi
     */
    @Test
    public void isInvalidIfLocationFromDeliveryBelongsToCustomer() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.TRUE);

        final DeliveryOrder deliveryOrder = new DeliveryOrder();
        deliveryOrder.setLocationId(UUID.randomUUID());

        final List<DeliveryOrder> deliveryOrders = new LinkedList<>();
        deliveryOrders.add(deliveryOrder);

        salesOrder.setDeliveryOrders(deliveryOrders);

        Mockito.when(customerGateway.locationBelongsToCustomer(Matchers.any(), Matchers.any())).thenReturn(Boolean.FALSE);

        final LogicError error = validator.validateIfLocationFromDeliveryBelongsToCustomer(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("sales", error.getField());
        Assert.assertEquals("delivery.location.dontBelong", error.getMessage());
    }

    /**
     * is invalid if the order has a delivery and the location from delivery dont belongs to the customer
     *
     * @author Maykon Rissi
     */
    @Test
    public void isValidIfLocationFromDeliveryBelongsToCustomer() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.TRUE);

        final DeliveryOrder deliveryOrder = new DeliveryOrder();
        deliveryOrder.setLocationId(UUID.randomUUID());

        final List<DeliveryOrder> deliveryOrders = new LinkedList<>();
        deliveryOrders.add(deliveryOrder);

        salesOrder.setDeliveryOrders(deliveryOrders);

        Mockito.when(customerGateway.locationBelongsToCustomer(Matchers.any(), Matchers.any())).thenReturn(Boolean.FALSE);

        final LogicError error = validator.validateIfLocationFromDeliveryBelongsToCustomer(salesOrder);

        TestCase.assertNotNull(error);
        Assert.assertEquals("sales", error.getField());
        Assert.assertEquals("delivery.location.dontBelong", error.getMessage());
    }

    /**
     * is valid if the order hasn't a delivery
     *
     * @author Maykon Rissi
     */
    @Test
    public void isValidIfTheOrderHasNotADelivery() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setDraft(Boolean.TRUE);

        salesOrder.setDeliveryOrders(null);

        Mockito.when(customerGateway.locationBelongsToCustomer(Matchers.any(), Matchers.any())).thenReturn(Boolean.FALSE);

        final LogicError error = validator.validateIfLocationFromDeliveryBelongsToCustomer(salesOrder);

        Assert.assertNull(error);
    }
    
    @Test
    public void notAllowChangeIncotermsAcronymOnThereAreItemsInOrderReturnsLogicError() {
        final SalesOrder orderDb = new SalesOrder();
        orderDb.setId(UUID.randomUUID());
        orderDb.setIncotermsAcronym(IncotermsAcronym.CIF);
        orderDb.setItems(Arrays.asList(new SalesOrderItem()));
        
        Mockito.when(this.salesOrderDAO.findById(orderDb.getId())).thenReturn(orderDb);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderDb.getId());
        toUpdate.setIncotermsAcronym(IncotermsAcronym.FOB);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNotNull(error);
        Assert.assertEquals(Constants.FIELD_INCOTERMS_ACRONYM, error.getField());
        Assert.assertEquals(Constants.MESSAGE_DELIVERY_CHANGE_INCOTERMS_NOT_ALLOWED, error.getMessage());
    }
        
    @Test
    public void notAllowChangeIncotermsAcronymToNullOnThereAreItemsInOrderReturnsLogicError() {
        final SalesOrder orderDb = new SalesOrder();
        orderDb.setId(UUID.randomUUID());
        orderDb.setIncotermsAcronym(IncotermsAcronym.CIF);
        orderDb.setItems(Arrays.asList(new SalesOrderItem()));
        
        Mockito.when(this.salesOrderDAO.findById(orderDb.getId())).thenReturn(orderDb);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderDb.getId());
        toUpdate.setIncotermsAcronym(null);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNotNull(error);
        Assert.assertEquals(Constants.FIELD_INCOTERMS_ACRONYM, error.getField());
        Assert.assertEquals(Constants.MESSAGE_DELIVERY_CHANGE_INCOTERMS_NOT_ALLOWED, error.getMessage());
    }

    @Test
    public void notAllowChangeIncotermsAcronymToFobOnThereAreItemsInOrderReturnsLogicError() {
        final SalesOrder orderDb = new SalesOrder();
        orderDb.setId(UUID.randomUUID());
        orderDb.setIncotermsAcronym(null);
        orderDb.setItems(Arrays.asList(new SalesOrderItem()));
        
        Mockito.when(this.salesOrderDAO.findById(orderDb.getId())).thenReturn(orderDb);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderDb.getId());
        toUpdate.setIncotermsAcronym(IncotermsAcronym.FOB);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNotNull(error);
        Assert.assertEquals(Constants.FIELD_INCOTERMS_ACRONYM, error.getField());
        Assert.assertEquals(Constants.MESSAGE_DELIVERY_CHANGE_INCOTERMS_NOT_ALLOWED, error.getMessage());
    }
    
    @Test
    public void notChangeIncotermsAcronymOnThereAreItemsInOrderReturnsNull() {
        final SalesOrder orderDb = new SalesOrder();
        orderDb.setId(UUID.randomUUID());
        orderDb.setIncotermsAcronym(IncotermsAcronym.CIF);
        orderDb.setItems(Arrays.asList(new SalesOrderItem()));
        
        Mockito.when(this.salesOrderDAO.findById(orderDb.getId())).thenReturn(orderDb);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderDb.getId());
        toUpdate.setIncotermsAcronym(IncotermsAcronym.CIF);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNull(error);
    }
    
    @Test
    public void allowChangeIncotermsAcronymOnThereArentItemsInOrderReturnsLogicError() {
        final SalesOrder orderDb = new SalesOrder();
        orderDb.setId(UUID.randomUUID());
        orderDb.setIncotermsAcronym(IncotermsAcronym.CIF);
        
        Mockito.when(this.salesOrderDAO.findById(orderDb.getId())).thenReturn(orderDb);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderDb.getId());
        toUpdate.setIncotermsAcronym(IncotermsAcronym.FOB);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNull(error);
    }
    
    @Test
    public void insertNewOrderWithIncotermsAcronymReturnsNull() {
        final UUID orderId = UUID.randomUUID();

        Mockito.when(this.salesOrderDAO.findById(orderId)).thenReturn(null);
        
        final SalesOrder toUpdate = new SalesOrder();
        toUpdate.setId(orderId);
        toUpdate.setIncotermsAcronym(IncotermsAcronym.FOB);
        
        final LogicError error = this.headerValidator.doValidateChangeIncoterms(toUpdate);
        Assert.assertNull(error);
    }

    @Test
    public void shouldNotAllowToInsertOrderWithNonexistentActivity() {
        final UUID id = UUID.randomUUID();

        final SalesOrder order = new SalesOrder();
        order.setActivityId(id);

        Mockito.when(this.opportunityGateway.activityNotExists(id)).thenReturn(true);

        final LogicError error = this.headerValidator.validateActivityExists(order);
        Assert.assertThat(error, notNullValue());
    }

    @Test
    public void shouldNotValidateActivityWhenActivityIdIsNull() {
        final LogicError error = this.headerValidator.validateActivityExists(new SalesOrder());
        Assert.assertThat(error, nullValue());
    }
}