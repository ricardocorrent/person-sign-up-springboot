package com.ws.sales.order.OrderCurrency;

import com.sollar.test.BaseUnitTest;
import com.ws.administration.model.Currency;
import com.ws.administration.model.ExchangeRate;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.administration.AdministrationGateway;
import com.ws.sales.ordercurrency.OrderCurrency;
import com.ws.sales.ordercurrency.OrderCurrencyValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.UUID;

import static org.junit.Assert.assertNull;
import static org.testng.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class OrderCurrencyUnitTest extends BaseUnitTest {

    @Mock
    private AdministrationGateway administrationGateway;

    @InjectMocks
    private OrderCurrencyValidator validator;

    @Test
    public void validateOrderCurrencyExists() {
        final UUID orderCurrencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(orderCurrencyId);

        Mockito.when(administrationGateway.currencyExists(orderCurrencyId)).thenReturn(Boolean.TRUE);

        assertNull(validator.validateCurrencyExists(orderCurrency));
    }

    @Test
    public void validateOrderCurrencyExistsWithoutOrderCurrencyId() {
        final OrderCurrency orderCurrency = new OrderCurrency();
        assertNull(validator.validateCurrencyExists(orderCurrency));
    }

    @Test
    public void validateOrderCurrencyNotExists() {
        final UUID orderCurrencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(orderCurrencyId);

        final LogicError error = validator.validateCurrencyExists(orderCurrency);

        assertEquals("currencyId", error.getField());
        assertEquals("order.orderCurrency.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateCurrencyQuotationExists() {
        final UUID currencyQuotationId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        Mockito.when(administrationGateway.currencyQuotationExists(currencyQuotationId)).thenReturn(Boolean.TRUE);

        assertNull(validator.validateCurrencyQuotationExists(orderCurrency));
    }

    @Test
    public void validateCurrencyQuotationExistsWithoutCurrencyQuotationId() {
        final OrderCurrency orderCurrency = new OrderCurrency();
        assertNull(validator.validateCurrencyQuotationExists(orderCurrency));
    }

    @Test
    public void validateCurrencyQuotationNotExists() {
        final UUID currencyQuotationId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        final LogicError error = validator.validateCurrencyQuotationExists(orderCurrency);

        assertEquals("currencyQuotationId", error.getField());
        assertEquals("order.currencyQuotation.notFound", error.getMessageTemplate());
    }

    @Test
    public void validateOrderCurrencyIsActive() {
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);

        Mockito.when(administrationGateway.currencyIsActive(currencyId)).thenReturn(Boolean.TRUE);

        assertNull(validator.validateCurrencyIsActive(orderCurrency));
    }

    @Test
    public void validateOrderCurrencyIsActiveWithoutCurrencyId() {
        final OrderCurrency orderCurrency = new OrderCurrency();
        assertNull(validator.validateCurrencyIsActive(orderCurrency));
    }

    @Test
    public void validateOrderCurrencyInactive() {
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);

        final LogicError error = validator.validateCurrencyIsActive(orderCurrency);

        assertEquals("currencyId", error.getField());
        assertEquals("order.orderCurrency.inactive", error.getMessageTemplate());
    }

    @Test
    public void validateQuotationBelongsToOrderCurrency() {
        final UUID currencyQuotationId = UUID.randomUUID();
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        final Currency currency = new Currency();
        currency.setId(currencyId.toString());

        final ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.setCurrency(currency);

        Mockito.when(administrationGateway.getExchangeRate(currencyQuotationId)).thenReturn(exchangeRate);

        assertNull(validator.validateQuotationBelongsToOrderCurrency(orderCurrency));
    }

    @Test
    public void validateQuotationBelongsToOrderCurrencyWithNonExistentQuotation() {
        final UUID currencyQuotationId = UUID.randomUUID();
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        Mockito.when(administrationGateway.getExchangeRate(currencyQuotationId)).thenReturn(null);

        assertNull(validator.validateQuotationBelongsToOrderCurrency(orderCurrency));
    }

    @Test
    public void validateQuotationBelongsToOrderCurrencyWithoutCurrencyId() {
        final UUID currencyQuotationId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        assertNull(validator.validateQuotationBelongsToOrderCurrency(orderCurrency));
    }

    @Test
    public void validateQuotationBelongsToOrderCurrencyWithoutCurrencyQuotationId() {
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);

        assertNull(validator.validateQuotationBelongsToOrderCurrency(orderCurrency));
    }

    @Test
    public void validateQuotationNotBelongsToOrderCurrency() {
        final UUID currencyQuotationId = UUID.randomUUID();
        final UUID currencyId = UUID.randomUUID();

        final OrderCurrency orderCurrency = new OrderCurrency();
        orderCurrency.setCurrencyId(currencyId);
        orderCurrency.setCurrencyQuotationId(currencyQuotationId);

        final Currency currency = new Currency();
        currency.setId(UUID.randomUUID().toString());

        final ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.setCurrency(currency);

        Mockito.when(administrationGateway.getExchangeRate(currencyQuotationId)).thenReturn(exchangeRate);

        final LogicError error = validator.validateQuotationBelongsToOrderCurrency(orderCurrency);


        assertEquals("currencyQuotationId", error.getField());
        assertEquals("order.orderCurrency.quotationDateNotBelongsToCurrency", error.getMessageTemplate());
    }
}
