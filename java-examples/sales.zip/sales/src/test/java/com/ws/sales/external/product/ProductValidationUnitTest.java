package com.ws.sales.external.product;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.product.model.PriceList;
import com.ws.product.model.PriceListItem;
import com.ws.product.model.Product;
import com.ws.product.model.ProductPackaging;
import com.ws.sales.util.Constants;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Tests for product, price list, price list item and package
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-21
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductValidationUnitTest {

    @InjectMocks
    private ProductValidation productValidation;

    @Mock
    private ProductGateway productGateway;

    @Mock
    private OrderParameterService orderParameterService;

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productExistAndIsActive() {
        final Product product = new Product();
        product.setActive(Boolean.TRUE);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateProductCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productExistAndIsInactive() {
        final Product product = new Product();
        product.setActive(Boolean.FALSE);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateProductCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productDoesNotExist() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidateProductCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemExists() {
        final PriceListItem priceListItem = new PriceListItem();
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidatePriceListItemCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemDoesNotExist() {
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidatePriceListItemCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }


    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = productValidation.doValidateProductCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a product that belongs to the priceListItem. Must not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productBelongsToPriceListItem() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setId(UUID.randomUUID().toString());
        final Product product = new Product();
        product.setId(UUID.randomUUID().toString());
        priceListItem.setProduct(product);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateProductBelongToThePriceListItem(UUID.randomUUID(), UUID.fromString(product.getId()));
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a product that doest not belong to the priceListItem. Must not return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productDoesNotBelongToPriceListItem() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setId(UUID.randomUUID().toString());
        final Product product = new Product();
        product.setId(UUID.randomUUID().toString());
        priceListItem.setProduct(product);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateProductBelongToThePriceListItem(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a price list item that does not exists in db. Must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productBelongToPriceListCantBeValidateBecausePriceListItemDoesNotExist() {
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidateProductBelongToThePriceListItem(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with null values. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productBelongToPriceListItemCantBeValidateBecauseValuesAreNull() {
        final LogicError logicError = productValidation.doValidateProductBelongToThePriceListItem(null, null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a item that belongs to the priceList. Must not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemBelongsToPriceList() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setId(UUID.randomUUID().toString());
        final PriceList priceList = new PriceList();
        priceList.getItems().add(priceListItem);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListItemBelongsToThePriceList(UUID.fromString(priceListItem.getId()), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a item that does not belong to the priceList. Must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemDoestNotBelongToPriceList() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setId(UUID.randomUUID().toString());
        final PriceList priceList = new PriceList();
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListItemBelongsToThePriceList(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a price list that does not exists in db. Must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemBelongToPriceListCantBeValidateBecausePriceListDoesNotExist() {
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidatePriceListItemBelongsToThePriceList(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with null values. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListItemBelongToPriceListCantBeValidateBecauseValuesAreNull() {
        final LogicError logicError = productValidation.doValidatePriceListItemBelongsToThePriceList(null, null);
        Assert.assertNull(logicError);
    }

    /**
     * Creates a register active and without start and end dates. Expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListExistAndIsActiveAndDoesNotHaveDates() {
        final PriceList priceList = new PriceList();
        priceList.setActive(Boolean.TRUE);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates a register active with valid dates. Expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListExistAndIsActiveAndIsInDate() {
        final PriceList priceList = new PriceList();
        priceList.setActive(Boolean.TRUE);
        priceList.setStartOn(LocalDate.now().toString());
        priceList.setEndOn(LocalDate.now().toString());
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListExistAndIsInactive() {
        final PriceList priceList = new PriceList();
        priceList.setActive(Boolean.FALSE);
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Creates an expired register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListExistAndIsExpired() {
        final PriceList priceList = new PriceList();
        priceList.setActive(Boolean.TRUE);
        priceList.setEndOn(LocalDate.now().minusDays(1).toString());
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Creates an register that did not started yet and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListExistAndDidNotStartedYet() {
        final PriceList priceList = new PriceList();
        priceList.setActive(Boolean.TRUE);
        priceList.setStartOn(LocalDate.now().plusDays(1).toString());
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(priceList);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListDoesNotExist() {
        Mockito.when(productGateway.getPriceList(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void priceListCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = productValidation.doValidatePriceListCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with fraction sale and a product that can be in fraction. It must does not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productPermitsFractionSaleAndIsInFraction() {
        final Product product = new Product();
        product.setSaleFractioned(Boolean.TRUE);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateProductPermitFractionSale(BigDecimal.valueOf(10.5), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with fraction sale and a product that can not be in fraction. It must returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void productDoesNotPermitFractionSaleAndIsInFraction() {
        final Product product = new Product();
        product.setSaleFractioned(Boolean.FALSE);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateProductPermitFractionSale(BigDecimal.valueOf(10.5), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a null productId. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void mustHaveAndProductIdToValidateFractionSale() {
        final LogicError logicError = productValidation.doValidateProductPermitFractionSale(BigDecimal.valueOf(10.5), null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a product tha does not exists in database. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void mustHaveAnExistingProductInDbToValidateFractionSale() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidateProductPermitFractionSale(BigDecimal.valueOf(10.5), UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a package that exists in the product. It must does not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void packageExistsInTheProduct() {
        final Product product = new Product();
        final ProductPackaging productPackaging = new ProductPackaging();
        productPackaging.setId(UUID.randomUUID().toString());
        product.getPackagings().add(productPackaging);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidatePackageCanBeUsed(UUID.randomUUID(), UUID.fromString(productPackaging.getId()));
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a package that does not exist in the product. It must returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void packageDoesNotExistsInTheProduct() {
        final Product product = new Product();
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidatePackageCanBeUsed(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate the package without the packageId. It must does nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void canNotValidatePackageWithoutPackageId() {
        final LogicError logicError = productValidation.doValidatePackageCanBeUsed(UUID.randomUUID(), null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate the package without the productId. It must does nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void canNotValidatePackageWithoutProductId() {
        final LogicError logicError = productValidation.doValidatePackageCanBeUsed(null, UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a product tha does not exists in database. It must returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void canNotValidatePackageBecauseProductDoesNotExistsInDatabase() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidatePackageCanBeUsed(UUID.randomUUID(), UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a quantity that match the conversion. It must does not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackagingIsValid() {
        final Product product = new Product();
        final ProductPackaging productPackaging = new ProductPackaging();
        productPackaging.setId(UUID.randomUUID().toString());
        productPackaging.setConversionFactor(BigDecimal.valueOf(5));
        product.getPackagings().add(productPackaging);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateQuantityOfPackaging(UUID.randomUUID(), UUID.fromString(productPackaging.getId()), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a quantity that does not match the conversion. It must does not returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackagingIsInvalid() {
        final Product product = new Product();
        final ProductPackaging productPackaging = new ProductPackaging();
        productPackaging.setId(UUID.randomUUID().toString());
        productPackaging.setConversionFactor(BigDecimal.valueOf(7));
        product.getPackagings().add(productPackaging);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateQuantityOfPackaging(UUID.randomUUID(), UUID.fromString(productPackaging.getId()), BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a package that does not have conversion factor. It must not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackageMustNotValidateBecausePackageDoesNotHaveConversionFactor() {
        final Product product = new Product();
        final ProductPackaging productPackaging = new ProductPackaging();
        productPackaging.setId(UUID.randomUUID().toString());
        product.getPackagings().add(productPackaging);
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        final LogicError logicError = productValidation.doValidateQuantityOfPackaging(UUID.randomUUID(), UUID.fromString(productPackaging.getId()), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a package that does not exists. It must throw a require not null
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackageMustNotValidateBecausePackageDoesNotExistsAndThrowError() {
        final Product product = new Product();
        final ProductPackaging productPackaging = new ProductPackaging();
        productPackaging.setId(UUID.randomUUID().toString());
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(product);
        try {
            productValidation.doValidateQuantityOfPackaging(UUID.randomUUID(), UUID.fromString(productPackaging.getId()), BigDecimal.TEN);
        } catch (final Exception ex) {
            Assert.assertEquals(ex.getMessage(), EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(Constants.FIELD_PRODUCT_PACKAGING));
        }
    }

    /**
     * Tries to validate with a product that does not exists. It must throw a require not null
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackageMustNotValidateBecauseProductDoesNotExistsAndThrowError() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        try {
            productValidation.doValidateQuantityOfPackaging(UUID.randomUUID(), UUID.fromString(UUID.randomUUID().toString()), BigDecimal.TEN);
        } catch (final Exception ex) {
            Assert.assertEquals(ex.getMessage(), EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(Constants.FIELD_PRODUCT_PACKAGING));
        }
    }

    /**
     * Tries to validate with null params. It must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void quantityOfPackagingMustNotValidateBecauseParamsAreNull() {
        Mockito.when(productGateway.getProduct(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidateQuantityOfPackaging(null, null, null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a original price that is equal to the price list item price. It must not return a logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void originalValueIsEqualsToPriceListValue() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setSalesPrice(BigDecimal.TEN);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateOriginalPriceIsEqualToPriceListItemPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with a original price that is not equal to the price list item price. It must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void originalValueIsDifferentThanPriceListValue() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setSalesPrice(BigDecimal.ONE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateOriginalPriceIsEqualToPriceListItemPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with a original price null. Must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void canNotValidateWithOriginalPriceNull() {
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setSalesPrice(BigDecimal.ONE);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateOriginalPriceIsEqualToPriceListItemPrice(UUID.randomUUID(), null);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with no priceListItemId. Must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void canNotValidateWithPriceListItemNull() {
        final LogicError logicError = productValidation.doValidateOriginalPriceIsEqualToPriceListItemPrice(null, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with the plugin active and a value higher than the minimum price. Must not return and logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceIsValidBecausePluginIsActivatedAndValueIsHigherThanMinimum() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setMinimumPrice(BigDecimal.ONE);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateMinimumPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with the plugin active a null value. It must returns an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceIsInvalidBecausePluginIsActivatedAndValueIsLowerThanMinimum() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setMinimumPrice(BigDecimal.TEN);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateMinimumPrice(UUID.randomUUID(), BigDecimal.ONE);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate with the plugin active a value equal to minimum value. It must not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceIsValidBecausePluginIsActivatedAndValueIsEqualMinimum() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        final PriceListItem priceListItem = new PriceListItem();
        priceListItem.setMinimumPrice(BigDecimal.TEN);
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(priceListItem);
        final LogicError logicError = productValidation.doValidateMinimumPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with the plugin active and a null priceListItemId. It must not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceIsCanNotBeValidatedBecausePriceListItemIdIsNull() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        final LogicError logicError = productValidation.doValidateMinimumPrice(null, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with the plugin active and a price list item that does not exists in DB. It must not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceIsCanNotBeValidatedBecausePriceListItemIsNull() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("true");
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        Mockito.when(productGateway.getPriceListItem(Mockito.any())).thenReturn(null);
        final LogicError logicError = productValidation.doValidateMinimumPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate with the plugin inactive. It must returns do not return an logic error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void minimumPriceWillNotValidateBecausePluginIsFalse() {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue("false");
        Mockito.when(orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
        final LogicError logicError = productValidation.doValidateMinimumPrice(UUID.randomUUID(), BigDecimal.TEN);
        Assert.assertNull(logicError);
    }
}
