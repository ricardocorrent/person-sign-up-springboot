package com.ws.sales.order.SalesOrderTest;

import com.sollar.test.BaseUnitTest;
import com.ws.sales.order.SalesOrderSearch;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

import static org.testng.Assert.assertEquals;

/**
 * @author Samuel Blum Vorpagel <samuel.vorpagel@wssim.com.br>
 * @since v 2017-03-08
 */

@RunWith(MockitoJUnitRunner.class)
public class SalesOrderSearchUnitTest extends BaseUnitTest {

    private static final String RANDOM_STRING = UUID.randomUUID().toString();
    private UUID id = UUID.randomUUID();

    @Test
    public void validSetAndGet_Draft() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        Boolean[] bools = {true};
        salesOrderSearch.setDraft(bools);

        assertEquals(bools, salesOrderSearch.getDraft());
    }

    @Test
    public void validSetAndGet_OrderNumber() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setOrderNumber(RANDOM_STRING);

        assertEquals(RANDOM_STRING, salesOrderSearch.getOrderNumber());
    }

    @Test
    public void validSetAndGet_ExternalNumber() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setExternalNumber(RANDOM_STRING);

        assertEquals(RANDOM_STRING, salesOrderSearch.getExternalNumber());
    }

    @Test
    public void validSetAndGet_CustomerNumber() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setCustomerNumber(RANDOM_STRING);

        assertEquals(RANDOM_STRING, salesOrderSearch.getCustomerNumber());
    }

    @Test
    public void validSetAndGet_InitialOrderedDate() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        LocalDate localDate = LocalDate.now();

        salesOrderSearch.setInitialOrderedDate(localDate);

        assertEquals(localDate, salesOrderSearch.getInitialOrderedDate());
    }

    @Test
    public void validSetAndGet_FinalOrderedDate() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        LocalDate localDate = LocalDate.now();

        salesOrderSearch.setFinalOrderedDate(localDate);

        assertEquals(localDate, salesOrderSearch.getFinalOrderedDate());
    }

    @Test
    public void validSetAndGet_InvoicedBetween() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        OffsetDateTime[] offsetDateTimes = {OffsetDateTime.MAX};

        salesOrderSearch.setInvoicedBetween(offsetDateTimes);

        assertEquals(offsetDateTimes, salesOrderSearch.getInvoicedBetween());
    }

    @Test
    public void validSetAndGet_CustomerId() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setCustomerId(id);

        assertEquals(id, salesOrderSearch.getCustomerId());
    }

    @Test
    public void validSetAndGet_UserId() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setUserId(id);

        assertEquals(id, salesOrderSearch.getUserId());
    }

    @Test
    public void validSetAndGet_LocationId() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        salesOrderSearch.setLocationId(id);

        assertEquals(id, salesOrderSearch.getLocationId());
    }

    @Test
    public void validSetAndGet_Origin() {
        final SalesOrderSearch salesOrderSearch = new SalesOrderSearch();

        String[] str = {RANDOM_STRING};
        salesOrderSearch.setOrigin(str);

        assertEquals(str, salesOrderSearch.getOrigin());
    }
}
