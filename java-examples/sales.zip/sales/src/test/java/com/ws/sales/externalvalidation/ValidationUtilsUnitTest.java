package com.ws.sales.externalvalidation;

import com.ws.commons.server.validation.exception.IndexedLogicError;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.util.Constants;
import com.ws.sales.validator.ValidationUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Tests for validation utils
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-18
 */
@RunWith(MockitoJUnitRunner.class)
public class ValidationUtilsUnitTest {

    /**
     * Creates a valid error with params. Must return a logic error with the passed parameters.
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void createErrorWithValidParams() {
        final LogicError error = ValidationUtils.doCreateLogicErrorWithParam(Constants.FIELD_MINIMUM_PRICE,
                "12",
                Constants.FIELD_SALES_PRICE,
                Constants.MESSAGE_PRICE_LOWER_THAN_MINIMUM);
        Assert.assertEquals(Constants.FIELD_SALES_PRICE, error.getField());
        Assert.assertEquals(Constants.MESSAGE_PRICE_LOWER_THAN_MINIMUM, error.getMessage());
        Assert.assertEquals(Constants.MESSAGE_PRICE_LOWER_THAN_MINIMUM, error.getMessageTemplate());
        Assert.assertEquals("12", error.getParams().get(Constants.FIELD_MINIMUM_PRICE));
    }

    /**
     * Tries to validate with a value bigger than zero. Must be false
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void valueIsBiggerThanZero() {
        Assert.assertFalse(ValidationUtils.isValueNullOrZero(BigDecimal.TEN));
    }

    /**
     * Tries to validate with a value equal to zero. Must be true
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void valueIsEqualToZero() {
        Assert.assertTrue(ValidationUtils.isValueNullOrZero(BigDecimal.ZERO));
    }

    /**
     * Tries to validate with a null value. Must be true
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void valueIsNull() {
        Assert.assertTrue(ValidationUtils.isValueNullOrZero(null));
    }

    /**
     * Tries to validate with the date of yesterday. Must be true
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateBeforeWithYesterdayDate() {
        final String date = LocalDate.now().minusDays(1).toString();
        Assert.assertTrue(ValidationUtils.isDateBeforeToday(date));
    }

    /**
     * Tries to validate with the date of today. Must be false
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateBeforeWithTodayDate() {
        final String date = LocalDate.now().toString();
        Assert.assertFalse(ValidationUtils.isDateBeforeToday(date));
    }

    /**
     * Tries to validate with the date of tomorrow. Must be false
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateBeforeWithTomorrowDate() {
        final String date = LocalDate.now().plusDays(1).toString();
        Assert.assertFalse(ValidationUtils.isDateBeforeToday(date));
    }

    /**
     * Tries to validate with the date of yesterday. Must be false
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateAfterWithYesterdayDate() {
        final String date = LocalDate.now().minusDays(1).toString();
        Assert.assertFalse(ValidationUtils.isDateAfterToday(date));
    }

    /**
     * Tries to validate with the date of today. Must be true
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateAfterWithTodayDate() {
        final String date = LocalDate.now().toString();
        Assert.assertFalse(ValidationUtils.isDateAfterToday(date));
    }

    /**
     * Tries to validate with the date of tomorrow. Must be true
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-21
     */
    @Test
    public void validateAfterWithTomorrowDate() {
        final String date = LocalDate.now().plusDays(1).toString();
        Assert.assertTrue(ValidationUtils.isDateAfterToday(date));
    }

    /**
     * Tries to validate with a null value. Must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-28
     */
    @Test
    public void valueIsNullAndFieldNameIsPresent() {
        Assert.assertNotNull(ValidationUtils.doValidateFieldMandatory(Constants.FIELD_COMPANY_ID, null));
    }

    /**
     * Tries to validate with a valida value. Must return not return an error
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-28
     */
    @Test
    public void valueIsNotNullAndFieldNameIsPresent() {
        Assert.assertNull(ValidationUtils.doValidateFieldMandatory(Constants.FIELD_COMPANY_ID, Constants.FIELD_VALUE));
    }

    /**
     * Tries to validate with null params. Must do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-28
     */
    @Test
    public void canNotValidateFieldMandatoryBecauseParamsAreNull() {
        Assert.assertNull(ValidationUtils.doValidateFieldMandatory(null, null));
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-04
     */
    @Test
    public void willConvertLogicErrorToIndexedLogicError() {
        final LogicError error = new LogicError("field", "message");
        final IndexedLogicError indexedLogicError = ValidationUtils.createIndexedFromLogicError("1", error);
        Assert.assertEquals(error.getField(), indexedLogicError.getField());
        Assert.assertEquals(error.getMessage(), indexedLogicError.getMessage());
        Assert.assertEquals("1", indexedLogicError.getIndex());
    }

    /**
     * @author Maykon Rissi
     * @since v6.2.0 2018-09-04
     */
    @Test
    public void wontConvertBecauseLogicErrorIsNull() {
        final IndexedLogicError indexedLogicError = ValidationUtils.createIndexedFromLogicError("1", null);
        Assert.assertNull(indexedLogicError);
    }
}
