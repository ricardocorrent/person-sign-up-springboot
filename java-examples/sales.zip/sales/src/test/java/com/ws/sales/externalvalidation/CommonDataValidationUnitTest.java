package com.ws.sales.externalvalidation;

import com.ws.commondata.model.Incoterms;
import com.ws.commons.server.validation.exception.LogicError;
import com.ws.sales.external.commondata.CommonDataValidation;
import com.ws.sales.external.commondata.CommonDataGateway;
import com.ws.sales.external.commondata.IncotermsAcronym;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Tests for customer and location validations
 *
 * @author Maykon Rissi
 * @since v5.22.0 2018-06-13
 */
@RunWith(MockitoJUnitRunner.class)
public class CommonDataValidationUnitTest {

    @InjectMocks
    private CommonDataValidation commonDataValidation;

    @Mock
    private CommonDataGateway commonDataGateway;

    /**
     * Creates an active register and expect the validation to do not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void incotermsExistAndIsActive() {
        final Incoterms incoterms = new Incoterms();
        incoterms.setActive(Boolean.TRUE);
        Mockito.when(commonDataGateway.getIncoterms(Mockito.any())).thenReturn(incoterms);
        final LogicError logicError = commonDataValidation.doValidateIncotermsCanBeUsed(UUID.randomUUID());
        Assert.assertNull(logicError);
    }

    /**
     * Creates an inactive register and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void incotermsExistAndIsInactive() {
        final Incoterms incoterms = new Incoterms();
        incoterms.setActive(Boolean.FALSE);
        Mockito.when(commonDataGateway.getIncoterms(Mockito.any())).thenReturn(incoterms);
        final LogicError logicError = commonDataValidation.doValidateIncotermsCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a register that does not exists and expect the validation to return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void incotermsDoesNotExist() {
        Mockito.when(commonDataGateway.getIncoterms(Mockito.any())).thenReturn(null);
        final LogicError logicError = commonDataValidation.doValidateIncotermsCanBeUsed(UUID.randomUUID());
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void incotermsCanNotBeLoadBecauseParamIdIsNull() {
        final LogicError logicError = commonDataValidation.doValidateIncotermsCanBeUsed(null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate freight value with FOB and null value. Must not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void freightValueFobIsValid() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueFob(IncotermsAcronym.FOB, null);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate freight value with FOB and a value. Must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void freightValueFobIsInvalid() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueFob(IncotermsAcronym.FOB, BigDecimal.TEN);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void valueCanNotBeValidatedBecauseFobAcronymIsNull() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueFob(null, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate freight value with CIF and a value. Must not return an logicError
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void freightValueCifIsValid() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueCif(IncotermsAcronym.CIF, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }

    /**
     * Tries to validate freight value with CIF and a value. Must return an {@link LogicError}
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void freightValueCifIsInvalid() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueCif(IncotermsAcronym.CIF, null);
        Assert.assertNotNull(logicError);
    }

    /**
     * Tries to validate a null register and expect the validation to do nothing
     *
     * @author Maykon Rissi
     * @since v5.22.0 2018-06-13
     */
    @Test
    public void valueCanNotBeValidatedBecauseCifAcronymIsNull() {
        final LogicError logicError = commonDataValidation.doValidateFreightValueFob(null, BigDecimal.TEN);
        Assert.assertNull(logicError);
    }
}
