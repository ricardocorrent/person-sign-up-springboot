import io.gatling.core.Predef._
import io.gatling.http.Predef._

class CustomerRequests extends Simulation {

  object Customer {

      val postCustomerWithLocation =
        exec(
          http("post_customer_with_location")
            .post("/api/v1/customer/customers")
            .body(StringBody(
              """{
                "id" : "${uuid}",
                "createdAt" : "2017-03-21T13:47:40.832Z",
                "updatedAt" : "2017-03-21T13:47:40.832Z",
                "active" : true,
                "name" : "Dark Amazo 153",
                "customerSince" : "2017-03-21",
                "customerIdentificationDocuments" : [ ],
                "customerPhones" : [ ],
                "customerEmails" : [ ],
                "contacts" : [ ],
                "locations" : [ {
                  "createdAt" : "2017-03-21T13:47:44.901Z",
                  "updatedAt" : "2017-03-21T13:47:44.901Z",
                  "customer" : {
                    "id" : "${uuid}",
                    "active" : true,
                    "name" : "Dark Amazo 153",
                    "customerIdentificationDocuments" : [ ],
                    "customerPhones" : [ ],
                    "customerEmails" : [ ],
                    "contacts" : [ ],
                    "locations" : [ ],
                    "customerGroups" : [ ]
                  },
                  "locationTypes" : [ ],
                  "locationBusinessLines" : [ ],
                  "active" : true,
                  "headquarter" : false,
                  "description" : "Mantarys 23",
                  "standard" : false,
                  "locationPhones" : [ ],
                  "locationEmails" : [ ],
                  "areas" : [ ],
                  "contacts" : [ ],
                  "locationIdentificationDocuments" : [ ]
                }],
                "customerGroups" : [ ]
              }
            """)).asJSON
          .check(status.is(201))
      )

    val getCustomer =
      exec(
        http("get_customers")
          .get("/api/v1/customer/customers?active=true&select=id,name")
          .check(status.is(200))
      )

    val getLocation =
      exec(
        http("get_customer_location")
          .get("/api/v1/customer/customers/b80fa0de-f2db-43d6-a427-84e9caf6cfd3/locations?active=true&select=id,description,street,addressNumber,district,cityName,stateName")
          .check(status.is(200))
      )
  }


}