package com.ws.sales.external.financial;

import com.ws.commons.server.validation.exception.MessageException;
import com.ws.financial.model.CreditLimit;
import com.ws.sales.util.Constants;
import com.ws.sales.order.SalesOrder;
import com.ws.sales.orderparameter.OrderParameter;
import com.ws.sales.orderparameter.OrderParameterService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;


/**
 * @author Maykon Rissi
 * @since v6.1.0 2018-08-16.
 */
@RunWith(MockitoJUnitRunner.class)
public class FinancialServiceUnitTest {

    @InjectMocks
    private FinancialService financialService;

    @Mock
    private OrderParameterService orderParameterService;

    @Mock
    private FinancialGateway financialGateway;

    /**
     * @param value to set the mock
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockOrderParameter(final Boolean value) {
        final OrderParameter orderParameter = new OrderParameter();
        orderParameter.setValue(value.toString());
        Mockito.when(this.orderParameterService.searchByKey(Mockito.any())).thenReturn(orderParameter);
    }

    /**
     * @param status to set the mock
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockInsertOfCreditLimit(final Response.Status status) {
        Mockito.when(this.financialGateway.insertCreditLimitMovement(Mockito.any())).thenReturn(Response.status(status).build());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private void doMockCreditLimitSearch() {
        final List<CreditLimit> creditLimitList = new LinkedList<>();
        creditLimitList.add(new CreditLimit());
        Mockito.when(this.financialGateway.searchCreditLimit(Mockito.any())).thenReturn(creditLimitList);
    }

    /**
     * Creates a new {@link SalesOrder} with the required fields
     *
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    private SalesOrder doMockNewSalesOrder() {
        final SalesOrder salesOrder = new SalesOrder();
        salesOrder.setId(UUID.randomUUID());
        salesOrder.setCustomerId(UUID.randomUUID());
        salesOrder.setLocationId(UUID.randomUUID());
        salesOrder.setCompanyId(UUID.randomUUID());
        salesOrder.setNetValue(BigDecimal.TEN);
        return salesOrder;
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void dueDatePluginIsEnabled() {
        this.doMockOrderParameter(Boolean.TRUE);
        Assert.assertTrue(this.financialService.isCreditLimitPluginEnabled());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void dueDatePluginIsDisabled() {
        this.doMockOrderParameter(Boolean.FALSE);
        Assert.assertFalse(this.financialService.isCreditLimitPluginEnabled());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void creditLimitMovementWasInsert() {
        this.doMockOrderParameter(Boolean.TRUE);
        this.doMockCreditLimitSearch();
        this.doMockInsertOfCreditLimit(Response.Status.CREATED);
        this.financialService.updateCreditLimit(this.doMockNewSalesOrder());
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void creditLimitMovementCouldNotBeInserted() {
        this.doMockOrderParameter(Boolean.TRUE);
        this.doMockCreditLimitSearch();
        this.doMockInsertOfCreditLimit(Response.Status.INTERNAL_SERVER_ERROR);
        try {
            this.financialService.updateCreditLimit(this.doMockNewSalesOrder());
        } catch (final MessageException ex) {
            Assert.assertEquals(Constants.MESSAGE_ORDER_GENERATE_CREDIT_LIMIT_ERROR, ex.getMessage());
        }
    }

    /**
     * @author Maykon Rissi
     * @since v6.1.0 2018-08-16.
     */
    @Test
    public void wontInsertBecauseCreditLimitPluginIsDisabled() {
        this.doMockOrderParameter(Boolean.FALSE);
        this.financialService.updateCreditLimit(this.doMockNewSalesOrder());
    }
}
