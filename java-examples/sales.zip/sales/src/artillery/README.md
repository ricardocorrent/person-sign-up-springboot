# 1 - Informações gerais
- Artillery é utilizado para testes de carga/stress...
- Nos .json é necessário alterar o id do "JSESSIONID" caso ocorra problema na execução (utilizada para não realizar login / consumir User)
- As informações do arquivo my-functions.json devem ser alterados conforme o ambiente a ser executado. Deve alterar também a url nos arquivos sales-header.json e sales-integration.json


# 2 - Comandos para execução dos testes:

- Execução com debug ativo (mostra http codes e responses por requisição):
    - DEBUG=http artillery run sales-header.json --output=sales-header-report.json
    - DEBUG=http artillery run sales-integration.json --output=sales-integration-report.json

- Execução normal, gerando um json com o resultados dos testes:
    - npm run integration
    - npm run header

- Criação de um report html a partir do json de output gerado:
    - artillery report sales-integration-report.json
    - artillery report sales-header-report.json

    Não é necessário comitar o report gerado

- Para mais comandos:
https://artillery.io/docs/cli-reference/
