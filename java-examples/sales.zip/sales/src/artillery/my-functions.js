"use strict";

module.exports = {
  generateRandomData
};

// Make sure to "npm install faker" first.
const Faker = require("faker");

function generateRandomData(userContext, events, done) {
  // generate data with Faker:
  const fullName = `${Faker.name.firstName()} ${Faker.name.lastName()}`;
  const name = Faker.name.firstName();
  const number = Faker.random.number();
  const email = Faker.internet.email();
  const username = "vendedor@teste.com";
  const password = "132";
  const tenant = "frimesa";
  const userVersion = "/v10";
  const companyId = "cb610f22-f6ca-4088-9bef-35461b021705";

  const salesVersion = "/v8";
  const userId = "4f89c769-1d76-43ef-b0f2-617848481cd7";
  const customerId = "76df93ff-f727-4477-ac11-60c7dcb95fde";
  const locationId = "d2b0469d-ec50-4351-b70c-6b30121faf4c";
  const orderTypeId = "b507051f-7910-46ad-96ca-c780ed849807";
  const priceListId = "07034232-fa66-4a08-88a0-4ab73ec4de8a";
  const pymtTermOrdertId = "5ccd0348-ef9d-47ee-9764-4f2ce1600277";
  const pymtMthdId = "b0fedba8-7cfa-4173-ace7-01819f96566e";
  const situationId = "9bfc6b3c-b1bb-4852-bdaf-beec07b4f2d6";
  const currencyId = "5ebcc87b-af5d-42ad-85ad-df620844055f";
  const currencyQuotationId = "42851313-c5d5-482b-b7bd-3553d497f22b";
  const productId = "c9e1c275-f23a-4a60-9689-8c064c9c75ea";
  const packagingId = "0522e8b5-e67f-42c8-8525-db6ebd860a71";
  const serviceId1 = "f5d343dd-a4d3-4c39-b9a9-453a82676c44";
  const serviceId2 = "397f17e8-3a0c-4080-a51a-436ac4000832";

  // add variables to virtual user's context:
  userContext.vars.fullName = fullName;
  userContext.vars.name = name;
  userContext.vars.number = number;
  userContext.vars.username = username;
  userContext.vars.password = password;
  userContext.vars.tenant = tenant;
  userContext.vars.userVersion = userVersion;
  userContext.vars.companyId = companyId;

  userContext.vars.salesVersion = salesVersion;
  userContext.vars.userId = userId;
  userContext.vars.customerId = customerId;
  userContext.vars.locationId = locationId;
  userContext.vars.orderTypeId = orderTypeId;
  userContext.vars.priceListId = priceListId;
  userContext.vars.pymtTermOrdertId = pymtTermOrdertId;
  userContext.vars.pymtMthdId = pymtMthdId;
  userContext.vars.situationId = situationId;
  userContext.vars.currencyId = currencyId;
  userContext.vars.currencyQuotationId = currencyQuotationId;
  userContext.vars.productId = productId;
  userContext.vars.packagingId = packagingId;
  userContext.vars.serviceId1 = serviceId1;
  userContext.vars.serviceId2 = serviceId2;

  // continue with executing the scenario:
  return done();
}
