[![build status](https://gitlab.wssim.com.br/sollar/sales/badges/development/build.svg)](https://gitlab.wssim.com.br/sollar/sales/commits/development)

<!-- TOC depthFrom:1 depthTo:3 orderedList:false withLinks:true anchorMode:gitlab.com -->

- 1 - Sales
    - 1.1 - Dependências
- 2 - Links Externos

# Sales 8.1.0

# 1 - Sales

### 1.1 Dependências

Na versão 8.1.0 foi adicionado suporte para geração de Documentos e para isso foi feito a integração com o Projeto Document Manager.
Portanto para a API `/sales/orders/{orderId}/document` (POST) funcionar corretamente é necessário que o Microsserviço de DocumentManager esteja corretamente configurado.

### 2 Links Externos

* [Document Manager](https://gitlab.wssim.com.br/cloud/document-manager)