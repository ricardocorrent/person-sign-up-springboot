insert into order_parameter (id,key,internationalization_key,value_type,value,note,created_at,updated_at,deleted)
values ('2cb4581d-127b-41dd-a8ec-7984bc6e02f4','ENABLE_DUE_DATE_FIELD','sales.orderConfiguration.enableDueDateField','BOOL','false','Exibe o campo Data de vencimento no cabeçalho do pedido',current_timestamp,current_timestamp,false);
insert into order_parameter (id,key,internationalization_key,value_type,value,note,created_at,updated_at,deleted)
values ('f60634ec-51dc-4d0e-a8d5-d4621cb4dba5','DUE_DATE_FIELD_REQUIRED','sales.orderConfiguration.dueDateFieldRequired','BOOL','false','Exige o preenchimento do campo Data de vencimento',current_timestamp,current_timestamp,false);
insert into order_parameter (id,key,internationalization_key,value_type,value,note,created_at,updated_at,deleted)
values ('3105fd66-dd65-4611-bea8-1ac403bd0cc8','ENABLE_PRICE_LIST_BY_ORDER_ITEM','sales.orderConfiguration.enablePriceListByOrderItem','BOOL','false','Exibe o campo Tabela de preço nos detalhes dos itens, na aba de produtos e carrinho',current_timestamp,current_timestamp,false);
insert into order_parameter (id,key,internationalization_key,value_type,value,note,created_at,updated_at,deleted)
values ('22b696ce-9b94-4c72-80ff-36a18dd7cbc0','BLOCK_ORDER_INACTIVE_CUSTOMER','sales.orderConfiguration.blockOrderInactiveCustomer','BOOL','false','Não permite finalizar pedido para cliente inativo',current_timestamp,current_timestamp,false);
insert into order_parameter (id,key,internationalization_key,value_type,value,note,created_at,updated_at,deleted)
values ('85ca6ceb-3215-45f8-a5ab-9fd5f57efb79','BLOCK_ORDER_INACTIVE_LOCATION','sales.orderConfiguration.blockOrderInactiveLocation','BOOL','false','Não permite finalizar pedido para local inativo',current_timestamp,current_timestamp,false);
insert into order_parameter (id, key, internationalization_key, value_type, value, note, min_value, max_value, created_at, updated_at, deleted)
values ('60d45ed4-dc2d-4b96-9b3d-3bc4bcad0ed1','DECIMAL_PLACES','sales.orderConfiguration.decimalPlaces', 'INT','2','Define a quantidade de casas decimais que devem ser utilizadas no pedido',0,6, current_timestamp, current_timestamp, false);