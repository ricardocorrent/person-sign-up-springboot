
--
-- TOC entry 394 (class 1259 OID 134443)
-- Name: access_group; Type: TABLE; 
--

CREATE TABLE access_group (
    id uuid NOT NULL,
    version bigint,
    group_name character varying(255),
    user_id uuid,
    all_records boolean,
    user_and_superiors uuid[],
    group_type character varying(255),
    entity_ids uuid[],
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 395 (class 1259 OID 134452)
-- Name: access_rule; Type: TABLE; 
--

CREATE TABLE access_rule (
    id uuid NOT NULL,
    version bigint,
    rule_name character varying(255),
    active boolean,
    default_rule boolean,
    all_users boolean,
    entity_name character varying(255),
    reference_property character varying(255),
    access_group_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 396 (class 1259 OID 134460)
-- Name: deal; Type: TABLE; 
--

CREATE TABLE deal (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    customer_id uuid,
    customer_name character varying(255),
    location_id uuid,
    location_description character varying(255),
    commodity_id uuid,
    commodity_description character varying(255),
    culture_id uuid,
    culture_description character varying(255),
    crop_year_id uuid,
    crop_year_description character varying(255),
    available boolean,
    market_position timestamp with time zone,
    shipping_by_supplier boolean,
    attendance boolean,
    over_attendance boolean,
    draft boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    product_id uuid,
    product_description character varying(255),
    user_id uuid,
    user_name character varying(255)
);


--
-- TOC entry 418 (class 1259 OID 134673)
-- Name: delivery_order; Type: TABLE; 
--

CREATE TABLE delivery_order (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    sales_order_id uuid,
    shipment_date date,
    delivery_date date,
    location_id uuid,
    location_description character varying(255),
    observation character varying(4000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    incoterms_id uuid,
    incoterms_acronym character varying(3),
    freight_value numeric(18,6)
);


--
-- TOC entry 393 (class 1259 OID 134436)
-- Name: instalment; Type: TABLE; 
--

CREATE TABLE instalment (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    id_payment_term uuid,
    instalment_quantity integer,
    rank integer,
    percent numeric(38,0),
    medium_term integer,
    days_to_expire integer,
    minimum_order numeric(38,0),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    fixed_date date
);


--
-- TOC entry 397 (class 1259 OID 134469)
-- Name: invoice; Type: TABLE; 
--

CREATE TABLE invoice (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    number character varying(20),
    series character varying(80),
    total numeric(18,6),
    note character varying(4000),
    billing_date date,
    payment_term_id uuid,
    invoice_situation_id uuid,
    invoice_type_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 419 (class 1259 OID 134683)
-- Name: invoice_currency; Type: TABLE; 
--

CREATE TABLE invoice_currency (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    description character varying(255),
    invoice_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 389 (class 1259 OID 134394)
-- Name: invoice_customer; Type: TABLE; 
--

CREATE TABLE invoice_customer (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    name character varying(255),
    invoice_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 399 (class 1259 OID 134487)
-- Name: invoice_item; Type: TABLE; 
--

CREATE TABLE invoice_item (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    total_value numeric(18,6),
    unit_value numeric(18,6),
    quantity integer,
    batch character varying(255),
    sales_order_id uuid,
    invoice_id uuid,
    invoice_type_item_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 402 (class 1259 OID 134521)
-- Name: invoice_item_measure_unit; Type: TABLE; 
--

CREATE TABLE invoice_item_measure_unit (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    description character varying(255),
    invoice_item_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 401 (class 1259 OID 134510)
-- Name: invoice_item_product; Type: TABLE; 
--

CREATE TABLE invoice_item_product (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    description character varying(255),
    invoice_item_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 400 (class 1259 OID 134499)
-- Name: invoice_location; Type: TABLE; 
--

CREATE TABLE invoice_location (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    description character varying(255),
    invoice_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 398 (class 1259 OID 134481)
-- Name: invoice_situation; Type: TABLE; 
--

CREATE TABLE invoice_situation (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    description character varying(80),
    active boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 390 (class 1259 OID 134405)
-- Name: invoice_type; Type: TABLE; 
--

CREATE TABLE invoice_type (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    description character varying(255),
    active boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 406 (class 1259 OID 134562)
-- Name: invoice_type_item; Type: TABLE; 
--

CREATE TABLE invoice_type_item (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    description character varying(255),
    active boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 405 (class 1259 OID 134551)
-- Name: invoice_user; Type: TABLE; 
--

CREATE TABLE invoice_user (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    replicated_id uuid,
    name character varying(255),
    invoice_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 403 (class 1259 OID 134532)
-- Name: order_agricultural; Type: TABLE; 
--

CREATE TABLE order_agricultural (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    crop_year_id uuid,
    crop_year_description character varying(255),
    culture_id uuid,
    culture_description character varying(255),
    occurrence_id uuid,
    occurrence_common_name character varying(255),
    application_area numeric(18,6),
    number_applications integer,
    dosage numeric(18,6),
    sales_order_item_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 422 (class 1259 OID 134714)
-- Name: order_configuration; Type: TABLE; 
--

CREATE TABLE order_configuration (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    attendance_required boolean DEFAULT false,
    agricultural_plugin boolean DEFAULT false,
    currency_plugin boolean DEFAULT false,
    blockbyinventory boolean,
    validatediscount boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    block_by_inventory boolean DEFAULT false,
    validate_discount boolean DEFAULT false,
    validate_minimum_price boolean DEFAULT false,
    signature_required boolean DEFAULT false,
    due_date_price boolean DEFAULT false,
    credit_limit_required boolean DEFAULT false,
    validate_negative_credit_limit boolean DEFAULT false,
    sync_from date,
    sync_request_limit numeric(10,0),
    enable_order_instalment boolean DEFAULT false,
    sync_days integer DEFAULT 60,
    order_filter_days bigint DEFAULT 60
);


--
-- TOC entry 404 (class 1259 OID 134542)
-- Name: order_currency; Type: TABLE; 
--

CREATE TABLE order_currency (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    currency_id uuid,
    currency_description character varying(255),
    currency_quotation_id uuid,
    currency_quotation_value numeric(18,6),
    currency_quotation_date timestamp with time zone,
    order_item_value numeric(18,6),
    sales_order_item_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    sales_order_id uuid
);


--
-- TOC entry 425 (class 1259 OID 134750)
-- Name: order_operation; Type: TABLE; 
--

CREATE TABLE order_operation (
    id uuid NOT NULL,
    version bigint,
    code character varying(255),
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 421 (class 1259 OID 134703)
-- Name: order_parameter; Type: TABLE; 
--

CREATE TABLE order_parameter (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    key character varying(100),
    internationalization_key character varying(200),
    value_type character varying(40),
    value character varying(255),
    note character varying(255),
    min_value character varying(255),
    max_value character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 426 (class 1259 OID 134759)
-- Name: order_representative; Type: TABLE; 
--

CREATE TABLE order_representative (
    id uuid NOT NULL,
    version bigint,
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 427 (class 1259 OID 134768)
-- Name: order_technical_consultant; Type: TABLE; 
--

CREATE TABLE order_technical_consultant (
    id uuid NOT NULL,
    version bigint,
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 428 (class 1259 OID 134777)
-- Name: order_technical_coordinator; Type: TABLE; 
--

CREATE TABLE order_technical_coordinator (
    id uuid NOT NULL,
    version bigint,
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 423 (class 1259 OID 134733)
-- Name: order_treatment; Type: TABLE; 
--

CREATE TABLE order_treatment (
    id uuid NOT NULL,
    version bigint,
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 407 (class 1259 OID 134571)
-- Name: order_type; Type: TABLE; 
--

CREATE TABLE order_type (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    active boolean,
    standard boolean,
    available_first_order boolean,
    description character varying(255),
    acronym character varying(40),
    code character varying(40),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 430 (class 1259 OID 134792)
-- Name: order_warehouse; Type: TABLE; 
--

CREATE TABLE order_warehouse (
    id uuid NOT NULL,
    version bigint,
    description character varying(255),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 408 (class 1259 OID 134580)
-- Name: payment_method; Type: TABLE; 
--

CREATE TABLE payment_method (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    active boolean,
    standard boolean,
    available_first_order boolean,
    description character varying(255),
    acronym character varying(40),
    code character varying(40),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 420 (class 1259 OID 134694)
-- Name: payment_term; Type: TABLE; 
--

CREATE TABLE payment_term (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    active boolean,
    standard boolean,
    available_first_order boolean,
    description character varying(255),
    acronym character varying(40),
    code character varying(40),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    middle_term integer,
    allow_change_due_date boolean,
    max_number_instalment numeric(10,0),
    days_between_instalment bigint,
    instalment_number bigint
);


--
-- TOC entry 411 (class 1259 OID 134609)
-- Name: payment_term_company_permission; Type: TABLE; 
--

CREATE TABLE payment_term_company_permission (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    payment_term_id uuid,
    company_id uuid,
    company_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 409 (class 1259 OID 134589)
-- Name: payment_term_customer_permission; Type: TABLE; 
--

CREATE TABLE payment_term_customer_permission (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    payment_term_id uuid,
    customer_id uuid,
    customer_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 410 (class 1259 OID 134599)
-- Name: payment_term_location_permission; Type: TABLE; 
--

CREATE TABLE payment_term_location_permission (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    payment_term_id uuid,
    location_id uuid,
    location_description character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 415 (class 1259 OID 134645)
-- Name: payment_term_user_permission; Type: TABLE; 
--

CREATE TABLE payment_term_user_permission (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    payment_term_id uuid,
    user_id uuid,
    user_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 413 (class 1259 OID 134628)
-- Name: permission_changes; Type: TABLE; 
--

CREATE TABLE permission_changes (
    id uuid NOT NULL,
    version bigint,
    group_name character varying(255),
    user_id uuid,
    user_and_superiors uuid[],
    granted_entity_ids uuid[],
    revoked_entity_ids uuid[],
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 432 (class 1259 OID 134811)
-- Name: recycling_entity; Type: TABLE; 
--

CREATE TABLE recycling_entity (
    id uuid NOT NULL,
    resource_uri character varying(255),
    performed_at timestamp with time zone
);


--
-- TOC entry 392 (class 1259 OID 134424)
-- Name: sales_order; Type: TABLE; 
--

CREATE TABLE sales_order (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    price_list_id uuid,
    price_list_description character varying(255),
    payment_term_id uuid,
    payment_term_description character varying(255),
    order_type_id uuid,
    order_type_description character varying(255),
    payment_method_id uuid,
    payment_method_description character varying(255),
    user_id uuid,
    user_name character varying(255),
    company_id uuid,
    company_name character varying(255),
    customer_id uuid,
    customer_image_id uuid,
    customer_name character varying(255),
    location_id uuid,
    location_description character varying(255),
    location_address character varying(255),
    draft boolean,
    order_number character varying(255),
    external_number character varying(255),
    customer_number character varying(255),
    invoice_notes character varying(4000),
    order_notes character varying(4000),
    currency character varying(10),
    ordered_at timestamp with time zone,
    invoiced_at timestamp with time zone,
    transmited_at timestamp with time zone,
    exported_at timestamp with time zone,
    gross_value numeric(18,6),
    net_value numeric(18,6),
    quantity numeric(18,6),
    invoiced_value numeric(18,6),
    invoiced_quantity numeric(18,6),
    situation_id uuid,
    situation_description character varying(255),
    origin character varying(20),
    crop_id uuid,
    crop_description character varying(255),
    culture_id uuid,
    culture_description character varying(255),
    complement character varying(4000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    items_quantity integer,
    signature_id uuid,
    due_date date,
    user_professional_id uuid,
    user_professional_name character varying(255),
    initial_credit_limit numeric(18,6),
    transmitted_at timestamp with time zone,
    withdrawal_company_id uuid,
    withdrawal_company_name character varying(255),
    order_warehouse_id uuid,
    incoterms_id uuid,
    incoterms_acronym character varying(255),
    service_id uuid,
    inserted_at timestamp with time zone
);


--
-- TOC entry 412 (class 1259 OID 134619)
-- Name: sales_order_historic; Type: TABLE; 
--

CREATE TABLE sales_order_historic (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    sales_order_id uuid,
    original_order jsonb,
    user_id uuid,
    username character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 388 (class 1259 OID 134388)
-- Name: sales_order_instalment; Type: TABLE; 
--

CREATE TABLE sales_order_instalment (
    id uuid NOT NULL,
    version bigint,
    sales_order_id uuid,
    number integer,
    due_date date,
    value numeric(18,6),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 431 (class 1259 OID 134801)
-- Name: sales_order_item; Type: TABLE; 
--

CREATE TABLE sales_order_item (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    sales_order_id uuid,
    product_id uuid,
    product_description character varying(255),
    product_code character varying(40),
    price_list_id uuid,
    price_list_description character varying(255),
    sales_order_item_situation_id uuid,
    sales_order_item_situation_description character varying(255),
    gross_value numeric(18,6),
    net_value numeric(18,6),
    quantity numeric(18,6),
    rank integer,
    invoiced_value numeric(18,6),
    invoiced_quantity numeric(18,6),
    product_packaging_id uuid,
    product_packaging_description character varying(255),
    total_item numeric(18,6),
    discount numeric(18,6),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    price_list_item_id uuid,
    discount_percentage numeric(18,6),
    due_date_value numeric(18,6),
    increase_value numeric(18,6),
    increase_percentage numeric(18,6),
    withdrawal_company_id uuid,
    withdrawal_company_name character varying(255),
    order_warehouse_id uuid
);


--
-- TOC entry 424 (class 1259 OID 134742)
-- Name: sales_order_item_seed; Type: TABLE; 
--

CREATE TABLE sales_order_item_seed (
    id uuid NOT NULL,
    version bigint,
    sales_order_item_id uuid,
    bag boolean DEFAULT false,
    seed_treated boolean DEFAULT false,
    order_treatment_id uuid,
    treatment_price numeric(18,6),
    total_treatment_value numeric(18,6),
    freight_value numeric(18,6),
    royalty_technology character varying(15),
    royalty_value numeric(18,6),
    technology_value numeric(18,6),
    overall_unit_price numeric(18,6),
    plant_population numeric(18,6),
    estimated_germination numeric(18,6),
    initial_pms numeric(18,6),
    final_pms numeric(18,6),
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 414 (class 1259 OID 134636)
-- Name: sales_order_item_situation; Type: TABLE; 
--

CREATE TABLE sales_order_item_situation (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    description character varying(255),
    active boolean,
    acronym character varying(40),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 429 (class 1259 OID 134786)
-- Name: sales_order_seed; Type: TABLE; 
--

CREATE TABLE sales_order_seed (
    id uuid NOT NULL,
    version bigint,
    sales_order_id uuid,
    order_operation_id uuid,
    order_representative_id uuid,
    representative_commission numeric(18,6),
    order_technical_consultant_id uuid,
    consultant_commission numeric(18,6),
    order_technical_coordinator_id uuid,
    coordinator_commission numeric(18,6),
    taxes_account character varying(15),
    shipment_ordered_paid boolean,
    external_id character varying(255),
    deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 391 (class 1259 OID 134414)
-- Name: sales_order_situation; Type: TABLE; 
--

CREATE TABLE sales_order_situation (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    sales_order_id uuid,
    situation_id uuid,
    situation_description character varying(255),
    situation_icon character varying(255),
    rank numeric(18,6),
    started_on timestamp with time zone,
    ended_on timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);



--
-- TOC entry 416 (class 1259 OID 134655)
-- Name: situation; Type: TABLE; 
--

CREATE TABLE situation (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    active boolean,
    description character varying(255),
    image_id uuid,
    acronym character varying(40),
    rank numeric(38,0),
    icon character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 417 (class 1259 OID 134664)
-- Name: topic_offset_partition; Type: TABLE; 
--

CREATE TABLE topic_offset_partition (
    id uuid NOT NULL,
    version bigint,
    external_id character varying(255),
    topic character varying(255),
    partition integer,
    queue_offset bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- TOC entry 5449 (class 2606 OID 134450)
-- Name: access_group access_group_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY access_group
    ADD CONSTRAINT access_group_pkey PRIMARY KEY (id);


--
-- TOC entry 5451 (class 2606 OID 134459)
-- Name: access_rule access_rule_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY access_rule
    ADD CONSTRAINT access_rule_pkey PRIMARY KEY (id);


--
-- TOC entry 5453 (class 2606 OID 134468)
-- Name: deal deal_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY deal
    ADD CONSTRAINT deal_pkey PRIMARY KEY (id);


--
-- TOC entry 5516 (class 2606 OID 134681)
-- Name: delivery_order delivery_order_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY delivery_order
    ADD CONSTRAINT delivery_order_pkey PRIMARY KEY (id);


--
-- TOC entry 5446 (class 2606 OID 134441)
-- Name: instalment instalment_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY instalment
    ADD CONSTRAINT instalment_pkey PRIMARY KEY (id);


--
-- TOC entry 5519 (class 2606 OID 134693)
-- Name: invoice_currency invoice_currency_invoice_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_currency
    ADD CONSTRAINT invoice_currency_invoice_id_key UNIQUE (invoice_id);


--
-- TOC entry 5521 (class 2606 OID 134691)
-- Name: invoice_currency invoice_currency_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_currency
    ADD CONSTRAINT invoice_currency_pkey PRIMARY KEY (id);


--
-- TOC entry 5431 (class 2606 OID 134404)
-- Name: invoice_customer invoice_customer_invoice_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_customer
    ADD CONSTRAINT invoice_customer_invoice_id_key UNIQUE (invoice_id);


--
-- TOC entry 5433 (class 2606 OID 134402)
-- Name: invoice_customer invoice_customer_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_customer
    ADD CONSTRAINT invoice_customer_pkey PRIMARY KEY (id);


--
-- TOC entry 5475 (class 2606 OID 134531)
-- Name: invoice_item_measure_unit invoice_item_measure_unit_invoice_item_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_measure_unit
    ADD CONSTRAINT invoice_item_measure_unit_invoice_item_id_key UNIQUE (invoice_item_id);


--
-- TOC entry 5477 (class 2606 OID 134529)
-- Name: invoice_item_measure_unit invoice_item_measure_unit_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_measure_unit
    ADD CONSTRAINT invoice_item_measure_unit_pkey PRIMARY KEY (id);


--
-- TOC entry 5464 (class 2606 OID 134495)
-- Name: invoice_item invoice_item_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item
    ADD CONSTRAINT invoice_item_pkey PRIMARY KEY (id);


--
-- TOC entry 5471 (class 2606 OID 134520)
-- Name: invoice_item_product invoice_item_product_invoice_item_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_product
    ADD CONSTRAINT invoice_item_product_invoice_item_id_key UNIQUE (invoice_item_id);


--
-- TOC entry 5473 (class 2606 OID 134518)
-- Name: invoice_item_product invoice_item_product_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_product
    ADD CONSTRAINT invoice_item_product_pkey PRIMARY KEY (id);


--
-- TOC entry 5467 (class 2606 OID 134509)
-- Name: invoice_location invoice_location_invoice_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_location
    ADD CONSTRAINT invoice_location_invoice_id_key UNIQUE (invoice_id);


--
-- TOC entry 5469 (class 2606 OID 134507)
-- Name: invoice_location invoice_location_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_location
    ADD CONSTRAINT invoice_location_pkey PRIMARY KEY (id);


--
-- TOC entry 5458 (class 2606 OID 134477)
-- Name: invoice invoice_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- TOC entry 5460 (class 2606 OID 134486)
-- Name: invoice_situation invoice_situation_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_situation
    ADD CONSTRAINT invoice_situation_pkey PRIMARY KEY (id);


--
-- TOC entry 5488 (class 2606 OID 134570)
-- Name: invoice_type_item invoice_type_item_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_type_item
    ADD CONSTRAINT invoice_type_item_pkey PRIMARY KEY (id);


--
-- TOC entry 5435 (class 2606 OID 134413)
-- Name: invoice_type invoice_type_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_type
    ADD CONSTRAINT invoice_type_pkey PRIMARY KEY (id);


--
-- TOC entry 5484 (class 2606 OID 134561)
-- Name: invoice_user invoice_user_invoice_id_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_user
    ADD CONSTRAINT invoice_user_invoice_id_key UNIQUE (invoice_id);


--
-- TOC entry 5486 (class 2606 OID 134559)
-- Name: invoice_user invoice_user_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY invoice_user
    ADD CONSTRAINT invoice_user_pkey PRIMARY KEY (id);


--
-- TOC entry 5479 (class 2606 OID 134540)
-- Name: order_agricultural order_agricultural_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_agricultural
    ADD CONSTRAINT order_agricultural_pkey PRIMARY KEY (id);


--
-- TOC entry 5529 (class 2606 OID 134732)
-- Name: order_configuration order_configuration_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_configuration
    ADD CONSTRAINT order_configuration_pkey PRIMARY KEY (id);


--
-- TOC entry 5482 (class 2606 OID 134550)
-- Name: order_currency order_currency_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_currency
    ADD CONSTRAINT order_currency_pkey PRIMARY KEY (id);


--
-- TOC entry 5535 (class 2606 OID 134758)
-- Name: order_operation order_operation_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_operation
    ADD CONSTRAINT order_operation_pkey PRIMARY KEY (id);


--
-- TOC entry 5525 (class 2606 OID 134713)
-- Name: order_parameter order_parameter_key_key; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_parameter
    ADD CONSTRAINT order_parameter_key_key UNIQUE (key);


--
-- TOC entry 5527 (class 2606 OID 134711)
-- Name: order_parameter order_parameter_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_parameter
    ADD CONSTRAINT order_parameter_pkey PRIMARY KEY (id);


--
-- TOC entry 5537 (class 2606 OID 134767)
-- Name: order_representative order_representative_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_representative
    ADD CONSTRAINT order_representative_pkey PRIMARY KEY (id);


--
-- TOC entry 5539 (class 2606 OID 134776)
-- Name: order_technical_consultant order_technical_consultant_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_technical_consultant
    ADD CONSTRAINT order_technical_consultant_pkey PRIMARY KEY (id);


--
-- TOC entry 5541 (class 2606 OID 134785)
-- Name: order_technical_coordinator order_technical_coordinator_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_technical_coordinator
    ADD CONSTRAINT order_technical_coordinator_pkey PRIMARY KEY (id);


--
-- TOC entry 5531 (class 2606 OID 134741)
-- Name: order_treatment order_treatment_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_treatment
    ADD CONSTRAINT order_treatment_pkey PRIMARY KEY (id);


--
-- TOC entry 5490 (class 2606 OID 134579)
-- Name: order_type order_type_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_type
    ADD CONSTRAINT order_type_pkey PRIMARY KEY (id);


--
-- TOC entry 5545 (class 2606 OID 134800)
-- Name: order_warehouse order_warehouse_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY order_warehouse
    ADD CONSTRAINT order_warehouse_pkey PRIMARY KEY (id);


--
-- TOC entry 5492 (class 2606 OID 134588)
-- Name: payment_method payment_method_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_method
    ADD CONSTRAINT payment_method_pkey PRIMARY KEY (id);


--
-- TOC entry 5501 (class 2606 OID 134617)
-- Name: payment_term_company_permission payment_term_company_permission_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_company_permission
    ADD CONSTRAINT payment_term_company_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 5495 (class 2606 OID 134597)
-- Name: payment_term_customer_permission payment_term_customer_permission_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_customer_permission
    ADD CONSTRAINT payment_term_customer_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 5498 (class 2606 OID 134607)
-- Name: payment_term_location_permission payment_term_location_permission_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_location_permission
    ADD CONSTRAINT payment_term_location_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 5523 (class 2606 OID 134702)
-- Name: payment_term payment_term_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_term
    ADD CONSTRAINT payment_term_pkey PRIMARY KEY (id);


--
-- TOC entry 5510 (class 2606 OID 134653)
-- Name: payment_term_user_permission payment_term_user_permission_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_user_permission
    ADD CONSTRAINT payment_term_user_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 5505 (class 2606 OID 134635)
-- Name: permission_changes permission_changes_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY permission_changes
    ADD CONSTRAINT permission_changes_pkey PRIMARY KEY (id);


--
-- TOC entry 5550 (class 2606 OID 134815)
-- Name: recycling_entity recycling_entity_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY recycling_entity
    ADD CONSTRAINT recycling_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 5503 (class 2606 OID 134627)
-- Name: sales_order_historic sales_order_historic_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_historic
    ADD CONSTRAINT sales_order_historic_pkey PRIMARY KEY (id);


--
-- TOC entry 5429 (class 2606 OID 134393)
-- Name: sales_order_instalment sales_order_instalment_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_instalment
    ADD CONSTRAINT sales_order_instalment_pkey PRIMARY KEY (id);


--
-- TOC entry 5547 (class 2606 OID 134809)
-- Name: sales_order_item sales_order_item_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item
    ADD CONSTRAINT sales_order_item_pkey PRIMARY KEY (id);


--
-- TOC entry 5533 (class 2606 OID 134749)
-- Name: sales_order_item_seed sales_order_item_seed_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item_seed
    ADD CONSTRAINT sales_order_item_seed_pkey PRIMARY KEY (id);


--
-- TOC entry 5507 (class 2606 OID 134644)
-- Name: sales_order_item_situation sales_order_item_situation_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item_situation
    ADD CONSTRAINT sales_order_item_situation_pkey PRIMARY KEY (id);


--
-- TOC entry 5443 (class 2606 OID 134432)
-- Name: sales_order sales_order_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order
    ADD CONSTRAINT sales_order_pkey PRIMARY KEY (id);


--
-- TOC entry 5543 (class 2606 OID 134791)
-- Name: sales_order_seed sales_order_seed_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_pkey PRIMARY KEY (id);


--
-- TOC entry 5437 (class 2606 OID 134422)
-- Name: sales_order_situation sales_order_situation_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_situation
    ADD CONSTRAINT sales_order_situation_pkey PRIMARY KEY (id);


--
-- TOC entry 5512 (class 2606 OID 134663)
-- Name: situation situation_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY situation
    ADD CONSTRAINT situation_pkey PRIMARY KEY (id);


--
-- TOC entry 5514 (class 2606 OID 134672)
-- Name: topic_offset_partition topic_offset_partition_pkey; Type: CONSTRAINT; 
--

ALTER TABLE ONLY topic_offset_partition
    ADD CONSTRAINT topic_offset_partition_pkey PRIMARY KEY (id);


--
-- TOC entry 5447 (class 1259 OID 134451)
-- Name: access_group_group_name_idx; Type: INDEX; 
--

CREATE INDEX access_group_group_name_idx ON access_group USING btree (group_name);


--
-- TOC entry 5517 (class 1259 OID 134682)
-- Name: delivery_order_sales_order_id_idx; Type: INDEX; 
--

CREATE INDEX delivery_order_sales_order_id_idx ON delivery_order USING btree (sales_order_id);


--
-- TOC entry 5444 (class 1259 OID 134442)
-- Name: instalment_id_payment_term_idx; Type: INDEX; 
--

CREATE INDEX instalment_id_payment_term_idx ON instalment USING btree (id_payment_term);


--
-- TOC entry 5454 (class 1259 OID 134478)
-- Name: invoice_invoice_situation_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_invoice_situation_id_idx ON invoice USING btree (invoice_situation_id);


--
-- TOC entry 5455 (class 1259 OID 134479)
-- Name: invoice_invoice_type_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_invoice_type_id_idx ON invoice USING btree (invoice_type_id);


--
-- TOC entry 5461 (class 1259 OID 134496)
-- Name: invoice_item_invoice_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_item_invoice_id_idx ON invoice_item USING btree (invoice_id);


--
-- TOC entry 5462 (class 1259 OID 134497)
-- Name: invoice_item_invoice_type_item_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_item_invoice_type_item_id_idx ON invoice_item USING btree (invoice_type_item_id);


--
-- TOC entry 5465 (class 1259 OID 134498)
-- Name: invoice_item_sales_order_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_item_sales_order_id_idx ON invoice_item USING btree (sales_order_id);


--
-- TOC entry 5456 (class 1259 OID 134480)
-- Name: invoice_payment_term_id_idx; Type: INDEX; 
--

CREATE INDEX invoice_payment_term_id_idx ON invoice USING btree (payment_term_id);


--
-- TOC entry 5480 (class 1259 OID 134541)
-- Name: order_agricultural_sales_order_item_id_idx; Type: INDEX; 
--

CREATE UNIQUE INDEX order_agricultural_sales_order_item_id_idx ON order_agricultural USING btree (sales_order_item_id) WHERE (deleted IS FALSE);


--
-- TOC entry 5499 (class 1259 OID 134618)
-- Name: payment_term_company_permission_payment_term_id_idx; Type: INDEX; 
--

CREATE INDEX payment_term_company_permission_payment_term_id_idx ON payment_term_company_permission USING btree (payment_term_id);


--
-- TOC entry 5493 (class 1259 OID 134598)
-- Name: payment_term_customer_permission_payment_term_id_idx; Type: INDEX; 
--

CREATE INDEX payment_term_customer_permission_payment_term_id_idx ON payment_term_customer_permission USING btree (payment_term_id);


--
-- TOC entry 5496 (class 1259 OID 134608)
-- Name: payment_term_location_permission_payment_term_id_idx; Type: INDEX; 
--

CREATE INDEX payment_term_location_permission_payment_term_id_idx ON payment_term_location_permission USING btree (payment_term_id);


--
-- TOC entry 5508 (class 1259 OID 134654)
-- Name: payment_term_user_permission_payment_term_id_idx; Type: INDEX; 
--

CREATE INDEX payment_term_user_permission_payment_term_id_idx ON payment_term_user_permission USING btree (payment_term_id);


--
-- TOC entry 5439 (class 1259 OID 134433)
-- Name: sales_order_created_at_idx; Type: INDEX; 
--

CREATE INDEX sales_order_created_at_idx ON sales_order USING btree (created_at);


--
-- TOC entry 5440 (class 1259 OID 134435)
-- Name: sales_order_customer_id_idx; Type: INDEX; 
--

CREATE INDEX sales_order_customer_id_idx ON sales_order USING btree (customer_id);


--
-- TOC entry 5548 (class 1259 OID 134810)
-- Name: sales_order_item_sales_order_id_idx; Type: INDEX; 
--

CREATE INDEX sales_order_item_sales_order_id_idx ON sales_order_item USING btree (sales_order_id);


--
-- TOC entry 5441 (class 1259 OID 134434)
-- Name: sales_order_ordered_at_idx; Type: INDEX; 
--

CREATE INDEX sales_order_ordered_at_idx ON sales_order USING btree (ordered_at);


--
-- TOC entry 5438 (class 1259 OID 134423)
-- Name: sales_order_situation_sales_order_id_idx; Type: INDEX; 
--

CREATE INDEX sales_order_situation_sales_order_id_idx ON sales_order_situation USING btree (sales_order_id);


--
-- TOC entry 5576 (class 2606 OID 134926)
-- Name: delivery_order fk_delivery_order_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY delivery_order
    ADD CONSTRAINT fk_delivery_order_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5558 (class 2606 OID 134836)
-- Name: instalment fk_instalment_id_payment_term; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY instalment
    ADD CONSTRAINT fk_instalment_id_payment_term FOREIGN KEY (id_payment_term) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5577 (class 2606 OID 134931)
-- Name: invoice_currency fk_invoice_currency_invoice_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_currency
    ADD CONSTRAINT fk_invoice_currency_invoice_id FOREIGN KEY (invoice_id) REFERENCES invoice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5555 (class 2606 OID 134821)
-- Name: invoice_customer fk_invoice_customer_invoice_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_customer
    ADD CONSTRAINT fk_invoice_customer_invoice_id FOREIGN KEY (invoice_id) REFERENCES invoice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5561 (class 2606 OID 134841)
-- Name: invoice fk_invoice_invoice_situation_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT fk_invoice_invoice_situation_id FOREIGN KEY (invoice_situation_id) REFERENCES invoice_situation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5560 (class 2606 OID 134846)
-- Name: invoice fk_invoice_invoice_type_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT fk_invoice_invoice_type_id FOREIGN KEY (invoice_type_id) REFERENCES invoice_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5564 (class 2606 OID 134856)
-- Name: invoice_item fk_invoice_item_invoice_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item
    ADD CONSTRAINT fk_invoice_item_invoice_id FOREIGN KEY (invoice_id) REFERENCES invoice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5563 (class 2606 OID 134861)
-- Name: invoice_item fk_invoice_item_invoice_type_item_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item
    ADD CONSTRAINT fk_invoice_item_invoice_type_item_id FOREIGN KEY (invoice_type_item_id) REFERENCES invoice_type_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5567 (class 2606 OID 134881)
-- Name: invoice_item_measure_unit fk_invoice_item_measure_unit_invoice_item_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_measure_unit
    ADD CONSTRAINT fk_invoice_item_measure_unit_invoice_item_id FOREIGN KEY (invoice_item_id) REFERENCES invoice_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5566 (class 2606 OID 134876)
-- Name: invoice_item_product fk_invoice_item_product_invoice_item_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item_product
    ADD CONSTRAINT fk_invoice_item_product_invoice_item_id FOREIGN KEY (invoice_item_id) REFERENCES invoice_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5562 (class 2606 OID 134866)
-- Name: invoice_item fk_invoice_item_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_item
    ADD CONSTRAINT fk_invoice_item_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5565 (class 2606 OID 134871)
-- Name: invoice_location fk_invoice_location_invoice_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_location
    ADD CONSTRAINT fk_invoice_location_invoice_id FOREIGN KEY (invoice_id) REFERENCES invoice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5559 (class 2606 OID 134851)
-- Name: invoice fk_invoice_payment_term_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT fk_invoice_payment_term_id FOREIGN KEY (payment_term_id) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5571 (class 2606 OID 134901)
-- Name: invoice_user fk_invoice_user_invoice_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY invoice_user
    ADD CONSTRAINT fk_invoice_user_invoice_id FOREIGN KEY (invoice_id) REFERENCES invoice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5568 (class 2606 OID 134886)
-- Name: order_agricultural fk_order_agricultural_sales_order_item_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY order_agricultural
    ADD CONSTRAINT fk_order_agricultural_sales_order_item_id FOREIGN KEY (sales_order_item_id) REFERENCES sales_order_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5570 (class 2606 OID 134891)
-- Name: order_currency fk_order_currency_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY order_currency
    ADD CONSTRAINT fk_order_currency_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5569 (class 2606 OID 134896)
-- Name: order_currency fk_order_currency_sales_order_item_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY order_currency
    ADD CONSTRAINT fk_order_currency_sales_order_item_id FOREIGN KEY (sales_order_item_id) REFERENCES sales_order_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5574 (class 2606 OID 134916)
-- Name: payment_term_company_permission fk_payment_term_company_permission_id_payment_term; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_company_permission
    ADD CONSTRAINT fk_payment_term_company_permission_id_payment_term FOREIGN KEY (payment_term_id) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5572 (class 2606 OID 134906)
-- Name: payment_term_customer_permission fk_payment_term_customer_permission_id_payment_term; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_customer_permission
    ADD CONSTRAINT fk_payment_term_customer_permission_id_payment_term FOREIGN KEY (payment_term_id) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5573 (class 2606 OID 134911)
-- Name: payment_term_location_permission fk_payment_term_location_permission_id_payment_term; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_location_permission
    ADD CONSTRAINT fk_payment_term_location_permission_id_payment_term FOREIGN KEY (payment_term_id) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5575 (class 2606 OID 134921)
-- Name: payment_term_user_permission fk_payment_term_user_permission_id_payment_term; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY payment_term_user_permission
    ADD CONSTRAINT fk_payment_term_user_permission_id_payment_term FOREIGN KEY (payment_term_id) REFERENCES payment_term(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5554 (class 2606 OID 134816)
-- Name: sales_order_instalment fk_sales_order_instalment_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_instalment
    ADD CONSTRAINT fk_sales_order_instalment_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5586 (class 2606 OID 134971)
-- Name: sales_order_item fk_sales_order_item_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item
    ADD CONSTRAINT fk_sales_order_item_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5556 (class 2606 OID 134826)
-- Name: sales_order_situation fk_sales_order_situation_sales_order_id; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_situation
    ADD CONSTRAINT fk_sales_order_situation_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5585 (class 2606 OID 134976)
-- Name: sales_order_item sales_order_item_order_warehouse_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item
    ADD CONSTRAINT sales_order_item_order_warehouse_id_fkey FOREIGN KEY (order_warehouse_id) REFERENCES order_warehouse(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5579 (class 2606 OID 134936)
-- Name: sales_order_item_seed sales_order_item_seed_order_treatment_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item_seed
    ADD CONSTRAINT sales_order_item_seed_order_treatment_id_fkey FOREIGN KEY (order_treatment_id) REFERENCES order_treatment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5578 (class 2606 OID 134941)
-- Name: sales_order_item_seed sales_order_item_seed_sales_order_item_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_item_seed
    ADD CONSTRAINT sales_order_item_seed_sales_order_item_id_fkey FOREIGN KEY (sales_order_item_id) REFERENCES sales_order_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5557 (class 2606 OID 134831)
-- Name: sales_order sales_order_order_warehouse_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order
    ADD CONSTRAINT sales_order_order_warehouse_id_fkey FOREIGN KEY (order_warehouse_id) REFERENCES order_warehouse(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5584 (class 2606 OID 134946)
-- Name: sales_order_seed sales_order_seed_order_operation_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_order_operation_id_fkey FOREIGN KEY (order_operation_id) REFERENCES order_operation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5583 (class 2606 OID 134951)
-- Name: sales_order_seed sales_order_seed_order_representative_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_order_representative_id_fkey FOREIGN KEY (order_representative_id) REFERENCES order_representative(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5582 (class 2606 OID 134956)
-- Name: sales_order_seed sales_order_seed_order_technical_consultant_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_order_technical_consultant_id_fkey FOREIGN KEY (order_technical_consultant_id) REFERENCES order_technical_consultant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5581 (class 2606 OID 134961)
-- Name: sales_order_seed sales_order_seed_order_technical_coordinator_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_order_technical_coordinator_id_fkey FOREIGN KEY (order_technical_coordinator_id) REFERENCES order_technical_coordinator(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5580 (class 2606 OID 134966)
-- Name: sales_order_seed sales_order_seed_sales_order_id_fkey; Type: FK CONSTRAINT; 
--

ALTER TABLE ONLY sales_order_seed
    ADD CONSTRAINT sales_order_seed_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES sales_order(id) DEFERRABLE INITIALLY DEFERRED;


-- Completed on 2018-09-06 10:19:19 -03

--
-- PostgreSQL database dump complete
--

