UPDATE order_parameter
SET    value = false
WHERE  key = 'ATTENDANCE_REQUIRED';

UPDATE order_parameter
SET    value = false
WHERE  key = 'AGRICULTURAL_PLUGIN';

UPDATE order_parameter
SET    value = false
WHERE  key = 'CURRENCY_PLUGIN';

UPDATE order_parameter
SET    value = false
WHERE  key = 'BLOCK_BY_INVENTORY';

UPDATE order_parameter
SET    value = false
WHERE  key = 'DUE_DATE_PRICE';

UPDATE order_parameter
SET    value = false
WHERE  key = 'VALIDATE_DISCOUNT';

UPDATE order_parameter
SET    value = false
WHERE  key = 'VALIDATE_MINIMUM_PRICE';

UPDATE order_parameter
SET    value = false
WHERE  key = 'SIGNATURE_REQUIRED';

UPDATE order_parameter
SET    value = false
WHERE  key = 'CREDIT_REQUIRED';

UPDATE order_parameter
SET    value = false
WHERE  key = 'BLOCK_ORDER_NEGATIVE_CREDIT';

UPDATE order_parameter
SET    value = false
WHERE  key = 'ENABLE_FIELDS_SEEDS_CONFIGURATOR';

UPDATE order_parameter
SET    value = false
WHERE  key = 'SEED_ORDER';

UPDATE order_parameter
SET    value = false
WHERE  key = 'ENABLE_ROYALTY_TECHNOLOGY_VALUE_FIELDS';

UPDATE order_parameter
SET    value = false
WHERE  key = 'GENERATE_CONTRACT_USING_MODEL';

UPDATE order_parameter
SET    value = false
WHERE  key = 'ENABLE_ORDER_INSTALMENT';
