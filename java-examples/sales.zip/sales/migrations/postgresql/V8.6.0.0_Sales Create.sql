--Product's detail view
CREATE
OR REPLACE
VIEW product_purchased_history_view AS
SELECT
	so.customer_id AS customer_id,
	i.sales_order_id AS sales_order_id,
	i.product_id AS product_id,
	i.product_description AS product_description,
	i.updated_at AS updated_at,
	so.ordered_at AS ordered_at,
	i.net_value AS net_value,
	i.quantity AS quantity
FROM
	sales_order_item i
JOIN
	sales_order so
ON
	so.id = i.sales_order_id
WHERE
	so.draft IS FALSE;

--Service's detail view
CREATE
OR REPLACE
VIEW service_purchased_history_view AS
SELECT
	so.customer_id AS customer_id,
	s.sales_order_id AS sales_order_id,
	s.service_id AS service_id,
	s.service_description AS service_description,
	s.updated_at AS updated_at,
	so.ordered_at AS ordered_at,
	s.sales_price AS sales_price,
	s.total_quantity AS total_quantity
FROM
	sales_order_service s
JOIN
	sales_order so
ON
	so.id = s.sales_order_id
WHERE
	so.draft IS FALSE;
