alter table sales_order add create_date date;

--Products' view
CREATE
OR REPLACE
VIEW customer_order_history_products_view AS SELECT
	o.id AS order_id,
	o.created_at AS date,
	o.customer_id AS customer_id,
	i.product_id AS product_id,
	i.product_code AS product_code,
	i.product_description AS product_description,
	i.net_value AS item_net_value,
	i.quantity AS item_quantity,
	o.updated_at AS last_purchase_date
FROM
	sales_order o,
	sales_order_item i
WHERE
	o.id = i.sales_order_id
AND
	o.draft IS FALSE;

--Services' view
CREATE
OR REPLACE
VIEW customer_order_history_services_view AS SELECT
	o.id AS order_id,
	o.created_at as date,
	o.customer_id AS customer_id,
	s.service_id AS service_id,
	s.service_code AS service_code,
	s.service_description AS service_description,
	s.total_value AS service_net_value,
	s.quantity AS service_quantity,
	o.updated_at AS last_purchase_date
FROM
	sales_order o,
	sales_order_service s
WHERE
	o.id = s.sales_order_id
AND
	o.draft IS FALSE;