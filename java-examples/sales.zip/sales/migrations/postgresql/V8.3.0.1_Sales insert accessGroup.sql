-- OrderServices por usuário
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('832a9183-e796-4923-8e97-f9826bb59485', 'accessrule.sales.salesOrderServiceByUser', false, false, false, 'SalesOrderService',
            'salesOrder.userId', 'user', 1, now(), now());

-- OrderServices por cliente respeitando região
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('7b1bec49-b4d1-48a8-8e01-3cbed3136917', 'accessrule.sales.salesOrderServiceByCustomer', true, true, false, 'SalesOrderService',
            'salesOrder.customerId', 'customerByRegion', 1, now(), now());

-- RequestSignature by user
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('80ffebc3-ffb0-4fa3-87f1-62b6a0b19ab6', 'accessrule.sales.salesOrderRequestSignatureByUser', false, false, false, 'SalesOrderSignedDocument',
            'salesOrder.userId', 'user', 1, now(), now());

-- RequestSignature by customer
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('ca2c2142-b615-4ca9-8812-2cbbe4eeb844', 'accessrule.sales.salesOrderRequestSignatureByCustomer', true, true, false, 'SalesOrderSignedDocument',
            'salesOrder.customerId', 'customerByRegion', 1, now(), now());
