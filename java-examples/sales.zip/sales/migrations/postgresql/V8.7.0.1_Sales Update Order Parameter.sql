update
	order_parameter
set
	value = 'false'
where
	key = 'ENABLE_PRICE_LIST_BY_ORDER_ITEM';