CREATE TABLE sales_order_service (
    id uuid NOT NULL,
    version bigint,
    external_id CHARACTER VARYING(255),
    sales_order_id uuid NOT NULL,
    service_id uuid NOT NULL,
    service_description CHARACTER VARYING(255) NOT NULL,
    service_code CHARACTER VARYING(40),
    recurrence_type CHARACTER VARYING(10),
    original_price NUMERIC(18,6) NOT NULL,
    user_id uuid,
    user_name CHARACTER VARYING(255),
    sales_price NUMERIC(18,6) NOT NULL,
    quantity NUMERIC(18,6) not null,
    repetitions NUMERIC(18,6) not null,
    total_quantity NUMERIC(18,6) not null,
    total_value NUMERIC(18,6) not null,    
    discount NUMERIC(18,6),
    discount_percentage NUMERIC(18,6),
    increase_value NUMERIC(18,6),
    increase_percentage NUMERIC(18,6),
    deleted BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);

ALTER TABLE ONLY sales_order_service
    ADD CONSTRAINT sales_order_service_pkey PRIMARY KEY (id);

CREATE TABLE sales_order_signed_document (
    id uuid NOT NULL,
    sales_order_id uuid NOT NULL,
    document_id CHARACTER VARYING(255) NOT NULL,
    template_description CHARACTER VARYING(255) NOT NULL,
    document_name CHARACTER VARYING(255),
    message CHARACTER VARYING(100),
    rejectable boolean NOT NULL DEFAULT FALSE,
    rejected boolean DEFAULT FALSE,
    file_signed_url CHARACTER VARYING(4000),
    version bigint,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    external_id CHARACTER VARYING(255)
);

ALTER TABLE ONLY sales_order_signed_document
    ADD CONSTRAINT sales_order_signed_document_pkey PRIMARY KEY (id);

ALTER TABLE sales_order ADD COLUMN service_total_value NUMERIC(18,6);
ALTER TABLE sales_order ADD COLUMN product_total_value NUMERIC(18,6);

ALTER TABLE sales_order ADD COLUMN activity_id uuid;
