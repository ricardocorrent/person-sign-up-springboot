-- Orders por usuário
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('efd95390-4a5f-424b-9fb8-84f60d43c79f', 'accessrule.sales.salesOrderByUser', false, false, false, 'SalesOrder',
            'userId', 'user', 1, now(), now());

-- Orders por cliente respeitando região
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('ee6e00e3-7b60-4593-85e9-681ad22c8f4e', 'accessrule.sales.salesOrderByCustomer', true, true, false, 'SalesOrder',
            'customerId', 'customerByRegion', 1, now(), now());

-- OrderItems por usuário
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('612629b9-72cd-4479-9242-f528961d7bca', 'accessrule.sales.salesOrderItemByUser', false, false, false, 'SalesOrderItem',
            'salesOrder.userId', 'user', 1, now(), now());

-- OrderItems por cliente respeitando região
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('410c7e50-69ff-4159-b870-48daf4748d27', 'accessrule.sales.salesOrderItemByCustomer', true, true, false, 'SalesOrderItem',
            'salesOrder.customerId', 'customerByRegion', 1, now(), now());
			
			
INSERT INTO order_configuration(id, version, external_id, attendance_required, agricultural_plugin,
                                    currency_plugin, created_at, updated_at, deleted, block_by_inventory,
                                    validate_discount, validate_minimum_price, signature_required, due_date_price)
    VALUES (cloudextensions.uuid_generate_v4(), null, null, false, false, false, now(), now(), false, false, false, false, false, false);
	
-- 18.4.2
UPDATE order_configuration SET sync_from = '1991-01-01';

UPDATE order_configuration SET sync_request_limit = 1000;

--migrations 7.1

-- migration 6.0.0.1
-- migration 5.21.0.1
INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('6ec65d74-5dde-11e8-9c2d-fa7ae01bbebc', null, null, 'ATTENDANCE_REQUIRED', 'sales.orderConfiguration.attendanceRequired', 'BOOL',
	(SELECT '' || attendance_required || '' FROM order_configuration LIMIT 1), 'Obrigar atendimento antes de realizar um pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a140e-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'AGRICULTURAL_PLUGIN', 'sales.orderConfiguration.agriculturalPlugin', 'BOOL',
	(SELECT '' || AGRICULTURAL_PLUGIN || '' FROM order_configuration LIMIT 1), 'Exibir informações agricolas, como colheita, ocorrencias na colheira entre outros.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a1698-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'CURRENCY_PLUGIN', 'sales.orderConfiguration.currencyPlugin', 'BOOL',
	(SELECT '' || CURRENCY_PLUGIN || '' FROM order_configuration LIMIT 1), 'Exibir informações monetárias, como a cotação da moeda selecionada.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a17ec-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'BLOCK_BY_INVENTORY', 'sales.orderConfiguration.blockByInventory', 'BOOL',
	(SELECT '' || BLOCK_BY_INVENTORY || '' FROM order_configuration LIMIT 1), 'Bloquear a venda de produto com estoque negativo ou estoque zerado.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a1922-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'DUE_DATE_PRICE', 'sales.orderConfiguration.dueDatePrice', 'BOOL',
	(SELECT '' || DUE_DATE_PRICE || '' FROM order_configuration LIMIT 1), 'Utiliza calculo de preço por data de vencimento.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a1a62-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'VALIDATE_DISCOUNT', 'sales.orderConfiguration.validateDiscount', 'BOOL',
	(SELECT '' || VALIDATE_DISCOUNT || '' FROM order_configuration LIMIT 1), 'Validar desconto.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a1d8c-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'VALIDATE_MINIMUM_PRICE', 'sales.orderConfiguration.validateMinimumPrice', 'BOOL',
	(SELECT '' || VALIDATE_MINIMUM_PRICE || '' FROM order_configuration LIMIT 1), 'Validar preço mínimo.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a1ee0-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'SIGNATURE_REQUIRED', 'sales.orderConfiguration.signatureRequired', 'BOOL',
	(SELECT '' || SIGNATURE_REQUIRED || '' FROM order_configuration LIMIT 1), 'Exigir assinatura.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a2016-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'CREDIT_REQUIRED', 'sales.orderConfiguration.creditLimitRequired', 'BOOL',
	(SELECT '' || CREDIT_LIMIT_REQUIRED || '' FROM order_configuration LIMIT 1), 'Validar se o cliente possui limite de crédito disponível ao iniciar um pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('4b6a214c-5e03-11e8-9c2d-fa7ae01bbebc', null, null, 'BLOCK_ORDER_NEGATIVE_CREDIT', 'sales.orderConfiguration.validateNegativeCreditLimit', 'BOOL',
	(SELECT '' || VALIDATE_NEGATIVE_CREDIT_LIMIT || '' FROM order_configuration LIMIT 1), 'Bloquear a finalização de um pedido para um cliente com limite de crédito negativo.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('a616df48-6044-11e8-9c2d-fa7ae01bbebc', null, null, 'ENABLE_FIELDS_SEEDS_CONFIGURATOR', 'sales.parameter.enableFieldsSeeds', 'BOOL', 'true',
	'Utilizado para habilitar a configuração de sementes no configurador de pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('a616e470-6044-11e8-9c2d-fa7ae01bbebc', null, null, 'SEED_ORDER', 'sales.parameter.seedOrder', 'BOOL', 'false',
	'Parametro utilizado para habilitar/desabilitar os campos de semente no pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('a616ea42-6044-11e8-9c2d-fa7ae01bbebc', null, null, 'ENABLE_ROYALTY_TECHNOLOGY_VALUE_FIELDS', 'sales.parameter.enableRoyaltyTechnologyValueFields', 'BOOL', 'false',
	'Para para habilitar/desabilitar a exibição do campo para informar valor de Royalties no pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('a616ec9a-6044-11e8-9c2d-fa7ae01bbebc', null, null, 'GENERATE_CONTRACT_USING_MODEL', 'sales.parameter.generateContractUsingModel', 'BOOL', 'false',
	'Gerar contrato utilizando modelo cadastrado.', null, null, now(), now(), false);



-- migration 5.22.0.1

UPDATE order_configuration
SET enable_order_instalment = false;


-- migration 5.23.0.1
UPDATE order_configuration
    SET order_filter_days = 60;
    
UPDATE order_configuration
    SET sync_days = 60;

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('d1a16f55-45e6-4bb5-b93a-82ac88c7b47a', null, null, 'ENABLE_ORDER_INSTALMENT', 'sales.orderConfiguration.enableOrderInstalment', 'BOOL',
(SELECT '' || ENABLE_ORDER_INSTALMENT || '' FROM order_configuration LIMIT 1), 'Habilitar tela de parcelamento do pedido.', null, null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('137e4950-e90e-4450-beb3-6249db7ad842', null, null, 'ORDER_FILTER_DAYS', 'sales.orderConfiguration.filterDays', 'INT',
(SELECT '' || ORDER_FILTER_DAYS || '' FROM order_configuration LIMIT 1), 'Numero de dias para filtrar listagem de pedidos.', '0', null, now(), now(), false);

INSERT INTO order_parameter(ID, VERSION, EXTERNAL_ID, KEY, INTERNATIONALIZATION_KEY, VALUE_TYPE, VALUE, NOTE, MIN_VALUE, MAX_VALUE, CREATED_AT, UPDATED_AT, DELETED)
VALUES ('0f297370-5364-4eed-b274-ecde6ae27222', null, null, 'SYNC_DAYS', 'sales.orderConfiguration.syncDays', 'INT',
(SELECT '' || SYNC_DAYS || '' FROM order_configuration LIMIT 1), 'Numero de dias para limitar sincronização de pedidos.', '0', null, now(), now(), false);


-- Delivery by Customer
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('fce192fb-6b15-453e-a61e-be43a5c39be1', 'accessrule.sales.deliveryOrderByCustomer', true, true, false, 'DeliveryOrder',
            'salesOrder.customerId', 'customerByRegion', 1, now(), now());

-- Instalment by Customer
INSERT INTO access_rule(
            id, rule_name, active, default_rule, all_users, entity_name,
            reference_property, access_group_name, version, created_at, updated_at)
    VALUES ('3f20c405-6e08-4055-bdbe-a21a715b51df', 'accessrule.sales.salesOrderInstalmentByCustomer', true, true, false, 'SalesOrderInstalment',
            'salesOrder.customerId', 'customerByRegion', 1, now(), now());


---- migration 6.1.0.1
UPDATE order_parameter
SET value = true
WHERE id = 'a616df48-6044-11e8-9c2d-fa7ae01bbebc';
