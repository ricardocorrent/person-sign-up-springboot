UPDATE order_parameter
SET    value = false
WHERE  key = 'DUE_DATE_PRICE';

UPDATE order_parameter
SET    value = false
WHERE  key = 'DUE_DATE_FIELD_REQUIRED';

UPDATE order_parameter
SET    value = false
WHERE  key = 'ENABLE_DUE_DATE_FIELD';
