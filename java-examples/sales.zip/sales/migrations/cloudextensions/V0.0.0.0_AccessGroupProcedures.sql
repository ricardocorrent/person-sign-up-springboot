CREATE OR REPLACE FUNCTION cloudextensions.update_access_group_entity_ids(UUID, UUID[])
RETURNS void AS $$
DECLARE
BEGIN
    UPDATE access_group SET entity_ids = $2 WHERE id = $1;
END;
$$ LANGUAGE plpgsql;