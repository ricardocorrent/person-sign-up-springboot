package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import com.ws.commons.remoteconfig.provider.git.GitProvider;
import com.ws.commons.remoteconfig.provider.http.HttpProvider;
import com.ws.commons.remoteconfig.provider.noop.NoOpProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;

/**
 * Test cases for {@link RemoteProviderFactory}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(MockitoJUnitRunner.class)
public class RemoteProviderFactoryUnitTests {

    @Mock
    private RemoteConfigConfig config;

    private RemoteProviderFactory factory;

    @Before
    public void setup() {
        this.factory = new RemoteProviderFactory(config);
    }

    @Test
    public void shouldProduceUsingNoopAlias() {
        // scenario
        final String providerName = "NOOP";
        final Class<?> expectedImplementation = NoOpProvider.class;
        doReturn(providerName).when(config).getProvider();

        // execution
        final RemoteProvider provider = factory.build();

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(expectedImplementation)));
    }

    @Test
    public void shouldProduceUsingHttpAlias() {
        // scenario
        final String providerName = "HTTP";
        final Class<?> expectedImplementation = HttpProvider.class;
        doReturn(providerName).when(config).getProvider();

        // execution
        final RemoteProvider provider = factory.build();

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(expectedImplementation)));
    }

    @Test
    public void shouldProduceUsingGitAlias() {
        // scenario
        final String providerName = "GIT";
        final Class<?> expectedImplementation = GitProvider.class;
        doReturn(providerName).when(config).getProvider();

        // execution
        final RemoteProvider provider = factory.build();

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(expectedImplementation)));
    }

}
