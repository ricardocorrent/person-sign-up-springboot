package com.ws.commons.remoteconfig;

import java.util.Optional;
import java.util.Random;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

/**
 * Test cases for {@link StartingRemoteConfigSourceState}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public class StartingRemoteConfigSourceStateUnitTests {

    @Test
    public void shouldAlwaysReturnEmpty() {
        // scenario
        final String key = Double.toString(new Random().nextDouble());

        // execution
        final Optional<String> actualReturn = new StartingRemoteConfigSourceState().getValue(key);

        // validation
        assertThat(actualReturn.isPresent(), is(false));
    }

}
