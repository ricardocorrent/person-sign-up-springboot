package com.ws.commons.remoteconfig.provider.configserver;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Test cases for {@link AuthenticationModeConverter}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-14
 */
@RunWith(Parameterized.class)
public class AuthenticationModeConverterUnitTests {

    private final String currentTestValue;
    private final AuthenticationModeConverter converter;

    public AuthenticationModeConverterUnitTests(final String currentTestValue) {
        this.currentTestValue = currentTestValue;
        this.converter = new AuthenticationModeConverter();
    }

    @Parameterized.Parameters
    public static String[] getTestData() {
        return Stream
                .of(AuthenticationMode.values())
                .map(Enum::toString)
                .toArray(String[]::new);
    }

    @Test
    public void shouldConvertSuccessfullyIgnoringCase() {
        // scenario
        final AuthenticationMode expectedValue = AuthenticationMode.valueOf(currentTestValue.toUpperCase());

        // execution
        final AuthenticationMode currentValue = converter.convert(currentTestValue.toLowerCase());

        // validation
        assertThat(currentValue, is(expectedValue));
    }

}
