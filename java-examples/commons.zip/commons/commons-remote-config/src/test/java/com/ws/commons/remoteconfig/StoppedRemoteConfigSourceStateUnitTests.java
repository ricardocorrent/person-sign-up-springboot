package com.ws.commons.remoteconfig;

import java.util.Random;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * Test cases for {@link StoppedRemoteConfigSourceState}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public class StoppedRemoteConfigSourceStateUnitTests {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void shouldAlwaysThrowException() {
        // scenario
        expectedException.expect(IllegalStateException.class);
        expectedException.expectMessage("Resolver proxy needs to be initialized before use");
        final String key = Double.toString(new Random().nextDouble());

        // execution
        new StoppedRemoteConfigSourceState().getValue(key);
    }

}
