package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import java.util.Optional;
import java.util.Random;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

/**
 * Test cases for {@link StartedRemoteConfigSourceState}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(MockitoJUnitRunner.class)
public class StartedRemoteConfigSourceStateUnitTests {

    @Mock
    private RemoteProvider provider;
    private String serviceName;
    private String serviceVersion;
    private ProjectStage projectStage;
    private StartedRemoteConfigSourceState state;

    @Before
    public void setup() {
        this.serviceName = Double.toString(new Random().nextDouble());
        this.serviceVersion = Double.toString(new Random().nextDouble());
        this.projectStage = ProjectStage.UnitTest;
        this.state = new StartedRemoteConfigSourceState(provider, serviceName, serviceVersion, projectStage);
    }

    @Test
    public void shouldForwardToDelegate() {
        // scenario
        final String expectedKey = Double.toString(new Random().nextDouble());
        final String expectedReturn = Double.toString(new Random().nextDouble());
        doReturn(Optional.of(expectedReturn)).when(provider).getValue(projectStage, serviceName, serviceVersion, expectedKey);

        // execution
        final Optional<String> actualReturn = state.getValue(expectedKey);

        // validation
        assertThat(actualReturn.isPresent(), is(true));
        assertThat(actualReturn.get(), is(expectedReturn));
        verify(provider, times(1)).getValue(projectStage, serviceName, serviceVersion, expectedKey);
    }

}
