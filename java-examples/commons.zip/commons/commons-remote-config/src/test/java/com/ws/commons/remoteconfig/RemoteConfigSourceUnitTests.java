package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import java.util.Optional;
import java.util.Random;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.core.util.ProjectStageProducer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doReturn;

/**
 * Test cases for {@link RemoteConfigSource}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(MockitoJUnitRunner.class)
public class RemoteConfigSourceUnitTests {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private RemoteConfigConfig config;
    @Mock
    private RemoteProviderFactory factory;
    @Mock
    private RemoteProvider provider;

    private RemoteConfigSource source;

    @Before
    public void setup() {
        doReturn(provider).when(factory).build();
        doReturn("TestApplication").when(config).getServiceName();
        doReturn("TestProvider").when(config).getProvider();
        this.source = new RemoteConfigSource(config, factory);
    }

    @Test
    public void shouldValidateServiceName() {
        // scenario
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Missing configuration value for service name");
        doReturn(null).when(config).getServiceName();

        // execution
        source.getPropertyValue(null);
    }

    @Test
    public void shouldForwardToProvider() {
        // scenario
        final String expectedKey = Double.toString(new Random().nextDouble());
        final String expectedValue = Double.toString(new Random().nextDouble());
        ProjectStageProducer.setProjectStage(ProjectStage.UnitTest);
        doReturn(Optional.of(expectedValue))
                .when(provider)
                .getValue(any(), any(), any(), eq(expectedKey));

        // execution
        final String actualValue = source.getPropertyValue(expectedKey);

        // validation
        assertThat(actualValue, is(expectedValue));
    }

    @Test
    public void shouldReturnOrdinal150() {
        // execution
        final Integer actualValue = source.getOrdinal();

        // validation
        assertThat(actualValue, is(150));
    }

    @Test
    public void shouldDeclareItselfAsNotScannable() {
        // execution
        final boolean scannable = source.isScannable();

        // validation
        assertThat(scannable, is(false));
    }
}
