package com.ws.commons.remoteconfig.cache;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test cases for {@link CacheManager}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-21
 */
@RunWith(MockitoJUnitRunner.class)
public class CacheManagerUnitTests {

    private static final TimeUnit TEST_EXPIRATION_UNIT = TimeUnit.SECONDS;
    private static final Long TEST_EXPIRATION_UNIT_COUNT = 2L;

    @Mock
    private RemoteConfigConfig config;

    private CacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        doReturn(TEST_EXPIRATION_UNIT).when(config).getCacheExpireUnit();
        doReturn(TEST_EXPIRATION_UNIT_COUNT).when(config).getCacheExpireCount();

        this.cacheManager = new CacheManager(config);
    }

    @Test
    public void shouldCallLoaderWhenValueIsMissing() {
        // scenario
        final String expectedKey = Double.toString(new Random().nextDouble());
        final String expectedValue = Double.toString(new Random().nextDouble());
        final Function<String, String> loader = mock(Function.class);
        doReturn(expectedValue).when(loader).apply(any());

        // execution
        final String currentValue = cacheManager.retrieve(expectedKey, loader);

        // validation
        assertNotNull(currentValue);
        assertThat(currentValue, is(expectedValue));
        verify(loader, times(1)).apply(expectedKey);
    }

    @Test
    public void shouldReturnValueFromMemoryWhenPresent() {
        // scenario
        final String expectedKey = Double.toString(new Random().nextDouble());
        final String expectedValue = Double.toString(new Random().nextDouble());
        final Function<String, String> loader = mock(Function.class);
        doReturn(expectedValue).when(loader).apply(any());

        // execution
        final String currentValue1 = cacheManager.retrieve(expectedKey, loader);
        final String currentValue2 = cacheManager.retrieve(expectedKey, loader);
        final String currentValue3 = cacheManager.retrieve(expectedKey, loader);

        // validation
        assertNotNull(currentValue1);
        assertNotNull(currentValue2);
        assertNotNull(currentValue3);
        assertThat(currentValue1, is(expectedValue));
        assertThat(currentValue2, is(expectedValue));
        assertThat(currentValue3, is(expectedValue));
        verify(loader, times(1)).apply(expectedKey);
    }

    @Test
    public void shouldExpireValuesAfterConfigurationTimeout() throws Exception {
        // scenario
        final String expectedKey = Double.toString(new Random().nextDouble());
        final String expectedValue = Double.toString(new Random().nextDouble());
        final Function<String, String> loader = mock(Function.class);
        doReturn(expectedValue).when(loader).apply(any());

        // execution
        final String currentValue1 = cacheManager.retrieve(expectedKey, loader);
        final String currentValue2 = cacheManager.retrieve(expectedKey, loader);
        TEST_EXPIRATION_UNIT.sleep(TEST_EXPIRATION_UNIT_COUNT);
        final String currentValue3 = cacheManager.retrieve(expectedKey, loader);

        // validation
        assertNotNull(currentValue1);
        assertNotNull(currentValue2);
        assertNotNull(currentValue3);
        assertThat(currentValue1, is(expectedValue));
        assertThat(currentValue2, is(expectedValue));
        assertThat(currentValue3, is(expectedValue));
        verify(loader, times(2)).apply(expectedKey);
    }

}
