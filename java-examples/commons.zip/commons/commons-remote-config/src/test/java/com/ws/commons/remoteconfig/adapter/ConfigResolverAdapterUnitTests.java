package com.ws.commons.remoteconfig.adapter;

import com.ws.commons.remoteconfig.adapter.artifact.TestInterface;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.assertNotNull;

/**
 * Test cases for {@link ConfigResolverAdapter}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public class ConfigResolverAdapterUnitTests {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void shouldProduceInstances() {
        // scenario
        final Class<TestInterface.Valid> configInterface = TestInterface.Valid.class;

        // execution
        final TestInterface.Valid instance = ConfigResolverAdapter.forInterface(configInterface);

        // validation
        assertNotNull(instance);
    }

    @Test
    public void shouldThrowExceptionForInvalidInterface() {
        // scenario
        final Class<?> configInterface = TestInterface.InvalidInterface.class;
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Provided class isn't a valid configuration interface");

        // execution
        ConfigResolverAdapter.forInterface(configInterface);
    }

    @Test
    public void shouldThrowExceptionForClass() {
        // scenario
        final Class<?> configInterface = TestInterface.InvalidClass.class;
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Provided class isn't a valid configuration interface");

        // execution
        ConfigResolverAdapter.forInterface(configInterface);
    }

}
