package com.ws.commons.remoteconfig.provider.http;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javax.enterprise.inject.Instance;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import com.ws.commons.remoteconfig.cache.CacheManager;
import com.ws.commons.remoteconfig.http.HttpRequestCustomizer;
import com.ws.commons.remoteconfig.http.HttpRequestFacade;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockserver.junit.MockServerRule;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.verify.VerificationTimes.once;

/**
 * Test cases for {@link HttpProvider}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({HttpRequestFacade.class, HttpProvider.class, CacheManager.class})
public class HttpProviderIntegrationTests {

    @Rule
    public MockServerRule mockedServer = new MockServerRule(this);

    @Mock
    private Instance<HttpRequestCustomizer> customizerInstance;
    @Mock
    private HttpRequestCustomizer customizer;
    @Mock
    private HttpConfig httpConfig;
    @Mock
    private RemoteConfigConfig remoteConfig;

    private HttpRequestFacade requestFacade;
    private CacheManager cacheManager;
    private HttpProvider provider;
    private String targetHost;
    private String urlTemplate;
    private String targetPath;
    private String serviceName;
    private String serviceVersion;
    private ProjectStage projectStage;
    private String configurationKey;

    @Before
    public void setup() {
        this.serviceName = Integer.toString(new Random().nextInt());
        this.serviceVersion = Integer.toString(new Random().nextInt());
        this.projectStage = ProjectStage.IntegrationTest;
        this.configurationKey = Double.toString(new Random().nextDouble());
        this.targetHost = "http://localhost:" + mockedServer.getPort();
        this.urlTemplate = "/config/{application}/{stage}/{key}";
        this.targetPath = urlTemplate
                .replace("{application}", serviceName)
                .replace("{stage}", projectStage.toString())
                .replace("{key}", configurationKey);
        this.requestFacade = new HttpRequestFacade(Collections.emptyList());

        doReturn(Arrays.asList(customizer).iterator()).when(customizerInstance).iterator();
        doReturn(targetHost).when(httpConfig).getUrl();
        doReturn(urlTemplate).when(httpConfig).getTemplate();
        doReturn(TimeUnit.DAYS).when(remoteConfig).getCacheExpireUnit();
        doReturn(Long.MAX_VALUE).when(remoteConfig).getCacheExpireCount();

        this.cacheManager = new CacheManager(remoteConfig);
        this.provider = new HttpProvider(httpConfig, requestFacade, cacheManager);
    }

    @Test
    public void shouldRequestValueToRemoteServer() {
        // scenario
        final String expectedValue = Double.toString(new Random().nextDouble());

        mockedServer
                .getClient()
                .when(request().withPath(targetPath))
                .respond(response().withBody(expectedValue));

        // execution
        final Optional<String> actualValue = provider.getValue(projectStage, serviceName, serviceVersion, configurationKey);

        // validation
        assertThat(actualValue.isPresent(), is(true));
        assertThat(actualValue.get(), is(expectedValue));
        mockedServer.getClient().verify(
                request().withPath(targetPath),
                once()
        );
    }

    @Test
    public void shouldReturnEmptyWhenRemoteServerReplyWith404() {
        // scenario
        mockedServer
                .getClient()
                .when(request().withPath(targetPath))
                .respond(response().withStatusCode(404));

        // execution
        final Optional<String> actualValue = provider.getValue(projectStage, serviceName, serviceVersion, configurationKey);

        // validation
        assertThat(actualValue.isPresent(), is(false));
    }

    @Test
    public void shouldReturnValueFromCache() {
        // scenario
        final String expectedValue = Double.toString(new Random().nextDouble());

        mockedServer
                .getClient()
                .when(request().withPath(targetPath))
                .respond(response().withBody(expectedValue));

        // execution
        provider.getValue(projectStage, serviceName, serviceVersion, configurationKey);
        provider.getValue(projectStage, serviceName, serviceVersion, configurationKey);
        provider.getValue(projectStage, serviceName, serviceVersion, configurationKey);

        // validation
        mockedServer.getClient().verify(
                request().withPath(targetPath),
                once()
        );
    }

}
