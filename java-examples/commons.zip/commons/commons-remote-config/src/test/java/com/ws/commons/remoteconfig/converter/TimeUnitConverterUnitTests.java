package com.ws.commons.remoteconfig.converter;

import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.hamcrest.Matchers.is;

/**
 * Test cases for {@link TimeUnitConverter}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(Parameterized.class)
public class TimeUnitConverterUnitTests {

    private final TimeUnit expectedType;
    private final String unitName;

    public TimeUnitConverterUnitTests(final TimeUnit expectedType) {
        this.expectedType = expectedType;
        this.unitName = expectedType.name();
    }

    @Parameterized.Parameters(name = "Unit {0}")
    public static Object[] getTestData() {
        return TimeUnit.values();
    }

    @Test
    public void shouldConvertToTimeUnit() {
        final TimeUnit convertedValue = new TimeUnitConverter().convert(unitName);
        Assert.assertThat(convertedValue, is(expectedType));
    }

    @Test
    public void shouldConvertWhenNotAllUppercase() {
        final TimeUnit convertedValue = new TimeUnitConverter().convert(unitName.toLowerCase());
        Assert.assertThat(convertedValue, is(expectedType));
    }


}
