package com.ws.commons.remoteconfig.provider.noop;

import java.util.Optional;
import java.util.Random;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

/**
 * Test cases for {@link NoOpProvider}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public class NoOpProviderUnitTests {

    @Test
    public void shouldAlwaysReturnEmpty() {
        // scenario
        final String key = Double.toString(new Random().nextDouble());
        final ProjectStage projectStage = ProjectStage.UnitTest;
        final String serviceName = Double.toString(new Random().nextDouble());
        final String serviceVersion = Double.toString(new Random().nextDouble());

        // execution
        final Optional<String> actualReturn = new NoOpProvider().getValue(projectStage, serviceName, serviceVersion, key);

        // validation
        assertThat(actualReturn.isPresent(), is(false));
    }

}
