package com.ws.commons.remoteconfig.provider.configserver;

import com.ws.commons.remoteconfig.cache.CacheManager;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.*;
import java.util.function.Function;

import static org.apache.deltaspike.core.api.projectstage.ProjectStage.*;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

/**
 * Test cases for {@link ConfigServerProvider}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-14
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ConfigServerProvider.class, CacheManager.class})
public class ConfigServerProviderUnitTest {

    @Mock
    private ConfigServerConfig config;

    @Mock
    private ConfigServerLoader loader;

    @Mock
    private CacheManager cacheManager;

    private ConfigServerProvider provider;

    @Before
    public void setUp() throws Exception {
        provider = new ConfigServerProvider(config, cacheManager, loader);
    }

    @Test
    public void shouldResolveConfigurationValuesFromConfigServer() {

        // scenario
        final String applicationName = Double.toString(new Random().nextDouble());
        final String applicationVersion = Double.toString(new Random().nextDouble());
        final List<ProjectStage> stages = Arrays.asList(Development, IntegrationTest, Production, UnitTest);
        final ProjectStage stage = stages.get(new Random().nextInt(stages.size()));
        final String configurationKey = Double.toString(new Random().nextDouble());
        final String expectedValue = Double.toString(new Random().nextDouble());

        final ConfigurationDetails response = new ConfigurationDetails();
        final ConfigurationSource source = new ConfigurationSource();
        source.setName(applicationName + "-" + stage.toString());
        source.setSource(Collections.singletonMap(configurationKey, expectedValue));
        response.setPropertySources(Collections.singletonList(source));

        doReturn(Double.toString(new Random().nextDouble())).when(config).getTemplate();
        doReturn(Double.toString(new Random().nextDouble())).when(config).getUrl();
        doReturn(response).when(loader).fromUrl(any());
        doAnswer(invocation -> invocation.getArgumentAt(1, Function.class).apply(invocation.getArgumentAt(0, Object.class)))
                .when(cacheManager).retrieve(any(), any());

        // execution
        final Optional<String> currentValue = provider.getValue(stage, applicationName, applicationVersion, configurationKey);

        // validation
        assertNotNull(currentValue);
        assertThat(currentValue.isPresent(), is(true));
        assertThat(currentValue.get(), is(expectedValue));
    }

    @Test
    public void shouldStorePropertiesUnderAnInMemoryCache() {
        // scenario
        final String applicationName = Double.toString(new Random().nextDouble());
        final String applicationVersion = Double.toString(new Random().nextDouble());
        final List<ProjectStage> stages = Arrays.asList(Development, IntegrationTest, Production, UnitTest);
        final ProjectStage stage = stages.get(new Random().nextInt(stages.size()));
        final String configurationKey = Double.toString(new Random().nextDouble());
        final String expectedUrl = "http://test/" + applicationName + "/" + stage + "/" + applicationVersion;
        final ConfigurationDetails response = new ConfigurationDetails();
        response.setPropertySources(Collections.emptyList());

        doReturn("/{application}/{stage}/{version}").when(config).getTemplate();
        doReturn("http://test").when(config).getUrl();
        doReturn(response).when(cacheManager).retrieve(any(), any());

        // execution
        provider.getValue(stage, applicationName, applicationVersion, configurationKey);

        // validation
        verify(cacheManager, times(1)).retrieve(eq(expectedUrl), any());
    }

    @Test
    public void shouldReplaceDynamicTagsFromTemplateUrl() {

        // scenario
        final String applicationName = Double.toString(new Random().nextDouble());
        final String applicationVersion = Double.toString(new Random().nextDouble());
        final List<ProjectStage> stages = Arrays.asList(Development, IntegrationTest, Production, UnitTest);
        final ProjectStage stage = stages.get(new Random().nextInt(stages.size()));
        final String configurationKey = Double.toString(new Random().nextDouble());
        final String expectedUrl = "http://test/" + applicationName + "/" + stage + "/" + applicationVersion;
        final ConfigurationDetails response = new ConfigurationDetails();
        response.setPropertySources(Collections.emptyList());

        doReturn("/{application}/{stage}/{version}").when(config).getTemplate();
        doReturn("http://test").when(config).getUrl();
        doReturn(response).when(loader).fromUrl(any());
        doAnswer(invocation -> invocation.getArgumentAt(1, Function.class).apply(invocation.getArgumentAt(0, Object.class)))
                .when(cacheManager).retrieve(any(), any());

        // execution
        provider.getValue(stage, applicationName, applicationVersion, configurationKey);

        // validation
        verify(loader, times(1)).fromUrl(expectedUrl);

    }
}
