package com.ws.commons.remoteconfig.provider.configserver;

import com.ws.commons.remoteconfig.http.HttpRequestFacade;
import okhttp3.Request;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.*;
import java.util.function.Consumer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test cases for {@link ConfigServerLoader}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-14
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(HttpRequestFacade.class)
public class ConfigServerLoaderUnitTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ConfigServerConfig config;
    @Mock
    private HttpRequestFacade requestFacade;
    @Mock
    private Request.Builder requestBuilder;

    private ConfigServerLoader loader;
    private String testJsonResponse;
    private String url;

    @Before
    public void setUp() throws Exception {
        this.testJsonResponse = "{}";
        this.url = "http://localhost:1234/config/" + new Random().nextDouble();
        this.loader = new ConfigServerLoader(requestFacade, config);

        doReturn(AuthenticationMode.DISABLED).when(config).getAuthenticationMode();
        doAnswer(invocation -> {
            invocation.getArgumentAt(2, Consumer.class).accept(requestBuilder);
            return Optional.of(testJsonResponse);
        }).when(requestFacade).loadFromRemote(any(), any(), any());
    }

    @Test
    public void shouldAddAuthenticationHeaderWhenModeIsSetToBasic() {
        // scenario
        final String username = Double.toString(new Random().nextDouble());
        final String password = Double.toString(new Random().nextDouble());
        final String expectedAuthenticationValue = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());

        doReturn(username).when(config).getUsername();
        doReturn(password).when(config).getPassword();
        doReturn(AuthenticationMode.BASIC).when(config).getAuthenticationMode();

        // execution
        final ConfigurationDetails details = loader.fromUrl(url);

        // validation
        assertNotNull(details);

        final ArgumentCaptor<String> headerNameCaptor = ArgumentCaptor.forClass(String.class);
        final ArgumentCaptor<String> headerValueCaptor = ArgumentCaptor.forClass(String.class);
        verify(requestBuilder, times(1)).addHeader(headerNameCaptor.capture(), headerValueCaptor.capture());

        assertThat(headerNameCaptor.getValue(), is("Authentication"));
        assertThat(headerValueCaptor.getValue(), is ("Basic " + expectedAuthenticationValue));
    }

    @Test
    public void shouldAddAuthenticationHeaderWhenModeIsSetToToken() {
        // scenario
        final String token = Double.toString(new Random().nextDouble());

        doReturn(token).when(config).getToken();
        doReturn(AuthenticationMode.TOKEN).when(config).getAuthenticationMode();

        // execution
        final ConfigurationDetails details = loader.fromUrl(url);

        // validation
        assertNotNull(details);

        final ArgumentCaptor<String> headerNameCaptor = ArgumentCaptor.forClass(String.class);
        final ArgumentCaptor<String> headerValueCaptor = ArgumentCaptor.forClass(String.class);
        verify(requestBuilder, times(1)).addHeader(headerNameCaptor.capture(), headerValueCaptor.capture());

        assertThat(headerNameCaptor.getValue(), is("Authentication"));
        assertThat(headerValueCaptor.getValue(), is ("Bearer " + token));
    }

    @Test
    public void shouldConvertHttpResponseToConfigurationDetailsObject() throws Exception {
        // scenario
        final String name = Double.toString(new Random().nextDouble());
        final String label = Double.toString(new Random().nextDouble());
        final String version = Double.toString(new Random().nextDouble());
        final String profile = Double.toString(new Random().nextDouble());
        final String state = Double.toString(new Random().nextDouble());
        final String configName = Double.toString(new Random().nextDouble());
        final Map<String, String> source = Collections.singletonMap("value", Double.toString(new Random().nextDouble()));

        final JSONObject configurationSource = new JSONObject()
                .put("name", configName)
                .put("source", new JSONObject().put("value", source.get("value")));

        testJsonResponse = new JSONObject()
                .put("name", name)
                .put("label", label)
                .put("version", version)
                .put("profiles", new JSONArray().put(profile))
                .put("state", state)
                .put("propertySources", new JSONArray().put(configurationSource))
                .toString();

        // execution
        final ConfigurationDetails currentValue = loader.fromUrl(url);

        // validation
        assertNotNull(currentValue);
        assertThat(currentValue.getName(), is(name));
        assertThat(currentValue.getLabel(), is(label));
        assertNotNull(currentValue.getProfiles());
        assertThat(currentValue.getProfiles().size(), is(1));
        assertThat(currentValue.getProfiles().get(0), is(profile));
        assertThat(currentValue.getState(), is(state));
        assertNotNull(currentValue.getPropertySources());
        assertThat(currentValue.getPropertySources().size(), is(1));

        final ConfigurationSource currentConfigurationSource = currentValue.getPropertySources().get(0);
        assertThat(currentConfigurationSource.getName(), is(configName));
        assertNotNull(currentConfigurationSource.getSource());
        assertThat(currentConfigurationSource.getSource().size(), is(1));
        assertThat(currentConfigurationSource.getSource().get("value"), is(source.get("value")));
    }

    @Test
    public void shouldThrowExceptionWhenResponseIsntAValidJson() {
        // scenario
        testJsonResponse = "This is not a valida JSON value " + new Random().nextInt();

        // validation
        expectedException.expect(RuntimeException.class);
        expectedException.expectMessage("Error reading response from Spring Cloud Config Server. Content is not a valid JSON value.");

        // execution
        loader.fromUrl(url);
    }

    @Test
    public void shouldThrowExceptionWhenAuthModeIsBasicAndNoUsernameIsSet() {
        // scenario
        doReturn(null).when(config).getUsername();
        doReturn(AuthenticationMode.BASIC).when(config).getAuthenticationMode();

        // validation
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Authentication mode is set to basic but no username was set in configuration");

        // execution
        loader.fromUrl(url);
    }

    @Test
    public void shouldThrowExceptionWhenAuthModeIsTokenAndNoTokenIsSet() {
        // scenario
        doReturn(null).when(config).getUsername();
        doReturn(AuthenticationMode.TOKEN).when(config).getAuthenticationMode();

        // validation
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Authentication mode is set to token but no token was set in configuration");

        // execution
        loader.fromUrl(url);
    }

}
