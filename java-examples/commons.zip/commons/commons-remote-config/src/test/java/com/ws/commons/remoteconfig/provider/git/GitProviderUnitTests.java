package com.ws.commons.remoteconfig.provider.git;

import java.util.Optional;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import com.ws.commons.remoteconfig.cache.CacheManager;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test cases for {@link GitProvider}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({CacheManager.class, GitProvider.class})
public class GitProviderUnitTests {


    @Mock
    private GitRepository repository;
    @Mock
    private GitConfig config;
    @Mock
    private Properties properties;
    @Mock
    private RemoteConfigConfig remoteConfig;

    private CacheManager cacheManager;

    private GitProvider provider;

    @Before
    public void setup() {
        doReturn(Optional.of(properties)).when(repository).getProperties(any(ProjectStage.class), any(String.class), any(String.class));
        doReturn(30L).when(remoteConfig).getCacheExpireCount();
        doReturn(TimeUnit.SECONDS).when(remoteConfig).getCacheExpireUnit();
        this.cacheManager = new CacheManager(remoteConfig);
        this.provider = new GitProvider(repository, cacheManager);
    }

    @Test
    public void shouldLoadValuesFromRepository() {
        // scenario
        final String key = Double.toString(new Random().nextDouble());
        final ProjectStage projectStage = ProjectStage.UnitTest;
        final String serviceName = Double.toString(new Random().nextDouble());
        final String serviceVersion = Double.toString(new Random().nextDouble());
        final String expectedReturn = Double.toString(new Random().nextDouble());
        doReturn(expectedReturn).when(properties).getProperty(key);

        // execution
        final Optional<String> actualReturn = provider.getValue(projectStage, serviceName, serviceVersion, key);

        // validation
        assertThat(actualReturn.isPresent(), is(true));
        assertThat(actualReturn.get(), is(expectedReturn));
        verify(repository, times(1)).getProperties(projectStage, serviceName, serviceVersion);
    }

    @Test
    public void shouldRequestPullToRepositoryAfterFirstCall() {
        // scenario
        final String key = Double.toString(new Random().nextDouble());
        final ProjectStage projectStage = ProjectStage.UnitTest;
        final String serviceName = Double.toString(new Random().nextDouble());
        final String serviceVersion = Double.toString(new Random().nextDouble());

        // execution
        provider.getValue(projectStage, serviceName, serviceVersion, key);
        provider.getValue(projectStage, serviceName, serviceVersion, key);

        // validation
        verify(repository, times(1)).requestPull();
    }

}
