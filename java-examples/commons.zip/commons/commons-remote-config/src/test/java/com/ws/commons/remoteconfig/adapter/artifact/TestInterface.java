package com.ws.commons.remoteconfig.adapter.artifact;

import org.apache.deltaspike.core.api.config.Configuration;

/**
 * Test artifacts for {@link com.ws.commons.remoteconfig.adapter.ConfigResolverAdapterUnitTests}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public class TestInterface {

    @Configuration
    public interface Valid {
    }

    public interface InvalidInterface {

    }

    public static class InvalidClass {

    }


}
