package com.ws.commons.remoteconfig.provider.configserver;

import java.io.Serializable;
import java.util.List;

/**
 * Spring Cloud Config Server configuration details response object
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-2-12
 */
class ConfigurationDetails implements Serializable {

    private String name;
    private List<String> profiles;
    private String label;
    private String version;
    private String state;
    private List<ConfigurationSource> propertySources;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public List<String> getProfiles() {
        return profiles;
    }

    public void setProfiles(final List<String> profiles) {
        this.profiles = profiles;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(final String version) {
        this.version = version;
    }

    public String getState() {
        return state;
    }

    public void setState(final String state) {
        this.state = state;
    }

    public List<ConfigurationSource> getPropertySources() {
        return propertySources;
    }

    public void setPropertySources(final List<ConfigurationSource> propertySources) {
        this.propertySources = propertySources;
    }
}
