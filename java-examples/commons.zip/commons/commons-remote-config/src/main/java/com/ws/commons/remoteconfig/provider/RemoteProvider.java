package com.ws.commons.remoteconfig.provider;

import java.util.Optional;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;

/**
 * Remote configuration repository interface
 *
 * <p>Allows simple configuration resolution using remote repositories. A remote repository can be a service,
 * a Git repository or any other.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
public interface RemoteProvider {

    /**
     * Resolves a configuration value using provided stage, key and service name
     *
     * @param projectStage Project current stage
     * @param serviceName Project name
     * @param serviceVersion Project API version
     * @param configurationKey Configuration key
     * @return Resolved configuration value
     */
    Optional<String> getValue(ProjectStage projectStage, String serviceName, String serviceVersion, String configurationKey);

}
