package com.ws.commons.remoteconfig;

import java.util.Optional;
import com.ws.commons.remoteconfig.RemoteConfigSource.State;

/**
 * {@link State} implementation for stopped state
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
class StoppedRemoteConfigSourceState implements State {

    /**
     * Executes the configuration resolution
     *
     * @param key Configuration key to be resolved
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final String key) {
        throw new IllegalStateException("Resolver proxy needs to be initialized before use");
    }

    /**
     * Returns if current state requires initialization tasks to be started
     *
     * @return Initialization status
     */
    @Override
    public boolean isInitializationRequired() {
        return true;
    }
}
