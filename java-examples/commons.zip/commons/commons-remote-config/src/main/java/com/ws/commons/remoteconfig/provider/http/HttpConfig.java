package com.ws.commons.remoteconfig.provider.http;

import com.ws.commons.remoteconfig.http.HttpRequestCustomizer;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * Deltaspike configuration interface with properties for HTTP remote config resolver
 *
 * <p>This class is able to resolve configuration properties using a remote HTTP service (a.k.a repository).
 * Implementation is also able to store resolved values from remote HTTP service under a temporary cache, but this
 * is optional and can be disabled using configuration.</p>
 *
 * <p>All requests can also be customized using interface {@link HttpRequestCustomizer}. See interface documentation for
 * more information.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-07
 */
@Configuration(prefix = "remoteconfig.http.")
interface HttpConfig {

    /**
     * @return The URL template to be used in resolution HTTP requests
     */
    @ConfigProperty(name = "template", defaultValue = "/config/{application}/{stage}/{key}")
    String getTemplate();

    /**
     * @return The base URL to be used to connect to the remote repository.
     */
    @ConfigProperty(name = "url")
    String getUrl();

}
