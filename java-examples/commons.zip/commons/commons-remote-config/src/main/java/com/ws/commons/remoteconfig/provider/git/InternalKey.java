package com.ws.commons.remoteconfig.provider.git;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;

/**
 * Internal key helper class for Git remote repositories
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-07
 */
class InternalKey {

    private final ProjectStage stage;
    private final String serviceName;
    private final String serviceVersion;

    /**
     * Constructor with key details initialization
     *
     * @param stage Project stage
     * @param serviceName Service name
     */
    InternalKey(final ProjectStage stage,
                       final String serviceName,
                       final String serviceVersion) {
        this.stage = stage;
        this.serviceName = serviceName;
        this.serviceVersion = serviceVersion;
    }

    ProjectStage getStage() {
        return stage;
    }

    String getServiceName() {
        return serviceName;
    }

    String getServiceVersion() {
        return serviceVersion;
    }

    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        final InternalKey other = (InternalKey) object;

        return new EqualsBuilder()
                .append(stage, other.stage)
                .append(serviceName, other.serviceName)
                .append(serviceVersion, other.serviceVersion)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(stage)
                .append(serviceName)
                .append(serviceVersion)
                .toHashCode();
    }

    @Override
    public String toString() {
        return "InternalKey{" +
                "stage=" + stage +
                ", serviceName='" + serviceName + '\'' +
                ", serviceVersion='" + serviceVersion + '\'' +
                '}';
    }
}
