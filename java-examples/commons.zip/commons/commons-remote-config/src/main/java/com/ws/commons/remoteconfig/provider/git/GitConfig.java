package com.ws.commons.remoteconfig.provider.git;

import com.ws.commons.remoteconfig.converter.TimeUnitConverter;
import java.util.concurrent.TimeUnit;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * Deltaspike configuration interface with properties for Git remote config resolver
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-07
 */
@Configuration(prefix = "remoteconfig.git.")
interface GitConfig {

    /**
     * @return Branch name from remote repository to be used. Defaults to master.
     */
    @ConfigProperty(name = "branch", defaultValue = "master")
    String getBranch();

    /**
     * @return Username to be used when authentication is enabled
     */
    @ConfigProperty(name = "username")
    String getUsername();

    /**
     * @return Password to be used when authentication is enabled
     */
    @ConfigProperty(name = "password")
    String getPassword();

    /**
     * @return Boolean flag to indicate if authentication needs to be done on remote repository. Defaults to false.
     */
    @ConfigProperty(name = "useauthentication", defaultValue = "false")
    Boolean isUseAuthentication();

    /**
     * @return The URL to be used to connect to the remote repository.
     */
    @ConfigProperty(name = "url")
    String getUrl();

}
