package com.ws.commons.remoteconfig.provider.git;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Internal Git repository utilitary class
 *
 * <p>This class is responsible for executing and controlling Git operations under a remote repository that stores
 * configuration properties. Among others, this class can perform operations like clone, pull and file reading.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-07
 */
@ApplicationScoped
class GitRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(GitRepository.class);

    private Long lastPull;
    private Git repository;
    private final String branch;
    private final String username;
    private final String password;
    private final String url;
    private final boolean useAuthentication;
    private final TimeUnit cacheTimeUnit;
    private final Long cacheTimeCount;

    /**
     * Constructor with {@link GitConfig} initialization
     *
     * @param gitConfig Configuration properties
     */
    @Inject
    GitRepository(final GitConfig gitConfig, final RemoteConfigConfig remoteConfigConfig) {
        this.branch = gitConfig.getBranch();
        this.username = gitConfig.getUsername();
        this.password = gitConfig.getPassword();
        this.url = gitConfig.getUrl();
        this.useAuthentication = gitConfig.isUseAuthentication();
        this.cacheTimeCount = remoteConfigConfig.getCacheExpireCount();
        this.cacheTimeUnit = remoteConfigConfig.getCacheExpireUnit();
    }

    /**
     * Request the execution of a pull under local clone
     *
     * <p>This method requests a new pull under local cloned repository, but the pull can be ignored when
     * cache is enabled and the last pull was made not too long ago (and the expiration timeout has not triggered yet).</p>
     */
    synchronized void requestPull() {
        if (repository == null) {
            return;
        }

        final Optional<Long> pullInterval = getPullInterval();
        if (pullInterval.isPresent()) {
            final Long lastPullDiff = System.currentTimeMillis() - lastPull;
            if (lastPullDiff < pullInterval.get()) {
                LOGGER.debug("Cache is enabled and hasn't expired yet. Pull request will be ignored.");
                return;
            }
        }

        try {
            LOGGER.debug("Invoking pull under local Git repository");
            repository.pull().call();
            lastPull = System.currentTimeMillis();
        } catch (final Exception ex) {
            throw new RuntimeException("Error pulling updated changes", ex);
        }
    }

    /**
     * Returns the {@link Properties} object for the provided stage of the service
     *
     * @param projectStage Project current stage
     * @param serviceName Service name
     * @return Properties file if present
     */
    Optional<Properties> getProperties(final ProjectStage projectStage, final String serviceName, final String serviceVersion) {
        synchronized (this) {
            if (repository == null) {
                cloneOrigin();
            }
        }

        final File localFolder = repository.getRepository().getWorkTree();
        final String filePath = serviceName + File.separator + serviceVersion + File.separator + projectStage + ".properties";
        final File propertiesFile = new File(localFolder, filePath);

        if (!propertiesFile.exists() || !propertiesFile.isFile() || !propertiesFile.canRead()) {
            LOGGER.debug("No configuration properties available to read for service {} at stage {}", serviceName, projectStage);
            return Optional.empty();
        }

        try {
            final Properties properties = new Properties();
            properties.load(new FileInputStream(propertiesFile));
            return Optional.of(properties);
        } catch (final Exception ex) {
            throw new RuntimeException("Error loading properties file from temporary local Git clone", ex);
        }
    }

    /**
     * Retrieves the pull interval in milliseconds
     *
     * <p>This method checks configuration for cache attributes. When present, calculates and returns the amount
     * of milliseconds to wait between pulls.</p>
     *
     * @return Amount of milliseconds to wait between pulls. Can be null when cache is disabled.
     */
    private Optional<Long> getPullInterval() {
        if (cacheTimeUnit == null || cacheTimeCount == null) {
            return Optional.empty();
        }

        return Optional.of(cacheTimeUnit.toMillis(cacheTimeCount));
    }

    /**
     * Clones the repository from the Git origin server
     */
    private void cloneOrigin() {

        final File tempDir;
        try {
            tempDir = File.createTempFile("configuration", "");
        } catch (final IOException ex) {
            throw new RuntimeException("Error creating temporary folder/file", ex);
        }

        LOGGER.debug("Cloning remote Git repository with configuration properties locally at {}", tempDir.getAbsolutePath());

        tempDir.delete();
        tempDir.mkdirs();

        final CloneCommand cloneCommand = Git
                .cloneRepository()
                .setBranch(branch)
                .setDirectory(tempDir)
                .setURI(url);

        LOGGER.debug("Trying to clone from branch {} at {}", branch, url);

        if (useAuthentication) {
            LOGGER.debug("Authentication is enabled. Username {} will be used.", username);

            cloneCommand.setCredentialsProvider(new UsernamePasswordCredentialsProvider(
                    username, password
            ));
        }

        try {
            this.repository = cloneCommand.call();
        } catch (final Exception ex) {
            throw new RuntimeException("Error cloning remote Git repository", ex);
        }

        LOGGER.debug("Clone completed");
    }

}
