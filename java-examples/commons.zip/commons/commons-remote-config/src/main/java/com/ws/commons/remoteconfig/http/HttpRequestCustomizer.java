package com.ws.commons.remoteconfig.http;

import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Customizes the request and client that will be used to retrieve a configuration value from a remote HTTP provider
 *
 * <p>This interface allows the customization of the requests and clients before execution the request under the
 * remote HTTP repository, allowing to tune options for the request when needed.</p>
 *
 * <p>All implementations of this interface will be found using CDI. </p>
 *
 * <p>Following is an example implementation that adds an authentication header:</p>
 * <pre><code>
 *     @Default
 *     public class ExampleCustomizer implements HttpRequestCustomizer {
 *
 *         @Override
 *         public void customize(Request.Builder request, OkHttpClient.Builder client) {
 *            request.header(
 *              "Authorization",
 *              "Bearer " + AuthContext.currentUser().getToken()
 *            );
 *         }
 *     }
 * </code></pre>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-07
 */
public interface HttpRequestCustomizer {

    /**
     * Customizes the request and the client before execution of the HTTP request
     *
     * @param request Request builder
     * @param client Client builder
     */
    void customize(Request.Builder request, OkHttpClient.Builder client);

}
