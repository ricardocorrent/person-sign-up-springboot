package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.adapter.ConfigResolverAdapter;
import com.ws.commons.remoteconfig.provider.RemoteProvider;
import org.apache.deltaspike.core.api.config.Source;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.core.spi.config.ConfigSource;
import org.apache.deltaspike.core.util.ProjectStageProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

/**
 * Deltaspike {@link ConfigSource} implementation for simple integration with the API
 *
 * <p>This class implements the {@link ConfigSource} and acts as a bridge between the Deltaspike API and the commons
 * remote configuration API.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
@Source
public final class RemoteConfigSource implements ConfigSource {

    /**
     * Resolver proxy nternal state interface
     *
     * @author Lucas Dillmann
     * @since 7.5.0, 2019-01-03
     */
    interface State {

        /**
         * Executes the configuration resolution
         *
         * @param key Configuration key to be resolved
         * @return Resolved configuration value
         */
        Optional<String> getValue(String key);

        /**
         * Returns if current state requires initialization tasks to be started
         *
         * @return Initialization status
         */
        boolean isInitializationRequired();
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoteConfigSource.class);
    private final RemoteConfigConfig config;
    private final RemoteProviderFactory factory;
    private State state;

    /**
     * Default constructor
     */
    public RemoteConfigSource() {
        this.config = ConfigResolverAdapter.forInterface(RemoteConfigConfig.class);
        this.factory = new RemoteProviderFactory(config);
        this.state = new StoppedRemoteConfigSourceState();
    }

    /**
     * CDI enabled constructor with {@link RemoteConfigConfig} and {@link RemoteProviderFactory} initialization
     *
     * @param config Configuration object
     * @param factory RemoteProvider factory
     */
    @Inject
    public RemoteConfigSource(final RemoteConfigConfig config, final RemoteProviderFactory factory) {
        this.config = config;
        this.factory = factory;
        this.state = new StoppedRemoteConfigSourceState();
    }

    /**
     * Returns the precedence order
     *
     * <p>Value returned by this method is used by Deltaspike to build an internal precedence order of all
     * {@link ConfigSource} implementations. This implementation statically returns {@code 150} as the ordinal
     * value, which means that it should be called before resolution of values using configuration files but
     * after resolutions using environment variables.</p>
     *
     * @return Precedence order
     */
    @Override
    public int getOrdinal() {
        return 150;
    }

    /**
     * Returns all available properties pairs, not implemented on this class
     *
     * @return {@code null}
     */
    @Override
    public Map<String, String> getProperties() {
        return null;
    }

    /**
     * Invoke configuration resolution for the given key
     *
     * <p>This method is called by Deltaspike API when configuration resolution is needed. Current implementation
     * will forward all requests to loaded {@link RemoteProvider}
     * using and internal proxy. When resolution can't be done this method simple returns {@code null},
     * letting Deltaspike known that resolution should be done using the next available {@link ConfigSource}.</p>
     *
     * @param key Configuration key to be resolved
     * @return Resolved configuration value for the requested key
     */
    @Override
    public String getPropertyValue(final String key) {
        synchronized (state) {
            if (state.isInitializationRequired()) {
                initialize();
            }
        }

        LOGGER.debug("Resolving configuration key {}", key);
        return state.getValue(key).orElse(null);
    }

    /**
     * Starts the initialization procedure
     */
    private void initialize() {
        if (!state.isInitializationRequired()) {
            throw new IllegalStateException("Internal state is already initialized");
        }

        LOGGER.debug("Initializing internal state");
        this.state = new StartingRemoteConfigSourceState();

        LOGGER.debug("Resolved service name is {}", config.getServiceName());
        if (config.getServiceName() == null) {
            throw new IllegalArgumentException("Missing configuration value for service name");
        }

        final ProjectStage projectStage = ProjectStageProducer.getInstance().getProjectStage();
        LOGGER.debug("Current project stage is {}", projectStage);
        if (projectStage == null){
            throw new IllegalArgumentException("No active project stage found under Deltaspike context");
        }

        final RemoteProvider provider = factory.build();
        LOGGER.debug("Remote config provider started as {}", provider.getClass().getName());

        final String applicationVersion = getApplicationVersion();
        this.state = new StartedRemoteConfigSourceState(provider, config.getServiceName(), applicationVersion, projectStage);
        LOGGER.debug("Initialization completed");
    }

    /**
     * Tries to retrieve current application version from service release property, falling-back to service version when
     * not available
     *
     * @return Application version
     */
    private String getApplicationVersion() {
        final String releaseVersion = config.getServiceRelease();
        if (releaseVersion != null) {
            return releaseVersion;
        }

        LoggerFactory
                .getLogger(getClass())
                .warn("Service release version is missing (key service.release). " +
                        "Using service version instead to resolve configuration values.");
        return config.getServiceVersion();
    }

    /**
     * Returns current {@link ConfigSource} implementation name. Always returns {@code Remote config forwarder}.
     *
     * @return Implementatation name
     */
    @Override
    public String getConfigName() {
        return "Remote config forwarder";
    }

    /**
     * Returns if current implementation is compatible with scan. If true, means that {@link #getProperties()}
     * will be called to retrieve all configuration values at once. Since referred method always returns {@code null},
     * this method always returns {@code false}.
     *
     * @return {@code false}
     */
    @Override
    public boolean isScannable() {
        return false;
    }
}
