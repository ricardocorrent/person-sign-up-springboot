package com.ws.commons.remoteconfig.provider.configserver;

import com.google.gson.Gson;
import com.ws.commons.remoteconfig.http.HttpRequestFacade;
import okhttp3.Request;

import javax.inject.Inject;
import java.util.Base64;

/**
 * Utility class able to talk to and load configuration values from a remote Config Server
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-13
 */
class ConfigServerLoader {

    private static final String AUTHENTICATION_HEADER = "Authentication";
    private static final String BASIC_AUTHENTICATION_PREFIX = "Basic ";
    private static final String TOKEN_AUTHENTICATION_PREFIX = "Bearer ";
    private static final String NO_USERNAME_FOUND_MESSAGE = "Authentication mode is set to basic but no username was set in configuration";
    private static final String NO_TOKEN_FOUND_MESSAGE = "Authentication mode is set to token but no token was set in configuration";

    private final HttpRequestFacade httpFacade;
    private final ConfigServerConfig configuration;

    /**
     * CDI enabled constructor with HTTP facade and configuration initialization
     *
     * @param httpFacade HTTP utility object
     * @param configuration Configuration for Config Server
     */
    @Inject
    ConfigServerLoader(final HttpRequestFacade httpFacade, final ConfigServerConfig configuration) {
        this.httpFacade = httpFacade;
        this.configuration = configuration;
    }

    /**
     * Retrieve {@link ConfigurationDetails} from Config Server using supplied URL
     *
     * @param url URL where config server should be found
     * @return Configuration details retrieved from provided URL
     */
    ConfigurationDetails fromUrl(final String url) {
        return httpFacade
                .loadFromRemote(url, "application/json", this::addAuthenticationHeader)
                .map(this::fromJsonString)
                .orElseThrow(() -> new RuntimeException("Error retrieving configuration properties from remote server"));
    }

    /**
     * Converts an JSON String to a {@link ConfigurationDetails} object using {@link Gson}
     *
     * @param json JSON String to be converted
     * @return Parsed {@link ConfigurationDetails}
     */
    private ConfigurationDetails fromJsonString(final String json) {
        try {
            return new Gson().fromJson(json, ConfigurationDetails.class);
        } catch (final Exception ex) {
            throw new RuntimeException("Error reading response from Spring Cloud Config Server. Content is not a valid JSON value.", ex);
        }
    }

    /**
     * Using definitions from configuration, injects into request the authentication header when needed
     *
     * @param requestBuilder Request builder
     */
    private void addAuthenticationHeader(final Request.Builder requestBuilder) {
        final AuthenticationMode authenticationMode = configuration.getAuthenticationMode();
        switch (authenticationMode) {
            case DISABLED:
                return;
            case BASIC:
                final String username = configuration.getUsername();
                final String password = configuration.getPassword();
                requireNonEmpty(username, NO_USERNAME_FOUND_MESSAGE);
                final String encodedValue = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
                requestBuilder.addHeader(AUTHENTICATION_HEADER, BASIC_AUTHENTICATION_PREFIX + encodedValue);
                break;
            case TOKEN:
                final String token = configuration.getToken();
                requireNonEmpty(token, NO_TOKEN_FOUND_MESSAGE);
                requestBuilder.addHeader(AUTHENTICATION_HEADER, TOKEN_AUTHENTICATION_PREFIX + token);
                break;
            default:
                throw new IllegalArgumentException("Unsupported authentication mode: " + authenticationMode);
        }
    }

    /**
     * Validates if the provided value is null or empty, throwing a {@link IllegalArgumentException} when validation fails
     * using provided exception message
     *
     * @param value Value to be validated
     * @param exceptionMessage Message to be used when validation fails
     */
    private void requireNonEmpty(final String value, final String exceptionMessage) {
        if (value == null || value.trim().isEmpty())
            throw new IllegalArgumentException(exceptionMessage);
    }
}
