package com.ws.commons.remoteconfig.provider.configserver;

/**
 * Available authentication modes for Spring Config Server authentication over HTTP
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-14
 */
enum AuthenticationMode {
    DISABLED,
    BASIC,
    TOKEN
}
