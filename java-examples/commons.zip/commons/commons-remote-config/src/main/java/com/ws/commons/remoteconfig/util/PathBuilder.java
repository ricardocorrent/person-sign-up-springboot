package com.ws.commons.remoteconfig.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Simple path builder with dynamic template tags replacement capabilities
 *
 * <p>This utility class helps the constructions of template based values under a builder-like pattern. In other words,
 * provide a simple API for scenarios where a template with pre-defined replacement tags are available.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-14
 */
public final class PathBuilder {

    private final Map<String, String> tags;

    /**
     * Default constructor
     */
    public PathBuilder() {
        this.tags = new HashMap<>();
    }

    /**
     * Adds a tag and target replacement value
     *
     * @param tag Replacement tag (source)
     * @param value Replacement value (target)
     * @return Current builder instance
     */
    public PathBuilder withTag(final String tag, final String value) {
        tags.put(tag, value);
        return this;
    }

    /**
     * Ends the build process and replaces all available tags with target values
     *
     * @param template Template string to be used
     * @return Template value with tag values replaced
     */
    public String build(String template) {
        for (final Map.Entry<String, String> pair : tags.entrySet()) {
            template = template.replace(pair.getKey(), pair.getValue());
        }

        return template;
    }
}
