package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import java.util.Optional;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ws.commons.remoteconfig.RemoteConfigSource.State;

/**
 * {@link State} implementation for started/running state
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
class StartedRemoteConfigSourceState implements State {

    private static final Logger LOGGER = LoggerFactory.getLogger(StartedRemoteConfigSourceState.class);
    private final RemoteProvider delegate;
    private final String serviceName;
    private final String serviceVersion;
    private final ProjectStage projectStage;

    /**
     * Constructor with delegate, service name and project stage initialization
     *
     * @param delegate     Configuration provider to delegate resolution calls
     * @param serviceName  Service name
     * @param projectStage Project stage
     */
    StartedRemoteConfigSourceState(final RemoteProvider delegate,
                                   final String serviceName,
                                   final String serviceVersion,
                                   final ProjectStage projectStage) {
        this.delegate = delegate;
        this.serviceName = serviceName;
        this.serviceVersion = serviceVersion;
        this.projectStage = projectStage;
    }

    /**
     * Executes the configuration resolution
     *
     * @param key Configuration key to be resolved
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final String key) {
        LOGGER.debug("Forwarding configuration resolution for key {}", key);
        return delegate.getValue(projectStage, serviceName, serviceVersion, key);
    }

    /**
     * Returns if current state requires initialization tasks to be started
     *
     * @return Initialization status
     */
    @Override
    public boolean isInitializationRequired() {
        return false;
    }
}
