package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import com.ws.commons.remoteconfig.provider.configserver.ConfigServerProvider;
import com.ws.commons.remoteconfig.provider.git.GitProvider;
import com.ws.commons.remoteconfig.provider.http.HttpProvider;
import com.ws.commons.remoteconfig.provider.noop.NoOpProvider;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.enterprise.inject.spi.CDI;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Factory for {@link RemoteProvider} implementations
 *
 * <p>Resolves active {@link RemoteProvider} implementation using configuration values and builds an instance
 * for it. This class uses CDI to get the instance when available, or native Java Reflection API as fallback to build
 * the instances.</p>
 *
 * <p>Provider identification is done using a set of static aliases or by fully qualified implementation class name.
 * Supported aliases are:</p>
 * <ul>
 *     <li>HTTP for {@link HttpProvider}</li>
 *     <li>GIT for {@link GitProvider}</li>
 *     <li>NOOP for {@link NoOpProvider}</li>
 * </ul>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
class RemoteProviderFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoteProviderFactory.class);
    private static final Map<String, Class<? extends RemoteProvider>> ALIASES;

    private final RemoteConfigConfig config;

    static {
        ALIASES = new HashMap<>();
        ALIASES.put("HTTP", HttpProvider.class);
        ALIASES.put("GIT", GitProvider.class);
        ALIASES.put("NOOP", NoOpProvider.class);
        ALIASES.put("CONFIGSERVER", ConfigServerProvider.class);
    }

    /**
     * CDI enabled constructor with {@link RemoteConfigConfig} initialization
     *
     * @param config Configuration object
     */
    @Inject
    RemoteProviderFactory(final RemoteConfigConfig config) {
        this.config = config;
    }

    /**
     * Detect active implementation and produce an instance
     *
     * @return Produced instance
     */
    RemoteProvider build() {
        LOGGER.debug("Begin production of a {} instance", RemoteProvider.class);

        final String providerClassName = config.getProvider();
        LOGGER.debug("Resolved implementation class is {}", providerClassName);

        final Class<? extends RemoteProvider> providerClass = getProviderClass(providerClassName);
        return produceInstance(providerClass);
    }

    /**
     * Validate and load the class using provided qualified name. This method only loads classes that implements the
     * {@link RemoteProvider}, throwing an exception otherwise.
     *
     * @param className Qualified implementation class name
     * @return Loaded class from provided name
     */
    private Class<? extends RemoteProvider> getProviderClass(final String className) {
        LOGGER.debug("Trying to identify target provider class from configuration value {}", className);

        if (ALIASES.containsKey(className.toUpperCase())) {
            final Class<? extends RemoteProvider> providerClass = ALIASES.get(className);
            LOGGER.debug("Using {} since {} is an alias to it", providerClass.getName(), className);
            return providerClass;
        }

        LOGGER.debug("Trying to load class using qualified name {}", className);

        final Class<?> clazz;
        try {
            clazz = Class.forName(className);
        } catch (final Exception ex) {
            throw new IllegalArgumentException("Supplied RemoteProvider implementation class not found using name " + className);
        }

        LOGGER.debug("Class {} available at classpath and loaded successfully", className);
        validateType(clazz);

        LOGGER.debug("Provider {} loaded successfully", className);
        return (Class<? extends RemoteProvider>) clazz;
    }

    /**
     * Validates if the provided class is a valid implementation of {@link RemoteProvider}. An exception is
     * thrown when validation fails.
     *
     * @param clazz Class to be validated
     */
    private void validateType(final Class<?> clazz) {
        LOGGER.debug("Validating if {} is a valid {} implementation", clazz.getName(), RemoteProvider.class.getName());
        if (RemoteProvider.class.equals(clazz) || !RemoteProvider.class.isAssignableFrom(clazz)) {
            throw new IllegalArgumentException("Class " + clazz.getName() + " isn't a valid " + RemoteProvider.class.getName() + " implementation");
        }
    }

    /**
     * Produce an instance of the given class. Production will be done using CDI when available or using
     * Java Reflection otherwise
     *
     * @param providerClass Provider implementation class
     * @return Produced instance
     */
    private RemoteProvider produceInstance(final Class<? extends RemoteProvider> providerClass) {
        LOGGER.debug("Producing a instance of {}", providerClass.getName());

        return produceWithCdi(providerClass)
                .orElseGet(() -> produceWithReflection(providerClass));
    }

    /**
     * Produce a {@link RemoteProvider} instance for the given class using CDI if available
     *
     * @param providerClass Provider implementation class to be produced
     * @return Produced instance
     */
    private Optional<RemoteProvider> produceWithCdi(final Class<? extends RemoteProvider> providerClass) {
        LOGGER.debug("Trying to produce an instance of {} using CDI", providerClass.getName());
        try {
            final RemoteProvider provider = CDI.current().select(providerClass).get();
            LOGGER.debug("Instance of {} produced successfully using CDI", providerClass.getName());
            return Optional.ofNullable(provider);
        } catch (final Exception ex) {
            LOGGER.warn("Error producing a instance of " + providerClass.getSimpleName() + " using CDI. Allowing application to continue.");
            return Optional.empty();
        }
    }

    /**
     * Produce a {@link RemoteProvider} instance for the given class using Java Reflection
     *
     * @param providerClass Provider implementation to be produced
     * @return Produced instance
     */
    private RemoteProvider produceWithReflection(final Class<? extends RemoteProvider> providerClass) {
        LOGGER.debug("Producing an instance of {} using Java Reflection", providerClass.getName());

        LOGGER.debug("Checking if a valid default constructor is available at {}", providerClass.getName());
        try {
            if (!Modifier.isPublic(providerClass.getConstructor().getModifiers())) {
                throw new IllegalArgumentException("Default constructor not accessible in " + providerClass.getName());
            }
        } catch (final NoSuchMethodException ex) {
            throw new IllegalArgumentException("No default constructor found at class " + providerClass.getName(), ex);
        }

        LOGGER.debug("Invoking instance creation using Java Reflection for {}", providerClass.getName());
        try {
            final RemoteProvider instance = providerClass.getConstructor().newInstance();
            LOGGER.debug("Instance of {} produced successfully using Reflection API", providerClass.getName());
            return instance;
        } catch (final Exception ex) {
            throw new RuntimeException("Failed producing " + providerClass.getName() + " instance", ex);
        }

    }
}
