package com.ws.commons.remoteconfig.adapter;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Objects;
import java.util.Optional;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.config.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Adapter factory class for configuration interfaces
 *
 * <p>This class produces dynamic proxy instance for simple, annotated configuration interfaces, allowing simple
 * reuse of configuration resolution logic on scenarios where CDI isn't available (and integrated solution of same
 * kind from Deltaspike isn't available).</p>
 *
 * <p>Any method call to instances produced with this class expects that the class has {@link Configuration}
 * annotation on the class and {@link ConfigProperty} on the called method. An error will be thrown when any of them
 * are missing.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-08
 */
public final class ConfigResolverAdapter {

    /**
     * Private default constructor
     */
    private ConfigResolverAdapter() {
    }

    /**
     * Internal Proxy {@link InvocationHandler} implementation
     *
     * <p>This class is responsible of the proxy method call interception and configuration resolution. All requests
     * will be forwarded to Deltaspike {@link ConfigResolver} to be completed.</p>
     *
     * <p>This class expects that {@link Configuration} and {@link ConfigProperty} are in place. If not, an
     * exception will be thrown.</p>
     */
    private static class ConfigResolveRequestHandler implements InvocationHandler {

        private static final Logger LOGGER = LoggerFactory.getLogger(ConfigResolveRequestHandler.class);

        /**
         * Executes the configuration resolution
         *
         * @param proxyInstance Proxy instance
         * @param method Called method
         * @param callArguments Call arguments
         * @return Resolved value
         * @throws IllegalArgumentException When {@link Configuration} or {@link ConfigProperty} is missing
         */
        @Override
        public Object invoke(final Object proxyInstance, final Method method, final Object[] callArguments) {
            LOGGER.debug("Configuration resolve request received on method {}", method.getName());

            final ConfigProperty configProperty = method.getAnnotation(ConfigProperty.class);
            final Configuration configuration = method.getDeclaringClass().getAnnotation(Configuration.class);

            if (configProperty == null) {
                throw new IllegalArgumentException("Missing ConfigProperty annotation from called method " + method.getName());
            }

            if (configuration == null) {
                throw new IllegalArgumentException("Missing Configuration annotation from interface " + method.getDeclaringClass().getName());
            }

            final String key = configuration.prefix() + configProperty.name();
            final String defaultValue = Optional
                    .of(configProperty.defaultValue())
                    .filter(value -> !value.equals(ConfigProperty.NULL))
                    .orElse(null);
            final Class<?> returnType = method.getReturnType();
            final ConfigResolver.Converter converter = Optional
                    .of(configProperty.converter())
                    .filter(clazz -> !clazz.equals(ConfigResolver.Converter.class))
                    .map(this::produceConverter)
                    .orElse(null);

            LOGGER.debug(
                    "Resolving configuration key {} with default value of {} as {} with {} converter",
                    key, defaultValue, returnType.getSimpleName(), converter
            );

            final ConfigResolver.TypedResolver<?> resolver = ConfigResolver
                    .resolve(key)
                    .as(returnType, converter)
                    .withCurrentProjectStage(configProperty.projectStageAware())
                    .evaluateVariables(configProperty.evaluateVariables());

            if (defaultValue != null) {
                resolver.withStringDefault(defaultValue);
            }

            return resolver.getValue();
        }

        /**
         * Produces a {@link org.apache.deltaspike.core.api.config.ConfigResolver.Converter} instance using reflection
         *
         * @param clazz Converter implementation class
         * @return Produced instance
         */
        private ConfigResolver.Converter produceConverter(final Class<? extends ConfigResolver.Converter> clazz) {
            LOGGER.debug("Producing an instance for {} converter", clazz.getName());

            try {
                return clazz.getConstructor().newInstance();
            } catch (final Exception ex) {
                throw new RuntimeException("Error producing converter instance for " + clazz.getName(), ex);
            }
        }
    }

    /**
     * Creates a dynamic proxy instance for the provided interface
     *
     * @param configurationInterface Configuration interface
     * @param <T> Generic type of the interface
     * @return Proxy instance for the interface
     */
    public static <T> T forInterface(final Class<T> configurationInterface) {
        Objects.requireNonNull(configurationInterface);

        LoggerFactory
                .getLogger(ConfigResolverAdapter.class)
                .debug("Producing proxy instance for {}", configurationInterface.getName());

        if (!configurationInterface.isInterface() || configurationInterface.getAnnotation(Configuration.class) == null) {
            throw new IllegalArgumentException("Provided class isn't a valid configuration interface");
        }

        return (T) Proxy.newProxyInstance(
                configurationInterface.getClassLoader(),
                new Class[] { configurationInterface },
                new ConfigResolveRequestHandler()
        );
    }

}
