package com.ws.commons.remoteconfig.provider.noop;

import com.ws.commons.remoteconfig.provider.RemoteProvider;
import java.util.Optional;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;

/**
 * Simple, default {@link RemoteProvider} implementation with NO-OP behaviour
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
public final class NoOpProvider implements RemoteProvider {

    /**
     * Resolves a configuration value using provided stage, key and service name
     *
     * @param projectStage Project current stage
     * @param serviceName Project name
     * @param configurationKey Configuration key
     * @return Resolved configuration value. Always return an empty {@link Optional}.
     */
    @Override
    public Optional<String> getValue(final ProjectStage projectStage,
                                     final String serviceName,
                                     final String serviceVersion,
                                     final String configurationKey) {
        return Optional.empty();
    }
}
