package com.ws.commons.remoteconfig.http;

import okhttp3.CacheControl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Simple utility class to invoke remote HTTP requests
 *
 * <p>This class handles all the HTTP related operations needed to fire a GET request to a remote host, returning the
 * raw response as a String object.</p>
 *
 * <p>Please note that this class expects a response to have status code 200 to be classified as a valid response. Also,
 * all {@link HttpRequestCustomizer} implementations will be called right before the request is invoked.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-12
 */
public final class HttpRequestFacade {

    private static final Integer HTTP_STATUS_OK = 200;
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpRequestFacade.class);
    private final List<HttpRequestCustomizer> customizers;

    /**
     * CDI enabled constructor with {@link HttpRequestCustomizer} initialization
     *
     * @param customizers CDI lazy inject access object for {@link HttpRequestCustomizer} implementations
     */
    @Inject
    public HttpRequestFacade(final @Any Instance<HttpRequestCustomizer> customizers) {
        this.customizers = StreamSupport.stream(customizers.spliterator(), false).collect(Collectors.toList());
    }

    /**
     * Constructor with {@link HttpRequestCustomizer}s initialization
     *
     * @param customizers HTTP request customizers
     */
    public HttpRequestFacade(final List<HttpRequestCustomizer> customizers) {
        this.customizers = customizers;
    }

    /**
     * Load configuration value using provided URL from remote server
     *
     * @param url URL to be requested
     * @param contentType Requested content type
     * @return Returned value
     */
    public Optional<String> loadFromRemote(final String url, final String contentType) {
        return loadFromRemote(url, contentType, null);
    }

    /**
     * Load configuration value using provided URL from remote server
     *
     * @param url URL to be requested
     * @param contentType Requested content type
     * @param requestCustomizer Optional request customizer
     * @return Returned value
     */
    public Optional<String> loadFromRemote(final String url,
                                           final String contentType,
                                           final Consumer<Request.Builder> requestCustomizer) {
        Objects.requireNonNull(contentType);

        final Request.Builder requestBuilder = new Request.Builder()
                .get()
                .url(url)
                .addHeader("Accept", contentType)
                .cacheControl(CacheControl.FORCE_NETWORK);

        if (requestCustomizer != null)
            requestCustomizer.accept(requestBuilder);

        final OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder()
                .retryOnConnectionFailure(true)
                .followRedirects(true)
                .followSslRedirects(true);

        customizers.forEach(customizer -> customizer.customize(requestBuilder, clientBuilder));

        final Request request = requestBuilder.build();
        final OkHttpClient client = clientBuilder.build();

        try {
            return Optional
                    .of(client.newCall(request).execute())
                    .filter(this::isResponseCodeValid)
                    .filter(response -> isContentTypeValid(response, contentType))
                    .map(this::getResponseBody);
        } catch (final Exception ex) {
            throw new RuntimeException("Error loading configuration value from remote URL: " + url, ex);
        }
    }

    /**
     * Extract the body content as String from provided {@link Response} object
     *
     * @param response Response
     * @return Body content
     */
    private String getResponseBody(final Response response) {
        try {
            return response.body().string();
        } catch (final IOException ex) {
            throw new RuntimeException("Error reading response body", ex);
        }
    }

    /**
     * Validates if status code from given {@link Response} is a valid status code
     *
     * @param response Response
     * @return Result of the validation, true being a valid status code
     */
    private boolean isResponseCodeValid(final Response response) {
        return response.code() == HTTP_STATUS_OK;
    }

    /**
     * Validates if content type from given {@link Response} is a valid, compatible content type
     *
     * @param response Response
     * @param expectedContentType Expected content type
     * @return Result of the validation, true being a compatible content type
     */
    private boolean isContentTypeValid(final Response response, final String expectedContentType) {
        final String responseType = response.header("Content-type");

        if (responseType == null) {
            LOGGER.warn("Remote HTTP repository replied without content-type header on URL {}", response.request().url().toString());
        }
        if (responseType != null && !responseType.startsWith(expectedContentType)) {
            throw new RuntimeException("Remote repository replied with unsupported content type: " + responseType);
        }

        return true;
    }

}
