package com.ws.commons.remoteconfig;

import com.ws.commons.remoteconfig.converter.TimeUnitConverter;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * Deltaspike configuration interface with properties for remote configuration API
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-08
 */
@Configuration
public interface RemoteConfigConfig {

    /**
     * @return Current service name.
     */
    @ConfigProperty(name = "service.name")
    String getServiceName();

    /**
     * @return Current service version.
     */
    @ConfigProperty(name = "service.version")
    String getServiceVersion();

    /**
     * @return Current service release.
     */
    @ConfigProperty(name = "service.release")
    String getServiceRelease();

    /**
     * @return The remote configuration provider to be used. Defaults to NOOP.
     */
    @ConfigProperty(name = "remoteconfig.provider", defaultValue = "NOOP")
    String getProvider();

    /**
     * @return The amount of units (defined in {@link #getCacheExpireUnit()}) to be used to cache values. When null the
     * cache is disabled. Defaults to 30.
     */
    @ConfigProperty(name = "cache.unitcount", defaultValue = "30")
    Long getCacheExpireCount();

    /**
     * @return The {@link TimeUnit} to be used in conjunction with {@link #getCacheExpireUnit()} to store configuration
     * properties under internal cache. When null the cache is disabled. Defaults to MINUTES.
     */
    @ConfigProperty(name = "cache.unit", defaultValue = "MINUTES", converter = TimeUnitConverter.class)
    TimeUnit getCacheExpireUnit();

}
