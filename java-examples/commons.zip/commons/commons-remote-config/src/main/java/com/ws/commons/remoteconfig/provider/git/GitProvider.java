package com.ws.commons.remoteconfig.provider.git;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import com.ws.commons.remoteconfig.adapter.ConfigResolverAdapter;
import com.ws.commons.remoteconfig.cache.CacheManager;
import com.ws.commons.remoteconfig.provider.RemoteProvider;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;
import java.util.Properties;

/**
 * {@link RemoteProvider} implementation that resolves values from a Git repository
 *
 * <p>This class implements the {@link RemoteProvider} resolving configuration values from a remote Git repository.
 * This class expects that the repository holds properties files (compatible with {@link java.util.Properties})
 * under the path of {@code /application-name/project-stage.properties}.</p>
 *
 * <p>Properties of the Git repository, like URL, branch and other are resolved using configuration values.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
@ApplicationScoped
public class GitProvider implements RemoteProvider {

    private final CacheManager cache;
    private final GitRepository repository;

    /**
     * Default constructor
     */
    public GitProvider() {
        final GitConfig gitConfig = ConfigResolverAdapter.forInterface(GitConfig.class);
        final RemoteConfigConfig apiConfig = ConfigResolverAdapter.forInterface(RemoteConfigConfig.class);

        // Resolution needs to be done eagerly to avoid resolution loops
        this.repository = new GitRepository(gitConfig, apiConfig);
        this.cache = new CacheManager(apiConfig);
    }

    /**
     * CDI enabled constructor
     *
     * @param repository Git repository
     */
    @Inject
    public GitProvider(final GitRepository repository, final CacheManager cache) {
        // Resolution needs to be done eagerly to avoid resolution loops
        this.repository = repository;
        this.cache = cache;
    }

    /**
     * Resolves a configuration value using provided stage, key and service name
     *
     * @param projectStage     Project current stage
     * @param serviceName      Project name
     * @param configurationKey Configuration key
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final ProjectStage projectStage,
                                     final String serviceName,
                                     final String serviceVersion,
                                     final String configurationKey) {

        final InternalKey key = new InternalKey(projectStage, serviceName, serviceVersion);
        final Properties properties = cache.retrieve(key, this::loadFromRepository);
        return Optional.ofNullable(properties.getProperty(configurationKey));
    }

    /**
     * Load a configuration value directly from Git repository
     *
     * @param key Details of the configuration to be loaded
     * @return Loaded value
     */
    private Properties loadFromRepository(final InternalKey key) {
        repository.requestPull();

        return repository
                .getProperties(key.getStage(), key.getServiceName(), key.getServiceVersion())
                .orElseGet(Properties::new);
    }
}
