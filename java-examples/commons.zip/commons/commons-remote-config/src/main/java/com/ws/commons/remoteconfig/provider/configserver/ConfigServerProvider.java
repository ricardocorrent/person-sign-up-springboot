package com.ws.commons.remoteconfig.provider.configserver;

import com.ws.commons.remoteconfig.cache.CacheManager;
import com.ws.commons.remoteconfig.provider.RemoteProvider;
import com.ws.commons.remoteconfig.util.PathBuilder;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

/**
 * {@link RemoteProvider} implementation for Spring Cloud Config Server
 *
 * <p>This class enables Deltaspike to resolve configuration values from a remote Config Server from Spring Cloud
 * stack.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-13
 */
@ApplicationScoped
public class ConfigServerProvider implements RemoteProvider {

    private static final String TEMPLATE_SERVICE_NAME_KEY = "{application}";
    private static final String TEMPLATE_STAGE_KEY = "{stage}";
    private static final String TEMPLATE_VERSION_KEY = "{version}";

    private final ConfigServerConfig configuration;
    private final CacheManager cacheManager;
    private final ConfigServerLoader loader;

    /**
     * CDI enabled constructor with configuration, cache and loader initialization
     *
     * @param configuration Configuration for Config Server
     * @param cacheManager Cache manager
     * @param loader Configuration loader from Config Server
     */
    @Inject
    public ConfigServerProvider(final ConfigServerConfig configuration,
                                final CacheManager cacheManager,
                                final ConfigServerLoader loader) {
        this.loader = loader;
        this.configuration = configuration;
        this.cacheManager = cacheManager;
    }

    /**
     * Resolves a configuration value using provided stage, key and service name
     *
     * @param projectStage Project current stage
     * @param serviceName Project name
     * @param serviceVersion Project API version
     * @param configurationKey Configuration key
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final ProjectStage projectStage,
                                     final String serviceName,
                                     final String serviceVersion,
                                     final String configurationKey) {
        final String url = buildUrl(serviceName, projectStage, serviceVersion);
        final ConfigurationDetails details = cacheManager.retrieve(url, loader::fromUrl);
        return getConfigurationValue(details, serviceName, projectStage.toString(), configurationKey);
    }

    /**
     * Walks the {@link ConfigurationDetails} tree retrieved from Config Server looking for the desired configuration value
     *
     * <p>This method walks under {@link ConfigurationDetails} object tree looking for the requested configuration
     * property. Search is done taking into account current project stage as the prioritary profile under received
     * values. In other words, this method will try to retrieve configuration value using the value present in the
     * profile for current stage, falling back to the default values when no option is found.</p>
     *
     * @param configurationValues Configuration values received from Config Server
     * @param serviceName Application name
     * @param projectStage Current project stage
     * @param targetKey Requested configuration key
     * @return Configuration value, if present
     */
    private Optional<String> getConfigurationValue(final ConfigurationDetails configurationValues,
                                                   final String serviceName,
                                                   final String projectStage,
                                                   final String targetKey) {
        final String prioritySourceKey = serviceName + "-" + projectStage;
        final Optional<ConfigurationSource> prioritySource = configurationValues
                .getPropertySources()
                .stream()
                .filter(item -> item.getName().equalsIgnoreCase(prioritySourceKey))
                .findAny();

        if (prioritySource.isPresent()) {
            final ConfigurationSource source = prioritySource.get();
            final Map<String, String> values = source.getSource();
            if (values.containsKey(targetKey)) {
                return Optional.ofNullable(values.get(targetKey));
            }
        }

        return configurationValues
                .getPropertySources()
                .stream()
                .flatMap(element -> element.getSource().entrySet().stream())
                .filter(element -> element.getKey().equals(targetKey))
                .map(Map.Entry::getValue)
                .findAny();
    }

    /**
     * Build and return the target URL to be used to connect with Config Server
     *
     * @param applicationName Name of the application
     * @param projectStage Deltaspike stage
     * @param applicationVersion Version of the application
     * @return Target URl to connect to
     */
    private String buildUrl(final String applicationName,
                            final ProjectStage projectStage,
                            final String applicationVersion) {

        final String path = new PathBuilder()
                .withTag(TEMPLATE_SERVICE_NAME_KEY, applicationName)
                .withTag(TEMPLATE_STAGE_KEY, projectStage.toString())
                .withTag(TEMPLATE_VERSION_KEY, applicationVersion)
                .build(configuration.getTemplate());

        return configuration.getUrl() + path;
    }

}
