package com.ws.commons.remoteconfig.converter;

import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.LoggerFactory;

/**
 * {@link org.apache.deltaspike.core.api.config.ConfigResolver.Converter} implementation for {@link TimeUnit} enumerations
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
public final class TimeUnitConverter implements ConfigResolver.Converter<TimeUnit> {

    /**
     * Returns the converted value of the configuration entry.
     *
     * @param value The String property value to convert
     * @return Converted value
     */
    @Override
    public TimeUnit convert(final String value) {
        LoggerFactory
                .getLogger(getClass())
                .debug("Converting {} to {}", value, TimeUnit.class.getName());

        return Optional
                .ofNullable(value)
                .map(String::toUpperCase)
                .map(TimeUnit::valueOf)
                .orElse(null);
    }
}
