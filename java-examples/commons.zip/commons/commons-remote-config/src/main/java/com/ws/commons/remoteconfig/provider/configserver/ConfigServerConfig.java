package com.ws.commons.remoteconfig.provider.configserver;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * Deltaspike configuration interface with properties for Spring Cloud Config Server remote config resolver
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-12
 */
@Configuration(prefix = "remoteconfig.configserver.")
interface ConfigServerConfig {

    /**
     * @return Username to be used when authentication is enabled
     */
    @ConfigProperty(name = "username")
    String getUsername();

    /**
     * @return Password to be used when authentication is enabled
     */
    @ConfigProperty(name = "password")
    String getPassword();

    /**
     * @return Token to be used when authentication is enabled
     */
    @ConfigProperty(name = "token")
    String getToken();

    /**
     * @return The authentication mode to be use to talk with Config Server. Defaults do "DISABLED".
     */
    @ConfigProperty(name = "authenticationmode", defaultValue = "DISABLED", converter = AuthenticationModeConverter.class)
    AuthenticationMode getAuthenticationMode();

    /**
     * @return The URL to be used to connect to the remote repository.
     */
    @ConfigProperty(name = "url")
    String getUrl();

    /**
     * @return The URL template to be used in resolution HTTP requests
     */
    @ConfigProperty(name = "template", defaultValue = "/{application}/{stage}/{version}")
    String getTemplate();
}
