package com.ws.commons.remoteconfig;

import java.util.Optional;
import org.slf4j.LoggerFactory;
import com.ws.commons.remoteconfig.RemoteConfigSource.State;

/**
 * {@link State} implementation for starting/initializing state
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
class StartingRemoteConfigSourceState implements State {

    /**
     * Executes the configuration resolution
     *
     * @param key Configuration key to be resolved
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final String key) {
        LoggerFactory
                .getLogger(getClass())
                .debug("Configuration resolution skipped for key {}. Resolver is not started yet.", key);

        return Optional.empty();
    }

    /**
     * Returns if current state requires initialization tasks to be started
     *
     * @return Initialization status
     */
    @Override
    public boolean isInitializationRequired() {
        return false;
    }
}
