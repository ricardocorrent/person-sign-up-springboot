package com.ws.commons.remoteconfig.provider.configserver;

import java.io.Serializable;
import java.util.Map;

/**
 * Spring Cloud Config Server configuration source response object
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-2-12
 */
class ConfigurationSource implements Serializable {

    private String name;
    private Map<String, String> source;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public Map<String, String> getSource() {
        return source;
    }

    public void setSource(final Map<String, String> source) {
        this.source = source;
    }
}
