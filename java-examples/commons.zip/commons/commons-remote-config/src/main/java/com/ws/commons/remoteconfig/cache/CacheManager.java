package com.ws.commons.remoteconfig.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ws.commons.remoteconfig.RemoteConfigConfig;

import javax.inject.Inject;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

/**
 * Simple in-memory cache utility class
 *
 * <p>This class provide a simple API to store and retrieve on-demand values using an in-memory volatile cache.</p>
 *
 * <p>All stored values expires automatically after the amount of time units set in configuration. Expire countdown
 * starts when the value is stored in the cache.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-12
 */
public final class CacheManager {

    private final Cache<Object, Object> delegate;

    /**
     * CDI enabled constructor with {@link RemoteConfigConfig} initialization
     *
     * @param configuration Remote configuration properties
     */
    @Inject
    public CacheManager(final RemoteConfigConfig configuration) {
        this.delegate = CacheBuilder
                .newBuilder()
                .expireAfterWrite(configuration.getCacheExpireCount(), configuration.getCacheExpireUnit())
                .build();
    }

    /**
     * Retrieve the value from cache and, if not present, loads it from the supplier function
     *
     * @param key Key to be retrieved from cache
     * @param supplier Supplier to be called when cache don't have the requested key
     * @param <R> Generic cache value type
     * @param <K> Generic cache key type
     * @return
     */
    public <R, K> R retrieve(final K key, final Function<K, R> supplier) {
        try {
            return (R) delegate.get(key, () -> supplier.apply(key));
        } catch (final ExecutionException ex) {
            throw new RuntimeException("Error retrieving value from in-memory cache", ex);
        }
    }

}
