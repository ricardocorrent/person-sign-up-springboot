package com.ws.commons.remoteconfig.provider.configserver;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * Apache Deltaspike {@link org.apache.deltaspike.core.api.config.ConfigResolver.Converter} implementation for
 * {@link AuthenticationMode} enumeration
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-12
 */
final class AuthenticationModeConverter implements ConfigResolver.Converter<AuthenticationMode> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationModeConverter.class);

    /**
     * Convert a String value to a {@link AuthenticationMode}
     *
     * @param value Value to be converted. Can be null.
     * @return Converted value
     */
    @Override
    public AuthenticationMode convert(final String value) {
        LOGGER.debug("Converting '{}' to '{}'", value, AuthenticationMode.class);

        return Optional
                .ofNullable(value)
                .map(String::toUpperCase)
                .map(AuthenticationMode::valueOf)
                .orElse(null);
    }
}
