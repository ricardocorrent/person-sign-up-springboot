package com.ws.commons.remoteconfig.provider.http;

import com.ws.commons.remoteconfig.RemoteConfigConfig;
import com.ws.commons.remoteconfig.adapter.ConfigResolverAdapter;
import com.ws.commons.remoteconfig.cache.CacheManager;
import com.ws.commons.remoteconfig.http.HttpRequestFacade;
import com.ws.commons.remoteconfig.provider.RemoteProvider;
import com.ws.commons.remoteconfig.util.PathBuilder;
import org.apache.commons.validator.routines.UrlValidator;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Collections;
import java.util.Optional;

/**
 * {@link RemoteProvider} implementation for HTTP based remote repositories
 *
 * <p>This class implements the {@link RemoteProvider} for HTTP based repositories using a request
 * template extracted from configuration values. Implementation expects that any HTTP response is a String value
 * without formatting ({@code text/plain}).</p>
 *
 * <p>Since a HTTP request can be slow, this class can use cache strategies to optimize the configuration resolution.
 * Cache duration and size can be customized using configuration values.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-03
 */
@ApplicationScoped
public class HttpProvider implements RemoteProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(HttpProvider.class);
    private static final String TEMPLATE_SERVICE_NAME_KEY = "{application}";
    private static final String TEMPLATE_STAGE_KEY = "{stage}";
    private static final String TEMPLATE_CONFIG_NAME_KEY = "{key}";

    private final HttpRequestFacade httpFacade;
    private final String mainUrl;
    private final String urlTemplate;
    private final CacheManager cache;

    /**
     * Default constructor
     */
    public HttpProvider() {
        final HttpConfig httpConfig = ConfigResolverAdapter.forInterface(HttpConfig.class);
        final RemoteConfigConfig apiConfig = ConfigResolverAdapter.forInterface(RemoteConfigConfig.class);

        // Resolution needs to be done eagerly to avoid resolution loops
        this.mainUrl = httpConfig.getUrl();
        this.urlTemplate = httpConfig.getTemplate();
        this.httpFacade = new HttpRequestFacade(Collections.emptyList());
        this.cache = new CacheManager(apiConfig);
    }

    /**
     * CDI enabled constructor
     *
     * @param config     HTTP configuration
     * @param httpFacade HTTP request customizers
     */
    @Inject
    public HttpProvider(final HttpConfig config, final HttpRequestFacade httpFacade, final CacheManager cache) {
        // Resolution needs to be done eagerly to avoid resolution loops
        this.mainUrl = config.getUrl();
        this.urlTemplate = config.getTemplate();
        this.httpFacade = httpFacade;
        this.cache = cache;
    }

    /**
     * Loads the configuration value from remote server using the provided URL
     *
     * @param url URL to be loaded
     * @return Repsonse from remote server
     */
    private Optional<String> loadFromRemote(final String url) {
        return httpFacade.loadFromRemote(url, "text/plain");
    }

    /**
     * Resolves a configuration value using provided stage, key and service name
     *
     * @param projectStage     Project current stage
     * @param serviceName      Project name
     * @param serviceVersion   Project API version
     * @param configurationKey Configuration key
     * @return Resolved configuration value
     */
    @Override
    public Optional<String> getValue(final ProjectStage projectStage,
                                     final String serviceName,
                                     final String serviceVersion,
                                     final String configurationKey) {

        final String urlTemplate = buildUrlTemplate();
        final String url = buildTargetUrl(urlTemplate, projectStage, serviceName, configurationKey);
        try {
            return cache.retrieve(url, this::loadFromRemote);
        } catch (final Exception ex) {
            LOGGER.warn("Error retrieving value from in-memory cache", ex);
            return Optional.empty();
        }
    }


    /**
     * Produces the target URL to be requested by replacing template tags with actual values when they are present
     *
     * @param template         URL template
     * @param projectStage     Project stage
     * @param serviceName      Service (application) name
     * @param configurationKey Configuration key
     * @return Target URL to be requested
     */
    private String buildTargetUrl(final String template,
                                  final ProjectStage projectStage,
                                  final String serviceName,
                                  final String configurationKey) {
        return new PathBuilder()
                .withTag(TEMPLATE_SERVICE_NAME_KEY, serviceName)
                .withTag(TEMPLATE_STAGE_KEY, projectStage.toString())
                .withTag(TEMPLATE_CONFIG_NAME_KEY, configurationKey)
                .build(template);
    }

    /**
     * Produces the URL template using values from Deltaspike configuration
     *
     * <p>This method retrieve configuration values from Deltaspike for URL and template to produce the base URL template
     * for future requests. If required values is missing from configuration a {@link RuntimeException} will be thrown.</p>
     *
     * <p>Please note that this method should only be called while the remote config API is initializing (or, in another
     * words, in constructor), or a {@link StackOverflowError} can be achieved.</p>
     *
     * @return URL template for future requests
     */
    private String buildUrlTemplate() {

        if (mainUrl == null) {
            throw new RuntimeException("No configuration value found for HTTP remote repository URL");
        }

        if (urlTemplate == null) {
            throw new RuntimeException("No configuration value found for HTTP remote repository template URL");
        }

        return Optional
                .of(mainUrl + urlTemplate)
                .filter(this::isUrlTemplateValid)
                .orElseThrow(() -> new IllegalArgumentException("HTTP URL for remote configuration repository is not a valid URL: " + mainUrl + urlTemplate));
    }

    /**
     * Validates if the provided URL template is valid
     *
     * @param urlTemplate URL template to be validated
     * @return Result of the validation
     */
    private boolean isUrlTemplateValid(final String urlTemplate) {
        final String testUrl = buildTargetUrl(urlTemplate, ProjectStage.SystemTest, "InternalTest", "test.config");
        return new UrlValidator(UrlValidator.ALLOW_LOCAL_URLS).isValid(testUrl);
    }

}
