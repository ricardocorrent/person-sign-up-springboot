package com.ws.commons.server.pagination;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Abstraction class of paged searches.
 *
 * <p>This class contains instructions of filtering and pagination for searches and it can be extended if a project
 * wants to use additional or custom filters to perform pagination searches.</p>
 *
 * <p><b>Please note that the usage of this class is not recommended, since the RestQuery implementation allows to reach
 * the same results more dynamically and with less verbosity.</b></p>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Diego Peliser
 * @author  Lucas Dillmann
 * @version 4.10.1 - 2017-07-05
 * @version 7.3.0 - 2018-08-15 - Deprecation of the class
 * @version 7.3.4 - 2018-09-28 - Removal of the deprecation
 * @since   1.1.0 - 2016-05-24
 */
public class PaginationSearch implements Serializable {

    public static final String FIRST_ROW       = "firstRow";
    public static final String PAGE_PARAM      = "page";
    public static final String PAGE_SIZE_PARAM = "pageSize";
    public static final String SELECT_PARAM    = "select";
    public static final String SORT_PARAM      = "sort";
    public static final int DEFAULT_PAGE       = 0;
    public static final int DEFAULT_PAGESIZE   = 500;
    public static final int MAX_PAGESIZE       = 5000;
    public static final PaginationSearch EMPTY_SEARCH  = new PaginationSearch(DEFAULT_PAGE, DEFAULT_PAGESIZE);

    /**
     * This field is used to set the first row to the query. <br><br>
     *
     * It is the
     * <a href="https://www.postgresql.org/docs/9.5/static/queries-limit.html">offset of PostgreSQL</a>.<br><br>
     *
     * The {@link PaginationSearch#page} also set the first row to the query, but it calculates the value
     * using {@link PaginationSearch#pageSize}.<br><br>
     *
     * This field will be set directly.<br><br>
     *
     * If both {@link PaginationSearch#firstRow} and {@link PaginationSearch#page} have values,
     * {@link PaginationSearch#page} will be used over {@link PaginationSearch#firstRow}.
     *
     * @since 6.0.0 - 2018-03-23
     */
    private Integer firstRow;

    private Integer page;

    private Integer pageSize;

    private List<Sort> sort;

    private String select;

    private String conditions;

    /**
     * Indicates if {@link PagedList#setCount(Integer)} must not be called.
     *
     * @see     <a href="https://redmineproduto.wssim.com.br/issues/42222">Task Redmine</a>
     * @since   6.0.0 - 2018-04-16
     */
    private Boolean noCount = Boolean.FALSE;

    public PaginationSearch() {}

    private PaginationSearch(final int page, final int pageSize) {
        this.page = page;
        this.pageSize = pageSize;
        this.sort = new ArrayList<>();
        this.select = StringUtils.EMPTY;
        this.conditions = StringUtils.EMPTY;
    }

    /**
     * Getter for property 'firstRow'.
     *
     * @return value for property 'firstRow'.
     */
    public Integer getFirstRow() {
        return firstRow;
    }

    /**
     * Setter for property 'firstRow'.
     *
     * @param firstRow value to set for property 'firstRow'.
     */
    public void setFirstRow(Integer firstRow) {
        this.firstRow = firstRow;
    }

    /**
     * Getter for property 'page'.
     *
     * @return value for property 'page'.
     */
    public Integer getPage() {
        return page;
    }

    /**
     * Setter for property 'page'.
     *
     * @param page value to set for property 'page'.
     */
    public void setPage(Integer page) {
        this.page = page;
    }

    /**
     * Getter for property 'pageSize'.
     *
     * @return value for property 'pageSize'.
     */
    public Integer getPageSize() {
        return pageSize;
    }

    /**
     * Setter for property 'pageSize'.
     *
     * @param pageSize value to set for property 'pageSize'.
     */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * Getter for property 'sort'.
     *
     * @return value for property 'sort'.
     */
    public List<Sort> getSort() {
        return sort;
    }

    /**
     * Setter for property 'sort'.
     *
     * @param sort value to set for property 'sort'.
     */
    public void setSort(List<Sort> sort) {
        this.sort = sort;
    }

    /**
     * Getter for property 'select'.
     *
     * @return value for property 'select'.
     */
    public String getSelect() {
        return select;
    }

    /**
     * Setter for property 'select'.
     *
     * @param select value to set for property 'select'.
     */
    public void setSelect(String select) {
        this.select = select;
    }

    /**
     * Getter for property 'conditions'.
     *
     * @return value for property 'conditions'.
     */
    public String getConditions() {
        return conditions;
    }

    /**
     * Setter for property 'conditions'.
     *
     * @param conditions value to set for property 'conditions'.
     */
    public void setConditions(String conditions) {
        this.conditions = conditions;
    }

    /**
     * Getter for property 'noCount'.
     *
     * @return value for property 'noCount'.
     */
    public Boolean getNoCount() {
        return noCount != null ? noCount : Boolean.FALSE;
    }

    /**
     * Setter for property 'noCount'.
     *
     * @param noCount value to set for property 'noCount'.
     */
    public void setNoCount(Boolean noCount) {
        this.noCount = noCount;
    }

}
