package com.ws.commons.server.pagination;

import java.io.Serializable;
import java.util.List;

/**
 * Entity responsible to store the result of {@link PaginationSearch} and RestQuery.
 *
 * <p>
 * {@link PagedList} class determines all related data and control of a paged result of data. It contains a {@link List}
 * of the result data and the parameters relative to the page data such as its {@code pageSize}, {@code firstRow}
 * and {@code page} which represents the current result page number.
 * </p>
 * <p>A {@link PagedList} can be retrieved trough persistence API, using DAO-related paged list methods.</p>
 *
 * @author  Sezar Thiago Caldeira
 * @since   1.1.0-SNAPSHOT - 23-02-2016
 */
@SuppressWarnings("javadoc")
public class PagedList<T> implements Serializable {

    private List<T> items;

    /**
     * Changed from int to {@link Integer}.
     *
     * @author  Diego Peliser
     * @see     <a href="https://redmineproduto.wssim.com.br/issues/42222">Task Redmine</a>
     * @since   6.0.0 - 2018-04-16
     */
    private Integer count;

    /**
     * This field represents the first row of the query.
     *
     * <p>It is the
     * <a href="https://www.postgresql.org/docs/9.5/static/queries-limit.html">offset of PostgreSQL</a>.</p>
     *
     * <p>The {@link PaginationSearch#setNoCount(Boolean)} ()} also set the first row to the query, but it calculates the value
     * using {@link PaginationSearch#getPageSize()}.</p>
     *
     * <p>This field will be set directly.</p>
     *
     * <p>Basically, you can work with {@code firstRow} OR {@code page}. The page field controls pagination automatically,
     * with {@code firstRow} you need to control manually.</p>
     *
     * @author  Diego Peliser
     * @since   6.0.0 - 2018-03-23
     */
    private Integer firstRow;

    private Integer page;

    private int pageSize;

    public PagedList() {}

    public PagedList(final List<T> items, final Integer count) {
        this(items, count, -1, -1);
    }

    public PagedList(final List<T> items, final Integer count, final Integer page, final int pageSize) {
        this(items, count, null, page, pageSize);
    }

    public PagedList(final List<T> items, final Integer count, final Integer firstRow, final Integer page,
                     final int pageSize) {
        this.items = items;
        this.count = count;
        this.firstRow = firstRow;
        this.page = page;
        this.pageSize = pageSize;
    }

    /**
     * Getter for property 'items'.
     *
     * @return value for property 'items'.
     */
    public List<T> getItems() {
        return items;
    }

    /**
     * Setter for property 'items'.
     *
     * @param items value to set for property 'items'.
     */
    public void setItems(List<T> items) {
        this.items = items;
    }

    /**
     * Getter for property 'count'.
     *
     * @return value for property 'count'.
     */
    public Integer getCount() {
        return count;
    }

    /**
     * Setter for property 'count'.
     *
     * @param count value to set for property 'count'.
     */
    public void setCount(Integer count) {
        this.count = count;
    }

    /**
     * Getter for property 'firstRow'.
     *
     * @return value for property 'firstRow'.
     */
    public Integer getFirstRow() {
        return firstRow;
    }

    /**
     * Setter for property 'firstRow'.
     *
     * @param firstRow value to set for property 'firstRow'.
     */
    public void setFirstRow(Integer firstRow) {
        this.firstRow = firstRow;
    }

    /**
     * Getter for property 'page'.
     *
     * @return value for property 'page'.
     */
    public Integer getPage() {
        return page;
    }

    /**
     * Setter for property 'page'.
     *
     * @param page value to set for property 'page'.
     */
    public void setPage(Integer page) {
        this.page = page;
    }

    /**
     * Getter for property 'pageSize'.
     *
     * @return value for property 'pageSize'.
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * Setter for property 'pageSize'.
     *
     * @param pageSize value to set for property 'pageSize'.
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

}
