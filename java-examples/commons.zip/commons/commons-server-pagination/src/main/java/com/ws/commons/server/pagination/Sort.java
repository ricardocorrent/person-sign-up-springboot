package com.ws.commons.server.pagination;

import java.io.Serializable;

/**
 * This class is responsible to store ordering instructions and direction for the fields that are searched through a
 * {@link PaginationSearch}.
 *
 * @author  Sezar Thiago Caldeira
 * @since   2016-02-23
 */
public class Sort implements Serializable{

    private String dir;

    private String field;

    public Sort() {
    }

    public Sort(String field, String dir) {
        this.field = field;
        this.dir = dir;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    @Override
    public String toString() {
        StringBuilder sortString = new StringBuilder();
        sortString.append(field);
        if (dir != null) {
            sortString.append(' ').append(dir);
        }
        return sortString.toString();
    }
}
