package com.ws.commons.server.pagination;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sollar.test.BaseUnitTest;
import com.ws.commons.server.json.ObjectMapperResolver;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;

import static org.junit.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

/**
 *
 * Simple unit test class to test {@link PaginationSearch}.
 *
 * @author  Thyago Volpatto
 * @since   6.0.0 - 2018-02-06
 */
@RunWith(PowerMockRunner.class)
public class PaginationSearchUnitTest extends BaseUnitTest {

    /**
     * Test if the classes {@link PaginationSearch} and {@link Sort} implements {@link Serializable}.
     */
    @Test
    public void verifyPaginationSearchAndSortImplementsSerializable() throws IOException {
        assertTrue(Serializable.class.isAssignableFrom(PaginationSearch.class));
        assertTrue(Serializable.class.isAssignableFrom(Sort.class));

    }

    /**
     * Test if a {@link PaginationSearch} object can be serialized.
     */
    @Test
    public void serializePaginationSearchWithoutErrors() throws IOException {
        final ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();
        final String serializedPaginationSearch = mapper.writeValueAsString(createPaginationSearchObject());

        final PaginationSearch deserializedPaginationSearch = mapper.readValue(serializedPaginationSearch, PaginationSearch.class);
        assertNotNull(deserializedPaginationSearch);

    }

    /**
     * Test if all {@link PaginationSearch} constructor creates the object
     * where {@link PaginationSearch#getNoCount()} is false.
     */
    @Test
    public void allConstructorSetWithCountToFalse() {
        assertFalse(new PaginationSearch().getNoCount());
        assertFalse(PaginationSearch.EMPTY_SEARCH.getNoCount());
    }

    private PaginationSearch createPaginationSearchObject(){
        final PaginationSearch paginationSearch = new PaginationSearch();
        final Sort sort = new Sort("description", "ASC");

        paginationSearch.setPage(PaginationSearch.DEFAULT_PAGE);
        paginationSearch.setPageSize(PaginationSearch.DEFAULT_PAGESIZE);
        paginationSearch.setSort(Collections.singletonList(sort));

        return paginationSearch;
    }
}
