package br.com.wealthsystems.commons.quartz.scheduling.artifact;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;

/**
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-25
 */
@SuppressWarnings("javadoc")
public class TestLoggerJobExecution {

    private final Logger logger = LoggerFactory.getLogger(TestLoggerJobExecution.class);
    
    public void logExecution() {
        this.logger.info(MarkerFactory.getMarker("QUARTZ"), " Job executed successfully.\n");
    }
}
