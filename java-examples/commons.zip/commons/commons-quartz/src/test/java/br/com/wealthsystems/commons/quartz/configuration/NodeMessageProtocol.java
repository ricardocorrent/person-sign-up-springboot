package br.com.wealthsystems.commons.quartz.configuration;

import org.quartz.Scheduler;

import java.io.Serializable;

/**
 * Provides a communication protocol between nodes of the Quartz test cluster.
 *
 * @author  Diego A. Costa
 * @see     TestSchedulerCluster#buildNewMessage(Scheduler, NodeMessage)
 * @see     NodeMessage
 * @since   6.1.0 - 2018-07-05
 */
public class NodeMessageProtocol implements Serializable {

    private static final long serialVersionUID = 1L;

    private String scheduleInstanceId;
    
    private NodeMessage nodeMessage;

    /**
     * @return the {@link Scheduler} instance ID.
     */
    public String getScheduleInstanceId() {
        return scheduleInstanceId;
    }

    /**
     * @param scheduleInstanceId the {@link Scheduler} instance ID.
     */
    public void setScheduleInstanceId(final String scheduleInstanceId) {
        this.scheduleInstanceId = scheduleInstanceId;
    }

    /**
     * @return the node message.
     */
    public NodeMessage getNodeMessage() {
        return nodeMessage;
    }

    /**
     * @param nodeMessage the node message.
     */
    public void setNodeMessage(final NodeMessage nodeMessage) {
        this.nodeMessage = nodeMessage;
    }
}
