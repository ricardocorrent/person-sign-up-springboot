package br.com.wealthsystems.commons.quartz.configuration;

import org.quartz.Scheduler;

/**
 * Provides communication messages between nodes of the Quartz test cluster.
 *
 * @author  Diego A. Costa
 * @see     TestSchedulerCluster#buildNewMessage(Scheduler, NodeMessage)
 * @since   6.1.0 - 2018-07-05
 */
public enum NodeMessage {

    /**
     * Signals that a node has started successfully.
     */
    NODE_STARTED,
    
    /**
     * Indicates that a node was declined and will not 
     * be present in the cluster because the node limit 
     * has already been reached.
     */
    NODE_REFUSED,
    
    /**
     * Signals that the cluster is complete and all nodes 
     * have already been initialized.
     */
    CLUSTER_COMPLETED,
    
    /**
     * It signals that the cluster is incomplete and is 
     * still waiting for other nodes to boot.
     */
    CLUSTER_INCOMPLETE,
    
    /**
     * Cluster state request message. Possible states are 
     * {@link #CLUSTER_COMPLETED} and {@link #CLUSTER_INCOMPLETE}.
     */
    CLUSTER_STATUS;
}
