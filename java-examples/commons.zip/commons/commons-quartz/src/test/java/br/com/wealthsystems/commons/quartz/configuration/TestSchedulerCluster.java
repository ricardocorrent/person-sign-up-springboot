package br.com.wealthsystems.commons.quartz.configuration;

import br.com.wealthsystems.commons.quartz.scheduling.artifact.TestDataBaseJob;
import com.ws.commons.utils.ArrayUtils;
import com.ws.commons.utils.reflection.packages.PackageReflectionHelper;
import org.jboss.weld.exceptions.IllegalArgumentException;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ProcessBuilder.Redirect;
import java.net.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

/**
 * Provides a simple way to start a new QUARTZ node. 
 *
 * <p>The node starts with only one {@link Job} configured on only one {@link Trigger}, each registered in
 * {@link Scheduler} with a specific identification.</p>
 *
 * <p>Consider reading the Quartz documentation for clusters. Here's an important snippet of this documentation:</p>
 * "<em>The clustering feature works best for scaling out long-running and/or cpu-intensive jobs
 * (distributing the work-load over multiple nodes). If you need to scale out to support thousands of short-running
 * (e.g 1 second) jobs, consider partitioning the set of jobs by using multiple distinct schedulers
 * (including multiple clustered schedulers for HA). The scheduler makes use of a cluster-wide lock, a pattern that
 * degrades performance as you add more nodes (when going beyond about three nodes - depending upon your database’s
 * capabilities, etc.).</em>"</p>
 *
 * <p>>Each cluster node must be coordinated by a witness service, which must be started together with the cluster nodes.</p>
 *
 * <p>Check the documentation for the constants:</p>
 * <ul>
 * <li>{@link #NODE_LIFE_TIME_SECONDS}</li>
 * <li>{@link #WITNESS_TIME_OUT_MILLIS}</li>
 * <li>{@link #NODE_TIME_OUT_MILLIS}</li>
 * <li>And others...</li>
 * </ul>
 *
 * <b><em>Example:</em></b>
 * <pre><code>
 *  {@literal @}Test
 *  public void howToDoQuartzClusterTestCase() {
 *      final int clusterNodes = 5;
 *      
 *      try {
 *          for (int i = 0; i &lt; clusterNodes; i++) {
 *              TestSchedulerCluster.startNewNode(WITNESS_PORT, EBEAN_AGENT_ARGUMENT);
 *              sleepSeconds(1);
 *          }
 *      
 *          TestSchedulerCluster.startWitness(clusterNodes, WITNESS_PORT);
 *          
 *          {@literal /}*Do your things here*{@literal /}
 *          
 *          TestSchedulerCluster.destroyAll();
 *      } catch (final Exception exception) {
 *          exception.printStackTrace();
 *          fail(exception.getMessage());
 *      }
 *  }
 * </code></pre>
 *
 * @author  Diego A. Costa
 * @see     <a href="http://www.quartz-scheduler.org/documentation/quartz-2.2.x/configuration/ConfigJDBCJobStoreClustering.html">
 *          Cluster DOC reference
 *          </a>
 * @since   6.1.0 - 2018-06-26
 */
public class TestSchedulerCluster {
    
    private static final String LOCAL_HOST_IP = "127.0.0.1";
    private static final String SCHEDULER_NODE_MARKER = TestSchedulerCluster.class.getSimpleName();
    private static final Logger LOGGER = LoggerFactory.getLogger(TestSchedulerCluster.class);
    private static final List<Process> NODES = new ArrayList<>();
    private static final Map<Process, Throwable> NODE_EXCEPTIONS = new HashMap<>();
    private static final Map<String, Boolean> CLUSTER = new HashMap<>();
    private static final String CLASSPATH_ARGUMENT = "-cp";
    private static final String JAVA_COMMAND_LINE = "java";
    private static final String FILE_PATH_SEPARATOR = File.pathSeparator;
    
    /**
     * Class containing the {@link Job} implementation.<br>
     * Default value: "TestDataBaseJob.class"
     * @see TestDataBaseJob
     */
    public static final Class<TestDataBaseJob> JOB_CLASS = TestDataBaseJob.class;
    
    /**
     * Default value: "0/6 * * ? * * *"
     *
     * @see CronExpression
     * @see CronScheduleBuilder
     */
    public static final String CRON_EXPRESSION = "0/6 * * ? * * *";
    
    /**
     * @see JobDetail
     * @see JobBuilder
     */
    public static JobDetail JOB_DETAIL;

    /**
     * @see Trigger
     * @see TriggerBuilder
     */
    public static Trigger TRIGGER;
    
    /**
     * Job name as identification.
     * @see JobKey
     */
    public static String JOB_KEY = "concurrentJobTest";
    
    /**
     * Trigger name as identification.
     * @see TriggerKey
     */
    public static String TRIGGER_KEY = "concurrentTriggerTest";
    
    /**
     * Maximum time the witness will wait for the cluster to form.
     */
    public static long WITNESS_TIME_OUT_MILLIS = 40000;
    
    /**
     * Time decoded while the witness waits for cluster formation. 
     * This value is updated only when some node communicates with the witness.
     */
    private static long WITNESS_TIME_ELAPSED_MILLIS;
    
    /**
     * Maximum time the witness will wait for the node to connect. 
     * It also determines the maximum time a node waits for the connection to the witness.
     */
    public static int NODE_TIME_OUT_MILLIS = 40000;
    
    /**
     * Maximum time the node will remain online, until it is automatically shut down.
     */
    public static final int NODE_LIFE_TIME_SECONDS = 55;
    
    /**
     * Starts a new {@link Scheduler} with only one Job configured 
     * on only one Trigger. The Scheduler will be shutdown after 
     * {@value #NODE_LIFE_TIME_SECONDS} seconds.
     *
     * @param args                      the command line arguments
     *                                  The witness service is expected to be the first argument
     * @throws InterruptedException     if thread management fails
     * @throws IllegalArgumentException if the witness service port number is invalid or null
     */
    public static void main(final String[] args) throws InterruptedException {
        final long start = System.currentTimeMillis();
        
        LOGGER.info(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Starting Scheduler.");
        
        TestSchedulerCluster.scheduleJob(getValidPort(args[0]));
        
        final long elapsed = (System.currentTimeMillis() - start) / 1000;
        
        LOGGER.info(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Scheduler started successfully in " + elapsed + " millis.");
        
        shutdownAfterTimeOut();
    }

    private static int getValidPort(final String port) {
        try {
            int intPort = Integer.parseInt(port);
            
            if (intPort < 1 || intPort > 65535) {
                throw new IllegalArgumentException("The port number of the witness service is invalid.");
            }
            
            return intPort;
        } catch (final NumberFormatException nfe) {
            nfe.printStackTrace();
            
            throw new IllegalArgumentException("The port number of the witness service is invalid.", nfe);
        }
    }
    
    /**
     * @see Scheduler#scheduleJob(JobDetail, Trigger)
     */
    private static void scheduleJob(final int port) {
        try {
            final Scheduler scheduler = getScheduler();

            startScheduleIfIsIdle(scheduler);
            
            boolean wasCreated = reuseOrCreateJobAndTriggerIfNotExist(scheduler);
            
            scheduleOrResumeJobAndTrigger(scheduler, wasCreated);
            
            publishToWitness(port, buildNewMessage(scheduler, NodeMessage.NODE_STARTED));
        } catch (final SchedulerException | IOException exception) {
            exception.printStackTrace();
        }
    }

    private static Scheduler getScheduler() throws SchedulerException {
        return StdSchedulerFactory.getDefaultScheduler();
    }
    
    private static void startScheduleIfIsIdle(final Scheduler scheduler) throws SchedulerException {
        if (!scheduler.isStarted()) {
            scheduler.start();
        }
    }

    private static void scheduleOrResumeJobAndTrigger(final Scheduler scheduler, boolean wasCreated) throws SchedulerException {
        if (wasCreated) {
            scheduler.scheduleJob(JOB_DETAIL, TRIGGER);
        } else {
            scheduler.resumeJob(JobKey.jobKey(JOB_KEY));
            
            scheduler.resumeTrigger(TriggerKey.triggerKey(TRIGGER_KEY));
        }
    }
    
    private static void publishToWitness(final int port, final NodeMessageProtocol protocol) throws UnknownHostException, IOException {
        try (final Socket client = new Socket()) {
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Client connecting on server...");
            
            client.connect(new InetSocketAddress(LOCAL_HOST_IP, port), NODE_TIME_OUT_MILLIS);
            
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Client connected on server...");
            
            try (final ObjectOutputStream objectOutputStream = new ObjectOutputStream(client.getOutputStream())) {
                LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Client writing on server...");

                objectOutputStream.writeObject(protocol);
                
                objectOutputStream.flush();
            }
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Client connection lifecycle done...");
        }
    }
    
    private static void sleepSeconds(int seconds) throws InterruptedException {
        Thread.sleep(seconds * 1000);
    }
    
    /**
     * @param scheduler the scheduler from which JobDetail will be retrieved
     * @return          {@code true} if the JobDetail was created, false otherwise
     */
    private static boolean reuseOrCreateJobAndTriggerIfNotExist(final Scheduler scheduler) {
        reuseJobIfExists(scheduler);
        
        boolean shouldBeCreated = JOB_DETAIL == null;
        
        createJobIfNotExists();
        
        reuseTriggerIfExist(scheduler);
        
        createTriggerIfNotExist();
        
        return shouldBeCreated;
    }

    private static void reuseJobIfExists(final Scheduler scheduler) {
        if (JOB_DETAIL == null) {
            try {
                JOB_DETAIL = scheduler.getJobDetail(JobKey.jobKey(JOB_KEY));
            } catch (final SchedulerException e) {
                e.printStackTrace();
            }
        }
    }

    private static void createJobIfNotExists() {
        if (JOB_DETAIL == null) {
            createJob();
        }
    }
    
    private static void reuseTriggerIfExist(final Scheduler scheduler) {
        if (TRIGGER == null) {
            try {
                TRIGGER = scheduler.getTrigger(TriggerKey.triggerKey(TRIGGER_KEY));
            } catch (final SchedulerException e) {
                e.printStackTrace();
            }
        }
    }
    
    private static void createTriggerIfNotExist() {
        if (TRIGGER == null) {
            createTrigger();
        }
    }

    private static void createJob() {
        JOB_DETAIL = newJob(JOB_CLASS)
                .withIdentity(JOB_KEY)
                .build();
    }

    private static void createTrigger() {
        TRIGGER = newTrigger()
                .withSchedule(cronSchedule(CRON_EXPRESSION)
                        .withMisfireHandlingInstructionIgnoreMisfires())
                .withIdentity(TRIGGER_KEY)
                .build();
    }
    
    /**
     * Shutdowns after {@value #NODE_LIFE_TIME_SECONDS} seconds.
     */
    private static void shutdownAfterTimeOut() throws InterruptedException {
        sleepSeconds(NODE_LIFE_TIME_SECONDS);
        System.exit(0);
    }
    
    /**
     * Starts a Socket-based service to coordinate the startup of the nodes that make up the cluster.<br>
     *
     * <b>WARNING:</b> <em>Starts the witness only after started all nodes.</em><br>
     *
     * Example: {@link TestSchedulerCluster}<br>
     * The witness service is intended to queue the startup of the cluster nodes, 
     * and upon completion of all startup, this witness service terminates.
     *
     * @param nodes                     the nodes that will compose the cluster
     * @param port                      the port of the witness service
     * @throws IOException              if the initialization of the witness service fails
     * @throws ClassNotFoundException   if node communication fails.
     * @see                             #startNewNode(int, String...)
     */
    public static void startWitness(final Integer nodes, final int port) throws IOException, ClassNotFoundException {
        throwExceptionIfThereIsNoNodes(nodes);
        
        LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Starting server...");
        
        try (final ServerSocket server = new ServerSocket(port)) {
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Server started.");
            LOGGER.info(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Cluster witness is ready and listening messages.");
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Server listening nodes...");
            
            listenNodes(nodes, server);
            
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Nodes completed.");
            
            throwExceptionIfIsIvalidClusterAndTimeOut(nodes);
            
            LOGGER.info(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Cluster started successfully with " + nodes + " node(s).");
        } 
    }

    private static void throwExceptionIfThereIsNoNodes(final Integer nodes) {
        final String invalidNumberNodes = "The witness must start for a cluster composed of one or more nodes.";
        
        Objects.requireNonNull(nodes, invalidNumberNodes);
        
        if (nodes.intValue() <= 0) {
            throw new IllegalArgumentException(invalidNumberNodes);
        }
    }
    
    private static void listenNodes(final Integer nodes, final ServerSocket server)
            throws SocketException, IOException, ClassNotFoundException {
        final long startedAt = System.currentTimeMillis();
        
        while(getWitnessTimeElapsed(startedAt) <= WITNESS_TIME_OUT_MILLIS && CLUSTER.size() != nodes.intValue()) {
            server.setSoTimeout(NODE_TIME_OUT_MILLIS);
            
            LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Server listening one node...");
            
            try (final Socket client = server.accept()) {
                LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Server connected with one node and reading...");
                
                final NodeMessageProtocol protocol = readProtocol(client);
                
                if (NodeMessage.NODE_STARTED == protocol.getNodeMessage()) {
                    CLUSTER.put(protocol.getScheduleInstanceId(), Boolean.TRUE);
                    
                    client.close();
                }
                
                LOGGER.debug(MarkerFactory.getMarker(SCHEDULER_NODE_MARKER), "Server endind node...");
            }
        }
    }
    
    private static void throwExceptionIfIsIvalidClusterAndTimeOut(final Integer nodes) {
        if (CLUSTER.size() != nodes.intValue() && WITNESS_TIME_ELAPSED_MILLIS > WITNESS_TIME_OUT_MILLIS) {
            throw new IllegalStateException("Time Out:\nThe witness has reached the time limit ("+ WITNESS_TIME_OUT_MILLIS +") to listen for the initialization of the nodes.");
        }
    }
    
    private static long getWitnessTimeElapsed(final long startedAt) {
        return WITNESS_TIME_ELAPSED_MILLIS = System.currentTimeMillis() - startedAt;
    }
    
    /**
     * @param socket                    the client from wich will be received the protocol.
     * @return                          a new protocol instance.
     * @throws IOException              if the client has no input stream.
     * @throws ClassNotFoundException   if the object coming from the
     *                                  client can not be casted to {@link NodeMessageProtocol}.
     */
    private static NodeMessageProtocol readProtocol(final Socket socket) throws IOException, ClassNotFoundException {
        try (final ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream())) {
            return NodeMessageProtocol.class.cast(objectInputStream.readObject());
        }
    }

    /**
     * @param scheduler             the scheduler from which the message will be sent.
     * @param nodeMessage           the message that will be sent.
     * @return                      a new protocol instance containing the new message.
     * @throws SchedulerException   if the scheduler instance ID is not be obtained.
     */
    public static NodeMessageProtocol buildNewMessage(
            final Scheduler scheduler, 
            final NodeMessage nodeMessage) throws SchedulerException {
        final NodeMessageProtocol nodeMessageProtocol = new NodeMessageProtocol();
        
        nodeMessageProtocol.setScheduleInstanceId(scheduler.getSchedulerInstanceId());
        nodeMessageProtocol.setNodeMessage(nodeMessage);
        
        return nodeMessageProtocol;
    }

    /**
     * Starts a new Scheduler node with only one Job configured 
     * on only one Trigger. The execution CLASSPATH of the 
     * Scheduler node will be the same as the thread in which 
     * execution is started.<br>
     * Example: {@link TestSchedulerCluster}
     *
     * @param witnessPort   the port of the witness service.
     * @param args          the arguments to compose the java line command. <em>They are not arguments of class execution.</em>
     * @return              a process under which the Scheduler node is running.
     * @see                 #startWitness(Integer, int)
     * @see                 #JOB_CLASS
     */
    public static Process startNewNode(final int witnessPort, final String... args) {
        final String[] lineCommand = generateLineCommand(witnessPort, args);
        
        final ProcessBuilder builder = generateAndConfigureProcessBuilder(lineCommand);
        
        try {
            final Process process = builder.start();
            
            NODES.add(process);
            
            return process;
        } catch (final IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private static String[] generateLineCommand(final int witnessPort, final String... args) {
        final String mainClass = TestSchedulerCluster.class.getName();

        final String classPathValue = getClassPath();
        
        final List<String> lineCommand = new LinkedList<>();
        
        lineCommand.add(JAVA_COMMAND_LINE);
        lineCommand.add(CLASSPATH_ARGUMENT);
        lineCommand.add(classPathValue);
        
        if (ArrayUtils.isNotEmpty(args)) {
            lineCommand.addAll(Arrays.asList(args));
        }
        
        lineCommand.add(mainClass);
        lineCommand.add(String.valueOf(witnessPort));
        
        return lineCommand.toArray(new String[0]);
    }
    
    private static String getClassPath() {
        final URL[] urls = URLClassLoader.class.cast(Thread.currentThread().getContextClassLoader()).getURLs();
        
        return Stream.<URL>of(urls).map(URL::getPath).collect(Collectors.joining(FILE_PATH_SEPARATOR));
    }
    
    private static ProcessBuilder generateAndConfigureProcessBuilder(final String[] lineCommand) {
        final String directory = PackageReflectionHelper
                .fromPackage(TestSchedulerCluster.class.getPackage()).getRootPath();
        
        final ProcessBuilder builder = new ProcessBuilder(lineCommand);
        
        builder.redirectErrorStream(true);
        builder.redirectOutput(Redirect.INHERIT);
        builder.directory(new File(directory));
        
        return builder;
    }

    /**
     * @return  the started nodes.
     * @see     #startNewNode(int, String...)
     */
    public static List<Process> getNodes() {
        return Collections.unmodifiableList(NODES);
    }
    
    /**
     * Destroys forcibly all the started nodes and waits for conclusion of each one of them.
     * The destroyed nodes will be eligible for garbage collector and will not be accessible anymore.
     * If any exceptions occur, they will be printed to the console and stored in a Map, using the node as the key.
     *
     * @see Process#destroyForcibly()
     * @see #getNodeExceptions()
     */
    public static void destroyAll() {
        NODES.removeIf(n -> {
            try {
                n.destroyForcibly();
                
                n.waitFor();
                
                NODE_EXCEPTIONS.remove(n);
                
                return true;
            } catch (final InterruptedException e) {
                e.printStackTrace();
                
                NODE_EXCEPTIONS.put(n, e);
                
                return false;
            }
        });
    }
    
    /**
     * @return the node exceptions
     * @see #destroyAll()
     */
    public static Map<Process, Throwable> getNodeExceptions() {
        return Collections.unmodifiableMap(NODE_EXCEPTIONS);
    }
}
