package br.com.wealthsystems.commons.quartz.scheduling;

import br.com.wealthsystems.commons.quartz.configuration.QuartzPropertyLocator;
import br.com.wealthsystems.commons.quartz.configuration.TestProperties;
import br.com.wealthsystems.commons.quartz.configuration.TestSchedulerCluster;
import br.com.wealthsystems.commons.quartz.scheduling.artifact.FakeEntity;
import br.com.wealthsystems.commons.quartz.scheduling.artifact.TestDataBaseJobExecution;
import br.com.wealthsystems.commons.quartz.util.QuartzClusterUtil;
import org.apache.commons.lang3.StringUtils;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.*;

/**
 * Scheduling unit test cases.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-22
 */
@Ignore("Execution only for changing versions of the Quartz lib")
public class SchedulingUnitTest {
    
    private static final int WITNESS_PORT = 43210;
    private static final String EBEAN_AGENT_ARGUMENT;
    private static QuartzClusterUtil QUARTZ_CLUSTER_UTIL;
    private static QuartzPropertyLocator QUARTZ_PROPERTY_LOCATOR;
    
    static {
        /*
         * The EBEAN_AGENT_ARGUMENT consists of the "-javaagent:" argument 
         * concatenated with the JAR "ebean-agent-11.11.1.jar" path, which 
         * is obtained as a resource through the ContextClassLoader. The 
         * ContextClassLoader returns the path starting with a "/", which 
         * must be removed, depending on the substring function below.
         * */
        EBEAN_AGENT_ARGUMENT = StringUtils.join(
                "-javaagent:", 
                Thread.currentThread()
                        .getContextClassLoader()
                                .getResource("ebean-agent-11.11.1.jar")
                                        .getPath().substring(1));
        
        try {
            QUARTZ_PROPERTY_LOCATOR = new QuartzPropertyLocator();
            
            QUARTZ_CLUSTER_UTIL = QuartzClusterUtil.fromQuartzPropertyLocator(QUARTZ_PROPERTY_LOCATOR);
            
            QUARTZ_CLUSTER_UTIL.createQuartzTables();
        } catch (final ClassNotFoundException | SQLException | IOException exception) {
            exception.printStackTrace();
            
            fail(exception.getMessage());
        } 
    }
    
    /**
     * Creates the Quartz tables in database.
     */
    @BeforeClass
    public static void beforeClass() {
        try {
            final Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();

            scheduler.clear();
            
            if (!scheduler.isShutdown()) {
                scheduler.shutdown();
            }
        } catch (final SchedulerException e) {
            e.printStackTrace();
            
            fail(e.getMessage());
        }
    }
    
    /**
     * Creates the Ebean server.
     */
    public SchedulingUnitTest() {
        TestDataBaseJobExecution.createEbeanServer(true);
    }

    /**
     * The test was constructed to simulate a clustered environment 
     * composed of 5 nodes. The purpose of this test is to ensure that 
     * the same task, registered on all cluster nodes, runs only once, 
     * by only one cluster node, for each stipulated time frame.
     * Example: A single task has been created to run within 6 seconds, 
     * and every 6 seconds it will run again. Given this configuration, 
     * while one of the nodes executes the task, the others must be 
     * prevented from performing the task. After completion of the 
     * execution, all nodes in the clusters will be able to perform 
     * the task again.
     */
    @Test
    public void onlyOneNodeRunsTheSameJobThatIsRegisteredOnANodeCluster() {
        try {
            startClusterNodes(5);
            
            int maxExecutions = TestProperties.getTestDatabaseJobExecutionMaxExecutions().intValue();
            
            waitForTheJobToRunForAMaximumOfFiftySeconds(maxExecutions);
            
            final List<FakeEntity> findInsertedEntities = TestDataBaseJobExecution.findInsertedEntities();
            
            assertNotNull(findInsertedEntities);
            
            assertThat(findInsertedEntities, hasSize(maxExecutions));
            
            TestSchedulerCluster.destroyAll();
            
            failIfThereIsNodeExceptions();
        } catch (final IOException | ClassNotFoundException exception) {
            exception.printStackTrace();
            
            fail(exception.getMessage());
        }
    }

    private void startClusterNodes(final int clusterNodes) throws IOException, ClassNotFoundException {
        for (int i = 0; i < clusterNodes; i++) {
            TestSchedulerCluster.startNewNode(WITNESS_PORT, EBEAN_AGENT_ARGUMENT);
            
            sleepSeconds(1);
        }
        
        TestSchedulerCluster.startWitness(clusterNodes, WITNESS_PORT);
    }

    private void waitForTheJobToRunForAMaximumOfFiftySeconds(int maxExecutions) {
        int millis = 50000;
        
        while (millis > 0) {
            millis -= 5000;
            
            sleepSeconds(5);
            
            final List<FakeEntity> findInsertedEntities = TestDataBaseJobExecution.findInsertedEntities();
            
            if (findInsertedEntities.size() == maxExecutions) {
                break;
            }
        }
    }
    
    private void failIfThereIsNodeExceptions() {
        if (!TestSchedulerCluster.getNodeExceptions().isEmpty()) {
            fail(TestSchedulerCluster
                    .getNodeExceptions()
                    .values()
                    .iterator().next().getMessage());
        }
    }
    
    private void sleepSeconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (final InterruptedException exception) {
            exception.printStackTrace();
            
            fail(exception.getMessage());
        }
    }
}
