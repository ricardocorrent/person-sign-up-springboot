package br.com.wealthsystems.commons.quartz.util;

import br.com.wealthsystems.commons.quartz.configuration.DataSourceProperty;
import br.com.wealthsystems.commons.quartz.configuration.QuartzPropertyLocator;
import com.ws.commons.utils.database.PostgresConnectionHelper;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Provides the essentials operations to prepare and execute Quartz cluster tests.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-07-02
 */
public class QuartzClusterUtil {
    
    private static final String SCHEMA_TABLE_SEPARATOR = ".";
    private static final String SCHEMA_TABLE_SEPARATOR_REGEX = "\\.";
    private static final String CREATE_SCHEMA_IF_NOT_EXISTS = "CREATE SCHEMA IF NOT EXISTS %s";
    
    /**
     * SQL file containing the necessary script to create the Quartz cluster tables.<br>
     * Default value: {@value}
     */
    public static final String QUARTZ_POSTGRES_SQL_FILE_PATH = "sql-script/quartz_postgres.sql";
    
    private final QuartzPropertyLocator quartzPropertyLocator;
    
    private PostgresConnectionHelper postgresConnectionHelper;
    
    private QuartzClusterUtil(final QuartzPropertyLocator quartzPropertyLocator) {
        this.quartzPropertyLocator = quartzPropertyLocator;
    }
    
    /**
     * Builds a QuartzClusterUtil instance.
     *
     * @param quartzPropertyLocator the property locator instance to provide the Quartz properties.
     * @return                      the {@link QuartzClusterUtil} with {@link QuartzPropertyLocator}
     *                              and {@link PostgresConnectionHelper} configured.
     */
    public static QuartzClusterUtil fromQuartzPropertyLocator(final QuartzPropertyLocator quartzPropertyLocator) {
        final QuartzClusterUtil quartzClusterUtil = new QuartzClusterUtil(quartzPropertyLocator);
        
        quartzClusterUtil.createPostgresConnectionHelper();
        
        return quartzClusterUtil;
    }

    private void createPostgresConnectionHelper() {
        this.postgresConnectionHelper = PostgresConnectionHelper
                .fromPersistenceProperties(
                        this.quartzPropertyLocator.getPropertyValueAsString(
                                DataSourceProperty.ORG_QUARTZ_DATASOURCE_WSDS_DRIVER),
                        this.quartzPropertyLocator.getPropertyValueAsString(
                                DataSourceProperty.ORG_QUARTZ_DATASOURCE_WSDS_URL),
                        this.quartzPropertyLocator.getPropertyValueAsString(
                                DataSourceProperty.ORG_QUARTZ_DATASOURCE_WSDS_USER),
                        this.quartzPropertyLocator.getPropertyValueAsString(
                                DataSourceProperty.ORG_QUARTZ_DATASOURCE_WSDS_PASSWORD));
    }
    
    /**
     * Generates the Quartz cluster tables according the default SQL file content
     * (<a href="https://github.com/quartz-scheduler/quartz/blob/master/quartz-core/src/main/resources/org/quartz/impl/jdbcjobstore/tables_postgres.sql">
     * Quartz-Scheduler-SQL-Tables</a>).
     *
     * @throws ClassNotFoundException   if database connection fails.
     * @throws SQLException             if SQL execution fails.
     * @throws IOException              if SQL file reading fails.
     * @see                             #QUARTZ_POSTGRES_SQL_FILE_PATH
     */
    public void createQuartzTables() throws 
            ClassNotFoundException, SQLException, IOException {
        
        final String tablePrefix = this.quartzPropertyLocator
            .getPropertyValueAsString(DataSourceProperty.ORG_QUARTZ_JOBSTORE_TABLEPREFIX);
        
        if (StringUtils.isNotBlank(tablePrefix)) {
            final String schema = extractSchemaFromTablePrefix(tablePrefix);
            
            if (StringUtils.isNotBlank(schema)) {
                createAndSetSchemaIfExists(schema);
            }
            
            this.postgresConnectionHelper.runInPostgresWithSchema(schema, getPostgresSQLFile());
        } else {
            this.postgresConnectionHelper.runInPostgres(getPostgresSQLFile());
        }
    }

    private File getPostgresSQLFile() {
        return new File(Thread.currentThread()
                .getContextClassLoader()
                .getResource(QUARTZ_POSTGRES_SQL_FILE_PATH).getPath());
    }
    
    /**
     * @param schema                    to extract the SCHEMA.
     * @throws SQLException             if SQL execution fails.
     * @throws ClassNotFoundException   if SQL execution fails.
     */
    private void createAndSetSchemaIfExists(final String schema) throws ClassNotFoundException, SQLException {
        if (StringUtils.isNotBlank(schema)) {
            createSchemaIfNotExists(schema);
        }
    }

    /**
     * @param tablePrefix to extract the SCHEMA.
     */
    private String extractSchemaFromTablePrefix(final String tablePrefix) {
        if (tablePrefix.contains(SCHEMA_TABLE_SEPARATOR)) {
            return tablePrefix.split(SCHEMA_TABLE_SEPARATOR_REGEX)[0];
        }
        
        return null;
    }
    
    /**
     * @param schema                    the SCHEMA to be created.
     * @throws SQLException             if SQL execution fails.
     * @throws ClassNotFoundException   if SQL execution fails.
     */
    private void createSchemaIfNotExists(final String schema) throws ClassNotFoundException, SQLException {
        this.postgresConnectionHelper.runInPostgres(String.format(CREATE_SCHEMA_IF_NOT_EXISTS, schema));
    }
}
