package br.com.wealthsystems.commons.quartz.scheduling.artifact;

import io.ebean.EbeanServer;
import io.ebean.EbeanServerFactory;
import io.ebean.config.ServerConfig;
import org.quartz.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Test class to be used in a {@link Job} to insert entities in database.
 *
 * <p>Uses the "pg" database configuration available in "test-ebean.properties".</p>
 * <p>Entities inserted will contain only one ID attribute.</p>
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-25
 */
public class TestDataBaseJobExecution {

    private final Logger logger = LoggerFactory.getLogger(TestDataBaseJobExecution.class);
    
    /**
     * The class of the entity whose objects will be inserted into the database.
     * Entities inserted will contain only one ID attribute.
     */
    public static final Class<FakeEntity> ENTITY_CLASS = FakeEntity.class;
    
    private static final Set<FakeEntity> INSERTED_ENTITIES = new HashSet<>();
    
    /**
     * {@link ServerConfig#setPackages(List)}
     */
    public static final String PACKAGE_WEALTHSYSTEMS = "br.com.wealthsystems";
    
    /**
     * {@link ServerConfig#setPackages(List)}
     */
    public static final String PACKAGE_WS = "com.ws";
    
    /**
     * {@link ServerConfig#setName(String)}
     */
    public static final String POSTGRES_EBEAN_CONF = "pg";
    
    private final EbeanServer ebeanServer = createEbeanServer(false);
    
    /**
     * Inserts a new entity only with an ID.
     */
    public void insertAnEntity() {
        final FakeEntity bean = new FakeEntity();
        
        this.ebeanServer.insert(bean);
        
        INSERTED_ENTITIES.add(bean);
        
        this.logger.info(MarkerFactory.getMarker("QUARTZ"), "Job executed successfully.\n");
    }
    
    
    /**
     * Creates Ebean server with some properties({@link ServerConfig}):
     * <ul>
     * <li>name: {@link #POSTGRES_EBEAN_CONF}</li>
     * <li>packages: {@link TestDataBaseJobExecution#PACKAGE_WS} and {@link #PACKAGE_WEALTHSYSTEMS}</li>
     * <li>register: True ({@link ServerConfig#setRegister(boolean)})</li> 
     * </ul>
     * 
     * @param runDDL    {@link ServerConfig#setDdlRun(boolean)}
     * @return          the configured Ebean server.
     */
    public static synchronized EbeanServer createEbeanServer(final boolean runDDL) {
        final ServerConfig config = new ServerConfig();

        config.setName(POSTGRES_EBEAN_CONF);
        config.loadFromProperties();
        config.setPackages(Arrays.asList(PACKAGE_WEALTHSYSTEMS, PACKAGE_WS));
        config.setRegister(true);
        config.setDdlRun(runDDL);

        return EbeanServerFactory.create(config);
    }
    
    /**
     * Deletes all inserted entities.
     * @param runDDL    {@link ServerConfig#setDdlRun(boolean)}
     * @see             #insertAnEntity()
     */
    public static synchronized void deleteAllEntities(final boolean runDDL) {
        if (!INSERTED_ENTITIES.isEmpty()) {
            createEbeanServer(runDDL).deleteAll(INSERTED_ENTITIES);
            
            INSERTED_ENTITIES.clear();
        }
    }
    
    /**
     * Returns the list of inserted entities.
     *
     * @return  the inserted entities.
     * @see     #insertAnEntity()
     */
    public static synchronized List<FakeEntity> findInsertedEntities() {
        final EbeanServer ebeanServer = createEbeanServer(false);
        
        return ebeanServer.findList(ebeanServer.find(FakeEntity.class), null);
    }
}
