package br.com.wealthsystems.commons.quartz.configuration;

import org.quartz.Job;

/**
 * Provides configuration keys that determines tests behaviors.<br>
 * A configuration key can be used in <a href="http://deltaspike.apache.org/documentation/">DeltaSpike</a>
 * features or {@link QuartzPropertyLocator}, to access the configuration values.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-07-04
 */
public enum TestConfigurationKey {

    /**
     * Key: <em>commons.quartz.scheduling.artifact.TestDataBaseJobExecution.maxExecutions</em><br>
     * Defines a maximum {@link Integer} of runs for a {@link Job}.<br>
     * After the maximum limit is reached, {@link Job} is interrupted.
     */
    TEST_DATABASE_JOB_EXECUTION_MAX_EXECUTIONS("commons.quartz.scheduling.artifact.TestDataBaseJobExecution.maxExecutions");
    
    private final String key;
    
    TestConfigurationKey(final String key) {
        this.key = key;
    }
    
    /**
     * @return the configuration key.
     */
    public String getKey() {
        return this.key;
    }
}
