package br.com.wealthsystems.commons.quartz.configuration;

import org.apache.deltaspike.core.api.config.ConfigResolver;

import java.util.concurrent.TimeUnit;

/**
 * Provides values of properties to Quartz configuration.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-07-04
 */
public class TestProperties {
    
    private static final Integer UNLIMETED = -1;

    /**
     * @return the max number of executions configured according to 
     * {@link TestConfigurationKey#TEST_DATABASE_JOB_EXECUTION_MAX_EXECUTIONS}
     */
    public static Integer getTestDatabaseJobExecutionMaxExecutions() {
        return ConfigResolver
                    .resolve(TestConfigurationKey.TEST_DATABASE_JOB_EXECUTION_MAX_EXECUTIONS.getKey())
                    .as(Integer.class)
                    .withDefault(UNLIMETED)
                    .cacheFor(TimeUnit.MINUTES, 1L)
                    .getValue();
    }
}
