package br.com.wealthsystems.commons.quartz.scheduling.artifact;

import org.mockito.Mockito;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;

import br.com.wealthsystems.commons.quartz.configuration.TestConfigurationKey;
import br.com.wealthsystems.commons.quartz.configuration.TestProperties;

/**
 * Provides interceptable database operations for Quartz-Scheduler testing.
 *
 * @author  Diego A. Costa
 * @see     #execute(JobExecutionContext)
 * @since   6.1.0 - 2018-06-22
 */
public class TestDataBaseJob implements Job {

    private static final Integer UNLIMETED = -1;
    
    /**
     * Spy Object that provides the database persistence operation.
     */
    public static final TestDataBaseJobExecution TEST_DATA_BASE_JOB_EXECUTION = Mockito.spy(new TestDataBaseJobExecution());

    private final Logger logger = LoggerFactory.getLogger(TestDataBaseJobExecution.class);
    
    private static int CURRENT_EXECUTION;
    
    private Integer maxExecutions;
    
    @SuppressWarnings("javadoc")
    public TestDataBaseJob() {
        this.logger.info(MarkerFactory.getMarker("QUARTZ"), "Max executions value: " + getMaxExecutions());
    }
    
    /**
     * Inserts an entity in the database as described in {@link TestDataBaseJobExecution#insertAnEntity()}<br>
     * If the max executions number is reached, the Scheduler will be shut down.
     *
     * @see Job#execute(org.quartz.JobExecutionContext)
     * @see TestConfigurationKey#TEST_DATABASE_JOB_EXECUTION_MAX_EXECUTIONS
     * @see TestDataBaseJobExecution
     */
    @Override
    public void execute(final JobExecutionContext context) throws JobExecutionException {
        final Integer max = getMaxExecutions();
        
        if (max == UNLIMETED || max > CURRENT_EXECUTION) {
            TEST_DATA_BASE_JOB_EXECUTION.insertAnEntity();
            
            CURRENT_EXECUTION++;
            
            this.logger.info(MarkerFactory.getMarker("QUARTZ"), "Current execution in " 
                    + getSchedulerInstanceId(context.getScheduler()) + ": " + CURRENT_EXECUTION);
        } else {
            unscheduleJob(context);
        }
    }

    private Integer getMaxExecutions() {
        if (this.maxExecutions == null) {
            this.maxExecutions = TestProperties.getTestDatabaseJobExecutionMaxExecutions();
        }
        
        return this.maxExecutions;
    }
    
    private void unscheduleJob(final JobExecutionContext context) throws JobExecutionException {
        final Scheduler scheduler = context.getScheduler();
        
        final String jobKey = context.getJobDetail().getKey().getName();
        
        try {
            scheduler.unscheduleJob(context.getTrigger().getKey());
        } catch (final SchedulerException e) {
            throw new JobExecutionException("Fail to unschedule job:" + jobKey, e);
        }
        
        this.logger.info(MarkerFactory.getMarker("QUARTZ"), "The job " + jobKey 
                + " was unschedule successfully on " + getSchedulerInstanceId(scheduler) + ".\n");
    }

    private String getSchedulerInstanceId(final Scheduler scheduler) throws JobExecutionException {
        try {
            return scheduler.getSchedulerInstanceId();
        } catch (final SchedulerException e) {
            throw new JobExecutionException("Fail to get Scheduler name", e);
        }
    }
}
