package br.com.wealthsystems.commons.quartz.scheduling.artifact;

import com.ws.commons.persistence.model.PhysicalDeleteBaseEntity;

import javax.persistence.Entity;

/**
 * Artifact to be used in Quartz cluster tests.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-07-02
 */
@Entity
public class FakeEntity extends PhysicalDeleteBaseEntity {

    private static final long serialVersionUID = 1L;

    //Has no properties, is not yet needed.
}
