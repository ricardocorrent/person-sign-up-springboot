package br.com.wealthsystems.commons.quartz.scheduling.artifact;

import org.mockito.Mockito;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * Logger test class.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-22
 */
@SuppressWarnings("javadoc")
public class TestLoggerJob implements Job {

    public static final TestLoggerJobExecution TEST_LOGGER_JOB_EXECUTION_INSTANCE = Mockito.spy(new TestLoggerJobExecution());
    
    /**
     * @see Job#execute(org.quartz.JobExecutionContext)
     */
    @Override
    public void execute(final JobExecutionContext context) throws JobExecutionException {
        TEST_LOGGER_JOB_EXECUTION_INSTANCE.logExecution();
    }
}
