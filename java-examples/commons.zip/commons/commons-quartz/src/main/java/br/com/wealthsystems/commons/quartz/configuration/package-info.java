/**
 * Package <em>"br.com.wealthsystems.commons.quartz"</em> 
 * features were created to facilitate the configuration of 
 * clustered implementations as well as to perform automated
 * testing of these environments. </p>
 * <em>Consider reading lib's official documentation:</em>
 * <ul>
 * <li><a target="_blank" href="http://www.quartz-scheduler.org/">Oficial site</a></li>
 * <li><a target="_blank" href="http://www.quartz-scheduler.org/documentation/quartz-2.2.x/configuration/">Configuration reference</a></li>
 * <li><a target="_blank" href="http://www.quartz-scheduler.org/documentation/quartz-2.2.x/configuration/ConfigJDBCJobStoreClustering.html">Cluster configuration reference</a></li>
 * <li><a target="_blank" href="https://github.com/quartz-scheduler/quartz">GitHub</a></li>
 * </ul>
 * Consider reading the Quartz documentation for clusters. Here's an 
 * important snippet of this documentation:<br>
 * "<em>The clustering feature works best for scaling out long-running 
 * and/or cpu-intensive jobs (distributing the work-load over multiple nodes). 
 * If you need to scale out to support thousands of short-running (e.g 1 second) 
 * jobs, consider partitioning the set of jobs by using multiple distinct 
 * schedulers (including multiple clustered schedulers for HA). The scheduler 
 * makes use of a cluster-wide lock, a pattern that degrades performance 
 * as you add more nodes (when going beyond about three nodes - depending 
 * upon your database’s capabilities, etc.).</em>"
 * @since 6.1.0 - 2018-06-28
 * @author Diego A. Costa
 * @see <a href="http://www.quartz-scheduler.org/">Oficial site</a>
 * @see <a href="http://www.quartz-scheduler.org/documentation/quartz-2.2.x/configuration/">Configuration reference</a>
 * @see <a href="http://www.quartz-scheduler.org/documentation/quartz-2.2.x/configuration/ConfigJDBCJobStoreClustering.html">Cluster configuration reference</a>
 * @see <a href="https://github.com/quartz-scheduler/quartz">GitHub</a>
 */
package br.com.wealthsystems.commons.quartz.configuration;