package br.com.wealthsystems.commons.quartz.configuration;

/**
 * Provides property keys for data sources.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-28
 */
public enum DataSourceProperty {

    /**
     * Property key for WSDS data source driver.
     */
    ORG_QUARTZ_DATASOURCE_WSDS_DRIVER("org.quartz.dataSource.wsds.driver"),
    
    /**
     * Property key for WSDS data source URL.
     */
    ORG_QUARTZ_DATASOURCE_WSDS_URL("org.quartz.dataSource.wsds.URL"),
    
    /**
     * Property key for WSDS data source user.
     */
    ORG_QUARTZ_DATASOURCE_WSDS_USER("org.quartz.dataSource.wsds.user"),
    
    /**
     * Property key for WSDS data source password.
     */
    ORG_QUARTZ_DATASOURCE_WSDS_PASSWORD("org.quartz.dataSource.wsds.password"),
    
    /**
     * Property key for data source table prefix.<br>
     *
     * <b>Value:</b> org.quartz.jobStore.tablePrefix<br>
     * The table prefix can be used to determine the SCHEMA, according the example below:<br>
     * <b><em>org.quartz.jobStore.tablePrefix</em> = mySchema.myTablePrefiz_</b>
     */
    ORG_QUARTZ_JOBSTORE_TABLEPREFIX("org.quartz.jobStore.tablePrefix");
    
    private final String key;

    /**
     * Constructor with key initialization.
     *
     * @param key property key
     */
    DataSourceProperty(final String key) {
        this.key = key;
    }
    
    /**
     * @return the property key.
     */
    public String getKey() {
        return this.key;
    }
}
