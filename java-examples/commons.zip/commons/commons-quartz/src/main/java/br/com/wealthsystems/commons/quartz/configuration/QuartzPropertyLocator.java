package br.com.wealthsystems.commons.quartz.configuration;

import br.com.wealthsystems.commons.quartz.exception.NoQuartzPropFileFound;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Provides a simple way to obtain any Quartz property value.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-29
 */
public class QuartzPropertyLocator {
    
    /**
     * Alternative path where the properties file can be stored.<br>
     * Value: {@value}
     */
    public static final String ALTERNATIVE_PROP_FILE_PATH = "org/quartz/";
    
    /**
     * Default name of the properties file.<br>
     * Value: {@value}
     */
    public static final String DEFAULT_PROP_FILE_NAME = "quartz.properties";
    
    private Properties properties;
    private final Logger logger;
    
    /**
     * After the instance is constructed, the properties file will be read.
     *
     * @throws NoQuartzPropFileFound if no Quartz properties is found.
     */
    public QuartzPropertyLocator() throws NoQuartzPropFileFound {
        this.logger = LoggerFactory.getLogger(getClass());
        this.properties = getPropertiesFile();
    }
    
    /**
     * Retrieves the property value according to passed property {@code key}.
     *
     * @param key   the property key.
     * @return      the property value according the property key.
     */
    public String getPropertyValueAsString(final String key) {
        return this.properties.getProperty(key);
    }
    
    /**
     * Gets property value according to a {@link DataSourceProperty}.
     *
     * @param dataSourceProperty    the object that contains property key.
     * @return                      the property value according the property key.
     */
    public String getPropertyValueAsString(final DataSourceProperty dataSourceProperty) {
        return getPropertyValueAsString(dataSourceProperty.getKey());
    }
    
    /**
     * Retrieves the property value as a boolean.
     *
     * @param key   the property key.
     * @return      the property value according the property key.
     */
    public Boolean getPropertyValueAsBoolean(final String key) {
        return Boolean.valueOf(getPropertyValueAsString(key));
    }
    
    private Properties getPropertiesFile() throws NoQuartzPropFileFound {
        if (this.properties == null) {
            logger.debug("Trying to load properties from default properties file");
            this.properties = getDefaultPropFile();
        }
        
        if (this.properties == null) {
            logger.debug("Trying to load properties from file in alternative path");
            this.properties = getDefaultPropFileInAlternativePath();
        }
        
        if (this.properties == null) {
            throw new NoQuartzPropFileFound();
        }
        
        return this.properties;
    }

    private Properties getDefaultPropFile() {
        return getResourcePropFile(DEFAULT_PROP_FILE_NAME);
    }
    
    private Properties getDefaultPropFileInAlternativePath() {
        return getResourcePropFile(ALTERNATIVE_PROP_FILE_PATH + DEFAULT_PROP_FILE_NAME);
    }

    private Properties getResourcePropFile(final String path) {
        logger.debug("Trying to load properties from file '{}'", path);
        try(final InputStream resourceAsStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {
            if (resourceAsStream != null) {
                final Properties resourceProperties = new Properties();
                
                resourceProperties.load(resourceAsStream);
                
                return resourceProperties; 
            }
            
            return null;
        } catch (final IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * @return the properties
     */
    public Properties getProperties() {
        return this.properties;
    }
}
