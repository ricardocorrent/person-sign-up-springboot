package br.com.wealthsystems.commons.quartz.exception;

import java.io.IOException;

/**
 * Exception that reports the nonexistence of the Quartz properties file.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-29
 */
public class NoQuartzPropFileFound extends IOException {

    private static final long serialVersionUID = 1L;

    /**
     * @see IOException#IOException()
     */
    public NoQuartzPropFileFound(){
        super();
    }

    /**
     * @param throwable {@link IOException#IOException(Throwable)}
     */
    public NoQuartzPropFileFound(final Throwable throwable){
        super(throwable);
    }

    /**
     * @param message IOException#IOException(String)
     */
    public NoQuartzPropFileFound(final String message){
        super(message);
    }

    /**
     * @param message   IOException#IOException(String, Throwable)
     * @param throwable IOException#IOException(String, Throwable)
     */
    public NoQuartzPropFileFound(final String message, final Throwable throwable){
        super(message, throwable);
    }
}
