package com.ws.commons.management

import com.ws.commons.server.JettyServerCustomizer
import org.eclipse.jetty.server.Server
import org.eclipse.jetty.server.ServerConnector
import org.eclipse.jetty.server.handler.HandlerCollection
import org.eclipse.jetty.servlet.ServletContextHandler
import org.eclipse.jetty.servlet.ServletHolder
import org.eclipse.jetty.util.resource.Resource
import org.eclipse.jetty.webapp.WebAppContext
import org.glassfish.jersey.servlet.ServletContainer
import org.jboss.weld.environment.servlet.WeldServletLifecycle
import org.slf4j.LoggerFactory
import javax.enterprise.inject.Default
import javax.enterprise.inject.Instance
import javax.enterprise.inject.spi.BeanManager
import javax.inject.Inject

/**
 * [JettyServerCustomizer] implementation for Management API
 *
 * When enabled by configuration, this class customizes Jetty server by adding a custom connector, context and handler
 * for Management API. Main goal here is to provide an isolated context to not expose management APIs alongside
 * application APIs.
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-26
 */
@Default
class ManagementJettyServerCustomizer @Inject constructor(private val configuration: ManagementConfiguration,
                                                          private val customizers: Instance<ManagementContextCustomizer>,
                                                          private val beanManager: BeanManager) : JettyServerCustomizer {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Customizes the Jetty [Server] adding management context if enabled
     */
    override fun customize(server: Server) {
        with(configuration) {
            if (!enabled()) {
                logger.info("Management port disabled by configuration")
                return@customize
            } else {
                logger.info("Starting management context at port ${port()} and path ${path()}")
            }
        }

        startConnector(server).also { startContext(server).apply(it::addManaged) }.apply(server::addConnector)
        server.handler = HandlerCollection(startJerseyHandler(), server.handler)
    }

    private fun startConnector(server: Server) =
            ServerConnector(server).also {
                it.port = configuration.port()
                it.name = JETTY_CONNECTOR_NAME
            }

    private fun startContext(server: Server) =
            WebAppContext().also {
                it.server = server
                it.isThrowUnavailableOnStartupException = true
                it.contextPath = "/"
                it.baseResource = Resource.newClassPathResource("management-web")
                it.isParentLoaderPriority = false
                it.defaultsDescriptor = null
                it.servletContext.isExtendedListenerTypes = true
                it.setAttribute(WeldServletLifecycle.BEAN_MANAGER_ATTRIBUTE_NAME, beanManager)

                invokeContextCustomizers(it)
            }

    /**
     * Executes all [ManagementContextCustomizer] implementations available, applying additional context configurations
     * when required
     */
    private fun invokeContextCustomizers(context: WebAppContext) =
            customizers.forEach {
                it.customize(context)
                customizers.destroy(it)
            }

    private fun startJerseyHandler(): ServletContextHandler {
        val holder = ServletHolder(ServletContainer::class.java).also {
            it.initParameters[JAXRS_SERVLET_APPLICATION_PARAMETER] = ManagementApplication::class.java.name
            it.initOrder = 0
        }

        return ServletContextHandler(ServletContextHandler.NO_SESSIONS).also {
            it.contextPath = configuration.path()
            it.virtualHosts = arrayOf("@$JETTY_CONNECTOR_NAME")
            it.servletContext.isExtendedListenerTypes = true
            it.addServlet(holder, "/*")
        }
    }
}