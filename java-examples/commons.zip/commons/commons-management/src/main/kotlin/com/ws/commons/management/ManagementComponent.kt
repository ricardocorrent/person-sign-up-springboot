package com.ws.commons.management

import javax.inject.Qualifier

/**
 * Management component qualifier
 *
 * This annotation identifies JAX-RS based management components. When a class has this annotation it will be
 * automatically registered under JAX-RS context for management API.
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-26
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS, AnnotationTarget.TYPE, AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.FIELD)
@MustBeDocumented
@Qualifier
annotation class ManagementComponent
