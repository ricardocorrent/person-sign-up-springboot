package com.ws.commons.management

/**
 * Optional interface for [ManagementComponent] annotated classes which allows conditional
 * deactivation of the component based on component internal rules
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
interface ConditionalComponent {

    /**
     * Returns if current component should be enabled on automatic registration
     */
    fun isComponentEnabled(): Boolean
}