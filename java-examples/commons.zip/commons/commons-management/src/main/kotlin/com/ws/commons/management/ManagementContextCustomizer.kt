package com.ws.commons.management

import org.eclipse.jetty.webapp.WebAppContext

/**
 * Customization interface for the management context
 *
 * This interface allows customization of the Jetty context for the management API, allowing implementations to
 * execute additional configurations when needed
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
interface ManagementContextCustomizer {

    /**
     * Executes the customization under provided context
     */
    fun customize(context: WebAppContext)
}