package com.ws.commons.management

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-26
 */
internal const val JAXRS_SERVLET_APPLICATION_PARAMETER = "javax.ws.rs.Application"
internal const val JETTY_CONNECTOR_NAME = "managed"