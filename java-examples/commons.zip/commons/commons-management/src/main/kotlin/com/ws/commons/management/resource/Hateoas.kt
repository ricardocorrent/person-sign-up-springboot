package com.ws.commons.management.resource

import javax.ws.rs.core.Link

/**
 * Simple representation of a HATEOAS link suitable for JSON responses
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
data class JsonHateoasLink(val href: String, val rel: String)

/**
 * Simple response bean with a collection of HATEOAS links
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
data class JsonHateoas(val _links: List<JsonHateoasLink>)

/**
 * Extension function for simple conversion from [Link] to [JsonHateoasLink]
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
fun Link.toJsonHateoasLink() = JsonHateoasLink(uri.toString(), rel)

/**
 * Extension function for simple conversion from [List] of [Link] to [JsonHateoas]
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
fun List<Link>.toJsonHateoas() = JsonHateoas(map { it.toJsonHateoasLink() })