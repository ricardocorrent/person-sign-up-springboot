package com.ws.commons.management

import org.apache.deltaspike.core.api.config.ConfigProperty
import org.apache.deltaspike.core.api.config.Configuration

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-26
 */
@Configuration(prefix = "management.")
interface ManagementConfiguration {

    /**
     * Returns the port where API should listen for HTTP requests. Defaults to 8082.
     */
    @ConfigProperty(name = "port", defaultValue = "8082")
    fun port(): Int

    /**
     * Returns if Management API should be enabled. Defaults to false.
     */
    @ConfigProperty(name = "enabled", defaultValue = "false")
    fun enabled(): Boolean

    /**
     * Returns the path prefix for management APIs exposed over HTTP. Defaults to /.
     */
    @ConfigProperty(name = "path", defaultValue = "/")
    fun path(): String
}