package com.ws.commons.management.resource

import com.ws.commons.management.ManagementComponent
import javax.ws.rs.GET
import javax.ws.rs.Path
import javax.ws.rs.Produces
import javax.ws.rs.core.*

/**
 * Basic JAX-RS resource exposing all available management APIs available. Representation
 * of the available endpoints is done using HATEOAS under JSON.
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
@Path("/")
@ManagementComponent
class ManagementDefaultResource {

    @Context
    internal lateinit var uriInfo: UriInfo

    @Context
    internal lateinit var application: Application

    /**
     * Retrieves all available management endpoints
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    fun get() =
            Response.ok(availableResources().toJsonHateoas()).build()

    /**
     * Scans JAX-RS [Application] and locates all registered classes with [Path] annotation,
     * returning all identified values from annotation (which represent JAX-RS resource paths)
     */
    private fun availableResources() =
            application.classes.filter { clazz ->
                clazz.annotations.any { it is Path }
            }.map { clazz ->
                clazz.annotations.single { it is Path } as Path
            }.map {
                Pair(it.value, toName(it.value))
            }.map {
                Link.fromUriBuilder(uriInfo.baseUriBuilder.path(it.first)).rel(it.second).build()
            }

    /**
     * Normalizes a path value to a human-readable (like-ish) name by removing the first slash and replacing remaining
     * ones with hyphen
     */
    private fun toName(value: String) =
            when (value) {
                "/" -> "self"
                else -> value.takeUnless { value.startsWith("/") } ?: value.substring(1)
            }.replace("/", "-")

}