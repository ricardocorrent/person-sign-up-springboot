package com.ws.commons.management

import com.ws.commons.server.json.ObjectMapperResolver
import org.glassfish.jersey.server.ResourceConfig
import org.slf4j.LoggerFactory
import javax.annotation.PostConstruct
import javax.enterprise.inject.spi.Bean
import javax.enterprise.inject.spi.BeanManager
import javax.enterprise.util.AnnotationLiteral
import javax.inject.Inject

/**
 * JAX-RS configuration class for Management API
 *
 * This class configures JAX-RS context for Management API. This class uses CDI to scan for all JAX-RS based resources
 * with [ManagementComponent] annotation and automatically register them under context.
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-26
 */
internal class ManagementApplication @Inject constructor(private val beanManager: BeanManager) : ResourceConfig() {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Initializes JAX-RS context
     */
    @PostConstruct
    fun initialize() {
        registerDefaultComponents()
        discoverComponents()
    }

    /**
     * Scans for all management components using CDI and register them in JAX-RS context
     */
    private fun discoverComponents() =
            beanManager
                    .getBeans(Object::class.java, object : AnnotationLiteral<ManagementComponent>() {})
                    .filter { isComponentEnabled(it as Bean<Any>) }
                    .map { it.beanClass }
                    .forEach {
                        register(it)
                        logger.debug("Management resource started: ${it.simpleName}")
                    }

    /**
     * Checks if the given bean is a implementation of [ConditionalComponent] and executes component internal rules
     * to conditionally disable the registration.
     *
     * When bean isn't a [ConditionalComponent] implementation this method always return as a enabled component.
     */
    private fun isComponentEnabled(bean: Bean<Any>) =
            bean.takeIf { ConditionalComponent::class.java.isAssignableFrom(bean.beanClass) }?.let {
                beanManager.createCreationalContext(bean).let { bean.create(it) as ConditionalComponent }.isComponentEnabled()
            } ?: true

    private fun registerDefaultComponents() =
            register(ObjectMapperResolver::class.java)
}