package com.ws.commons.management.resource

import com.nhaarman.mockito_kotlin.doAnswer
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.stub
import com.ws.commons.server.json.ObjectMapperResolver
import org.json.JSONObject
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import java.net.URI
import javax.ws.rs.Path
import javax.ws.rs.core.Application
import javax.ws.rs.core.UriBuilder
import javax.ws.rs.core.UriInfo
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
@RunWith(MockitoJUnitRunner::class)
class ManagementDefaultResourceUnitTests {

    @Path("/test1")
    class ResourceArtifact1

    @Path("/test2")
    class ResourceArtifact2

    @Mock
    private lateinit var uriInfo: UriInfo

    @Mock
    private lateinit var application: Application

    private val testBaseUri = URI("http://unit-test")
    private lateinit var resource: ManagementDefaultResource

    @Before
    fun setup() {
        stub {
            on { application.classes } doReturn setOf(ResourceArtifact1::class.java, ResourceArtifact2::class.java)
            on { uriInfo.baseUriBuilder } doAnswer { UriBuilder.fromUri(testBaseUri) }
        }

        resource = ManagementDefaultResource()
        resource.application = application
        resource.uriInfo = uriInfo
    }

    @Test
    fun `when a resource is registered it should return a response with the resource API href using HATEOAS`() {
        // execution
        val response = resource.get()

        // validation
        assertNotNull(response)
        assertNotNull(response.entity)
        assertTrue {
            val jsonString = ObjectMapperResolver.getInstance().createMapper().writeValueAsString(response.entity)
            val links = JSONObject(jsonString).getJSONArray("_links").let {
                (0 until it.length()).map { index -> it.getJSONObject(index).getString("href") }
            }
            val artifacts = application.classes.map { testBaseUri.toString() + pathOf(it) }

            links.containsAll(artifacts)
        }
    }

    @Test
    fun `when a resource is registered it should return a response with the resource API rel using HATEOAS`() {
        // execution
        val response = resource.get()

        // validation
        assertNotNull(response)
        assertNotNull(response.entity)
        assertTrue {
            val jsonString = ObjectMapperResolver.getInstance().createMapper().writeValueAsString(response.entity)
            val rels = JSONObject(jsonString).getJSONArray("_links").let {
                (0 until it.length()).map { index -> it.getJSONObject(index).getString("rel") }
            }
            val artifacts = application.classes.map { relOf(it) }

            rels.containsAll(artifacts)
        }
    }

    private fun pathOf(clazz: Class<*>) =
            clazz.annotations.single { it is Path }.let { it as Path }.value

    private fun relOf(clazz: Class<*>) =
            with(pathOf(clazz)) {
                when (this) {
                    "/" -> "self"
                    else -> takeUnless { startsWith("/") } ?: substring(1)
                }.replace("/", "-")
            }

}