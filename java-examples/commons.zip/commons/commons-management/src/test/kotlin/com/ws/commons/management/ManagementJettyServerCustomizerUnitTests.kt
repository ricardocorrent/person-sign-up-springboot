package com.ws.commons.management

import com.nhaarman.mockito_kotlin.*
import org.eclipse.jetty.server.Handler
import org.eclipse.jetty.server.Server
import org.eclipse.jetty.util.thread.ThreadPool
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import javax.enterprise.inject.Instance
import javax.enterprise.inject.spi.BeanManager
import kotlin.random.Random

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
@RunWith(MockitoJUnitRunner::class)
class ManagementJettyServerCustomizerUnitTests {

    @Mock
    private lateinit var configuration: ManagementConfiguration
    @Mock
    private lateinit var server: Server
    @Mock
    private lateinit var contextCustomizers: Instance<ManagementContextCustomizer>
    @Mock
    private lateinit var contextCustomizer: ManagementContextCustomizer
    @Mock
    private lateinit var beanManager: BeanManager

    private lateinit var customizer: ManagementJettyServerCustomizer

    @Before
    fun setUp() {
        stub {
            on { server.threadPool } doReturn mock<ThreadPool> {}
            on { server.handler } doReturn mock<Handler> {}
            on { configuration.path() } doReturn Random.nextLong().toString()
            on { configuration.port() } doReturn Random.nextInt()
            on { configuration.enabled() } doReturn true
            on { contextCustomizers.iterator() } doAnswer { mutableListOf(contextCustomizer).iterator() }
        }

        customizer = ManagementJettyServerCustomizer(configuration, contextCustomizers, beanManager)
    }

    @Test
    fun `when management is disabled by configuration it should do nothing when customize method is called`() {
        // scenario
        stub {
            on { configuration.enabled() } doReturn false
        }

        // execution
        customizer.customize(server)

        // validation
        verify(server, never()).handler = any()
        verify(server, never()).addConnector(any())
    }

    @Test
    fun `when management is enabled by configuration and customize method is called it should start management connector`() {
        // execution
        customizer.customize(server)

        // validation
        verify(server, times(1)).addConnector(any())
    }

    @Test
    fun `when management is enabled by configuration and customize method is called it should start management handler`() {
        // execution
        customizer.customize(server)

        // validation
        verify(server, times(1)).handler = any()

    }

    @Test
    fun `when management is enabled and customize method is called it should invoke context customizers and release them from CDI context`() {
        // execution
        customizer.customize(server)

        // validation
        verify(contextCustomizer, times(1)).customize(any())
        verify(contextCustomizers, times(1)).destroy(contextCustomizer)
    }

}