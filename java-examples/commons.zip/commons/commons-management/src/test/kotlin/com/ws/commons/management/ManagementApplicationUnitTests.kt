package com.ws.commons.management

import com.nhaarman.mockito_kotlin.any
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.mock
import com.nhaarman.mockito_kotlin.stub
import com.ws.commons.server.json.ObjectMapperResolver
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import javax.enterprise.inject.spi.Bean
import javax.enterprise.inject.spi.BeanManager
import javax.enterprise.util.AnnotationLiteral
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-06-27
 */
@RunWith(MockitoJUnitRunner::class)
class ManagementApplicationUnitTests {

    @Mock
    private lateinit var beanManager: BeanManager

    private lateinit var application: ManagementApplication

    @Before
    fun setUp() {
        application = ManagementApplication(beanManager)
    }

    @Test
    fun `when initialize method is called it should register ObjectMapperResolver`() {
        // execution
        application.initialize()

        // validation
        assertTrue { application.classes.contains(ObjectMapperResolver::class.java) }
    }

    @Test
    fun `when initialize method is called it should register beans from CDI with ManagementComponent qualifier`() {
        // scenario
        class Artifact

        val bean = mock<Bean<*>> {
            on { beanClass } doReturn Artifact::class.java
        }
        stub {
            on { beanManager.getBeans(any(), any<AnnotationLiteral<ManagementComponent>>()) } doReturn setOf(bean)
        }

        // execution
        application.initialize()

        // validation
        assertTrue { application.classes.contains(Artifact::class.java) }
    }
}