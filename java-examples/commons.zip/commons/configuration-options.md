## Opções de configuração

Este documento relaciona todas as opções de configuração disponíveis na Backend Foundation. 

As propriedades dispostas abaixo são resolvidas pela biblioteca usando o Apache Deltaspike. Maiores detalhes do 
funcionamento desse processo estão disponíveis [aqui](readme.md#configuração).

### Índice

- [Perfil de configuração ativo](#perfil-de-configuração-ativo)
- [Definições gerais do serviço](#definições-gerais-do-serviço)
- [Autenticação, permissões e sessão](#autenticação-permissões-e-sessão)
- [Banco de dados](#banco-de-dados)
- [Connection pool](#connection-pool)
- [Acesso a dados](#acesso-a-dados)
- [Camada de serviço](#camada-de-serviço)
- [Vault](#vault)
- [PojoConverter](#pojoconverter)
- [Serialização e deserialização para JSON](#serialização-e-deserialização-para-json)
- [Configuração centralizada](#configuração-centralizada)
- [Métricas](#métricas)
- [Gerenciamento remoto](#gerenciamento-remoto)
- [Health Check](#health-check)


### Perfil de configuração ativo

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|org.apache.deltaspike.ProjectStage|String|Production|Nome do estágio/perfil de configuração ativo|

### Definições gerais do serviço

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|service.name|String|null|Nome do serviço|
|service.version|String|Versão do serviço|
|service.release|String|Versão do release do serviço. Exemplo: 7.5.1|
|port|Integer|80|Porta TCP em que a aplicação irá escutar.|
|host|String|null|IP ou nome DNS em que a aplicação irá escutar.|
|timezone|String|GMT|Identificação da zona de tempo padrão a ser usada pela aplicação.|
|discovery.service.address|String|null|IP ou nome DNS do servidor de descoberta que a aplicação deve se registrar.|

### Autenticação, permissões e sessão

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|authorization.service.name|String|user|Nome do serviço de consulta das permissões do usuário autenticado|
|authorization.service.api|String|/users/self-permissions|URI da API de consulta das permissões do usuário autenticado|
|redis.host|String|127.0.0.1|IP ou nome DNS do servidor Redis de armazenamento dos dados da sessão|
|redis.port|Integer|6379|Porta TCP do servidor Redis|
|redis.password|String|null|Senha de autenticação no servidor Redis|
|redis.expire|Integer|1800|Tempo de duração de uma sessão de usuário. O valor é representado em segundos após o último acesso.|
|redis.timeout|Integer|0|Tempo de espera para conexão com o servidor Redis|
|redis.session.enabled|Boolean|true|Define se o armazenamento de sessões via Redis deve ser habilitado.|
|jwt.timeout.seconds|Integer|30|Tempo em segundos para o token JWT expirar|

### Banco de dados

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|db.url|String|null|URL JDBC de conexão com o banco de dados|
|db.username|String|postgres|Usuário de autenticação no SGBD|
|db.password|String|postgres|Senha de autenticação no SGBD|
|db.driver|String|org.postgresql.Driver|Nome qualificado da classe de driver JDBC do banco de dados|
|db.schema|String|welathsystems|Nome da schema do banco de dados. Em cenários com multi tenancia ativada por schema, este valor será usado como o padrão.|
|db.platform|String|io.ebean.config.dbplatform.postgres.PostgresPlatform|Nome qualificado da classe de plataforma para o ORM Ebean|
|tenant.mode|String|SCHEMA|Define o modo de multi tenancia a ser usado|

### Connection pool

|Propriedade|Tipo|Valor padrão|Compatibilidade|Descrição|
|---|---|---|---|---|
|ds.provider|String|HIKARICP|-|Define o nome do provedor do pool de conexões com o banco de dados|
|ds.removeAbandonedOnBorrow|Boolean|true|DBCP|Define se conexões abandonadas devem ser encerradas automaticamente|
|ds.removeAbandonedTimeout|Integer|null|DBCP|Tempo em segundos de espera antes que uma conexão abandonada seja encerrada|
|ds.removeAbandonedOnMaintenance|Boolean|true|DBCP|Define se as conexões abandonadas devem ser removidas nos ciclos de manutenção|
|ds.timeBetweenEvictionRunsMillis|Integer|null|DBCP|Tempo de espera entre os ciclos de manutenção. Valores negativos desativam a manutenção.|
|ds.softMinEvictableIdleTimeMillis|Integer|null|DBCP|Tempo minimo (soft) que uma conexão aberta aguarde no pool de conexões antes de ser fechada automaticamente.|
|ds.minEvictableIdleTimeMillis|Integer|null|DBCP|Tempo minimo que uma conexão aberta aguarde no pool de conexões antes de ser fechada automaticamente.|
|ds.connectionTimeoutMillis|Integer|null|DBCP; HikariCP|Tempo máximo que o pool irá aguardar ao tentar iniciar uma conexão com o banco de dados.|
|ds.minIdle|Integer|null|DBCP; HikariCP|Número mínimo de conexões que serão mantidas abertas no pool, mesmo que não estejam em uso|
|ds.maxIdle|Integer|null|DBCP|Número máximo de conexões que serão mantidas abertas no pool em estado ocioso|
|ds.logAbandoned|Boolean|null|DBCP|Define se conexões abandonadas devem ser registradas em log quando detectadas nos ciclos de manutenção.|
|ds.logExpiredConnections|Boolean|null|DBCP|Define se conexões expiradas devem ser registradas em log quando detectadas nos ciclos de manutenção.|
|ds.maxConnLifetimeMillis|Integer|null|DBCP; HikariCP|Tempo máximo de vida em milissegundos que uma conexão pode ter|
|ds.maxTotal|Integer|null|DBCP; HikariCP|Quantidade máxima de conexões que o pool pode manter abertas em qualquer momento|
|ds.testOnBorrow|Boolean|null|DBCP|Define se uma conexão deve ser testada antes de ser concedida para uso|
|ds.testOnReturn|Boolean|null|DBCP|Define se uma conexão deve ser testada quando ela retornar para o pool|
|ds.testWhileIdle|Boolean|null|DBCP|Define se uma conexão deve ser teatada enquanto ociosa durante os ciclos de manutenção|

### Acesso a dados

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|dao.throwRegisterNotFound|Boolean|false|Define se o `AbstractDAO` deve disparar `RegisterNotFoundException` quando solicitado o acesso a um registro inexistente|
|dao.mapExceptionToLogicException|Boolean|true|Define se o `AbstractDAO` deve mapear as exceções automaticamente para `LogicException`|
|dao.onlyUpdateChangedFields|Boolean|true|Define a estratégia de atualização de objetos pelo `AbstractDAO`. Quando `true` a SQL gerada pelo ORM irá conter apenas os atributos da entidade que foram alterados; `false` irá gerar uma SQL com todos os atributos.|
|ebean.server.name|String|EbeanMultiTenancyServer|Nome da instância do ORM Ebean a ser utilizada|
|recycling.disableDefaultRecycler|Boolean|false|Define de o `DefaultRecycleListener` deve ser registrado automaticamente ou não. `true` desativa o registro.|

### Camada de serviço

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|service.throwRegisterNotFound|Boolean|true|Define se o `AbstractService` deve disparar `RegisterNotFoundException` quando solicitado o acesso a um registro inexistente|

### Vault

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|vault.host|String|null|IP ou nome DNS do servidor Vault|
|vault.token|String|null|Token de acesso ao servidor Vault|
|vault.api|String|/v1/secret|URI da API a ser consumida no servidor Vault|
|vault.protocol|String|http|Protocolo a ser utilizado para comunicação com o servidor Vault|

### PojoConverter

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|pojo.column.mapper.metadata.cache.limit|Integer|10|Quantidade limite de itens de metadados armazenados em cache pelo PojoConverter|
|pojo.onlyConvertChangedValues|Boolean|false|Determina se o PojoConverter deve converter apenas os atributos alterados (não nulos) usando métodos get/set das classes envolvidas.|
|find.dto.target.on.reading.field.name|Boolean|false|Define como o PojoConverter irá resolver o nome do atributo. Quando `true` será usado o nome do atributo na classe de destino da conversão; `false` será usado o nome do atributo na classe de origem.|

### Serialização e deserialização para JSON

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|server.serialization.values.empty|Boolean|true|Define como valores vazios não nulos devem ser serializados para JSON. Quando `false` eles serão omitidos do JSON gerado.|
|server.deserialization.disableDefaultExceptionHandlers|Boolean|false|Define se as implementações padrão de tratamento de erros de deserialização de JSON devem ser desabilitadas|
|server.deserialization.disableInterceptionOfMappingExceptions|Boolean|false|Define se exceções de mapeamento na deserialização de JSON devem ser tratadas automaticamente. `true` desabilita o tratamento automático.|
|server.deserialization.disableInterceptionOfAllExceptions|Boolean|false|Define se qualquer exceção durante a deserialização de JSON deve ser tratada automaticamente. `true` desabilita o tratamento automático.|

### Configuração centralizada

#### Geral

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|remoteconfig.provider|Class|NOOP|Nome qualificado da classe de implementação do provedor de configuração remota ou alias (NOOP, CONFIGSERVER, GIT ou HTTP)|
|remoteconfig.cache.unit|TimeUnit|MINUTES|Unidade de tempo de expiração do cache do provedor|
|remoteconfig.cache.unitcount|Long|30|Quantidade de unidades de tempo para expiração do cache do provedor|
|service.release|String|null|Versão de release do serviço/aplicação. Exemplo: 7.5.1|

#### HTTP

Valor para uso em `remoteconfig.provider`: `HTTP` ou `com.ws.commons.remoteconfig.provider.http.HttpProvider`

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|remoteconfig.http.url|String|null|Endereço URL do servidor que fornece o repositório de configuração via HTTP|
|remoteconfig.http.template|String|/config/{application}/{stage}/{key}|Template do path a ser consultado via GET no servidor remoto|

Nota sobre o template do `path` a ser solicitado via `GET`: A implementação suporta o uso de 3 atributos dinamicos na URL,
que são `{application}`, `{stage}` e `{key}` que representam o nome da aplicação, o estágio de configuração e a chave
de configuração sendo resolvida respectivamente. 

#### Git

Valor para uso em `remoteconfig.provider`: `GIT` ou `com.ws.commons.remoteconfig.provider.git.GitProvider`

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|remoteconfig.git.url|String|null|URL do repositório Git remoto|
|remoteconfig.git.branch|String|master|Nome do branch para ser clonado|
|remoteconfig.git.useauthentication|Boolean|false|Define se deve ser usado autenticação para efetuar o clone do repositório|
|remoteconfig.git.username|String|null|Usuário de autenticação|
|remoteconfig.git.password|String|null|Senha de autenticação|

#### Config Server

Valor para uso em `remoteconfig.provider`: `CONFIGSERVER` ou `com.ws.commons.remoteconfig.provider.configserver.ConfigServerProvider`

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|remoteconfig.configserver.url|String|null|URL do servidor de configuração|
|remoteconfig.configserver.template|String|/{application}/{stage}/{version}|Template do path que será utilizado para acesso aos valores de configuração|
|remoteconfig.configserver.authenticationmode|String|DISABLED|Define o modo de autenticação. Valores válidos: DISABLED, BASIC e TOKEN|
|remoteconfig.configserver.username|String|null|Usuário de autenticação. Obrigatório quando o modo de autenticação é BASIC.|
|remoteconfig.configserver.password|String|null|Senha de autenticação. Usado quando o modo de autenticação é BASIC.|
|remoteconfig.configserver.token|String|null|Token de autenticação. Obrigatório quando o modo de autenticação é TOKEN.|

### Métricas

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|metrics.enable|Boolean|false|Define se a API de métricas como um todo é ativada ou não|
|metrics.reporter|String|null|Identifica qual o reporter a ser usado. Deve conter o valor JMX ou ELASTICSEARCH|

#### Coletor

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|metrics.collector.jvm.enable|Boolean|false|Define se a coleta de métricas da JVM é ativada|
|metrics.collector.jersey.enable|Boolean|false|Define se a coleta de métricas do Jersey é ativada|
|metrics.collector.jetty.enable|Boolean|false|Define se a coleta de métricas do Jetty é ativada|
|metrics.collector.log4j2.enable|Boolean|false|Define se a coleta de métricas do Log4j é ativada|

#### Elasticsearch

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|metrics.reporter.elasticsearch.host|String|null|Endereço IP ou nome DNS de acesso ao servidor|
|metrics.reporter.elasticsearch.port|String|null|Porta TCP a ser usada para conectar ao servidor|
|metrics.reporter.elasticsearch.usessl|Boolean|false|Define se deve ser usado SSL ao conectar com o servidor|
|metrics.reporter.elasticsearch.index|String|metrics|Nome do índice a ser usado no Elasticsearch|
|metrics.reporter.elasticsearch.prefix|String|null|Define o prefixo a a ser usado para conectar com o Elasticsearch|
|metrics.reporter.elasticsearch.intervalunit|TimeUnit|SECONDS|Unidade de tempo em que os dados serão publicados no Elasticsearch|
|metrics.reporter.elasticsearch.intervalcount|Long|30|Quantidade de unidades de tempo em Long em que os dados serão publicados|

### Gerenciamento remoto

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|management.enabled|Boolean|false|Habilita a porta no container HTTP para expor as APIs de gerenciamento|
|management.port|Integer|8082|Porta em que as APIs de gerenciamento serão expostas|
|management.path|String|/|Prefixo das APIs de gerenciamento|

### Health Check

|Propriedade|Tipo|Valor padrão|Descrição|
|---|---|---|---|
|healthcheck.enabled|Boolean|true|Habilita a API de consulta do Health Check na porta de gerenciamento|
|healthcheck.showdetails|Boolean|false|Habilita a exibição dos detalhes das verificações. Quando falso, a API irá retornar apenas o status geral (UP/DOWN)|