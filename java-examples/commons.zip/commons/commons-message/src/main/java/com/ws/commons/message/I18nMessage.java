package com.ws.commons.message;

/**
 * Represents the minimal structure of a message internationalization artifact.
 *
 * <p>
 * This class is minimally represented by {@link #getKey()} method, which is used to retrieve they key of the message
 * declared in apache-deltaspike.properties file.
 * </p>
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-07-13
 */
public interface I18nMessage {

    /**
     * Method to retrieve message key from properties' file.
     *
     * @return the message key.
     */
    String getKey();
}
