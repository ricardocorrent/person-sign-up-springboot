package com.ws.commons.message;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

/**
 * PostgreSQL error code group enumerator.
 *
 * <p>
 * This enumerator defines all the classes of errors that can be returned from PostgreSQL operations.<br>
 * For more information about these error classes and its meanings, please take a look at the <a href=https://www.postgresql.org/docs/9.4/static/errcodes-appendix.html>
 * PostgreSQL documentation</a>
 * </p>
 *
 * @author  Lucas Dillmann
 * @see     <a href="https://www.postgresql.org/docs/9.4/static/errcodes-appendix.html">
 *          https://www.postgresql.org/docs/9.4/static/errcodes-appendix.html
 *          </a>
 * @since   6.1.0 - 2018-06-15
 */
public enum EPostgreSQLErrorCodeType implements Serializable {

    WARNING("01", "warning"),
    NO_DATA("02", "noData"),
    STATEMENT_NOT_YET_COMPLETE("03", "statementNotYetComplete"),
    CONNECTION_EXCEPTION("08", "connectionException", true),
    TRIGGERED_ACTION_EXCEPTION("09", "triggeredActionException"),
    FEATURE_NOT_SUPPORTED("0A", "featureNotSupported"),
    INVALID_TRANSACTION_INITIATION("0B", "invalidTransactionInitiation"),
    LOCATOR_EXCEPTION("0F", "locatorException"),
    INVALID_GRANTOR("0L", "invalidGrantor", true),
    INVALID_ROLE_ESPECIFICATION("0P", "invalidRoleEspecification", true),
    DIAGNOSTICS_EXCEPTION("0Z", "diagnosticsException", true),
    CASE_NOT_FOUND("20", "caseNotFound"),
    CARDINALITY_VIOLATION("21", "cardinalityViolation"),
    DATA_EXCEPTION("22", "dataException"),
    INTEGRITY_CONSTRAINT_VIOLATION("23", "integrityConstraintViolation"),
    INVALID_CURSOR_STATE("24", "invalidCursorState", true),
    INVALID_TRANSACTION_STATE("25", "invalidTransactionState"),
    INVALID_SQL_STATEMENT_NAME("26", "invalidSqlStatementName"),
    TRIGGERED_DATA_CHANGE_VIOLATION("27", "triggeredDataChangeViolation"),
    INVALID_AUTHORIZATION_SPECIFICATION("28", "invalidAuthorizationSpecification", true),
    DEPENDENT_PRIVILEGE_DESCRIPTORS_STILL_EXIST("2B", "dependentPrivilegeDescriptorStillExist", true),
    INVALID_TRANSACTION_TERMINATION("2D", "invalidTransactionTermination"),
    SQL_ROUTINE_EXCEPTION("2F", "sqlRoutineException"),
    INVALID_CURSOR_NAME("34", "invalidCursorName", true),
    EXTERNAL_ROUTINE_EXCEPTION("38", "externalRoutineException"),
    EXTERNAL_ROUTINE_INVOCATION_EXCEPTION("39", "externalRoutineInvocationException"),
    SAVEPOINT_EXCEPTION("3B", "savepointException", true),
    INVALID_CATALOG_NAME("3D", "invalidCatalogName", true),
    INVALID_SCHEMA_NAME("3F", "invalidSchemaName", true),
    TRANSACTION_ROLLBACK("40", "transactionRollback"),
    SYNTAX_ERROR_OR_ACCESS_VIOLATION("42", "syntaxErrorOrAccessRuleViolation"),
    WITH_CHECK_OPTION_VIOLATION("44", "withCheckOptionViolation"),
    INSUFFICIENT_RESOURCES("53", "insufficientResources", true),
    PROGRAM_LIMIT_EXCEEDED("54", "programLimitExceeded", true),
    OBJECT_NOT_IN_PREREQUISITE_STATE("55", "objectNotInRequiredState", true),
    OPERATOR_INTERVATION("57", "operatorIntervention", true),
    SYSTEM_ERROR("58", "systemError", true),
    SNAPSOT_FAILURE("72", "snapshotFailure", true),
    CONFIGURATION_FILE_ERROR("F0", "configurationError", true),
    FOREIGN_DATA_WRAPPER_ERROR("HV", "foreignDataWrapperError", true),
    PLPGSQL_ERROR("P0", "plpgsqlError", true),
    INTERNAL_ERROR("XX", "internalError", true);

    private final String classCode;
    private final String description;
    private final boolean sensitiveError;

    /**
     * Default enumeration constructor.
     *
     * @param classCode   error type class code
     * @param description error type internationalization key
     * @since 6.1.0 - 2018-06-05
     */
    EPostgreSQLErrorCodeType(final String classCode, final String description) {
        this.description = getClass().getName() + "." + description;
        this.classCode = classCode;
        this.sensitiveError = false;
    }

    /**
     * Alternative enumeration constructor with error class code, error description and
     * if error has sensitive information flag.
     *
     * @param classCode      error type class code
     * @param description    error type internationalization key
     * @param sensitiveError error sensitive information flag
     * @since 6.1.0 - 2018-06-05
     */
    EPostgreSQLErrorCodeType(final String classCode, final String description, final boolean sensitiveError) {
        this.description = getClass().getName() + "." + description;
        this.classCode = classCode;
        this.sensitiveError = sensitiveError;
    }

    /**
     * Retrieves the PostgreSQL error class code
     *
     * @return the error class code
     */
    public String getClassCode() {
        return classCode;
    }

    /**
     * Retrieves the PostgreSQL error class description
     *
     * @return the error class description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Enumeration access method by PostgreSQL error code.
     *
     * @param code PostgreSQL error code
     * @return     enumeration instance for given error code
     * @since 6.1.0 - 2018-06-05
     */
    public static final EPostgreSQLErrorCodeType getByCode(String code) {

        Objects.requireNonNull(code, "Class code cannot be null");

        if(code.length() > 2) {
            code = code.substring(0, 2);
        }

        final String searchCode = code;
        return Arrays
                .stream(values())
                .filter(item -> item.classCode.equals(searchCode))
                .findAny()
                .orElse(null);
    }

    /**
     * Verifies if the error type has a sensitive information.
     *
     * @return {@code true} if the current error type has aa sensitive information
     * @since 6.1.0 - 2018-06-15
     */
    public boolean isSensitiveError() {
        return sensitiveError;
    }
}
