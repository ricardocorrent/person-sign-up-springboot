package com.ws.commons.message;

/**
 * Enumerator that maps useful message's keys defined at an internationalization file.
 *
 * @author  Diego Armange Costa
 * @see     I18nMessage
 * @since   5.0.0 2017-07-31
 */
public enum EMessage implements I18nMessage {
    
    /**
     * <pre>
     * Key: entity.not.found.with.id
     * {0}: Entity name.
     * {1}: Id value.
     * </pre>
     */
    ENTITY_NOT_FOUND_WITH_ID("entity.not.found.with.id"),
    
    /**
     * <pre>
     * Key: error.on.inserting.entity
     * {0}: Entity name.
     * {1}: Id value.
     * </pre>
     */
    ERROR_ON_INSERTING_ENTITY("error.on.inserting.entity"),
    
    /**
     * <pre>
     * Key: id.has.relations
     * {0}: Id value.
     * </pre>
     */
    ID_HAS_RELATIONS("id.has.relations"),
    
    /**
     * <pre>
     * Key: error.on.deleting.id
     * {0}: Entity to be deleted.
     * {1}: ID value.
     * </pre>
     */
    ERROR_ON_DELETION_WITH_ID("error.on.deletion.with.id"),

    /**
     * <pre>
     * Key: commons.projection.mapping.invalidPaths
     * {0}: Invalid paths separated by commas.
     * </pre>
     */
    PROJECTION_MAPPING_INVALIDPATHS("commons.projection.mapping.invalidPaths"),
    
    ;
    
    private String key;
    
    EMessage(final String key) {
        this.key = key;
    }
    
    /**
     * @see com.ws.commons.message.I18nMessage#getKey()
     */
    @Override
    public String getKey() {
        return this.key;
    }
}
