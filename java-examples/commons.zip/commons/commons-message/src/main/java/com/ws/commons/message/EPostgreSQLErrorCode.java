package com.ws.commons.message;

import javax.persistence.PersistenceException;
import java.sql.SQLException;
import java.util.Objects;

/**
 * Enumerates the main errors of PostgreSQL and manipulate them through exceptions of type {@link PersistenceException}.
 *
 * <p>
 * For more information, please consult PostgreSQL error codes:
 * <a href="https://www.postgresql.org/docs/9.4/static/errcodes-appendix.html">https://www.postgresql.org/docs/9.4/static/errcodes-appendix.html</a>
 * </p>
 *
 * <p>
 * Besides, it also provides methods to verify those related errors, such as {@link #getErrorByException(Throwable)} and
 * {@link #isMatchedException(Throwable)}.
 * </p>
 *
 * @author  Diego Armange Costa
 * @author  Lucas Dillmann
 * @version 6.1.0 - 2018-06-05
 * @since   3.0.0 2017-07-14
 */
public enum EPostgreSQLErrorCode {

    WARNING("01000", "warning"),
    DYNAMIC_RESULT_SETS_RETURNED("0100C", "dynamicResultSetsReturned"),
    IMPLICIT_ZERO_BIT_PADDING("01008", "implicitZeroBitPadding"),
    NULL_VALUE_ELIMINATED_IN_SET_FUNCTION("01003", "nullValueEliminatedInSetFunction"),
    PRIVILEGE_NOT_GRANTED("01007", "privilegeNotGranted"),
    PRIVILEGE_NOT_REVOKED("01006", "privilegeNotRevoked"),
    WARN_STRING_DATA_RIGHT_TRUNCATION("01004", "warnStringDataRightTruncation"),
    DEPRECATED_FEATURE("01P01", "deprecatedFeature"),
    NO_DATA("02000", "noData"),
    NO_ADDITIONAL_DYNAMIC_RESULT_SETS_RETURNED("02001", "noAdditionalDynamicResultSetsReturned"),
    SQL_STATEMENT_NOT_YET_COMPLETE("03000", "sqlStatementNotYetComplete"),
    CONNECTION_EXCEPTION("08000", "connectionException"),
    CONNECTION_DOES_NOT_EXIST("08003", "connectionDoesNotExist"),
    CONNECTION_FAILURE("08006", "connectionFailure"),
    SQLCLIENT_UNABLE_TO_ESTABLISH_SQLCONNECTION("08001", "sqlclientUnableToEstablishSqlconnection"),
    SQLSERVER_REJECTED_ESTABLISHMENT_OF_SQLCONNECTION("08004", "sqlserverRejectedEstablishmentOfSqlconnection"),
    TRANSACTION_RESOLUTION_UNKNOWN("08007", "transactionResolutionUnknown"),
    PROTOCOL_VIOLATION("08P01", "protocolViolation"),
    TRIGGERED_ACTION_EXCEPTION("09000", "triggeredActionException"),
    FEATURE_NOT_SUPPORTED("0A000", "featureNotSupported"),
    INVALID_TRANSACTION_INITIATION("0B000", "invalidTransactionInitiation"),
    LOCATOR_EXCEPTION("0F000", "locatorException"),
    INVALID_LOCATOR_SPECIFICATION("0F001", "invalidLocatorSpecification"),
    INVALID_GRANTOR("0L000", "invalidGrantor"),
    INVALID_GRANT_OPERATION("0LP01", "invalidGrantOperation"),
    INVALID_ROLE_SPECIFICATION("0P000", "invalidRoleSpecification"),
    DIAGNOSTICS_EXCEPTION("0Z000", "diagnosticsException"),
    STACKED_DIAGNOSTICS_ACCESSED_WITHOUT_ACTIVE_HANDLER("0Z002", "stackedDiagnosticsAccessedWithoutActiveHandler"),
    CASE_NOT_FOUND("20000", "caseNotFound"),
    CARDINALITY_VIOLATION("21000", "cardinalityViolation"),
    DATA_EXCEPTION("22000", "dataException"),
    ARRAY_SUBSCRIPT_ERROR("2202E", "arraySubscriptError"),
    CHARACTER_NOT_IN_REPERTOIRE("22021", "characterNotInRepertoire"),
    DATETIME_FIELD_OVERFLOW("22008", "datetimeFieldOverflow"),
    DIVISION_BY_ZERO("22012", "divisionByZero"),
    ERROR_IN_ASSIGNMENT("22005", "errorInAssignment"),
    ESCAPE_CHARACTER_CONFLICT("2200B", "escapeCharacterConflict"),
    INDICATOR_OVERFLOW("22022", "indicatorOverflow"),
    INTERVAL_FIELD_OVERFLOW("22015", "intervalFieldOverflow"),
    INVALID_ARGUMENT_FOR_LOGARITHM("2201E", "invalidArgumentForLogarithm"),
    INVALID_ARGUMENT_FOR_NTILE_FUNCTION("22014", "invalidArgumentForNtileFunction"),
    INVALID_ARGUMENT_FOR_NTH_VALUE_FUNCTION("22016", "invalidArgumentForNthValueFunction"),
    INVALID_ARGUMENT_FOR_POWER_FUNCTION("2201F", "invalidArgumentForPowerFunction"),
    INVALID_ARGUMENT_FOR_WIDTH_BUCKET_FUNCTION("2201G", "invalidArgumentForWidthBucketFunction"),
    INVALID_CHARACTER_VALUE_FOR_CAST("22018", "invalidCharacterValueForCast"),
    INVALID_DATETIME_FORMAT("22007", "invalidDatetimeFormat"),
    INVALID_ESCAPE_CHARACTER("22019", "invalidEscapeCharacter"),
    INVALID_ESCAPE_OCTET("2200D", "invalidEscapeOctet"),
    INVALID_ESCAPE_SEQUENCE("22025", "invalidEscapeSequence"),
    NONSTANDARD_USE_OF_ESCAPE_CHARACTER("22P06", "nonstandardUseOfEscapeCharacter"),
    INVALID_INDICATOR_PARAMETER_VALUE("22010", "invalidIndicatorParameterValue"),
    INVALID_PARAMETER_VALUE("22023", "invalidParameterValue"),
    INVALID_REGULAR_EXPRESSION("2201B", "invalidRegularExpression"),
    INVALID_ROW_COUNT_IN_LIMIT_CLAUSE("2201W", "invalidRowCountInLimitClause"),
    INVALID_ROW_COUNT_IN_RESULT_OFFSET_CLAUSE("2201X", "invalidRowCountInResultOffsetClause"),
    INVALID_TABLESAMPLE_ARGUMENT("2202H", "invalidTablesampleArgument"),
    INVALID_TABLESAMPLE_REPEAT("2202G", "invalidTablesampleRepeat"),
    INVALID_TIME_ZONE_DISPLACEMENT_VALUE("22009", "invalidTimeZoneDisplacementValue"),
    INVALID_USE_OF_ESCAPE_CHARACTER("2200C", "invalidUseOfEscapeCharacter"),
    MOST_SPECIFIC_TYPE_MISMATCH("2200G", "mostSpecificTypeMismatch"),
    NULL_VALUE_NOT_ALLOWED("22004", "nullValueNotAllowed"),
    NULL_VALUE_NO_INDICATOR_PARAMETER("22002", "nullValueNoIndicatorParameter"),
    NUMERIC_VALUE_OUT_OF_RANGE("22003", "numericValueOutOfRange"),
    SEQUENCE_GENERATOR_LIMIT_EXCEEDED("2200H", "sequenceGeneratorLimitExceeded"),
    STRING_DATA_LENGTH_MISMATCH("22026", "stringDataLengthMismatch"),
    STRING_DATA_RIGHT_TRUNCATION("22001", "stringDataRightTruncation"),
    SUBSTRING_ERROR("22011", "substringError"),
    TRIM_ERROR("22027", "trimError"),
    UNTERMINATED_C_STRING("22024", "unterminatedCString"),
    ZERO_LENGTH_CHARACTER_STRING("2200F", "zeroLengthCharacterString"),
    FLOATING_POINT_EXCEPTION("22P01", "floatingPointException"),
    INVALID_TEXT_REPRESENTATION("22P02", "invalidTextRepresentation"),
    INVALID_BINARY_REPRESENTATION("22P03", "invalidBinaryRepresentation"),
    BAD_COPY_FILE_FORMAT("22P04", "badCopyFileFormat"),
    UNTRANSLATABLE_CHARACTER("22P05", "untranslatableCharacter"),
    NOT_AN_XML_DOCUMENT("2200L", "notAnXmlDocument"),
    INVALID_XML_DOCUMENT("2200M", "invalidXmlDocument"),
    INVALID_XML_CONTENT("2200N", "invalidXmlContent"),
    INVALID_XML_COMMENT("2200S", "invalidXmlComment"),
    INVALID_XML_PROCESSING_INSTRUCTION("2200T", "invalidXmlProcessingInstruction"),
    INTEGRITY_CONSTRAINT_VIOLATION("23000", "integrityConstraintViolation"),
    RESTRICT_VIOLATION("23001", "restrictViolation"),
    NOT_NULL_VIOLATION("23502", "notNullViolation"),
    FOREIGN_KEY_VIOLATION("23503", "foreignKeyViolation"),
    UNIQUE_VIOLATION("23505", "uniqueViolation"),
    CHECK_VIOLATION("23514", "checkViolation"),
    EXCLUSION_VIOLATION("23P01", "exclusionViolation"),
    INVALID_CURSOR_STATE("24000", "invalidCursorState"),
    INVALID_TRANSACTION_STATE("25000", "invalidTransactionState"),
    ACTIVE_SQL_TRANSACTION("25001", "activeSqlTransaction"),
    BRANCH_TRANSACTION_ALREADY_ACTIVE("25002", "branchTransactionAlreadyActive"),
    HELD_CURSOR_REQUIRES_SAME_ISOLATION_LEVEL("25008", "heldCursorRequiresSameIsolationLevel"),
    INAPPROPRIATE_ACCESS_MODE_FOR_BRANCH_TRANSACTION("25003", "inappropriateAccessModeForBranchTransaction"),
    INAPPROPRIATE_ISOLATION_LEVEL_FOR_BRANCH_TRANSACTION("25004", "inappropriateIsolationLevelForBranchTransaction"),
    NO_ACTIVE_SQL_TRANSACTION_FOR_BRANCH_TRANSACTION("25005", "noActiveSqlTransactionForBranchTransaction"),
    READ_ONLY_SQL_TRANSACTION("25006", "readOnlySqlTransaction"),
    SCHEMA_AND_DATA_STATEMENT_MIXING_NOT_SUPPORTED("25007", "schemaAndDataStatementMixingNotSupported"),
    NO_ACTIVE_SQL_TRANSACTION("25P01", "noActiveSqlTransaction"),
    IN_FAILED_SQL_TRANSACTION("25P02", "inFailedSqlTransaction"),
    IDLE_IN_TRANSACTION_SESSION_TIMEOUT("25P03", "idleInTransactionSessionTimeout"),
    INVALID_SQL_STATEMENT_NAME("26000", "invalidSqlStatementName"),
    TRIGGERED_DATA_CHANGE_VIOLATION("27000", "triggeredDataChangeViolation"),
    INVALID_AUTHORIZATION_SPECIFICATION("28000", "invalidAuthorizationSpecification"),
    INVALID_PASSWORD("28P01", "invalidPassword"),
    DEPENDENT_PRIVILEGE_DESCRIPTORS_STILL_EXIST("2B000", "dependentPrivilegeDescriptorsStillExist"),
    DEPENDENT_OBJECTS_STILL_EXIST("2BP01", "dependentObjectsStillExist"),
    INVALID_TRANSACTION_TERMINATION("2D000", "invalidTransactionTermination"),
    SQL_ROUTINE_EXCEPTION("2F000", "sqlRoutineException"),
    FUNCTION_EXECUTED_NO_RETURN_STATEMENT("2F005", "functionExecutedNoReturnStatement"),
    MODIFYING_SQL_DATA_NOT_PERMITTED_EXCEPTION("2F002", "modifyingSqlDataNotPermittedException"),
    PROHIBITED_SQL_STATEMENT_ATTEMPTED_EXCEPTION("2F003", "prohibitedSqlStatementAttemptedException"),
    READING_SQL_DATA_NOT_PERMITTED("2F004", "readingSqlDataNotPermitted"),
    INVALID_CURSOR_NAME("34000", "invalidCursorName"),
    EXTERNAL_ROUTINE_EXCEPTION("38000", "externalRoutineException"),
    CONTAINING_SQL_NOT_PERMITTED("38001", "containingSqlNotPermitted"),
    MODIFYING_SQL_DATA_NOT_PERMITTED("38002", "modifyingSqlDataNotPermitted"),
    PROHIBITED_SQL_STATEMENT_ATTEMPTED("38003", "prohibitedSqlStatementAttempted"),
    READING_SQL_DATA_NOT_PERMITTED_EXCEPTION("38004", "readingSqlDataNotPermittedException"),
    EXTERNAL_ROUTINE_INVOCATION_EXCEPTION("39000", "externalRoutineInvocationException"),
    INVALID_SQLSTATE_RETURNED("39001", "invalidSqlstateReturned"),
    NULL_VALUE_NOT_ALLOWED_EXTERNAL("39004", "nullValueNotAllowedExternal"),
    TRIGGER_PROTOCOL_VIOLATED("39P01", "triggerProtocolViolated"),
    SRF_PROTOCOL_VIOLATED("39P02", "srfProtocolViolated"),
    EVENT_TRIGGER_PROTOCOL_VIOLATED("39P03", "eventTriggerProtocolViolated"),
    SAVEPOINT_EXCEPTION("3B000", "savepointException"),
    INVALID_SAVEPOINT_SPECIFICATION("3B001", "invalidSavepointSpecification"),
    INVALID_CATALOG_NAME("3D000", "invalidCatalogName"),
    INVALID_SCHEMA_NAME("3F000", "invalidSchemaName"),
    TRANSACTION_ROLLBACK("40000", "transactionRollback"),
    TRANSACTION_INTEGRITY_CONSTRAINT_VIOLATION("40002", "transactionIntegrityConstraintViolation"),
    SERIALIZATION_FAILURE("40001", "serializationFailure"),
    STATEMENT_COMPLETION_UNKNOWN("40003", "statementCompletionUnknown"),
    DEADLOCK_DETECTED("40P01", "deadlockDetected"),
    SYNTAX_ERROR_OR_ACCESS_RULE_VIOLATION("42000", "syntaxErrorOrAccessRuleViolation"),
    SYNTAX_ERROR("42601", "syntaxError"),
    INSUFFICIENT_PRIVILEGE("42501", "insufficientPrivilege"),
    CANNOT_COERCE("42846", "cannotCoerce"),
    GROUPING_ERROR("42803", "groupingError"),
    WINDOWING_ERROR("42P20", "windowingError"),
    INVALID_RECURSION("42P19", "invalidRecursion"),
    INVALID_FOREIGN_KEY("42830", "invalidForeignKey"),
    INVALID_NAME("42602", "invalidName"),
    NAME_TOO_LONG("42622", "nameTooLong"),
    RESERVED_NAME("42939", "reservedName"),
    DATATYPE_MISMATCH("42804", "datatypeMismatch"),
    INDETERMINATE_DATATYPE("42P18", "indeterminateDatatype"),
    COLLATION_MISMATCH("42P21", "collationMismatch"),
    INDETERMINATE_COLLATION("42P22", "indeterminateCollation"),
    WRONG_OBJECT_TYPE("42809", "wrongObjectType"),
    GENERATED_ALWAYS("428C9", "generatedAlways"),
    UNDEFINED_COLUMN("42703", "undefinedColumn"),
    UNDEFINED_FUNCTION("42883", "undefinedFunction"),
    UNDEFINED_TABLE("42P01", "undefinedTable"),
    UNDEFINED_PARAMETER("42P02", "undefinedParameter"),
    UNDEFINED_OBJECT("42704", "undefinedObject"),
    DUPLICATE_COLUMN("42701", "duplicateColumn"),
    DUPLICATE_CURSOR("42P03", "duplicateCursor"),
    DUPLICATE_DATABASE("42P04", "duplicateDatabase"),
    DUPLICATE_FUNCTION("42723", "duplicateFunction"),
    DUPLICATE_PREPARED_STATEMENT("42P05", "duplicatePreparedStatement"),
    DUPLICATE_SCHEMA("42P06", "duplicateSchema"),
    DUPLICATE_TABLE("42P07", "duplicateTable"),
    DUPLICATE_ALIAS("42712", "duplicateAlias"),
    DUPLICATE_OBJECT("42710", "duplicateObject"),
    AMBIGUOUS_COLUMN("42702", "ambiguousColumn"),
    AMBIGUOUS_FUNCTION("42725", "ambiguousFunction"),
    AMBIGUOUS_PARAMETER("42P08", "ambiguousParameter"),
    AMBIGUOUS_ALIAS("42P09", "ambiguousAlias"),
    INVALID_COLUMN_REFERENCE("42P10", "invalidColumnReference"),
    INVALID_COLUMN_DEFINITION("42611", "invalidColumnDefinition"),
    INVALID_CURSOR_DEFINITION("42P11", "invalidCursorDefinition"),
    INVALID_DATABASE_DEFINITION("42P12", "invalidDatabaseDefinition"),
    INVALID_FUNCTION_DEFINITION("42P13", "invalidFunctionDefinition"),
    INVALID_PREPARED_STATEMENT_DEFINITION("42P14", "invalidPreparedStatementDefinition"),
    INVALID_SCHEMA_DEFINITION("42P15", "invalidSchemaDefinition"),
    INVALID_TABLE_DEFINITION("42P16", "invalidTableDefinition"),
    INVALID_OBJECT_DEFINITION("42P17", "invalidObjectDefinition"),
    WITH_CHECK_OPTION_VIOLATION("44000", "withCheckOptionViolation"),
    INSUFFICIENT_RESOURCES("53000", "insufficientResources"),
    DISK_FULL("53100", "diskFull"),
    OUT_OF_MEMORY("53200", "outOfMemory"),
    TOO_MANY_CONNECTIONS("53300", "tooManyConnections"),
    CONFIGURATION_LIMIT_EXCEEDED("53400", "configurationLimitExceeded"),
    PROGRAM_LIMIT_EXCEEDED("54000", "programLimitExceeded"),
    STATEMENT_TOO_COMPLEX("54001", "statementTooComplex"),
    TOO_MANY_COLUMNS("54011", "tooManyColumns"),
    TOO_MANY_ARGUMENTS("54023", "tooManyArguments"),
    OBJECT_NOT_IN_PREREQUISITE_STATE("55000", "objectNotInPrerequisiteState"),
    OBJECT_IN_USE("55006", "objectInUse"),
    CANT_CHANGE_RUNTIME_PARAM("55P02", "cantChangeRuntimeParam"),
    LOCK_NOT_AVAILABLE("55P03", "lockNotAvailable"),
    OPERATOR_INTERVENTION("57000", "operatorIntervention"),
    QUERY_CANCELED("57014", "queryCanceled"),
    ADMIN_SHUTDOWN("57P01", "adminShutdown"),
    CRASH_SHUTDOWN("57P02", "crashShutdown"),
    CANNOT_CONNECT_NOW("57P03", "cannotConnectNow"),
    DATABASE_DROPPED("57P04", "databaseDropped"),
    SYSTEM_ERROR("58000", "systemError"),
    IO_ERROR("58030", "ioError"),
    UNDEFINED_FILE("58P01", "undefinedFile"),
    DUPLICATE_FILE("58P02", "duplicateFile"),
    SNAPSHOT_TOO_OLD("72000", "snapshotTooOld"),
    CONFIG_FILE_ERROR("F0000", "configFileError"),
    LOCK_FILE_EXISTS("F0001", "lockFileExists"),
    FDW_ERROR("HV000", "fdwError"),
    FDW_COLUMN_NAME_NOT_FOUND("HV005", "fdwColumnNameNotFound"),
    FDW_DYNAMIC_PARAMETER_VALUE_NEEDED("HV002", "fdwDynamicParameterValueNeeded"),
    FDW_FUNCTION_SEQUENCE_ERROR("HV010", "fdwFunctionSequenceError"),
    FDW_INCONSISTENT_DESCRIPTOR_INFORMATION("HV021", "fdwInconsistentDescriptorInformation"),
    FDW_INVALID_ATTRIBUTE_VALUE("HV024", "fdwInvalidAttributeValue"),
    FDW_INVALID_COLUMN_NAME("HV007", "fdwInvalidColumnName"),
    FDW_INVALID_COLUMN_NUMBER("HV008", "fdwInvalidColumnNumber"),
    FDW_INVALID_DATA_TYPE("HV004", "fdwInvalidDataType"),
    FDW_INVALID_DATA_TYPE_DESCRIPTORS("HV006", "fdwInvalidDataTypeDescriptors"),
    FDW_INVALID_DESCRIPTOR_FIELD_IDENTIFIER("HV091", "fdwInvalidDescriptorFieldIdentifier"),
    FDW_INVALID_HANDLE("HV00B", "fdwInvalidHandle"),
    FDW_INVALID_OPTION_INDEX("HV00C", "fdwInvalidOptionIndex"),
    FDW_INVALID_OPTION_NAME("HV00D", "fdwInvalidOptionName"),
    FDW_INVALID_STRING_LENGTH_OR_BUFFER_LENGTH("HV090", "fdwInvalidStringLengthOrBufferLength"),
    FDW_INVALID_STRING_FORMAT("HV00A", "fdwInvalidStringFormat"),
    FDW_INVALID_USE_OF_NULL_POINTER("HV009", "fdwInvalidUseOfNullPointer"),
    FDW_TOO_MANY_HANDLES("HV014", "fdwTooManyHandles"),
    FDW_OUT_OF_MEMORY("HV001", "fdwOutOfMemory"),
    FDW_NO_SCHEMAS("HV00P", "fdwNoSchemas"),
    FDW_OPTION_NAME_NOT_FOUND("HV00J", "fdwOptionNameNotFound"),
    FDW_REPLY_HANDLE("HV00K", "fdwReplyHandle"),
    FDW_SCHEMA_NOT_FOUND("HV00Q", "fdwSchemaNotFound"),
    FDW_TABLE_NOT_FOUND("HV00R", "fdwTableNotFound"),
    FDW_UNABLE_TO_CREATE_EXECUTION("HV00L", "fdwUnableToCreateExecution"),
    FDW_UNABLE_TO_CREATE_REPLY("HV00M", "fdwUnableToCreateReply"),
    FDW_UNABLE_TO_ESTABLISH_CONNECTION("HV00N", "fdwUnableToEstablishConnection"),
    PLPGSQL_ERROR("P0000", "plpgsqlError"),
    RAISE_EXCEPTION("P0001", "raiseException"),
    NO_DATA_FOUND("P0002", "noDataFound"),
    TOO_MANY_ROWS("P0003", "tooManyRows"),
    ASSERT_FAILURE("P0004", "assertFailure"),
    INTERNAL_ERROR("XX000", "internalError"),
    DATA_CORRUPTED("XX001", "dataCorrupted"),
    INDEX_CORRUPTED("XX002", "indexCorrupted");

    private final String code;
    private final String message;

    /**
     * Default enumeration constructor.
     *
     * @param code    the SQL error code
     * @param message the SQL error message
     */
    EPostgreSQLErrorCode(final String code, final String message) {
        this.code = code;
        this.message = "com.ws.commons.message.EPostgreSQLErrorCode." + message;
    }

    /**
     * Retrieves the corresponding SQL error code.
     *
     * @return the corresponding SQL error code
     */
    public String getCode() {
        return code;
    }

    /**
     * Retrieves the corresponding SQL error message.
     *
     * @return the corresponding SQL error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Checks whether the exception matches the SQL error code.
     *
     * @param throwable to verify SQL error code.
     * @return true if the error code matches.
     * @see SQLException#getSQLState
     */
    public boolean isMatchedException(final Throwable throwable) {
        Objects.requireNonNull(throwable, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("throwable"));

        if (throwable instanceof PersistenceException) {
            PersistenceException persistenceException = (PersistenceException) throwable;

            if (isCausedBySQLException(persistenceException)) {
                return getSQLExceptionCause(persistenceException).getSQLState().equals(this.code);
            }
        }
        return false;
    }

    /**
     * Returns the error code that matches the code found in the exception.
     *
     * @param throwable to verify SQL error code.
     * @return the corresponding error code
     * @see SQLException#getSQLState
     */
    public static EPostgreSQLErrorCode getErrorByException(final Throwable throwable) {
        Objects.requireNonNull(throwable, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("throwable"));

        if (throwable instanceof PersistenceException) {
            PersistenceException persistenceException = (PersistenceException) throwable;

            for (EPostgreSQLErrorCode errorCode : EPostgreSQLErrorCode.values()) {
                if (isCausedBySQLException(persistenceException) && getSQLExceptionCause(persistenceException).getSQLState().equals(errorCode.code)) {
                    return errorCode;
                }
            }
        }
        return null;
    }

    /**
     * Error type access method by current enumeration PostgreSQL error code.
     *
     * @return error type for current error
     * @since 6.1.0 - 2018-06-05
     */
    public EPostgreSQLErrorCodeType getErrorType() {
        return EPostgreSQLErrorCodeType.getByCode(code);
    }

    private static boolean isCausedBySQLException(final PersistenceException persistenceException) {
        return persistenceException.getCause() instanceof SQLException;
    }

    private static SQLException getSQLExceptionCause(final PersistenceException persistenceException) {
        return SQLException.class.cast(persistenceException.getCause());
    }
}
