package com.ws.commons.message;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test cases for {@link EMessage} enumerator retrieval of message's key.
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-15
 */
public class MessageUnitTest {

    /**
     * Tests method {@link EMessage#valueOf(String)}.
     * It covers enum package.
     */
    @Test
    public void validateEnum() {
        assertEquals(EMessage.ENTITY_NOT_FOUND_WITH_ID, EMessage.valueOf("ENTITY_NOT_FOUND_WITH_ID"));
    }
    
    /**
     * Tests retrieval of {@link EMessage#ENTITY_NOT_FOUND_WITH_ID} message key.
     * It must return the key.
     */
    @Test
    public void entityNotFoundWithId() {
        assertEquals("entity.not.found.with.id", EMessage.ENTITY_NOT_FOUND_WITH_ID.getKey());
    }
    
    /**
     * Tests retrieval of {@link EMessage#ERROR_ON_DELETION_WITH_ID} message key.
     * It must return the key.
     */
    @Test
    public void errorOnIsertingEntity() {
        assertEquals("error.on.inserting.entity", EMessage.ERROR_ON_INSERTING_ENTITY.getKey());
    }
    
    /**
     * Tests retrieval of {@link EMessage#ID_HAS_RELATIONS} message key.
     * It must return the key.
     */
    @Test
    public void isHasRelations() {
        assertEquals("id.has.relations", EMessage.ID_HAS_RELATIONS.getKey());
    }
    
    /**
     * Tests retrieval of {@link EMessage#ERROR_ON_DELETION_WITH_ID} message key.
     * It must return the key.
     */
    @Test
    public void errorOnDeletionWithId() {
        assertEquals("error.on.deletion.with.id", EMessage.ERROR_ON_DELETION_WITH_ID.getKey());
    }
    
    /**
     * Tests retrieval of {@link EMessage#PROJECTION_MAPPING_INVALIDPATHS} message key.
     * It must return the key.
     */
    @Test
    public void projectionMappingIvalidPaths() {
        assertEquals("commons.projection.mapping.invalidPaths", EMessage.PROJECTION_MAPPING_INVALIDPATHS.getKey());
    }
}
