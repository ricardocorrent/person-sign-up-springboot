package com.ws.commons.message;

import org.junit.Test;

import javax.persistence.PersistenceException;
import java.sql.SQLException;

import static org.junit.Assert.*;

/**
 * Unit test cases for {@link EPostgreSQLErrorCode} enumerator codes retrieval.
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-15
 */
public class PostgreSQLErrorCodeUnitTest {

    /**
     * Tests method {@link EPostgreSQLErrorCode#valueOf(String)}.
     * It covers enum package.
     */
    @Test
    public void validateEnum() {
        assertEquals(EPostgreSQLErrorCode.INTEGRITY_CONSTRAINT_VIOLATION, EPostgreSQLErrorCode.valueOf("INTEGRITY_CONSTRAINT_VIOLATION"));
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#INTEGRITY_CONSTRAINT_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void integrityConstraintViolation() {
        assertEquals("23000", EPostgreSQLErrorCode.INTEGRITY_CONSTRAINT_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#RESTRICT_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void restrictViolation() {
        assertEquals("23001", EPostgreSQLErrorCode.RESTRICT_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#NOT_NULL_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void notNullViolation() {
        assertEquals("23502", EPostgreSQLErrorCode.NOT_NULL_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#FOREIGN_KEY_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void foreignKeyViolation() {
        assertEquals("23503", EPostgreSQLErrorCode.FOREIGN_KEY_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#UNIQUE_VIOLATION} code.
     * it must assert the code.
     */
    @Test
    public void uniqueViolation() {
        assertEquals("23505", EPostgreSQLErrorCode.UNIQUE_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#CHECK_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void checkViolation() {
        assertEquals("23514", EPostgreSQLErrorCode.CHECK_VIOLATION.getCode());
    }
    
    /**
     * Tests retrieval of {@link EPostgreSQLErrorCode#CHECK_VIOLATION} code.
     * It must assert the code.
     */
    @Test
    public void exclusionViolation() {
        assertEquals("23P01", EPostgreSQLErrorCode.EXCLUSION_VIOLATION.getCode());
    }
    
    /**
     * Tests if a {@link PersistenceException} matches a {@link EPostgreSQLErrorCode}.
     * It must return true.
     */
    @Test
    public void isMatchedException() {
        final SQLException sqlException = new SQLException("Test", "23P01", 0);
        
        final PersistenceException persistenceException = new PersistenceException();
        
        persistenceException.initCause(sqlException);
        
        assertTrue(EPostgreSQLErrorCode.EXCLUSION_VIOLATION.isMatchedException(persistenceException));
    }
    
    /**
     * Tests if any another exception matches a {@link EPostgreSQLErrorCode}.
     * It must return false.
     */
    @Test
    public void isNotMatchedException() {
        final NullPointerException nullPointerException = new NullPointerException();
        
        assertFalse(EPostgreSQLErrorCode.EXCLUSION_VIOLATION.isMatchedException(nullPointerException));
    }
    
    /**
     * Tests when a {@link PersistenceException} caused by a {@link SQLException} that doesn't match
     * another known {@link EPostgreSQLErrorCode}.
     * It must return false.
     */
    @Test
    public void isNotMatchedCode() {
        final SQLException sqlException = new SQLException("Test", "23503", 0);
        
        final PersistenceException persistenceException = new PersistenceException();
        
        persistenceException.initCause(sqlException);
        
        assertFalse(EPostgreSQLErrorCode.EXCLUSION_VIOLATION.isMatchedException(persistenceException));
    }
    
    /**
     * Tests when a {@link PersistenceException} is not caused by a {@link SQLException}. Additionally, it doesn't have
     * any code that matches with an enum constant from {@link EPostgreSQLErrorCode}
     * It must return false.
     */
    @Test
    public void isNotMatchedCause() {
        final NullPointerException nullPointerException = new NullPointerException();
        
        final PersistenceException persistenceException = new PersistenceException();
        
        persistenceException.initCause(nullPointerException);
        
        assertFalse(EPostgreSQLErrorCode.EXCLUSION_VIOLATION.isMatchedException(persistenceException));
    }
    
    /**
     * Tests when a {@link PersistenceException} doesn't have any cause. Since it doesn't have any {@link EPostgreSQLErrorCode},
     * its method must return false.
     */
    @Test
    public void isNotMatchedWhenHasNoCause() {
        final PersistenceException persistenceException = new PersistenceException();
        
        assertFalse(EPostgreSQLErrorCode.EXCLUSION_VIOLATION.isMatchedException(persistenceException));
    }
    
    /**
     * Tests if an {@link SQLException} is identified correctly by retrieving it through its code in method
     * {@link EPostgreSQLErrorCode#getErrorByException(Throwable)}
     * It must return the correct code.
     */
    @Test
    public void getErrorByException() {
        final String sqlState = "23P01";
        
        final SQLException sqlException = new SQLException("Test", sqlState, 0);
        
        final PersistenceException persistenceException = new PersistenceException();
        
        persistenceException.initCause(sqlException);
        
        assertEquals(sqlState, EPostgreSQLErrorCode.getErrorByException(persistenceException).getCode());
    }
    
    /**
     * Tests error retrieval on {@link EPostgreSQLErrorCode#getErrorByException(Throwable)} call when parameter is an
     * exception that doesn't match any {@link SQLException} error listed on {@link EPostgreSQLErrorCode} enumerator.
     * The method must return null.
     */
    @Test
    public void getNullErrorByNotMatchedException() {
        final NullPointerException nullPointerException = new NullPointerException();
        
        assertEquals(null, EPostgreSQLErrorCode.getErrorByException(nullPointerException));
    }
    
    /**
     * Tests error retrieval on {@link EPostgreSQLErrorCode#getErrorByException(Throwable)} when a
     * {@link PersistenceException} is caused by an exception that doesn't match any {@link SQLException} error listed
     * on {@link EPostgreSQLErrorCode} enumerator.
     * The method must return null.
     */
    @Test
    public void getNullErrorByNotMatchedCause() {
        final NullPointerException nullPointerException = new NullPointerException();
        
        final PersistenceException persistenceException = new PersistenceException();
        
        persistenceException.initCause(nullPointerException);
        
        assertEquals(null, EPostgreSQLErrorCode.getErrorByException(persistenceException));
    }
    
    /**
     * Tests error retrieval on {@link EPostgreSQLErrorCode#getErrorByException(Throwable)} when a
     * {@link PersistenceException} is thrown with no cause.
     * It must return null.
     */
    @Test
    public void getNullErrorWhenHasNoCause() {
        final PersistenceException persistenceException = new PersistenceException();
        
        assertEquals(null, EPostgreSQLErrorCode.getErrorByException(persistenceException));
    }
}
