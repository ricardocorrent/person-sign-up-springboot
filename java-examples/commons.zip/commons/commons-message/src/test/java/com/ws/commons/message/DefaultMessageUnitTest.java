package com.ws.commons.message;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test cases for {@link EDefaultMessage} retrieval of unformatted messages.
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-15
 */
public class DefaultMessageUnitTest {

    /**
     * Tests method {@link EDefaultMessage#valueOf(String)}.
     * It covers enum package.
     */
    @Test
    public void validateEnum() {
        assertEquals(EDefaultMessage.PARAMETER_CANNOT_BE_NULL, EDefaultMessage.valueOf("PARAMETER_CANNOT_BE_NULL"));
    }
    
    /**
     * Tests retrieval of {@link EDefaultMessage#PARAMETER_CANNOT_BE_NULL} unformatted message.
     * It must return the unformatted message.
     */
    @Test
    public void parameterNotNull() {
        assertEquals("The {0} parameter cannot be null.", EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getUnformattedMessage());
    }
    
    /**
     * Tests retrieval of {@link EDefaultMessage#PARAMETER_CANNOT_BE_EMPTY} unformatted message.
     * It must return the unformatted message.
     */
    @Test
    public void parameterNotEmpty() {
        assertEquals("The {0} parameter cannot be empty.", EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getUnformattedMessage());
    }
    
    /**
     * Tests retrieval of {@link EDefaultMessage#PARAMETER_MUST_BE_POSITIVE} unformatted message.
     * It must return the unformatted message.
     */
    @Test
    public void positiveParameter() {
        assertEquals("The {0} parameter must be positive.", EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getUnformattedMessage());
    }
    
    /**
     * Tests successful retrieval of {@link EDefaultMessage#ARRAY_CONTAIN_NULL_VALUE_AT} unformatted message.
     * It must return the unformatted message.
     */
    @Test
    public void arrayContainingNullValue() {
        assertEquals("The {0} array contain a null value at position {1}.", EDefaultMessage.ARRAY_CONTAIN_NULL_VALUE_AT.getUnformattedMessage());
    }
    
    /**
     * Tests successful retrieval of {@link EDefaultMessage#ELEMENT_NOT_DEFINED_IN_CLASS} unformatted message.
     * It must return the unformatted message.
     */
    @Test
    public void elementNotDefinedInClass() {
        assertEquals("The {0} is not defined in {1}.", EDefaultMessage.ELEMENT_NOT_DEFINED_IN_CLASS.getUnformattedMessage());
    }
}
