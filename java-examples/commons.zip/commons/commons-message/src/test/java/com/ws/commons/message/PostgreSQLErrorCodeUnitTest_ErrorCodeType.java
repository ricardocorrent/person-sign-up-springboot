package com.ws.commons.message;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Unit test cases for {@link EPostgreSQLErrorCode} and {@link EPostgreSQLErrorCodeType}.
 *
 * @author  Lucas Dillmann
 * @since   6.1.0 - 2018-06-18
 */
@RunWith(Parameterized.class)
public class PostgreSQLErrorCodeUnitTest_ErrorCodeType {

    private final EPostgreSQLErrorCode errorCode;

    /**
     * Parametrized test constructor.
     *
     * @author          Lucas Dillmann
     * @param errorCode error code to be testes
     * @since           6.1.0 - 2018-06-18
     */
    public PostgreSQLErrorCodeUnitTest_ErrorCodeType(EPostgreSQLErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Tests {@link EPostgreSQLErrorCode#values()} data generation method.
     *
     * @author  Lucas Dillmann
     * @return  all available {@link EPostgreSQLErrorCode}
     * @since   6.1.0 - 2018-06-18
     */
    @Parameterized.Parameters(name = "Error code {0}")
    public static Object[] getData() {
        return EPostgreSQLErrorCode.values();
    }

    /**
     * Test case for {@link EPostgreSQLErrorCode#getErrorType()} to check if
     * given instance has a valid associated {@link EPostgreSQLErrorCodeType}.
     *
     * @author  Lucas Dillmann
     * @since   6.1.0 - 2018-06-18
     */
    @Test
    public void shouldHaveAnValidErrorCodeType() {
        assertThat(errorCode.getErrorType(), Matchers.isA(EPostgreSQLErrorCodeType.class));
    }
}
