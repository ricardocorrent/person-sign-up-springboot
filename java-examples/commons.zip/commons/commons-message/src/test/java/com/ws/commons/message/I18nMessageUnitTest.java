package com.ws.commons.message;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test cases for {@link I18nMessage} implementation on {@link EMessage}.
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-13
 */
public class I18nMessageUnitTest {

    /**
     * Tests {@link EMessage#getKey()} method retrieving a message's key.
     * It must return the key.
     */
    @Test
    public void getMessage() {
        Assert.assertEquals("entity.not.found.with.id", EMessage.ENTITY_NOT_FOUND_WITH_ID.getKey());
    }
}
