package com.ws.commons.persistence.model;

/**
 * This interface is meant to register the URI in which a persistence action was sent.
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-03-23
 */
public interface PathAudit {

    /**
     * @return  the URI in which a persistence action was sent to be retrieved.
     * @see     <a href="https://tools.ietf.org/html/rfc3986">URI RFC3986</a>
     */
    String getResourceUri();
    
    /**
     * @param resourceUri the URI in which a persistence action was sent to be set.
     * @see               <a href="https://tools.ietf.org/html/rfc3986">URI RFC3986</a>
     */
    void setResourceUri(final String resourceUri);
}
