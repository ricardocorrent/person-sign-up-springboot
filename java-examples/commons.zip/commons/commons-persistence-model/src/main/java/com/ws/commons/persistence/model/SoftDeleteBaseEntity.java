package com.ws.commons.persistence.model;

import com.fasterxml.jackson.annotation.JsonView;
import io.ebean.annotation.PreSoftDelete;
import io.ebean.annotation.SoftDelete;

import javax.persistence.*;

/**
 * This implementation allows entities to use SoftDelete with EbeanORM.
 *
 * <p>
 * Entities that extends this class will have an additional {@code deleted} field in database. It means that every deleted
 * record of the table will be marked as deleted, however the registry will be kept with the same data.
 * </p>
 * <p>
 * The following implementations means that any deleted record of 'AnyEntity' in database is marked as 'deleted' and will not
 * be accessible or seen by its services, however, its record will be visible through any DBMS.
 * </p>
 * <pre>
 *     public class AnyEntity extends SoftDeleteBaseEntity {
 *         private String description;
 *
 *         public String getDescription(){
 *             return description;
 *         }
 *
 *         public void setDescription(final String description){
 *             this.description = description;
 *         }
 *     }
 * </pre>
 *
 * @author  Ivan A. Reffatti
 * @author  Rogerio Kiihl
 * @version 6.0.0 - 2018-04-24
 * @since   4.12.0 2017-07-31
 */
@SuppressWarnings("serial")
@MappedSuperclass
public class SoftDeleteBaseEntity extends PhysicalDeleteBaseEntity {

    @SoftDelete @JsonView(Views.Internal.class)
    @AttributeOverride(name = "deleted", column = @Column(name = "deleted"))
    private Boolean deleted;

    /**
     * @return The value indicating whether the template has been deleted.
     */
    public Boolean getDeleted() {
        return deleted;
    }

    private void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }

    /**
     * Method to handle records before insertions
     * <p>
     * The deleted field has the same behavior of the fields {@code createdAt} and {@code updatedAt}.
     * </p>
     * @see PhysicalDeleteBaseEntity#prePersist()
     */
    @PrePersist
    public void prePersist() {
        if (this.getDeleted() == null) {
            this.setDeleted(Boolean.FALSE);
        }
        super.prePersist();
    }

    /**
     * Method to handle records before updates.
     * <p>
     * The deleted field has the same behavior of the fields {@code createdAt} and {@code updatedAt}.
     * </p>
     * @see PhysicalDeleteBaseEntity#preUpdate()
     */
    @PreUpdate
    public void preUpdate() {
        if (this.getDeleted() == null) {
            this.setDeleted(Boolean.FALSE);
        }
        super.preUpdate();
    }

    /**
     * Method to handle records before (soft) deletions.
     *
     * @author  Rogerio Kiihl
     * @since   6.0.0 - 2018-04-24
     */
    @PreSoftDelete
    public void preRemove() {
        // No implementation for now. Coming issue will add functionality
    }
}
