package com.ws.commons.persistence.model;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * This class represents a minimum model of data with an unique identifier.
 * <p>
 * Every entity implementation in a microservice contains this minimal data. This abstract class is extended by
 * {@link SoftDeleteBaseEntity} and {@link PhysicalDeleteBaseEntity} to keep all common fields for all models
 * in a service.
 * </p>
 *
 * @author  Diego Armange Costa
 * @author  Lucas Dillmann
 * @version 7.0.0 - 2018-07-27 - Change from interface to abstract class due to error generating the
 *                               integration client between microservices on Wayland plugin
 * @see     PhysicalDeleteBaseEntity
 * @since   6.0.0 - 2018-02-15
 */
@MappedSuperclass
public abstract class BaseModel implements Serializable, Identification<UUID>{

    /**
     * @see com.ws.commons.persistence.model.Identification#getId()
     */
    public abstract UUID getId();

    /**
     * @see com.ws.commons.persistence.model.Identification#setId(java.lang.Object)
     */
    public abstract void setId(final UUID id);

    /**
     * @return the field value's creation time to be retrieved.
     */
    public abstract OffsetDateTime getCreatedAt();

    /**
     * @param createdAt the field value's creation date and time to be set.
     * */
    public abstract void setCreatedAt(final OffsetDateTime createdAt);

    /**
     * @return the field update time to be retrieved.
     */
    public abstract OffsetDateTime getUpdatedAt();

    /**
     * @param updatedAt the field value's update date and time to be set.
     */
    public abstract void setUpdatedAt(final OffsetDateTime updatedAt);

}
