package com.ws.commons.persistence.dao;

import com.ws.commons.persistence.model.Identification;
import com.ws.commons.persistence.model.RecyclingModel;
import io.ebean.Query;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * RecycleBin operations to collect and persist data from deleted entities.
 *
 * @author      Diego A. Costa
 * @author      Lucas Dillmann
 * @version     6.1.0 - 2018-07-02
 * @since       6.0.0 - 2018-04-03
 * @deprecated  6.1.0 - 2018-07-02 - use RecycleListener or DefaultRecycleListener instead
 */
@Deprecated
public interface RecycleBin {
    
    /**
     * Collects and persists data from deleted entities.
     *
     * @param identification as data model that was deleted.
     */
    void recycle(Identification<UUID> identification);
    
    /**
     * Collects and persists data from deleted entities.
     *
     * @param <T>                   generic type that extends Identification{@code <UUID>}
     * @param <C>                   generic type that extends Collection{@code <T>}
     * @param baseModelCollection   as data models that was deleted.
     */
    <T extends Identification<UUID>, C extends Collection<T>> void recycle(C baseModelCollection);

    /**
     * Collects and persists data from deleted entities.
     *
     * @param <T>           generic type that extends Identification{@code <UUID>}
     * @param id            as identification by which the data model will be located.
     * @param modelClass    as data model.
     */
    <T extends Identification<UUID>> void recycle(UUID id, Class<T> modelClass);

    /**
     * Collects and persists data from deleted entities.
     *
     * @param <T> extends Identification{@code <UUID>}
     * @param ids as identifications by which the data models will be located.
     * @param modelClass as data model.
     */
    <T extends Identification<UUID>> void recycle(Set<UUID> ids, Class<T> modelClass);
    
    /**
     * @param <T>   generic type that extends RecyclingModel
     * @return      a Query-Object to allow custom queries.
     * @see         #find(Query)
     */
    <T extends RecyclingModel> Query<T> getQuery();
    
    /**
     * @param <T>   generic type that extends RecyclingModel
     * @param query containing SQL instructions to retrieve {@link RecyclingModel}s. 
     * @return      an {@link RecyclingModel} list based on {@link Query}-Object instructions.
     */
    <T extends RecyclingModel> List<T> find(Query<T> query);
    
    /**
     * @param baseModel by which the recycling model will be located.
     * @return          the recycled model.
     */
    RecyclingModel find(Identification<UUID> baseModel);
    
    /**
     * @param id    as identification by which the data model will be located.
     * @return      the recycled model.
     */
    RecyclingModel findById(UUID id);
    
    /**
     * @param id as identification by which the data model will be located.
     */
    void delete(UUID id);
    
    /**
     * @param ids as identification by which the data model will be located.
     */
    void delete(Set<UUID> ids);
}
