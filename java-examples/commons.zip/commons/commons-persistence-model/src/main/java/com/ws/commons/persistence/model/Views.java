package com.ws.commons.persistence.model;

/**
 * JSON views used to control the fields that are internal or public.
 *
 * @author  Diego Peliser
 * @since   6.0.0 - 2018-03-16
 */
public class Views {

    /**
     * Default view.
     */
    public static class Public {}

    /**
     * View to use for internal elements.
     */
    public static class Internal {}

}
