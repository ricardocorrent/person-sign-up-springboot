package com.ws.commons.persistence.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.ebean.annotation.EnumValue;

/**
 * Enumerator is used to identify in the environment where a record was created.
 *
 * @author  Gustavo P. Bilert
 * @since   4.3.0 - 2017-03-28
 */
public enum OriginEnvironment {

    /**
     * Indicates that a record was created in the WEB environment.
     */
    @JsonProperty("WEB")
    @EnumValue("WEB")
    WEB,

    /**
     * Indicates that a record was created in the ANDROID environment.
     */
    @JsonProperty("AND")
    @EnumValue("AND")
    ANDROID,

    /**
     * Indicates that a record was created in the IOS environment.
     */
    @JsonProperty("IOS")
    @EnumValue("IOS")
    IOS,

    /**
     * Indicates that a record was created in the EXTERNAL environment.
     */
    @JsonProperty("EXT")
    @EnumValue("EXT")
    EXTERNAL
}
