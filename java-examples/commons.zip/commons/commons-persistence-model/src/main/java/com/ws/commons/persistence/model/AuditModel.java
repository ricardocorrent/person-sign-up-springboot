package com.ws.commons.persistence.model;

import java.util.UUID;

/**
 * Abstract representation of operations performed on audited data.
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-03-23
 * @see     PathAudit
 * @see     TimeAudit
 */
public interface AuditModel extends PathAudit, TimeAudit {

    /**
     * @return the user responsible for the operation performed on the audited data.
     */
    UUID getUserId();
    
    /**
     * @param userId as responsible for the operation performed on the audited data.
     */
    void setUserId(final UUID userId);
    
    /**
     * @return audited data.
     */
    String getData();
    
    /**
     * @param data to be audited.
     */
    void setData(final String data);
}
