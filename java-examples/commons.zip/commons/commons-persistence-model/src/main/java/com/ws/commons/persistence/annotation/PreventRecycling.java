package com.ws.commons.persistence.annotation;

import com.ws.commons.persistence.dao.RecycleBin;
import com.ws.commons.persistence.model.RecyclingEntity;
import com.ws.commons.persistence.model.RecyclingModel;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Entities annotated with this interface will not be subject to the recycling feature during the deletion.
 *
 * @author  Diego A. Costa
 * @see     RecycleBin
 * @see     RecyclingEntity
 * @see     RecyclingModel
 * @since   6.0.0 - 2018-04-06
 */
@Target({ TYPE })
@Retention(RUNTIME)
@Documented
public @interface PreventRecycling {}
