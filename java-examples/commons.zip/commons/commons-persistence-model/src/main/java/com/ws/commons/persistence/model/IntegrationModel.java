package com.ws.commons.persistence.model;

import com.ws.commons.persistence.dto.BaseDTO;

/**
 * This interface represents an integration model.
 * <p>
 * It contains the external ID that represents the primary key of the (external) data model integrated
 * with the local model.
 * </p>
 * <p>
 * It is used by {@link PhysicalDeleteBaseEntity} and {@link BaseDTO} to implement the {@code externalId} database
 * control field.
 * </p>
 * <p>Example:</p>
 * <pre>
 *     public class AnyClass implements IntegrationModel{@literal <String>} {
 *          {@literal @Override}
 *          public String getExternalId() {
 *              return id;
 *          }
 *          {@literal @Override}
 *          public void setId(final String externalId) {
 *              this.externalId = externalId;
 *          }
 *     }
 * </pre>

 * @author      Diego A. Costa
 * @param <T>   as external identification type.
 * @since       6.0.0 - 2018-04-13
 */
public interface IntegrationModel<T> {

    /**
     * @return The entity external identification to be retrieved.
     */
    T getExternalId();

    /**
     * @param externalId The entity external identification to be set.
     */
    void setExternalId(final T externalId);
}
