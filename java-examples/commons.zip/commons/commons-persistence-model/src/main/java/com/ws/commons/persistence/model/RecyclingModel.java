package com.ws.commons.persistence.model;

import java.util.UUID;

/**
 * Interface that represents a model containing data from other deleted models.
 *
 * <p>
 * It is used by {@link RecyclingEntity} to handle deletions of entities.
 * </p>
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-03-23
 */
public interface RecyclingModel extends Identification<UUID>, PathAudit, TimeAudit {}
