package com.ws.commons.persistence.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Recycling representation model of other deleted models.
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-04-02
 */
@Entity
public class RecyclingEntity implements RecyclingModel {

    @Id
    private UUID id;
    
    private String resourceUri;
    
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime performedAt;

    /**
     * Representing the entity id that was recycled.
     * @see com.ws.commons.persistence.model.Identification#getId()
     */
    @Override
    public UUID getId() {
        return this.id;
    }

    /**
     * @see com.ws.commons.persistence.model.Identification#setId(java.lang.Object)
     */
    @Override
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * @see com.ws.commons.persistence.model.PathAudit#getResourceUri()
     */
    @Override
    public String getResourceUri() {
        return resourceUri;
    }

    /**
     * @see com.ws.commons.persistence.model.PathAudit#setResourceUri(java.lang.String)
     */
    @Override
    public void setResourceUri(final String resourceUri) {
        this.resourceUri = resourceUri;
    }

    /**
     * @see com.ws.commons.persistence.model.TimeAudit#getPerformedAt()
     */
    @Override
    public OffsetDateTime getPerformedAt() {
        return performedAt;
    }

    /**
     * @see com.ws.commons.persistence.model.TimeAudit#setPerformedAt(java.time.OffsetDateTime)
     */
    @Override
    public void setPerformedAt(final OffsetDateTime performedAt) {
        this.performedAt = performedAt;
    }
}
