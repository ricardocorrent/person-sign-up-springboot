package com.ws.commons.persistence.model;

import javax.persistence.MappedSuperclass;

/**
 * An entity that extends this class is the main entity of a group of entities that work as one,
 * for example, 'Order' is the main (root) entity and 'OrderItem' is a secondary or subordinate entity.
 *
 * <p>
 * This class applies the rules of a {@link SoftDeleteBaseEntity} to a {@link RootEntity}.
 * </p>
 *
 * @author  Gustavo P. Bilert
 * @author  Diego Armange Costa
 * @version 6.0.0 - 2018-03-26 - Renamed from "RootEntity" to "SoftDeleteRootEntity".
 * @see     SoftDeleteBaseEntity
 * @see     RootEntity
 * @since   4.3.0 - 2017-03-28
 */
@SuppressWarnings("serial")
@MappedSuperclass
public class SoftDeleteRootEntity extends SoftDeleteBaseEntity {

    private OriginEnvironment originEnvironment;

    /**
     * @return the environment where the record was created to be retrieved.
     */
    public OriginEnvironment getOriginEnvironment() {
        return originEnvironment;
    }

    /**
     * @param originEnvironment the environment where the record was created to be set.
     */
    public void setOriginEnvironment(OriginEnvironment originEnvironment) {
        this.originEnvironment = originEnvironment;
    }
}
