package com.ws.commons.persistence.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.persistence.model.IntegrationModel;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * <p>
 * This class represents a base DTO. It provides common fields for all entity representations.
 * </p>
 * <p>
 * DTOs classes must extend this class to get prepared for the base implementation of common database fields contained
 * in every entity, such as {@code id}, {@code version}, {@code createdAt}, {@code updatedAt}, {@code externalId} and
 * {@code deleted}.
 * </p>
 *
 * <p>Usage:</p>
 * <pre>
 *     public class AnyDTO extends BaseDTO {
 *         private String description;
 *
 *         public String getDescription(){
 *             return description;
 *         }
 *
 *         public void setDescription(final String description){
 *             this.description = description;
 *         }
 *     }
 * </pre>
 * <p>AnyDTO class haves all default BaseDTO fields and a description field.</p>
 *
 * @author  Diego A. Costa
 * @author  Lucas Dillmann
 * @version 7.0.0 - 2018-07-27 - Change class signature due to {@link BaseModel} changes
 * @since   5.0.0 2017-07-11
 */
@SuppressWarnings("serial")
public class BaseDTO extends BaseModel implements IPojoConverter, IntegrationModel<String> {

    protected UUID id;

    protected Long version;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    protected OffsetDateTime createdAt;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    protected OffsetDateTime updatedAt;

    protected String externalId;

    @JsonIgnore
    protected Boolean deleted;

    /**
     * @see com.ws.commons.persistence.model.BaseModel#getId()
     */
    @Override
    public UUID getId() {
        return id;
    }

    /**
     * @see com.ws.commons.persistence.model.BaseModel#setId(java.util.UUID)
     */
    @Override
    public void setId(final UUID id) {
        this.id = id;
    }
    
    /**
     * @see com.ws.commons.persistence.model.BaseModel#getCreatedAt()
     */
    @Override
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * @see com.ws.commons.persistence.model.BaseModel#setCreatedAt(java.time.OffsetDateTime)
     */
    @Override
    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * @see com.ws.commons.persistence.model.BaseModel#getUpdatedAt()
     */
    @Override
    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    /**
     * @see com.ws.commons.persistence.model.BaseModel#setUpdatedAt(java.time.OffsetDateTime)
     */
    @Override
    public void setUpdatedAt(final OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * @return the model's version
     */
    public Long getVersion() {
        return version;
    }
    
    /**
     * @param version of the model.
     */
    public void setVersion(final Long version) {
        this.version = version;
    }

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#getExternalId()
     */
    @Override
    public String getExternalId() {
        return externalId;
    }

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#setExternalId(java.lang.Object)
     */
    @Override
    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }
    
    /**
     * @return a flag indicating whether the model has been deleted.
     */
    public Boolean getDeleted() {
        return deleted;
    }

    /**
     * @param deleted indicating whether the model has been deleted.
     */
    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        
        int result = 1;
        
        return prime * result + ((getId() == null) ? 0 : getId().hashCode());
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final BaseDTO other = (BaseDTO) obj;
        
        if (getId() == null) {
            if (other.getId() != null) {
                return false;
            }
        } else if (!getId().equals(other.getId())) {
            return false;
        }
        
        return true;
    }
}
