package com.ws.commons.persistence.model;

/**
 * This interface represents a POJO identification.
 *
 * <p>It is used to provide getter and setter method to entities that are persisted with an unique {@code id}.</p>
 *
 * <p>Usage example:</p>
 * <pre>
 *     public class ExampleClass implements Identification{@literal <UUID>} {
 *          {@literal @Override}
 *          public UUID getId() {
 *              return id;
 *          }
 *          {@literal @Override}
 *          public void setId(final UUID id) {
 *              this.id = id;
 *          }
 *     }
 * </pre>
 *
 * @author      Diego Armange Costa
 * @param <T>   as identification type.
 * @version     6.0.0 - 2018-02-15 - Renamed from IIdentification to Identification.
 *                                   Changed value from UUID to Object.
 *
 * @since       5.0.0 - 2017-07-28
 */
public interface Identification<T extends Object> {

    /**
     * @return the object identification value to be retrieved.
     */
    T getId();
    
    /**
     * @param id the object identification value to be set.
     */
    void setId(final T id);
}
