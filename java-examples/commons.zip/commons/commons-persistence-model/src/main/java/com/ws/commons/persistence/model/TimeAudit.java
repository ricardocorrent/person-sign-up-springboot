package com.ws.commons.persistence.model;

import java.time.OffsetDateTime;

/**
 * Interface meant to record when a persistence action is performed on a model.
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-03-23
 */
public interface TimeAudit {

    /**
     * @return the time when a persistence action was performed on a model.
     */
    OffsetDateTime getPerformedAt();
   
    /**
     * @param performedAt the moment in which a persistence action was executed in a model.
     */
    void setPerformedAt(final OffsetDateTime performedAt);
}
