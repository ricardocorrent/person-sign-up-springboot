package com.ws.commons.persistence.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import io.ebean.annotation.Index;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Represents common fields for all models in the microservice.
 *
 * <p>
 * All entities that extends this class will have its records completely deleted when its resources allow DELETE
 * operations.
 * </p>
 *
 * <p>An implementation like:</p>
 * <pre>
 *     public class AnyEntity extends PhysicalDeleteBaseEntity {
 *         private String description;
 *
 *         public String getDescription(){
 *             return description;
 *         }
 *
 *         public void setDescription(final String description){
 *             this.description = description;
 *         }
 *     }
 * </pre>
 * <p>means that ´AnyEntity` is a deletable entity register in database.</p>
 *
 * <p>If you want to use {@link io.ebean.annotation.SoftDelete}, extend {@link SoftDeleteBaseEntity} instead.</p>
 *
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @author  Diego Peliser
 * @author  Rogerio Kiihl
 * @author  Lucas Dillmann
 * @version 5.4.2 - 2018-01-23 - Added rule to do not change the field value if it is not null.
 * @version 6.0.0 - 2018-03-20 - Added {@link Views.Internal} to control serialization/deserialization
 *                               of internal fields.
 * @version 6.0.0 - 2018-04-24 - Added support to {@link javax.persistence.PreRemove} event.
 * @version 6.0.0 - 2018-05-04 - Added indexes to "createdAt" and "updatedAt" attrs.
 * @version 7.0.0 - 2018-07-27 - Change class signature following changes on {@link BaseModel}
 * @version 7.5.0 - 2019-01-15 - Added {@link Views.Public} on externalId field.
 * @since   1.0.0 - 2016-02-24
 */
//Task: 11503 - Transparent Multi Tenancy refactor.
@MappedSuperclass
@SuppressWarnings("serial")
public class PhysicalDeleteBaseEntity extends BaseModel implements IntegrationModel<String> {

    /**
     * Auto-generated id. Represents the unique id from an entity.
     */
    @Id
    private UUID id;

    // #27579
    @JsonIgnore
    private Long version;

    /**
     * Indicates when the record was created in server.
     */
    @Index
    @JsonView(Views.Internal.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime createdAt;

    /**
     * Indicates when the record was updated in server.
     */
    @Index
    @JsonView(Views.Internal.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime updatedAt;

    /**
     * @see IntegrationModel
     */
    // #28581 - Redmine
    @Size(max = 255)
    @JsonView(Views.Public.class)
    private String externalId;

    /**
     * @see com.ws.commons.persistence.model.BaseModel#getId()
     */
    @Override
    public UUID getId() {
        return id;
    }

    /**
     * @see com.ws.commons.persistence.model.BaseModel#setId(java.util.UUID)
     */
    @Override
    public void setId(final UUID id) {
        this.id = id;
    }

    /**
     * @return The field value's creation.
     */
    @Override
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Stores when record was created. It will not change the field value when already is different of null.
     *
     * @author          Diego A. Costa
     * @param createdAt the field value's creation date and time.
     */
    @Override
    public void setCreatedAt(final OffsetDateTime createdAt) {
        if (this.createdAt == null) {
            this.createdAt = createdAt;
        }
    }

    /**
     * @return the time when the record was updated.
     */
    @Override
    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    /**
     * @param updatedAt the field value's update date and time.
     */
    @Override
    public void setUpdatedAt(final OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @SuppressWarnings("unused")
    private void setVersion(final Long version) {
        this.version = version;
    }

    /**
     * @return the entity version value.
     */
    public Long getVersion() {
        return version;
    }

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#getExternalId()
     */
    @Override
    public String getExternalId() {
        return externalId;
    }

    /**
     * @see com.ws.commons.persistence.model.IntegrationModel#setExternalId(java.lang.Object)
     */
    @Override
    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    /**
     * Method to handle records before insertions.
     * <p>
     * Fields {@link PhysicalDeleteBaseEntity#createdAt} and {@link PhysicalDeleteBaseEntity#updatedAt}
     * always must be created by server before insert.
     * </p>
     *
     * @author  Diego Peliser
     * @since   6.0.0 - 2018-03-20
     */
    @PrePersist
    public void prePersist() {
        final OffsetDateTime now = OffsetDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    /**
     * Method to handle records before updates.
     * <p>
     * Field {@link PhysicalDeleteBaseEntity#updatedAt} always must be set by server before any update.
     * </p>
     *
     * @author  Diego Peliser
     * @since   6.0.0 - 2018-03-20
     */
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = OffsetDateTime.now();
    }

    /**
     * Method to handle records before deletions.
     *
     * @author  Rogerio Kiihl
     * @since   6.0.0 - 2018-04-24
     */
    @PreRemove
    public void preRemove() {
        // No implementation for now. Coming issue will add functionality
    }
}
