package com.ws.commons.management.security

import com.ws.commons.management.ManagementComponent
import org.apache.shiro.util.ThreadContext
import javax.inject.Inject
import javax.ws.rs.container.ContainerRequestContext
import javax.ws.rs.container.ContainerRequestFilter
import javax.ws.rs.container.ContainerResponseContext
import javax.ws.rs.container.ContainerResponseFilter

/**
 * JAX-RS based filter to dynamically bind [SecurityManager] into request context
 *
 * This filter implementation binds management [SecurityManager] instance to current thread using Shiro's [ThreadContext].
 * Current approach is done to not mix management [SecurityManager] with actual application [SecurityManager] under
 * JVM-wide singleton of [org.apache.shiro.SecurityUtils], which can lead to security flaws if it happens.
 *
 * Implementation is based in two steps: First, when request arrives and wasn't processed yet, this class retrieves
 * management [SecurityManager] and set it under [ThreadContext]. Second, when request is processed, this class unbinds
 * [SecurityManager] from context. This is done to avoid leak of the manager under different requests since Jetty
 * do not create a unique Thread for each request, but reuse an instance from a shared pool.
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
@ManagementComponent
class SecurityManagerBinder @Inject constructor(private val installer: FilterInstaller) : ContainerRequestFilter, ContainerResponseFilter {

    private val requestPropertyName = "${javaClass.name}.securityManagerEnabled"

    /**
     * Pre-request filter method, injecting [SecurityManager] under thread context if a [SecurityManager]S isn't already
     * set
     *
     * @see ContainerRequestFilter.filter
     */
    override fun filter(requestContext: ContainerRequestContext) {
        if (ThreadContext.getSecurityManager() == null) {
            requestContext.setProperty(requestPropertyName, true)
            ThreadContext.bind(installer.securityManager)
        }
    }

    /**
     * Post-request filter method, removing [SecurityManager] from thread context if it was injected in pre-request
     * method
     *
     * @see ContainerResponseFilter.filter
     */
    override fun filter(requestContext: ContainerRequestContext, responseContext: ContainerResponseContext) {
        val removeFromContext = requestContext.getProperty(requestPropertyName) as Boolean? ?: false
        if (removeFromContext) {
            ThreadContext.unbindSecurityManager()
        }
    }

}