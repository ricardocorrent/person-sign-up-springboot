package com.ws.commons.management.security

import com.ws.commons.management.ManagementComponent
import org.apache.shiro.mgt.SecurityManager
import org.secnod.shiro.jersey.AuthorizationFilterFeature
import org.slf4j.LoggerFactory
import javax.ws.rs.core.Feature
import javax.ws.rs.core.FeatureContext

/**
 * JAX-RS feature for Apache Shiro integration
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
@ManagementComponent
class FeatureInstaller : Feature {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Enables Apache Shiro [AuthorizationFilterFeature] under management JAX-RS context
     *
     * @see Feature.configure
     */
    override fun configure(featureContext: FeatureContext): Boolean {
        featureContext.register(AuthorizationFilterFeature::class.java)
        logger.debug("Shiro feature started in management context")
        return true
    }

}