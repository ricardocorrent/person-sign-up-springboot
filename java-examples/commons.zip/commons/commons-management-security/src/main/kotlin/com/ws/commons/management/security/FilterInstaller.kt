package com.ws.commons.management.security

import com.ws.commons.management.ManagementContextCustomizer
import org.apache.shiro.web.env.EnvironmentLoaderListener
import org.apache.shiro.web.mgt.WebSecurityManager
import org.apache.shiro.web.servlet.ShiroFilter
import org.eclipse.jetty.servlet.FilterHolder
import org.eclipse.jetty.webapp.WebAppContext
import org.slf4j.LoggerFactory
import java.util.*
import javax.enterprise.context.ApplicationScoped
import javax.servlet.DispatcherType.*

/**
 * [ManagementContextCustomizer] implementation for Apache Shiro installation
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
class FilterInstaller : ManagementContextCustomizer {

    private val logger = LoggerFactory.getLogger(javaClass)
    private val filterUrlPattern = "/*"
    private val filterTypes = EnumSet.of(FORWARD, REQUEST, INCLUDE)
    private lateinit var holder: FilterHolder

    val securityManager: WebSecurityManager?
        get() = (holder.filter as ShiroFilter).securityManager

    /**
     * Customizes the management context by installing Apache Shiro filter and listener
     *
     * @see ManagementContextCustomizer.customize
     */
    override fun customize(context: WebAppContext) {
        context.addEventListener(EnvironmentLoaderListener())
        holder = context.addFilter(ShiroFilter::class.java, filterUrlPattern, filterTypes)

        logger.debug("Shiro filter and listener started for management context")
    }
}