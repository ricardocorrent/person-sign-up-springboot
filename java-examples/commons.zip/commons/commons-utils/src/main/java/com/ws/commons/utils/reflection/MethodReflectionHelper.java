package com.ws.commons.utils.reflection;

import com.ws.commons.utils.ArrayUtils;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.apache.commons.lang3.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * This class is meant to aid repetitive reflection tasks related to methods and reducing boilerplate.
 *
 * <p>It can be used, for example, to retrieve getter and setter methods using reflection strategies,
 * using {@link #getEncapsulationMethod(Field, EncapsulationMethod)}:</p>
 * <pre>
 *     // param field is the field you want to recover the getter method
 *     final Method method = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
 * </pre>
 *
 * <p>It also can be used to retrieve any another method from a class, using {@link #getMethod(Class, String, Class[])}</p>
 * <pre>
 *     final Method method = MethodReflectionHelper.getInstance().getMethod(Any.class, "anyMethod");
 * </pre>
 * <p>Finally, {@link Method}s can be invoked through {@link #invokeMethod(Method, Object, Object...)}</p>
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-13
 */
public class MethodReflectionHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(MethodReflectionHelper.class);
    private boolean allowSyntheticMethod;
    
    /**
     * Enumerator created to normalize {@link String} parameter on {@link MethodReflectionHelper#getEncapsulationMethod(Field, EncapsulationMethod)}.
     * 
     * @author Diego Armange Costa
     * @since 5.0.0 2017-09-11
     */
    public enum EncapsulationMethod {
        /**
         * Reference to the getter method.
         * When the field is a primitive boolean, it will be considered as "is" prefix, 
         * according Java encapsulation convention.
         * <pre>
         *  <code>
         *      public boolean isPrimitiveField() {...}
         *      public String getStringField() {...}
         *  </code>
         * </pre>
         * 
         * @see #getName(Field)
         */
        GET,
        
        /**
         * Reference to the getter method.
         * Ignores the encapsulation convention.
         * <pre>
         *  <code>
         *      //Ignores the encapsulation convention.
         *      public boolean getPrimitiveField() {...}
         *      public String getStringField() {...}
         *  </code>
         * </pre>
         * 
         * @see #getName(Field)
         */
        FORCE_GET,
        
        /**
         * Reference to the setter method.
         */
        SET;
        
        /**
         * @param field     to get the field name to capitalize and compose the method name.
         * @return          the formatted method name.
         */
        public String getName(final Field field) {
            ObjectHelper.requireNotNullParameter(field);
            
            if (field.getType().isPrimitive() && field.getType().equals(boolean.class) && this == GET) {
                return "is".concat(WordUtils.capitalize(field.getName()));
            } else if (this == FORCE_GET) {
                return this.toString().toLowerCase().substring(6,9).concat(WordUtils.capitalize(field.getName()));
            }
            
            return this.toString().toLowerCase().concat(WordUtils.capitalize(field.getName()));
        }
        
        /**
         * Retrieves the argument type of the enumerator from a {@link Field}.
         *
         * @param field to get the argument type.
         * @return      the argument type when is setter or null when is getter.
         */
        public Class<?>[] getArgumentType(final Field field) {
            ObjectHelper.requireNotNullParameter(field);
            
            if (SET == this) {
                return new Class[] {field.getType()}; 
            }
            
            return new Class[] {};
        }
    }
    
    private Class<? extends RuntimeException> runtimeThrowableClass;
    
    /**
     * Instantiates this class.
     *
     * @return a new {@link MethodReflectionHelper} instance.
     */
    public static MethodReflectionHelper getInstance() {
        return new MethodReflectionHelper();
    }
    
    /**
     * Any field search will also include synthetic fields.
     *
     * @see Field#isSynthetic()
     */
    public void includeSynteticField() {
        allowSyntheticMethod = true;
    }
    
    /**
     * Sets a {@link RuntimeException} to be thrown without any treatment.
     * @param runtimeThrowableClass to be thrown without catching on any method invocation by this helper.
     */
    public void throwException(final Class<? extends RuntimeException> runtimeThrowableClass) {
        this.runtimeThrowableClass = runtimeThrowableClass;
    }
    
    /**
     * <p>
     * Will find the method and invoke it.
     * Can will throw the runtime exception if defined by {@link MethodReflectionHelper#throwException(Class)}
     * <b>NOTE: </b>This resource only can be used when no argument of desired method is null.
     * </p>
     * 
     * @param methodName        to find method.
     * @param declaringInstance to invoke the method.
     * @param arguments         to invoke the method.
     * @return                  the method's return.
     * @see                     MethodReflectionHelper#throwException(Class)
     */
    public Object invokeMethod(final String methodName, final Object declaringInstance, final Object... arguments) {
        ObjectHelper.requireNotNullParameter(declaringInstance, ReflectionStringConstants.DECLARING_INSTANCE_NAME);
        
        return invokeMethod(declaringInstance.getClass(), methodName, declaringInstance, arguments);
    }
    
    /**
     * <p>
     * Will find the method and invoke it.
     * Can will throw the runtime exception if defined by {@link MethodReflectionHelper#throwException(Class)}
     * <b>NOTE: </b>This resource only can be used when no argument of desired method is null.
     * </p>
     * 
     * @param targetClass       that declares the desired method.
     * @param methodName        to find method.
     * @param declaringInstance to invoke the method.
     * @param arguments         to invoke the method.
     * @return                  the method's return.
     * 
     * @see MethodReflectionHelper#throwException(Class)
     */
    public Object invokeMethod(final Class<?> targetClass, final String methodName, final Object declaringInstance, final Object... arguments) {
        ObjectHelper.requireNotNullParameter(declaringInstance, ReflectionStringConstants.DECLARING_INSTANCE_NAME);
        
        ArrayUtils.validateNotContainNull("arguments", arguments);
        
        final Class<?>[] parameterTypes = getParameterTypesFromArguments(arguments);
        
        return invokeMethod(getMethod(targetClass, methodName, parameterTypes), declaringInstance, arguments);
    }

    private Class<?>[] getParameterTypesFromArguments(Object[] arguments) {
        Class<?>[] parameterTypes = new Class<?>[arguments.length];
        
        int index = 0;
        
        for (; index < arguments.length; index++) {
            parameterTypes[index] = arguments[index].getClass();
        }
        
        return parameterTypes;
    }
    
    /**
     * Retrieves a {@link Method} from a class using the method's name.
     *
     * @param declaringClass    that declares the desired method.
     * @param methodName        to find method.
     * @param parameterTypes    to find method.
     * @return                  the method according to the name and types of arguments informed.
     */
    public Method getMethod(final Class<?> declaringClass, final String methodName, final Class<?>... parameterTypes) {
        ObjectHelper.requireNotNullParameter(declaringClass, ReflectionStringConstants.DECLARING_CLASS_NAME);
        ObjectHelper.requireNotNullParameter(methodName, ReflectionStringConstants.METHOD_NAME);
        
        try {
            final Method declaredMethod = declaringClass.getDeclaredMethod(methodName, parameterTypes);
            
            validateSynteticField(declaredMethod);
            
            return declaredMethod;
        } catch (final NoSuchMethodException | SecurityException exception) {
            if (declaringClass.getSuperclass() != null) {
                return getMethod(declaringClass.getSuperclass(), methodName, parameterTypes);
            }
            
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Retrieves a method from a {@link Field} using {@link EncapsulationMethod}.
     *
     * @param field                 to get name and use to format the method.
     * @param encapsulationMethod   to determine the required method.
     * @return                      the method instance or null if it not to exist.
     */
    public Method getEncapsulationMethod(final Field field, final EncapsulationMethod encapsulationMethod) {
        ObjectHelper.requireNotNullParameter(field);
        ObjectHelper.requireNotNullParameter(encapsulationMethod);
        
        try {
            final Method declaredMethod = field.getDeclaringClass().getDeclaredMethod(encapsulationMethod.getName(field), encapsulationMethod.getArgumentType(field));
            
            validateSynteticField(declaredMethod);
            
            return declaredMethod;
        } catch (final NoSuchMethodException | SecurityException exception) {
            return null;
        }
    }
    
    /**
     * Retrieves a method from a {@link Field} using {@link EncapsulationMethod}, ignoring convention.
     * <p>
     * When the field type is a primitive boolean, it will search for using "#FORCE_GET" prefixes. This will
     * ignore Java encapsulation convention, as the method tries to use a {@code getBoolean()} method before
     * a {@code isBoolean()} one.
     * </p>
     *
     * @param field                 to get name and use to format the method.
     * @param encapsulationMethod   to determine the required method.
     * @return                      the method instance or null if it not to exist.
     */
    public Method getEncapsulationMethodIgnoringConvetion(final Field field, final EncapsulationMethod encapsulationMethod) {
        ObjectHelper.requireNotNullParameter(field);
        ObjectHelper.requireNotNullParameter(encapsulationMethod);
        
        try {
            final Method declaredMethod = field.getDeclaringClass().getDeclaredMethod(encapsulationMethod.getName(field), encapsulationMethod.getArgumentType(field));
            
            validateSynteticField(declaredMethod);
            
            return declaredMethod;
        } catch (final NoSuchMethodException | SecurityException exception) {
            return encapsulationMethod == EncapsulationMethod.GET ? 
                    getEncapsulationMethodIgnoringConvetion(field, EncapsulationMethod.FORCE_GET) : null;
        }
    }

    /**
     * Makes a method call.
     * Will throw the runtime exception defined by {@link MethodReflectionHelper#throwException(Class)}
     * 
     * @param method            to be invoked.
     * @param declaringInstance to invoke the method.
     * @param arguments         to invoke the method.
     * @return                  the method's return.
     * @see                     MethodReflectionHelper#throwException(Class)
     */
    public Object invokeMethod(final Method method, final Object declaringInstance, final Object... arguments) {
        ObjectHelper.requireNotNullParameter(method);
        ObjectHelper.requireNotNullParameter(declaringInstance, ReflectionStringConstants.DECLARING_INSTANCE_NAME);
        
        try {
            method.setAccessible(true);
            
            validateSynteticField(method);
            
            return method.invoke(declaringInstance, arguments);
        } catch (final IllegalAccessException | InvocationTargetException | IllegalArgumentException exception) {
            if (runtimeThrowableClass != null && ThrowableReflectionHelper.isThrowableCausedBy(exception, runtimeThrowableClass)) {
                LOGGER.error("Method invocation exception: ", new ReflectionException(exception));
                
                throw ClassReflectionHelper.newInstanceFromClass(runtimeThrowableClass);
            }
            
            throw new ReflectionException(exception);
        }
    }
    
    private void validateSynteticField(final Method declaredMethod) {
        if (!allowSyntheticMethod) {
            SyntheticValidator.denySyntetic(declaredMethod);
        }
    }
}
