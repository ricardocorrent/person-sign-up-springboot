package com.ws.commons.utils.reflection;

import com.ws.commons.message.IFormattedMessage;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Enumerator that defines messages for use in reflection process.
 * 
 * @author  Diego Armange Costa
 * @see     ClassReflectionHelper
 * @see     TypeReflectionHelper
 * @see     FieldReflectionHelper
 * @since   5.0.0 - 2017-06-08
 */
enum EReflectionHelperMessage implements IFormattedMessage {

    /**
     * Unformatted message: The type {0} is not a interface.
     */
    THE_TYPE_IS_NOT_A_INTERFACE("The type {0} is not a interface."),

    /**
     * Unformatted message: The type {0} is a interface.
     */
    THE_TYPE_IS_A_INTERFACE("The type {0} is a interface."),
    
    /**
     * Unformatted message: The field name is required to get declared field.
     */
    THE_FIELD_NAME_IS_REQUIRED_TO_GET_FIELD("The field name is required to get declared field."),
    
    ;
    
    private String unformattedMessage;
    
    EReflectionHelperMessage(final String unformattedMessage){
        this.unformattedMessage = unformattedMessage;
    }
    
    /**
     * @see IFormattedMessage#getUnformattedMessage()
     */
    @Override
    public String getUnformattedMessage() {
        return this.unformattedMessage;
    }
}
