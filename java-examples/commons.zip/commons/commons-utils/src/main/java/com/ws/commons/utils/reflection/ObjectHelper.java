package com.ws.commons.utils.reflection;

import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import com.ws.commons.message.EDefaultMessage;

/**
 * Helper to validate nullable objects.
 *
 * <pre>
 *     ObjectHelper.requireNotNullParameter(anyObject);
 * </pre>
 *
 * @author Diego A. Costa
 * @since 6.0.0 - 2018-04-16
 */
public class ObjectHelper {
    
    private ObjectHelper() {}

    /**
     * Sends a predefined message containing {@link Class#getSimpleName()} of parameter type.
     *
     * @param parameter to be validated.
     * @see             EDefaultMessage#PARAMETER_CANNOT_BE_NULL
     */
    public static void requireNotNullParameter(final Object parameter) {
        Objects
            .requireNonNull(parameter, 
                    EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(
                            parameter != null ? parameter.getClass().getSimpleName() : StringUtils.EMPTY));
    }
    
    /**
     * Sends a predefined message containing a parameter name.
     *
     * @param parameter     to be validated.
     * @param parameterName to compose the predefined message.
     * @see                 EDefaultMessage#PARAMETER_CANNOT_BE_NULL
     */
    public static void requireNotNullParameter(final Object parameter, final String parameterName) {
        Objects
            .requireNonNull(parameter, 
                    EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(parameterName));
    }
    
    /**
     * Sends a predefined message containing a parameter name.
     * @param parameter     to be validated.
     * @param parameterName to compose the predefined message.
     * @see                 EDefaultMessage#PARAMETER_CANNOT_BE_NULL
     */
    public static void requireNotNullParameter(final Object parameter, final StringConstants parameterName) {
        Objects
            .requireNonNull(parameter, 
                    EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(parameterName.getValue()));
    }
    
    /**
     * Sends a predefined message containing {@link Class#getSimpleName()} of value type.
     *
     * @param value to be validated.
     * @see         EDefaultMessage#VALUE_CANNOT_BE_NULL
     */
    public static void requireNotNullValue(final Object value) {
        Objects
            .requireNonNull(value, 
                    EDefaultMessage.VALUE_CANNOT_BE_NULL.getMessage(
                            value != null ? value.getClass().getName() : StringUtils.EMPTY));
    }
    
    /**
     * Sends a predefined message containing a value name.
     *
     * @param value     to be validated.
     * @param valueName to compose the predefined message.
     * @see             EDefaultMessage#PARAMETER_CANNOT_BE_NULL
     */
    public static void requireNotNullValue(final Object value, final String valueName) {
        Objects
            .requireNonNull(value, 
                    EDefaultMessage.VALUE_CANNOT_BE_NULL.getMessage(valueName));
    }
    
    /**
     * Sends a predefined message containing a value name.
     *
     * @param value     to be validated.
     * @param valueName to compose the predefined message.
     * @see             EDefaultMessage#PARAMETER_CANNOT_BE_NULL
     */
    public static void requireNotNullValue(final Object value, final StringConstants valueName) {
        Objects
            .requireNonNull(value, 
                    EDefaultMessage.VALUE_CANNOT_BE_NULL.getMessage(valueName));
    }
}
