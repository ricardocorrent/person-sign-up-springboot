package com.ws.commons.utils.reflection;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.Numbers;
import com.ws.commons.utils.reflection.exception.ReflectionException;

import java.lang.reflect.*;
import java.util.Objects;

/**
 * This class is meant to aid repetitive reflection tasks related to {@link Type} and reducing boilerplate.
 *
 * @author  Diego Armange Costa
 * @version 7.3.0 - 2018-09-05 - Changed internal logic to search for the interface class in the superclass when
 *                               the type can't be found directly on the source class. This allows this method to be able to retrieve generic types
 *                               even from interfaces that are present in any level of class extension hierarchy.
 * @since   5.0.0 - 2017-08-08
 */
public final class TypeReflectionHelper {
    
    private TypeReflectionHelper() {}
    
    /**
     * @param type that declaring generic type.
     * @param position of type.
     * @return The generic type.
     */
    public static Class<?> getGenericType(final Type type, final int position) {
        Objects.requireNonNull(type, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("type"));
        
        Numbers.requirePositive(position, EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        Type localType = type;
        
        if (localType == Object.class) {
            return (Class<?>)localType;
        }
        
        if (!ParameterizedType.class.isAssignableFrom(localType.getClass())) {
            localType = getGenericTypeFromType(localType, position);
            
            Class<?> foundClass = castTypeToClass(localType);
            
            return foundClass.isArray() ? foundClass.getComponentType() : foundClass;
            
        }
        
        Type resultType = handleParameterizedTypeAssigned((ParameterizedType) localType, position);
        
        return handleResultType(resultType, position);
    }
    
    /**
     * Retrieves the generic type declared in an interface.
     *
     * @author                  Lucas Dillmann
     * @param <T>               the interface type parameter.
     * @param sourceClass       as class that implements the interface from which the generic type is desired.
     * @param interfaceClass    as interface that contains the desired generic type.
     * @param position          as type argument position.
     * @return                  the generic type declared in the interface.
     *
     */
    @SuppressWarnings("unchecked")
    public static <T> Class<T> getGenericTypeFromInterface(final Class<?> sourceClass, final Class<?> interfaceClass, final int position) {
        Objects.requireNonNull(sourceClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("sourceClass"));
        
        Objects.requireNonNull(interfaceClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("interfaceClass"));
        
        Numbers.requirePositive(position, EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        if (!interfaceClass.isInterface()) {
            throw new ReflectionException(EReflectionHelperMessage.THE_TYPE_IS_NOT_A_INTERFACE.getMessage(interfaceClass.getName()));
        }
        
        for (Type type : sourceClass.getGenericInterfaces()) {
            if (type instanceof ParameterizedType) {
                ParameterizedType parameterizedType = (ParameterizedType) type;
                
                if (parameterizedType.getRawType().equals(interfaceClass)) {
                    Type actualType = parameterizedType.getActualTypeArguments()[position];
                    
                    return (Class<T>) actualType;
                }
            }
        }

        final Class superclass = sourceClass.getSuperclass();
        if (superclass != null && !Object.class.equals(superclass)) {
            return getGenericTypeFromInterface(sourceClass.getSuperclass(), interfaceClass, position);
        }
        
        return null;
    }

    /**
     * Searches and returns the {@code position} generic argument from the class hierarchy of the given {@code sourceClass}
     * on the {@code targetClass}.
     *
     * <p>This method will look into the source class hierarchy to search for the target class type. When found and the
     * target class is a parameterized class, then this method will return the argument on the requested position index.</p>
     *
     * @author              Lucas Dillmann
     * @param sourceClass   source class to search on
     * @param targetClass   target class to look into
     * @param position      position or number of the generic argument of the target class to return
     * @param <T>           generic type
     * @return              the found type argument when one is found, null otherwise
     * @since               7.3.0 - 2018-09-06
     */
    public static <T> Class<T> getGenericTypeFromClass(final Class<?> sourceClass, final Class<?> targetClass, final int position) {
        Objects.requireNonNull(sourceClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("sourceClass"));
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("targetClass"));
        Numbers.requirePositive(position, EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));

        if (targetClass.isInterface()) {
            throw new ReflectionException(EReflectionHelperMessage.THE_TYPE_IS_A_INTERFACE.getMessage(targetClass.getName()));
        }

        final Type superclass = sourceClass.getGenericSuperclass();
        if (superclass == null || superclass.equals(Object.class)) {
            return null;
        }

        if (superclass instanceof ParameterizedType) {
            final ParameterizedType parameterizedType = (ParameterizedType) superclass;
            if (parameterizedType.getRawType().equals(targetClass)) {
                return (Class<T>) parameterizedType.getActualTypeArguments()[position];
            }
        }

        return getGenericTypeFromClass(sourceClass.getSuperclass(), targetClass, position);
    }

    /**
     * Retrieves the generic type from a {@link Field}.
     *
     * @param filed     that declaring generic type.
     * @param position  of type.
     * @return          the generic type.
     * @see             TypeReflectionHelper#getGenericType(Type, int)
     */
    public static Class<?> getGenericFieldType(final Field filed, final int position) {
        Objects.requireNonNull(filed, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("filed"));
        
        Numbers.requirePositive(position, EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        return getGenericType(filed.getGenericType(), position);
    }
    
    private static Type getGenericTypeFromType(final Type type, final int position) {
        if (type instanceof TypeVariable) {
            return handleTypeVariable((TypeVariable<?>) type, position);
        } else if (type instanceof WildcardType) { 
            return handleWildcardType((WildcardType) type);
        } else if (type instanceof GenericArrayType) {
            return handleGenericArrayType((GenericArrayType) type);
        } else {
            return type;
        }
    }
    
    private static Class<?> castTypeToClass(final Type localType) {
        if (!(localType instanceof ParameterizedType)) {
            return (Class<?>)localType;
        } else {
            return (Class<?>)((ParameterizedType)localType).getRawType();
        }
    }
    
    private static Type handleWildcardType(final WildcardType wildcardType) {
        Type[] bounds = wildcardType.getLowerBounds();
        
        if (bounds.length == 0) { 
            bounds = wildcardType.getUpperBounds();
        }
        
        return bounds[0];
    }

    private static Type handleTypeVariable(final TypeVariable<?> typeVariable, final int position) {
        return typeVariable.getBounds()[position];
    }
    
    private static Type handleGenericArrayType(final GenericArrayType genericArrayType) {
        if (genericArrayType.getGenericComponentType() instanceof GenericArrayType) {
            return handleGenericArrayType((GenericArrayType) genericArrayType.getGenericComponentType());
        }
        
        return genericArrayType.getGenericComponentType();
    }

    private static Type handleParameterizedTypeAssigned(final ParameterizedType parameterizedType, final int position) {
        return parameterizedType.getActualTypeArguments()[position];
    }
    
    private static Class<?> handleResultType(final Type resultType, final int position) {
        return resultType instanceof Class ? (Class<?>)resultType : getGenericType(resultType, position);
    }
}
