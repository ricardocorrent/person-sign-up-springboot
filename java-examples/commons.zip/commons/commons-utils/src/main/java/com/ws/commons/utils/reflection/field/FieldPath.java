package com.ws.commons.utils.reflection.field;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.SyntheticValidator;
import com.ws.commons.utils.reflection.TypeReflectionHelper;

/**
 * Auxiliary class to manipulate field paths.
 * 
 * @author  Cristopher Zanchetta
 * @author  Diego A. Costa
 * @version 5.3.0 - 2017-11-23 - Added declaringClass and declaringField to scope.
 * @since   5.2.0 - 2017-10-19
 */
class FieldPath {
    private static final String PATH_DELIMITER = ".";
    
    private static final String PATH_DELIMITER_REGEX = "\\.";
    
    private String currentPath;
    
    private String currentFieldName;
    
    private Field currentField;
    
    private Type currentFieldType;
    
    private Class<?> currentDeclaringClass;
    
    private boolean allowSynteticField;

    private FieldPath(final String path) {
        setCurrentPath(path);
    }
    
    static FieldPath fromPath(final String path) {
        return new FieldPath(path);
    }
    
    /**
     * Any field search will also include synthetic fields.
     * 
     * @see Field#isSynthetic()
     */
    void includeSynteticField() {
        allowSynteticField = true;
    }
    
    FieldPath withClass(final Class<?> declaringClass) {
        currentDeclaringClass = declaringClass;
        
        return this;
    }

    private void setCurrentPath(final String path) {
        String newPath = path.replaceAll("\\s","");
        if (StringUtils.isEmpty(newPath)) {
            throw new IllegalArgumentException(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("path"));
        }

        this.currentPath = newPath;
    }
    
    /**
     * @return the current path under evaluation
     */
    String getCurrentPath() {
        return currentPath;
    }
    
    String getCurrentFieldName() {
        return currentFieldName;
    }
    
    Field getCurrentField() {
        return currentField;
    }
    
    Type getCurrentFieldType() {
        return currentFieldType;
    }
    
    Class<?> getCurrentDeclaringClass() {
        return currentDeclaringClass;
    }

    boolean isEmptyPath() {
        return StringUtils.isEmpty(currentPath);
    }

    /**
     * Removes and returns the first subpath(root) from a given path (string, separated by commas).
     *
     * @author                          Cristopher Zanchetta
     * @author                          Diego A. Costa
     * @return                          the first subpath(root) of a given path (e.g. "tree" from "tree.branch.leaf").
     * @throws IllegalStateException    if path is empty.
     * @since                           5.3.0 - 2017-11-23
     */
    String popRootFromPath() {
        if (this.isEmptyPath()){
            throw new IllegalStateException("Path is either null or empty.");
        }

        final String[] splitPath = currentPath.split(PATH_DELIMITER_REGEX);
        
        currentPath = String.join(PATH_DELIMITER, Arrays.copyOfRange(splitPath, 1, splitPath.length));
        
        currentFieldName = splitPath[0];
        
        findFieldAndDeclaringClass(currentFieldName);

        return currentFieldName;
    }

    private void findFieldAndDeclaringClass(final String fieldName) {
        if (currentDeclaringClass != null) {
            currentField = FieldReflectionHelper.fromClass(currentDeclaringClass).getField(fieldName);
            
            validateSynteticField(currentField);
            
            currentFieldType = TypeReflectionHelper.getGenericFieldType(currentField, 0);
        }
    }
    
    private void validateSynteticField(final Field declaredField) {
        if (!allowSynteticField) {
            SyntheticValidator.denySyntetic(declaredField);
        }
    }
}
