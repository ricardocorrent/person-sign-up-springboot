package com.ws.commons.utils.reflection.field;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.ArrayUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.*;
import java.util.function.BiConsumer;

/**
 * Represents the filter configuration to search for fields in any declaring class.
 * 
 * @author  Diego Armange Costa
 * @since   5.1.0 2017-10-02
 */
public final class FieldFilter {

    private final Class<?> declaringClass;
    
    private Class<? extends Annotation>[] annotations;
    
    private Set<Field> fieldSet = new HashSet<>();
    
    private boolean recursively;
    
    /**
     * @param declaringClass    that contain the desired fields.
     * @param annotations       to determine the filter for class search.
     */
    @SuppressWarnings("unchecked")
    FieldFilter(final Class<?> declaringClass, final Class<? extends Annotation>... annotations) {
        Objects.requireNonNull(declaringClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringClass"));
        
        this.declaringClass = declaringClass;
        
        this.annotations = annotations;
    }
    
    /**
     * Defines the field annotations that will be used to find the fields contained in the declaring class.
     * 
     * @param annotations   to determine the filter for class search.
     * @return              a {@link FieldFilter} instance with the defined filter to the class search.
     */
    @SuppressWarnings("unchecked")
    public FieldFilter containingAnnotations(final Class<? extends Annotation>... annotations) {
        ArrayUtils.validateNotContainNull("annotation", (Object[]) annotations);
        
        this.annotations = annotations;
        
        return this;
    }
    
    /**
     * @return this {@link FieldFilter} instance with recursive flag configuration to search
     *         for fields contained in classes and superclasses.
     */
    public FieldFilter recursively() {
        recursively = true;
        
        return this;
    }
    
    /**
     * @return the fields contained in the declaring class.
     */
    public Set<Field> getFieldSet() {
        return getFieldSet(null);
    }
    
    /**
     * Returns a {@link Set} of fields of the declaring class.
     *
     * <p>The annotation parameter will be null when the read field does not match the configured filter.</p>
     *
     * @param action    the action that should be performed on each field read.
     * @return          the fields contained in the declaring class.
     */
    public Set<Field> getFieldSet(final BiConsumer<Annotation, Field> action) {
        if (recursively) {
            final List<Field> fields = FieldReflectionHelper.fromClass(declaringClass).getFields();
            
            handleDeclaringFields(fields, action);
        } else {
            final List<Field> fields = Arrays.asList(declaringClass.getDeclaredFields());
            
            handleDeclaringFields(fields, action);
        }
        
        return fieldSet;
    }

    private void handleDeclaringFields(final List<Field> fields, final BiConsumer<Annotation, Field> action) {
        if (ArrayUtils.isEmpty(annotations)) {
            fieldSet = new HashSet<>(fields);
        } else {
            fields.forEach(field -> {
                Annotation annotation = null;
                
                for (Class<? extends Annotation> annotationType : annotations) {
                    annotation = field.getAnnotation(annotationType);
                    
                    if (annotation != null) {
                        break;
                    }
                }
                
                if (annotation != null) {
                    fieldSet.add(field);
                }
                
                action.accept(annotation, field);
            }); 
        }
    }
}