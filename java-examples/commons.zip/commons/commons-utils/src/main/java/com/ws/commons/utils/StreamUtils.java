package com.ws.commons.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Utility methods for lambda expressions used in streams.
 *
 * <p>This class contains common-use methods that can help in scenarios where the direct use of a lambda can't be done,
 * like when you need to map some value calling a method that can throw a checked exception.</p>
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-12
 */
public final class StreamUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(StreamUtils.class);

    /**
     * Private constructor to avoid class instances.
     */
    private StreamUtils() {}

    /**
     * Tries to execute the given command and return the value provided by it. If any exception is thrown,
     * then this method will ignore the exception and simple return null.
     *
     * @param command   command to be run
     * @param <T>       generic type of the return
     * @return          the returned value from the command
     */
    public static <T> T mapAndIgnoreException(final Callable<T> command) {
        try {
            return command.call();
        } catch (final Exception ex) {
            LOGGER.debug("Exception detected and ignored", ex);
            return null;
        }
    }

    /**
     * Tries to execute the given command and return the value provided by it. If any exception is thrown,
     * then this method will ignore the exception and simple return the default value provided.
     *
     * @param command       command to be run
     * @param defaultValue  the default value to be returned when an exception occurs
     * @param <T>           generic type of the return
     * @return              the returned value from the command
     */
    public static <T> T mapAndIgnoreException(final Callable<T> command,
                                              final T defaultValue) {
        try {
            return command.call();
        } catch (final Exception ex) {
            LOGGER.debug("Exception detected and ignored", ex);
            return defaultValue;
        }
    }

    /**
     * Tries to execute the given command and return the value provided by it. If any exception is thrown,
     * then this method will absorb the exception, inform the caller about the exception using the provided callback
     * and simple return null to the original caller.
     *
     * @param command       command to be run
     * @param errorCallback callback to be fired when any exception occurs
     * @param <T>           generic type of the return
     * @return              the returned value from the command
     */
    public static <T> T mapAndAbsorbException(final Callable<T> command,
                                              final Consumer<Exception> errorCallback) {
        try {
            return command.call();
        } catch (final Exception ex) {
            errorCallback.accept(ex);
            return null;
        }
    }

    /**
     * Tries to execute the given command and return the value provided by it. If any exception is thrown,
     * then this method will absorb the exception, inform the caller about the exception using the provided callback
     * and simple return the default value provided.
     *
     * @param command       command to be run
     * @param defaultValue  the default value to be returned when an exception occurs
     * @param errorCallback callback to be fired when any exception occurs
     * @param <T>           generic type of the return
     * @return              the returned value from the command
     */
    public static <T> T mapAndAbsorbException(final Callable<T> command,
                                              final T defaultValue,
                                              final Consumer<Exception> errorCallback) {
        try {
            return command.call();
        } catch (final Exception ex) {
            errorCallback.accept(ex);
            return defaultValue;
        }
    }

    /**
     * Tries to execute the given command and return the value provided by it. If any exception is thrown,
     * then this method will absorb the exception and call the provided error handler to provide what value
     * should be returned by this method to the original caller.
     *
     * @param command Command to be run
     * @param errorHandler Handler to be fired when any exception occurs, responsible to provide a value to be returned
     * @param <T> Generic type of the return
     * @return The returned value from the command
     */
    public static <T> T mapAndAbsorbException(final Callable<T> command,
                                              final Function<Exception, T> errorHandler) {
        try {
            return command.call();
        } catch (final Exception ex) {
            return errorHandler.apply(ex);
        }
    }

}
