package com.ws.commons.utils.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import com.ws.commons.utils.reflection.exception.ReflectionException;

/**
 * This class is meant to aid in repetitive reflection tasks related to {@link Method} and {@link Field} {@link Modifier}s
 * and reducing boilerplate.
 *
 * <p>This class offers methods to handle {@link Modifier}s through reflection strategies.</p>
 * <pre>
 *     private Field field;
 *     ...
 *     // Uses reflection to change field modifier from 'private' to 'public'
 *     ModifierReflectionHelper.from(field).changeToPublic();
 * </pre>
 *
 * @author  Diego Armange Costa
 * @since   5.3.1 - 2017-12-01
 */
public class ModifierReflectionHelper {

    /**
     * Can be a {@link Method} or a {@link Field} that will be changed. 
     */
    private final Object target;
    
    /**
     * {@link Method} that will be changed. 
     */
    private final Method method;
    
    /**
     * {@link Field} that will be changed. 
     */
    private final Field field;
    
    /**
     * Modifiers attribute, inside target.
     */
    private final Field modifiersField;
    
    /**
     * Accessible attribute, inside target.
     * 
     * @see Field#isAccessible()
     * @see Method#isAccessible()
     */
    private boolean accessible;
    
    /**
     * Modifiers that will be returned when {@link #undo()} is performed.
     */
    private Integer toRemember;
    
    /**
     * Modifiers that will be deleted when {@link #undo()} is performed.
     */
    private Integer toForget;
    
    private ModifierReflectionHelper(final Method method) {
        this.target = method;
        
        this.method = method;
        
        this.field = null;
        
        this.modifiersField = com.ws.commons.utils.reflection.field.FieldReflectionHelper.fromClass(target.getClass()).getField("modifiers");
    }
    
    private ModifierReflectionHelper(final Field field) {
        this.target = field;
        
        this.method = null;
        
        this.field = field;
        
        this.modifiersField = com.ws.commons.utils.reflection.field.FieldReflectionHelper.fromClass(target.getClass()).getField("modifiers");
    }
    
    /**
     * Returns an instance of this class with method initialization.
     *
     * @param method    that will have its modifier changed.
     * @return          the helper instance.
     */
    public static ModifierReflectionHelper from(final Method method) {
        return new ModifierReflectionHelper(method);
    }
    
    /**
     * Returns an instance of this class with field initialization.
     *
     * @param field that will have its modifier changed.
     * @return      the helper instance.
     */
    public static ModifierReflectionHelper from(final Field field) {
        return new ModifierReflectionHelper(field);
    }
    
    /**
     * Changes current modifier to the desired one via reflection.
     *
     * @param modifiers             that will be applied<b>(except final modifier)</b>.
     * @throws ReflectionException  if the reflection fail.
     */
    public void changeTo(final int modifiers) {
        remember(getModifiers());
        
        setModifiers(modifiers);
        
        forget(modifiers);
    }
    
    /**
     * Sets modifier to the instantiated object.
     *
     * @param modifiers that will be added.
     */
    public void add(final int modifiers) {
        forget(modifiers);
        
        setModifiers(getModifiersAdding(modifiers));
        
    }
    
    /**
     * Removes modifier from the instantiated object.
     *
     * @param modifiers that will be removed.
     */
    public void remove(final int modifiers) {
        remember(modifiers);
        
        setModifiers(getModifiersRemoving(modifiers));
    }
    
    /**
     * Replaces all modifiers with the public.
     */
    public void changeToPublic() {
        final int modifiers = getModifiers();
        
        if (Modifier.isPrivate(modifiers)) {
            setModifiers(getModifiersRemoving(Modifier.PRIVATE));
            
            remember(Modifier.PRIVATE);
        } else if (Modifier.isProtected(modifiers)) {
            setModifiers(getModifiersRemoving(Modifier.PROTECTED));
            
            remember(Modifier.PROTECTED);
        }
        
        setModifiers(getModifiersAdding(Modifier.PUBLIC));
        
        forget(Modifier.PUBLIC);
    }
    
    /**
     * Removes the final modifier and preserves the remaining modifiers. 
     */
    public void removeFinal() {
        setModifiers(getModifiersRemoving(Modifier.FINAL));
        
        remember(Modifier.FINAL);
    }
    
    /**
     * Undoes all changes made by this helper instance.
     */
    public void undo() {
        setModifiers(getModifiersRemoving(toForget));
        
        setModifiers(getModifiersAdding(toRemember));
        
        modifiersField.setAccessible(accessible);
    }
    
    private void setModifiers(final int modifiers) {
        try {
            accessible = modifiersField.isAccessible();
            
            modifiersField.setAccessible(true);
            
            modifiersField.setInt(target, modifiers);
        } catch (IllegalArgumentException | IllegalAccessException | SecurityException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    private int getModifiersAdding(final Integer modifiers) {
        if (modifiers == null) {
            return getModifiers();
        }
        
        return getModifiers() + modifiers;
    }

    private int getModifiersRemoving(final Integer modifiers) {
        if (modifiers == null) {
            return getModifiers();
        }
        
        if (method != null) {
            return method.getModifiers() != 0 ? method.getModifiers() & ~modifiers : method.getModifiers();
        } else {
            return field.getModifiers() != 0 ? field.getModifiers() & ~modifiers : field.getModifiers();
        }
    }
    
    private int getModifiers() {
        return method != null ? method.getModifiers() : field.getModifiers();
    }

    /**
     * @param modifiers that will be returned when {@link #undo()} is performed.
     */
    private void remember(final int modifiers) {
        toRemember = toRemember == null ? modifiers : toRemember + modifiers;
    }
    
    /**
     * @param modifiers that will be removed when {@link #undo()} is performed.
     */
    private void forget(final int modifiers) {
        toForget = toForget == null ? modifiers : toForget + modifiers;
    }
}
