package com.ws.commons.utils;

import com.ws.commons.message.EDefaultMessage;
import org.jboss.weld.bean.proxy.ProxyObject;
import org.jboss.weld.interceptor.util.proxy.TargetInstanceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.CDI;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Utility class to avoid duplicating CDI related code.
 *
 * @author  Gustavo P. Bilert
 * @author  Lucas Dillmann
 * @version 7.3.0 - 2018-09-11 - Added methods to search and retrieve beans using CDI
 * @since   2017-07-27
 */
public final class CDIUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(CDIUtils.class);
    private final BeanManager beanManager;
    private final Logger logger;

    /**
     * Private constructor with {@link BeanManager} initialization.
     *
     * @author              Lucas Dillmann
     * @param beanManager   {@link BeanManager} instance to be used
     * @since               7.3.0 - 2018-09-11
     */
    private CDIUtils(final BeanManager beanManager) {
        this.beanManager = beanManager;
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Gets an instance of this class using provided {@link BeanManager} instance.
     *
     * @author              Lucas Dillmann
     * @param beanManager   {@link BeanManager} to be used in CDI operations
     * @return              CDI utils instance using provided BeanManager
     * @since               7.3.0 - 2018-09-11
     */
    public static CDIUtils usingBeanManager(final BeanManager beanManager) {
        Objects.requireNonNull(beanManager, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("beanManager"));
        return new CDIUtils(beanManager);
    }

    /**
     * Gets an instance of this class using static CDI injection.
     *
     * @author  Lucas Dillmann
     * @return  CDI utils instance using BeanManager from static CDI injection
     * @since   7.3.0 - 2018-09-11
     */
    public static CDIUtils usingStaticInjection() {
        final BeanManager beanManager = CDI.current().getBeanManager();
        return new CDIUtils(beanManager);
    }

    /**
     * Extracts the original instance from the CDI proxy.
     *
     * @param instance  the instance which may be a CDI proxy
     * @param <T>       the type of the object
     * @return          the extracted instance
     */
    public static <T> T extractFromProxy(final T instance) {
        final Logger logger = LoggerFactory.getLogger(CDIUtils.class);
        logger.debug("Extracting '{}' from CDI proxy instance '{}'", instance.getClass().getName(), instance);

        if (instance instanceof TargetInstanceProxy) {
            final TargetInstanceProxy<T> instanceProxy = (TargetInstanceProxy<T>) instance;
            return instanceProxy.getTargetInstance();
        } else {
            logger.warn("Instance isn't a proxy instance. Extraction can't be done: {}", instance);
            return instance;
        }
    }

    /**
     * Returns a bean for the given type.
     *
     * <p>This method search for an available implementation of the given bean type using CDI.</p>
     *
     * <p>Be aware that this method uses the CDI bean resolution API to figure out which of all available
     * implementations should be used when there is more than one, following it's commons rules like
     * qualifiers, precedence, bean.xml file and others. If more than one bean is found and the CDI can't figure out
     * which one to use, this method will throw an exception (like a regular injection will do when that happens).</p>
     *
     * @author              Lucas Dillmann
     * @param beanType      bean type to search for
     * @param qualifiers    qualifiers of the implementation to look for (optional)
     * @param <T>           generic raw type
     * @return              bean instance retrieved from CDI
     * @since               7.3.0 - 2018-09-11
     * @deprecated Use {@link #getSingleBean(Class, Consumer, Annotation...)}
     */
    @Deprecated
    public <T> T getSingleBean(final Class<T> beanType, final Annotation... qualifiers) {
        logger.debug("Looking for a single bean of type '{}' and qualifiers '{}'", beanType, qualifiers);
        return resolveBean(beanType, qualifiers).orElse(null);
    }

    private <T> Optional<T> resolveBean(final Class<T> beanType, final Annotation... qualifiers) {
        return Optional
                .of(beanManager.getBeans(beanType, qualifiers))
                .map(beans -> (Bean<? extends T>) beanManager.resolve(beans))
                .map(this::getBeanInstance);
    }

    /**
     * @param beanType Bean class
     * @param consumer Bean instance consumer
     * @param qualifiers Bean qualifiers
     */
    public <T> void getSingleBean(final Class<T> beanType,
                                  final Consumer<Optional<T>> consumer,
                                  final Annotation... qualifiers) {
        final Optional<T> bean = resolveBean(beanType, qualifiers);
        try {
            consumer.accept(bean);
        } finally {
            bean.ifPresent(CDI.current()::destroy);
        }
    }

    /**
     * Returns a set of all available bean implementations for the given type.
     *
     * <p>This method search for all available implementations of the given type that are available using CDI. For all
     * results found an instance will be created and then returned in a set collection.</p>
     *
     * @author              Lucas Dillmann
     * @param beanType      bean type to search for
     * @param qualifiers    qualifiers of the implementation to look for (optional)
     * @param <T>           generic raw type
     * @return              a {@link Set} with all available implementations
     * @since               7.3.0 - 2018-09-11
     * @deprecated Use {@link #getAllAvailableBeans(Class, Consumer, Annotation...)} instead
     */
    @Deprecated
    public <T> Set<T> getAllAvailableBeans(final Class<T> beanType, final Annotation... qualifiers) {
        logger.debug("Looking for all beans of type '{}' and qualifiers '{}'", beanType, qualifiers);
        return resolveBeans(beanType, qualifiers);
    }

    private <T> Set<T> resolveBeans(final Class<T> beanType, final Annotation... qualifiers) {
        return beanManager
                .getBeans(beanType, qualifiers)
                .stream()
                .map(bean -> (Bean<? extends T>) bean)
                .map(this::getBeanInstance)
                .collect(Collectors.toSet());
    }

    public <T> void getAllAvailableBeans(final Class<T> beanType,
                                           final Consumer<Set<T>> consumer,
                                           final Annotation... qualifiers) {
        final Set<T> beans = resolveBeans(beanType, qualifiers);
        try {
            consumer.accept(beans);
        } finally {
            beans.forEach(CDI.current()::destroy);
        }

    }

    /**
     * Returns a bean for the given raw type and generic type.
     *
     * <p>This method search for an available implementation of the given raw type with the provided generic type
     * (from Java generics) using CDI.</p>
     *
     * <p>Be aware that this method uses the CDI bean resolution API to figure out which of all available
     * implementations should be used when there is more than one, following it's commons rules like
     * qualifiers, precedence, bean.xml file and others. If more than one bean is found and the CDI can't figure out
     * which one to use, this method will throw an exception (like a regular injection will do when that happens).</p>
     *
     * @author              Lucas Dillmann
     * @param rawType       raw type to search for
     * @param genericType   generic type o the raw one
     * @param qualifiers    qualifiers of the implementation to look for (optional)
     * @param <T>           generic raw type
     * @return              bean instance retrieved from CDI
     * @since 7.3.0 - 2018-09-11
     * @deprecated Use {@link #getSingleBean(Class, Class, Consumer, Annotation...)} instead
     */
    @Deprecated
    public <T> T getSingleBean(final Class<T> rawType, final Class<?> genericType, final Annotation... qualifiers) {
        logger.debug("Looking for a single bean of type '{}' and generic argument '{}' with qualifiers '{}'", rawType, genericType, qualifiers);
        return resolveBean(rawType, genericType, qualifiers).orElse(null);
    }


    private <T> Optional<T> resolveBean(final Class<T> rawType,
                                        final Class<?> genericType,
                                        final Annotation... qualifiers) {
        final ParameterizedType parameterizedType = buildParameterizedType(rawType, genericType);
        return Optional
                .of(beanManager.getBeans(parameterizedType, qualifiers))
                .map(beans -> (Bean<? extends T>) beanManager.resolve(beans))
                .map(this::getBeanInstance);
    }

    /**
     * @param rawType     raw type to search for
     * @param genericType generic type o the raw one
     * @param qualifiers  qualifiers of the implementation to look for (optional)
     * @param <T>         generic raw type
     */
    public <T> void getSingleBean(final Class<T> rawType,
                                  final Class<?> genericType,
                                  final Consumer<Optional<T>> consumer,
                                  final Annotation... qualifiers) {
        final Optional<T> bean = resolveBean(rawType, genericType, qualifiers);
        try {
            consumer.accept(bean);
        } finally {
            bean.ifPresent(CDI.current()::destroy);
        }
    }

    /**
     * Returns a set of all available bean implementations for the given raw type and generic type.
     *
     * <p>This method search for all available implementations of the given raw type with the provided generic type
     * (using Java generics) that are available using CDI. For all results found an instance will be created and
     * then returned in a set collection.</p>
     *
     * @author              Lucas Dillmann
     * @param rawType       raw type to search for
     * @param genericType   generic type o the raw one
     * @param qualifiers    qualifiers of the implementation to look for (optional)
     * @param <T>           generic raw type
     * @return              a {@link Set} with all available implementations
     * @since               7.3.0 - 2018-09-11
     * @deprecated Use {@link #getAllAvailableBeans(Class, Class, Consumer, Annotation...)}
     */
    public <T> Set<T> getAllAvailableBeans(final Class<T> rawType, final Class<?> genericType, final Annotation... qualifiers) {
        logger.debug("Looking for all beans of type '{}' and generic argument '{}' with qualifiers '{}'", rawType, genericType, qualifiers);
        return resolveBeans(rawType, genericType, qualifiers);
    }

    private <T> Set<T> resolveBeans(final Class<T> rawType,
                                    final Class<?> genericType,
                                    final Annotation... qualifiers) {
        final ParameterizedType parameterizedType = buildParameterizedType(rawType, genericType);
        return beanManager
                .getBeans(parameterizedType, qualifiers)
                .stream()
                .map(bean -> (Bean<? extends T>) bean)
                .map(this::getBeanInstance)
                .collect(Collectors.toSet());
    }

    /**
     * @param rawType     raw type to search for
     * @param genericType generic type o the raw one
     * @param qualifiers  qualifiers of the implementation to look for (optional)
     * @param consumer    Beans consumer
     */
    public <T> void getAllAvailableBeans(final Class<T> rawType,
                                           final Class<?> genericType,
                                           final Consumer<Set<T>> consumer,
                                           final Annotation... qualifiers) {

        final Set<T> beans = resolveBeans(rawType, genericType, qualifiers);
        try {
            consumer.accept(beans);
        } finally {
            beans.forEach(CDI.current()::destroy);
        }

    }

    /**
     * Creates and returns an object instance from CDI using provided bean details.
     *
     * @author      Lucas Dillmann
     * @param bean  bean details
     * @param <T>   generic bean type
     * @return      instance created from bean details
     * @since 7.3.0 - 2018-09-11
     */
    private <T> T getBeanInstance(final Bean<? extends T> bean) {
        final CreationalContext creationalContext = beanManager.createCreationalContext(null);
        return (T) bean.create(creationalContext);
    }

    /**
     * Builds and return a {@link ParameterizedType} object with the provided {@code rawType} and {@code genericType}.
     *
     * <p>This method creates and returns a runtime instance of a {@link ParameterizedType} with the provided raw and
     * generic types, allowing to create a representation required by CDI to locate any given class or interface
     * typed (using generics) with another class</p>
     *
     * @author              Lucas Dillmann
     * @param rawType       raw type class
     * @param genericType   generic class of the raw type
     * @since               7.3.0 - 2018-09-11
     */
    private <T> ParameterizedType buildParameterizedType(final Class<?> rawType, final Class<T> genericType) {
        return new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return new Type[]{genericType};
            }

            @Override
            public Type getRawType() {
                return rawType;
            }

            @Override
            public Type getOwnerType() {
                return rawType;
            }
        };
    }

    /**
     * Calls CDI destroy procedures when bean is a CDI provided instance
     *
     * @param beans Objects to be destroyed
     */
    public static void destroy(final Object... beans) {
        Arrays.stream(beans).forEach(bean -> {
            if (bean instanceof ProxyObject || bean instanceof TargetInstanceProxy) {
                CDI.current().destroy(bean);
            } else {
                LOGGER.debug("Not a CDI proxy ({}). Ignoring destruction call.", bean);
            }
        });
    }
}
