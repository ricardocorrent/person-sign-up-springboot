package com.ws.commons.utils.reflection;

import com.ws.commons.message.EDefaultMessage;

import java.util.Objects;

/**
 * This class is meant to aid repetitive reflection tasks related to throwable exceptions and reducing boilerplate.
 *
 * <p>It provides methods to verify if an exception cause matches an expected one.</p>
 * <pre>
 *     final boolean expected = ThrowableReflectionHelper.isThrowableCausedBy(throwable.getCause(), AnyThrowable.class);
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-12
 */
public final class ThrowableReflectionHelper {

    private ThrowableReflectionHelper() {}
    
    /**
     * Returns true if the exception is equal to the expected cause or it has an equal cause.
     * 
     * @param throwable     thrown.
     * @param causeClass    to be search.
     * @return              {@code true} if is the exception cause.
     */
    public static boolean isThrowableCausedBy(final Throwable throwable, final Class<? extends Throwable> causeClass) {
        Objects.requireNonNull(throwable, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("throwable"));
        
        Objects.requireNonNull(causeClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("causeClass"));
        
        if (ClassReflectionHelper.isClassRecursivelyEqualsTo(throwable.getClass(), causeClass)) {
            return true;
        } else if (throwable.getCause() != null) {
            return isThrowableCausedBy(throwable.getCause(), causeClass);
        }
        return false;
    }
}
