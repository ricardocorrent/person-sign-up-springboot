package com.ws.commons.utils.reflection.packages;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.ArrayUtils;
import com.ws.commons.utils.io.FileSeparator;
import com.ws.commons.utils.reflection.exception.ReflectionException;

import java.io.File;
import java.lang.annotation.Annotation;
import java.net.URL;
import java.util.Enumeration;
import java.util.Objects;

/**
 * This class is meant to aid repetitive reflection tasks related to {@link Package} and reducing boilerplate.
 *
 * <p>For example, if you want to find all classes that are annotated with some annotation, it is possible to use this
 * class like:</p>
 * <pre>
 *     final Set{@literal <Class<?>>} classesWithAnyAnnotation = PackageReflectionHelper
 *                  .fromPackage(AnyClass.class.getPackage())
 *                  .containingAnnotations(AnyAnnotation.class)
 *                  .recursively()
 *                  .getClassSet();
 * </pre>
 *
 * <p>It can easily be used to retrieve the root path from any class:</p>
 * <pre>
 *     final String rootPath = PackageReflectionHelper
 *                             .fromPackage(AnyClass.class.getPackage()).getRootPath();
 * </pre>
 *
 * @author  Diego Armange Costa
 * @version 6.1.0 - 2018-06-26 - Added new methods
 * @since   5.2.0 - 2017-09-27
 */
public class PackageReflectionHelper {

    /**
     * Value: \.
     */
    public static final String PACKAGE_SEPARATOR_REGEX = "\\.";

    /**
     * @see File#separator
     */
    public static final String FILE_SEPARATOR_REGEX = "\\".concat(File.separator);

    private final Package targetPackage;
    
    private PackageReflectionHelper(final Package targetPackage) {
        this.targetPackage = targetPackage;
    }
    
    /**
     * Returns a new instance of this class with the defined target package.
     *
     * @param packageTarget to determine the target for the reflection operations
     * @return              this helper with the defined target package
     */
    public static PackageReflectionHelper fromPackage (final Package packageTarget) {
        Objects.requireNonNull(packageTarget, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("packageTarget"));
        
        return new PackageReflectionHelper(packageTarget);
    }
    
    /**
     * Defines the class annotations that will be used to find the classes contained in the package.
     * 
     * @param annotations   to determine the filter for class search
     * @return              a {@link ClassFilter} instance with the defined filter to the class search
     */
    @SuppressWarnings("unchecked")
    public ClassFilter containingAnnotations(final Class<? extends Annotation>... annotations) {
        ArrayUtils.validateNotContainNull("annotation", (Object[]) annotations);
        
        return new ClassFilter(this.targetPackage, annotations);
    }
    
    /**
     * Returns the paths of the available resources represented by the package name.
     * <br>
     * <b>Package name:</b> com.package.any
     * <br>
     * <b>Resource:</b> com/package/any
     * 
     * @param packageTarget to find resource paths
     * @return              the found resources by package name
     * @see                 ClassLoader#getResources(String)
     * @since               6.1.0 - 2018-06-26 - Deprecated
     * @deprecated          use {@link #getPath()}
     */
    @Deprecated
    public static Enumeration<URL> forPackage(final Package packageTarget) {
        Objects.requireNonNull(packageTarget, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("packageTarget"));
        
        try {
            return Thread.currentThread().getContextClassLoader().getResources(getNameAsResourcePath(packageTarget));
        } catch (Exception exception) {
            throw new ReflectionException(exception);
        }
    }

    /**
     * Converts the package name to resource path.
     * <br>
     * <b>Package name:</b> com.package.any
     * <br>
     * <b>Resource:</b> com/package/any
     * 
     * @param packageTarget to convert the package name to resource path
     * @return              the resource path.
     */
    public static String getNameAsResourcePath(final Package packageTarget) {
        return packageTarget.getName().replaceAll(PACKAGE_SEPARATOR_REGEX, FILE_SEPARATOR_REGEX);
    }
    
    /**
     * Converts the package name to resource path.
     * <br>
     * <b>Package name:</b> com.package.any
     * <br>
     * <b>Resource:</b> com/package/any
     *
     * @param fileSeparator the file separator to format the resource path
     * @return              the resource path.
     * @since               6.1.0 - 2018-06-26
     */
    public String getNameAsResourcePath(final FileSeparator fileSeparator) {
        return this.targetPackage.getName().replaceAll(PACKAGE_SEPARATOR_REGEX, fileSeparator.getSeparatorRegex());
    }
    
    /**
     * Returns the paths of the available resources represented by the package name.
     * <br>
     * <b>Package name:</b> com.package.any
     * <br>
     * <b>Resource:</b> com/package/any
     *
     * @return  the found resources by package name
     * @see     ClassLoader#getResources(String)
     * @since   6.1.0 - 2018-06-26
     */
    public String getPath() {
        try {
            final Enumeration<URL> enumeration = Thread.currentThread()
                    .getContextClassLoader().getResources(getNameAsResourcePath(FileSeparator.UNIX));
            
            return enumeration.nextElement().getPath();
        } catch (Exception exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Unix example:<br>
     * <b>Class path:</b> /home/com/package/Any.class<br>
     * <b>Package path:</b> /home/com/package<br>
     * <b>Root path:</b> /home

     * @return  the root path from resource path
     * @since   6.1.0 - 2018-06-26
     */
    public String getRootPath() {
        final String nameAsResourcePath = getNameAsResourcePath(FileSeparator.UNIX);
        
        final String path = getPath();
        
        return path.substring(0, path.indexOf(nameAsResourcePath));
    }
}
