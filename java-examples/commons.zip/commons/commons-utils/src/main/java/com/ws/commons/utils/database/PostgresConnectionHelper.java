package com.ws.commons.utils.database;

import com.google.common.io.Files;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

/**
 * Helper class that is able to provide SQL connection in the PostgreSQL database.
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-28
 */
public final class PostgresConnectionHelper {
    
    private final String driver;
    private final String url;
    private final String userName;
    private final String password;
    
    private Connection connection;
    
    private PostgresConnectionHelper(final String driver, final String url, final String userName, final String password) {
        this.driver = driver;
        this.url = url;
        this.userName = userName;
        this.password = password;
    }
    
    /**
     * Creates a new instance receiving parameters from persistence properties configuration data.
     *
     * @param driver    the database connection driver
     * @param url       the database connection URL
     * @param userName  the database connection userName
     * @param password  the database connection password
     * @return          the helper with the database connection properties
     */
    public static PostgresConnectionHelper fromPersistenceProperties(final String driver, final String url, final String userName, final String password) {
        return new PostgresConnectionHelper(driver, url, userName, password);
    }

    /**
     * Creates a connection, executes the command entered, and closes the connection.
     *
     * @param scripts                   as commands to be executed in POSTGRES
     * @throws SQLException             if command fails
     * @throws ClassNotFoundException   if the driver class is not valid
     */
    public void runInPostgres(final String... scripts) throws SQLException, ClassNotFoundException {
        buildNewConection();
        
        try(final Statement statement = this.connection.createStatement()) {
            for (final String script : scripts) {
                statement.execute(script);
            }
        } finally {
            this.connection.close();
        }
    }
    
    /**
     * Executes a SQL file in database.
     *
     * @param scripts                   the SQL File to be executed
     * @throws SQLException             if connection fails
     * @throws ClassNotFoundException   if connection fails
     * @throws IOException              if script execution fails
     */
    public void runInPostgres(final File... scripts) throws ClassNotFoundException, SQLException, IOException {
        runInPostgresWithSchema(null, scripts);
    }
    
    /**
     * Executes a SQL file in database.
     *
     * @param schema                    the database schema where the script will be applied
     * @param scripts                   the SQL File to be executed
     * @throws SQLException             if connection fails
     * @throws ClassNotFoundException   if connection fails
     * @throws IOException              if script execution fails
     */
    public void runInPostgresWithSchema(final String schema, final File... scripts) throws ClassNotFoundException, SQLException, IOException {
        buildNewConection();
        
        try(final Statement statement = this.connection.createStatement()) {
            if (schema == null) {
                for (final File script : scripts) {
                    statement.execute(getSQLFileContent(script));
                }
            } else {
                for (final File script : scripts) {
                    statement.execute(getSQLFileContent(schema, script));
                }
            }
        } finally {
            this.connection.close();
        }
    }

    private void buildNewConection() throws ClassNotFoundException, SQLException {
        //--> trazer pelo deltaspike
        
        Class.forName(this.driver);
        
        this.connection = DriverManager.getConnection(
                this.url,
                this.userName,
                this.password);
    }
    
    /**
     * Executes a CHARSET UTF-8 file with SQL extension in database.
     *
     * @param schema        the database schema where the script will be applied
     * @param script        the CHARSET UTF-8 file with SQL extension to be executed
     * @return              the file content
     * @throws IOException  if file reading fails
     */
    public String getSQLFileContent(final String schema, final File script) throws IOException {
        final String targetSchema = "set schema '" + schema + "';";
        
        return targetSchema + getSQLFileContent(script);
    }
    
    /**
     * Executes a CHARSET UTF-8 file with SQL extension in database
     *
     * @param script        the CHARSET UTF-8 file with SQL extension to be executed
     * @throws IOException  if file reading fails
     * @return              the file content
     */
    public String getSQLFileContent(final File script) throws IOException {
        return Files.readLines(script, StandardCharsets.UTF_8)
                .stream().collect(Collectors.joining(StringUtils.LF));
    }
}
