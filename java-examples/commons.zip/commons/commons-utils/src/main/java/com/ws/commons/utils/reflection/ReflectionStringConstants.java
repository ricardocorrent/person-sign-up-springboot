package com.ws.commons.utils.reflection;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Constants used for common utilities in reflection operations.
 *
 * @author Diego A. Costa
 * @see MethodReflectionHelper
 * @see FieldReflectionHelper
 * @since 6.0.0 - 2018-04-16
 */
public enum ReflectionStringConstants implements StringConstants {

    /**
     * Value: Field name: %s
     */
    FIELD_NAME_MESSAGE("Field name: %s"),
    
    /**
     * Value: Method name: %s
     */
    METHOD_NAME_MESSAGE("Method name: %s"),
    
    /**
     * Value: field
     */
    FIELD_NAME("field"),
    
    /**
     * Value: method
     */
    METHOD_NAME("method"),
    
    /**
     * Value: declaringClass
     */
    DECLARING_CLASS_NAME("declaringClass"),
    
    /**
     * Value: declaringInstance
     */
    DECLARING_INSTANCE_NAME("declaringInstance"),
    ;
    
    private String value;
    
    ReflectionStringConstants(final String value) {
        this.value = value;
    }
    
    /**
     * @see com.ws.commons.utils.reflection.StringConstants#getValue()
     */
    @Override
    public String getValue() {
        return value;
    }
}
