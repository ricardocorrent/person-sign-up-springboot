package com.ws.commons.utils.reflection;

/**
 * Interface to represent enumerable constants.
 *
 * @author Diego A. Costa
 * @since 6.0.0 - 2018-04-16
 */
public interface StringConstants {

    /**
     * @return a constant value.
     */
    String getValue();
}
