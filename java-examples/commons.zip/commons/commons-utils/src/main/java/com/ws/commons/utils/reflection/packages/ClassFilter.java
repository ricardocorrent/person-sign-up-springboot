package com.ws.commons.utils.reflection.packages;

import java.io.File;
import java.lang.annotation.Annotation;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.ws.commons.utils.ArrayUtils;
import com.ws.commons.utils.reflection.exception.ReflectionException;

/**
 * Represents the filter configuration to search for classes within any package.
 * 
 * @author  Diego Armange Costa
 * @since   5.2.0 - 2017-09-27
 */
public class ClassFilter {
    private static final String CLASS_EXTENSION_REGEX = "\\.class$";

    private final Package rootPackage;
    
    private final Class<? extends Annotation>[] annotations;
    
    private final Set<Class<?>> classSet = new HashSet<>();
    
    private boolean recursively;
    
    /**
     * Constructor with {@code rootPackage} and {@code annotations} initialization.
     *
     * @param rootPackage to find the classes.
     * @param annotations representing the search filter to find the classes.
     */
    ClassFilter(final Package rootPackage, final Class<? extends Annotation>... annotations) {
        this.rootPackage = rootPackage;
        
        this.annotations = annotations;
    }
    
    /**
     * Instantiates this class with {@code recursively} flag configuration to search
     * for classes contained in packages within packages.
     *
     * @return this class filter instance with recursive flag
     */
    public ClassFilter recursively() {
        this.recursively = true;
        
        return this;
    }
    
    /**
     * Retrieves a {@link Set} of classes contained in the package.
     *
     * @return the class contained in the package informed and with the given filters.
     */
    public Set<Class<?>> getClassSet() {
        final Enumeration<URL> urls = PackageReflectionHelper.forPackage(rootPackage);
        
        try {
            handleURLsToFindClasses(urls);
        } catch (Exception exception) {
            throw new ReflectionException(exception);
        }
        
        return this.classSet;
    }
    
    private void handleURLsToFindClasses(final Enumeration<URL> urls) throws URISyntaxException {
        while (urls.hasMoreElements()) {
            final File packageDirectory = getFileFromURL(urls);

            handleDirectoryToFindClasses(packageDirectory);
        }
    }

    private File getFileFromURL(final Enumeration<URL> urls) throws URISyntaxException {
        return new File(urls.nextElement().toURI());
    }
    
    private void handleDirectoryToFindClasses(final File file) {
        final File[] nextLevelPath = file.listFiles();
        
        if (ArrayUtils.isNotEmpty(nextLevelPath)) {
            for (final File nextLevelFile : nextLevelPath) {
                handleFileToAddIntoClassList(nextLevelFile);
            }
        }
    }

    //https://stackoverflow.com/questions/10993418/package-getpackage-in-java-returning-null
    private void handleFileToAddIntoClassList(final File file) {
        if (isJavaFile(file)) {
            final Class<?> foundClass = readClassFile(file);
            
            if (isAnntationPresent(foundClass)) {
                this.classSet.add(foundClass);
            }
        } else if (this.recursively && file.isDirectory()) {
            handleDirectoryToFindClasses(file);
        }
    }

    private boolean isJavaFile(final File file) {
        return file.isFile() && file.getName().toLowerCase().endsWith(".class");
    }
    
    private boolean isAnntationPresent(final Class<?> targetClass) {
        for (final Class<? extends Annotation> annotation : this.annotations) {
            if (targetClass.isAnnotationPresent(annotation)) {
                return true;
            }
        }
        
        return false;
    }

    private Class<?> readClassFile(final File file) {
        try {
            return Class.forName(getQualifiedName(file));
        } catch (ClassNotFoundException exception) {
            throw new ReflectionException(exception);
        }
    }

    private String getQualifiedName(final File file) {
        final String path = file.getPath()
                .replaceAll(PackageReflectionHelper.FILE_SEPARATOR_REGEX, PackageReflectionHelper.PACKAGE_SEPARATOR_REGEX)
                .replaceAll(CLASS_EXTENSION_REGEX, StringUtils.EMPTY);
        
        int startQualifiedName = path.indexOf(this.rootPackage.getName());
        
        return path.substring(startQualifiedName);
    }
}
