package com.ws.commons.utils.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.exception.ReflectionException;

/**
 * This class is meant to aid repetitive reflection tasks related to {@link Class} and reducing boilerplate.
 *
 * <p>It can be used to retrieve new instances of classes using reflection strategies.</p>
 * <pre>
 *     final Object object = ClassReflectionHelper.newInstanceFromClass(Any.class);
 * </pre>
 *
 * <p>It also can be used to find out if any class is recursively equal to another one:</p>
 * <pre>
 *     ClassReflectionHelper.isClassRecursivelyEqualsTo(AnyClass.class, AnotherClass.class);
 * </pre>
 *
 * @author  Diego Armange Costa
 * @version 5.3.1 - 2017-12-04 - Added class loading.
 * @since   5.0.0 - 2017-08-08
 */
public final class ClassReflectionHelper {

    private ClassReflectionHelper() {}
    
    /**
     * Returns a new instance from class.
     * 
     * @param <C>           as class type.
     * @param targetClass   as instance class
     * @return              a new instance
     */
    public static <C> C newInstanceFromClass(final Class<C> targetClass) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("targetClass"));
        
        try {
            final Class<?> declaringClass = targetClass.getDeclaringClass();
            
            if (declaringClass == null) {
                final Constructor<C> declaredConstructor = targetClass.getDeclaredConstructor();
                
                declaredConstructor.setAccessible(true);
                
                return declaredConstructor.newInstance();
            } else {
                final Object enclosingInstance = newInstanceFromClass(declaringClass);
                
                final Constructor<C> declaredConstructor = targetClass.getDeclaredConstructor(declaringClass);
                
                declaredConstructor.setAccessible(true);
                
                return declaredConstructor.newInstance(enclosingInstance);
            }
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Makes a comparison between two classes and returns {@code true} if their superclasses are equal.
     *
     * @param leftClass     to compare with right class.
     * @param rightClass    to compare with left class or its superclasses.
     * @return              {@code true} if the left class or its superclasses are equal to the right class.
     */
    public static boolean isClassRecursivelyEqualsTo(final Class<?> leftClass, final Class<?> rightClass) {
        Objects.requireNonNull(leftClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("leftClass"));
        
        return leftClass.equals(rightClass) || leftClass.getSuperclass() != null && isClassRecursivelyEqualsTo(leftClass.getSuperclass(), rightClass);
    }
    
    /**
     * Returns the {@code Class} object associated with the class or interface with the given string name.
     *
     * @param qualifiedName to load class.
     * @return              the loaded class.
     * @see                 ClassReflectionHelper#forName(String)
     */
    public static Class<?> forName(final String qualifiedName) {
        try {
            return Class.forName(qualifiedName);
        } catch (ClassNotFoundException exception) {
            throw new ReflectionException(exception);
        }
    }
}
