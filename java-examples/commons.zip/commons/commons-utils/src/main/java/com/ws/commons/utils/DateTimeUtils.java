package com.ws.commons.utils;

import com.ws.commons.server.json.LocalDateDeserializer;
import com.ws.commons.server.json.LocalTimeDeserializer;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.OffsetTimeDeserializer;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;

/**
 * Utility class for conversion of {@link String} dates to other time-related objects such as {@link LocalDate} and
 * {@link LocalTime}.

 * @author  Ivan A. Reffatti
 * @author  Franciones Marmentini
 * @version 4.12.0 - 2017-08-02
 * @since   1.1.0 - 2016-07-08
 */
public final class DateTimeUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(DateTimeUtils.class);

    private DateTimeUtils() {}

    /**
     * {@link String} to {@link LocalDate} converter.
     *
     * @author              Ivan A. Reffatti
     * @param date          the date to convert
     * @return              the converted date
     * @throws IOException  if conversion fails
     * @since               1.1.0 - 2016-07-08
     */
    public static LocalDate convertLocalDate(final String date) throws IOException {
        LOGGER.debug("Converting '{}' to '{}'", date, LocalDate.class);
        LocalDateDeserializer deserializer = BeanProvider.getContextualReference(LocalDateDeserializer.class);
        return deserializer.deserialize(date);
    }
    /**
     * {@link String} to {@link LocalTime} converter.
     *
     * @author              Ivan A. Reffatti
     * @param date          the date to convert
     * @return              the converted date
     * @throws IOException  if conversion fails
     * @since               1.1.0 - 2016-07-08
     */
    public static LocalTime convertLocalTime(final String date) throws IOException {
        LOGGER.debug("Converting '{}' to '{}'", date, LocalTime.class);
        LocalTimeDeserializer deserializer = BeanProvider.getContextualReference(LocalTimeDeserializer.class);
        return deserializer.deserialize(date);
    }
    /**
     * {@link String} to {@link OffsetDateTime} converter.
     *
     * @author              Ivan A. Reffatti
     * @param date          the date to convert
     * @return              the converted date
     * @throws IOException  if conversion fails
     * @since               1.1.0 - 2016-07-08
     */
    public static OffsetDateTime convertOffSetDateTime(final String date) throws IOException {
        LOGGER.debug("Converting '{}' to '{}'", date, OffsetDateTime.class);
        OffsetDateTimeDeserializer deserializer = BeanProvider.getContextualReference(OffsetDateTimeDeserializer.class);
        return deserializer.deserialize(date);
    }
    /**
     * {@link String} to {@link OffsetTime} converter.
     *
     * @author              Ivan A. Reffatti
     * @param time          the time to convert
     * @return              the converted time
     * @throws IOException  if conversion fails
     * @since               1.1.0 - 2016-07-08
     */
    public static OffsetTime convertOffSetTime(final String time) throws IOException {
        LOGGER.debug("Converting '{}' to '{}'", time, OffsetTime.class);
        OffsetTimeDeserializer deserializer = BeanProvider.getContextualReference(OffsetTimeDeserializer.class);
        return deserializer.deserialize(time);
    }
}
