package com.ws.commons.utils.reflection.exception;

/**
 * Exception class for any reflection-related error.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 - 2017-08-07
 */
@SuppressWarnings("serial")
public class ReflectionException extends RuntimeException{

    /**
     * @see java.lang.RuntimeException#RuntimeException()
     */
    public ReflectionException() {
        super();
    }
    
    /**
     * @param message the exception message.
     * @see java.lang.RuntimeException#RuntimeException(String)
     */
    public ReflectionException(final String message) {
        super(message);
    }
    
    /**
     * @param cause the exception cause.
     * @see java.lang.RuntimeException#RuntimeException(Throwable)
     */
    public ReflectionException(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message the exception message.
     * @param cause the exception cause.
     * @see java.lang.RuntimeException#RuntimeException(String, Throwable)
     */
    public ReflectionException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
