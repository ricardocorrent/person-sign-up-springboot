package com.ws.commons.utils.reflection.field;

import com.ws.commons.utils.reflection.*;
import com.ws.commons.utils.reflection.MethodReflectionHelper.EncapsulationMethod;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.apache.commons.lang3.ArrayUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * This class is meant to aid repetitive reflection tasks related to {@link Field} and reducing boilerplate.
 *
 * <p>To retrieve the "any" {@link Field} from a class using reflection strategies:</p>
 * <pre>
 *     final Field field = FieldReflectionHelper.fromClass(AnyClass.class).getField("any");
 * </pre>
 *
 * <p>If you want to retrieve all fields from a class:</p>
 * <pre>
 *     final List{@literal <Field>} fields = FieldReflectionHelper.forClass(Any.class).getFields();
 * </pre>
 *
 * @author  Diego Armange Costa
 * @version 5.3.0 - 2017-11-23 - Added declaringClass and declaringField to scope.
 * @version 5.3.1 - 2017-11-04 - Added getFieldValue by Field Object.
 * @since   5.1.0 2017-10-02
 */
public final class FieldReflectionHelper {
    private boolean allowSyntheticField;

    /**
     * Created to normalize Method return on {@link FieldReflectionHelper#getFieldValueByGetter(Field, Object...)}.
     *
     * @author Diego Armange Costa
     * @since 5.0.0 - 2017-09-11
     */
    public enum MethodReturnStatus {
        /**
         * Method not found status.
         */
        METHOD_NOT_FOUND
    }
    
    private final Class<?> declaringClass;
    
    private Object declaringInstance;
    
    private FieldReflectionHelper(final Class<?> declaringClass) {
        this.declaringClass = declaringClass;
    }
    
    private FieldReflectionHelper(final Object declaringInstance) {
        this.declaringInstance = declaringInstance;
        
        this.declaringClass = declaringInstance.getClass();
    }
    
    /**
     * Starts reflecting over a class.
     * 
     * @param declaringClass    to start reflecting.
     * @return                  a {@link FieldReflectionHelper}'s instance with a declaring class defined.
     */
    public static FieldReflectionHelper fromClass(final Class<?> declaringClass) {
        ObjectHelper.requireNotNullParameter(declaringClass, ReflectionStringConstants.DECLARING_CLASS_NAME);
        
        return new FieldReflectionHelper(declaringClass);
    }
    
    /**
     * Starts reflecting over a instance.
     * 
     * @param declaringInstance to start reflecting.
     * @return A {@link FieldReflectionHelper}'s instance with a declaring class and a declaring instance defined.
     */
    public static FieldReflectionHelper fromInstance(final Object declaringInstance) {
        ObjectHelper.requireNotNullParameter(declaringInstance, ReflectionStringConstants.DECLARING_INSTANCE_NAME);
        
        return new FieldReflectionHelper(declaringInstance);
    }
    
    /**
     * Any field search will also include synthetic fields.
     *
     * @see Field#isSynthetic()
     */
    public void includeSynteticField() {
        allowSyntheticField = true;
    }
    
    /**
     * Retrieves the current value of the {@code field}, using {@link Field} as parameter.
     *
     * @param field from where the value will be obtained.
     * @return      the field content
     */
    public Object getFieldValue(final Field field) {
        ObjectHelper.requireNotNullParameter(field);
        
        try {
            field.setAccessible(true);
            
            return field.get(declaringInstance);
        } catch (final IllegalArgumentException | IllegalAccessException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Retrieves the current value of the {@code fieldName}, using a {@link String} that represents the field name
     * as parameter.
     *
     * @param fieldName to be search field.
     * @return          the field value
     */
    public Object getFieldValue(final String fieldName) {
        ObjectHelper.requireNotNullParameter(fieldName, ReflectionStringConstants.FIELD_NAME);
        
        final Field field = getField(fieldName);
        
        try {
            field.setAccessible(true);
            
            return field.get(declaringInstance);
        } catch (final IllegalArgumentException | IllegalAccessException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Retrieves a {@link Field} object by reflection using the {@code fieldName}.
     *
     * @param fieldName as the desired field
     * @return          a field from type
     */
    public Field getField(final String fieldName) {
        ObjectHelper.requireNotNullParameter(fieldName, ReflectionStringConstants.FIELD_NAME);
        
        try {
            final Field declaredField = declaringClass.getDeclaredField(fieldName);
            
            validateSynteticField(declaredField);
            
            return declaredField;
        } catch (final NoSuchFieldException noSuchFieldException) {
            if (declaringClass.getSuperclass() == null || declaringClass.getSuperclass().equals(Object.class)) {
                throw new ReflectionException(getNoSuchFieldExceptionMessage(declaringClass, fieldName), noSuchFieldException);
            } else {
                return FieldReflectionHelper.fromClass(declaringClass.getSuperclass()).getField(fieldName);
            }
        }
    }

    /**
     * Returns a field by name, searching recursively in the declaring class and its superclasses.
     * 
     * @param fieldNames    as the desired fields
     * @return              a field from type
     */
    public List<Field> getFields(final String... fieldNames) {
        final List<Field> fields = new ArrayList<>();
        
        if (ArrayUtils.isNotEmpty(fieldNames)) {
            getDeclaredFields(fields, declaringClass, fieldNames);
        } else {
            getDeclaredFields(fields, declaringClass);
        }

        removeSynteticFieldsIfNotAllowed(fields);
        
        return fields;
    }

    private void getDeclaredFields(final List<Field> fields, final Class<?> declaringClass) {
        ObjectHelper.requireNotNullParameter(fields, "fields");
        
        fields.addAll(Arrays.asList(declaringClass.getDeclaredFields()));
        
        if (declaringClass.getSuperclass() != null && !declaringClass.getSuperclass().equals(Object.class)) {
            getDeclaredFields(fields, declaringClass.getSuperclass());
        }
    }

    private void getDeclaredFields(final List<Field> fields, final Class<?> declaringClass, final String... fieldNames) {
        ObjectHelper.requireNotNullParameter(fields, "fields");
        
        com.ws.commons.utils.ArrayUtils.validateNotContainNull("fieldNames", (Object[]) fieldNames);
        
        for (String fieldName : fieldNames) {
            try {
                final Field declaredField = declaringClass.getDeclaredField(fieldName);
                
                validateSynteticField(declaredField);
                
                fields.add(declaredField);
            } catch (final NoSuchFieldException noSuchFieldException) {
                if (declaringClass.getSuperclass() == null || declaringClass.getSuperclass().equals(Object.class)) {
                    throw new ReflectionException(getNoSuchFieldExceptionMessage(declaringClass, fieldName), noSuchFieldException);
                } else {
                    getDeclaredFields(fields, declaringClass.getSuperclass(), fieldName);
                }
            }
        }
    }

    /**
     * <pre>
     * Inserts the value within the field considering whether the value is primitive or an object.
     *   Primitive field: field.set(declaringInstance, Integer.class.cast(value).intValue());
     * </pre>
     * 
     * @param field that will to receive the value 
     * @param value to insert into field
     */
    public void setFieldValue(final Field field, final Object value) {
        ObjectHelper.requireNotNullParameter(field, "field");
        
        validateSynteticField(field);
        
        try {
            field.setAccessible(true);
            
            field.set(declaringInstance, value);
        } catch (IllegalArgumentException | IllegalAccessException exception) {
            throw new ReflectionException(exception);
        }
    }

    private static String getNoSuchFieldExceptionMessage(final Class<?> type, final String fieldName) {
        final StringBuilder stringBuilder = new StringBuilder();
        
        stringBuilder.append("No such field: ").
        append(fieldName).
        append(" -> Type: ").
        append(type.getName());
        
        return stringBuilder.toString();
    }
    
    /**
     * Uses reflection strategies to obtain current {@link Field}'s setter and invokes it to set a {@code value}.
     *
     * @param field to get the references to invoke the setter.
     * @param value to be set.
     * @return {@code true} if the method exists, false if not exists or throws {@link ReflectionException} if the invocation fails.
     */
    public boolean setFieldValueBySetter(final Field field, final Object... value) {
        ObjectHelper.requireNotNullParameter(field);
        
        validateSynteticField(field);
        
        final Method setter = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.SET);
        
        try {
            if (setter != null) {
                setter.invoke(declaringInstance, value);
                
                return true;
            } else {
                return false;
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Uses reflection strategies to obtain the {@link Field} getter and retrieves its current value by invoking it.
     *
     * @param field                 to get the references to invoke the setter.
     * @param value                 to be set.
     * @return                      the found value if getter method exists, the {@link MethodReturnStatus#METHOD_NOT_FOUND} if not exists
     * @throws ReflectionException  if the invocation fails
     */
    public Object getFieldValueByGetter(final Field field, final Object... value) {
        ObjectHelper.requireNotNullParameter(field);
        
        validateSynteticField(field);
        
        final Method getter = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        try {
            if (getter != null) {
                return getter.invoke(declaringInstance, value);
            } else {
                return MethodReturnStatus.METHOD_NOT_FOUND;
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
            throw new ReflectionException(exception);
        }
    }
    
    /**
     * Uses reflection strategies to obtain the {@link Field} getter and retrieves its current value by invoking it.
     * <p>
     * When the field type is a primitive boolean, it will search for using {@link EncapsulationMethod#FORCE_GET} prefixes.
     * This will ignore Java encapsulation convention, as the method tries to use a {@code getBoolean()} method before a
     * {@code isBoolean()} one.
     * </p>
     *
     * @param field                 to get the references to invoke the getter.
     * @param value                 to be set.
     * @return                      the found value if getter method exists, the {@link MethodReturnStatus#METHOD_NOT_FOUND} if not exists,
     * @throws ReflectionException  if the invocation fails.

     */
    public Object getFieldValueByGetterIgnoringConvention(final Field field, final Object... value) {
        ObjectHelper.requireNotNullParameter(field);
        
        validateSynteticField(field);
        
        final Method getter = MethodReflectionHelper.getInstance()
                .getEncapsulationMethodIgnoringConvetion(field, MethodReflectionHelper.EncapsulationMethod.GET);
        try {
            if (getter != null) {
                return getter.invoke(declaringInstance, value);
            } else {
                return MethodReturnStatus.METHOD_NOT_FOUND;
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
            throw new ReflectionException(exception);
        }
    }

    /**
     * Walks through a given attribute path and returns the last {@link Field} that does not implement/extend the class
     * passed in {@code superClass} parameter.<br>
     * It's expected the field to be in the last node of the path.
     *
     * @param rawPath       the path for the requested attribute
     * @param superClasses  the class which every field in the path shall be inherited from
     * @return              the {@link Field} of the last field in the path, or {@code null} if the attribute was not
     *                      found or didn't matched the class inheritance criteria
     */
    public Field getLastUninheritedFieldFromPath(final String rawPath, final Class<?>... superClasses) {
        com.ws.commons.utils.ArrayUtils.validateNotContainNull("superclasses", superClasses);

        final FieldPath fieldPath = FieldPath.fromPath(rawPath).withClass(declaringClass);
        
        try {
            fieldPath.popRootFromPath();
            
            final Field field = fieldPath.getCurrentField();

            final Class<?> fieldType = Class.class.cast(fieldPath.getCurrentFieldType());
            
            if (isFieldTypeEqualsToSuperclass(fieldType, superClasses) || isFieldTypeNotAssignableFromSuperclass(fieldType, superClasses)) {
                return field;
            } else {
                return FieldReflectionHelper.fromClass(fieldType).getLastUninheritedFieldFromPath(fieldPath.getCurrentPath(), superClasses);
            }
        } catch (Exception ex) {
            throw new ReflectionException(ex);
        }
    }
    
    private boolean isFieldTypeEqualsToSuperclass(final Class<?> fieldType, final Class<?>[] superClasses) {
        return Stream.of(superClasses).anyMatch(fieldType::equals);
    }
    
    private boolean isFieldTypeNotAssignableFromSuperclass(final Class<?> fieldType, final Class<?>[] superClasses) {
        return Stream.of(superClasses).noneMatch(superclass -> superclass.isAssignableFrom(fieldType));
    }

    /**
     * Recursively searches a class {@link Field} for a given attribute path, considering
     * every classes' superclass.
     *
     * @author          Cristopher Zanchetta
     * @author          Diego A. Costa
     * @param rawPath   path for the requested attribute
     * @return          the corresponding {@link Field} to the attribute represented by the path
     */
    public Field getFieldFromPath(final String rawPath) {
        final FieldPath fieldPath = FieldPath.fromPath(rawPath);

        try {
            final String currentFieldName = fieldPath.popRootFromPath();
            
            final Field currentField = getField(currentFieldName);

            if (currentFieldName.equals(currentField.getName()) && fieldPath.isEmptyPath() ) {
                return currentField;
            } else {
                return FieldReflectionHelper.fromClass(TypeReflectionHelper.getGenericFieldType(currentField,0)).getFieldFromPath(fieldPath.getCurrentPath());
            }
        } catch (Exception ex) {
            throw new ReflectionException(ex);
        }
    }

    /**
     * Instantiates a {@link FieldFilter} object with the {@code declaringClass}.
     *
     * @return a {@link FieldFilter}'s instance to handle the field filters.
     */
    @SuppressWarnings("unchecked")
    public FieldFilter fieldFilter() {
        return new FieldFilter(declaringClass);
    }
    
    private void validateSynteticField(final Field declaredField) {
        if (!allowSyntheticField) {
            SyntheticValidator.denySyntetic(declaredField);
        }
    }
    
    private void removeSynteticFieldsIfNotAllowed(final List<Field> fields) {
        if (!allowSyntheticField) {
            fields.removeIf(Field::isSynthetic);
        }
    }
}
