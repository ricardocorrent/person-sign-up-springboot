package com.ws.commons.utils.io;

/**
 * Provides the file separator's char and its REGEX value, according to operational system platform.
 *
 * <p>On unix systems, the {@link #UNIX} constant should be used to retrieve files using paths like
 * {@code /home/com/package/Any.class}
 * </p>
 *
 * <p>In case of Windows, the same path should be displayed as {@code \\home\\com\\package\\Any.class}</p>
 *
 * @author  Diego A. Costa
 * @since   6.1.0 - 2018-06-26
 */
public enum FileSeparator {

    /**
     * Value: "/"
     */
    UNIX("/"),
    
    /**
     * Value: "\\"
     */
    WINDOWS("\\")
    ;
    
    private String separator;
    
    FileSeparator(final String separator) {
        this.separator = separator;
    }
    
    /**
     * @return the separator
     */
    public String getSeparator() {
        return this.separator;
    }
    
    /**
     * @return the separator REGEX
     */
    public String getSeparatorRegex() {
        return "\\".concat(this.separator);
    }
}
