package com.ws.commons.utils.reflection.exception;

import java.lang.reflect.Field;

/**
 * Exception class that will be thrown if any synthetic field (identified by {@link Field#isSynthetic()}) is found.
 *
 * @author  Diego A. Costa
 * @since   6.0.0 - 2018-04-16
 */
@SuppressWarnings("serial")
public class SyntheticFieldNotAllowed extends RuntimeException{

    /**
     * @see java.lang.RuntimeException#RuntimeException()
     */
    public SyntheticFieldNotAllowed() {
        super();
    }
    
    /**
     * @param message the exception message.
     * @see java.lang.RuntimeException#RuntimeException(String)
     */
    public SyntheticFieldNotAllowed(final String message) {
        super(message);
    }
    
    /**
     * @param cause the exception cause.
     * @see java.lang.RuntimeException#RuntimeException(Throwable)
     */
    public SyntheticFieldNotAllowed(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message the exception message.
     * @param cause the exception cause.
     * @see java.lang.RuntimeException#RuntimeException(String, Throwable)
     */
    public SyntheticFieldNotAllowed(final String message, final Throwable cause) {
        super(message, cause);
    }
}