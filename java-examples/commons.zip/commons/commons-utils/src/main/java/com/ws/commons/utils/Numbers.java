package com.ws.commons.utils;

import com.ws.commons.message.EDefaultMessage;
import org.jboss.weld.exceptions.IllegalArgumentException;

import java.util.Objects;
import java.util.stream.IntStream;

/**
 * Provides utilitarian methods for numbers verifications.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 - 2017-08-10
 */
public final class Numbers {

    private static final String INTEGERS_SMALLER_THAN_1_CAN_NOT_BE_SPLIT = "Integers smaller than 1 can not be split.";

    private Numbers() {}
    
    /**
     * Requires an {@link Integer} to be positive.
     *
     * @param number    to be validated
     * @param message   of exception
     */
    public static void requirePositive(final Integer number, final String message) {
        validatePositiveNumber(number, 0, message);
    }
    
    /**
     * Requires a {@link Long} to be positive.
     *
     * @param number    to be validated
     * @param message   of exception
     */
    public static void requirePositive(final Long number, final String message) {
        validatePositiveNumber(number, 0L, message);
    }
    
    /**
     * Requires a {@link Float} to be positive.
     *
     * @param number    to be validated
     * @param message   of exception
     */
    public static void requirePositive(final Float number, final String message) {
        validatePositiveNumber(number, 0.0f, message);
    }
    
    /**
     * Requires an {@link Integer} to be positive.
     *
     * @param number    to be validated
     * @param message   of exception
     */
    public static void requirePositive(final Short number, final String message) {
        validatePositiveNumber(number, Short.valueOf("0"), message);
    }
    
    /**
     * Requires a {@link Double} to be positive.
     *
     * @param number    to be validated
     * @param message   of exception
     */
    public static void requirePositive(final Double number, final String message) {
        validatePositiveNumber(number, new Double("0"), message);
    }

    private static <T extends Number & Comparable<T>> void validatePositiveNumber(final T number, final T zero, final String message) {
        if (isLessThan(number, zero)) {
            throw new ArrayIndexOutOfBoundsException(message);
        }
    }

    private static <T extends Number> boolean isLessThan(final Comparable<T> number, final T zero) {
        return number.compareTo(zero) < 0;
    }
    
    /**
     * Given a positive integer number n, it creates an array with all the numbers from 0 to n-1.
     * <p>Example:</p>
     * <ul>
     *   <li>0{@code ->} NPE</li>
     *   <li>1{@code ->} {0}</li>
     *   <li>2{@code ->} {0,1}</li>
     *   <li>3{@code ->} {0,1,2}</li>
     *   <li>4{@code ->} {0,1,2,3}</li>
     *   <li>successively...</li>
     * </ul>
     *
     * @param size  the size of the array
     * @return      an array containing the numbers from 0 to size-1
     * @since       5.1.0 - 2017-10-05
     */
    public static int[] range(final Integer size) {
        Objects.requireNonNull(size, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("size"));
        
        requirePositive(size, EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("size"));
        
        if (size == 0) {
            throw new IllegalArgumentException(INTEGERS_SMALLER_THAN_1_CAN_NOT_BE_SPLIT);
        } else {
            return IntStream.range(0, size).toArray();
        }
    }
}
