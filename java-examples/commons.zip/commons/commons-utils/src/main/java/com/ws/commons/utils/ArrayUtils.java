package com.ws.commons.utils;

import com.ws.commons.message.EDefaultMessage;

import java.util.Objects;

/**
 * Utility class to complement the {@link org.apache.commons.lang3.ArrayUtils} class.
 *
 * <p>Provides general util methods to perform array verifications</p>
 * <pre>
 *     ArrayUtils.validateNotContainNull("description", (Object[]) array);
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-13
 */
public final class ArrayUtils extends org.apache.commons.lang3.ArrayUtils{

    private ArrayUtils() {}
    
    /**
     * Validates if an array does not contain null values.
     *
     * @param <T>               extends Object generic type
     * @param arrayDescription  to compose the message when null value is found
     * @param values            to be verified
     */
    @SafeVarargs
    public static <T extends Object> void validateNotContainNull(final String arrayDescription, final T... values) {
        Objects.requireNonNull(arrayDescription, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("arrayDescription"));
        
        Objects.requireNonNull(values, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("values"));
        
        int index = 0;
        
        for (; index < values.length; index++) {
            if (values[index] == null) {
                throw new NullPointerException(EDefaultMessage.ARRAY_CONTAIN_NULL_VALUE_AT.getMessage(arrayDescription, index));
            }
        }
    }
    
    /**
     * Verifies if the {@code index} provided as parameter is the last index of an array.
     *
     * @param array where the last index will be verified
     * @param index to be compared
     * @return      {@code true} if is last index of array, false otherwise
     */
    public static boolean isLastIndex(final String[] array, final int index) {
        ArrayUtils.validateNotContainNull("Array", (Object[]) array);
        
        return array.length-1 == index;
    }
}
