package com.ws.commons.utils.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.ws.commons.utils.reflection.exception.ReflectionException;
import com.ws.commons.utils.reflection.exception.SyntheticFieldNotAllowed;

/**
 * Performs validations linked to field reflection rules.
 *
 * <p>Most commonly used to deny usage of synthetic fields when not allowed.</p>
 *
 * @author Diego A. Costa
 * @since 6.0.0 - 2018-04-16
 */
public class SyntheticValidator {

    private SyntheticValidator() {}
    
    /**
     * If the field is synthetic, it will throw a new @{@link ReflectionException} caused by {@link SyntheticFieldNotAllowed}.
     *
     * @param field to be verified.
     */
    public static void denySyntetic(final Field field) {
        ObjectHelper.requireNotNullParameter(field);
        
        if (field.isSynthetic()) {
            throw new ReflectionException(new SyntheticFieldNotAllowed(
                    String.format(ReflectionStringConstants.FIELD_NAME_MESSAGE.getValue(), field.getName())));
        }
    }
    
    /**
     * If the field is synthetic, it will throw a new @{@link ReflectionException} caused by {@link SyntheticFieldNotAllowed}.
     *
     * @param method to be verified.
     */
    public static void denySyntetic(final Method method) {
        ObjectHelper.requireNotNullParameter(method);
        
        if (method.isSynthetic()) {
            throw new ReflectionException(new SyntheticFieldNotAllowed(
                    String.format(ReflectionStringConstants.METHOD_NAME_MESSAGE.getValue(), method.getName())));
        }
    }
}
