package com.ws.commons.utils.reflection.artifact.classAssociation;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Root artifact class to help on {@link FieldReflectionHelper} test.
 *
 * @author Rogerio Kiihl
 * @since 6.0.0 - 2018-04-20
 */
public class RootArtifact extends BaseArtifact {

    private String name;
    private FirstNodeArtifact firstNode;

    public RootArtifact() {
        name = "root";
        firstNode = new FirstNodeArtifact();
    }

    public String getName() {
        return name;
    }

    public FirstNodeArtifact getFirstNode() {
        return firstNode;
    }
}
