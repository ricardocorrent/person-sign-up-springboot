package com.ws.commons.utils.reflection.artifact;

/**
 * Entity to be used on reflection tests.
 *
 * @author      Diego Armange Costa
 * @param <T>   extends GenericClassTestArtifact
 * @param <U>   undefined
 * @param <V>   extends ClassTestArtifact.InnerClassTestArtifact
 * @since       5.0.0 2017-08-09
 */
public abstract class AbstractSuperClassTestArtifact<T extends GenericClassTestArtifact, U, V extends ClassTestArtifact.InnerClassTestArtifact> {

    private Short anyShort;
    
    protected int anyInteger;

    /**
     * @return Any Short.
     */
    public Short getAnyShort() {
        return anyShort;
    }

    /**
     * @param anyShort to be tested.
     */
    public void setAnyShort(Short anyShort) {
        this.anyShort = anyShort;
    }
    
    /**
     * @return Any Integer.
     */
    public int getAnyInteger() {
        return anyInteger;
    }
    
    /**
     * @param anyInteger to be tested.
     */
    public void setAnyInteger(int anyInteger) {
        this.anyInteger = anyInteger;
    }
}
