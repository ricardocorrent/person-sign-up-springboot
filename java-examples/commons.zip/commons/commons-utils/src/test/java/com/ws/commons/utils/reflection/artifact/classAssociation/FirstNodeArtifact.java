package com.ws.commons.utils.reflection.artifact.classAssociation;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * First node artifact class to help on {@link FieldReflectionHelper} test.
 *
 * @author  Rogerio Kiihl
 * @since   6.0.0 - 2018-04-20
 */
public class FirstNodeArtifact extends BaseArtifact {

    private String name;

    private SecondNodeArtifact secondNode;
    private SecondNodeVariationArtifact secondNodeVariation;

    public FirstNodeArtifact() {
        name = "first";
        secondNode = new SecondNodeArtifact();
        secondNodeVariation = new SecondNodeVariationArtifact();
    }

    public SecondNodeArtifact getSecondNode() {
        return secondNode;
    }

    public SecondNodeVariationArtifact getSecondNodeVariation() {
        return secondNodeVariation;
    }

    public String getName() {
        return name;
    }
}
