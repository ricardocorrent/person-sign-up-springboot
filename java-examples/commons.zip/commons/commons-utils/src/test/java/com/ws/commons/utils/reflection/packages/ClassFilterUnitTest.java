package com.ws.commons.utils.reflection.packages;

import com.ws.commons.utils.reflection.artifact.ClassTestArtifact;
import com.ws.commons.utils.reflection.artifact.ClassToScanWithAnnotation;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.ws.rs.Path;
import java.util.Set;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;

/**
 * Unit test cases for {@link ClassFilter}.
 *
 * @author  Diego Armange Costa
 * @since   5.2.0 2017-10-23
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*"})
@PrepareForTest(ClassFilter.class)
public class ClassFilterUnitTest {

    /**
     * Filter class without recursion test case.
     * It must find one class.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void filterClassWithoutRecursion() {
        Set<Class<?>> classSet = new ClassFilter(ClassTestArtifact.class.getPackage(), Path.class).getClassSet();
        
        assertNotNull(classSet);
        
        assertThat(classSet, hasSize(1));
        
        assertThat(classSet, hasItems(ClassToScanWithAnnotation.class));
    }
    
    /**
     * Filter class with recursion test case.
     * It must find two classes.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void filterClassWithRecursion() {
        Set<Class<?>> classSet = new ClassFilter(ClassTestArtifact.class.getPackage(), Path.class)
                .recursively()
                .getClassSet();
        
        assertNotNull(classSet);
        
        assertThat(classSet, hasSize(2));
        
        assertThat(classSet, allOf(
            hasItems(com.ws.commons.utils.reflection.artifact.ClassToScanWithAnnotation.class),
            hasItems(com.ws.commons.utils.reflection.artifact.scannable.ClassToScanWithAnnotation.class)
        ));
    }
    
    /**
     * Must throw {@link ReflectionException} when is invalid URL.
     *
     * @throws Exception if mock fails.
     */
    @SuppressWarnings("unchecked")
    @Test(expected = ReflectionException.class)
    public void throwsExceptionWhenInvalidURL() throws Exception {
        Package packageForTest = ClassTestArtifact.class.getPackage();
        
        ClassFilter classFilterSpied = PowerMockito.spy(new ClassFilter(packageForTest, Path.class));

        when(classFilterSpied, method(ClassFilter.class, "handleURLsToFindClasses", Mockito.any()))
                .withArguments(PackageReflectionHelper.forPackage(packageForTest))
                .thenThrow(new RuntimeException());

        classFilterSpied.getClassSet();
    }
    
    /**
     * Must throw {@link ReflectionException} when is invalid class.
     *
     * @throws Exception if mock fails.
     */
    @SuppressWarnings("unchecked")
    @Test(expected = ReflectionException.class)
    public void throwsExceptionWhenInvalidClass() throws Exception {
        Package packageForTest = ClassTestArtifact.class.getPackage();
        
        ClassFilter classFilterSpied = PowerMockito.spy(new ClassFilter(packageForTest, Path.class));

        PowerMockito.doThrow(new RuntimeException()).when(classFilterSpied, "getQualifiedName", Mockito.any());

        classFilterSpied.getClassSet();
    }
}
