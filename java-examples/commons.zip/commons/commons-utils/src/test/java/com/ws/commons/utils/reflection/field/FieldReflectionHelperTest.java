package com.ws.commons.utils.reflection.field;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.artifact.ClassTestArtifact;
import com.ws.commons.utils.reflection.artifact.GenericClassTestArtifact;
import com.ws.commons.utils.reflection.artifact.classAssociation.*;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

/**
 * Class adapted from previous test class of old {@link FieldReflectionHelper} implementation.
 *
 * @author  Rogerio Kiihl
 * @since   6.0.0 - 2018-04-18
 */
public class FieldReflectionHelperTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     *
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    /**
     * Validates {@link FieldReflectionHelper}'s fromInstance equivalent constructor.
     *
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callFromInstanceConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        Constructor<FieldReflectionHelper> constructor = FieldReflectionHelper.class.getDeclaredConstructor(new Class[] { Object.class });
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance(new ClassTestArtifact());
    }

    /**
     * Validates {@link FieldReflectionHelper}'s fromClass equivalent constructor.
     *
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callFromClassConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        Constructor<FieldReflectionHelper> constructor = FieldReflectionHelper.class.getDeclaredConstructor(new Class[] { Class.class });
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance(ClassTestArtifact.class);
    }

    /**
     * Validates the {@link FieldReflectionHelper#fromClass(Class)} instance returns.
     */
    public void fromClass() {
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        Assert.assertNotNull(instanceHelper);
    }

    /**
     * Validates the {@link FieldReflectionHelper#fromInstance(Object)} instance returns.
     */
    public void fromInstance() {
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromInstance(new ClassTestArtifact());
        Assert.assertNotNull(instanceHelper);
    }

    /**
     * Validates the {@link FieldReflectionHelper#getFieldValue} method by retrieving field value through reflection.
     */
    @Test
    public void getFieldValue() {
        final ClassTestArtifact declaringInstance = new ClassTestArtifact();
        final String expected = "teste";
        declaringInstance.setAnyString(expected);

        final Object object = FieldReflectionHelper.fromInstance(declaringInstance).getFieldValue("anyString");

        assertNotNull(object);
        assertEquals(expected, object);
    }

    /**
     * Validates the {@link FieldReflectionHelper#getFieldValue} method with wrong instance.
     */
    @Test
    public void getFieldValueWithWrongDeclaringInstance() {
        thrown.expect(ReflectionException.class);

        final Field fieldFromOtherClass = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("anyLong");

        FieldReflectionHelper.fromInstance(new ClassTestArtifact()).getFieldValue(fieldFromOtherClass);
    }

    /**
     * Validates the {@link FieldReflectionHelper#getField} method by retrieving the field through reflection.
     */
    @Test
    public void getField() {
        final String fieldName = "anyInteger";
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField(fieldName);

        assertNotNull(field);
        assertEquals(fieldName, field.getName());
    }

    /**
     * Tests retrieval of nonexistent field.
     * It must throw a {@link ReflectionException} when getting a nonexistent field.
     */
    @Test
    public void throwsExceptionWhenGetNonexistentField() {
        thrown.expect(ReflectionException.class);
        final String fieldName = "anyString";

        FieldReflectionHelper.fromClass(GenericClassTestArtifact.class) .getField(fieldName);
    }

    /**
     * Tests retrieval of a field on {@link Object} class.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwsExceptionWhenGetFieldFromObjectClass() {
        thrown.expect(ReflectionException.class);
        final String fieldName = "anyString";

        FieldReflectionHelper.fromClass(Object.class).getField(fieldName);
    }

    /**
     * Tests instantiation of {@link FieldReflectionHelper} on a null class.
     * It must throw a {@link NullPointerException} when passing null type on {@link FieldReflectionHelper#fromClass}
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullTypeOnfromClass() {
        thrown.expect(NullPointerException.class);
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringClass"));

        FieldReflectionHelper.fromClass(null);
    }

    /**
     * Tests instantiation of {@link FieldReflectionHelper} on a null object instance.
     * It must throw a {@link NullPointerException} when passing null object on {@link FieldReflectionHelper#fromInstance(Object)}
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullTypeOnfromInstance() {
        thrown.expect(NullPointerException.class);
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringInstance"));

        FieldReflectionHelper.fromInstance(null);
    }

    /**
     * Tests retrieval of a null field through reflection.
     * It must throw a {@link NullPointerException} when pass null field name to {@link FieldReflectionHelper#getField(String)}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullFieldNameOngetField() {
        thrown.expect(NullPointerException.class);
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("field"));

        final Class<?> targetClass = ClassTestArtifact.class;
        FieldReflectionHelper.fromClass(targetClass).getField(null);
    }

    /**
     * Validates retrieval of specific fields in a class.
     */
    @Test
    public void getFieldsWithSpecificFields() {
        final String propertyName = "name";
        final String classFieldName = "anyString";
        final String superClassFieldName = "anyShort";

        final List<Field> fieldList = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getFields(classFieldName, superClassFieldName);

        assertNotNull(fieldList);
        assertFalse(fieldList.isEmpty());
        assertThat(fieldList.size(), greaterThanOrEqualTo(2));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(classFieldName))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(superClassFieldName))));
    }

    /**
     * Tests retrieval of nonexistent field.
     * It must throw a {@link ReflectionException} when getting a nonexistent field.
     */
    @Test
    public void throwsExceptionWhenGetNonexistentFields() {
        thrown.expect(ReflectionException.class);
        final String fieldName = "anyString";

        FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getFields(fieldName);
    }

    /**
     * Tests retrieval of a field on {@link Object} class.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwsExceptionWhenGetFieldsFromObject() {
        thrown.expect(ReflectionException.class);
        final String fieldName = "anyString";

        FieldReflectionHelper.fromClass(Object.class).getFields(fieldName);
    }

    /**
     * Tries to retrieve field using wrong field name.
     * It must throw a {@link NullPointerException} when passing wrong field name to {@link FieldReflectionHelper#getField(String)}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassWrongFieldNameOnGetFields() {
        thrown.expect(ReflectionException.class);

        FieldReflectionHelper.fromClass(ClassTestArtifact.class).getFields("null");
    }

    /**
     * Tries to retrieve all fields from a class.
     * It should get all fields.
     */
    @Test
    public void getFieldsWithAllFields() {
        final Class<?> targetClass = ClassTestArtifact.class;

        final String propertyName = "name";
        final String anyStringField = "anyString";
        final String anyLongField = "anyLong";
        final String anyMapField = "anyMap";
        final String anyShortField = "anyShort";
        final String anyIntegerField = "anyInteger";

        final List<Field> fieldList = FieldReflectionHelper.fromClass(targetClass).getFields();

        assertNotNull(fieldList);
        assertFalse(fieldList.isEmpty());
        assertThat(fieldList.size(), greaterThanOrEqualTo(5));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyStringField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyLongField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyMapField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyShortField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyIntegerField))));
    }

    /**
     * Tries to retrieve all fields from a class using an empty array as {@link FieldReflectionHelper#getFields(String...)}
     * as parameter.
     * It should get all fields even with an empty array of fields name.
     */
    @Test
    public void getFieldsWithAllFieldsOnEmptyArrayFieldsNameParameter() {
        final Class<?> targetClass = ClassTestArtifact.class;

        final String propertyName = "name";
        final String anyStringField = "anyString";
        final String anyLongField = "anyLong";
        final String anyMapField = "anyMap";
        final String anyShortField = "anyShort";
        final String anyIntegerField = "anyInteger";

        final List<Field> fieldList = FieldReflectionHelper.fromClass(targetClass).getFields(new String[] {});

        assertNotNull(fieldList);
        assertFalse(fieldList.isEmpty());
        assertThat(fieldList.size(), greaterThanOrEqualTo(5));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyStringField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyLongField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyMapField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyShortField))));
        assertThat(fieldList, hasItem(Matchers.<Field>hasProperty(propertyName, equalTo(anyIntegerField))));
    }

    /**
     * Tests setting value to a primitive field.
     * It should set it successfully.
     */
    @Test
    public void setValueIntoPrimitiveField() {
        final ClassTestArtifact declaringInstance = new ClassTestArtifact();
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromInstance(declaringInstance);

        final Field anyLongPrimitiveField = instanceHelper.getField("anyLong");
        final Object value = 1L;

        instanceHelper.setFieldValue(anyLongPrimitiveField, value);

        assertEquals(value, declaringInstance.getAnyLong());
    }

    /**
     * Tries to set value into field with wrong declaring instance.
     * It should throw a {@link ReflectionException}.
     */
    @SuppressWarnings("rawtypes")
    @Test
    public void throwsReflectionExceptionWhenSetValueIntoFieldWithWrongDecInstance() {
        thrown.expect(ReflectionException.class);

        final Field anyLongPrimitiveField = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyLong");

        FieldReflectionHelper.fromInstance(new GenericClassTestArtifact()).setFieldValue(anyLongPrimitiveField, 1L);
    }

    /**
     * Tries to set {@code null} in a field through reflection.
     * It should throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullFieldOnGetAllFields() {
        thrown.expect(NullPointerException.class);

        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("field"));

        FieldReflectionHelper.fromInstance(new ClassTestArtifact()).setFieldValue(null, 1L);
    }

    /**
     * Validates consistency of {@link FieldReflectionHelper#getFieldValueByGetter(Field, Object...)}.
     */
    @Test
    public void getValueByGetter() {
        final ClassTestArtifact bean = new ClassTestArtifact();

        bean.setAnyString("description");

        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyString");
        final Object value = FieldReflectionHelper.fromInstance(bean).getFieldValueByGetter(field, new Object[] {});

        assertEquals("description", value);
    }

    /**
     * Validates consistency of {@link FieldReflectionHelper#getFieldValueByGetter(Field, Object...)} on restricted getter.
     */
    @Test
    public void getValueByRestrictedGetter() {
        thrown.expect(ReflectionException.class);
        thrown.expectCause(instanceOf(IllegalAccessException.class));

        final Object bean = new ClassTestArtifact().getRestrictedClass();
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromInstance(bean);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.getFieldValueByGetter(field, new Object[] {});
    }

    /**
     * Validates getting primitive boolean value by getter.
     * It should retrieve the value successfully.
     */
    @Test
    public void getPrimitiveBooleanValueByGetter() {
        final ClassTestArtifact bean = new ClassTestArtifact();
        bean.setAnyBoolean(true);

        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyBoolean");
        final Object fieldValueByGetter = FieldReflectionHelper.fromInstance(bean).getFieldValueByGetter(field, new Object[] {});

        assertEquals(true, fieldValueByGetter);
    }

    /**
     * Validates the scenario when the getter does not exist.
     * It should return {@link FieldReflectionHelper.MethodReturnStatus#METHOD_NOT_FOUND}.
     */
    @Test
    public void getMethodNotFoundWhenSearchingGetter() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anotherBoolean");
        final Object result = FieldReflectionHelper.fromInstance(new ClassTestArtifact()).getFieldValueByGetter(field, new Object[] {});

        assertEquals(FieldReflectionHelper.MethodReturnStatus.METHOD_NOT_FOUND, result);
    }

    /**
     * Tries to get field value with wrong type from getter.
     * It validates when exceptions are thrown on getter invocation. Expects to throw a {@link ReflectionException}.
     */
    @Test
    public void throwExceptionWhenTryGetWithWrongValueTypeByGetter() {
        thrown.expect(ReflectionException.class);
        thrown.expectCause(instanceOf(IllegalArgumentException.class));

        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyBoolean");
        FieldReflectionHelper.fromInstance(new ClassTestArtifact()).getFieldValueByGetter(field, new Object[] {1});
    }

    /**
     * Validates consistency of {@link FieldReflectionHelper#setFieldValueBySetter(Field, Object...)}.
     * It should set field value successfully.
     */
    @Test
    public void setValueBySetter() {
        final ClassTestArtifact bean = new ClassTestArtifact();
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyString");

        assertTrue(FieldReflectionHelper.fromInstance(bean).setFieldValueBySetter(field, "description"));
        assertEquals("description", bean.getAnyString());
    }

    /**
     * Validates consistency of {@link FieldReflectionHelper#setFieldValueBySetter(Field, Object...)} on restricted setter.
     * It should set field value successfully.
     */
    @Test
    public void setValueByRestrictedSetter() {
        thrown.expect(ReflectionException.class);
        thrown.expectCause(instanceOf(IllegalAccessException.class));

        final Object bean = new ClassTestArtifact().getRestrictedClass();
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromInstance(bean);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.setFieldValueBySetter(field,"description");
    }

    /**
     * Tries to set field value with wrong type from setter.
     * It validates when exceptions are thrown on setter invocation. Expects to throw a {@link ReflectionException}.
     */
    @Test
    public void throwExceptionWhenSetWrongValueTypeBySetter() {
        thrown.expect(ReflectionException.class);
        thrown.expectCause(instanceOf(IllegalArgumentException.class));

        final ClassTestArtifact bean = new ClassTestArtifact();
        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromInstance(bean);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.setFieldValueBySetter(field, 1);
    }

    /**
     * Searches for a nonexistent setter.
     * It should return {@code false} when calling {@link FieldReflectionHelper#setFieldValueBySetter(Field, Object...)}.
     */
    @Test
    public void searchNonexistentSetter() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anotherBoolean");

        assertFalse(FieldReflectionHelper.fromInstance(new ClassTestArtifact()).setFieldValueBySetter(field, "description"));
    }

    /**
     * Tries to get a field from a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOngetFieldValueWithNoInstance() {
        thrown.expect(NullPointerException.class);

        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.getFieldValue(field);
    }

    /**
     * Tries to get a string field value from a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOngetFieldValueStringWithNoInstance() {
        thrown.expect(NullPointerException.class);
        FieldReflectionHelper.fromClass(ClassTestArtifact.class).getFieldValue("anyString");
    }

    /**
     * Tries to set a field from a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOnsetFieldValueWithNoInstance() {
        thrown.expect(NullPointerException.class);

        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.setFieldValue(field, "description");
    }

    /**
     * Tries to set a field value from a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOnsetFieldValueBySetterWithNoInstance() {
        thrown.expect(NullPointerException.class);

        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.setFieldValueBySetter(field, "description");
    }

    /**
     * Tries to get a field value from getter in a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOngetFieldValueByGetterWithNoInstance() {
        thrown.expect(NullPointerException.class);

        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.getFieldValueByGetter(field);
    }

    /**
     * Tries to get a field value from getter ignoring convention in a class with no instance.
     * It must throw a {@link NullPointerException} since {@link FieldReflectionHelper} instance was created with
     * {@link FieldReflectionHelper#fromClass(Class)} and has no instance.
     */
    @Test
    public void throwNullPointerOngetFieldValueByGetterInoringConventionWithNoInstance() {
        thrown.expect(NullPointerException.class);

        final FieldReflectionHelper instanceHelper = FieldReflectionHelper.fromClass(ClassTestArtifact.class);
        final Field field = instanceHelper.getField("anyString");

        instanceHelper.getFieldValueByGetterIgnoringConvention(field);
    }

    /**
     * Method used for the further getLastUninheritedFieldFromPath tests.
     */
    private void fieldValueOnPathTest(final Object target, final String path) {
        final FieldReflectionHelper helpInstance = FieldReflectionHelper.fromInstance(target);

        final Field fieldFromPath = FieldReflectionHelper.fromClass(RootArtifact.class).getLastUninheritedFieldFromPath(path, BaseArtifact.class);
        final Field fieldFromTarget = helpInstance.getField("name");

        Assert.assertEquals(fieldFromTarget, fieldFromPath);
        Assert.assertEquals(helpInstance.getFieldValue(fieldFromTarget), helpInstance.getFieldValue(fieldFromPath));
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is not
     * valid.
     * It should throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenRootPathIsNotValid()
    {
        thrown.expect(ReflectionException.class);

        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root, "invalidField");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when first node path is
     * not valid.
     * It should throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenFirstNodePathIsNotValid() {
        thrown.expect(ReflectionException.class);

        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root, "firstNode.invalidField");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when second node path is
     * not valid.
     * It should throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenSecondNodePathIsNotValid() {
        thrown.expect(ReflectionException.class);

        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root, "firstNode.secondNode.invalidField");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is valid.
     * It must return the field 'name' from the class {@link RootArtifact} because it is a {@link BaseArtifact} used to
     * filter.
     */
    @Test
    public void getValueFromRootInstanceInAPath() {
        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root, "name");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is valid
     * and tries to retrieve first node.
     * It must return the field 'root.firstNode.name' from the class {@link FirstNodeArtifact} because it is a
     * {@link BaseArtifact} used to filter
     */
    @Test
    public void getValueFromFirstInstanceInAPath() {
        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root.getFirstNode(), "firstNode.name");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is valid
     * and tries to retrieve second node.
     * It must return the field 'root.firstNode.secondNode.name' from the class {@link SecondNodeArtifact} because it is a
     * {@link BaseArtifact} used to filter.
     */
    @Test
    public void getValueFromSecondInstanceInAPath() {
        final RootArtifact root = new RootArtifact();
        fieldValueOnPathTest(root.getFirstNode().getSecondNode(), "firstNode.secondNode.name");
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is valid
     * and tries to retrieve first node second variation.
     * It must return the field 'root.firstNode.secondNodeVariation' from the class {@link FirstNodeArtifact} because
     * {@link SecondNodeVariationArtifact} is NOT a {@link BaseArtifact} used to filter.
     */
    @Test
    public void getValueFromSecondVariationInstanceInAPath() {
        final Field fieldFromPath = FieldReflectionHelper.fromClass(RootArtifact.class).getLastUninheritedFieldFromPath("firstNode.secondNodeVariation.name", BaseArtifact.class);
        final Field fieldExpected = FieldReflectionHelper.fromClass(FirstNodeArtifact.class).getField("secondNodeVariation");
        final Field fieldFromTarget = FieldReflectionHelper.fromClass(SecondNodeVariationArtifact.class).getField("name");

        Assert.assertNotEquals(fieldFromTarget, fieldFromPath);
        Assert.assertEquals(fieldExpected, fieldFromPath);
    }

    /**
     * Validates {@link FieldReflectionHelper#getLastUninheritedFieldFromPath(String, Class[])} when root path is valid
     * and tries to retrieve first node second variation from an invalid instance in a path.
     * It must return the field 'root.firstNode.secondNodeVariation' from the class {@link FirstNodeArtifact} because
     * {@link SecondNodeVariationArtifact} is NOT a {@link BaseArtifact} used to filter.
     */
    @Test
    public void getValueFromInvalidInstanceInAPath() {
        final RootArtifact root = new RootArtifact();
        final Field field = FieldReflectionHelper.fromInstance(root).getLastUninheritedFieldFromPath("firstNode.secondNodeVariation.name", BaseArtifact.class);
        final Object value = FieldReflectionHelper.fromInstance(root.getFirstNode()).getFieldValue(field);

        Assert.assertEquals(root.getFirstNode().getSecondNodeVariation(), value);
    }

    /**
     * Checks field values from getter using the {@link FieldReflectionHelper#getFieldValueByGetterIgnoringConvention}.
     * It should retrieve the value successfully.
     */
    @Test
    public void getFieldValueByGetterIgnoringConvention() {
        final ClassTestArtifact instance = spy(new ClassTestArtifact());
        final FieldReflectionHelper helper = FieldReflectionHelper.fromInstance(instance);
        final Field field = helper.getField("primitiveBooleanWithoutConvention");

        instance.setPrimitiveBooleanWithoutConvetion(true);
        assertTrue((boolean)helper.getFieldValue(field));
        assertTrue((boolean)helper.getFieldValueByGetterIgnoringConvention(field));

        verify(instance).getPrimitiveBooleanWithoutConvention();
    }
}
