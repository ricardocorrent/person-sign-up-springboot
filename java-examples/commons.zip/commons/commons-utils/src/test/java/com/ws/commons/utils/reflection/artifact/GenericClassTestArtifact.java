package com.ws.commons.utils.reflection.artifact;

import java.util.List;
import java.util.Map;

/**
 * Generic class artifact to be used on reflection tests.
 *
 * @author      Diego Armange Costa
 * @param <T>   extends ClassTestArtifact
 * @since       5.0.0 2017-08-09
 */
public class GenericClassTestArtifact<T extends ClassTestArtifact & IIntnterfaceTestArtifact> {

    private long anyLong;
    
    protected Map<? extends Object, ? super Object[]> map;
    
    protected List<String>[] listArray; //  :-)
    
    protected List<String[]> arrayList; //  :-D
    
    protected List<List<String[]>> listArrayList; //  :-D
    
    protected List<String>[][] matrix; //  :-P 

    /**
     * @return Any Long.
     */
    public long getAnyLong() {
        return anyLong;
    }

    /**
     * @param anyLong to be tested.
     */
    public void setAnyLong(long anyLong) {
        this.anyLong = anyLong;
    }
}
