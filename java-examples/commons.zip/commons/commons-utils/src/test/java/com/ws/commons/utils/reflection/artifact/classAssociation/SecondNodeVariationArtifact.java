package com.ws.commons.utils.reflection.artifact.classAssociation;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Second node artifact non-inherited class to help on {@link FieldReflectionHelper} test.
 *
 * @author  Rogerio Kiihl
 * @since   6.0.0 - 2018-04-20
 */
public class SecondNodeVariationArtifact {

    private String name;

    public SecondNodeVariationArtifact() {
        name = "secondVariation";
    }

    public String getName() {
        return name;
    }
}
