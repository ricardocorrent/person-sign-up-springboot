package com.ws.commons.utils.reflection.artifact;

import com.ws.commons.utils.reflection.ClassReflectionHelper;

import java.util.Map;

/**
 * Class test artifact with inner class to execute reflection tests.
 *
 * @author  Diego Armange Costa
 * @version 5.3.1 - 2017-12-04 - Added restrict class instance getter.
 * @since   5.0.0 - 2017-08-09
 */
@SuppressWarnings({ "rawtypes", "javadoc" })
public class ClassTestArtifact extends AbstractSuperClassTestArtifact<GenericClassTestArtifact, ClassTestArtifact, ClassTestArtifact.InnerClassTestArtifact> 
    implements IGenericInterfaceTestArtifact<ClassTestArtifact, ClassTestArtifact.InnerClassTestArtifact>, IInterfaceTypeVariableTestArtifact {
    
    private String anyString;
    
    private long anyLong;
    
    private Map<String, Integer> anyMap;
    
    private boolean anyBoolean;
    
    private Boolean anyWrapperBoolean;

    /**
     * The encapsulated methods are created with "SET" and "GET"(instead "IS") prefixes.
     */
    private boolean primitiveBooleanWithoutConvention;
    
    @SuppressWarnings("unused")
    private boolean anotherBoolean;
    
    /**
     * Inner class artifact used to execute tests on {@link ClassReflectionHelper}.
     * 
     * @author  Diego Armange Costa
     * @since   3.0.0 2017-08-09
     */
    public class InnerClassTestArtifact {}

    /**
     * @return any String.
     */
    public String getAnyString() {
        return anyString;
    }

    /**
     * @param anyString to be tested.
     */
    public void setAnyString(String anyString) {
        this.anyString = anyString;
    }

    /**
     * @return any Long.
     */
    public long getAnyLong() {
        return anyLong;
    }

    /**
     * @param anyLong to be tested.
     */
    public void setAnyLong(long anyLong) {
        this.anyLong = anyLong;
    }

    /**
     * @return any Map.
     */
    public Map<String, Integer> getAnyMap() {
        return anyMap;
    }

    /**
     * @param anyMap to be tested.
     */
    public void setAnyMap(Map<String, Integer> anyMap) {
        this.anyMap = anyMap;
    }

    public boolean isAnyBoolean() {
        return anyBoolean;
    }

    public void setAnyBoolean(boolean anyBoolean) {
        this.anyBoolean = anyBoolean;
    }
    
    public Boolean getAnyWrapperBoolean() {
        return anyWrapperBoolean;
    }

    public void setAnyWrapperBoolean(Boolean anyWrapperBoolean) {
        this.anyWrapperBoolean = anyWrapperBoolean;
    }

    /**
     * The encapsulated method must be created with "SET" and "GET"(instead "IS") prefixes.
     *
     * @return the primitiveBooleanWithoutConvention
     */
    public boolean getPrimitiveBooleanWithoutConvention() {
        return primitiveBooleanWithoutConvention;
    }

    /**
     * @param primitiveBooleanWithoutConvention the primitiveBooleanWithoutConvention to set
     */
    public void setPrimitiveBooleanWithoutConvetion(boolean primitiveBooleanWithoutConvention) {
        this.primitiveBooleanWithoutConvention = primitiveBooleanWithoutConvention;
    }
    
    /**
     * @author  Diego Armange Costa
     * @return  a restrict class instance
     * @since   5.3.1 - 2017-12-04
     */
    public RestrictedClassTestArtifact getRestrictedClass() {
        return new RestrictedClassTestArtifact();
    }
}