package com.ws.commons.utils.reflection;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.artifact.ClassTestArtifact;
import com.ws.commons.utils.reflection.artifact.IGenericInterfaceTestArtifact;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.hamcrest.Matchers.instanceOf;
import static org.junit.Assert.*;

/**
 * Test cases for {@link ClassReflectionHelper}.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-09
 */
public class ClassReflectionHelperTest extends BaseUnitTest{

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validates {@link ClassReflectionHelper}'s default constructor.
     * 
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callDefaultConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        Constructor<ClassReflectionHelper> constructor = ClassReflectionHelper.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    /**
     * Test case that throws {@link ReflectionException} when trying to generate an instance from a class without
     * default constructor.
     */
    @Test
    public void ReflectionExceptionWhenHasNoDefaultConstructor() {
        thrown.expect(ReflectionException.class);
        
        ClassReflectionHelper.newInstanceFromClass(IGenericInterfaceTestArtifact.class);
    }
    
    /**
     * Tests the generation of a new class instance.
     */
    @Test
    public void generateNewInstanceFromClass() {
        Object newInstance = ClassReflectionHelper.newInstanceFromClass(ClassTestArtifact.class);
        
        assertNotNull(newInstance);
        
        assertTrue(newInstance instanceof ClassTestArtifact);
    }
    
    /**
     * Tests the generation of a new inner class instance.
     */
    @Test
    public void generateNewInstanceFromInnerClass() {
        Object newInstance = ClassReflectionHelper.newInstanceFromClass(ClassTestArtifact.InnerClassTestArtifact.class);
        
        assertNotNull(newInstance);
        
        assertTrue(newInstance instanceof ClassTestArtifact.InnerClassTestArtifact);
    }
    
    /**
     * Tests the instantiation of a {@code null} class.
     * It must throw a {@link NullPointerException} when passing {@code null} class to generate instance.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullParameterOnNewInstanceFromClass() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("targetClass"));
        
        ClassReflectionHelper.newInstanceFromClass(null);
    }
    
    /**
     * <pre>
     * Validates when two classes are equal recursively.
     * <code>
     *  Class01 extends Classe02.
     *  
     *  Class03 extends Classe02.
     *  
     *  Class01 is equals to Class03 because both extends Class02.
     * </code>
     * </pre>
     */
    @Test
    public void isClassRecursivelyEqualsTo() {
        assertTrue(ClassReflectionHelper.isClassRecursivelyEqualsTo(NullPointerException.class, RuntimeException.class));
        
        assertFalse(ClassReflectionHelper.isClassRecursivelyEqualsTo(NullPointerException.class, IOException.class));
    }
    
    /**
     * Tests loading class by qualified name.
     * It must load the class successfully.
     */
    @Test
    public void loadClassByName() {
        assertNotNull(ClassReflectionHelper.forName(ClassTestArtifact.class.getName()));
    }
    
    /**
     * Tests loading a class with an invalid name.
     * It must throw a {@link ReflectionException} caused by {@link ClassNotFoundException}.
     */
    @Test
    public void throwExceptionWhenLoadClassByInvalidName() {
        thrown.expect(ReflectionException.class);
        
        thrown.expectCause(instanceOf(ClassNotFoundException.class));
        
        assertNotNull(ClassReflectionHelper.forName("InvalidName"));
    }
}
