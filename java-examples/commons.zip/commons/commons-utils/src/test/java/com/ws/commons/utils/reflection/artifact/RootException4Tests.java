package com.ws.commons.utils.reflection.artifact;

/**
 * Root exception class to be used only for testing purposes.
 *
 * @author  Diego Armange Costa
 * @since   6.0.0 - 2018-02-15
 */
@SuppressWarnings("serial")
public class RootException4Tests extends RuntimeException {}
