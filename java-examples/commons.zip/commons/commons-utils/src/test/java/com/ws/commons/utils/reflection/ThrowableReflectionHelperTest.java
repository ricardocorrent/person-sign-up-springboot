package com.ws.commons.utils.reflection;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.artifact.Exception4Tests;
import com.ws.commons.utils.reflection.artifact.RootException4Tests;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.jboss.weld.exceptions.IllegalArgumentException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test cases for {@link ThrowableReflectionHelper}.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-14
 */
public class ThrowableReflectionHelperTest extends BaseUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validates {@link FieldReflectionHelper}'s default constructor.
     *  
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callDefaultConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        Constructor<ThrowableReflectionHelper> constructor = ThrowableReflectionHelper.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    /**
     * Validates if the exception is equals to expected cause without recursive cause.
     */
    @Test
    public void throwableCausedWithoutRecursiveCause() {
        assertTrue(ThrowableReflectionHelper.isThrowableCausedBy(new Exception4Tests(), RootException4Tests.class));
    }
    
    /**
     * Validate if the exception is not equals to expected cause without recursive cause.
     */
    @Test
    public void differentThrowableCausedWithoutRecursiveCause() {
        assertFalse(ThrowableReflectionHelper.isThrowableCausedBy(new IOException(), RootException4Tests.class));
    }
    
    /**
     * Validates if the exception cause is equals to expected cause with recursive cause.
     */
    @Test
    public void throwableCausedWithRecursiveCause() {
        assertTrue(ThrowableReflectionHelper.isThrowableCausedBy(
                new RuntimeException(
                        new Exception4Tests()), RootException4Tests.class));
    }
    
    /**
     * Validates if the exception cause is equals to expected cause (with three recursively levels).
     */
    @Test
    public void throwableCausedWithThreeRecursiveCause() {
        assertTrue(ThrowableReflectionHelper.isThrowableCausedBy(
                new RuntimeException(
                        new IllegalArgumentException(
                                new Exception4Tests())), RootException4Tests.class));
    }
    
    /**
     * Tests {@link ThrowableReflectionHelper#isThrowableCausedBy(Throwable, Class)} providing a {@code null} throwable
     * as parameter.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullThrowableOnIsThrowableCausedBy() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("throwable"));
        
        ThrowableReflectionHelper.isThrowableCausedBy(null, RootException4Tests.class);
    }

    /**
     * Tests {@link ThrowableReflectionHelper#isThrowableCausedBy(Throwable, Class)} providing a {@code null} cause
     * as parameter.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullCauseClassOnIsThrowableCausedBy() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("causeClass"));
        
        ThrowableReflectionHelper.isThrowableCausedBy(new Exception4Tests(), null);
    }
}
