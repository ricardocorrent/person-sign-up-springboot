package com.ws.commons.utils;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.testng.Assert;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertTrue;

/**
 * Test cases for {@link ArrayUtils} class.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-16
 */
public class ArrayUtilsTest extends BaseUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validate {@link FieldReflectionHelper}'s default constructor.
     *  
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callDefaultConstructor() throws InstantiationException,
            IllegalAccessException,
            IllegalArgumentException,
            InvocationTargetException,
            NoSuchMethodException,
            SecurityException {
        Constructor<ArrayUtils> constructor = ArrayUtils.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    /**
     * Validates that parameters are not {@code null} through {@link ArrayUtils#validateNotContainNull(String, Object[])}.
     */
    @Test
    public void validateNotContainNull() {
        ArrayUtils.validateNotContainNull("", "", "", "");
    }
    
    /**
     * Tests {@link ArrayUtils#validateNotContainNull(String, Object[])} when providing any {@code null} parameter.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenValidateNotContainNullPassingAnyNullItem() {
        thrown.expect(NullPointerException.class);
        
        ArrayUtils.validateNotContainNull("", "", "", null);
    }

    /**
     * Tests {@link ArrayUtils#validateNotContainNull(String, Object[])} when providing {@code null} array description
     * parameter.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenValidateNotContainNullPassingAnyNullItem2() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("arrayDescription"));
        
        ArrayUtils.validateNotContainNull(null, "", "", null);
    }

    /**
     * Tests {@link ArrayUtils#validateNotContainNull(String, Object[])} when providing {@code null} values parameter.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenValidateNotContainNullPassingAnyNullItem22() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("values"));
        
        final Object[] vararg = null;
        
        ArrayUtils.validateNotContainNull("", vararg);
    }
    
    /**
     * Verifies if the given parameter is the last index of a {@code null} array.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void sendNullToLastIndexMethod() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("values"));
        
        final String[] values = null;
        
        ArrayUtils.isLastIndex(values, 0);
    }

    /**
     * Verifies if the given parameter is the last index of an empty array.
     * Expects to assert {@code false} on method return.
     */
    @Test
    public void sendEmptyToLastIndexMethod() {
        final String[] values = {};
        
        Assert.assertFalse(ArrayUtils.isLastIndex(values, 0));
    }

    /**
     * Verifies if the given parameter is the last index of a valid array.
     * Expects to assert {@code true}.
     */
    @Test
    public void isLastIndex() {
        final String[] values = {"zero","um","dois"};
        
        Assert.assertTrue(ArrayUtils.isLastIndex(values, 2));
    }

    /**
     * Verifies if the given parameter is the last index of a valid array.
     * Expects to assert {@code false} as the parameter is greater than the last index.
     */
    @Test
    public void shouldReturnFalseWhenIndexIsHigherThanTheLastIndex() {
        final String[] values = {"zero","um","dois"};
        
        Assert.assertFalse(ArrayUtils.isLastIndex(values, 3));
    }

    /**
     * Verifies if the given parameter is the last index of a valid array.
     * Expects to assert {@code false} as the parameter is smaller than the last index.
     */
    @Test
    public void isNotLastIndexWhenSmaller() {
        final String[] values = {"zero","um","dois"};
        
        Assert.assertFalse(ArrayUtils.isLastIndex(values, 1));
    }

    /**
     * Verifies if the given parameter is the last index of a valid array.
     * Expects to assert {@code false} as the parameter is a negative number.
     */
    @Test
    public void sendInvalidIndexAndAssertIsNotLastIndex() {
        final String[] values = {"zero","um","dois"};
        
        Assert.assertFalse(ArrayUtils.isLastIndex(values, -1));
    }
}
