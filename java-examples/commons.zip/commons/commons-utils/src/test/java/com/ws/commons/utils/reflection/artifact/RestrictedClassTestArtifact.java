package com.ws.commons.utils.reflection.artifact;

/**
 * This class is meant to be used on reflection tests.
 * 
 * @author  Diego Armange Costa
 * @since   5.3.1 2017-11-30
 */
class RestrictedClassTestArtifact {
    
    private String anyString;
    
    /**
     * @return Any String.
     */
    @SuppressWarnings("unused")
    private final String getAnyString() {
        return anyString;
    }

    /**
     * @param anyString to be tested.
     */
    @SuppressWarnings("unused")
    private final void setAnyString(String anyString) {
        this.anyString = anyString;
    }
}
