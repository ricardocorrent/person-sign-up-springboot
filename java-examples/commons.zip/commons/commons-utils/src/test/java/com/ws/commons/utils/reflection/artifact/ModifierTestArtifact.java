package com.ws.commons.utils.reflection.artifact;

/**
 * This artifact is meant to cover reflection testing on different modifiers.
 *
 * @author  Diego Armange Costa
 * @since   5.3.1 - 2017-12-01
 */
public class ModifierTestArtifact {

    boolean defaultModifier;
    
    @SuppressWarnings("javadoc")
    public boolean publicModifier;
    
    @SuppressWarnings("unused")
    private boolean privateModifier;
    
    protected boolean protectedModifier;
    
    final boolean finalModifier = true;
    
    @SuppressWarnings("unused")
    private final boolean privateFinalModifier = true;
    
    boolean defaultModifier() {return true;}
    
    @SuppressWarnings("javadoc")
    public boolean publicModifier() {return true;}
    
    @SuppressWarnings("unused")
    private boolean privateModifier() {return true;}
    
    protected boolean protectedModifier() {return true;}
    
    final boolean finalModifier() {return true;}
    
    @SuppressWarnings("unused")
    private final boolean privateFinalModifier() {return true;}
}
