package com.ws.commons.utils.reflection;

import com.ws.commons.utils.reflection.artifact.ModifierTestArtifact;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.junit.Test;
import org.testng.Assert;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Unit test cases for {@link ModifierReflectionHelper}.
 *
 * @since   5.3.0 - 2017-12-01
 * @author  Diego Armange Costa
 */
public class ModifierReflectionHelperUnitTest {

    /**
     * Removes all modifiers from a field.
     * Expects the field not to have modifier.
     */
    @Test
    public void changeDefaultTryingtoRemoveTheModifier() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("defaultModifier");
        
        ModifierReflectionHelper.from(field).remove(0);
        
        Assert.assertFalse(Modifier.isPublic(field.getModifiers()));
        
        Assert.assertFalse(Modifier.isPrivate(field.getModifiers()));
        
        Assert.assertFalse(Modifier.isProtected(field.getModifiers()));
    }

    /**
     * Undoes the removal of a field's modifier.
     * Expects the test to succeed.
     */
    @Test
    public void UndoesChangeDefaultTryingtoRemoveTheModifier() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("defaultModifier");
        
        ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.remove(0);
        
        helper.undo();
        
        Assert.assertFalse(Modifier.isPublic(field.getModifiers()));
        
        Assert.assertFalse(Modifier.isPrivate(field.getModifiers()));
        
        Assert.assertFalse(Modifier.isProtected(field.getModifiers()));
    }

    /**
     * Changes a field's modifier from private do public.
     * Expects the field not to be private after the conversion.
     */
    @Test
    public void changePrivateToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateModifier");
        
        ModifierReflectionHelper.from(field).changeToPublic();
        
        Assert.assertFalse(Modifier.isPrivate(field.getModifiers()));
    }

    /**
     * Undoes changing field's modifier from private to public.
     * Expects the field to be private after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangePrivateToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isPrivate(field.getModifiers()));
    }

    /**
     * Changes a field's modifier from default to public.
     * Expects the field to be public after the conversion.
     */
    @Test
    public void changeDefaultToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("defaultModifier");
        
        ModifierReflectionHelper.from(field).changeToPublic();
        
        Assert.assertTrue(Modifier.isPublic(field.getModifiers()));
    }
    /**
     *
     * Undoes changing field's modifier from default to public.
     * Expects the field to be default after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeDefaultToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("defaultModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
        
        Assert.assertFalse(Modifier.isPrivate(modifiers));
        
        Assert.assertFalse(Modifier.isProtected(modifiers));
    }

    /**
     * Changes a field's modifier from protected to public.
     * Expects the field to be public after the conversion.
     */
    @Test
    public void changeProtectedToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("protectedModifier");
        
        ModifierReflectionHelper.from(field).changeToPublic();
        
        Assert.assertTrue(Modifier.isPublic(field.getModifiers()));
    }

    /**
     * Undoes changing field's modifier from protected to public.
     * Expects the field to be protected after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeProtectedToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("protectedModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertTrue(Modifier.isProtected(modifiers));
    }

    /**
     * Changes a field's modifier from public to private.
     * Expects the field to be private after the conversion.
     */
    @Test
    public void changePublicToPrivate() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("publicModifier");
        
        ModifierReflectionHelper.from(field).changeTo(Modifier.PRIVATE);
        
        Assert.assertTrue(Modifier.isPrivate(field.getModifiers()));
    }

    /**
     * Undoes changing field's modifier from public to private.
     * Expects the field to be public after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoeschangePublicToPrivate() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("publicModifier");

        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeTo(Modifier.PRIVATE);
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isPublic(field.getModifiers()));
    }

    /**
     * Changes a field's modifier from protected to default.
     * Expects the field to be default after the conversion.
     */
    @Test
    public void changeProtectedToDefault() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("protectedModifier");
        
        ModifierReflectionHelper.from(field).remove(Modifier.PROTECTED);
        
        final int modifiers = field.getModifiers();
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
        
        Assert.assertFalse(Modifier.isPrivate(modifiers));
        
        Assert.assertFalse(Modifier.isProtected(modifiers));
    }

    /**
     * Undoes changing field's modifier from protected to default.
     * Expects the field to be protected after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeProtectedToDefault() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("protectedModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.remove(Modifier.PROTECTED);
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isProtected(field.getModifiers()));
    }

    /**
     * Removes a field's final modifier.
     * Expects the field not to be final after the conversion.
     */
    @Test
    public void removeFinal() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("finalModifier");
        
        ModifierReflectionHelper.from(field).removeFinal();
        
        Assert.assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    /**
     * Undoes removing field's final modifier.
     * Expects the field to be final after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesRemoveFinal() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("finalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.removeFinal();
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isFinal(field.getModifiers()));
    }

    /**
     * Removes a private field's final modifier.
     * Expects the field to be private but not final after the conversion.
     */
    @Test
    public void removeFinalAndKeepPrivate() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateFinalModifier");
        
        ModifierReflectionHelper.from(field).removeFinal();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertFalse(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPrivate(modifiers));
    }

    /**
     * Undoes removing private field's final modifier.
     * Expects the field to be final and private after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesRemoveFinalAndKeepPrivate() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateFinalModifier");
        
        ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.removeFinal();
        
        helper.undo();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPrivate(modifiers));
    }

    /**
     * Changes a final field's modifier from default to public.
     * Expects the field to be final and public after the conversion.
     */
    @Test
    public void changeDefaultFinalToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("finalModifier");
        
        ModifierReflectionHelper.from(field).changeToPublic();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPublic(modifiers));
    }

    /**
     * Undoes changing field's modifier from default to public.
     * Expects the field to be final but not public after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeDefaultFinalToPublic() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("finalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
    }

    /**
     * Changes a final field's modifier from private to public and removes final modifier. After, adds static modifier.
     * Expects the field to be public and static, but not final after the conversion.
     */
    @Test
    public void changeDefaultFinalToPublicAndRemoveFinal() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateFinalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.removeFinal();
        
        helper.add(Modifier.STATIC);
        
        final int modifiers = field.getModifiers();
        
        Assert.assertFalse(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPublic(modifiers));
        
        Assert.assertTrue(Modifier.isStatic(modifiers));
    }

    /**
     * Undoes changing a field's modifier from private to public. Removes the static modifier either.
     * Expects the field to be private and final but not static after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeDefaultFinalToPublicStaticAndRemoveFinal() {
        final Field field = FieldReflectionHelper
                .fromClass(ModifierTestArtifact.class)
                .getField("privateFinalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(field);
        
        helper.changeToPublic();
        
        helper.add(Modifier.STATIC);
        
        helper.removeFinal();
        
        helper.undo();
        
        final int modifiers = field.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPrivate(modifiers));
        
        Assert.assertFalse(Modifier.isStatic(modifiers));
    }

    /**
     * Tries to remove modifier from a default method.
     * Expects the method not to have any modifier after the method call.
     */
    @Test
    public void changeDefaultMethodTryingtoRemoveTheModifier() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "defaultModifier");
        
        ModifierReflectionHelper.from(method).remove(0);
        
        Assert.assertFalse(Modifier.isPublic(method.getModifiers()));
        
        Assert.assertFalse(Modifier.isPrivate(method.getModifiers()));
        
        Assert.assertFalse(Modifier.isProtected(method.getModifiers()));
    }

    /**
     * Undoes removal of modifiers from a default method.
     * Expects the method to be default.
     */
    @Test
    public void UndoesChangeDefaultMethodTryingtoRemoveTheModifier() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "defaultModifier");
        
        ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.remove(0);
        
        helper.undo();
        
        Assert.assertFalse(Modifier.isPublic(method.getModifiers()));
        
        Assert.assertFalse(Modifier.isPrivate(method.getModifiers()));
        
        Assert.assertFalse(Modifier.isProtected(method.getModifiers()));
    }

    /**
     * Changes a method's modifier from private to public.
     * Expects the method not to be private after the conversion.
     */
    @Test
    public void changePrivateMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "privateModifier");
        
        ModifierReflectionHelper.from(method).changeToPublic();
        
        Assert.assertFalse(Modifier.isPrivate(method.getModifiers()));
    }

    /**
     * Undoes changing method's modifier from private to public.
     * Expects the method to be private after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangePrivateMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "privateModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.changeToPublic();
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isPrivate(method.getModifiers()));
    }

    /**
     * Changes a method's modifier from default to public.
     * Expects the method to be public after the conversion.
     */
    @Test
    public void changeDefaultMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "defaultModifier");
        
        ModifierReflectionHelper.from(method).changeToPublic();
        
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    /**
     * Undoes changing method's modifier from default to public.
     * Expects the method to be default after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeDefaultMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "defaultModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
        
        Assert.assertFalse(Modifier.isPrivate(modifiers));
        
        Assert.assertFalse(Modifier.isProtected(modifiers));
    }

    /**
     * Changes a method's modifier from protected to public.
     * Expects the method to be public after the conversion.
     */
    @Test
    public void changeProtectedMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "protectedModifier");
        
        ModifierReflectionHelper.from(method).changeToPublic();
        
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    /**
     * Undoes changing method's modifier from protected to public.
     * Expects the method to be protected after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeProtectedMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "protectedModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertTrue(Modifier.isProtected(modifiers));
    }

    /**
     * Changes a method's modifier from public to private.
     * Expects the method to be private after the conversion.
     */
    @Test
    public void changePublicMethodToPrivate() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "publicModifier");
        
        ModifierReflectionHelper.from(method).changeTo(Modifier.PRIVATE);
        
        Assert.assertTrue(Modifier.isPrivate(method.getModifiers()));
    }

    /**
     * Undoes changing method's modifier from public to private.
     * Expects the method to be public after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoeschangePublicMethodToPrivate() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "publicModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.changeTo(Modifier.PRIVATE);
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    /**
     * Changes a method's modifier from protected to default.
     * Expects the method to be default after the conversion.
     */
    @Test
    public void changeProtectedMethodToDefault() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "protectedModifier");
        
        ModifierReflectionHelper.from(method).remove(Modifier.PROTECTED);
        
        final int modifiers = method.getModifiers();
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
        
        Assert.assertFalse(Modifier.isPrivate(modifiers));
        
        Assert.assertFalse(Modifier.isProtected(modifiers));
    }

    /**
     * Undoes changing method's modifier from protected to default.
     * Expects the method to be protected after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeProtectedMethodToDefault() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "protectedModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.remove(Modifier.PROTECTED);
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isProtected(method.getModifiers()));
    }

    /**
     * Removes the final modifier from a method.
     * Expects the method not to be final after the removal.
     */
    @Test
    public void removeFinalFromMethod() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "finalModifier");
        
        ModifierReflectionHelper.from(method).removeFinal();
        
        Assert.assertFalse(Modifier.isFinal(method.getModifiers()));
    }

    /**
     * Undoes removal of a method's final modifier.
     * Expects the method to be final after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesRemoveFinalFromMethod() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "finalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.removeFinal();
        
        helper.undo();
        
        Assert.assertTrue(Modifier.isFinal(method.getModifiers()));
    }

    /**
     * Removes final modifier from a private method.
     * Expects the method to be private but not final after the removal.
     */
    @Test
    public void removeFinalAndKeepPrivateFromMethod() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "privateFinalModifier");
        
        ModifierReflectionHelper.from(method).removeFinal();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertFalse(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPrivate(modifiers));
    }

    /**
     * Undoes removal of a private method's final modifier.
     * Expects the method to be private and final after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesRemoveFinalAndKeepPrivateFromMethod() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "privateFinalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.removeFinal();
        
        helper.undo();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPrivate(modifiers));
    }

    /**
     * Changes a final method's modifier from default to public.
     * Expects the method to be public and final after the conversion.
     */
    @Test
    public void changeDefaultFinalMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "finalModifier");
        
        ModifierReflectionHelper.from(method).changeToPublic();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertTrue(Modifier.isPublic(modifiers));
    }

    /**
     * Undoes changing a final method's modifier from default to public.
     * Expects the method to be final but not public after {@link ModifierReflectionHelper#undo()} call.
     */
    @Test
    public void undoesChangeDefaultFinalMethodToPublic() {
        final Method method = MethodReflectionHelper
                .getInstance().getMethod(ModifierTestArtifact.class, "finalModifier");
        
        final ModifierReflectionHelper helper = ModifierReflectionHelper.from(method);
        
        helper.changeToPublic();
        
        helper.undo();
        
        final int modifiers = method.getModifiers();
        
        Assert.assertTrue(Modifier.isFinal(modifiers));
        
        Assert.assertFalse(Modifier.isPublic(modifiers));
    }
}
