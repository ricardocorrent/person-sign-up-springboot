package com.ws.commons.utils.reflection.artifact.classAssociation;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Second node artifact class to help on {@link FieldReflectionHelper} test.
 *
 * @author  Rogerio Kiihl
 * @since   6.0.0 - 2018-04-20
 */
public class SecondNodeArtifact extends BaseArtifact {

    private String name;

    public SecondNodeArtifact() {
        name = "second";
    }

    public String getName() {
        return name;
    }
}
