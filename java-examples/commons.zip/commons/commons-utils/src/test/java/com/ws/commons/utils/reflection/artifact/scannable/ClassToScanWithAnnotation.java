package com.ws.commons.utils.reflection.artifact.scannable;

import com.ws.commons.utils.reflection.packages.PackageReflectionHelper;

import javax.ws.rs.Path;

/**
 * This class is meant to be scanned by {@link PackageReflectionHelper} in tests, to cover classes' annotation processing.
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-09-26
 */
@Path("")
public class ClassToScanWithAnnotation {}
