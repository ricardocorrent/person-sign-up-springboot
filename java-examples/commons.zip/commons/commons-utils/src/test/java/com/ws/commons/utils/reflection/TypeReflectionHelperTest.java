package com.ws.commons.utils.reflection;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.artifact.*;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.apache.xmlbeans.impl.xb.xsdschema.Wildcard;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.lang.reflect.*;
import java.util.List;

import static org.junit.Assert.*;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;

/**
 * Test cases for {@link TypeReflectionHelper}.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-09
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*"})
@PrepareForTest(TypeReflectionHelper.class)
public class TypeReflectionHelperTest extends BaseUnitTest{

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validate {@link FieldReflectionHelper}'s default constructor.
     * 
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callDefaultConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        final Constructor<TypeReflectionHelper> constructor = TypeReflectionHelper.class.getDeclaredConstructor();
        /* @PrepareForTest changes the constructor to public */
        /* assertTrue(Modifier.isPrivate(constructor.getModifiers())); */
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from Object.class.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromObjectClass() {
        final Class<?> type = TypeReflectionHelper.getGenericType(Object.class, 0);
        
        assertNotNull(type);
        
        assertTrue(type.equals(Object.class));
    }


    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from a single class.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromSingleClass() {
        final Class<?> type = TypeReflectionHelper.getGenericType(GenericClassTestArtifact.class, 0);
        
        assertNotNull(type);
        
        assertTrue(type.equals(GenericClassTestArtifact.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from {@link TypeVariable}.
     * It should get both generic types correctly.
     */
    @Test
    public void getGenericTypeFromTypeVariable() {
        final Class<?> targetClass = GenericClassTestArtifact.class;
        
        final Class<?> firstType = TypeReflectionHelper.getGenericType(targetClass.getTypeParameters()[0], 0);
        
        final Class<?> secondType = TypeReflectionHelper.getGenericType(targetClass.getTypeParameters()[0], 1);
        
        assertNotNull(firstType);
        
        assertNotNull(secondType);
        
        assertTrue(firstType.equals(ClassTestArtifact.class));
        
        assertTrue(secondType.equals(IIntnterfaceTestArtifact.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from {@link Wildcard}'s upper bound.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromWildCardTypeUpperBound() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("map");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 0);
        
        assertNotNull(type);
        
        assertTrue(type.equals(Object.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from {@link Wildcard}'s lower bound.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromWildCardTypeLowerBound() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("map");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 1);
        
        assertNotNull(type);
        
        assertTrue(type.equals(Object.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from an array.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromArray() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("listArray");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 1);
        
        assertNotNull(type);
        
        assertTrue(type.equals(List.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from a matrix.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromMatrix() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("matrix");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 1);
        
        assertNotNull(type);
        
        assertTrue(type.equals(List.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from an array's list.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromArraysList() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("arrayList");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 0);
        
        assertNotNull(type);
        
        assertTrue(type.equals(String[].class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from an array's list inside list.
     * It should get the generic type correctly.
     */
    @Test
    public void getGenericTypeFromArraysListInsideList() {
        final Field field = FieldReflectionHelper.fromClass(GenericClassTestArtifact.class).getField("listArrayList");
        
        final Class<?> type = TypeReflectionHelper.getGenericType(field.getGenericType(), 0);
        
        assertNotNull(type);
        
        assertTrue(type.equals(String[].class));
    }

    /**
     * Validates retrieval of three generic types on {@link TypeReflectionHelper#getGenericType(Type, int)} from {@link ClassTestArtifact}.
     * It should get all the generic types correctly.
     */
    @Test
    public void getFirstThreeGenericTypes() {
        final Class<?> targetClass = ClassTestArtifact.class;
        
        final Class<?> firstParameterizedType = TypeReflectionHelper.getGenericType(targetClass.getGenericSuperclass(), 0);
        
        final Class<?> secondParameterizedType = TypeReflectionHelper.getGenericType(targetClass.getGenericSuperclass(), 1);
        
        final Class<?> thirdParameterizedType = TypeReflectionHelper.getGenericType(targetClass.getGenericSuperclass(), 2);
        
        assertNotNull(firstParameterizedType);
        
        assertNotNull(secondParameterizedType);
        
        assertNotNull(thirdParameterizedType);
        
        assertTrue(firstParameterizedType.equals(GenericClassTestArtifact.class));
        
        assertTrue(secondParameterizedType.equals(ClassTestArtifact.class));
        
        assertTrue(thirdParameterizedType.equals(ClassTestArtifact.InnerClassTestArtifact.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} from {@code null} class.
     * It should throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullParameterOnGetGenericType() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("type"));
        
        TypeReflectionHelper.getGenericType(null, 0);
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericType(Type, int)} when providing a negative parameter to the desired
     * position.
     * It should throw an {@link ArrayIndexOutOfBoundsException}.
     */
    @Test
    public void throwsArrayIndexOutOfBoundsExceptionWhenPassNegativeParameterOnGetGenericType() {
        thrown.expect(ArrayIndexOutOfBoundsException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        TypeReflectionHelper.getGenericType(ClassTestArtifact.class, -1);
    }
    
    /**
     * Validates the first two generic type parameters.
     * It should ensure that the method calls {@link TypeReflectionHelper#getGenericType(java.lang.reflect.Type, int)}.
     *
     * @throws SecurityException if field reflection fails.
     * @throws NoSuchFieldException if field reflection fails.
     */
    @Test
    public void getGenericFieldType() throws NoSuchFieldException, SecurityException {
        final Field declaredField = ClassTestArtifact.class.getDeclaredField("anyMap");
        
        mockStatic(TypeReflectionHelper.class, Mockito.CALLS_REAL_METHODS);
        
        final Class<?> firstType = TypeReflectionHelper.getGenericFieldType(declaredField, 0);
        
        verifyStatic();
        TypeReflectionHelper.getGenericFieldType(declaredField, 0);
        
        /* Repeating mockStatic to restart the verifying scope */
        mockStatic(TypeReflectionHelper.class, Mockito.CALLS_REAL_METHODS);
        
        final Class<?> secondType = TypeReflectionHelper.getGenericFieldType(declaredField, 1);
        
        verifyStatic();
        TypeReflectionHelper.getGenericFieldType(declaredField, 1);
        
        assertNotNull(firstType);
        assertNotNull(secondType);
        
        assertTrue(firstType.equals(String.class));
        assertTrue(secondType.equals(Integer.class));
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericFieldType(Field, int)} when passing {@code null} field as parameter.
     * It should throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullParameterOnGetGenericFieldType() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("filed"));
        
        TypeReflectionHelper.getGenericFieldType(null, 0);
    }
    
    /**
     * Validates {@link TypeReflectionHelper#getGenericFieldType(Field, int)} when passing a negative index as parameter.
     * Expect to throw an {@link ArrayIndexOutOfBoundsException}.
     * 
     * @throws SecurityException                if field reflection fails.
     * @throws NoSuchFieldException             if field reflection fails.
     * @throws ArrayIndexOutOfBoundsException   when send negative parameter to getGenericType method.
     */
    @Test
    public void throwsArrayIndexOutOfBoundsExceptionWhenPassNegativeParameterOnGetGenericFieldType() throws NoSuchFieldException, SecurityException {
        thrown.expect(ArrayIndexOutOfBoundsException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        final Field field = ClassTestArtifact.class.getDeclaredField("anyString");
        
        TypeReflectionHelper.getGenericFieldType(field, -1);
    }

    /**
     * Validates retrieval of two generic field types on {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)} from {@link ClassTestArtifact}.
     * It should get all the generic field types correctly.
     */
    @Test
    public void getGenericTypeFromInterface() {
        final Class<?> targetClass = ClassTestArtifact.class;
        
        final Class<?> firstParameterizedType = TypeReflectionHelper.getGenericTypeFromInterface(targetClass, IGenericInterfaceTestArtifact.class, 0);
        final Class<?> secondParameterizedType = TypeReflectionHelper.getGenericTypeFromInterface(targetClass, IGenericInterfaceTestArtifact.class, 1);
        
        assertNotNull(firstParameterizedType);
        assertNotNull(secondParameterizedType);
        
        assertTrue(firstParameterizedType.equals(ClassTestArtifact.class));
        assertTrue(secondParameterizedType.equals(ClassTestArtifact.InnerClassTestArtifact.class));
    }

    /**
     * Validates retrieval of generic field type on {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)}
     * from interface when passing a non generic interface.
     * The method's call should return {@code null}.
     */
    @Test
    public void getGenericTypeFromInterfaceWhenPassNonGenericInterface() {
        final Class<?> targetClass = ClassTestArtifact.class;
        
        final Class<?> type = TypeReflectionHelper.getGenericTypeFromInterface(targetClass, IIntnterfaceTestArtifact.class, 0);
        
        assertNull(type);
    }

    /**
     * Validates retrieval of generic field type on {@link TypeReflectionHelper#getGenericType(Type, int)} from an interface
     * that has generic type variable.
     * The method's call should return {@code null}.
     */
    @Test
    public void getGenericTypeFromInterfaceWhenGenericWillBeTypeVariable() {
        final Class<?> targetClass = ClassTestArtifact.class;
        
        final Class<?> type = TypeReflectionHelper.getGenericTypeFromInterface(targetClass, IInterfaceTypeVariableTestArtifact.class, 0);
        
        assertNull(type);
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)} when passing {@code null}
     * to source class.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullSourceClassOnGetGenericTypeFromInterface() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("sourceClass"));
        
        TypeReflectionHelper.getGenericTypeFromInterface(null, IGenericInterfaceTestArtifact.class, 0);
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)} when passing {@code null}
     * to interface class.
     * Expects to throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullInterfaceClassOnGetGenericTypeFromInterface() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("interfaceClass"));
        
        TypeReflectionHelper.getGenericTypeFromInterface(ClassTestArtifact.class, null, 1);
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)} when passing wrong parameter
     * to interface class.
     * Expects to throw a {@link ReflectionException}.
     */
    @Test
    public void throwsReflectionExceptionWhenPassIllegalParameterOnGetGenericTypeFromInterface() {
        final Class<?> targetClass = ClassTestArtifact.class;
        
        thrown.expect(ReflectionException.class);
        
        thrown.expectMessage(EReflectionHelperMessage.THE_TYPE_IS_NOT_A_INTERFACE.getMessage(targetClass.getName()));
        
        TypeReflectionHelper.getGenericTypeFromInterface(targetClass, targetClass, 0);
    }

    /**
     * Validates {@link TypeReflectionHelper#getGenericTypeFromInterface(Class, Class, int)} when passing negative index
     * as the position parameter.
     * Expects to throw an {@link ArrayIndexOutOfBoundsException}.
     */
    @Test
    public void throwsArrayIndexOutOfBoundsExceptionWhenPassNegativeParameterOnGetGenericTypeFromInterface() {
        thrown.expect(ArrayIndexOutOfBoundsException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_MUST_BE_POSITIVE.getMessage("position"));
        
        final Class<?> targetClass = ClassTestArtifact.class;
        
        TypeReflectionHelper.getGenericTypeFromInterface(targetClass, targetClass, -1);
    }
}

