package com.ws.commons.utils.reflection.packages;

import com.ws.commons.utils.reflection.artifact.ClassTestArtifact;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.ws.rs.Path;
import java.util.Set;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;

/**
 * Test cases for {@link PackageReflectionHelper}.
 *
 * @author  Diego Armange Costa
 * @since   5.2.0 2017-09-30
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*"})
@PrepareForTest(PackageReflectionHelper.class)
public class PackageReflectionHelperTest {

    /**
     * Checks a package having a corresponding class.
     * It should execute successfully.
     */
    @SuppressWarnings("unchecked")
    @Test
    public void scanClassWithJAXRSPathAnnotation() {
        Set<Class<?>> classSet = PackageReflectionHelper
            .fromPackage(ClassTestArtifact.class.getPackage())
            .containingAnnotations(Path.class)
            .recursively()
            .getClassSet();
        
        assertNotNull(classSet);
        
        assertThat(classSet, hasSize(2));
        
        assertThat(classSet, allOf(
            hasItems(com.ws.commons.utils.reflection.artifact.ClassToScanWithAnnotation.class),
            hasItems(com.ws.commons.utils.reflection.artifact.scannable.ClassToScanWithAnnotation.class)
        ));
    }
    
    /**
     * Tests converting of a package path to resource path.
     * It should execute successfully.
     */
    @Test
    public void getNameAsResourcePath() {
        String resourcePath = PackageReflectionHelper.getNameAsResourcePath(ClassTestArtifact.class.getPackage());
        
        assertEquals("com/ws/commons/utils/reflection/artifact".replaceAll("/", PackageReflectionHelper.FILE_SEPARATOR_REGEX),resourcePath);
    }
    
    /**
     * Tests the scenario when a problem occurs on {@link PackageReflectionHelper#getNameAsResourcePath(Package)} and an
     * exception in thrown. It should throw a {@link ReflectionException} when resource reading fails.
     *
     * @throws Exception if mock static method fails.
     */
    @SuppressWarnings("unchecked")
    @Test(expected = ReflectionException.class)
    public void throwReflectionExceptionWhenResourceReadingFails() throws Exception {
        PowerMockito.mockStatic(PackageReflectionHelper.class, Mockito.CALLS_REAL_METHODS);
        
        PowerMockito.doThrow(new RuntimeException()).when(PackageReflectionHelper.class, "getNameAsResourcePath", ClassTestArtifact.class.getPackage());
        
        Set<Class<?>> classSet = PackageReflectionHelper
            .fromPackage(ClassTestArtifact.class.getPackage())
            .containingAnnotations(Path.class)
            .recursively()
            .getClassSet();
        
        verifyStatic();
        PackageReflectionHelper.getNameAsResourcePath(ClassTestArtifact.class.getPackage());
        
        assertNotNull(classSet);
        
        assertThat(classSet, hasSize(0));
    }
}
