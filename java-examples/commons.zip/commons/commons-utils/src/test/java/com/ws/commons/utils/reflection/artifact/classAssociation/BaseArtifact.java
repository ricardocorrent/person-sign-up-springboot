package com.ws.commons.utils.reflection.artifact.classAssociation;

import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * Base artifact class to help on {@link FieldReflectionHelper} test.
 *
 * @since   6.0.0 - 2018-04-20
 * @author  Rogerio Kiihl
 */
public class BaseArtifact {
}
