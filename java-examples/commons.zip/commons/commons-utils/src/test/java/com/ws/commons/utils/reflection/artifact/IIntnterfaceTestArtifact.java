package com.ws.commons.utils.reflection.artifact;

/**
 * Interface test artifact to be used on reflection tests.
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-15
 */
public interface IIntnterfaceTestArtifact {

}
