package com.ws.commons.utils.reflection;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.utils.reflection.artifact.ClassTestArtifact;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Matchers;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.Assert.*;

/**
 * Test cases for {@link MethodReflectionHelper}.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-14
 */
public class MethodReflectionHelperTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validates {@link MethodReflectionHelper#getInstance()} method.
     * It should retrieve an instance correctly.
     */
    @Test
    public void getInstance() {
        Object instance = MethodReflectionHelper.getInstance();
        
        assertNotNull(instance);
        
        assertTrue(instance instanceof MethodReflectionHelper);
    }
    
    /**
     * Validates the exception throwing method.
     * 
     * @see MethodReflectionHelper#throwException(Class)
     * @see MethodReflectionHelper#invokeMethod(String, Object, Object...)
     */
    @Test
    public void throwException() {
        MethodReflectionHelper instance = MethodReflectionHelper.getInstance();
        
        instance.throwException(RuntimeException.class);
        
        assertEquals(RuntimeException.class, 
                FieldReflectionHelper
                    .fromInstance(instance).getFieldValue("runtimeThrowableClass"));
    }
    
    /**
     * Tests invoking method with a {@code null} declaring instance.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenInvokeMethodWithNullDeclaringInstance() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringInstance"));
        
        MethodReflectionHelper.getInstance().invokeMethod("getAnyString", null);
    }
    
    
    /**
     * Validates method invocation with null target class.
     */
    @Test
    public void invokeMethodByClassWithNullTargetClass() {
        /* It's not necessary, because is ambiguous method scenery. */
    }
    
    /**
     * Tests invoking method by class with {@code null} method name.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void throwsNullPointerExceptionWhenInvokeMethodByClassWithNullMethodName() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("method"));
        
        MethodReflectionHelper.getInstance().invokeMethod(ClassTestArtifact.class, null, new ClassTestArtifact());
    }

    /**
     * Tests invoking method by class with {@code null} declaring instance.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenInvokeMethodByClassWithNullDeclaringInstance() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringInstance"));
        
        MethodReflectionHelper.getInstance().invokeMethod(ClassTestArtifact.class, "", null);
    }
    
    /**
     * Validates method invocation with no arguments.
     */
    @Test
    public void invokeMethodWithNoArguments() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        int expected = 1;
        
        classTestArtifact.setAnyInteger(expected);
        
        Object object = MethodReflectionHelper.getInstance().invokeMethod("getAnyInteger", classTestArtifact);
        
        assertNotNull(object);
        
        assertEquals(expected, object);
    }
    
    /**
     * Validates method invocation with arguments.
     */
    @Test
    public void invokeMethodWithArguments() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        String expected = "Teste";
        
        MethodReflectionHelper.getInstance().invokeMethod("setAnyString", classTestArtifact, expected);
        
        assertNotNull(classTestArtifact.getAnyString());
        
        assertEquals(expected, classTestArtifact.getAnyString());
    }

    /**
     * Tests invoking method with wrong arguments.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwsReflectionExceptionWhenInvokeMethodWithWrongArguments() {
        Integer expected = 0;
        
        thrown.expect(ReflectionException.class);
        
        MethodReflectionHelper.getInstance().invokeMethod("setAnyString", new ClassTestArtifact(), expected);
    }
    
    /**
     * Validates call from other internal methods.
     */
    @Test
    public void invokeMethodCallInvokeByClass() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        MethodReflectionHelper spy = Mockito.spy(MethodReflectionHelper.class);
        
        spy.invokeMethod("getAnyString", classTestArtifact);
        
        Mockito.verify(spy, Mockito.times(1)).invokeMethod(Mockito.any(Class.class), Mockito.anyString(), Matchers.<Object> anyVararg());
        
        Mockito.verify(spy, Mockito.times(1)).getMethod(Mockito.any(Class.class), Mockito.anyString(), Matchers.<Class<?>> anyVararg());
        
        Mockito.verify(spy, Mockito.times(1)).invokeMethod(Mockito.any(Method.class), Mockito.anyObject(), Matchers.<Object> anyVararg());
    }

    /**
     * Tests  {@link MethodReflectionHelper#getMethod(Class, String, Class[])} with {@code null} declaring class.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenGetMethodWithNullTargetClass() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(
                EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(
                        ReflectionStringConstants.DECLARING_CLASS_NAME.getValue()));
        
        MethodReflectionHelper.getInstance().getMethod(null, "setAnyString", String.class);
    }

    /**
     * Tests {@link MethodReflectionHelper#getMethod(Class, String, Class[])} with {@code null} method name.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenGetMethodWithNullMethodName() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("method"));
        
        MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, null, String.class);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getMethod(Class, String, Class[])} with arguments.
     */
    @Test
    public void getMethodWithArguments() {
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "setAnyString", String.class);
        
        assertNotNull(method);
        
        assertEquals("setAnyString", method.getName());
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getMethod(Class, String, Class[])} with no arguments.
     */
    @Test
    public void getMethodWithNoArguments() {
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "getAnyString");
        
        assertNotNull(method);
        
        assertEquals("getAnyString", method.getName());
    }

    /**
     * Tests {@link MethodReflectionHelper#getMethod(Class, String, Class[])} when wrong parameters are provided.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenGetMethodWithWrongArguments() {
        thrown.expect(ReflectionException.class);
        
        MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "getAnyString", String.class);
    }
    
    /**
     * Validates method invocation without method name, with arguments.
     */
    @Test
    public void invokeMethodWithoutMethodNameWithArguments() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "setAnyString", String.class);
        
        String expected = "teste";
        
        MethodReflectionHelper.getInstance().invokeMethod(method, classTestArtifact, expected);
        
        assertNotNull(classTestArtifact.getAnyString());
        
        assertEquals(expected, classTestArtifact.getAnyString());
    }

    /**
     * Tests {@link MethodReflectionHelper#invokeMethod(Method, Object, Object...)} allowing it to throw specific exception.
     * It must throw a {@link NumberFormatException}.
     */
    @Test
    public void throwNumberFormatExceptionWhenInvokeMethodAndAllowThrowSpecificException() {
        thrown.expect(NumberFormatException.class);
        
        ClassTestArtifact dummyEntity = Mockito.mock(ClassTestArtifact.class);
        
        Mockito.doThrow(NumberFormatException.class).when(dummyEntity).getAnyInteger();
        
        MethodReflectionHelper helper = MethodReflectionHelper.getInstance();
        
        helper.throwException(NumberFormatException.class);
        
        helper.invokeMethod(helper.getMethod(ClassTestArtifact.class, "getAnyInteger"), dummyEntity);
    }

    /**
     * Tests {@link MethodReflectionHelper#invokeMethod(Method, Object, Object...)} not allowing it to throw specific exception.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenInvokeMethodAndNotThrowSpecificException() {
        thrown.expect(ReflectionException.class);
        
        ClassTestArtifact dummyEntity = Mockito.mock(ClassTestArtifact.class);
        
        Mockito.doThrow(IllegalStateException.class).when(dummyEntity).getAnyInteger();
        
        MethodReflectionHelper helper = MethodReflectionHelper.getInstance();
        
        helper.throwException(NumberFormatException.class);
        
        helper.invokeMethod(helper.getMethod(ClassTestArtifact.class, "getAnyInteger"), dummyEntity);
    }
    
    /**
     * Validates method invocation without method name, with no arguments.
     */
    @Test
    public void invokeMethodWithoutMethodNameWithNoArguments() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        String expected = "teste";
        
        classTestArtifact.setAnyString(expected);
        
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "getAnyString");
        
        Object object = MethodReflectionHelper.getInstance().invokeMethod(method, classTestArtifact);
        
        assertNotNull(object);
        
        assertEquals(expected, object);
    }


    /**
     * Tests method invocation without method name and with wrong arguments.
     * It must throw a {@link ReflectionException}.
     */
    @Test
    public void throwReflectionExceptionWhenInvokeMethodWithoutMethodNameWithWrongArguments() {
        ClassTestArtifact classTestArtifact = new ClassTestArtifact();
        
        String expected = "teste";
        
        classTestArtifact.setAnyString(expected);
        
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "getAnyString");
        
        thrown.expect(ReflectionException.class);
        
        MethodReflectionHelper.getInstance().invokeMethod(method, classTestArtifact, "wrong");
    }
    
    /**
     * Validates method invocation with {@code null} method object.
     */
    @Test
    public void invokeMethodWithoutMethodNameWithNullMethodObject() {
     /* It's not necessary, because is ambiguous method scenery. */
    }
    
    /**
     * Tests method invocation without method name and with {@code null} declaring class.
     * It mus throw a {@link NullPointerException}.
     */
    @Test
    public void throwNullPointerExceptionWhenInvokeMethodWithoutMethodNameWithNullDeclaringInstance() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringInstance"));
        
        Method method = MethodReflectionHelper.getInstance().getMethod(ClassTestArtifact.class, "getAnyString");
        
        MethodReflectionHelper.getInstance().invokeMethod(method, null);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the getter.
     */
    @Test
    public void getGetterWithoutExceptions() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyString");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the primitive boolean getter.
     */
    @Test
    public void getPrimitiveBooleanGetterWithoutExceptions() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyBoolean");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the primitive boolean getter.
     */
    @Test
    public void getWrapperBooleanGetterWithoutExceptions() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyWrapperBoolean");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validate {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the primitive boolean getter.
     */
    @Test
    public void getPrimitiveLongGetterWithoutExceptions() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyLong");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the primitive boolean getter
     * without Java encapsulation convention.
     */
    @Test
    public void getPrimitiveBooleanGetterWithoutConvetion() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("primitiveBooleanWithoutConvention");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethodIgnoringConvetion(field, MethodReflectionHelper.EncapsulationMethod.GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the primitive boolean getter
     * without Java encapsulation convention.
     */
    @Test
    public void getPrimitiveBooleanGetterWithoutConvetionForcingGET() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("primitiveBooleanWithoutConvention");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethodIgnoringConvetion(field, MethodReflectionHelper.EncapsulationMethod.FORCE_GET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's finding the setter (without exceptions).
     */
    @Test
    public void getSetterWithoutExceptions() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anyString");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.SET);
        
        assertNotNull(encapsulationMethod);
    }
    
    /**
     * Validates {@link MethodReflectionHelper#getEncapsulationMethod} when it's searching nonexistent setter.
     */
    @Test
    public void getNullWhenSetterDoesNotExist() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anotherBoolean");
        
        final Method encapsulationMethod = MethodReflectionHelper.getInstance().getEncapsulationMethod(field, MethodReflectionHelper.EncapsulationMethod.SET);
        
        assertNull(encapsulationMethod);
    }
    
    /**
     * Validate {@link MethodReflectionHelper#getEncapsulationMethod} when it's searching nonexistent setter without
     * Java encapsulation convention.
     */
    @Test
    public void getNullIgnoringConventionsWhenSetterDoesNotExist() {
        final Field field = FieldReflectionHelper.fromClass(ClassTestArtifact.class).getField("anotherBoolean");
        
        final MethodReflectionHelper methodReflectionHelper = new MethodReflectionHelper();
        
        final Method encapsulationMethod = methodReflectionHelper.getEncapsulationMethodIgnoringConvetion(field, MethodReflectionHelper.EncapsulationMethod.SET);
        
        assertNull(encapsulationMethod);
    }
}