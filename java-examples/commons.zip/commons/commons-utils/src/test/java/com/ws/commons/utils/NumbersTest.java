package com.ws.commons.utils;

import com.sollar.test.BaseUnitTest;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.testng.Assert;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertTrue;

/**
 * Test cases for {@link Numbers}.
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-16
 */
public class NumbersTest extends BaseUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Validates {@link NumbersTest}'s default constructor.
     * 
     * @throws InvocationTargetException    if constructor reflection fails.
     * @throws IllegalArgumentException     if constructor reflection fails.
     * @throws IllegalAccessException       if constructor reflection fails.
     * @throws InstantiationException       if constructor reflection fails.
     * @throws SecurityException            if constructor reflection fails.
     * @throws NoSuchMethodException        if constructor reflection fails.
     */
    @Test
    public void callDefaultConstructor() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        Constructor<Numbers> constructor = Numbers.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    /**
     * Validates when a positive integer is required.
     */
    @Test
    public void requirePositiveInteger() {
        Integer value = 1;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Validates when a positive long is required.
     */
    @Test
    public void requirePositiveLong() {
        Long value = 1L;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Validate when a positive float is required.
     */
    @Test
    public void requirePositiveFloat() {
        Float value = 1f;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Validates when a positive double is required.
     */
    @Test
    public void requirePositiveDouble() {
        Double value = 1d;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Validates when a positive short is required.
     */
    @Test
    public void requirePositiveShort() {
        Short value = 1;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Tests when a required positive short has negative value.
     * Expects to throw an {@link ArrayIndexOutOfBoundsException}.
     */
    @Test
    public void throwsArrayIndexOutOfBoundsExceptionWhenRequirePositiveShortWithNegativeParameter() {
        thrown.expect(ArrayIndexOutOfBoundsException.class);
        
        Short value = -1;
        
        Numbers.requirePositive(value, "");
    }
    
    /**
     * Tests splitting three integers to an array {0,1,2}.
     */
    @Test
    public void rangeThreeGreatness() {
        final int[] split = Numbers.range(3);
        
        Assert.assertEquals(split, new int[] {0,1,2});
    }
    
    /**
     * Tests splitting an integer (1) to array {0}.
     */
    @Test
    public void rangeOneGreatness() {
        final int[] split = Numbers.range(1);
        
        Assert.assertEquals(split, new int[] {0});
    }
    
    /**
     * Tries to invoke {@link Numbers#range(Integer)} providing an invalid integer as parameter.
     * It must throw an {@link IllegalArgumentException}.
     */
    @Test
    public void rangeWithInvalidInteger() {
        thrown.expect(IllegalArgumentException.class);
        
        thrown.expectMessage("Integers smaller than 1 can not be split.");
        
        Numbers.range(0);
    }
}
