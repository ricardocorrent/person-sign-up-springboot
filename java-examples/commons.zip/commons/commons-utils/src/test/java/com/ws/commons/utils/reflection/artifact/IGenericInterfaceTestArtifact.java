package com.ws.commons.utils.reflection.artifact;

/**
 * Generic interface artifact to be used on reflection tests.
 *
 * @author      Diego Armange Costa
 * @param <T>   extends ClassTestArtifact
 * @param <U>   undefined
 * @since       5.0.0 2017-08-09
 */
public interface IGenericInterfaceTestArtifact<T extends ClassTestArtifact, U> {

}
