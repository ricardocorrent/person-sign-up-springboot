package com.ws.commons.utils.reflection.artifact;

/**
 * Interface artifact to be used on reflection tests execution.
 * 
 * @author      Diego Armange Costa
 * @param <T>   generic type
 * @since       5.0.0 2017-08-15
 */
public interface IInterfaceTypeVariableTestArtifact<T extends ClassTestArtifact> {

}
