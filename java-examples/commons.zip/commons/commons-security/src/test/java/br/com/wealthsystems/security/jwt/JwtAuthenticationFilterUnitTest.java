package br.com.wealthsystems.security.jwt;

import org.apache.shiro.authc.AuthenticationException;
import org.junit.Test;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit test cases for {@link JwtAuthenticationFilter}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtAuthenticationFilterUnitTest {

    /**
     * Validates behaviour of login failure.
     *
     * @throws IOException to validate behaviour when exception occurs
     */
    @Test
    public void onLoginFailureMustJustReturnFalse() throws IOException {

        final JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter();
        final HttpServletResponse response = mock(HttpServletResponse.class);
        doThrow(new IOException()).when(response).sendError(anyInt(), anyString());

        final AuthenticationException exception = new AuthenticationException("error");

        final Boolean result = jwtAuthenticationFilter.onLoginFailure(null, exception ,null, response);
        assertFalse(result);
    }

    /**
     * Validates if authentication error messages and logs are propagated when login fails.
     *
     * @throws IOException when an error occurs
     */
    @Test
    public void onLoginFailurePropagateAuthenticationErrorMessageAndLog() throws IOException {

        final JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter();
        final HttpServletResponse response = mock(HttpServletResponse.class);
        final AuthenticationException exception = mock(AuthenticationException.class);

        jwtAuthenticationFilter.onLoginFailure(null, exception ,null, response);

        verify(response, times(1)).sendError(anyInt());
        verify(exception, times(1)).getMessage();
    }

}
