package br.com.wealthsystems.security.jwt;

import br.com.wealthsystems.security.exception.JwtException;
import br.com.wealthsystems.security.exception.JwtExpiredException;
import br.com.wealthsystems.security.exception.JwtInvalidSignatureJwtException;
import br.com.wealthsystems.security.utils.JwtUnitTestUtils;
import org.junit.Test;

import java.security.KeyPair;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Unit test cases for {@link JwtTokenUnitTest}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtTokenUnitTest {

    private final String stringToken = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims());

    /**
     * Validates if {@link JwtAuthenticationToken#getPrincipal()} returns the token in a raw string
     * successfully.
     */
    @Test
    public void getPrincipalMustReturnRawStringToken() {

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(stringToken);

        assertEquals(authenticationToken.getPrincipal(), stringToken);
    }

    /**
     * Validates if {@link JwtAuthenticationToken#getCredentials()} returns the token in a raw string
     * successfully.
     */
    @Test
    public void getCredentialslMustReturnRawStringToken() {

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(stringToken);

        assertEquals(authenticationToken.getCredentials(), stringToken);
    }

    /**
     * Validates if a creation of an extracted token in instantiated successfully.
     */
    @Test
    public void getTokenMustReturnExtractedToAccessToken() {

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(stringToken);

        assertTrue(authenticationToken.getToken() != null);
    }

    /**
     * Validates the verification of a valid token.
     * <P>Expects not to throw a {@link JwtException}.</P>
     *
     * @throws JwtException if the token is not valid
     */
    @Test
    public void verifyValidTokenMustNotThrowException() throws JwtException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);

        final String token = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair);

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(token);

        authenticationToken.verify(keyPair.getPublic());

    }

    /**
     * Validates the verification of an invalid token.
     * <p>Expects to throw a {@link JwtException}.</p>
     *
     * @throws JwtException if the token is not valid
     */
    @Test(expected = JwtException.class)
    public void verifyInvalidTokenMustThrowException() throws JwtException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        String token = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair);
        token = token.concat("Invalidate token String");

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(token);
        authenticationToken.verify(keyPair.getPublic());

    }

    /**
     * Validates the verification of an invalid authentication public key that doesn't correspond to actual token.
     * <p>Expects to throw a {@link JwtInvalidSignatureJwtException}, since the generated public key does not match
     * the current token's pair key</p>
     *
     * @throws JwtException if the token is not valid
     */
    @Test(expected = JwtInvalidSignatureJwtException.class)
    public void verifyInvalidPublicKeyMustThrowException() throws JwtException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        String token = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair);

        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(token);
        // Generating any random public key based on any other KeyPair
        authenticationToken.verify(JwtUnitTestUtils.generateKeyPair(1024).getPublic());

    }

    /**
     * Validates the verification process of an expired token.
     * <p>Expects to throw a {@link JwtExpiredException}, since the token is expired.</p>
     *
     * @throws JwtException if the token is not valid
     */
    @Test(expected = JwtExpiredException.class)
    public void verifyTokenExpiredMustThrowException() throws JwtException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);

        final String token = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getExpiredTokenClaims(), keyPair);
        final JwtAuthenticationToken authenticationToken = new JwtAuthenticationToken(token);

        authenticationToken.verify(keyPair.getPublic());
    }
    
}
