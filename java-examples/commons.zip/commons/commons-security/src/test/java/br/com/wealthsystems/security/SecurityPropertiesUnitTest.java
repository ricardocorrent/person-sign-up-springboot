package br.com.wealthsystems.security;

import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.inject.Inject;

import static org.junit.Assert.assertEquals;

/**
 * Unit test cases for {@link SecurityProperties} class.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-26
 */
@RunWith(CdiTestRunner.class)
public class SecurityPropertiesUnitTest {

    @Inject
    private SecurityProperties properties;

    /**
     * Validates public key property.
     */
    @Test
    public void publicKeyResource() {
        assertEquals("/oauth/token_key", properties.publicKeyResource());
    }

    /**
     * Validates public key address property.
     */
    @Test
    public void publicKeyAddress() {
        assertEquals("http://localhost:9999/api/v1/uaa", properties.publicKeyAddress());
    }

    /**
     * Validates client id property.
     */
    @Test
    public void clientId() {
        assertEquals("web_app", properties.clientId());
    }

    /**
     * Validates client secret property.
     */
    @Test
    public void clientSecret() {
        assertEquals("changeit", properties.clientSecret());
    }

    /**
     * Validates authorization resource name.
     */
    @Test
    public void authorizationResource() {
        assertEquals("/users/self-permissions", properties.authorizationResource());
    }

    /**
     * Validates authorization address.
     */
    @Test
    public void authorizationAddress() {
        assertEquals("http://localhost:9091/api/user", properties.authorizationAddress());
    }

}
