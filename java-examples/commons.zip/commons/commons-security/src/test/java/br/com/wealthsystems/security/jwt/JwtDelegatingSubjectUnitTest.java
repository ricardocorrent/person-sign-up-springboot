package br.com.wealthsystems.security.jwt;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SessionContext;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.subject.WebSubjectContext;
import org.apache.shiro.web.subject.support.DefaultWebSubjectContext;
import org.junit.Test;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.generateJwt;
import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.getDefaultClaims;
import static org.junit.Assert.assertEquals;

/**
 * Unit test cases for {@link JwtDelegatingSubject}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtDelegatingSubjectUnitTest {

    /**
     * Validates if session context returns session id correctly.
     * Expects to get it successfully.
     */
    @Test
    public void createSessionContextMustReturnTokenSubAsSessionId() {

        final JwtDelegatingSubject jwtDelegatingSubject = getJwtDelegatingSubject(stubSubjectContext());
        final SessionContext context = jwtDelegatingSubject.createSessionContext();

        assertEquals("Gandalf The White", context.getSessionId());
    }

    private JwtDelegatingSubject getJwtDelegatingSubject(SubjectContext context) {

        final WebSubjectContext wsc = (WebSubjectContext) context;
        final SecurityManager securityManager = wsc.resolveSecurityManager();
        final Session session = wsc.resolveSession();
        final boolean sessionEnabled = wsc.isSessionCreationEnabled();
        final PrincipalCollection principals = wsc.resolvePrincipals();
        final boolean authenticated = wsc.resolveAuthenticated();
        final String host = wsc.resolveHost();
        final ServletRequest request = wsc.resolveServletRequest();
        final ServletResponse response = wsc.resolveServletResponse();

        return new JwtDelegatingSubject(principals, authenticated, host, session, sessionEnabled,
                request, response, securityManager);
    }

    private SubjectContext stubSubjectContext() {
        final SubjectContext context = new DefaultWebSubjectContext();
        context.setAuthenticated(true);

        final SimplePrincipalCollection collection = new SimplePrincipalCollection();
        collection.add(generateJwt(getDefaultClaims()), "tenant");
        context.setPrincipals(collection);
        context.setSecurityManager(new DefaultWebSecurityManager());

        return context;
    }
}
