package br.com.wealthsystems.security.jwt;

import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.subject.support.DefaultWebSubjectContext;
import org.junit.Test;

import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.generateJwt;
import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.getDefaultClaims;
import static org.junit.Assert.assertNotNull;

/**
 * Unit test cases for {@link JwtSubjectFactory}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtSubjectFactoryUnitTest {

    /**
     * Validates successful creation of a subject.
     */
    @Test
    public void createSubjectMustReturnDefaultWebSubjectFactory(){

        final JwtSubjectFactory jwtSubjectFactory = new JwtSubjectFactory();
        jwtSubjectFactory.createSubject(stubSubjectContext());

        assertNotNull(jwtSubjectFactory);
    }

    private SubjectContext stubSubjectContext() {
        final SubjectContext context = new DefaultWebSubjectContext();
        context.setAuthenticated(true);

        final SimplePrincipalCollection collection = new SimplePrincipalCollection();
        collection.add(generateJwt(getDefaultClaims()), "tenant");
        context.setPrincipals(collection);
        context.setSecurityManager(new DefaultWebSecurityManager());

        return context;
    }
}
