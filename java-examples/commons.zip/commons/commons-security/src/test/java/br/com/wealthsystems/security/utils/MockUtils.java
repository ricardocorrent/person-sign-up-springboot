package br.com.wealthsystems.security.utils;

import br.com.wealthsystems.security.hofund.HofundJwkParseCacheLoader;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.jwk.RSAKey;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Mock utility class to provide common methods to be used in Jwt unit testing classes.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class MockUtils {

    private MockUtils() {}

    /**
     * Mocks a {@link HofundJwkParseCacheLoader} with a {@link KeyPair}.
     *
     * @param keyPair   for mocking {@link HofundJwkParseCacheLoader}
     * @return          mocked HofundJwkParseCacheLoader with keyPair
     */
    public static HofundJwkParseCacheLoader mockedHofundkJwkParserCacheLoader(final KeyPair keyPair) throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        final HofundJwkParseCacheLoader hofundJwkParseCacheLoader = mock(HofundJwkParseCacheLoader.class);
        final RSAKey rsaKey = JwtUnitTestUtils.generateDefaultRsaKey(keyPair);
        when(hofundJwkParseCacheLoader.load(anyString())).thenReturn(rsaKey.toPublicKey());

        return hofundJwkParseCacheLoader;
    }

    /**
     * Mocks {@link HofundJwkParseCacheLoader}.
     *
     * @param publicKey to be retrieved from {@code cacheLoader} load.
     * @return          mocked {@link HofundJwkParseCacheLoader}
     */
    public static HofundJwkParseCacheLoader getCacheLoaderMock(final PublicKey publicKey) throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {

        final HofundJwkParseCacheLoader cacheLoader = mock(HofundJwkParseCacheLoader.class);
        when(cacheLoader.load(anyString())).thenReturn(publicKey);

        return cacheLoader;
    }
}
