package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.utils.JwtUnitTestUtils;
import br.com.wealthsystems.security.utils.MockUtils;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit test cases for {@link HofundPublicKeyCache}.
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class HofundPublicKeyCacheUnitTest {

    @Test
    public void extractPublicKeyForRealm() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {
        final String realm = "tenant";
        final PublicKey key = JwtUnitTestUtils.getPublicKey();
        final HofundPublicKeyCache loader = new HofundPublicKeyCache(MockUtils.getCacheLoaderMock(key));
        Assert.assertEquals(key, loader.getValue(realm));
    }

    @Test
    public void refreshMustReloadValueOnCache() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {

        final String realm = "tenant";
        final HofundJwkParseCacheLoader cacheLoader = MockUtils.getCacheLoaderMock(JwtUnitTestUtils.getPublicKey());
        final HofundPublicKeyCache loader = new HofundPublicKeyCache(cacheLoader);
        loader.refresh(realm);

        verify(cacheLoader, times(1)).load(anyString());
    }
}
