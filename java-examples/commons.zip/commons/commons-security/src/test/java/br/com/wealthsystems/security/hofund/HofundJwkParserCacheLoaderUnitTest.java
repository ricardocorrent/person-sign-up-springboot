package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.jwt.JwtAuthenticationFilter;
import br.com.wealthsystems.security.utils.ProtectedResource;
import br.com.wealthsystems.security.utils.UnprotectedResource;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.http.HttpStatus;
import org.apache.shiro.web.env.EnvironmentLoaderListener;
import org.apache.shiro.web.servlet.ShiroFilter;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.glassfish.jersey.test.DeploymentContext;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.ServletDeploymentContext;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.glassfish.jersey.test.spi.TestContainerException;
import org.glassfish.jersey.test.spi.TestContainerFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.secnod.shiro.jaxrs.ShiroExceptionMapper;
import org.secnod.shiro.jersey.AuthorizationFilterFeature;
import org.secnod.shiro.jersey.SubjectFactory;

import javax.ws.rs.core.Response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Unit test cases for {@link HofundJwkParseCacheLoader}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
@RunWith(CdiTestRunner.class)
public class HofundJwkParserCacheLoaderUnitTest extends JerseyTest {

    private static final String RESOURCE_UNPROTECTED = "unprotected";
    private static final String RESOURCE_PROTECTED = "protected";

    /**
     * Creates a servlet-based test container factory for creating test container instances using Grizzly.
     *
     * @return                          a container
     * @throws TestContainerException   if a container-specific error occurs
     */
    @Override
    protected TestContainerFactory getTestContainerFactory() throws TestContainerException {
        return new GrizzlyWebTestContainerFactory();
    }

    /**
     * Configures deployment of test container.
     *
     * @return a basic application deployment context
     */
    @Override
    protected DeploymentContext configureDeployment() {
        final ResourceConfig resourceConfig = new ResourceConfig(
                ProtectedResource.class,
                UnprotectedResource.class
        );

        resourceConfig.register(AuthorizationFilterFeature.class);
        resourceConfig.register(SubjectFactory.class);
        resourceConfig.register(ShiroExceptionMapper.class);
        resourceConfig.register(ShiroFilter.class)
                .property("url-pattern", "/*")
                .property("filter-name", "ShiroFilter");
        resourceConfig.register(JwtAuthenticationFilter.class);

        return ServletDeploymentContext
                .forServlet(new ServletContainer(resourceConfig))
                .addFilter(ShiroFilter.class, "ShiroFilter")
                .addListener(EnvironmentLoaderListener.class)
                .contextParam("shiroConfigLocations", "classpath:shiro.ini")
                .build();
    }

    /**
     * Validates behaviour when sending a request to a protected resource when authentication bearer is not provided.
     * Expects to throw an exception and return HTTP Status 500 (Internal Server Error).
     */
    @Test
    public void requestOnProtectedResourceDeniedOnAuthenticationBearerNotProvided() {

        final Response response = target(RESOURCE_PROTECTED)
                .request()
                .header("Authorization", "Bearer")
                .get();

        final String exception = response.readEntity(String.class);

        assertTrue(exception.contains("createToken method implementation returned null. A valid non-null AuthenticationToken " +
                "must be created in order to execute a login attempt."));
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, response.getStatus());
    }

}
