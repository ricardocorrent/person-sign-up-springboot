package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.SecurityProperties;
import br.com.wealthsystems.security.jwt.JwtAuthenticationToken;
import br.com.wealthsystems.security.shiro.ShiroAuthenticationToken;
import br.com.wealthsystems.security.utils.JwtUnitTestUtils;
import com.nimbusds.jose.JOSEException;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import javax.enterprise.inject.spi.CDI;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.generateKeyPair;
import static br.com.wealthsystems.security.utils.JwtUnitTestUtils.getExpiredTokenClaims;
import static br.com.wealthsystems.security.utils.MockUtils.mockedHofundkJwkParserCacheLoader;
import static org.junit.Assert.*;

/**
 * Unit test cases for {@link HofundAuthorizingRealm}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-10
 */
@RunWith(CdiTestRunner.class)
public class HofundAuthorizingRealmUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     *
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    /**
     * Validates if an {@link AuthenticationException} is thrown when getting authentication info with an expired token.
     * Expects to throw an {@link AuthenticationException}.
     *
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     * @throws IOException
     * @throws InvalidKeySpecException
     * @throws JOSEException
     */
    @Test
    public void doGetAuthenticationInfoWithExpiredTokenThrowsException() throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        thrown.expect(AuthenticationException.class);
        thrown.expectMessage("Token has expired");

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final HofundAuthorizingRealm realm = getRealm(keyPair);

        final ShiroAuthenticationToken token =
                new JwtAuthenticationToken(JwtUnitTestUtils.generateJwt(getExpiredTokenClaims(), keyPair));

        realm.doGetAuthenticationInfo(token);
    }

    /**
     * Validates if an {@link AuthenticationException} is thrown when getting authentication with an invalid token signature.
     * Expects to throw an {@link AuthenticationException}.
     */
    @Test
    public void doGetAuthenticationInfoWithInvalidSignatureThrowsException() throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        thrown.expect(AuthenticationException.class);
        thrown.expectMessage("Invalid token signature");

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final HofundAuthorizingRealm realm = getRealm(keyPair);

        final KeyPair newKeyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final JwtAuthenticationToken token =
                new JwtAuthenticationToken(JwtUnitTestUtils.generateJwt(getExpiredTokenClaims(), newKeyPair));

        realm.doGetAuthenticationInfo(token);
    }

    /**
     * Validates retrieval of authentication info with valid token signature.
     * Expects to retrieve information successfully.
     */
    @Test
    public void doGetAuthenticationInfoWithValidSignatureReturnsInfo() throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final HofundAuthorizingRealm realm = getRealm(keyPair);
        final JwtAuthenticationToken token =
                new JwtAuthenticationToken(JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair));

        final AuthenticationInfo info = realm.doGetAuthenticationInfo(token);
        assertNotNull(info);
    }

    /**
     * Success case for validation of authentication realm.
     * <p>Expects the submitted token instance of the class to be supported.</p>
     */
    @Test
    public void realmSupportsJwtAuthenticationTokens() throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final HofundAuthorizingRealm realm = getRealm(keyPair);
        final JwtAuthenticationToken token =
                new JwtAuthenticationToken(JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair));

        assertTrue(realm.supports(token));
    }

    /**
     * Validates if {@code subKey} is retrieved with success from realm.
     */
    @Test
    public void getAuthorizationCacheKeyMustReturnTokenSub() throws InvalidKeyException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, JOSEException {

        final KeyPair keyPair = JwtUnitTestUtils.generateKeyPair(1024);
        final HofundAuthorizingRealm realm = getRealm(keyPair);
        final JwtAuthenticationToken token =
                new JwtAuthenticationToken(JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims(), keyPair));

        final AuthenticationInfo info = realm.doGetAuthenticationInfo(token);
        final String subKey = (String) realm.getAuthorizationCacheKey(info.getPrincipals());

        assertEquals("Gandalf The White", subKey);
    }

    /**
     * Validates that wrong tokens are not supported by {@link HofundAuthorizingRealm}.
     */
    @Test
    public void realmDoNOTSupportsWrongTokens() {
        final HofundAuthorizingRealm realm = new HofundAuthorizingRealm();
        final UsernamePasswordToken token = new UsernamePasswordToken();
        assertFalse(realm.supports(token));
    }

    /**
     * Validates that {@code null} tokens are not supported by {@link HofundAuthorizingRealm}.
     */
    @Test
    public void realmDoNOTSupportsNullTokens() {
        final HofundAuthorizingRealm realm = new HofundAuthorizingRealm();
        assertFalse(realm.supports(null));
    }

    /**
     * Validates behaviour when getting authorization info with {@code null} principals information.
     * Expects to throw an {@link AuthorizationException}.
     */
    @Test(expected = AuthorizationException.class)
    public void doGetAuthorizationInfoMustNotAcceptNullPrincipals() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException, InvalidKeyException, JOSEException {
        final HofundAuthorizingRealm realm = getRealm(generateKeyPair(1024));
        realm.doGetAuthorizationInfo(null);
    }

    private HofundAuthorizingRealm getRealm(final KeyPair keyPair) throws InvalidKeySpecException, NoSuchAlgorithmException, JOSEException, InvalidKeyException, IOException {
        final HofundPublicKeyCache hofundJwkCache = new HofundPublicKeyCache(mockedHofundkJwkParserCacheLoader(keyPair));
        final SecurityProperties properties = CDI.current().select(SecurityProperties.class).get();
        return new HofundAuthorizingRealm(hofundJwkCache, properties);
    }
}
