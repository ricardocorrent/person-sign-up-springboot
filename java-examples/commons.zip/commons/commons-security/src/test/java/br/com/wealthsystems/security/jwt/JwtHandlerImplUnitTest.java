package br.com.wealthsystems.security.jwt;

import br.com.wealthsystems.security.utils.JwtUnitTestUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test cases for {@link JwtHandlerImpl}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-09
 */
public class JwtHandlerImplUnitTest {

    private final String stringToken = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims());

    /**
     * Validates if tenant name is retrieved correctly from the handler.
     * Expects to succeed.
     */
    @Test
    public void getTenantMustReturnRightString() {

        final JwtHandlerImpl handler = new JwtHandlerImpl();
        final String tenant = handler.getTenant(new JwtAuthenticationToken(stringToken));

        Assert.assertNotNull(tenant);
        Assert.assertEquals("public", tenant);

    }

}
