package br.com.wealthsystems.security.utils;

import org.apache.shiro.authz.annotation.RequiresPermissions;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * Protected resource class for authentication testing purposes.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2017-12-27
 */
@Path("/protected")
public class ProtectedResource {

    @GET
    @RequiresPermissions("commons:protected:read")
    public Response getProtectedResource() {
        return Response.ok().build();
    }
}
