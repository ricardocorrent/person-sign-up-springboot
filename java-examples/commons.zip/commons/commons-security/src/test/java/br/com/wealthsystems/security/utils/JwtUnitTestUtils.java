package br.com.wealthsystems.security.utils;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import sun.security.rsa.RSAPrivateCrtKeyImpl;
import sun.security.rsa.RSAPublicKeyImpl;

import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Date;

/**
 * Utility class that defines common methods to be used on Jwt unit testing classes.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-26
 */
public class JwtUnitTestUtils {

    private JwtUnitTestUtils() {}

    /**
     * Jwt generator.
     *
     * @param claims    to be set on generated JWT
     * @return          JWT as String
     */
    public static String generateJwt(final JWTClaimsSet claims) {
        return generateJwt(claims, generateKeyPair(1024));
    }

    /**
     * Jwt generator.
     *
     * @param claims    to be set on generated JWT
     * @param keyPair   to generate JWT, can be get from {@link #generateKeyPair(Integer)}
     * @return          JWT as String
     */
    public static String generateJwt(final JWTClaimsSet claims, final KeyPair keyPair) {

        final JWSSigner signer = new RSASSASigner(keyPair.getPrivate());
        final SignedJWT signedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.RS256), claims);

        try {
            signedJWT.sign(signer);
        } catch (JOSEException e) {
            e.printStackTrace();
        }

        return signedJWT.serialize();
    }

    /**
     * RSA key generator.
     *
     * @param keyPair               to generate RSAKey, can be get from {@link #generateKeyPair(Integer)}
     * @return                      RSAKey based on KeyPair
     * @throws InvalidKeyException  on generation error
     */
    public static RSAKey generateDefaultRsaKey(final KeyPair keyPair) throws InvalidKeyException {

        final RSAPublicKey publicKey  = new RSAPublicKeyImpl(keyPair.getPublic().getEncoded());
        final RSAPrivateKey privateKey = RSAPrivateCrtKeyImpl.newKey(keyPair.getPrivate().getEncoded());

        return new RSAKey.Builder(publicKey)
                .privateKey(privateKey)
                .algorithm(JWSAlgorithm.RS256)
                .keyID("keyId")
                .keyUse(KeyUse.SIGNATURE)
                .build();

    }

    /**
     * Builds a default {@link JWTClaimsSet} instance for testing purposes.
     *
     * @return JWT default claims for tests
     */
    public static JWTClaimsSet getDefaultClaims() {

        return new JWTClaimsSet.Builder()
                .subject("Gandalf The White")
                .issuer("https://middle-earth:8080/realm/tenant")
                .claim("typ", "Bearer")
                .claim("ten", "public")
                .jwtID("jwt-id")
                .expirationTime(new Date(new Date().getTime() + 60 * 1000))
                .build();

    }

    /**
     * Generates a public key.
     *
     * @return public key from {@link #generateKeyPair(Integer)}
     */
    public static PublicKey getPublicKey() {
        return generateKeyPair(1024).getPublic();
    }

    /**
     * Generates a {@link KeyPair}.
     *
     * @param keySize   KeyPair size
     * @return          a {@link KeyPair} based on keySize
     */
    public static KeyPair generateKeyPair(final Integer keySize) {
        final KeyPairGenerator keyGenerator;
        try {

            keyGenerator = KeyPairGenerator.getInstance("RSA");
            keyGenerator.initialize(keySize);
            return keyGenerator.genKeyPair();

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    /**
     * Builds a {@link JWTClaimsSet} with a past expiration time for testing purposes.
     *
     * @return expired JWT claim set
     */
    public static JWTClaimsSet getExpiredTokenClaims() {

        return new JWTClaimsSet.Builder()
                .subject("Gandalf The White")
                .issuer("https://middle-earth:8080/realm/tenant")
                .claim("typ", "Bearer")
                .claim("ten", "public")
                .expirationTime(new Date(new Date().getTime() - 60 * 1000))
                .build();
    }
}
