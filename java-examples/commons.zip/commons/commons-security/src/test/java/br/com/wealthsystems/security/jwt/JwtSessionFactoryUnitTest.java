package br.com.wealthsystems.security.jwt;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SessionContext;
import org.apache.shiro.web.session.mgt.DefaultWebSessionContext;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test cases for {@link JwtSessionFactory}.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtSessionFactoryUnitTest {

    /**
     * Validates if both {@link Session} and {@link SessionContext} (which is used to create the session with a constant id)
     * have the same id.
     * Expects to succeed.
     */
    @Test
    public void createSessionWithSessionContextIdMustReturnSessionWithId() {

        final JwtSessionFactory jwtSessionFactory = new JwtSessionFactory();

        final SessionContext sessionContext =  new DefaultWebSessionContext();
        sessionContext.setSessionId("id");
        final Session session = jwtSessionFactory.createSession(sessionContext);

        assertEquals("id", session.getId());
    }

}
