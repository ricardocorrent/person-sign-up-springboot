package br.com.wealthsystems.security.jwt;

import br.com.wealthsystems.security.utils.JwtUnitTestUtils;
import org.junit.Test;

import javax.servlet.http.HttpServletRequest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Unit test cases for {@link JwtUtils} class.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018/04/26
 */
public class JwtUtilsUnitTest {

    /**
     * Validates retrieval of a Jwt token from the current {@link HttpServletRequest}.
     * Expects to get the token successfully.
     */
    @Test
    public void getJwtFromValidRequestReturnsToken() {

        final HttpServletRequest request = mock(HttpServletRequest.class);
        final String generatedJwt = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims());

        when(request.getHeader("Authorization")).thenReturn("Bearer " + generatedJwt);

        final String rawToken = JwtUtils.getJwtTokenFromRequest(request);

        assertEquals(generatedJwt, rawToken);
    }

    /**
     * Validates retrieval of a token from a valid {@link HttpServletRequest} without having the Authorization header
     * in the request.
     * Expects to receive a null token.
     */
    @Test
    public void getJwtFromValidRequestButNoAuthorizationHeaderReturnsNull() {

        final HttpServletRequest request = mock(HttpServletRequest.class);
        final String rawToken = JwtUtils.getJwtTokenFromRequest(request);

        assertNull(rawToken);
    }

    /**
     * Validates retrieval of a token from a valid {@link HttpServletRequest} that has an Authorization header with wrong
     * prefix in the request.
     * Expects to receive a null token.
     */
    @Test
    public void getJwtFromValidRequestButWrongPrefixReturnsNull() {

        final HttpServletRequest request = mock(HttpServletRequest.class);
        final String generatedJwt = JwtUnitTestUtils.generateJwt(JwtUnitTestUtils.getDefaultClaims());
        when(request.getHeader("Authorization")).thenReturn("Bearer123 " + generatedJwt);
        final String rawToken = JwtUtils.getJwtTokenFromRequest(request);

        assertNull(rawToken);
    }

}
