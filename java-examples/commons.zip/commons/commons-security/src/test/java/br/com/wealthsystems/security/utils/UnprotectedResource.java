package br.com.wealthsystems.security.utils;

import javax.ws.rs.Path;

/**
 * Unprotected resource class for authentication testing purposes.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2017-12-27
 */
@Path("/unprotected")
public class UnprotectedResource {
}
