package br.com.wealthsystems.security.jwt;

import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.session.mgt.SessionKey;

/**
 * Jwt handler interface, used to retrieve information about the current session.
 *
 * @author  Ivan A. Reffatti
 * @see     JwtHandlerImpl
 * @since   6.0.0 - 2018-04-06
 */
public interface JwtHandler {

    /**
     * @param token token for tenant to be extracted
     * @return      tenant
     */
    String getTenant(AuthenticationToken token);

    /**
     * @param sessionKey session key for accessing subject
     * @return           the subject's String
     */
    String getSubject(SessionKey sessionKey);

}
