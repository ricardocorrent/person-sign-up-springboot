package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.SecurityProperties;
import br.com.wealthsystems.security.jwt.JwtConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.cache.CacheLoader;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.http.HttpStatus;
import org.apache.shiro.codec.Base64;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;

/**
 * Handler for client information and security public key retrieval.
 *
 * @author  Ivan A. Reffatti
 * @see     CacheLoader
 * @since   6.0.0 2018-04-06
 */
public class HofundJwkParseCacheLoader extends CacheLoader<String, PublicKey> {

    /**
     * Loads client information and returns the public key.
     *
     * @param tenant    user tenant
     * @return          a "RSA" public key
     * @see             CacheLoader#load(Object)
     */
    @Override
    public PublicKey load(final String tenant) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

        final Client client = ClientBuilder.newClient();
        final HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(getClientId(), getClientSecret());
        client.register(feature);

        final Response jwkResponse = client
                .register(feature)
                .target(getPublicKeyAddress() + getJwkResource())
                .request(MediaType.APPLICATION_JSON)
                .header("Domain", tenant)
                .get();

        if (jwkResponse.getStatus() == HttpStatus.SC_OK) {
            final String jwkString = jwkResponse.readEntity(String.class);
            final Map<String, String> key = new ObjectMapper().readValue(jwkString, Map.class);
            final String formatted = key.get("value")
                                        .replaceAll("\\n", StringUtils.EMPTY)
                                        .replace("-----BEGIN PUBLIC KEY-----", StringUtils.EMPTY)
                                        .replace("-----END PUBLIC KEY-----", StringUtils.EMPTY);

            byte[] data = Base64.decode(formatted.getBytes());
            final X509EncodedKeySpec spec = new X509EncodedKeySpec(data);
            final KeyFactory kf = KeyFactory.getInstance(JwtConstants.RSA_ALGORITHM);
            return kf.generatePublic(spec);
        }

        throw new InvalidCacheLoadException("Could not call jwk server while loading cache");
    }

    /**
     * Retrieves client ID from {@link SecurityProperties}.
     *
     * @author Ivan A. Reffatti
     * @return client ID according to {@link SecurityProperties#CLIENT_ID}
     */
    protected String getClientId() {
        return ConfigResolver
                .resolve(SecurityProperties.CLIENT_ID)
                .getValue();
    }

    /**
     * Retrieves client secret from {@link SecurityProperties}, using client secret.
     *
     * @return client Secret according to {@link SecurityProperties#CLIENT_SECRET}
     */
    protected String getClientSecret() {
        return ConfigResolver
                .resolve(SecurityProperties.CLIENT_SECRET)
                .getValue();
    }

    /**
     * Retrieves client secret from {@link SecurityProperties}, using key address.
     *
     * @return client Secret according to {@link SecurityProperties#SERVER_PUBLICK_KEY_ADDRESS}
     */
    protected String getPublicKeyAddress() {
        return ConfigResolver
                .resolve(SecurityProperties.SERVER_PUBLICK_KEY_ADDRESS)
                .getValue();
    }

    /**
     * Retrieves client secret from {@link SecurityProperties}, using key resource.
     *
     * @return client Secret according to {@link SecurityProperties#SERVER_PUBLIC_KEY_RESOURCE}
     */
    protected String getJwkResource() {
        return ConfigResolver
                .resolve(SecurityProperties.SERVER_PUBLIC_KEY_RESOURCE)
                .getValue();
    }
}
