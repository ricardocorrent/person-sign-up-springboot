package br.com.wealthsystems.security.exception;

/**
 * This exception class is meant to be thrown on JWT token expiration validations.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-11
 */
public class JwtExpiredException extends JwtException {

    /**
     * @param message   the exception message
     * @param cause     the exception cause
     * @see             JwtException#JwtException(String, Throwable)
     */
    public JwtExpiredException(String message, Throwable cause) {
        super(message, cause);
    }
}
