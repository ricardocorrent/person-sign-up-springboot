package br.com.wealthsystems.security.jwt;

import br.com.wealthsystems.security.exception.JwtException;
import br.com.wealthsystems.security.exception.JwtExpiredException;
import br.com.wealthsystems.security.exception.JwtInvalidSignatureJwtException;
import br.com.wealthsystems.security.shiro.ShiroAuthenticationToken;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import org.apache.shiro.authc.AuthenticationException;

import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Objects;

/**
 * Implementation of {@link ShiroAuthenticationToken}.
 * <p>This class is responsible to process and verify an authentication token and retrieve its information as well.</p>
 *
 * @author  Ivan A. Reffatti
 * @see     ShiroAuthenticationToken
 * @since   6.0.0 - 2018-04-06
 */
public class JwtAuthenticationToken implements ShiroAuthenticationToken {

    private final String rawToken;

    /**
     * Custom constructor for setting token as {@link String}.
     *
     * @param rawToken jwt encoded raw token
     */
    public JwtAuthenticationToken(final String rawToken) {
        this.rawToken = rawToken;
    }

    /**
     * Verifies token validity according to it's expiring time, signature and parsing.
     *
     * @param publicKey     public key provided by PublicKeyCache implementation
     * @see                 ShiroAuthenticationToken#verify(PublicKey)
     * @throws JwtException as it's extensions according to errors @{@link JwtExpiredException}, {@link JwtInvalidSignatureJwtException}
     */
    @Override
    public void verify(final PublicKey publicKey) throws JwtException {
        Objects.requireNonNull(publicKey, "publicKey must not be null");

        try {
            final DefaultJWTProcessor jwtProcessor = new DefaultJWTProcessor();
            final RSAKey key = new RSAKey.
                    Builder((RSAPublicKey) publicKey)
                    .build();
            final JWKSource keySource = new ImmutableJWKSet(new JWKSet(key));
            final JWSAlgorithm expectedJWSAlg = JWSAlgorithm.RS256;
            final JWSVerificationKeySelector keySelector = new JWSVerificationKeySelector(expectedJWSAlg, keySource);
            jwtProcessor.setJWSKeySelector(keySelector);
            jwtProcessor.process((String) getPrincipal(), null);

        } catch (final BadJOSEException e) {
            // FIXME on internal requests, expiration should not be validated, leaving it to the Gateway
            // #42317 https://redmineproduto.wssim.com.br/issues/42317
            if (e.getMessage().contains("Expired JWT")) {
                throw new JwtExpiredException(e.getMessage(), e);
            }
            if (e.getMessage().contains("Invalid signature")) {
                throw new JwtInvalidSignatureJwtException(e.getMessage(), e);
            }
            throw new AuthenticationException("Unknown JWT validation error");
        } catch (final JOSEException e) {
            throw new JwtException("Due to unknown errors, the JWT could notbe vefied", e);
        } catch (final ParseException e) {
            throw new JwtException("Could not parse JWT", e);
        }
    }

    /**
     * Returns a {@link Payload} of the token object.
     *
     * @return parsing it from String token provided on constructor
     * */
    @Override
    public Payload getToken() {
        try {
            return JWSObject.parse(rawToken).getPayload();
        } catch (ParseException e) {
            throw new IllegalArgumentException("Could not get JWT payload");
        }
    }

    /**
     * @return JWT as rawToken
     */
    @Override
    public Object getPrincipal() {
        return rawToken;
    }

    /**
     * As we are working with JWT, it is both the credential and principal from user.
     *
     * @return jwt as rawToken
     */
    @Override
    public Object getCredentials() {
        return getPrincipal();
    }
}
