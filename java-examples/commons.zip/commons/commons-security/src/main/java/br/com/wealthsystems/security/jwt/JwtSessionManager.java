package br.com.wealthsystems.security.jwt;

import org.apache.shiro.session.mgt.DefaultSessionManager;
import org.apache.shiro.session.mgt.SessionKey;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * Shiro's session manager to extract ID from JWT, using it to identify user session on any needed session
 * database.
 *
 * @author  Ivan A. Reffati
 * @since   6.0.0 2018-04-26
 * */
public class JwtSessionManager extends DefaultSessionManager {

    private final JwtHandler handler;

    public JwtSessionManager() {
        this.handler = new JwtHandlerImpl();
    }

    /**
     * Gets sessionId from JWT token on {@link HttpServletRequest} header. May return null if no token is provided.
     *
     * @see DefaultSessionManager#getSessionId(SessionKey)
     */
    @Override
    protected Serializable getSessionId(final SessionKey sessionKey) {
        return handler.getSubject(sessionKey);
    }
}
