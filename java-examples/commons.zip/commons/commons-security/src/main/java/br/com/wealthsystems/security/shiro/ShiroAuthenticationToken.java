package br.com.wealthsystems.security.shiro;

import br.com.wealthsystems.security.exception.JwtException;
import org.apache.shiro.authc.AuthenticationToken;

import java.security.PublicKey;

/**
 * Shiro's authentication token interface.
 * <p>Provides overridable method for public key verification.</p>
 *
 * @author Ivan A. Reffatti
 * @since 6.0.0 - 2018-04-06
 */
public interface ShiroAuthenticationToken extends AuthenticationToken {

    /**
     * Verifies if token is valid according to provided public key.
     *
     * @param publicKey     the public key
     * @throws JwtException if an error occurs
     * */
    void verify (final PublicKey publicKey) throws JwtException;


    /**
     * Returns created token.
     *
     * @return the token
     */
    Object getToken();
}
