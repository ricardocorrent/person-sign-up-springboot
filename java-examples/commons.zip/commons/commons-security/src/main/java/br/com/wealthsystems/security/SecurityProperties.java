package br.com.wealthsystems.security;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * Commons security specific properties.
 *
 * <p>These properties can be set through apache-deltaspike.properties configuration {@link ConfigProperty}</p>
 * <p>For more information about its configuration properties values, please consult the
 * <a href="https://gitlab.wssim.com.br/platform/commons/blob/master/README.md#39-autentica%C3%A7%C3%A3oautoriza%C3%A7%C3%A3o-via-jwt">
 * README</a>
 * </p>
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 2018-04-25
 */
public class SecurityProperties {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityProperties.class);
    private static final String AND = " and ";
    private static final String MUST_BE_PROVIDED = " must be provided";

    /**
     * Address to get public keys to check the JWS.
     */
    public static final String SERVER_PUBLICK_KEY_ADDRESS = "security.oauth2.server.publicKeyAddress";
    /**
     * URI be used with {@link #SERVER_PUBLICK_KEY_ADDRESS} to get public keys to check the JWS.
     */
    public static final String SERVER_PUBLIC_KEY_RESOURCE = "security.oauth2.server.publicKeyResource";
    /**
     * Address to get user permissions if present.
     */
    public static final String SERVER_AUTHORIZATION_ADDRESS = "security.oauth2.server.authorizationAddress";
    /**
     * URI to be used with {@link #SERVER_AUTHORIZATION_ADDRESS} and load user authorizations.
     */
    public static final String SERVER_AUTHORIZATION_RESOURCE = "security.oauth2.server.authorizationResource";
    /**
     * Oauth server client id.
     */
    public static final String CLIENT_ID = "security.oauth2.client.clientId";
    /**
     * Oauth server client secret.
     */
    public static final String CLIENT_SECRET = "security.oauth2.client.clientSecret";
    /**
     * Oauth server client secret.
     */
    public static final String SHIRO_REDIS_KEY = "security.oauth2.client.shiroRedisKey";

    @Inject
    @ConfigProperty(name = CLIENT_ID)
    private String clientId;

    @Inject
    @ConfigProperty(name = CLIENT_SECRET)
    private String clientSecret;

    @Inject
    @ConfigProperty(name = SERVER_PUBLICK_KEY_ADDRESS)
    private String jwkAddress;

    @Inject
    @ConfigProperty(name = SERVER_PUBLIC_KEY_RESOURCE, defaultValue = "/oauth/token_key")
    private String jwkResource;

    @Inject
    @ConfigProperty(name = SERVER_AUTHORIZATION_ADDRESS)
    private String authorizationAddress;

    @Inject
    @ConfigProperty(name = SERVER_AUTHORIZATION_RESOURCE)
    private String authorizationResource;

    @Inject
    @ConfigProperty(name = SHIRO_REDIS_KEY)
    private String shiroRedisKey;

    public String clientId() {
        return clientId;
    }

    public String clientSecret() {
        return clientSecret;
    }

    public String publicKeyAddress() {
        return jwkAddress;
    }

    public String publicKeyResource() {
        return jwkResource;
    }

    public String authorizationAddress() {
        return authorizationAddress;
    }

    public String authorizationResource() {
        return authorizationResource;
    }

    public String getShiroRedisKey() {
        return shiroRedisKey;
    }

    @PostConstruct
    public void validate() {
        validateClientIdAndClientSecretMustBeProvided();
        validateKeyAddressAndKeyResourceMustBeProvided();
        warnAboutAuthorizationConfigs();
    }

    private void validateClientIdAndClientSecretMustBeProvided() {
        if ( isBlank(clientId()) || isBlank(clientSecret()) ) {
            throw new IllegalStateException(CLIENT_ID + AND + CLIENT_SECRET + MUST_BE_PROVIDED);
        }
    }

    private void validateKeyAddressAndKeyResourceMustBeProvided() {
        if (isBlank(publicKeyAddress()) || isBlank(publicKeyResource())) {
            throw new IllegalStateException(SERVER_PUBLICK_KEY_ADDRESS + AND + SERVER_PUBLIC_KEY_RESOURCE + MUST_BE_PROVIDED);
        }
    }

    private void warnAboutAuthorizationConfigs() {
        if (isBlank(authorizationAddress()) || isBlank(authorizationResource())) {
            LOGGER.warn(SERVER_AUTHORIZATION_ADDRESS, " or ", SERVER_AUTHORIZATION_RESOURCE, " not set");
        }
    }

}
