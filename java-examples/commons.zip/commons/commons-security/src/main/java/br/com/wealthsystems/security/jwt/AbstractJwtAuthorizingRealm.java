package br.com.wealthsystems.security.jwt;

import br.com.wealthsystems.security.shiro.ShiroAuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import br.com.wealthsystems.security.hofund.HofundAuthorizingRealm;

/**
 * Abstract class that represents Shiro JWT Realm to be implemented.
 *
 * <p>This class is used by {@link HofundAuthorizingRealm} to handle possible problems during
 * a session with a provided token.</p>
 *
 * <pre>
 *      {@literal @Override}
 *       protected SimpleAuthenticationInfo onJwtInvalidSignature(String, ShiroAuthenticationToken) {
 *           // Jwt verifications
 *       }
 * </pre>
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 2018-04-11
 * @see     HofundAuthorizingRealm for current implementations
 */
public abstract class AbstractJwtAuthorizingRealm extends AuthorizingRealm {

    /**
     * Handler for invalid signature on JWT.
     *
     * @param tenant    user tenant on JWT
     * @param token     validated token
     * @return          a possible SimpleAuthenticationInfo on Jwt Invalid Signature
     */
    protected abstract SimpleAuthenticationInfo onJwtInvalidSignature(final String tenant,
                                                             final ShiroAuthenticationToken token);

    /**
     * Handler for expiration on JWT.
     *
     * @param tenant    user tenant on JWT
     * @param token     validated token
     * @return          a possible SimpleAuthenticationInfo on Jwt Expired
     */
    protected abstract SimpleAuthenticationInfo onJwtExpired(final String tenant,
                                                    final ShiroAuthenticationToken token);

    /**
     * Handler for unknown errors on JWT.
     *
     * @param tenant    user tenant on JWT
     * @param token     validated token
     * @return          a possible SimpleAuthenticationInfo on any Unknown Error
     */
    protected abstract SimpleAuthenticationInfo onUnknownError(final String tenant,
                                                               final ShiroAuthenticationToken token);

}
