package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.jwk.AbstractPublicKeyCache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import java.security.PublicKey;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Cache for {@link PublicKey} avoiding the service on requesting authentication server on every request that must be authenticated.
 * <p>Also this provides a better security as if some key leaks, there is no need to make a full revoke on all realms.</p>
 *
 * @author  Ivan A. Reffatti
 * @see     AbstractPublicKeyCache
 * @since   6.0.0 2018-04-06
 */
public class HofundPublicKeyCache extends AbstractPublicKeyCache<String, PublicKey> {

    private LoadingCache<String, PublicKey> cache;

    HofundPublicKeyCache(final CacheLoader<String, PublicKey> cacheImpl) {
        super(cacheImpl);
    }

    /**
     * @param key   from which one key must be extracted
     * @return      the public key
     * @see         AbstractPublicKeyCache#getValue(String)
     */
    @Override
    public PublicKey getValue(final String key) {

        try {
            return getCache().get(key);
        } catch (ExecutionException e) {
            throw new IllegalStateException("Could not read value from cache with provided key " + key, e);
        }
    }

    /**
     * Refreshes cache.
     *
     * @author      Ivan A. Reffatti
     * @param key   key for cache to be refreshed
     * @see         AbstractPublicKeyCache#refresh(String)
     */
    @Override
    public void refresh(final String key) {
        getCache().refresh(key);
    }

    /**
     * Caches initialization and access.
     *
     * @author  Ivan A. Reffatti
     * @return  the cache var
     * @see     AbstractPublicKeyCache#getCache()
     */
    @Override
    public LoadingCache<String, PublicKey> getCache() {
        return Optional
                .ofNullable(cache)
                .orElseGet(() ->
                        cache = CacheBuilder
                                .newBuilder()
                                .maximumSize(500)
                                .expireAfterAccess(1, TimeUnit.DAYS)
                                .build(getCacheImpl())
                );
    }
}
