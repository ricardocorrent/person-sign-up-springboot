package br.com.wealthsystems.security.exception;

/**
 * Exception class to be used on JWT signature validations.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 2018-04-11
 */
public class JwtInvalidSignatureJwtException extends JwtException {

    /**
     * @param message   the exception message
     * @param cause     the exception cause
     * @see             JwtException#JwtException(String, Throwable)
     */
    public JwtInvalidSignatureJwtException(String message, Throwable cause) {
        super(message, cause);
    }
}
