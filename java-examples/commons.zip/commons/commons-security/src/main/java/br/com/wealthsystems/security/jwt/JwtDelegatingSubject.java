package br.com.wealthsystems.security.jwt;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SessionContext;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.web.subject.support.WebDelegatingSubject;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.Serializable;

/**
 * Implementation needed to set session context custom ID as user {@link JwtConstants#SUBJECT} on JWT.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 2018-04-12
 */
public class JwtDelegatingSubject extends WebDelegatingSubject {

    /**
     * Constructor with parent parameters initialization.
     *
     * @see WebDelegatingSubject#WebDelegatingSubject(PrincipalCollection, boolean, String, Session, boolean, ServletRequest, ServletResponse, SecurityManager)
     */
    public JwtDelegatingSubject(PrincipalCollection principals,
                                boolean authenticated,
                                String host,
                                Session session,
                                boolean sessionEnabled,
                                ServletRequest request,
                                ServletResponse response,
                                SecurityManager securityManager) {
        super(principals, authenticated, host, session, sessionEnabled, request, response, securityManager);
    }

    /**
     * Sets session id as JWT {@link JwtConstants#SUBJECT} (commonly user id).
     */
    @Override
    protected SessionContext createSessionContext() {
        final SessionContext context = super.createSessionContext();
        context.setSessionId((Serializable) new JwtAuthenticationToken((String) this.getPrincipal()).getToken().toJSONObject().get(JwtConstants.SUBJECT));
        return context;
    }
}
