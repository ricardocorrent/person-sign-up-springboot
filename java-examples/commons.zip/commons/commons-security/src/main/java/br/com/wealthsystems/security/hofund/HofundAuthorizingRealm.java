package br.com.wealthsystems.security.hofund;

import br.com.wealthsystems.security.SecurityProperties;
import br.com.wealthsystems.security.exception.JwtException;
import br.com.wealthsystems.security.exception.JwtExpiredException;
import br.com.wealthsystems.security.exception.JwtInvalidSignatureJwtException;
import br.com.wealthsystems.security.jwk.AbstractPublicKeyCache;
import br.com.wealthsystems.security.jwt.*;
import br.com.wealthsystems.security.shiro.ShiroAuthenticationToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.cache.CacheLoader;
import net.minidev.json.JSONObject;
import org.apache.http.HttpStatus;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.slf4j.Logger;

import javax.enterprise.inject.spi.CDI;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.MalformedURLException;
import java.security.PublicKey;
import java.util.Objects;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * {@link AbstractJwtAuthorizingRealm} implementation focused on providing multi tenant authentication, authorization and JWT
 * validations based on Hofund authentication/authorization service.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-06
 */
public class HofundAuthorizingRealm extends AbstractJwtAuthorizingRealm {

    private final SecurityProperties securityProperties;
    private final AbstractPublicKeyCache<String, PublicKey> jwkCache;
    private final JwtHandler jwtHandler;

    private static final Logger LOGGER = getLogger(HofundAuthorizingRealm.class);

    public HofundAuthorizingRealm() {
        this(new HofundPublicKeyCache(new HofundJwkParseCacheLoader()), new JwtHandlerImpl(), CDI.current().select(SecurityProperties.class).get());
    }

    /**
     * @param <T>           generic object type
     * @param jwkCache      AbstractPublicKeyCache implementation
     * @param properties    {@link SecurityProperties}
     */
    public <T extends AbstractPublicKeyCache> HofundAuthorizingRealm(final T jwkCache, final SecurityProperties properties) {
        this(jwkCache, new JwtHandlerImpl(), properties);
    }

    /**
     * Constructor with {@link CacheLoader}, giving the freedom to pass any kind of loading for keycloak permissions.
     *
     * @param <T>           {@link AbstractPublicKeyCache}
     * @param jwkCache      the jwt cache
     * @param jwtHandler    {@link JwtHandler}
     * @param properties    {@link SecurityProperties}
     * */
    public <T extends AbstractPublicKeyCache> HofundAuthorizingRealm(final T jwkCache, final JwtHandler jwtHandler, final SecurityProperties properties) {
        Objects.requireNonNull(jwkCache, "jwkcache cannot be null");
        Objects.requireNonNull(jwtHandler, "jwtHandler cannot be null");
        Objects.requireNonNull(properties, "properties cannot be null");

        this.securityProperties = properties;
        this.jwkCache = jwkCache;
        this.jwtHandler = jwtHandler;
    }

    /**
     * Verifies if authentication realm can process the submitted token instance of the class.
     * <p>Authentication valid only on {@link JwtAuthenticationToken}.</p>
     *
     * @see AuthenticatingRealm#supports(AuthenticationToken)
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof JwtAuthenticationToken;
    }

    /**
     * Validates user authentication based on user provided Authorization Bearer token.
     *
     * @see AuthenticatingRealm#doGetAuthenticationInfo(AuthenticationToken)
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(final AuthenticationToken token) {

        final ShiroAuthenticationToken authenticationToken = (ShiroAuthenticationToken) token;
        final String tenant = getTenant(authenticationToken);

        SimpleAuthenticationInfo info;
        try {

            authenticationToken.verify(jwkCache.getValue(tenant));
            info = new SimpleAuthenticationInfo(token.getPrincipal(), token.getCredentials(), tenant);

        } catch (final JwtExpiredException jwtee ) {

            info = onJwtExpired(tenant, authenticationToken);
            LOGGER.debug("Token signature is invalid, application will try to reload from server and check again.", jwtee);

        } catch(final JwtInvalidSignatureJwtException jwte) {

            // if signature is invalid, maybe we should update our local cache for renewing all sessions accordingly
            LOGGER.debug("Token signature is invalid, application will try to reload from server and check again.", jwte);
            info = onJwtInvalidSignature(tenant, authenticationToken);

        } catch (final JwtException jwte) {
            LOGGER.warn("Unknown error", jwte);
            info = onUnknownError(tenant, authenticationToken);
        }

        return info;
    }

    /**
     * According to principals, check user authorizations, for customizations on authorization loading, see
     * {@link #getSimpleAuthorizationInfo}.
     *
     * @see AuthorizingRealm#doGetAuthorizationInfo(PrincipalCollection)
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {

        if (principals == null) {
            throw new AuthorizationException("PrincipalCollection method argument cannot be null.");
        }

        try {
            final JwtAuthenticationToken token = new JwtAuthenticationToken((String) principals.getPrimaryPrincipal());
            return getSimpleAuthorizationInfo(token);
        } catch (final IOException e) {
            LOGGER.error(e.getMessage());
            throw new AuthorizationException("Error on converting user permissions, verify if the source " +
                    "and destination are reading/writing the correct values.", e);
        }
    }

    /**
     * <p>
     * Tries to get {@link SimpleAuthorizationInfo} via REST API.
     * Override this method if wanting to provide a custom way to get {@link SimpleAuthorizationInfo}.
     * </p>
     *
     * @param token         {@link JwtAuthenticationToken} as {@link ShiroAuthenticationToken} implementation
     * @return              user authorization
     * @throws IOException  if it fails to load authorization info from the cache
     * */
    protected SimpleAuthorizationInfo getSimpleAuthorizationInfo(final JwtAuthenticationToken token) throws IOException {

        final Client client = ClientBuilder.newClient();

        final Response response = client
                .target(getPermissionsApiAddress())
                .request(MediaType.APPLICATION_JSON)
                .header("Domain", getTenant(token))
                .header("Authorization", "Bearer " + token.getPrincipal())
                .get();

        if (response != null && response.getStatus() == HttpStatus.SC_OK) {
            return new ObjectMapper().readValue(response.readEntity(String.class), SimpleAuthorizationInfo.class);
        }

        throw new AuthorizationException("Could not load authorization info from cache, neither from source." +
                "User may have obtained access without authenticating or application is having problems to load" +
                " authorization info.");
    }

    /**
     * Returns JWT sub as cache key.
     *
     * @param principals    for accessing {@link br.com.wealthsystems.security.jwt.JwtConstants#SUBJECT} property
     * @return              shiro cache key
     */
    @Override
    protected Object getAuthorizationCacheKey(PrincipalCollection principals) {

        final JSONObject jsonObject = new JwtAuthenticationToken((String) principals
                                            .getPrimaryPrincipal())
                                            .getToken()
                                            .toJSONObject();

        return jsonObject != null ? jsonObject.getAsString(JwtConstants.SUBJECT): null;
    }

    /**
     * Customize this method to override behaviour on JWT invalid signature validation.
     *
     * @param tenant    tenant to be verified on access
     * @param token     token to be re-validated
     * @see             AbstractJwtAuthorizingRealm#onJwtInvalidSignature(String, ShiroAuthenticationToken)
     * @return          if everything occurs right
     */
    @Override
    protected SimpleAuthenticationInfo onJwtInvalidSignature(final String tenant,
                                                             final ShiroAuthenticationToken token) {
        jwkCache.refresh(tenant);

        final SimplePrincipalCollection principals = new SimplePrincipalCollection();
        principals.add(token.getPrincipal(), tenant);
        doClearCache(principals);
        try {

            token.verify(jwkCache.getValue(tenant));
            return new SimpleAuthenticationInfo(token.getPrincipal(), token.getPrincipal(), tenant);

        } catch (final JwtException jw) {
            // ok, no way, the signature is really invalid.
            throw new AuthenticationException("Invalid token signature", jw);
        }
    }

    /**
     * Customize this method to override behaviour on JWT expiration validate.
     *
     * @param tenant    tenant to be verified on access
     * @param token     token to be re-validated
     * @see             AbstractJwtAuthorizingRealm#onJwtExpired(String, ShiroAuthenticationToken)
     * @throws          AuthenticationException as it is intended to be
     */
    @Override
    protected SimpleAuthenticationInfo onJwtExpired(final String tenant,
                                                    final ShiroAuthenticationToken token) {
        throw new AuthenticationException("Token has expired");
    }

    /**
     * Customize this method to override behaviour on JWT unknown errors.
     *
     * @param tenant    tenant to be verified on access
     * @param token     token to be re-validated
     * @see             AbstractJwtAuthorizingRealm#onUnknownError(String, ShiroAuthenticationToken)
     * @throws          AuthenticationException as it is intended to be
     */
    @Override
    protected SimpleAuthenticationInfo onUnknownError(final String tenant,
                                                      final ShiroAuthenticationToken token) {
        throw new AuthenticationException("Could not read JWT token");
    }

    /**
     * <p>Override this to provide a customized API address</p>
     * <p>Loads URL from authorization.service.api property</p>
     *
     * @return                          shiro configured permissions api URI
     * @throws MalformedURLException    if provided malformed URL
     * */
    protected String getPermissionsApiAddress() throws MalformedURLException {

        final String authorizationAddress = securityProperties.authorizationAddress();
        if (authorizationAddress.startsWith("http")) {
            return authorizationAddress + securityProperties.authorizationResource();
        }

        throw new MalformedURLException("If not using any Service Discovery or DNS, full service URL must be provided.");
    }

    /**
     * Must return tenant as String
     *
     * @param token {@link ShiroAuthenticationToken}
     * @return      "ten" claim from JWT to get tenant
     */
    protected String getTenant(final ShiroAuthenticationToken token) {
        return jwtHandler.getTenant(token);
    }

    /**
     * @return constructor provided {@link SecurityProperties}
     */
    public SecurityProperties getSecurityProperties() {
        return securityProperties;
    }
}
