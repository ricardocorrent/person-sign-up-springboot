package br.com.wealthsystems.security.jwk;

import com.google.common.cache.LoadingCache;

/**
 * {@link PublicKeyCache} interface.
 *
 * <b>This interface defines methods that needs implementation to deal with public key retrieval.</b>
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-25
 * */
public interface PublicKeyCache<K extends String, V> {

    /**
     * Gets cache value.
     *
     * @return      contained on JWK
     * @param key   from which one key must be extracted
     * */
    V getValue(final String key);

    /**
     * Must force refresh of cache for specified realm.
     *
     * @param key key for cache to be refreshed
     * */
    void refresh(final String key);

    /**
     * @return a {@link LoadingCache} instance
     * */
    LoadingCache<K, V> getCache();
}
