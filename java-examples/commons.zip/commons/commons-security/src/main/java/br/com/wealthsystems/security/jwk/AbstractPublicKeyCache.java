package br.com.wealthsystems.security.jwk;

import com.google.common.cache.CacheLoader;

/**
 * Abstract class with specification to handle {@link CacheLoader} operations.
 * <p>Implementation must provide a cache to return public keys.</p>
 *
 * @author  Ivan A. Reffatti
 * @since   2018-04-25
 */
public abstract class AbstractPublicKeyCache<K extends String, V> implements PublicKeyCache<K, V> {

    private final CacheLoader<K, V> cacheImpl;

    /**
     * Constructor with {@link CacheLoader} initialization.
     *
     * @param cacheImpl a {@link CacheLoader} implementation that provides the PublicKey
     */
    public AbstractPublicKeyCache(CacheLoader<K, V> cacheImpl) {
        this.cacheImpl = cacheImpl;
    }

    /**
     * @return public key cache
     */
    protected CacheLoader<K, V> getCacheImpl() {
        return this.cacheImpl;
    }

}
