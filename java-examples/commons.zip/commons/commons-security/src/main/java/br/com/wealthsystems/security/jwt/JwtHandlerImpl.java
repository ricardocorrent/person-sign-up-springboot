package br.com.wealthsystems.security.jwt;

import com.nimbusds.jose.JWSObject;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.session.mgt.SessionKey;
import org.apache.shiro.web.session.mgt.WebSessionKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;

/**
 * Handler facilitator for JWT Tokens.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-06
 */
public class JwtHandlerImpl implements JwtHandler {

    private final Logger logger = LoggerFactory.getLogger(JwtHandlerImpl.class);

    /**
     * Gets principal token and tries to extract the tenant as String.
     *
     * @param token token for tenant to be extracted
     * @return      tenant as String or NULL
     * @see         JwtHandler#getTenant(AuthenticationToken)
     */
    @Override
    public String getTenant(final AuthenticationToken token) {

        try {
            final String rawToken = (String) token.getPrincipal();
            return JWSObject.parse(rawToken).getPayload().toJSONObject().getAsString("ten");

        } catch (ParseException e) {
            logger.error("Could not extract tenant from JWT", e);
        }
        return null;
    }

    /**
     * Based on sessionKey, tries to get the user id based on {@link JwtConstants#SUBJECT}.
     *
     * @see                 JwtHandler#getSubject(SessionKey)
     * @param sessionKey    session key for accessing subect
     * @return              subject as String
     */
    @Override
    public String getSubject(final SessionKey sessionKey) {

        String subject = null;

        if (sessionKey instanceof WebSessionKey) {
            final WebSessionKey webSessionKey = (WebSessionKey) sessionKey;
            final HttpServletRequest httpRequest = (HttpServletRequest) webSessionKey.getServletRequest();
            final String rawToken = JwtUtils.getJwtTokenFromRequest(httpRequest);

            if ( rawToken != null ) {
                try {
                    subject = JWSObject.parse(rawToken).getPayload().toJSONObject().getAsString(JwtConstants.SUBJECT);
                } catch (final ParseException e) {
                    logger.error("Could not extract subject from JWT", e);
                }
            }
        } else {
            subject = sessionKey != null && sessionKey.getSessionId() != null ? sessionKey.getSessionId().toString() : null;
        }
        return subject;
    }
}
