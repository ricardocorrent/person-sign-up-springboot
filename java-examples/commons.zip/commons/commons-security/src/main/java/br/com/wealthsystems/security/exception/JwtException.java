package br.com.wealthsystems.security.exception;

/**
 * JWT exception class to be used to encapsulate thrown exceptions on JWT generic validations.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 2018-04-17
 */
public class JwtException extends Exception {

    /**
     * @see Exception#Exception()
     */
    public JwtException() {
    }

    /**
     * @param message   the exception message
     * @param cause     the exception cause
     * @see             Exception#Exception(String, Throwable)
     */
    public JwtException(String message, Throwable cause) {
        super(message, cause);
    }
}
