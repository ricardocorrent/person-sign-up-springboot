package br.com.wealthsystems.security.jwt;

import com.ws.shiro.RedisProperties;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.shiro.session.Session;
import org.crazycake.shiro.RedisSessionDAO;
import org.crazycake.shiro.exception.SerializationException;
import org.crazycake.shiro.serializer.ObjectSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.spi.CDI;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

import static br.com.wealthsystems.security.SecurityProperties.SHIRO_REDIS_KEY;

/**
 * {@link RedisSessionDAO} specific implementation for JWT id uses to access Redis Sessions.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtRedisDAO extends RedisSessionDAO {

    private final Logger logger = LoggerFactory.getLogger(JwtRedisDAO.class);

    /**
     * Creates a session on redis and returns the session id.
     *
     * @param session   the current session
     * @return          the session id
     */
    @Override
    protected Serializable doCreate(final Session session) {
        Serializable sessionId = session.getId() == null ? this.generateSessionId(session) : session.getId();
        super.assignSessionId(session, sessionId);
        customSaveSession(session);
        return sessionId;
    }

    /**
     * Sets expiration timeout for current session at the Redis manager.
     *
     * @param session   to be saved on Redis
     * @implNote        as this method is private on super we had to copy it to use on {@link #doCreate(Session)}
     */
    private void customSaveSession(final Session session) {
        if (session == null) {
            logger.error("Session is null");
            return;
        } else{
            if(session.getId() == null){
                logger.error("Session id is null");
                return;
            }
        }

        byte[] value;
        try {
            value = new ObjectSerializer().serialize(session);
        } catch (final SerializationException ex) {
            throw new RuntimeException("Error serializing session", ex);
        }
        final byte[] key = customGetByteKey(session.getId()).getBytes(StandardCharsets.UTF_8);
        final RedisProperties redisProperties = CDI.current().select(RedisProperties.class).get();

        try {
            Long expire = session.getTimeout();

            if (expire == 0) {
                getRedisManager().set(key, value, redisProperties.getExpire());
            } else {
                expire = expire / 1000;
                getRedisManager().set(key, value, expire.intValue());
            }
        } finally {
            CDI.current().destroy(redisProperties);
        }
    }

    /**
     * Returns a key from the current shiro redis key with the current session id.
     *
     * @param sessionId for key creation
     * @return          formatted key
     */
    private String customGetByteKey(final Serializable sessionId){

        final String shiroRedisKey =
                ConfigResolver
                        .resolve(SHIRO_REDIS_KEY)
                        .getValue();

        if ( !StringUtils.isBlank(shiroRedisKey) ) {
            throw new IllegalStateException("When using " + this.getClass().getName() + " the property " + SHIRO_REDIS_KEY +
            " must be set to access the Redis Session. The value for this configuration must be provided by the stack, " +
                    "commonly set by the permission provider service");
        }
        return shiroRedisKey + sessionId;
    }
}
