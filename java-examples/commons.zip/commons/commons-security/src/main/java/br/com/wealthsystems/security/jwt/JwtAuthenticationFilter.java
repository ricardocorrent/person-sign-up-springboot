package br.com.wealthsystems.security.jwt;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.apache.shiro.web.filter.authc.AuthenticatingFilter;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;

/**
 * This class represents a filter to validate if Authorization Bearer token is provided and forcing a
 * new authentication on every request.
 *
 * @author  Ivan A. Reffatti
 * @since   5.5.0 - 2017-12-27
 * */
public class JwtAuthenticationFilter extends AuthenticatingFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    private Boolean createSession = Boolean.FALSE;

    /**
     * @see AuthenticatingFilter#isAccessAllowed(ServletRequest, ServletResponse, Object)
     */
    @Override
    protected boolean isAccessAllowed(final ServletRequest request, final ServletResponse response, final Object mappedValue) {
        return false;
    }

    /**
     * Creates token for authentication based on Authorization Header.
     *
     * @see AuthenticatingFilter#createToken(ServletRequest, ServletResponse)
     * */
    @Override
    protected AuthenticationToken createToken(final ServletRequest request, final ServletResponse response) {
        Objects.requireNonNull(request, "request cannot be null");

        final HttpServletRequest httpRequest = (HttpServletRequest) request;
        final String stringToken = JwtUtils.getJwtTokenFromRequest(httpRequest);

        if (stringToken != null) {
            return getToken(stringToken);
        }

        return null;
    }

    /**
     * Handler for access denial.
     *
     * @see AuthenticatingFilter#onAccessDenied(ServletRequest, ServletResponse)
     */
    @Override
    protected boolean onAccessDenied(final ServletRequest request, final ServletResponse response) throws Exception {
        return executeLogin(request, response);
    }

    /**
     * Returns an {@link AuthenticationToken}.
     *
     * @param token raw JWT token
     * @return      a parsed AuthenticationToken
     */
    protected AuthenticationToken getToken(final String token) {
        return new JwtAuthenticationToken(token);
    }

    /**
     * Handler for login failures.
     *
     * @see AuthenticatingFilter#onLoginFailure(AuthenticationToken, AuthenticationException, ServletRequest, ServletResponse)
     */
    @Override
    protected boolean onLoginFailure(final AuthenticationToken token,
                                     final AuthenticationException e,
                                     final ServletRequest request,
                                     final ServletResponse response) {

        final HttpServletResponse httpResponse = WebUtils.toHttp(response);
        try {

            LOGGER.debug("Login failure: " + e.getMessage(), e);
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);

        } catch (final IOException ioe) {
            LOGGER.error("An error occurred while trying to set login failure message.", ioe);
        }

        return false;
    }

    /**
     * As Jwt is stateless we may want to read from session but not create it. BUT if in some scenario the delevoper
     * needs to create it, just set configuration on shiro.ini as example below:
     * <pre>
     *    [filters]
     *      filter = JwtAuthenticationFilter
     *      filter.createSession = true
     *
     *      [urls]
     *    /** = filter
     * </pre>
     *
     * @see AuthenticatingFilter#onPreHandle(ServletRequest, ServletResponse, Object)
     * */
    @Override
    public boolean onPreHandle(final ServletRequest request, final ServletResponse response, final Object mappedValue) throws Exception {
        Objects.requireNonNull(request, "request cannot be null");

        request.setAttribute(DefaultSubjectContext.SESSION_CREATION_ENABLED, this.createSession);
        return super.onPreHandle(request, response, mappedValue);
    }

    /**
     * @param createSession if this filter should create sessions.
     */
    public void setCreateSession(Boolean createSession) {
        this.createSession = createSession;
    }
}
