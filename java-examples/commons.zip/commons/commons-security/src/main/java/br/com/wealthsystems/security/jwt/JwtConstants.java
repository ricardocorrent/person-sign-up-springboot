package br.com.wealthsystems.security.jwt;

/**
 * Constants for JWT and Hofund uses.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-26
 */
public final class JwtConstants {

    public static final String SUBJECT = "sub";

    public static final String TOKEN_TYPE_BEARER = "Bearer";

    public static final String RSA_ALGORITHM = "RSA";

    private JwtConstants() {}
}
