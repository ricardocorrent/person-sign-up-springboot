package br.com.wealthsystems.security.jwt;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SessionContext;
import org.apache.shiro.session.mgt.SimpleSession;
import org.apache.shiro.session.mgt.SimpleSessionFactory;

/**
 * Custom session factory needed to allow extracting session key from JWT.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtSessionFactory extends SimpleSessionFactory {

    /**
     * Creates a new session.
     *
     * @param initData  information about the session context
     * @see             SimpleSessionFactory#createSession(SessionContext)
     */
    @Override
    public Session createSession(final SessionContext initData) {
        final SimpleSession session = (SimpleSession) super.createSession(initData);
        session.setId(initData.getSessionId());
        return session;
    }
}
