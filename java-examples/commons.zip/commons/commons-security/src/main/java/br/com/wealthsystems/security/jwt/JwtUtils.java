package br.com.wealthsystems.security.jwt;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

/**
 * JWT utility class, used to describe common methods that does not correspond to a unique business logic from a feature.
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-26
 */
public final class JwtUtils {


    /**
     * Private constructor. Avoids undesired instantiation.
     * */
    private JwtUtils() {}

    /**
     * Extracts Authorization Header based on default prefix "Bearer".
     *
     * @return              raw string token
     * @param httpRequest   the request for the Authorization header to be extracted
     * */
    public static String getJwtTokenFromRequest(final HttpServletRequest httpRequest) {
        return getJwtTokenFromRequest(httpRequest, JwtConstants.TOKEN_TYPE_BEARER);
    }

    /**
     *
     * Extracts Authorization Header based on the custom token prefix.
     *
     * @return              raw string token
     * @param httpRequest   the request for the Authorization header to be extracted
     * @param tokenPrefix   custom token prefix for Authorization header
     * */
    public static String getJwtTokenFromRequest(final HttpServletRequest httpRequest, final String tokenPrefix) {

        final String authorizationHeader = httpRequest.getHeader("Authorization");

        if (authorizationHeader != null && authzHeaderStartsWithBearerPrefix(authorizationHeader)) {
            return authorizationHeader.substring(tokenPrefix.length() + 1);
        }

        return null;
    }

    private static Boolean authzHeaderStartsWithBearerPrefix(final String header) {
        return authzHeaderStartsWithPrefix(JwtConstants.TOKEN_TYPE_BEARER + " ", header);
    }

    private static Boolean authzHeaderStartsWithPrefix(final String prefix, final String header) {
        return Pattern.compile("\\b" + prefix + "\\b").matcher(header).find();
    }

}
