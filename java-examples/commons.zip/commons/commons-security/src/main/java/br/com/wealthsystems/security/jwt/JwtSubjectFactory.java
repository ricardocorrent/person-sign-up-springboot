package br.com.wealthsystems.security.jwt;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSubjectFactory;
import org.apache.shiro.web.subject.WebSubjectContext;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Default subject factory class.
 *
 * <p>This class is used to build web subjects using {@link SubjectContext}</p>
 *
 * @author  Ivan A. Reffatti
 * @since   6.0.0 - 2018-04-12
 */
public class JwtSubjectFactory extends DefaultWebSubjectFactory {

    /**
     * Returns a new web subject.
     *
     * @see DefaultWebSubjectFactory#createSubject(SubjectContext)
     */
    @Override
    public Subject createSubject(final SubjectContext context) {

        if (!(context instanceof WebSubjectContext)) {
            return super.createSubject(context);
        }
        final WebSubjectContext wsc = (WebSubjectContext) context;
        final SecurityManager securityManager = wsc.resolveSecurityManager();
        final Session session = wsc.resolveSession();
        final boolean sessionEnabled = wsc.isSessionCreationEnabled();
        final PrincipalCollection principals = wsc.resolvePrincipals();
        final boolean authenticated = wsc.resolveAuthenticated();
        final String host = wsc.resolveHost();
        final ServletRequest request = wsc.resolveServletRequest();
        final ServletResponse response = wsc.resolveServletResponse();

        return new JwtDelegatingSubject(principals, authenticated, host, session, sessionEnabled,
                request, response, securityManager);
    }
}
