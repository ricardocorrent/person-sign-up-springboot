package com.ws.commons.interceptor.sourceannotation;

import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * Annotation created to record the Jersey's interception of writing in the method(s) of the resource(s) http.
 * <p>The interception will perform the conversion of the returned POJO (JSON) into the response body.</p>
 *
 * <pre>
 *   {@literal @}POST
 *   {@literal @}Produces(MediaType.APPLICATION_JSON)
 *   {@literal @}Consumes(MediaType.APPLICATION_JSON)
 *   {@literal @}ConversionProduces(TORepresentation.class)
 *   public Response insert({@literal @}Consumer Entity object) throws Exception{
 *        return Response.status(HttpStatus.SC_CREATED).entity(new Id(service.insert(object))).build();
 *   }
 * </pre>
 * 
 * <p>
 *  Use {@link NoConversion} or {@link NoConversionProduces} to prevent conversion within annotated resource class.
 * </p>
 * 
 * <p>
 * See also:
 * <ul>
 *  <li>com.ws.commons.interceptor.pojoconverter.provider.ConversionProductionInterceptor</li>
 *  <li>com.ws.commons.pojoconverter.PojoConverter</li>
 * </p>
 * 
 * @author  Diego Armange Costa
 * @see     Consumer
 * @see     <a href="https://repo1.maven.org/maven2/org/glassfish/jersey/jersey-documentation/2.5.1/jersey-documentation-2.5.1-user-guide.pdf">
 *          Jersey documentation
 *          </a>
 * @since   5.0.0 - 2017-06-21
 * @deprecated
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NameBinding
@Deprecated
public @interface ConversionProduces {
    
    /*
     * The NameBinding above demands that the attributes be not null.
     */
    /**
     * @return The class representing the returned JSON.
     */
    Class<?> value() default Object.class;
    
    /**
     * @return The fields that will be filtered or ignored if {@link #ignore()} is true.
     */
    String[] fields() default "";
    
    /**
     * When true, indicates that the fields defined in {@link #fields()} will be ignored.<br> 
     * When false, indicates that the fields will be filtered.
     * 
     * @return True to ignore or false to filter.
     */
    boolean ignore() default false;
}
