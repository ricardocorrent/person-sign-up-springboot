package com.ws.commons.interceptor.sourceannotation;

import java.lang.annotation.*;

/**
 * Signals the parameter as the conversion consumer (request body).
 *
 * <p>It is not mandatory to use this annotation when the method has only one parameter.</p>
 *
 * <pre>
 *  {@literal @}POST
 *  {@literal @}Produces(MediaType.APPLICATION_JSON)
 *  {@literal @}Consumes(MediaType.APPLICATION_JSON)
 *  {@literal @}ConversionConsumes(TORepresentation.class)
 *   public Response insert({@literal @}Consumer Entity object) throws Exception{
 *        return Response.status(HttpStatus.SC_CREATED).entity(new Id(service.insert(object))).build();
 *   }
 * </pre>
 *
 * @author  Diego Armange Costa
 * @see     ConversionConsumes
 * @see     ConversionMapConsumes
 * @since   5.0.0 - 2017-06-26
 * @deprecated
 */
@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Deprecated
public @interface Consumer {}
