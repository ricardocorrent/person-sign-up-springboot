package com.ws.commons.interceptor.sourceannotation;

import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * Annotation created to record the Jersey's interception of reading in the method(s) of the resource(s) http.
 * <p>The interception will perform the conversion of POJO (Json) entered in the request body.</p>
 * <p>It is not mandatory to flag the method parameter as a consumer when there is only one parameter.</p>
 *
 * <pre>
 *   {@literal @}POST
 *   {@literal @}Produces(MediaType.APPLICATION_JSON)
 *   {@literal @}Consumes(MediaType.APPLICATION_JSON)
 *   {@literal @}ConversionMapConsumes(
 *           {@literal @}ConversionMap({
 *               {@literal @}ConversionMapEntry(from = TORepresentation.class, to = Entity.class),
 *               {@literal @}ConversionMapEntry(from = YieldTypeTO.class, to = YieldType.class)
 *           })
 *       )
 *   {@literal @}ConversionMapProduces(
 *           {@literal @}ConversionMap({
 *               {@literal @}ConversionMapEntry(from = Entity.class, to = TORepresentation.class),
 *               {@literal @}ConversionMapEntry(from = YieldType.class, to = YieldTypeTO.class)
 *           })
 *       )
 *   public Response insert({@literal @}Consumer Entity object) throws Exception{
 *       return Response.status(HttpStatus.SC_CREATED).entity(new Id(service.insert(object))).build();
 *   }
 * </pre>
 * *
 * @author  Diego Armange Costa
 * @see     Consumer
 * @see     ConversionMapEntry
 * @see     ConversionMapProduces
 * @see     <a href="https://repo1.maven.org/maven2/org/glassfish/jersey/jersey-documentation/2.5.1/jersey-documentation-2.5.1-user-guide.pdf">
 *          Jersey documentation
 *          </a>
 * @since   5.0.0 - 2017-06-22
 * @deprecated
 */
@Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NameBinding
@Deprecated
public @interface ConversionMapConsumes {
    
    /*
     * The NameBinding above demands that the attributes be not null.
     */
    /**
     * @return a map({@link ConversionMap}) indicating the source class and the resulting class of the conversion
     * @see ConversionMapEntry
     */
    ConversionMap value() default @ConversionMap({});
}
