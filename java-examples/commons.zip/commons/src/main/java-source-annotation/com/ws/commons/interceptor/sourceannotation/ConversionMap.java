package com.ws.commons.interceptor.sourceannotation;

import java.lang.annotation.*;

/**
 * Annotation created to indicate the source and resulting classes of the conversion.
 *
 * <pre>
 *  {@literal @}POST
 *  {@literal @}Produces(MediaType.APPLICATION_JSON)
 *  {@literal @}Consumes(MediaType.APPLICATION_JSON)
 *  {@literal @}ConversionMapConsumes(
 *           {@literal @}ConversionMap({
 *               {@literal @}ConversionMapEntry(from = TORepresentation.class, to = Entity.class),
 *               {@literal @}ConversionMapEntry(from = YieldTypeTO.class, to = YieldType.class)
 *           })
 *       )
 *   {@literal @}ConversionMapProduces(
 *           {@literal @}ConversionMap({
 *               {@literal @}ConversionMapEntry(from = Entity.class, to = TORepresentation.class),
 *               {@literal @}ConversionMapEntry(from = YieldType.class, to = YieldTypeTO.class)
 *           })
 *       )
 *   public Response insert({@literal @}Consumer Entity object) throws Exception{
 *       return Response.status(HttpStatus.SC_CREATED).entity(new Id(service.insert(object))).build();
 *   }
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @see     Consumer
 * @since   5.0.0 - 2017-06-21
 * @deprecated
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Deprecated
public @interface ConversionMap {
    
    /**
     * @return a map({@code ConversionMapEntry}) indicating the source class and the resulting class of the conversion
     * 
     * @see ConversionMapEntry
     */
    ConversionMapEntry[] value();
}
