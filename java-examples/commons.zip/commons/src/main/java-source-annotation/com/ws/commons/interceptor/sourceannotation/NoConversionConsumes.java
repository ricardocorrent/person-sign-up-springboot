package com.ws.commons.interceptor.sourceannotation;

import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * It marks the method to not perform {@link ConversionConsumes}.
 * <p>This only needs to be used on classes annotated with {@link ConversionConsumes} annotation.</p>
 *
 * <pre>
 * {@literal @}Path("/customer")
 * {@literal @}ConversionProduces(CustomerDTO.class)
 * {@literal @}ConversionConsumes(CustomerDTO.class)
 * public class CustomerResource {
 *      ...
 *      
 *      {@literal @}GET
 *      {@literal @}NoConversionConsumes
 *      {@literal @}Path("get-any")
 *      public Response getWithoutConversion() {
 *          ...
 *      }
 * }
 * </pre>
 *
 * @author  Diego Armange Costa
 * @see     ConversionConsumes
 * @since   5.3.0 - 2017-11-20
 * @deprecated
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NameBinding
@Deprecated
public @interface NoConversionConsumes {}
