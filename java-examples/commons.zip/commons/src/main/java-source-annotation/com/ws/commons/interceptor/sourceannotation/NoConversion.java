package com.ws.commons.interceptor.sourceannotation;

import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * It marks the method to not perform any conversion.
 * <p>This only needs to be used on classes annotated with any conversion annotation.</p>
 *
 * <pre>
 * {@literal @}Path("/customer")
 * {@literal @}ConversionProduces(CustomerDTO.class)
 * {@literal @}ConversionConsumes(CustomerDTO.class)
 * public class CustomerResource {
 *      ...
 *      
 *      {@literal @}GET
 *      {@literal @}NoConversion
 *      {@literal @}Path("get-any")
 *      public Response getWithoutConversion() {
 *          ...
 *      }
 * }
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @see     ConversionConsumes
 * @see     ConversionProduces
 * @since   5.3.0 - 2017-11-20
 * @deprecated
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NameBinding
@Deprecated
public @interface NoConversion {}
