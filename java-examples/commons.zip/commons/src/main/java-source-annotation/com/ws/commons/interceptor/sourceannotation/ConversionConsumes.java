package com.ws.commons.interceptor.sourceannotation;

import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * Annotation created to record the Jersey's interception of reading in the method(s) of the resource(s) http.
 * <p>The interception will perform the conversion of POJO (JSON) entered in the request body.</p>
 * <p>It is not mandatory to flag the method parameter as a consumer when there is only one parameter.</p>
 *
 * <pre>
 *  {@literal @}POST
 *  {@literal @}Produces(MediaType.APPLICATION_JSON)
 *  {@literal @}Consumes(MediaType.APPLICATION_JSON)
 *  {@literal @}ConversionConsumes(TORepresentation.class)
 *   public Response insert({@literal @}Consumer Entity object) throws Exception{
 *        return Response.status(HttpStatus.SC_CREATED).entity(new Id(service.insert(object))).build();
 *   }
 * </pre>
 * 
 * <p>
 *  Use {@link NoConversion} or {@link NoConversionConsumes} to prevent conversion within annotated resource class.
 * </p>
 * 
 * <p>
 * See also:
 * </p>
 * <ul>
 *  <li>com.ws.commons.interceptor.pojoconverter.provider.ConversionConsumeInterceptor</li>
 *  <li>com.ws.commons.pojoconverter.PojoConverter</li>
 * </ul>
 *
 * @author  Diego Armange Costa
 * @see     Consumer
 * @see     <a href="https://repo1.maven.org/maven2/org/glassfish/jersey/jersey-documentation/2.5.1/jersey-documentation-2.5.1-user-guide.pdf">
 *          Jersey documentation
 *          </a>
 * @since   5.0.0 - 2017-06-21
 * @deprecated
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NameBinding
@Deprecated
public @interface ConversionConsumes {
    
    /*
     * The NameBinding above demands that the attributes be not null.
     */
    /**
     * @return the class representing the received JSON.
     */
    Class<?> value() default Object.class;
}
