package com.ws.commons.integration.customizer;

import com.ws.commons.server.validation.beanvalidation.integration.ContextWrapper;
import feign.RequestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

/**
 * {@link IntegrationRequestCustomizer} implementation for language forwarding
 *
 * <p>This class forwards the requested language from the original request to the integration one.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-21
 */
@Default
public class LanguageIntegrationRequestCustomizer implements IntegrationRequestCustomizer {

    private static final String LANGUAGE_HEADER = "accept-language";
    private static final Logger LOGGER = LoggerFactory.getLogger(LanguageIntegrationRequestCustomizer.class);
    private final BeanManager beanManager;
    private final Instance<ContextWrapper> currentRequestProvider;

    /**
     * CDI enabled constructor with {@link BeanManager} and {@link Instance} provider for {@link HttpServletRequest}
     *
     * @param beanManager BeanManager
     * @param currentRequestProvider Instance provider for current request
     */
    @Inject
    public LanguageIntegrationRequestCustomizer(final BeanManager beanManager,
                                                final Instance<ContextWrapper> currentRequestProvider) {
        this.beanManager = beanManager;
        this.currentRequestProvider = currentRequestProvider;
    }

    /**
     * Customizes the request prior to the call
     *
     * @param template         Request template
     * @param clientDefinition Integration client in use
     */
    @Override
    public void customize(final RequestTemplate template, final Class<?> clientDefinition) {
        if (!isRequestContextActive()) {
            LOGGER.debug("RequestScoped context isn't active. Skipping language forward.");
            return;
        }

        String language = null;
        try {
            final HttpServletRequest currentRequest = currentRequestProvider.get().getRequest();
            language = currentRequest.getHeader(LANGUAGE_HEADER);
        } catch (final Exception e) {
            LOGGER.trace("Error to get Language header in the original request.", e);
        }

        if (language == null) {
            LOGGER.debug("Language header not found in the original request. Skipping language forward.");
            return;
        }

        LOGGER.debug("Forwarding language in integration request as {}", language);
        template.header(LANGUAGE_HEADER, language);
    }

    /**
     * Checks if the {@link RequestScoped} context is enabled for current thread
     *
     * @return Result of the check
     */
    private boolean isRequestContextActive() {
        try {
            return beanManager.getContext(RequestScoped.class).isActive();
        } catch (org.jboss.weld.context.ContextNotActiveException ex) {
            return false;
        } catch (javax.enterprise.context.ContextNotActiveException ex) {
            return false;
        }
    }
}
