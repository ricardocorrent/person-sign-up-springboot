package com.ws.commons;

import com.ws.commons.persistence.AbstractDAO;
import com.ws.commons.persistence.dao.mapper.DAOLogicErrorMapper;
import com.ws.commons.server.AbstractService;
import com.ws.commons.server.exception.MissingConfigException;
import com.ws.commons.server.validation.exception.LogicException;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import io.ebean.config.TenantMode;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Provides DeltaSpike custom persistence properties.
 *
 * <p>
 * If you need to know all information about these properties keys, its default values and the correct way to
 * explore the available configurations, consider reading the
 * <a href="https://gitlab.wssim.com.br/platform/commons/blob/master/configuration-options.md">README</a>
 * </p>
 *
 * @author  Ivan A. Reffatti
 * @author  Rogerio Kiihl
 * @author  Lucas Dillmann
 * @author  Hendric Gabriel Cechinato
 * @author  Hendric Gabriel Cechinato
 * @version 6.0.2 - 2018-06-27 - Added property to set if not found entities should throw an exception
 * @version 7.1.0 - Added property to set the update strategy on update operations using AbstractDAO
 * @version 7.3.7 - Added property to set if any Exception thrown in DAO should be intercepted and mapped to LogicException
 * @version 7.4.0 - Set HikariCP as the default DataSource provider and removed default values
 * @since   4.11.0 - 2017-07-21
 */
@ApplicationScoped
public class PersistenceProperties {

    public static final String DB_URL = "db.url";
    public static final String DB_USERNAME = "db.username";
    public static final String DB_PASSWORD = "db.password";
    public static final String DB_SCHEMA = "db.schema";
    public static final String DB_DRIVER = "db.driver";
    public static final String DB_PLATFORM = "db.platform";
    public static final String TENANT_MODE = "tenant.mode";
    public static final String DS_REMOVE_ABANDONED_ON_BORROW = "ds.removeAbandonedOnBorrow";
    public static final String DS_REMOVE_ABANDONED_ON_MAINTENANCE = "ds.removeAbandonedOnMaintenance";
    public static final String DS_REMOVE_ABANDONED_TIMEOUT = "ds.removeAbandonedTimeout";
    public static final String DS_LOG_ABANDONED = "ds.logAbandoned";
    public static final String DS_MAX_IDLE = "ds.maxIdle";
    public static final String DS_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = "ds.softMinEvictableIdleTimeMillis";
    public static final String DS_MIN_IDLE = "ds.minIdle";
    public static final String DS_MIN_EVICTABLE_IDLE_TIME_MILLIS = "ds.minEvictableIdleTimeMillis";
    public static final String DS_MAX_CONN_LIFETIME_MILLIS = "ds.maxConnLifetimeMillis";
    public static final String DS_MAX_TOTAL = "ds.maxTotal";
    public static final String DS_LOG_EXPIRED_CONNECTIONS = "ds.logExpiredConnections";
    public static final String DS_TEST_ON_BORROW = "ds.testOnBorrow";
    public static final String DS_TEST_ON_RETURN = "ds.testOnReturn";
    public static final String DS_TEST_WHILE_IDLE = "ds.testWhileIdle";
    public static final String DS_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "ds.timeBetweenEvictionRunsMillis";
    public static final String DS_PROVIDER = "ds.provider";
    public static final String DS_CONNECTION_TIMEOUT_MILLIS = "ds.connectionTimeoutMillis";
    public static final String EBEAN_SERVER_NAME = "ebean.server.name";
    public static final String RECYCLING_DISABLE_DEFAULT_RECYCLER = "recycling.disableDefaultRecycler";
    public static final String DAO_THROW_REGISTER_NOT_FOUND = "dao.throwRegisterNotFound";
    public static final String DAO_ONLY_UPDATE_CHANGED_FIELDS = "dao.onlyUpdateChangedFields";
    public static final String DAO_MAP_EXCEPTION_TO_LOGIC_EXCEPTION = "dao.mapExceptionToLogicException";
    public static final String SERVICE_THROW_REGISTER_NOT_FOUND = "service.throwRegisterNotFound";

    /**
     * @deprecated 7.3.0 - 2018-09-04 - Deprecation of the field. This configuration option isn't taken in consideration
     * anymore, and setting it or not will produce the exact same result.
     * This property was originally created after a bug found in a deadline of a product release to customer, allowing
     * it to be avoided prior to releasing the system to customer. Since the bug doesn't exist anymore this property is
     * deprecated.
     */
    @Deprecated
    public static final String DAO_MERGE_SKIP_MANY_TO_MANY_DISASSOCIATION = "dao.merge.skipManyToManyDisassociation";

    private static final String DEFAULT_FALSE = "false";
    private static final String DEFAULT_TRUE = "true";

    private final Logger logger = LoggerFactory.getLogger(PersistenceProperties.class);
    @Inject
    ProjectStage stage;

    @Inject
    @ConfigProperty(name = DB_URL)
    private String databaseUrl;

    @Inject
    @ConfigProperty(name = DB_USERNAME, defaultValue = "postgres")
    private String databaseUsername;

    @Inject
    @ConfigProperty(name = DB_PASSWORD, defaultValue = "postgres")
    private String databasePassword;

    @Inject
    @ConfigProperty(name = DAO_THROW_REGISTER_NOT_FOUND, defaultValue = DEFAULT_FALSE)
    private boolean throwRegisterNotFoundOnAbstractDAO;

    @Inject
    @ConfigProperty(name = DAO_MAP_EXCEPTION_TO_LOGIC_EXCEPTION, defaultValue = DEFAULT_TRUE)
    private boolean daoMapExceptionToLogicException;

    /**
     * Only in development
     **/
    @Inject
    @ConfigProperty(name = DB_SCHEMA, defaultValue = "wealthsystems")
    private String databaseSchema;

    @Inject
    @ConfigProperty(name = DB_DRIVER, defaultValue = "org.postgresql.Driver")
    private String dbDriver;

    @Inject
    @ConfigProperty(name = DB_PLATFORM, defaultValue = "io.ebean.config.dbplatform.postgres.PostgresPlatform")
    private String dbPlatform;

    @Inject
    @ConfigProperty(name = TENANT_MODE, defaultValue = "SCHEMA")
    private String tenantMode;

    @Inject
    @ConfigProperty(name = DS_REMOVE_ABANDONED_ON_BORROW)
    private Boolean dsRemoveAbandonedOnBorrow;

    @Inject
    @ConfigProperty(name = DS_REMOVE_ABANDONED_ON_MAINTENANCE)
    private Boolean dsRemoveAbandonedOnMaintenance;

    @Inject
    @ConfigProperty(name = DS_REMOVE_ABANDONED_TIMEOUT)
    private Integer dsRemoveAbandonedTimeout;

    @Inject
    @ConfigProperty(name = DS_LOG_ABANDONED)
    private Boolean dsLogAbandoned;

    @Inject
    @ConfigProperty(name = DS_MAX_IDLE)
    private Integer dsMaxIdle;

    @Inject
    @ConfigProperty(name = DS_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS)
    private Integer dsSoftMinEvictableIdleTimeMillis;

    @Inject
    @ConfigProperty(name = DS_MIN_IDLE)
    private Integer dsMinIdle;

    @Inject
    @ConfigProperty(name = DS_MIN_EVICTABLE_IDLE_TIME_MILLIS)
    private Long dsMinEvictableIdleTimeMillis;

    @Inject
    @ConfigProperty(name = DS_MAX_CONN_LIFETIME_MILLIS)
    private Long dsMaxConnLifeTimeMills;

    @Inject
    @ConfigProperty(name = DS_MAX_TOTAL)
    private Integer dsMaxTotal;

    @Inject
    @ConfigProperty(name = DS_LOG_EXPIRED_CONNECTIONS)
    private Boolean dsLogExpiredConnections;

    /**
     * TODO #24184 Opened task for performance test with this parameter
     */
    @Inject
    @ConfigProperty(name = DS_TEST_ON_BORROW)
    private Boolean dsTestOnBorrow;

    @Inject
    @ConfigProperty(name = DS_TEST_ON_RETURN)
    private Boolean dsTestOnReturn;

    @Inject
    @ConfigProperty(name = DS_TEST_WHILE_IDLE)
    private Boolean dsTestWhileIdle;

    @Inject
    @ConfigProperty(name = DS_TIME_BETWEEN_EVICTION_RUNS_MILLIS)
    private Integer dsTimeBetweenEvictionRunsMillis;

    @Inject
    @ConfigProperty(name = EBEAN_SERVER_NAME, defaultValue = "EbeanMultiTenancyServer")
    private String ebeanServerName;

    @Inject
    @ConfigProperty(name = RECYCLING_DISABLE_DEFAULT_RECYCLER, defaultValue = DEFAULT_FALSE)
    private Boolean recyclingDisableDefaultRecycler;

    @Inject
    @ConfigProperty(name = DS_PROVIDER, defaultValue = "HIKARICP")
    private String dsProvider;

    @Inject
    @ConfigProperty(name = DS_CONNECTION_TIMEOUT_MILLIS)
    private Long dsConnectionTimeoutMillis;

    @Inject
    @ConfigProperty(name = DAO_ONLY_UPDATE_CHANGED_FIELDS, defaultValue = DEFAULT_TRUE)
    private boolean daoOnlyUpdateChangedFields;

    @Inject
    @ConfigProperty(name = SERVICE_THROW_REGISTER_NOT_FOUND, defaultValue = DEFAULT_TRUE)
    private boolean throwRegisterNotFoundOnAbstractService;

    /**
     * @deprecated 7.3.0 - 2018-09-04 - Deprecation of the field. This configuration option isn't taken in consideration
     * anymore, and setting it or not will produce the exact same result.
     * This property was originally created after a bug found in a deadline of a product release to customer, allowing
     * it to be avoided prior to releasing the system to customer. Since the bug doesn't exist anymore this property is
     * deprecated.
     */
    @Inject
    @Deprecated
    @ConfigProperty(name = DAO_MERGE_SKIP_MANY_TO_MANY_DISASSOCIATION, defaultValue = DEFAULT_FALSE)
    private boolean daoMergeSkipManyToManyDisassociation;

    public String getDatabaseUrl() {
        return databaseUrl;
    }

    public String getDatabaseUsername() {
        return databaseUsername;
    }

    public String getDatabasePassword() {
        return databasePassword;
    }

    public String getDatabaseSchema() {
        return databaseSchema;
    }

    public String getDbDriver() {
        return dbDriver;
    }

    public String getDbPlatform() {
        return this.dbPlatform;
    }

    public TenantMode getTenantMode() {
        final Stream<TenantMode> stream = Stream.of(TenantMode.values())
                .filter(mode -> mode.name().equalsIgnoreCase(this.tenantMode));
        return stream.findAny().orElseThrow(() -> new IllegalArgumentException(String.format("TenantMode not available. Available: %s, %s, %s, %s", TenantMode.NONE, TenantMode.DB, TenantMode.SCHEMA, TenantMode.PARTITION)));
    }

    public Boolean getDsRemoveAbandonedOnBorrow() {
        return this.dsRemoveAbandonedOnBorrow;
    }

    public Boolean getDsRemoveAbandonedOnMaintenance() {
        return this.dsRemoveAbandonedOnMaintenance;
    }

    public Integer getDsRemoveAbandonedTimeout() {
        return this.dsRemoveAbandonedTimeout;
    }

    public Boolean getDsLogAbandoned() {
        return this.dsLogAbandoned;
    }

    public Integer getDsMaxIdle() {
        return dsMaxIdle;
    }

    public Integer getDsSoftMinEvictableIdleTimeMillis() {
        return dsSoftMinEvictableIdleTimeMillis;
    }

    public Integer getDsMinIdle() {
        return dsMinIdle;
    }

    public Long getDsMinEvictableIdleTimeMillis() {
        return dsMinEvictableIdleTimeMillis;
    }

    public Long getDsMaxConnLifeTimeMills() {
        return dsMaxConnLifeTimeMills;
    }

    public Integer getDsMaxTotal() {
        return dsMaxTotal;
    }

    public Boolean getDsLogExpiredConnections() {
        return dsLogExpiredConnections;
    }

    public Boolean getDsTestOnBorrow() {
        return dsTestOnBorrow;
    }

    public Boolean getDsTestOnReturn() {
        return dsTestOnReturn;
    }

    public Boolean getDsTestWhileIdle() {
        return dsTestWhileIdle;
    }

    public Integer getDsTimeBetweenEvictionRunsMillis() {
        return this.dsTimeBetweenEvictionRunsMillis;
    }

    public String getEbeanServerName() {
        return this.ebeanServerName;
    }

    public Boolean getRecyclingDisableDefaultRecycler() {
        return recyclingDisableDefaultRecycler;
    }

    /**
     * Returns the configured {@link DataSource} and connection pool provider.
     *
     * @author  Lucas Dillmann
     * @return  configured DataSource provider
     * @since   6.1.0 - 2018-07-06
     */
    public String getDsProvider() {
        return dsProvider;
    }

    /**
     * Gets a boolean value indicating if {@link AbstractDAO#findById(UUID)}
     * must throws an exception when no entity is found.
     *
     * @author  Rogerio Kiihl
     * @return  true if a {@link RegisterNotFoundException} should be thrown
     * @since   6.0.2 - 2018-06-27
     */
    public boolean getThrowRegisterNotFoundOnAbstractDAO() {
        return throwRegisterNotFoundOnAbstractDAO;
    }

    /**
     * Gets a boolean value indicating if {@link AbstractService#get(UUID)}
     * must throws an exception when no entity is found.
     *
     * @author  Hendric Gabriel Cechinato
     * @return  true if a {@link RegisterNotFoundException} should be thrown
     * @since   7.3.8 - 2018-11-22
     */
    public boolean getThrowRegisterNotFoundOnAbstractService() {
        return throwRegisterNotFoundOnAbstractService;
    }

    /**
     * Returns the configured connection timeout in milliseconds.
     *
     * @author  Lucas Dillmann
     * @return  connection timeout in milliseconds
     * @since   6.1.0 - 2018-07-06
     */
    public Long getDsConnectionTimeoutMillis() {
        return dsConnectionTimeoutMillis;
    }

    /**
     * Returns the configured update strategy for AbstractDAO. When {@code true} (default value), the DAO
     * will generate and execute a SQL update using only changed fields from entity. When {@code false},
     * the generated SQL will update all fields from entity (and it's sub entities) regardless of the
     * field was changed or not.
     *
     * @author  Lucas Dillmann
     * @return  the DAO update strategy. True to generate update SQL with only the changed fields from entity.
     * @since   7.1.0 - 2018-08-10
     */
    public boolean isDaoOnlyUpdateChangedFields() {
        return daoOnlyUpdateChangedFields;
    }

    /**
     * Indicates if an {@link Exception} thrown in {@link AbstractDAO} should be intercepted
     * and mapped to a {@link LogicException} through {@link DAOLogicErrorMapper}.
     *
     * @return a {@link Boolean#TRUE} if DAO should map any Exception to a LogicException.
     */
    public boolean isDaoMapExceptionToLogicException() {
        return daoMapExceptionToLogicException;
    }

    /**
     * Returns the configured merge strategy for ManyToMany relationships disassociation. When {@code true},
     * the disassociation engine will be disabled.
     *
     * @author      Lucas Dillmann
     * @author      Lucas Dillmann
     * @since       7.2.3 - 2018-08-30
     * @return      the DAO Merge ManyToMany disassociation strategy
     * @deprecated  7.3.0 - 2018-09-04 - Deprecation of the field. This configuration option isn't taken in consideration
     *              anymore, and setting it or not will produce the exact same result.
     *              This property was originally created after a bug found in a deadline of a product release to customer,
     *              allowing it to be avoided prior to releasing the system to customer.
     *              Since the bug doesn't exist anymore this property is deprecated.
     */
    @Deprecated
    public boolean isDaoMergeSkipManyToManyDisassociation() {
        return daoMergeSkipManyToManyDisassociation;
    }

    /**
     * #11862
     * Validates the configuration done on apache-deltaspike.properties.
     *
     * @author  Ivan A. Reffatti
     * @since   1.1.0 - 2016-02-05
     */
    @PostConstruct
    private void validateConfiguration() {

        logger.debug("Persistence properties...");
        logger.debug("Parameter db.url = {}", this.getDatabaseUrl());
        logger.debug("Parameter db.schema = {}", this.getDatabaseSchema());

        // DB_SCHEMA is mandatory to set the right tenantId in Development stage
        if (this.getDatabaseSchema() == null && stage.equals(ProjectStage.Development)) {
            throw new MissingConfigException(DB_SCHEMA + " needs to be set in stage " + stage.toString() + ". See commons lib documentation.\n");
        }
    }
}
