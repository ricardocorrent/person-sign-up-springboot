package com.ws.commons.integration.warmup;

import com.ws.commons.persistence.restquery.RestQueryUrlBuilder;

import java.util.List;

/**
 * Interface to implement and integrate data from a service resource.
 *
 * The goal is to use this warm up when a service is initialized for the first time
 * to integrate all data necessary for the service to work. After that, it is possible
 * to use the message broker to keep the data updated.
 *
 * All classes that implemens this interface are executed by {@link WarmUpRunner}.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/04/19
 */
public interface WarmUp<T> {

    /**
     * Getter for the data type class.
     *
     * @return Data class.
     */
    Class<T> getDataClass();

    /**
     * Getter for the path to integrate data.
     *
     * @return Path to a service resource.
     */
    String getPath();

    /**
     * Getter for the optional rest query params using the @{@link RestQueryUrlBuilder} format.
     *
     * @return Rest query params.
     */
    String getRestQueryParams();

    /**
     * Process a list of data with T type.
     *
     * When this method returns true, the warm up will get the next page to process. Otherwise, it will stop.
     *
     * @param list to process
     *
     * @return True if successfully processed, false otherwise.
     */
    boolean process(final List<T> list);

}
