package com.ws.commons.integration.integrationrequest;

import com.ws.commons.server.resource.HTTPHeaders;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.client.Invocation;
import java.util.Map;

import static com.ws.commons.integration.Constants.AUTHORIZATION;
import static com.ws.commons.integration.Constants.SCHEME_BEARER;

/**
 * Utility class to execute HTTP requests with JAX-RS client API to cloud-manager.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/04/19
 */
public class IntegrationRequestCloudManager extends AbstractIntegrationRequest {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String INTEGRATION_ADDRESS_CLOUD_MANAGER = "integration.address.cloud.manager";
    private static final String INTEGRATION_ADDRESS_CLOUD_MANAGER_DEFAULT_VALUE = "http://odin/api/v6/cloud-manager";

    private static final String INTEGRATION_TOKEN_CLOUD_MANAGER = "integration.token.cloud.manager";

    private final String token;

    @Inject
    public IntegrationRequestCloudManager(
        @ConfigProperty(name = INTEGRATION_ADDRESS_CLOUD_MANAGER, defaultValue = INTEGRATION_ADDRESS_CLOUD_MANAGER_DEFAULT_VALUE) final String integrationAddress,
        @ConfigProperty(name = INTEGRATION_TIMEOUT, defaultValue = INTEGRATION_TIMEOUT_DEFAULT_VALUE) final Integer searchTimeout,
        @ConfigProperty(name = INTEGRATION_TOKEN_CLOUD_MANAGER) final String token
    ) {
        super(integrationAddress, searchTimeout);
        this.token = token != null ? SCHEME_BEARER + token : null;
    }

    /**
     * Build the headers of the given request according with the given headers and {@link HTTPHeaders#USER_ROLE_INTEGRATION}.
     *
     * Also, if propagateSession is true, add a Cookie header with the JSESSIONID of the current user session, and
     * if token is not null, add a Authorization header with the token.
     */
    @Override
    protected void configureHeaders(
        final Invocation.Builder request,
        final Map<String, String> headers
    ) {
        super.configureHeaders(request, headers);
        if (token != null) {
            request.header(AUTHORIZATION, token);
            logger.debug("Adding header to request: {}={}", AUTHORIZATION, token);
        } else {
            logger.warn("Executing request to cloud-manager without define a value for \"{}\" variable.", INTEGRATION_TOKEN_CLOUD_MANAGER);
        }
    }

}
