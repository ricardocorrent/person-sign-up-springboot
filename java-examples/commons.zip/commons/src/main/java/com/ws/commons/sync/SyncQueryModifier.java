package com.ws.commons.sync;

import com.ws.commons.persistence.RestQuery;
import io.ebean.EbeanServer;
import io.ebean.Query;

import javax.enterprise.context.RequestScoped;
import java.util.Map;

/**
 * This interface allows to make changes to the synchronization query, or even completely replace it by returning a new query.
 *
 * <p>
 * Be careful, if there are several implementations, one must not break the other. If it is no possible to make them work
 * separated, they should be merged.
 * </p>
 *
 * <p>Also, the default query params handling should be present, it can be added through {@link RestQuery}.</p>
 *
 * @author      Gustavo P. Bilert
 * @author      Diego Peliser
 * @version     6.0.0 - 2018-03-23
 * @since       2017-05-16
 * @deprecated  This was deprecated because the query modifiers will be applied by sync microservice with rest query.
 */
@Deprecated
@RequestScoped
public interface SyncQueryModifier {

    /**
     * This method allows to modify a query during synchronization process. {@code queryParams} are used to customize
     * the necessary changes to the query.
     *
     * @param query         the current query
     * @param entityClass   the class which represents the query
     * @param queryParams   the query parameters
     * @param ebeanServer   an {@link EbeanServer} instance
     * @param <T>           generic type
     * @return              a modified query
     */
    <T> Query<T> modifySyncQuery(final Query<T> query, final Class<T> entityClass, final Map<String, String[]> queryParams, EbeanServer ebeanServer);
}
