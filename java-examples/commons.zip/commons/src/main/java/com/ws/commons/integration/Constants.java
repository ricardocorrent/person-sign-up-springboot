package com.ws.commons.integration;

/**
 * Constants used by commons.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/05/19
 */
public class Constants {

    public static final String AMPERSAND = "&";
    public static final String AUTHORIZATION = "Authorization";
    public static final String COOKIE = "Cookie";
    public static final String CREATED_AT = "createdAt";
    public static final String EQUALS = "=";
    public static final String ID = "id";
    public static final String ITEMS = "items";
    public static final String QUESTION_MARK = "?";
    public static final String REST_QUERY = "q";
    public static final String SCHEME_BEARER = "Bearer ";
    public static final String UTF_8 = "UTF-8";

    private Constants() {
    }

}
