package com.ws.commons.integration;

import com.ws.commons.integration.customizer.IntegrationRequestCustomizer;
import com.ws.commons.message.EDefaultMessage;
import feign.RequestInterceptor;
import feign.RequestTemplate;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Custom Feign {@link RequestInterceptor} that customizes the request and adds additional headers to enable
 * cross-service authentication and tracing.
 *
 * @author Lucas Dillmann
 * @since 7.4.0 - 2018-12-10
 */
final class FeignRequestCustomizer implements RequestInterceptor {

    private final List<IntegrationRequestCustomizer> customizers;
    private Class<?> clientDefinition;

    /**
     * CDI enbled constructor with request customizers initialization
     *
     * @param customizers Customizers access object
     */
    @Inject
    public FeignRequestCustomizer(final @Any Instance<IntegrationRequestCustomizer> customizers) {
        Objects.requireNonNull(customizers, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("customizers"));
        this.customizers = StreamSupport
                .stream(customizers.spliterator(), false)
                .collect(Collectors.toList());
    }

    /**
     * Called for every request. Add data using methods on the supplied {@link RequestTemplate}.
     *
     * @param template a {@link RequestTemplate} object
     */
    @Override
    public void apply(final RequestTemplate template) {
        Objects.requireNonNull(clientDefinition, EDefaultMessage.VALUE_CANNOT_BE_NULL.getMessage("clientDefinition"));
        customizers.forEach(customizer -> customizer.customize(template, clientDefinition));
    }

    void setClientDefinition(final Class<?> clientDefinition) {
        Objects.requireNonNull(clientDefinition, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("clientDefinition"));
        this.clientDefinition = clientDefinition;
    }
}
