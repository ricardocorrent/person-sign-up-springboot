package com.ws.commons.exception;

/**
 * Generic exceptions caught during API operations should use {@link APIException},
 * making it clear that they were somehow expected and treated by the API.
 *
 * @author  Cristopher Zanchetta
 * @since   5.2.0 2017-10-07
 */
public class APIException extends RuntimeException {

    /**
     * @see RuntimeException#RuntimeException()
     */
    public APIException() {
        super();
    }

    /**
     * @param message   the exception message
     * @see             RuntimeException#RuntimeException(String)
     */
    public APIException(String message) {
        super(message);
    }

    /**
     * @param message   the exception message
     * @param cause     the exception cause
     * @see             RuntimeException#RuntimeException(String, Throwable)
     */
    public APIException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause the exception cause
     * @see         RuntimeException#RuntimeException(Throwable)
     */
    public APIException(Throwable cause) {
        super(cause);
    }
}
