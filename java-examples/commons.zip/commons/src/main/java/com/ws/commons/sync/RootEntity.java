package com.ws.commons.sync;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Denotes a Root Entity, the main entity of an use case.
 * 
 * @author Gustavo Bilert
 * @author Ivan Reffatti
 * @author Luiz Filho
 * @author Franciones Marmentini
 * @since  2016-04-06
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface RootEntity {

}
