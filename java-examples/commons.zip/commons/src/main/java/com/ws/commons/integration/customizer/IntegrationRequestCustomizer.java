package com.ws.commons.integration.customizer;

import feign.RequestTemplate;

/**
 * Integration client request customizer
 *
 * <p>This class enables simple customization of any integration request beign made, such as adding additional
 * headers or query parameters.</p>
 *
 * @author Lucas Dillman
 * @since 7.5.0, 2019-02-21
 */
public interface IntegrationRequestCustomizer {

    /**
     * Customizes the request prior to the call
     *
     * @param template Request template
     * @param clientDefinition Integration client in use
     */
    void customize(RequestTemplate template, Class<?> clientDefinition);
}
