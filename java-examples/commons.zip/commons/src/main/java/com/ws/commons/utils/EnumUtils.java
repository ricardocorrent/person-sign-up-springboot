package com.ws.commons.utils;

import com.ws.commons.server.json.EnumDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Utility class to handle with Enums. Mainly provides a method to deserialize an enumerator value.
 *
 * @author  Thyago Volpatto
 * @since   5.5.2 - 2018-02-26
 */
public final class EnumUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnumUtils.class);

    /**
     * Converts an Enum.
     *
     * @param <T>           as enum type
     * @param enumClass     the Enum class
     * @param enumValue     the value to be converted
     * @return              the converted enum.
     * @throws IOException  if conversion fails
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static <T extends Enum<T>> Enum<T> convert(final Class<T> enumClass, final String enumValue)  throws IOException{
        LOGGER.debug("Converting '{}' to '{}'", enumValue, enumClass.getName());

        EnumDeserializer enumDeserializer = new EnumDeserializer(enumClass);
        if (enumValue.matches("\\d+") ){
            return enumDeserializer.deserialize(Integer.parseInt(enumValue));
        } else {
            return enumDeserializer.deserialize(enumValue);
        }
    }
}
