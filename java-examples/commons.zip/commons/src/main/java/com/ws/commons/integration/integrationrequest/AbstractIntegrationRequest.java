package com.ws.commons.integration.integrationrequest;

import com.ws.commons.server.resource.HTTPHeaders;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.UnavailableSecurityManagerException;
import org.apache.shiro.session.Session;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PreDestroy;
import javax.inject.Inject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import static com.ws.commons.integration.Constants.*;

/**
 * Abstract class to execute HTTP requests with JAX-RS client API.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/04/19
 */
public abstract class AbstractIntegrationRequest {

    static final String INTEGRATION_ADDRESS = "integration.address";
    static final String INTEGRATION_ADDRESS_DEFAULT_VALUE = "http://heimdall";

    static final String INTEGRATION_TIMEOUT = "integration.timeout";
    static final String INTEGRATION_TIMEOUT_DEFAULT_VALUE = "180000";

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final String userRoleName = HTTPHeaders.USER_ROLE_INTEGRATION.getHeaderName();
    private final String userRoleValue = HTTPHeaders.USER_ROLE_INTEGRATION.getHeaderValue();

    private final String integrationAddress;
    private final Client client;

    private boolean propagateSession = true;

    @Inject
    public AbstractIntegrationRequest(
        @ConfigProperty(name = INTEGRATION_ADDRESS, defaultValue = INTEGRATION_ADDRESS_DEFAULT_VALUE) final String integrationAddress,
        @ConfigProperty(name = INTEGRATION_TIMEOUT, defaultValue = INTEGRATION_TIMEOUT_DEFAULT_VALUE) final Integer searchTimeout
    ) {
        this.integrationAddress = integrationAddress;
        this.client = ClientBuilder.newClient(new ClientConfig().property(ClientProperties.READ_TIMEOUT, searchTimeout)).register(MultiPartFeature.class);
    }

    /**
     * Close client instance.
     */
    @PreDestroy
    private void close() {
        client.close();
    }

    /**
     * Build an URL with "integration.address" environment variable value, path and rest query.
     *
     * @param path to concat
     * @param queryParams keys and values to add as rest query parameters
     *
     * @return URL.
     */
    protected String buildURL(final String path, final Map<String, String> queryParams) {
        final StringBuilder url = new StringBuilder().append(integrationAddress).append(path);

        if (queryParams != null && queryParams.size() > 0) {
            final StringBuilder restQueryBuilder = new StringBuilder();

            queryParams.forEach((key, value) -> {
                if (restQueryBuilder.length() > 0) {
                    restQueryBuilder.append(AMPERSAND);
                }

                try {
                    restQueryBuilder
                        .append(URLEncoder.encode(key, UTF_8))
                        .append(EQUALS)
                        .append(URLEncoder.encode(value, UTF_8));
                } catch (final UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            });

            url.append(path.contains(QUESTION_MARK) ? AMPERSAND : QUESTION_MARK).append(restQueryBuilder.toString());
        }

        return url.toString();
    }

    /**
     * Build the headers of the given request according with the given headers and {@link HTTPHeaders#USER_ROLE_INTEGRATION}.
     *
     * Also, if propagateSession is true, add a Cookie header with the JSESSIONID of the current user session.
     */
    protected void configureHeaders(
        final Invocation.Builder request,
        final Map<String, String> headers
    ) {
        try {
            if (propagateSession) {
                final Session session = SecurityUtils.getSubject().getSession(false);
                if (session != null) {
                    final String cookie = "JSESSIONID=" + session.getId().toString();
                    request.header(COOKIE, cookie);
                    logger.debug("Adding header to request: {}", cookie);
                }
            }
        } catch (final UnavailableSecurityManagerException exception) {
            logger.debug("No session available to get JSESSIONID.", exception);
        }

        if (headers != null) {
            headers.forEach((name, value) -> {
                request.header(name, value);
                logger.debug("Adding header to request: {}={}", name, value);
            });
        }

        // Identifies sync requests to allow access to internal resources.
        request.header(userRoleName, userRoleValue);
        logger.debug("Adding header to request: {}={}", userRoleName, userRoleValue);
    }

    /**
     * Executes a GET request.
     *
     * @param path to execute request
     *
     * @return Response.
     */
    public Response get(final String path) {
        return get(path, null);
    }

    /**
     * Executes a GET request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     *
     * @return Response.
     */
    public Response get(final String path, final Map<String, String> queryParams) {
        return get(path, queryParams, null, null);
    }

    /**
     * Executes a GET request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param headers to add to the request
     *
     * @return Response.
     */
    public Response get(
        final String path,
        final Map<String, String> queryParams,
        final Map<String, String> headers
    ) {
        return get(path, queryParams, null, headers);
    }

    /**
     * Executes a GET request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param mediaType of the request
     * @param headers to add to the request
     *
     * @return Response.
     */
    public Response get(
        final String path,
        final Map<String, String> queryParams,
        final MediaType mediaType,
        final Map<String, String> headers
    ) {
        final String url = buildURL(path, queryParams);
        logger.debug("GET request with URL: {}", url);
        final Invocation.Builder request = client.target(url).request(mediaType == null ? MediaType.APPLICATION_JSON_TYPE : mediaType);
        configureHeaders(request, headers);
        return request.get();
    }

    /**
     * Executes a HEAD request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param headers to add to the request
     *
     * @return Response.
     */
    public Response head(
        final String path,
        final Map<String, String> queryParams,
        final Map<String, String> headers
    ) {
        final String url = buildURL(path, queryParams);
        logger.debug("HEAD request with URL: {}", url);
        final Invocation.Builder request = client.target(url).request();
        configureHeaders(request, headers);
        return request.head();
    }

    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param data the request body
     *
     * @return Response.
     */
    public Response post(final String path, final Object data) {
        return post(path, null, null, null, data, null);
    }

    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     *
     * @return Response.
     */
    public Response post(final String path, final Map<String, String> queryParams) {
        return post(path, queryParams, null, null, null, null);
    }

    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param data the request body
     *
     * @return Response.
     */
    public Response post(
        final String path,
        final Map<String, String> queryParams,
        final Object data
    ) {
        return post(path, queryParams, null, null, data, null);
    }

    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param headers to add to the request
     * @param data the request body
     *
     * @return Response.
     */
    public Response post(
        final String path,
        final Map<String, String> queryParams,
        final Map<String, String> headers,
        final Object data
    ) {
        return post(path, queryParams, null, headers, data, null);
    }


    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param headers to add to the request
     * @param data the request body
     * @param dataMediaType media type of the body data
     *
     * @return Response.
     */
    public Response post(
        final String path,
        final Map<String, String> headers,
        final Object data,
        final MediaType dataMediaType
    ) {
        return post(path, null, null, headers, data, dataMediaType);
    }

    /**
     * Executes a POST request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param mediaType of the request
     * @param headers to add to the request
     * @param data the request body
     * @param dataMediaType media type of the body data
     *
     * @return Response.
     */
    public Response post(
        final String path,
        final Map<String, String> queryParams,
        final MediaType mediaType,
        final Map<String, String> headers,
        final Object data,
        final MediaType dataMediaType
    ) {
        final String url = buildURL(path, queryParams);
        logger.debug("POST request with URL: {}", url);
        final Invocation.Builder request = client.target(url).request(mediaType == null ? MediaType.APPLICATION_JSON_TYPE : mediaType);
        configureHeaders(request, headers);
        return request.post(Entity.entity(data, dataMediaType == null ? MediaType.APPLICATION_JSON_TYPE : dataMediaType));
    }

    /**
     * Executes a PUT request.
     *
     * @param path to execute request
     * @param data the request body
     *
     * @return Response.
     */
    public Response put(final String path, final Object data) {
        return put(path, null, null, null, data, null);
    }

    /**
     * Executes a PUT request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param data the request body
     *
     * @return Response.
     */
    public Response put(
        final String path,
        final Map<String, String> queryParams,
        final Object data
    ) {
        return post(path, queryParams, null, null, data, null);
    }

    /**
     * Executes a PUT request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param headers to add to the request
     * @param data the request body
     *
     * @return Response.
     */
    public Response put(
        final String path,
        final Map<String, String> queryParams,
        final Map<String, String> headers,
        final Object data
    ) {
        return post(path, queryParams, null, headers, data, null);
    }

    /**
     * Executes a PUT request.
     *
     * @param path to execute request
     * @param queryParams keys and values to add as rest query parameters
     * @param mediaType of the request
     * @param headers to add to the request
     * @param data the request body
     * @param dataMediaType media type of the body data
     *
     * @return Response.
     */
    public Response put(
        final String path,
        final Map<String, String> queryParams,
        final MediaType mediaType,
        final Map<String, String> headers,
        final Object data,
        MediaType dataMediaType
    ) {
        final String url = buildURL(path, queryParams);
        logger.debug("PUT request with URL: {}", url);
        final Invocation.Builder request = client.target(url).request(mediaType == null ? MediaType.APPLICATION_JSON_TYPE : mediaType);
        configureHeaders(request, headers);
        if (dataMediaType == null) {
            dataMediaType = MediaType.APPLICATION_JSON_TYPE;
        }
        final Entity<Object> entity = Entity.entity(data, dataMediaType);
        return request.put(entity);
    }

    /**
     * Executes a DELETE request.
     *
     * @param path to execute request
     *
     * @return Response.
     */
    public Response delete(final String path) {
        return delete(path, null);
    }

    /**
     * Executes a DELETE request.
     *
     * @param path to execute request
     * @param headers to add to the request
     *
     * @return Response.
     */
    public Response delete(
        final String path,
        final Map<String, String> headers
    ) {
        final String url = buildURL(path, null);
        logger.debug("DELETE request with URL: {}", url);
        final Invocation.Builder request = client.target(url).request();
        configureHeaders(request, headers);
        return request.delete();
    }

    /**
     * Check if the response is with JSON media type.
     *
     * @param response to check
     *
     * @return True if is JSON media type, false otherwise.
     */
    public boolean isJSON(final Response response) {
        final MediaType mediaType = response.getMediaType();
        return mediaType != null
            && MediaType.APPLICATION_JSON_TYPE.getType().equals(mediaType.getType())
            && MediaType.APPLICATION_JSON_TYPE.getSubtype().equals(mediaType.getSubtype());
    }

    /**
     * Check if is a successful response based on HTTP status 2xx.
     *
     * @param response to check
     *
     * @return True if is a successful response, false otherwise.
     */
    public boolean isSuccessful(final Response response) {
        final Response.Status.Family familyStatus = Response.Status.Family.familyOf(response.getStatus());
        return Response.Status.Family.SUCCESSFUL.compareTo(familyStatus) == 0;
    }

    /**
     * Parse the response body to a {@link JSONArray}.
     *
     * @param response to convert body
     *
     * @return A {@link JSONArray} if successfully parsed, null otherwise.
     */
    public JSONArray toJSONArray(final Response response) {
        if (isJSON(response)) {
            try {
                return new JSONArray(response.readEntity(String.class));
            } catch (final Exception exception) {
                logger.trace("Error to parse response entity to JSONObject.", exception);
            }
        }
        return null;
    }

    /**
     * Parse the response body to a {@link JSONObject}.
     *
     * @param response to convert body
     *
     * @return A {@link JSONObject} if successfully parsed, null otherwise.
     */
    public JSONObject toJSONObject(final Response response) {
        if (isJSON(response)) {
            try {
                return new JSONObject(response.readEntity(String.class));
            } catch (final Exception exception) {
                logger.trace("Error to parse response entity to JSONObject.", exception);
            }
        }
        return null;
    }

    /**
     * Setter to configure if is to propagate the JSESSIONID from the current session in requests COOKIE header.
     *
     * Default value is true.
     *
     * @param propagateSession Value to set for property 'propagateSession'.
     */
    public void setPropagateSession(boolean propagateSession) {
        this.propagateSession = propagateSession;
    }

}
