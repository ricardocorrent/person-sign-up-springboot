package com.ws.commons.integration;

import feign.Response;
import feign.Util;

import java.io.IOException;

/**
 * Exception class used to wrap all requests coming from Integration process.
 *
 * <p>This implementation is designed to decode an HTTP {@link Response} when {@link
 * Response#status()} is neither in the 2xx range or 404.</p>
 * <p>Based on {@link feign.FeignException}.</p>
 *
 * @author  Evaristo W. Benfatti
 * @since   4.0.0 - 2017-04-25
 */
public class IntegrationException extends RuntimeException {

    private static final long serialVersionUID = 0;
    private int status;

    IntegrationException(String message, Throwable cause) {
        super(message, cause);
    }

    IntegrationException(String message) {
        super(message);
    }

    IntegrationException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int status() {
        return this.status;
    }

    /**
     * Translates the {@link Response} object to a {@link IntegrationException}.
     *
     * @param methodKey called proxy method name
     * @param response  feign response
     * @return          translated exception
     */
    static IntegrationException errorStatus(final String methodKey, final Response response) {
        String message = String.format(
                "Received error response during integration proxy request. Status was %s while reading %s.",
                response.status(),
                methodKey
        );

        try {
            if (response.body() != null) {
                String body = Util.toString(response.body().asReader());
                message += "\nContent: " + body;
            }
        } catch (final IOException ignored) { // NOPMD

        }
        return new IntegrationException(response.status(), message);
    }
}
