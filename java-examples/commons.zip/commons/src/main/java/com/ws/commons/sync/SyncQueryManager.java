package com.ws.commons.sync;

import com.ws.commons.server.context.UserContext;
import io.ebean.Junction;
import io.ebean.Query;
import io.github.lukehutch.fastclasspathscanner.FastClasspathScanner;
import io.github.lukehutch.fastclasspathscanner.matchprocessor.ImplementingClassMatchProcessor;
import org.apache.deltaspike.core.api.provider.BeanProvider;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class to find the SyncQueries and add them to the standard query.
 *
 * @author      Gustavo Paulo Bilert
 * @author      Diego Peliser
 * @version     6.0.0 - 2018-03-23
 * @since       2016-11-30
 * @deprecated  This was deprecated because the query modifiers will be applied by sync microservice with rest query.
 */
@Deprecated
public class SyncQueryManager {

    /**
     * Adds the SyncQueries specified by the queryNames to the query.
     * The restrictions are combined with OR among them and with AND with default GET parameters.
     * @param query         the current query
     * @param queryNames    the query names
     * @param userContext   the user context
     * @param <T>           generic type
     */
    public static <T> void addNamedRestrictions(final Query<T> query, final List<String> queryNames, final UserContext userContext) {

        if(queryNames.size()>1){
            Junction<T> or = query.getExpressionFactory().disjunction(query);
            for (String queryName :queryNames) {
                SyncQuery syncQuery = BeanProvider.getContextualReference(queryName, false, SyncQuery.class);
                or.add(syncQuery.getQuery(query.getExpressionFactory(), userContext, query.getBeanType()));
            }
            or.endOr();
            query.where().add(or);
        }else{
            for (String queryName :queryNames) { // used for loop because it works for 0 or 1 entries

                SyncQuery syncQuery = BeanProvider.getContextualReference(queryName, false, SyncQuery.class);
                query.where().add(syncQuery.getQuery(query.getExpressionFactory(), userContext, SyncQuery.class));
            }
        }
    }

    /**
     * Finds all classes implementing SyncQuery with the @Named annotation on the classpath.
     * It is intended as a data source to implement a view for choosing the desired queries.
     *
     * @return the bean names specified in the @Named annotations
     */
    public static List<String> findAnnotatedQueries(){
        final List<String> names = new ArrayList<>();

        FastClasspathScanner scanner = new FastClasspathScanner();
        scanner.matchClassesImplementing(SyncQuery.class, new ImplementingClassMatchProcessor<SyncQuery>() {
            @Override
            public void processMatch(Class<? extends SyncQuery> implementingClass) {
                Named annotation = implementingClass.getAnnotation(Named.class);
                if(annotation!=null) {
                    names.add(annotation.value());
                }
            }
        }).scan();

        return names;
    }
}
