package com.ws.commons.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.ws.rs.core.Response;
import feign.jackson.JacksonDecoder;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import org.apache.commons.io.IOUtils;
import org.apache.http.impl.io.EmptyInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Custom Feign response decoder using {@link JacksonDecoder} as the base implementation responsible to translate
 * Feign responses to JAX-RS responses when integration client interface uses JAX-RS API.
 *
 * @author  Lucas Dillmann
 * @since   7.4.0 - 2018-12-10
 */
final class FeignResponseDecoder extends JacksonDecoder {

    private final Logger logger;

    /**
     * Constructor with {@link ObjectMapper} initialization.
     *
     * @param mapper an {@link ObjectMapper}
     */
    FeignResponseDecoder(final ObjectMapper mapper) {
        super(mapper);
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Decodes Feign response to the target response type.
     *
     * @param sourceResponse    feign response
     * @param responseType      target type for the translation
     * @return                  translated object
     * @throws IOException      when translation fails
     */
    @Override
    public Object decode(final feign.Response sourceResponse, final Type responseType) throws IOException {
        if (Response.class.equals(responseType)) {
            logger.debug("Converting Feign response to JAX-RS response");
            final Response.ResponseBuilder translatedResponse = Response.status(sourceResponse.status());

            sourceResponse
                    .headers()
                    .forEach((name, value) -> value.forEach(val -> translatedResponse.header(name, val)));

            boolean bodyFound = false;
            final feign.Response.Body responseBody = sourceResponse.body();
            if (responseBody != null) {
                final InputStream inputStream = responseBody.asInputStream();
                if (inputStream != null) {
                    translatedResponse.entity(IOUtils.toBufferedInputStream(inputStream));
                    bodyFound = true;
                }
            }

            if(!bodyFound) {
                translatedResponse.entity(EmptyInputStream.INSTANCE);
            }

            return translatedResponse.build();
        }

        return super.decode(sourceResponse, responseType);
    }

}
