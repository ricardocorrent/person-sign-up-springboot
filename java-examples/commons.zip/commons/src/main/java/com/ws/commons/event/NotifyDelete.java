package com.ws.commons.event;

import javax.interceptor.InterceptorBinding;
import java.lang.annotation.*;

/**
 * Interceptor annotation to automatically fire a @{@link Deleted} event when the method is invoked.
 *
 * @author  Gustavo P. Bilert
 * @since   2017-04-28
 */
@Inherited
@InterceptorBinding
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface NotifyDelete {
}

