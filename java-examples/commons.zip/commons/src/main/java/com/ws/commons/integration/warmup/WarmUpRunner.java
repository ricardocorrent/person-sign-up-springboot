package com.ws.commons.integration.warmup;

import com.ws.commons.integration.ResponseUtils;
import com.ws.commons.integration.integrationrequest.IntegrationRequest;
import com.ws.commons.integration.tenants.InjectTenants;
import com.ws.commons.persistence.restquery.OrderBy;
import com.ws.commons.persistence.restquery.OrderByDirection;
import com.ws.commons.persistence.restquery.RestQueryUrlBuilder;
import com.ws.commons.server.pagination.PaginationSearch;
import com.ws.commons.server.sessioncreator.SessionCreator;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.weld.environment.se.events.ContainerInitialized;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ws.commons.integration.Constants.*;

/**
 * Runner for all instances of {@link WarmUp} produced by {@link WarmUpProducer} when the CDI container is initialized.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/14/19
 */
@ApplicationScoped
public class WarmUpRunner {

    private static final String WARM_UP_ENABLED = "warm.up.enabled";
    private static final String WARM_UP_ENABLED_DEFAULT_VALUE = "false";

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final Instance<WarmUp<?>> warmUpInstances;
    private final boolean warmUpEnabled;
    private final SessionCreator sessionCreator;
    private final IntegrationRequest integration;
    private final Instance<List<String>> tenantsProvider;

    @Inject
    public WarmUpRunner(
        @Any final Instance<WarmUp<?>> warmUpInstances,
        @ConfigProperty(name = WARM_UP_ENABLED, defaultValue = WARM_UP_ENABLED_DEFAULT_VALUE) final boolean warmUpEnabled,
        final SessionCreator sessionCreator,
        final IntegrationRequest integration,
        @InjectTenants final Instance<List<String>> tenantsProvider
    ) {
        this.warmUpInstances = warmUpInstances;
        this.warmUpEnabled = warmUpEnabled;
        this.sessionCreator = sessionCreator;
        this.integration = integration;
        this.tenantsProvider = tenantsProvider;
    }

    /**
     * Build the rest query for the warm up requests.
     *
     * @param page of the paged list
     * @param optionalRestQueryParams to add to the map
     *
     * @return IntegrationRestQuery for requests.
     */
    private Map<String, String> buildRestQuery(final int page, final String optionalRestQueryParams) {
        final Map<String, String> map = new HashMap<>();

        String params = new RestQueryUrlBuilder()
            .noCount()
            .pageSize(PaginationSearch.DEFAULT_PAGESIZE)
            .page(page)
            .orderBy(new OrderBy(CREATED_AT, OrderByDirection.ASC))
            .orderBy(new OrderBy(ID, OrderByDirection.ASC))
            .getUrlQueryParams();
        if (optionalRestQueryParams != null) {
            params += optionalRestQueryParams;
        }

        map.put(REST_QUERY, params);
        return map;
    }

    /**
     * Run the data integration with a service resource for a specific tenant.
     *
     * It is important to have in mind that the data is got page by page,
     * which means that it can change in the source service from a page to another.
     */
    private <T> void run(final WarmUp<T> warmUp) {
        logger.info("Starting warm-up {} at path {}", warmUp.getDataClass().getSimpleName(), warmUp.getPath());

        final List<String> tenants = tenantsProvider.get();
        try {
            tenants.forEach(tenant -> handleTenant(tenant, warmUp));
        } finally {
            tenantsProvider.destroy(tenants);
        }
    }

    /**
     * @param tenant Tenant ID
     * @param warmUp WarmUp parameters
     */
    private <T> void handleTenant(final String tenant, final WarmUp<T> warmUp) {

        try {
            logger.debug("Tenant: {}", tenant);
            sessionCreator.create(tenant);

            int page = 0;
            int size;

            do {
                final Map<String, String> restQuery = buildRestQuery(page, warmUp.getRestQueryParams());
                final Response response = integration.get(warmUp.getPath(), restQuery);

                if (integration.isSuccessful(response)) {
                    final Map pagedList = response.readEntity(Map.class);
                    final List<T> items = ResponseUtils.convertEntityAsList(pagedList.get(ITEMS), warmUp.getDataClass());

                    size = items.size();

                    if (items.isEmpty()) {
                        logger.debug("No messages");
                        break;
                    } else {
                        if (warmUp.process(items)) {
                            logger.debug("Page {} successfully processed", page);
                        } else {
                            logger.debug("Page {} not processed", page);
                        }
                    }
                } else {
                    logger.debug("Response error with HTTP status {} for page {}. Stopping warm up.", response.getStatus(), page);
                    size = 0;
                }
                page++;
                response.close();
            } while (PaginationSearch.DEFAULT_PAGESIZE == size);
        } catch (final Exception exception) {
            logger.error("Unexpected error running warm up", exception);
        }
    }

    /**
     * Runs warm up when the CDI container is initialized and if is enabled.
     *
     * @param event CDI event fired when CDI contained is initialized
     */
    public void registerJobs(@Observes final ContainerInitialized event) {
        logger.info("Warm Up enabled: {}", warmUpEnabled);
        if (warmUpEnabled && !warmUpInstances.isUnsatisfied()) {
            logger.info("Starting warm-up jobs");
            warmUpInstances.forEach(this::run);
            logger.info("Warm-up jobs completed");
        }
    }

}
