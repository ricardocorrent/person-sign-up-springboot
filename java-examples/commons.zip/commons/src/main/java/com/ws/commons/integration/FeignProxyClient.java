package com.ws.commons.integration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.integration.proxytextension.ProxyClient;
import com.ws.commons.server.json.ObjectMapperResolver;
import feign.Feign;
import feign.RequestInterceptor;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import feign.jaxrs.JAXRSContract;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default {@link ProxyClient}. The implementation creates a Feign proxy obeying the {@link JAXRSContract},
 * {@link JacksonEncoder} and {@link JacksonDecoder}. Additionally, a {@link RequestInterceptor} is defined to forward
 * the session.
 *
 * @author  Evaristo W. Benfatti
 * @since   4.0.0 - 2016-12-28
 */
@Default
public class FeignProxyClient implements ProxyClient {

    private static final String INTEGRATION_ADDRESS = "integration.address";
    private static ObjectMapper encoder;
    private static ObjectMapper decoder;

    @Inject
    private Instance<FeignRequestCustomizer> requestCustomizerProvider;

    @Inject
    @ConfigProperty(name = INTEGRATION_ADDRESS)
    private String integrationAddress;

    private final Logger logger = LoggerFactory.getLogger(getClass());

    static ObjectMapper getDecoder() {
        if (decoder == null) {
            decoder = ObjectMapperResolver
                    .getInstance()
                    .createMapper()
                    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        }

        return decoder;
    }

    static ObjectMapper getEncoder() {
        if (encoder == null) {
            encoder = ObjectMapperResolver
                    .getInstance()
                    .createMapper();
        }

        return encoder;
    }

    /**
     * Creates a proxy instance for {@code clazz}.
     *
     * @param clazz the class the proxy will be built
     * @param <T>   generic type
     * @return      a proxy instance for the desired class
     */
    @Override
    public <T> T proxy(final Class<T> clazz) {
        logger.debug("Creating a proxy instance for {}", clazz.getName());
        final FeignRequestCustomizer requestCustomizer = requestCustomizerProvider.get();
        requestCustomizer.setClientDefinition(clazz);

        return Feign
                .builder()
                .contract(new JAXRSContract())
                .encoder(new JacksonEncoder(getEncoder()))
                .decoder(new FeignResponseDecoder(getDecoder()))
                .requestInterceptor(requestCustomizer)
                .decode404()
                .errorDecoder(IntegrationException::errorStatus)
                .target(clazz, integrationAddress);

    }
}
