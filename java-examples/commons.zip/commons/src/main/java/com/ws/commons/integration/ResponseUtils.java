package com.ws.commons.integration;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Util class needed to convert the Response Entity according expected model.
 *
 * @author  Evaristo W Benfatti
 * @since   4.0.0 - 2017-02-20
 */
public class ResponseUtils {

    private ResponseUtils() {}

    /**
     * Retrieves an entity from {@link FeignProxyClient}.
     *
     * @param response  the response
     * @param clazz     the corresponding class
     * @param <T>       generic type
     * @return          the desired entity
     */
    public static <T> T getEntity(Response response, Class<T> clazz) {
        try {
            return FeignProxyClient
                    .getDecoder()
                    .readValue((InputStream) response.getEntity(), clazz);
        } catch (IOException e) {
            throw new RuntimeException("Failure at entity reading/converting.", e);
        }
    }

    /**
     * Retrieves an entity as map from {@link FeignProxyClient}.
     *
     * @param response  the current response
     * @return          an entity as {@link Map}
     */
    public static Map getEntityAsMap(Response response) {
        return getEntity(response, Map.class);
    }

    /**
     * Converts an {@code objectToConvert} to another {@code clazz} using {@link ObjectMapper}
     * @param objectToConvert   object to be converted
     * @param clazz             target class
     * @param <T>               generic type
     * @return                  converted object
     */
    public static <T> T convertEntity(Object objectToConvert, Class<T> clazz) {
        return FeignProxyClient
                .getDecoder()
                .convertValue(objectToConvert, clazz);
    }

    /**
     * Converts a list of objects {@code objectToConvert} to another {@code clazz} using {@link ObjectMapper}
     * @param objectToConvert                   list of objects to convert
     * @param clazz                             target class
     * @param <T>                               generic type
     * @return                                  a list of converted objects
     * @throws UnsupportedOperationException    if {@code objectToConvert} is not an instance of a {@link List}
     */
    public static <T> List<T> convertEntityAsList(Object objectToConvert, Class<T> clazz) {
        if (!(objectToConvert instanceof List)) {
            throw new UnsupportedOperationException("Type conversion unsupported.");
        }

        return ((List<?>) objectToConvert).stream()
                .map(item -> convertEntity(item, clazz))
                .collect(Collectors.toList());
    }
}
