package com.ws.commons.interceptor.log.context;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Singleton;
import java.util.Objects;
import java.util.Optional;

/**
 * Utility class for simple management of mapped diagnostic context.
 *
 * <p>This class provides a simple set of methods for MDC related operations. MDC refers to Mapped Diagnostic Context,
 * which are key-value pairs of information used in log messages to help understand whats happening with the application
 * while it's running.</p>
 *
 * <p>All pairs of information created are bound only to current request (thread). It means that is safe to publish
 * request scoped data like the ID of the entity being processed, just be sure to not overflow with disposable values
 * that don't really help understanding what's happening.</p>
 *
 * @author  Lucas Dillmann
 * @since   7.4.0 - 2018-12-11
 */
@Singleton
public final class LogContext {

    private final Logger logger;

    /**
     * Constructor with {@link Logger} initialization.
     *
     * @param logger Logger
     */
    public LogContext(final Logger logger) {
        this.logger = logger;
    }

    /**
     * Default constructor
     */
    public LogContext() {
        this(LoggerFactory.getLogger(LogContext.class));
    }

    /**
     * Sets or updates a property under the log context.
     *
     * @param key   property key
     * @param value property value
     */
    public void setProperty(final String key, final String value) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(value);

        ThreadContext.put(key, value);
        logger.debug("MDC property '{}' set with value '{}'", key, value);
    }

    /**
     * Removes a property from the log context.
     *
     * @param key Property key
     */
    public void removeProperty(final String key) {
        Objects.requireNonNull(key);
        ThreadContext.remove(key);
        logger.debug("MDC property '{}' removed", key);
    }

    /**
     * Returns current context value for a property.
     *
     * @param key   property key
     * @return      property value
     */
    public Optional<String> getProperty(final String key) {
        Objects.requireNonNull(key);
        return Optional.ofNullable(ThreadContext.get(key));
    }

    /**
     * Removes all properties from current context.
     */
    public void clear() {
        ThreadContext.clearAll();
        logger.debug("All MDC properties removed");
    }

}
