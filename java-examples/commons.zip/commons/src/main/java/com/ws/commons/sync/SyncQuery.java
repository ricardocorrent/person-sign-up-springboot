package com.ws.commons.sync;

import com.ws.commons.server.context.UserContext;
import io.ebean.Expression;
import io.ebean.ExpressionFactory;

/**
 * Implementations of this class define a query fragment to be used by sync queries.
 * <p>
 * Each sync query should represent only one restriction, for example, if you need to retrieve Customers by Branch and User,
 * there would be one SyncQuery for Customer by Branch, and another for Customer by User, then the configuration would
 * say to use the two of them.
 *</p>
 *
 * @author      Gustavo Paulo Bilert
 * @author      Diego Peliser
 * @version     6.0.0 - 2018-03-23
 * @since       2016-11-28
 * @deprecated  this was deprecated because the query modifiers will be applied by sync microservice with rest query.
 */
public interface SyncQuery {

    /**
     * Returns the expression to be added to the query, this method must not modify anything.
     * @param exp           an {@link ExpressionFactory} object
     * @param userContext   the user context
     * @param entity        the base entity to retrieve the query
     * @return              a query expression
     */
    Expression getQuery(ExpressionFactory exp, UserContext userContext, Class entity);
}
