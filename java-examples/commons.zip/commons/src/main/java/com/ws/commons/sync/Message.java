package com.ws.commons.sync;

/**
 * Entity that defines a message.
 *
 * @author  Gustavo Bilert
 * @since   2016-08-29
 */
@RootEntity
public class Message {

    private String changeType;
    private String entity;
    private byte[] data;

    /**
     * Constructor with {@code changeType}, {@code entity} and {@code data} initialization.
     *
     * @param changeType the message change type
     * @param entity     an entity
     * @param data       the message data
     */
    public Message(String changeType, String entity, byte[] data) {
        this.changeType = changeType;
        this.entity = entity;
        this.data = data;
    }

    /**
     * Default constructor.
     */
    public Message() {
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
