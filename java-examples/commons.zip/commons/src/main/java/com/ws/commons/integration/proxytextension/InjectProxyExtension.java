package com.ws.commons.integration.proxytextension;

import com.google.common.collect.Sets;
import com.ws.commons.integration.FeignProxyClient;
import org.apache.deltaspike.core.util.bean.BeanBuilder;
import org.apache.deltaspike.core.util.metadata.builder.AnnotatedTypeBuilder;
import org.apache.deltaspike.core.util.metadata.builder.ContextualLifecycle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.Dependent;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.inject.spi.*;
import javax.enterprise.util.AnnotationLiteral;
import javax.inject.Inject;
import javax.inject.Scope;
import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <p>Extension used to process {@link InjectProxy} annotation. When an {@linkplain InjectProxy} annotation is used a
 * proxy class is supplied. Such class is responsible for the translation of the interface calls to the proxy calls. This abstraction allows
 * the developer to inject the interface and use their methods in a RPC like way.</p>
 *
 * <p>To use this extension a Producer {@link ProxyClient} must be specified. For API calls over REST protocol a default
 * Producer is delivered at {@link FeignProxyClient}.</p>
 *
 * <p>The extension put the {@linkplain Inject} annotation automatically on the injection point, all CDI concerns are
 * treated by it.</p>
 *
 * @author  Evaristo W. Benfatti
 * @since   4.0.0 - 2016-12-29
 */
@Vetoed
public class InjectProxyExtension implements Extension {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final HashMap<Class<?>, Set<Set<Annotation>>> qualifierSetsPerInjectProxyClassInjectionPoints = new HashMap<>();

    /**
     * Observer {@link ProcessAnnotatedType} event method responsible to amend the {@linkplain Inject} annotation to every
     * {@linkplain InjectProxy} points, turning them as inject points.
     *
     * @param pat a {@link ProcessAnnotatedType} event
     * @param <X> generic type
     */
    public <X> void processInjectProxyAnnotation(@Observes ProcessAnnotatedType<X> pat) {

        final AnnotatedType<X> annotatedType = pat.getAnnotatedType();

        final Set<AnnotatedField<? super X>> injectProxyFields = annotatedType.getFields().stream()
                .filter(field -> field.isAnnotationPresent(InjectProxy.class))
                .collect(Collectors.toSet());

        if (!injectProxyFields.isEmpty()) {

            injectProxyFields.forEach(field -> logger.debug(
                    "Integration client injection detected in field '{}' of '{}'",
                    field.getJavaMember().getName(),
                    field.getJavaMember().getDeclaringClass().getName()
            ));
            final AnnotatedTypeBuilder<X> annotatedTypeBuilder = new AnnotatedTypeBuilder<X>()
                    .readFromType(annotatedType.getJavaClass());

            injectProxyFields.forEach(annotatedField -> annotatedTypeBuilder.addToField(annotatedField, new AnnotationLiteral<Inject>() {}));

            pat.setAnnotatedType(annotatedTypeBuilder.create());
        }
    }

    /**
     * Observer ProcessInjectionPoint event method which is responsible to process all {@link InjectProxy} inject points.
     * <p>All desired proxy are scanned and their qualifiers and mapped to the after bean proxy constructing process.</p>
     *
     * @param pip           a {@link ProcessInjectionPoint} event
     * @param beanManager   injected to test annotation qualifier
     */
    public void processInjectProxyInjectPoints(@Observes final ProcessInjectionPoint<?, ?> pip, final BeanManager beanManager) {

        final InjectionPoint injectionPoint = pip.getInjectionPoint();
        final Annotated annotated = injectionPoint.getAnnotated();

        if (annotated.isAnnotationPresent(InjectProxy.class)) {

            if (!Class.class.isInstance(injectionPoint.getType()))
                throw new UnsupportedOperationException("Unsupported Type Integration Proxy.");

            final Class<?> clazz = (Class<?>) injectionPoint.getType();

            final Set<Annotation> qualifiers = annotated.getAnnotations().stream()
                    .filter(annotation -> beanManager.isQualifier(annotation.annotationType()))
                    .collect(Collectors.toSet());

            Set<Set<Annotation>> qualifierSetPerInjectProxyInjectionPoint = qualifierSetsPerInjectProxyClassInjectionPoints.get(clazz);
            if (qualifierSetPerInjectProxyInjectionPoint == null) {
                qualifierSetPerInjectProxyInjectionPoint = new LinkedHashSet<>();
                qualifierSetsPerInjectProxyClassInjectionPoints.put(clazz, qualifierSetPerInjectProxyInjectionPoint);
            }
            qualifierSetPerInjectProxyInjectionPoint.add(qualifiers);
        }
    }

    /**
     * Observer {@link AfterBeanDiscovery} event method responsible to delegate the creating bean proxy according to proxy class
     * and qualifier defined for each inject point configuration.
     *
     * @param afterBeanDiscovery    event
     * @param beanManager           used to build the bean.
     */
    public void createInjectProxyBeans(@Observes final AfterBeanDiscovery afterBeanDiscovery, final BeanManager beanManager) {

        qualifierSetsPerInjectProxyClassInjectionPoints.forEach((proxyClass, qualifierSetsFromProxyClass) ->
            qualifierSetsFromProxyClass.forEach(qualifierSet -> afterBeanDiscovery.addBean(
                    createInjectProxyTypedBean(beanManager, proxyClass, qualifierSet))));
    }

    /**
     * Private method extracted to allow the creation of a typed bean with templates instead of creating over an Object.
     *
     * <p>The proxy instance is created by {@link ProxyClient} producer class.</p>
     *
     * @param beanManager   used to build the bean
     * @param clazz         proxy interface class
     * @param qualifiers    set of qualifiers for an particular inject point configuration
     * @param <X>           the inferring type
     * @return              a Bean built to manage the proxying calls
     */
    private <X> Bean<X> createInjectProxyTypedBean(final BeanManager beanManager, final Class<X> clazz, final Set<Annotation> qualifiers) {

        logger.debug("Creating a dynamic integration proxy CDI bean for class {}", clazz.getName());
        final BeanBuilder<X> typedProxyBeanBuilder = new BeanBuilder<X>(beanManager)
                .beanClass(clazz)
                .injectionPoints(Collections.emptySet())
                .nullable(false)
                .types(Sets.newHashSet(clazz))
                .qualifiers(qualifiers.isEmpty() ? Sets.newHashSet(new AnnotationLiteral<Default>() {}) : qualifiers)
//                .scope(ApplicationScoped.class)
                .scope(Stream.of(clazz.getAnnotations())
                        // Explicit type inferring to workaround .orElse() cast problem
                        .<Class<? extends Annotation>>map(Annotation::getClass)
                        .filter(annotationClass -> annotationClass.getAnnotation(Scope.class) != null)
                        .findAny()
                        .orElse(Dependent.class))
                .name(null)
                .stereotypes(Collections.emptySet())
                .beanLifecycle(new ContextualLifecycle<X>() {
                    @Override
                    public X create(Bean beanIgnored, CreationalContext creationalContext) {
                        final Annotation[] qualifiersElegible = qualifiers.stream().toArray(Annotation[]::new);

                        final Set<Bean<?>> beans = beanManager.getBeans(ProxyClient.class, qualifiersElegible);
                        final Bean<?> bean = beanManager.resolve(beans);
                        final ProxyClient instance = (ProxyClient) beanManager.getReference(bean, ProxyClient.class, creationalContext);

                        logger.debug("Creating a dynamic integration proxy instance for class {}", clazz.getName());
                        return instance.proxy(clazz);
                    }

                    @Override
                    public void destroy(Bean bean, Object instance, CreationalContext creationalContext) {
                        // NO-OP
                    }
                });
        return typedProxyBeanBuilder.create();
    }
}
