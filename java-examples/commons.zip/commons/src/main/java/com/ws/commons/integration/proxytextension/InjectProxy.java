package com.ws.commons.integration.proxytextension;

import java.lang.annotation.*;

/**
 * InjectProxy annotation.
 * <p>Whenever an injection point is annotated with, it turns eligible to be proxied by {@link InjectProxyExtension}.</p>
 *
 * @author  Evaristo W. Benfatti
 * @since   4.0.0 - 2017-01-06
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface InjectProxy {
}
