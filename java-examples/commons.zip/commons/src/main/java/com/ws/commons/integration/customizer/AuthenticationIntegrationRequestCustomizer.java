package com.ws.commons.integration.customizer;

import feign.RequestTemplate;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Default;
import java.util.Optional;

/**
 * {@link IntegrationRequestCustomizer} implementation for authentication cookie forward
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-21
 */
@Default
public class AuthenticationIntegrationRequestCustomizer implements IntegrationRequestCustomizer {

    private static final String COOKIE_NAME = "JSESSIONID";
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationIntegrationRequestCustomizer.class);

    /**
     * Customizes the request prior to the call
     *
     * @param template         Request template
     * @param clientDefinition Integration client in use
     */
    @Override
    public void customize(final RequestTemplate template, final Class<?> clientDefinition) {
        final Subject subject = SecurityUtils.getSubject();
        if (subject == null || !subject.isAuthenticated()) return;

        Optional.ofNullable(subject.getSession(false))
                .ifPresent(session -> {
                    LOGGER.debug("Injecting session with ID {} into proxy request", session.getId());
                    final String cookieHeaderValue = COOKIE_NAME + "=" + session.getId().toString();
                    template.header("Cookie", cookieHeaderValue);
                });
    }
}
