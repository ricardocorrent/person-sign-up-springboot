package com.ws.commons.interceptor;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.ws.commons.event.PATCH;
import com.ws.commons.interceptor.exception.InterceptionException;
import com.ws.commons.interceptor.patch.PatchHandler;
import com.ws.commons.interceptor.patch.PatchHandlerFactory;
import com.ws.commons.mediatypes.CustomMediaTypes;
import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.server.ApplicationConfig;
import com.ws.commons.server.DefaultConfig;
import com.ws.commons.server.json.*;
import com.ws.commons.server.resource.IDTOResourceBatchPatch;
import com.ws.commons.server.resource.IDTOResourcePatch;
import com.ws.commons.server.resource.IResourceBatchPatch;
import com.ws.commons.server.resource.IResourcePatch;
import com.ws.commons.server.validation.exception.LogicException;
import com.ws.commons.server.validation.exception.MessageException;
import com.ws.commons.server.validation.exception.RegisterNotFoundException;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.ReaderInterceptor;
import javax.ws.rs.ext.ReaderInterceptorContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.temporal.Temporal;

/**
 * {@link ReaderInterceptor} implemenation to support {@link PATCH} operations over
 * {@link BaseModel} or {@link BaseDTO}. Check out {@link DefaultConfig} or
 * {@link ApplicationConfig} for instructions to register this ReaderInterceptor.
 *
 * <br><br>
 *
 * <strong>Important note about this implementation: </strong> All operations follow
 * <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a> (JSON Patch) or
 * <a href="https://tools.ietf.org/html/rfc7386">RFC 7386</a> (JSON Merge Patch).
 *
 * <br><br>
 *
 * This class supports {@link PATCH} operations over a single entity or DTO
 * using both JSON Patch and JSON Merge Patch. Support for {@link PATCH} operations
 * over a collection of entities or DTOs is only available using JSON Merge Patch since
 * the original collection can came from any GET method inside resource and
 * there's no direct way to identify object (like using it's ID) when using JSON Patch
 * (RFC 6902).
 *
 * <br><br>
 *
 * When the original content type for JSON (application/json) is sent on a {@link PATCH} request
 * this class will automatically use JSON Merge Patch strategy (application/merge-patch+json).
 *
 * <br><br>
 * <strong>Known issues (when using default PATCH implementations)</strong> <br>
 * Current implementation has the following know issues to be fixed in future releases:
 * <br>
 * - Deletion of children objects when using JSON Merge Patch isn't available yet. To do so, invoke
 *   the DELETE method on the entity/dto resource.<br>
 *
 * @author      Dante C. Basso Filho
 * @author      Diego A. Costa
 * @author      Lucas Dillmann
 * @version     2018-04-03 - 6.0.0
 * @version     2018-06-25 - 6.1.0
 * @see         IResourcePatch
 * @see         IResourceBatchPatch
 * @see         IDTOResourcePatch
 * @see         IDTOResourceBatchPatch
 * @see         <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a>
 * @see         <a href="https://tools.ietf.org/html/rfc7386">RFC 7386</a>
 * @since       2017-05-19 - 4.8.0
 * @deprecated  7.5.0, 2019-01-11 - Deprecation of the class. Use implementation from module commons-server-patch-api instead
 */
@PATCH
@Provider
@RequestScoped
@Deprecated
public class PatchReaderInterceptor implements ReaderInterceptor {

    private final Logger logger = LoggerFactory.getLogger(PatchReaderInterceptor.class);

    private UriInfo uriInfo;
    private ResourceInfo resourceInfo;

    @Inject
    private PatchHandlerFactory handlerFactory;

    public PatchReaderInterceptor() {
        // NO-OP
    }

    /**
     * Gets the context URI metadata.
     *
     * @param uriInfo from context.
     */
    @Context
    public void setInfo(final UriInfo uriInfo) {
        this.uriInfo = uriInfo;
    }

    /**
     * Gets the context URI metadata.
     *
     * @param resourceInfo from context.
     */
    @Context
    public void setResourceInfo(final ResourceInfo resourceInfo) {
        this.resourceInfo = resourceInfo;
    }

    /**
     * Process every {@link PATCH} request and executes the changes over a single entity
     * or a collection of {@link BaseModel} or {@link BaseDTO}.
     *
     * <p>This method supports both <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a>
     * (JSON Patch) and <a href="https://tools.ietf.org/html/rfc7386">RFC 7386</a> (JSON Merge Patch).</p>
     *
     * @author  Lucas Dillmann
     * @see     <a href="https://tools.ietf.org/html/rfc7386">RFC 7386</a>
     * @see     <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a>
     */
    @PATCH
    @Override
    public Object aroundReadFrom(final ReaderInterceptorContext interceptorContext) throws IOException {

        logger.debug("PATCH request received. Starting the request execution.");

        // validate request content-type
        String contentType = interceptorContext.getHeaders().getFirst("Content-Type");
        logger.debug("Detected content type is {}", contentType);
        if (contentType == null) {
            throw new MessageException("patch.invalid.header", HttpStatus.SC_UNSUPPORTED_MEDIA_TYPE);
        }

        if (contentType.contains(";")) {
            contentType = contentType.split(";")[0];
        }

        if (MediaType.APPLICATION_JSON.equals(contentType)) {
            logger.debug("Content type is a regular JSON content type. This request will be executed as a JSON Merge Patch.");
            contentType = CustomMediaTypes.APPLICATION_MERGE_PATCH_JSON;
        }

        try {
            final ObjectMapper objectMapper = getConfiguredMapper();

            // Run the patch
            final PatchHandler handler = handlerFactory
                    .createHandler(contentType, resourceInfo, uriInfo, interceptorContext, objectMapper);

            logger.debug("Starting the request processing using handler {}", handler.getClass().getName());
            final JsonNode result = handler.handleRequest();

            // Replace the InputStream from request to the patched content
            final byte[] newRequestContent = objectMapper.writeValueAsBytes(result);
            interceptorContext.setInputStream(new ByteArrayInputStream(newRequestContent));

            logger.debug("Patch procedures completed. Returning request over to JAX-RS again.");
        } catch (JsonMappingException ex) {
            logger.warn("Failed to read JSON sent by client", ex);
            throw new MessageException("patch.invalid.content", HttpStatus.SC_BAD_REQUEST, ex);
        } catch (MessageException | RegisterNotFoundException | InterceptionException | LogicException ex) {
            throw ex;
        } catch (Exception ex) {
            logger.warn("Failed to execute PATCH", ex);
            throw new WebApplicationException(ex.getMessage(), ex);
        }

        // Continue the request to the next step
        return interceptorContext.proceed();
    }

    /**
     * Retrieves an {@link ObjectMapper} instance registered with custom serializers and deserializers.
     *
     * @author  Diego A. Costa
     * @return  the mapper with default serializers and deserializers.
     * @since   5.4.2 - 2018-01-25
     */
    @SuppressWarnings({"deprecation"})
    private ObjectMapper getConfiguredMapper() {
        /*
         * In a future branch there will be an implementation that will resolve this scenario, leaving this method redundant or obsolete.
         * https://gitlab.wssim.com.br/platform/commons/issues/180
         * */
        final ObjectMapper mapper = new ObjectMapper();
        final Version version = new Version(1, 0, 0, null, null, null);
        final SimpleModule module = new SimpleModule("module", version);

        module.addSerializer(Temporal.class, new TemporalSerializer());
        module.addDeserializer(String.class, new StringDeserializer());
        module.addDeserializer(LocalDate.class, new LocalDateDeserializer());
        module.addDeserializer(LocalTime.class, new LocalTimeDeserializer());
        module.addDeserializer(OffsetDateTime.class, new OffsetDateTimeDeserializer());
        module.addDeserializer(OffsetTime.class, new OffsetTimeDeserializer());

        mapper.registerModule(module);

        return mapper;
    }
}
