package com.ws.commons.integration.integrationrequest;

import org.apache.deltaspike.core.api.config.ConfigProperty;

import javax.inject.Inject;

/**
 * Utility class to execute HTTP requests with JAX-RS client API.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/04/19
 */
public class IntegrationRequest extends AbstractIntegrationRequest {

    @Inject
    public IntegrationRequest(
        @ConfigProperty(name = INTEGRATION_ADDRESS, defaultValue = INTEGRATION_ADDRESS_DEFAULT_VALUE) final String integrationAddress,
        @ConfigProperty(name = INTEGRATION_TIMEOUT, defaultValue = INTEGRATION_TIMEOUT_DEFAULT_VALUE) final Integer searchTimeout
    ) {
        super(integrationAddress, searchTimeout);
    }

}
