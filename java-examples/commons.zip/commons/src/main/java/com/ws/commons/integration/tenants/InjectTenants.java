package com.ws.commons.integration.tenants;

import java.lang.annotation.*;

/**
 * Annotation to inject a list of available tenants from cloud-manager produced by {@link TenantsProducer}.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/14/19
 */
@Target({ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface InjectTenants {
}
