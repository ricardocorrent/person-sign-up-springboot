package com.ws.commons.configuration;

import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.PropertyFileConfig;
import org.apache.deltaspike.core.impl.config.MapConfigSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * This class gives support to YAML configuration files.
 *
 * @author  Maykon Rissi
 * @see     <a href="https://rmannibucau.wordpress.com/2016/02/09/yaml-configuration-for-deltaspike/">YAML Implementation for deltaspike</a>
 * @since   5.0.0 - 2017-08-17
 */
public class ConfYAML extends MapConfigSource implements PropertyFileConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfYAML.class);
    private static final String YAMLNAME = "application";

    /**
     * If there are any errors on application.yml, it will take another ordinal.
     *
     * @since 5.0.0 - 2017-08-17
     */
    @Override
    public boolean isOptional() {
        return true;
    }

    /**
     * Retrieves the YML file name.
     *
     * @return the yml file name
     */
    @Override
    public String getPropertyFileName() {
        return "application.yml";
    }


    private static String getFilePath(final String fileName){
        URL urlFile = ConfYAML.class.getResource(StringUtils.join("/META-INF/", fileName, ".yml"));
        if (urlFile != null) {
            return urlFile.getPath();
        }else{
            LOGGER.warn(StringUtils.join("Could not find ",fileName,".yml."));
            return "";
        }
    }

    /**
     * If there are any problems with this implementation, it will proceed to the next ordinal.
     *
     * @since 5.0.0 - 2017-08-17
     */
    @Override
    public int getOrdinal() {
        return 101;
    }

    /**
     * This method tries to find the system yml file.
     * <p>If it can't find application.yml, it will proceed to apache-deltaspike.properties.</p>
     * <p>If an application.yml is found and no profile is set, application.yml properties will be kept.</p>
     *
     * @since 5.0.0 - 2017-08-17
     */
    public ConfYAML() {
        super(
                Stream.of(getFilePath(YAMLNAME))
                        .findFirst()
                        .map(file -> {
                            final Map<String, String> properties = new HashMap<>();
                            if (!"".equals(file)){
                                readYml(YAMLNAME, new File(file), properties);
                                final String profile = properties.get("org.apache.deltaspike.ProjectStage");
                                if (!("").equals(profile) && profile != null ) {
                                    final String path = getFilePath(StringUtils.join(YAMLNAME, "-", profile));
                                    if (!"".equals(path)){
                                        Stream.of(path)
                                                .findFirst()
                                                .map(secondFile -> {
                                                    readYml(StringUtils.join(YAMLNAME, "-", profile), new File(secondFile), properties);
                                                    return properties;
                                                });
                                    }
                                }
                            }
                            return properties;
                        }).orElse(new HashMap<>()));
    }

    @Override
    public String getConfigName() {
        return YAMLNAME;
    }

    /**
     * This method creates a reader for the YML and calls enrich to map.
     *
     * @param profileName   the profile name
     * @param file          the yml file
     * @param properties    a {@link Map} of properties
     * @since 5.0.0 - 2017-08-17
     */
    private static void readYml(String profileName, File file, Map<String, String> properties ){
        final Yaml yaml = new Yaml();
        try (final Reader reader = new BufferedReader(new FileReader(file))) {
            for (final Object object : yaml.loadAll(reader)) {
                if (object == null || !Map.class.isInstance(object)) {
                    continue;
                }
                enrich(properties, Map.class.cast(object), "");
            }
        } catch (IOException ex) {
            LOGGER.warn(StringUtils.join("There are errors on the ", profileName ,".yml. Trying to load default file."));
            throw new IllegalStateException(ex);
        }
    }

    /**
     * This recursive method fills the objects and maps the properties from YML.
     *
     * @param map       to store information of the yml
     * @param object    to be read
     * @param keyString the object key
     * @since           5.0.0 - 2017-08-17
     */
    private static void enrich(final Map<String, String> map, final Map<?, ?> object, final String keyString) {
        for (final Map.Entry<?, ?> entry : object.entrySet()) {
            final String key = (keyString.isEmpty() ? keyString : keyString + '.') + entry.getKey();
            Object val = entry.getValue();
            val = val != null ? val : (Object) "";
            if (String.class.isInstance(val)) {
                map.put(key, String.valueOf(val));
            } else if (Map.class.isInstance(val)) {
                enrich(map, Map.class.cast(val), key);
            } else if (List.class.isInstance(val)) {
                final String list = String.valueOf(val).replace("[","").replace("]","");
                map.put(key,list);
            } else {
                throw new IllegalArgumentException(StringUtils.join("type not supported: ", val));
            }
        }
    }
}
