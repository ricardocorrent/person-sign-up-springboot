package com.ws.commons.event;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.NameBinding;
import java.lang.annotation.*;

/**
 * A custom HTTP PATCH REQUEST.
 * <p>This annotation is needed because the {@link HttpMethod} doesn't have the PATCH method by DEFAULT.</p>
 *
 * @author      Dante C. Basso Filho
 * @since       4.8.0 - 2017-05-19
 * @deprecated  Use implementation from module commons-server-patch-api instead
 */
@Target({ ElementType.METHOD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@HttpMethod("PATCH")
@Documented
@NameBinding
@Deprecated
public @interface PATCH {}
