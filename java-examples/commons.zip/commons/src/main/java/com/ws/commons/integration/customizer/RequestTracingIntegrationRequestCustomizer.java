package com.ws.commons.integration.customizer;

import com.ws.commons.ServerProperties;
import com.ws.commons.interceptor.log.servlet.RequestTracingUtils;
import feign.RequestTemplate;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Default;
import java.util.Optional;

/**
 * {@link IntegrationRequestCustomizer} implementation for request tracing headers
 *
 * <p>This class injects into integration requests the required request tracing headers, allowing to APM to
 * correctly trace the requests flowing between different services.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-02-21
 */
@Default
public class RequestTracingIntegrationRequestCustomizer implements IntegrationRequestCustomizer {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestTracingIntegrationRequestCustomizer.class);
    private static final String REQUEST_ID_HEADER = "X-Request-Id";
    private static final String REQUEST_CALLER_HEADER = "X-Request-Caller";

    /**
     * Customizes the request prior to the call
     *
     * @param template         Request template
     * @param clientDefinition Integration client in use
     */
    @Override
    public void customize(final RequestTemplate template, final Class<?> clientDefinition) {
        LOGGER.debug("Injecting request caller name and request ID headers into request");

        RequestTracingUtils
                .getRequestId()
                .ifPresent(value -> template.header(REQUEST_ID_HEADER, value));

        Optional.ofNullable(ConfigResolver.getProjectStageAwarePropertyValue(ServerProperties.SERVICE_NAME))
                .ifPresent(value -> template.header(REQUEST_CALLER_HEADER, value));
    }
}
