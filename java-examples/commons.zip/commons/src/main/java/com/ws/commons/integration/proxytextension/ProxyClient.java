package com.ws.commons.integration.proxytextension;

/**
 * Injection type expected by the {@link InjectProxyExtension} to produces the proxy class delivered to
 * each {@link InjectProxy}.
 *
 * @author  Evaristo W. Benfatti
 * @since   4.0.0 - 2017-01-03
 */
public interface ProxyClient {

    <T> T proxy(Class<T> clazz);

}
