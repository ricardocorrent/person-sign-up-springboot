package com.ws.commons.interceptor.exception;

/**
 * Exception to be thrown when an interception fails.
 *
 * @author  Diego Armange Costa
 * @since   6.0.0 - 2018-04-03
 */
@SuppressWarnings("serial")
public class InterceptionException extends RuntimeException {

    /**
     * @see RuntimeException#RuntimeException()
     */
    public InterceptionException() {
        super();
    }
    
    /**
     * @param message the exception message.
     * @see RuntimeException#RuntimeException(String)
     */
    public InterceptionException(final String message) {
        super(message);
    }
    
    
    /**
     * @param cause the exception cause.
     * @see RuntimeException#RuntimeException(Throwable)
     */
    public InterceptionException(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message the exception message.
     * @param cause the exception cause.
     * @see RuntimeException#RuntimeException(String, Throwable)
     */
    public InterceptionException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
