package com.ws.commons.integration.tenants;

import com.ws.commons.integration.integrationrequest.IntegrationRequestCloudManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Producer to a {@link List} of {@link String} with all available tenants from cloud-manager.
 *
 * @author Diego Peliser
 * @since 7.5.0 02/14/19
 */
public class TenantsProducer {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final IntegrationRequestCloudManager integrationRequestCloudManager;

    @Inject
    public TenantsProducer(final IntegrationRequestCloudManager integrationRequestCloudManager) {
        this.integrationRequestCloudManager = integrationRequestCloudManager;
    }

    /**
     * Produces a {@link List} of {@link String} with all available tenants from cloud-manager.
     *
     * @return {@literal Set<AbstractEntityIntegration>}
     */
    @Produces
    @InjectTenants
    public List<String> getTenants() {
        logger.debug("Producing list of tenants from cloud-manager.");
        final List<String> tenants = new ArrayList<>();

        try {
            final Response response = integrationRequestCloudManager.get("/customers/available-tenants");
            if (integrationRequestCloudManager.isSuccessful(response)) {
                final List items = response.readEntity(List.class);
                Optional.of(items).ifPresent(tenants::addAll);
            } else {
                logger.error("  Response error with HTTP status: {}", response.getStatus());
            }
            response.close();
        } catch (final Exception exception) {
            logger.error("  Unexpected error getting tenants from cloud-manager.", exception);
        }

        return tenants;
    }

}
