package com.ws.commons.interceptor.annotationprocessor;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.ws.commons.interceptor.sourceannotation.*;

import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;
import javax.ws.rs.ext.Provider;
import java.util.Set;

/**
 * Annotation processor class responsible to guarantee the right using of Interceptor Annotations. Its using allows the
 * interceptor developer not caring about in performing any validation during runtime, all of them are applied during
 * compilation time since this and service configuration file META-INF/services/javax.annotation.processing.Processor
 * are on classpath.
 *
 * @author  Evaristo W. Benfatti
 * @since   5.0.0 - 2017-07-13
 * @deprecated
 */
@SupportedSourceVersion(SourceVersion.RELEASE_8)
@Deprecated
public final class ConversionAnnotationProcessor extends AbstractProcessor {

    private Messager messager;

    /**
     * Override method used to init the custom processor. This implementation is just to set at the class context the processing
     * environment messenger to allow the code interact with compiler at compilation time.
     *
     * @param processingEnv the processing environment
     * @see                 AbstractProcessor#init(ProcessingEnvironment)
     */
    @Override
    public synchronized void init(final ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        messager = processingEnv.getMessager();
    }

    /**
     * Override method used to set the Annotation Types that the processor will be activated.
     *
     * @return the Annotation Types {@link Set} that activate the Annotation Processor
     */
    @Override
    public Set<String> getSupportedAnnotationTypes() {
        return ImmutableSet.of(Consumer.class.getCanonicalName(), ConversionConsumes.class.getCanonicalName(),
                ConversionMap.class.getCanonicalName(), ConversionMapConsumes.class.getCanonicalName(),
                ConversionMapEntry.class.getCanonicalName(), ConversionMapProduces.class.getCanonicalName(),
                ConversionProduces.class.getCanonicalName());
    }

    /**
     * Override Method responsible to apply all rules from Annotation Processor.
     *
     * @param annotations   a set of annotations
     * @param roundEnv      the round environment
     * @return              "false" to enable others annotation processing
     *
     * @see AbstractProcessor#process(Set, RoundEnvironment)
     */
    @Override
    public boolean process(Set<? extends TypeElement> annotations, final RoundEnvironment roundEnv) {

        processConsumesAnnotationPoints(roundEnv);

        processProducessAnnotationPoints(roundEnv);

        processMapAnnotationPoints(roundEnv);

        // Return false to enable others annotation processing
        return false;

    }

    /**
     * Method responsible to guarantee that only one Produces annotation type is being used.
     *
     * @param roundEnv the round environment
     */
    private void processProducessAnnotationPoints(final RoundEnvironment roundEnv) {

        final Set<? extends Element> conversionProducesPoints = roundEnv.getElementsAnnotatedWith(ConversionProduces.class);
        final Set<? extends Element> conversionMapProducesPoints = roundEnv.getElementsAnnotatedWith(ConversionMapProduces.class);

        Sets.intersection(conversionProducesPoints, conversionMapProducesPoints)
                .forEach(element -> messager.printMessage(Diagnostic.Kind.ERROR,
                        "Only one type @ConversionProduces or @ConversionMapProduces definition is allowed here.", element));

    }

    /**
     * Method responsible to guarantee that only one Consumes annotation type is being used.
     *
     * @param roundEnv the round environment
     */
    private void processConsumesAnnotationPoints(final RoundEnvironment roundEnv) {

        final Set<? extends Element> conversionConsumesPoints = roundEnv.getElementsAnnotatedWith(ConversionConsumes.class);
        final Set<? extends Element> conversionMapConsumesPoints = roundEnv.getElementsAnnotatedWith(ConversionMapConsumes.class);

        Sets.intersection(conversionConsumesPoints, conversionMapConsumesPoints)
                .forEach(element -> messager.printMessage(Diagnostic.Kind.ERROR,
                        "Only one type @ConversionConsumes or @ConversionMapConsumes definition is allowed here.", element));

    }

    /**
     * Method responsible to guarantee that always when is being used ConversionMapConsumes or ConversionMapProduces annotation
     * type is being used either {@link ConversionMap} or {@link ConversionMapEntry} is used along.
     *
     * @author          Evaristo W. Benfatti
     * @author          Diego Armange Costa
     * @param roundEnv  the round environment
     * @since           5.0.0 2017-08-21
     */
    private void processMapAnnotationPoints(final RoundEnvironment roundEnv) {

        final Set<? extends Element> conversionMapConsumesPoints = roundEnv.getElementsAnnotatedWith(ConversionMapConsumes.class);
        final Set<? extends Element> conversionMapProducesPoints = roundEnv.getElementsAnnotatedWith(ConversionMapProduces.class);

        // Remove the interceptors from evaluation
        conversionMapConsumesPoints.removeIf(element -> element.getAnnotation(Provider.class) != null);
        conversionMapProducesPoints.removeIf(element -> element.getAnnotation(Provider.class) != null);
        
        Sets.filter(conversionMapConsumesPoints, EConversionMapPredicate.INVALID_CONVERSION_MAP_CONSUMES)
        .forEach(element -> messager.printMessage(Diagnostic.Kind.ERROR,
                "When is being used @ConversionMapConsumes either @ConversionMapEntry and @ConversionMap must be used along.", element));
        
        Sets.filter(conversionMapProducesPoints, EConversionMapPredicate.INVALID_CONVERSION_MAP_PRODUCES)
        .forEach(element -> messager.printMessage(Diagnostic.Kind.ERROR,
                "When is being used @ConversionMapConsumes either @ConversionMapEntry and @ConversionMap must be used along.", element));
    }
}
