package com.ws.commons.interceptor.annotationprocessor;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.ws.commons.interceptor.sourceannotation.ConversionMap;
import com.ws.commons.interceptor.sourceannotation.ConversionMapConsumes;
import com.ws.commons.interceptor.sourceannotation.ConversionMapEntry;
import com.ws.commons.interceptor.sourceannotation.ConversionMapProduces;
import org.apache.commons.lang3.ArrayUtils;

import javax.lang.model.element.Element;

/**
 * Enumerator that applies annotation processing for elements that contains {@link ConversionMapProduces} and {@link ConversionMapConsumes}
 * annotations, providing validations as it may be used with {@link ConversionMap} or {@link ConversionMapEntry}.
 *
 * @author  Diego Armange Costa
 * @see     Predicates
 * @since   5.0.0 - 2017-08-21
 * @deprecated
 */
@Deprecated
enum EConversionMapPredicate implements Predicate<Element> {

    /**
     * Applies to get the invalid elements.
     * 
     * @see Predicate
     */
    INVALID_CONVERSION_MAP_CONSUMES {
        @Override
        public boolean apply(Element element) {
            ConversionMapConsumes consumesAnnotation = element.getAnnotation(ConversionMapConsumes.class);
            
            return consumesAnnotation != null 
                    && consumesAnnotation.value() != null
                    && ArrayUtils.isEmpty(consumesAnnotation.value().value());
        }
    },
    
    /**
     * Applies to get the invalid elements.
     * 
     * @see Predicate
     */
    INVALID_CONVERSION_MAP_PRODUCES{
        @Override
        public boolean apply(Element element) {
            ConversionMapProduces producesAnnotation = element.getAnnotation(ConversionMapProduces.class);

            return producesAnnotation != null 
                    && producesAnnotation.value() != null
                    && ArrayUtils.isEmpty(producesAnnotation.value().value());
        }
    }
}
