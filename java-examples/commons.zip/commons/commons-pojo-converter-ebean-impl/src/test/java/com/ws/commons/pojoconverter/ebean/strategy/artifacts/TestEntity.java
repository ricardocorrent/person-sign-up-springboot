package com.ws.commons.pojoconverter.ebean.strategy.artifacts;

import io.ebean.bean.EntityBean;
import io.ebean.bean.EntityBeanIntercept;

/**
 * Test artifact.
 *
 * @author  Lucas Dillmann
 * @since   7.2.0 - 2018-08-17
 */
public class TestEntity implements EntityBean {

    /**
     * Returns all the property names in defined order.
     */
    @Override
    public String[] _ebean_getPropertyNames() {
        return new String[0];
    }

    /**
     * Returns the property name at the given position.
     *
     * @param pos the position
     */
    @Override
    public String _ebean_getPropertyName(int pos) {
        return null;
    }

    /**
     * Returns the enhancement marker value.
     * <p>
     * This is the class name of the enhanced class and used to check that all
     * entity classes are enhanced (specifically not just a super class).
     * </p>
     */
    @Override
    public String _ebean_getMarker() {
        return null;
    }

    /**
     * Creates and returns a new entity bean instance.
     */
    @Override
    public Object _ebean_newInstance() {
        return null;
    }

    /**
     * Generator method that sets the loaded state on all the embedded beans on
     * this entity bean by using EntityBeanIntercept.setEmbeddedLoaded(Object o);
     */
    @Override
    public void _ebean_setEmbeddedLoaded() {

    }

    /**
     * Returns {@code true} if any embedded beans are new or dirty.
     */
    @Override
    public boolean _ebean_isEmbeddedNewOrDirty() {
        return false;
    }

    /**
     * Returns the intercept for this object.
     */
    @Override
    public EntityBeanIntercept _ebean_getIntercept() {
        return null;
    }

    /**
     * Similar to _ebean_getIntercept() except it checks to see if the intercept
     * field is null and will create it if required.
     * <p>
     * This is really only required when transientInternalFields=true as an
     * enhancement option. In this case the intercept field is transient and will
     * be null after a bean has been deserialized.
     * </p>
     * <p>
     * This transientInternalFields=true option was to support some serialization
     * frameworks that can't take into account our ebean fields.
     * </p>
     */
    @Override
    public EntityBeanIntercept _ebean_intercept() {
        return null;
    }

    /**
     * Sets the value of a field of an entity bean of this type.
     * <p>
     * Note that using this method bypasses any interception that otherwise occurs
     * on entity beans. That means lazy loading and oldValues creation.
     * </p>
     *
     * @param fieldIndex    the field index
     * @param value         the object to be set
     */
    @Override
    public void _ebean_setField(int fieldIndex, Object value) {

    }

    /**
     * Sets the field value with interception.
     *
     * @param fieldIndex    the field index
     * @param value         the object to be set
     */
    @Override
    public void _ebean_setFieldIntercept(int fieldIndex, Object value) {

    }

    /**
     * Returns the value of a field from an entity bean of this type.
     * <p>
     * Note that using this method bypasses any interception that otherwise occurs
     * on entity beans. That means lazy loading.
     * </p>
     *
     * @param fieldIndex the field index
     */
    @Override
    public Object _ebean_getField(int fieldIndex) {
        return null;
    }

    /**
     * Returns the field value with interception.
     *
     * @param fieldIndex the field index
     */
    @Override
    public Object _ebean_getFieldIntercept(int fieldIndex) {
        return null;
    }
}
