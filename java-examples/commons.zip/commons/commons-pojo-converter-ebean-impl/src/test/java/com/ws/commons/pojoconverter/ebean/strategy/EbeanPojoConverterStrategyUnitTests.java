package com.ws.commons.pojoconverter.ebean.strategy;

import com.ws.commons.pojoconverter.FieldWrapper;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import com.ws.commons.pojoconverter.ebean.strategy.artifacts.TestEntity;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Unit test cases for {@link EbeanPojoConverterStrategy}.
 *
 * @author  Lucas Dillmann
 * @since   7.2.0 - 2018-08-17
 */
@RunWith(CdiTestRunner.class)
public class EbeanPojoConverterStrategyUnitTests {

    @Mock
    private FieldWrapper fieldDetails;
    private EbeanPojoConverterStrategy strategy;

    /**
     * Prepares the scenario for the test cases
     */
    @Before
    public void setUp() {
        initMocks(this);
        this.strategy = new EbeanPojoConverterStrategy();
    }

    /**
     * Test case for a valid scenario when the supplied entity is a EntityBean, the field
     * to be converted isn't null and configuration is set to enabled, expecting the returned value to be true.
     */
    @Test
    @TestControl(projectStage = ProjectStage.IntegrationTest.class)
    public void shouldReturnTrueWhenIsAEntityBeanNonNullFieldWithConfigurationEnabled() {

        // scenario
        final Object sourceObject = new Object();
        final Object targetObject = new TestEntity();
        doReturn("SomeTestValue").when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertTrue(result);
    }

    /**
     * Test case for a valid scenario when the supplied entity isn't a EntityBean, the field
     * to be converted isn't null and configuration is set to enabled, expecting the returned value to be true.
     */
    @Test
    @TestControl(projectStage = ProjectStage.IntegrationTest.class)
    public void shouldReturnTrueWhenIsntAEntityBeanNonNullFieldWithConfigurationEnabled() {

        // scenario
        final Object sourceObject = new Object();
        final Object targetObject = new Object();
        doReturn("SomeTestValue").when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertTrue(result);
    }

    /**
     * Test case for a valid scenario when the supplied entity is a EntityBean, the field
     * to be converted isn't null and configuration is set to disabled, expecting the returned value to be true.
     */
    @Test
    @TestControl(projectStage = ProjectStage.UnitTest.class)
    public void shouldReturnTrueWhenIsAEntityBeanNonNullFieldWithConfigurationDisabled() {

        // scenario
        final Object sourceObject = new Object();
        final Object targetObject = new TestEntity();
        doReturn("SomeTestValue").when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertTrue(result);
    }

    /**
     * Test case for a valid scenario when the supplied entity is a EntityBean, the field
     * to be converted is null and configuration is set to disabled, expecting the returned value to be true.
     */
    @Test
    @TestControl(projectStage = ProjectStage.UnitTest.class)
    public void shouldReturnTrueWhenIsAEntityBeanNullFieldWithConfigurationDisabled() {

        // scenario
        final Object sourceObject = new Object();
        final Object targetObject = new TestEntity();
        doReturn(null).when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertTrue(result);
    }

    /**
     * Test case for a valid scenario when the supplied entity is a EntityBean, the field
     * to be converted is null and configuration is set to disabled, expecting the returned value to be true.
     *
     * @since 7.2.4 - 2018-09-03
     */
    @Test
    @TestControl(projectStage = ProjectStage.UnitTest.class)
    public void shouldReturnTrueWhenIsADtoBeanNullFieldWithConfigurationDisabled() {

        // scenario
        final Object sourceObject = new TestEntity();
        final Object targetObject = new Object();
        doReturn(null).when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertTrue(result);
    }

    /**
     * Test case for a valid scenario when the supplied entity is a DTO, the field
     * to be converted is null and configuration is set to enabled, expecting the returned value to be true.
     *
     * @since 7.2.4 - 2018-09-03
     */
    @Test
    @TestControl(projectStage = ProjectStage.IntegrationTest.class)
    public void shouldReturnFalseWhenIsADtoBeanNullFieldWithConfigurationEnabled() {

        // scenario
        final Object sourceObject = new TestEntity();
        final Object targetObject = new Object();
        doReturn(null).when(fieldDetails).getContent();

        // execution
        boolean result = strategy.shouldConvert(sourceObject, targetObject, fieldDetails);

        // validation
        assertFalse(result);
    }
}
