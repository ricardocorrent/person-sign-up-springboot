package com.ws.commons.pojoconverter.ebean.strategy;

import com.ws.commons.PojoConverterProperties;
import com.ws.commons.pojoconverter.FieldWrapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.strategy.PojoConverterStrategy;
import io.ebean.bean.EntityBean;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Objects;
import java.util.Optional;

/**
 * Default implementation for {@link PojoConverterStrategy} as a mechanism to provide the
 * {@link PojoConverterProperties#POJO_ONLY_CONVERT_CHANGED_VALUES} configuration in a proper way.
 *
 * <p>This class will analyze three points to take the decision if the field should be converted or not:</p>
 * <ul>
 *     <li>The configuration value from {@link PojoConverterProperties#POJO_ONLY_CONVERT_CHANGED_VALUES}</li>
 *     <li>The target of the conversion (if it's a EntityBean from Ebean)</li>
 *     <li>The value to be converted of the field</li>
 * </ul>
 *
 * <p>The default action is to allow the conversion. This implementation will only return false (to stop the conversion)
 * when configuration value is true, the target of the conversion is a EntityBean from Ebean and the value of the
 * field is null.</p>
 *
 * @author  Lucas Dillmann
 * @version 7.2.4 - 2018-09-03 - Changed internal logic from always returning the configuration value when the target is
 *                               a DTO to return true when the content of the field isn't null or the configuration value.
 * @since   7.2.0 - 2018-08-16
 */
public class EbeanPojoConverterStrategy implements PojoConverterStrategy {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * This method is called by the PojoConverter to validate if a field should be converted or not.
     *
     * <p>This method will be called before the conversion of every field in PojoConverter flow. If the returned value
     * is false, PojoConverter will ignore the field and continue to the next one. If return is true, PojoConverter
     * will continue the flow and run its internal secondary analysis to see if the conversion is needed.</p>
     *
     * <p>Please be aware that returning true by this method doesn't guarantee that the field will be converted.
     * For example: if the field contains no mapping or contains {@link PojoColumnIgnore}
     * annotation, even if this method returns true it will not be converted.</p>
     *
     * @param sourceObject  source object from the conversion
     * @param targetObject  target object of the conversion
     * @param fieldDetails  field details object (name, type and etc)
     * @return              result of the validation if the field should be converted or not
     */
    @Override
    public boolean shouldConvert(final Object sourceObject, final Object targetObject, final FieldWrapper fieldDetails) {

        final String fieldName = Optional
                .ofNullable(fieldDetails)
                .map(FieldWrapper::getField)
                .map(Field::getName)
                .orElse(null);

        final String className = Optional
                .ofNullable(fieldDetails)
                .map(FieldWrapper::getField)
                .map(Field::getDeclaringClass)
                .map(Class::getName)
                .orElse(null);

        logger.debug(
                "Checking if field '{}' of '{}' should be converted without messing with crazy Ebean routines",
                fieldName, className
        );

        final boolean isAEntityBeanTargetObject = !Objects.isNull(targetObject)
                && EntityBean.class.isAssignableFrom(targetObject.getClass());

        if (isAEntityBeanTargetObject) {
            logger.debug("Target of the conversion is an entity bean. Conversion can be done.");
            return true;
        }

        if (fieldDetails.getContent() != null) {
            logger.debug("Content isn't null. Conversion should be done.");
            return true;
        }

        final boolean onlyConvertChangedValues = ConfigResolver
                .resolve(PojoConverterProperties.POJO_ONLY_CONVERT_CHANGED_VALUES)
                .as(Boolean.class)
                .withDefault(false)
                .withCurrentProjectStage(true)
                .getValue();

        if (!onlyConvertChangedValues) {
            logger.debug("Project is configured to always convert all values. So we're returning to do the conversion.");
        }

        return !onlyConvertChangedValues;
    }
}
