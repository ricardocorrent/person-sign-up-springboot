package com.ws.commons.server.exception;

import com.ws.commons.server.messageloader.AbstractMessageLoader;

import java.io.IOException;

/**
 * <p>
 * This exception is meant to map any related JSON internationalization file reading error.
 * It is used in loading files for internationalization ({@link AbstractMessageLoader}), to indicate loading an invalid file.
 * </p>
 *
 * <p>
 * Whenever a problem is identified when reading an internationalization file JSON, this exception is thrown.
 * </p>
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-13
 */
@SuppressWarnings("serial")
public class InvalidInternationalizationFileException extends IOException {

    /**
     * Default exception constructor.
     *
     * @param message   the exception message.
     * @param cause     the exception cause.
     * @see             IOException#IOException(String, Throwable)
     */
    public InvalidInternationalizationFileException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
