package com.ws.commons.server.factory;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

/**
 * Context wrapper to provide {@link HttpServletRequest} injected from the context.
 *
 * <p>
 * This class is used only on {@link MessageBundleLocaleFactory} to retrieve the request {@link java.util.Locale} from the
 * servlet request, allowing it to provide internationalized messages correctly based on client's locale.
 * </p>
 *
 * @author  Hendric Gabriel Cechinato
 * @since   7.3.5 - 2018-10-02
 */
class ContextWrapper {

    @Context
    private HttpServletRequest request;

    /**
     * Retrieves a {@link HttpServletRequest} from the context.
     *
     * @return the servlet request from the context
     */
    public HttpServletRequest getRequest() {
        return request;
    }
}
