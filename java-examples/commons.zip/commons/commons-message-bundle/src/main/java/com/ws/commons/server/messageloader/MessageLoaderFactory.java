package com.ws.commons.server.messageloader;

import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

/**
 * Factory class for {@link CacheMessageLoader}.
 * <p>
 * This class is able to produce a singleton instance of {@link CacheMessageLoader} using CDI strategies.
 * </p>
 *
 * @author  Diego A. Costa
 * @see     #produce()
 * @since   6.0.0 - 2018-03-02
 */
@ApplicationScoped
public class MessageLoaderFactory {

    /**
     * The loader has a producer because there are classes (legacy) that need to get the loader instance outside
     * (direct access) of the CDI engine.
     *
     * @return the message loader.
     */
    @Produces
    @CacheMessageQualifier
    public CacheMessageLoader produce() {
        LoggerFactory
                .getLogger(getClass())
                .debug("Producing a {} instance for CDI using the singleton access point", CacheMessageLoader.class.getName());
        return CacheMessageLoader.getInstance();
    }
}