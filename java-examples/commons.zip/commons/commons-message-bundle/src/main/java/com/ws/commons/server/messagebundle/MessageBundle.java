package com.ws.commons.server.messagebundle;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.factory.MessageBundleLocaleFactory;
import com.ws.commons.server.factory.MessageBundleLocaleProvider;
import com.ws.commons.server.messageloader.CacheMessageQualifier;
import com.ws.commons.server.messageloader.MessageLoader;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * Performs internationalization message resolution based on {@link Locale}.<br>
 * This class provides methods to return an internationalized {@link ExceptionMessage} according to given parameters.
 * </p>
 *
 * <p>
 * <b>Example:</b>
 * </p>
 *
 * <pre><code>
 * messages-en.json
 * 
 * {
 *   "javax.validation.constraints.Null.message" : {
 *     "message" : "must be null"
 *   },
 *   "javax.validation.constraints.Past.message" : {
 *     "message" : "must be in the past"
 *   },
 *   "javax.validation.constraints.Size.message" : {
 *     "message" : "size must be between {1} and {3}"
 *   }
 * }
 * </code></pre>
 *
 * @author  William Santos
 * @author  Diego A. Costa
 * @author  Lucas Dillmann
 * @version 5.4.0 - 2017-12-06 - Added message formatting with named parameters({@link StrSubstitutor})
 *                               and {@link Locale} definition by {@link javax.ws.rs.core.Context}.
 * @version 7.3.2 - 2018-09-14 - Changed method {@link #getDefaultLocale()} to be able to handle exceptions, returning the default locale when
 *                               one happens
 * @version 7.3.4 - 2018-09-27 - Changed method {@link #getDefaultLocale()} to redirect responsibility to {@link MessageBundleLocaleFactory} that
 *                               will provide a locale based on service's implementation if possible or the default one otherwise.
 * @since   3.1.0 - 2016-10-24
 */
public class MessageBundle {

    @Context
    protected HttpServletRequest httpServletRequest;
    
    private static final String KEY_PARAM_DESCRIPTION = "key";

    private static final String NO_PARAMETERS_FOUND = "The message with key '%s' can't be recovered " +
            "using automatic parameters replacement because no parameter was received (parameter map is null or empty). " +
            "Please check if the parameters aren't missing or, if the message don't have parameters, you aren't calling the wrong " +
            "method on MessageBundle (try the simple message recovery by key without parameters instead).";

    protected final MessageLoader messageLoader;
    private final Logger logger;
    
    /**
     * Default file name prefix for the messages.
     *
     * @deprecated Message's default file name prefix belongs to {@link MessageLoader}.
     */
    @Deprecated
    public static final String FILE_NAME_PREFIX = "messages";
    
    /**
     * Default constructor.
     *
     * @author                  Diego A. Costa
     * @param messageLoader     to load internationalization files. Annotated with {@link CacheMessageQualifier}.
     * @since                   5.4.0 - 2017-12-06 - Added message formatting with named parameters({@link StrSubstitutor})
     *                          and {@link Locale} definition by {@link javax.ws.rs.core.Context}.
     */
    @Inject
    public MessageBundle(@CacheMessageQualifier final MessageLoader messageLoader) {
        this.logger = LoggerFactory.getLogger(getClass());
        this.messageLoader = messageLoader;
    }

    /**
     * Returns an internationalized message built based on a {@link Locale}.<br>
     * The {@link Locale} will be extracted from {@link HttpServletRequest} injected by {@link Context}, 
     * but case it is not possible to perform this extraction, the default {@link Locale} will be used.<br>
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    public ExceptionMessage getDefaultMessage(final String key, final Object... parameters) {
        logger.debug("Resolving i18n message '{}' using default locale and parameters '{}'", key, parameters);
        return getMessageWithoutLocale(key, parameters);
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The parameters will be replaced according its <b>indexes</b>.
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    private ExceptionMessage getMessageWithoutLocale(final String key, final Object... parameters) {
        Objects.requireNonNull(key, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(KEY_PARAM_DESCRIPTION));
        logger.debug("Resolving i18n message '{}' using default locale and parameters '{}'", key, parameters);
        final Map<String, ExceptionMessage> messages = messageLoader.load(getDefaultLocale());

        return getMessage(key, messages, parameters);
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The {@link Locale} will be extracted from {@link HttpServletRequest} injected by {@link Context}, 
     * but case if is not possible to perform this extraction, the default {@link Locale} will be used.<br>
     * The parameters will be replaced according its <b>names</b>.
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    public ExceptionMessage getNamedParameterMessage(final String key, final Map<String, Object> parameters) {
        logger.debug("Resolving i18n message '{}' using default locale and parameters '{}'", key, parameters);
        return getNamedParameterMessageWithoutLocale(key, parameters);
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The parameters will be replaced according its <b>indexes</b>.
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    private ExceptionMessage getNamedParameterMessageWithoutLocale(final String key, final Map<String, Object> parameters) {
        Objects.requireNonNull(key, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(KEY_PARAM_DESCRIPTION));
        logger.debug("Resolving i18n message '{}' using default locale and parameters '{}'", key, parameters);
        final Map<String, ExceptionMessage> messages = messageLoader.load(getDefaultLocale());
        
        return getNamedParameterMessage(key, parameters, messages);
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The parameters will be replaced according its <b>indexes</b>.
     *
     * @param key           to find the message.
     * @param parameters    to format the message.
     * @param locale        to set the language.
     * @return              the internationalized message.
     * @deprecated          use {@link #getMessage(String, Locale, Object...)}
     */
    @Deprecated
    public ExceptionMessage getMessage(final String key, final Object[] parameters, final Locale locale) {
        logger.debug(
                "Resolving i18n message '{}' for locale {} with parameters '{}'",
                key, locale.toLanguageTag(), parameters
        );
        return getMessage(key, locale, parameters);
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The parameters will be replaced according its <b>indexes</b>.
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param locale        to set the language.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    public ExceptionMessage getMessage(final String key, final Locale locale, final Object... parameters) {
        Objects.requireNonNull(key, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(KEY_PARAM_DESCRIPTION));
        Objects.requireNonNull(locale, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("locale"));

        logger.debug(
                "Resolving i18n message '{}' for locale {} with parameters '{}'",
                key, locale.toLanguageTag(), parameters
        );
        final Map<String, ExceptionMessage> messages = messageLoader.load(locale);
        return getMessage(key, messages, parameters);
    }

    private ExceptionMessage getMessage(final String key, final Map<String, ExceptionMessage> messages, final Object... parameters) {
        final ExceptionMessage i18nMessage = getI18nMessage(key, messages);

        if (ArrayUtils.isNotEmpty(parameters)) {
            configureParameters(parameters, messages);
        } else if (isNecessaryParameters(i18nMessage.getMessage())) {
            throw new IllegalStateException(String.format(NO_PARAMETERS_FOUND, key));
        }

        return new ExceptionMessage(i18nMessage.getCode(), MessageFormat.format(i18nMessage.getMessage(), parameters));
    }
    
    /**
     * Applies the internationalization in the parameters / keys that are present in the file of messages loaded according to the language.<br>
     * Null parameters are not assumed, and an {@link IllegalStateException} is thrown.
     *
     * @author              Diego A. Costa
     * @param parameters    to be validated and translated.
     * @param messages      that can contains the parameters keys to the translation.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    private void configureParameters(final Object[] parameters, final Map<String, ExceptionMessage> messages) {
        for (int index = 0; index < parameters.length; index++) {
            final Object parameter = parameters[index];
            
            validateParameter(parameter);
            
            final ExceptionMessage i18nParameter = getI18nParameter(parameter, messages);
            
            if (i18nParameter != null) {
                parameters[index] = i18nParameter.getMessage();
            }
        }
    }
    
    /**
     * Returns an internationalized message built based on a {@link Locale} and message composing parameters.<br>
     * The parameters will be replaced according its <b>indexes</b>.
     *
     * @author              Diego A. Costa
     * @param key           to find the message.
     * @param locale        to set the language.
     * @param parameters    to format the message.
     * @return              the internationalized message.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    public ExceptionMessage getNamedParameterMessage(final String key, final Locale locale, final Map<String, Object> parameters) {
        Objects.requireNonNull(key, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(KEY_PARAM_DESCRIPTION));
        Objects.requireNonNull(locale, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("locale"));

        logger.debug(
                "Resolving i18n message '{}' for locale {} with parameters '{}'",
                key, locale.toLanguageTag(), parameters
        );
        final Map<String, ExceptionMessage> messages = messageLoader.load(locale);
        return getNamedParameterMessage(key, parameters, messages);
    }

    private ExceptionMessage getNamedParameterMessage(final String key, final Map<String, Object> parameters, final Map<String, ExceptionMessage> messages) {
        final ExceptionMessage i18nMessage = getI18nMessage(key, messages);
        
        if (MapUtils.isNotEmpty(parameters)) {
            configureParameters(parameters, messages);
        } else if (isNecessaryParameters(i18nMessage.getMessage())) {
            throw new IllegalStateException(String.format(NO_PARAMETERS_FOUND, key));
        }
        
        return new ExceptionMessage(i18nMessage.getCode(), StrSubstitutor.replace(i18nMessage.getMessage(), parameters));
    }
    
    /**
     * Applies the internationalization in the parameters / keys that are present in messages file loaded according to the language.<br>
     * Null parameters are not assumed, and an {@link IllegalStateException} is thrown.
     *
     * @author              Diego A. Costa
     * @param parameters    to be validated and translated.
     * @param messages      that can contains the parameters keys to the translation.
     * @see                 MessageLoader#getDefaultLocale()
     * @since               5.4.0 - 2017-12-14
     */
    private void configureParameters(final Map<String, Object> parameters, final Map<String, ExceptionMessage> messages) {
        parameters.entrySet().forEach(entry -> {
            final Object parameter = entry.getValue();
            
            validateKey(entry.getKey());
            
            validateParameter(parameter);
            
            final ExceptionMessage i18nParameter = getI18nParameter(parameter, messages);
            
            if (i18nParameter != null) {
                parameters.put(entry.getKey(), i18nParameter.getMessage());
            }
        });
    }

    private ExceptionMessage getI18nMessage(final String key, final Map<String, ExceptionMessage> messages) {
        return Optional.ofNullable(messages.get(key)).orElse(new ExceptionMessage(ExceptionMessage.NONE_CODE, key));
    }
    
    private void validateKey(final Object key) {
        if(key == null || StringUtils.isEmpty(key.toString())){
            throw new IllegalStateException("Null or empty key to format the message is not supported.");
        }
    }
    
    private void validateParameter(final Object parameter) {
        if(parameter == null){
            throw new IllegalStateException("Null parameter to format the message is not supported.");
        }
    }
    
    private ExceptionMessage getI18nParameter(final Object parameterKey, final Map<String, ExceptionMessage> messages) {
        return messages.get(parameterKey.toString().replaceAll("[\\{\\}]+", ""));
    }
    
    private Boolean isNecessaryParameters(final String message){
        return message.matches("^.*\\{.+\\}.*$");
    }

    /**
     * Method to retrieve default {@link Locale} for message's internationalization.
     * <p>
     * This method calls {@link MessageBundleLocaleFactory} to search for implementations of {@link MessageBundleLocaleProvider}
     * interface through SPI and CDI strategies.
     * Any implementation of that interface is meant to provide a custom {@link Locale} as the default one when this method
     * is called.
     * </p>
     *
     * @author Lucas Dillmann
     * @return a {@link Locale} provided from {@link HttpServletRequest}, {@link MessageBundleLocaleProvider} implementation
     *         or {@link Locale#ENGLISH} as default.
     */
    public Locale getDefaultLocale() {
        return new MessageBundleLocaleFactory(messageLoader).getLocale();
    }
}
