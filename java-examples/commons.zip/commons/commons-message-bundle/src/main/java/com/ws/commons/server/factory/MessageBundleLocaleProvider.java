package com.ws.commons.server.factory;

import com.ws.commons.server.messagebundle.MessageBundle;
import javax.enterprise.context.RequestScoped;
import java.util.Locale;

/**
 * <p>
 * This interface allows to provide custom {@link Locale} when getting it through {@link MessageBundle}
 * in run-time.
 * </p>
 *
 * <p>
 * Any implementation of this interface will be found and loaded using ServiceLoader strategies or CDI injection instance.
 * </p>
 *
 * <p>
 * Usage example:
 * </p>
 * <pre>
 *     public class AnyClass implements MessageBundleLocaleProvider {
 *        {@literal @Override}
 *         public Locale getLocale() {
 *             return Locale.ENGLISH;
 *         }
 *     }
 * </pre>
 *
 * <p>
 * Whenever {@link MessageBundle#getDefaultLocale()} is called, this implementation may be found to provide the desired
 * {@link Locale}.
 * </p>
 *
 * @author  Hendric Gabriel Cechinato
 * @since   7.3.4 - 2018-09-27
 */
@RequestScoped
public interface MessageBundleLocaleProvider {

    /**
     * This method is called to produce a custom {@link Locale} when it's not possible to retrieve from {@link javax.servlet.http.HttpServletRequest}
     * or another strategy.
     * <p>This method will be called every time a {@link Locale} is being requested from {@link MessageBundle#getDefaultLocale()} and a valid
     * implementation of this interface is found through SPI strategies or CDI injection instance.
     *
     * @return the result {@link Locale} from method's execution
     */
    Locale getLocale();
}
