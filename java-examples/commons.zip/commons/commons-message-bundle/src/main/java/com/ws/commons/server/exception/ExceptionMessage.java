package com.ws.commons.server.exception;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import com.ws.commons.server.messagebundle.MessageBundle;

/**
 * This class defines an exception message to be returned, containing the code and description.
 *
 * <p>
 * An {@link ExceptionMessage} is most commonly retrieved through {@link MessageBundle#getMessage} methods, that
 * handles internationalized message buildings according to its parameters.
 * </p>
 *
 * <p>
 * A brief example of the returned object is shown below:
 * </p>
 *
 * <pre>
 *     {
 *          "code": "ERR-00005",
 *          "message": "Not found"
 *     }
 * </pre>
 *
 * <p>
 * <b>WARNING:</b> Keep this class as value object, once it will be cached updates can take trouble.
 * </p>
 *
 * @author  William Santos
 * @since   2.1.0 - 2016-07-11
 */

public class ExceptionMessage {

    /**
     * Indicates exception without code, just the message body.
     */
    public static final String NONE_CODE = "";

    /**
     * Default is SOL-XXXXX.
     */
    //TODO: #47802 (https://redmineproduto.wssim.com.br/issues/54555)
    private final String code;

    private final String message;

    /**
     * Default constructor.
     *
     * @param code    the message identification code.
     * @param message the message body.
     */
    @JsonCreator
    public ExceptionMessage(@JsonProperty("code") final String code, @JsonProperty("message") final String message) {
        this.message = message;
        this.code = code;
    }

    /**
     * Retrieves the message code.
     *
     * @return the message code
     */
    public String getCode() {
        return code;
    }

    /**
     * Retrieves the message body.
     *
     * @return the message body
     */
    public String getMessage() {
        return message;
    }
}
