package com.ws.commons.server.messageloader;

import com.ws.commons.server.messagebundle.MessageBundle;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Qualifier that must be used when is necessary to cache messages.
 *
 * <p>
 * This interface is used to annotate {@link MessageLoader} instances that needs to be cached in
 * {@link MessageBundle}.
 * </p>
 *
 * @author  William Santos
 * @since   2.1.0 - 2016-08-25
 */
@Qualifier
@Retention(RUNTIME)
@Target({TYPE, FIELD, METHOD, PARAMETER})
public @interface CacheMessageQualifier {}
