package com.ws.commons.server.factory;

import com.ws.commons.server.messageloader.MessageLoader;
import com.ws.commons.server.messagebundle.MessageBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.CDI;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Implementation of a {@link Locale} factory class.
 *
 * <p>
 * This factory class is able to produce a {@link Locale} using CDI and SPI strategies to find any implementation of
 * {@link MessageBundleLocaleProvider} and get the Locale from it.
 * </p>
 * <p>
 * If none implementations are found, it retrieves {@link Locale} from {@link HttpServletRequest} when possible, otherwise
 * it gets the default Locale from {@link MessageLoader#getDefaultLocale()}.
 * </p>
 *
 * <p>
 * Example usage:
 * </p>
 * <pre>
 *     // MessageLoader may be initialized through static injection
 *     Locale locale = new MessageBundleLocaleFactory(messageLoader).getLocale();
 * </pre>
 *
 * @author  Hendric Gabriel Cechinato
 * @since   7.3.4 - 2018-09-27
 * @version 7.3.5 - 2018-10-02 - Retrieves {@link HttpServletRequest} from {@link ContextWrapper} static instance.
 */
public class MessageBundleLocaleFactory {

    private final MessageLoader messageLoader;

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageBundleLocaleFactory.class);

    /**
     * Constructor with initialization of {@link MessageLoader} with information to provide internationalized messages.
     *
     * @param messageLoader a {@link MessageLoader} instance from {@link MessageBundle}
     */
    public MessageBundleLocaleFactory(final MessageLoader messageLoader) {
        this.messageLoader = messageLoader;
    }

    /**
     * This method is called whenever a {@link Locale} is requested. It calls methods to search for implementations
     * of {@link MessageBundleLocaleProvider} and return its {@link Locale}.
     *
     * @return the result of service's implementation's {@link MessageBundleLocaleProvider#getLocale()}. Otherwise, the default location.
     */
    public Locale getLocale() {
        return Optional.ofNullable(getLocaleFromSpi()).orElseGet(() ->
            Optional.ofNullable(getLocaleFromCdi()).orElse(getDefaultLocale()));
    }

    /**
     * This method searches for implementations of {@link MessageBundleLocaleProvider} through SPI strategies.
     * If any implementation is found, it will return the {@link Locale} from the a Service's
     * {@link MessageBundleLocaleProvider#getLocale()} method. Otherwise, it will return null.
     *
     * @author  Hendric Gabriel Cechinato
     * @since   7.3.4 - 2018-09-27
     * @return  a {@link Locale} from a found implementation, null otherwise.
     */
    private Locale getLocaleFromSpi() {
        LOGGER.debug("Trying to find a {} implementation using SPI", MessageBundleLocaleProvider.class.getName());
        final Iterator<MessageBundleLocaleProvider> iterator = getIteratorFromServiceLoader();
        if(iterator.hasNext()) {
            final MessageBundleLocaleProvider implementation = iterator.next();
            if(!iterator.hasNext()) {
                return implementation.getLocale();
            } else {
                throw new RuntimeException("Multiple implementations found using Java SPI for class " + MessageBundleLocaleProvider.class.getName() + ".");
            }
        } else {
           LOGGER.debug(
                    "Failed to retrieve {} from SPI. Trying to retrieve from CDI instead.", MessageBundleLocaleProvider.class.getName());
            return null;
        }
    }

    /**
     * This method searches for implementations of {@link MessageBundleLocaleProvider} through CDI strategies.
     * If any implementation is found, it will return the {@link Locale} from the a Service's
     * {@link MessageBundleLocaleProvider#getLocale()} method. Otherwise, it will return null.
     *
     * @author  Hendric Gabriel Cechinato
     * @since   7.3.4 - 2018-09-27
     * @return  a {@link Locale} from a found implementation, null otherwise.
     */
    private Locale getLocaleFromCdi() {
        LOGGER.debug("Trying to find a {} implementation using CDI", MessageBundleLocaleProvider.class.getName());
        final MessageBundleLocaleProvider provider = getLocaleProviderFromCdi();
        try {
            return Optional
                    .ofNullable(provider)
                    .map(MessageBundleLocaleProvider::getLocale)
                    .orElse(null);
        } catch (final Exception ex) {
            LOGGER.debug(
                    "Failed to retrieve " + MessageBundleLocaleProvider.class.getName() + " from CDI. Using the default one instead.", ex);
            return null;
        } finally {
            try {
                if (provider != null) {
                    CDI.current().destroy(provider);
                }
            } catch (final Exception ex) {
                LOGGER.warn("Error destructing object. How CDI produced the instance and now he is unavailable to destroy it?", ex);
            }
        }
    }

    /**
     * This method tries to get a valid {@link HttpServletRequest} from a CDI static injection.
     * If found, it returns the {@code httpServletRequest} {@link Locale}. Otherwise, it returns the default
     * {@link Locale} found through {@link MessageLoader}
     *
     * @author  Hendric Gabriel Cechinato
     * @since   7.3.4 - 2018-09-27
     * @return  a {@link Locale} from {@code httpServletRequest}, default {@link Locale} otherwise.
     */
    private Locale getDefaultLocale() {
        LOGGER.debug("Trying to find a {} value from current HTTP request", Locale.class.getName());
        try {
            final HttpServletRequest httpServletRequest = getServletRequestFromCdi();
            return Optional
                    .ofNullable(httpServletRequest.getLocales())
                    .map(messageLoader::getAvailableLocale)
                    .orElse(httpServletRequest.getLocale());
        } catch (final Exception ex) {
            LOGGER.warn(
                    "Failed to retrieve the Locale from the current HTTP request. Using the default one instead.",
                    ex
            );
            return messageLoader.getDefaultLocale();
        }
    }

    /**
     * Tries to retrieve a {@link HttpServletRequest} instance from {@link ContextWrapper}.
     *
     * @return the request's {@link HttpServletRequest}, null otherwise
     */
    public HttpServletRequest getServletRequestFromCdi() {
        final ContextWrapper wrapper = CDI.current().select(ContextWrapper.class).get();
        try {
            return wrapper.getRequest();
        } finally {
            CDI.current().destroy(wrapper);
        }
    }

    /**
     * Searches for implementations of {@link MessageBundleLocaleProvider} through CDI strategies.
     *
     * @return a {@link MessageBundleLocaleProvider} instance if found, null otherwise
     */
    public MessageBundleLocaleProvider getLocaleProviderFromCdi() {
        try {
            return Optional
                    .of(CDI.current().select(MessageBundleLocaleProvider.class))
                    .filter(it -> !it.isUnsatisfied())
                    .map(Instance::get)
                    .orElse(null);
        } catch (final Exception ex) {
            LOGGER.debug("Error retrieving instance from CDI", ex);
            return null;
        }
    }

    /**
     * Searches for implementations of {@link MessageBundleLocaleProvider} through SPI strategies.
     *
     * @return an iterator for the implementations found if available, null otherwise.
     */
    public Iterator<MessageBundleLocaleProvider> getIteratorFromServiceLoader() {
        return ServiceLoader.load(MessageBundleLocaleProvider.class).iterator();
    }
}
