package com.ws.commons.server.messageloader;

import com.ws.commons.server.exception.ExceptionMessage;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

/**
 * File resolver for exception messages that find message files based on the language. Message files must be on JSON format.
 *
 * @author  William Santos
 * @author  Diego A. Costa
 * @author  Rogerio Kiihl
 * @version 5.4.0 - 2017-12-12 - Added new loading methods
 * @version 6.0.0 - 2018-04-17 - Added new availability check methods
 *                  2018-04-26 - Removing default method implementation to force implementation on implementation classes
 * @since   2.1.0 - 2016-07-13
 */
public interface MessageLoader {

    /**
     * Method to provide filename prefix.
     *
     * @author Diego A. Costa
     * @author Rogerio Kiihl
     * @return the default file name
     *
     * TODO Load from properties file.
     * TODO https://redmineproduto.wssim.com.br/issues/47789
     */
    String getDefaultFileNamePrefix();

    /**
     * Method to provide default locale.
     *
     * @author Diego A. Costa
     * @author Rogerio Kiihl
     * @return {@link Locale#ENGLISH} as default
     *
     * TODO Load from properties file.
     * TODO https://redmineproduto.wssim.com.br/issues/47789
     */
    Locale getDefaultLocale();

    /**
     * Chooses an available {@link Locale} according to the preferred locales ordered at the enumeration.
     *
     * @param requestedLocales  enumeration with the preferred locales ordered by importance
     * @return                  the most important locale between available locales
     * @since                   6.0.0 - 2018-04-17
     */
    Locale getAvailableLocale(Enumeration<Locale> requestedLocales);

    /**
     * Returns if the asked locale is available to use.
     *
     * @author          Rogerio Kiihl
     * @param locale    to check availability
     * @return          true if the locale has localization available
     * @since           6.0.0 - 2018-04-17
     */
    boolean isLocaleAvailable(Locale locale);

    /**
     * Loads messages file using the {@link #getDefaultFileNamePrefix()} and {@link #getDefaultLocale()}.
     *
     * @author  Diego A. Costa
     * @author  Rogerio Kiihl
     * @return  The messages found (until version 6, will return null if not implemented)
     * @see     MessageLoader#getDefaultFileNamePrefix()
     * @see     MessageLoader#getDefaultLocale()
     */
    Map<String, ExceptionMessage> load();

    /**
     * Loads messages file using the default file name.
     *
     * @author          Diego A. Costa
     * @author          Rogerio Kiihl
     * @param locale    to determine internationalization.
     * @return          the messages found. (until version 6, will return null if not implemented)
     * @see             MessageLoader#getDefaultFileNamePrefix()
     */
    Map<String, ExceptionMessage> load(final Locale locale);

    /**
     * Loads messages file using the default {@link Locale}.
     *
     * @author                  Diego A. Costa
     * @author                  Rogerio Kiihl
     * @param fileNamePrefix    to be loaded
     * @return                  the messages found (until version 6, will return null if not implemented)
     * @see                     MessageLoader#getDefaultLocale()
     */
    Map<String, ExceptionMessage> load(final String fileNamePrefix);

    /**
     * Loads messages using {@code fileNamePrefix} and {@code locale}.
     *
     * @author                  Diego A. Costa
     * @author                  Rogerio Kiihl
     * @param fileNamePrefix    to be loaded
     * @param locale            to determine internationalization
     * @return                  the messages found (until version 6, will return null if not implemented)
     */
    Map<String, ExceptionMessage> load(final String fileNamePrefix, final Locale locale);
}
