package com.ws.commons.server.messageloader;

import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.exception.InvalidInternationalizationFileException;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.MapType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Provides essential operations for message loading.
 *
 * <p>
 * This class is responsible to find message files according to the desired {@link Locale} and load all found messages
 * into a {@link Map}.
 * </p>
 *
 * <p>
 * This {@link Map} that contains all messages is used by whole application to provide internationalized messages.
 * </p>
 *
 * <em>Note that when message file fetches fail, logs are issued, but the exceptions are not propagated.</em>
 *
 * @author  Diego Armange Costa
 * @version 7.2.5 - 2018-09-05 - Fix resource loader. Changed to Load the resource from all libraries.
 * @since   5.4.0 - 2017-12-12
 */
public abstract class AbstractMessageLoader {

    protected static final String ENCODING_MESSAGE = "After reviewing the syntax, make sure that the file is UTF-8 encoded.";
    protected static final String JSON_SYNTAX_MESSAGE = "Probably file is not a valid JSON.";
    protected static final String ERROR_READING_INVALID_JSON_WITH_COUNTRY = String.join(" ", "Error reading %s-%s-%s.json.", JSON_SYNTAX_MESSAGE, ENCODING_MESSAGE);
    protected static final String ERROR_READING_INVALID_JSON_FILE = "Error reading %s.";
    protected static final String ERROR_READING_INVALID_JSON = String.join(" ", "Error reading %s-%s.json.", JSON_SYNTAX_MESSAGE, ENCODING_MESSAGE);
    protected static final String FILE_NOT_FOUND = "Couldn't find the file: %s";
    protected static final String FILE_JSON_EXTENSION = ".json";
    
    private final ObjectMapper mapper = new ObjectMapper();
    private final Logger logger = LoggerFactory.getLogger(AbstractMessageLoader.class);
    
    /**
     * Loads all messages according the language obtained from {@link Locale}.
     * It will try to load the messages according country when it exists, 
     * otherwise it will try to load the messages that has no country defined.
     * <br>There is no precedence of message file loading for the loading in internal LIBs. 
     * The search engine in this implementation can find any file ignoring 
     * case in root resource, but it is not possible on internal LIBs.
     *
     * <pre>
     * <b>Example:</b>
     * File name prefix: <b>"messages"</b>
     * Locale: {@link Locale#ENGLISH}
     * File name result: <b>"messages-en.json"</b>
     * </pre>
     *
     * The messages loading can variate according the operating system. 
     * Windows system-bases are naturally case-insensitive, but Unix system-base are not, 
     * so in this cases, it's very important keep the files in a specific name pattern.
     *
     * @author                          Diego A. Costa
     * @param fileNamePrefix            the file name prefix to be attached with the language
     *                                  and compose the name of the message file.
     * @param locale the {@link Locale} to determine the internationalization.
     * @return                          the messages found.
     * @since                           5.4.0 - 2017-12-12
     */
    protected Map<String, ExceptionMessage> loadMessages(final String fileNamePrefix, final Locale locale) {
        final Map<String, ExceptionMessage> messagesMap = new HashMap<>();
        
        /*
         * The order of loading of the messages should ensure that the 
         * value of a key from a messages file without country, never 
         * will to replace the value of the same key from a messages 
         * file with a country specified.
         * 
         * The messages file without country always should be loaded, 
         * because is not possible to ensure that messages file with 
         * country specified will contains all necessary key values.
         * */
        loadMessagesIgnoringCountry(messagesMap, fileNamePrefix, locale);
        loadMessagesFromCountryIfExists(messagesMap, fileNamePrefix, locale);

        return messagesMap;
    }
    
    /**
     * Builds the name of the internationalization file.
     *
     * @param fileNamePrefix the prefix that composes the messages file name.
     * @param locale         the current {@link Locale}
     * @return               the file name that contains all messages according {@link Locale}
     */
    protected String buildLanguageFileName(final String fileNamePrefix, final Locale locale) {
        return hasCountry(locale) ? 
                buildLanguageFileNameWithCountry(fileNamePrefix, locale) : 
                    buildLanguageFileNameWithoutCountry(fileNamePrefix, locale);
    }

    private void loadMessagesIgnoringCountry(final Map<String, ExceptionMessage> messagesMap, final String fileNamePrefix, final Locale locale) {
        try {
            /*
             * The messages file without country always should be loaded, 
             * because is not possible to ensure that messages file with 
             * country specified will contains all necessary key values.
             * */
            messagesMap.putAll(loadMessagesThrowingExceptionWhenFileReadingFails(buildLanguageFileNameWithoutCountry(fileNamePrefix, locale)));
        } catch (final InvalidInternationalizationFileException ioException) {
            logger.error(String.format(ERROR_READING_INVALID_JSON, fileNamePrefix, locale.getLanguage()), ioException);
        }
    }

    private String buildLanguageFileNameWithoutCountry(final String fileNamePrefix, final Locale locale) {
        return new StringBuilder(fileNamePrefix).append("-").append(locale.getLanguage()).append(FILE_JSON_EXTENSION).toString();
    }
    
    private void loadMessagesFromCountryIfExists(final Map<String, ExceptionMessage> messagesMap, final String fileNamePrefix, final Locale locale) {
        try {
            if (hasCountry(locale)) {
                messagesMap.putAll(loadMessagesThrowingExceptionWhenFileReadingFails(buildLanguageFileNameWithCountry(fileNamePrefix, locale)));
            }
        } catch (final InvalidInternationalizationFileException exception) {
            logger.error(String.format(ERROR_READING_INVALID_JSON_WITH_COUNTRY, fileNamePrefix, locale.getLanguage(), locale.getCountry()), exception);
        }
    }
    
    private boolean hasCountry(final Locale locale) {
        return !locale.getCountry().isEmpty();
    }
    
    private String buildLanguageFileNameWithCountry(final String fileNamePrefix, final Locale locale) {
        return new StringBuilder(fileNamePrefix).append("-").append(locale.getLanguage()).append("-").append(locale.getCountry()).append(FILE_JSON_EXTENSION).toString();
    }

    private Map<String, ExceptionMessage> loadMessagesThrowingExceptionWhenFileReadingFails(final String fileName) 
            throws InvalidInternationalizationFileException {
        final Map<String, ExceptionMessage> messagesMap = new HashMap<>();
        
        try {
            final Enumeration<URL> resources = getClass().getClassLoader().getResources(fileName);
            
            loadMessagesFromInternalResourcesBeforeRootResource(messagesMap, fileName, resources);
        } catch (final JsonParseException | JsonMappingException exception) {
            throw new InvalidInternationalizationFileException(String.format(ERROR_READING_INVALID_JSON_FILE, fileName), exception);
        } catch (final Exception exception) {
            logger.error(String.format(FILE_NOT_FOUND, fileName), exception);
        }
        
        return messagesMap;
    }

    /**
     * Retrieves the path from the requested filename.
     *
     * @param fileName  the file name that will be requested as resource.
     * @return          the URL from requested file name.
     */
    protected URL getResource(final String fileName) {
        return getClass().getClassLoader().getResource(fileName);
    }

    private void loadMessagesFromInternalResourcesBeforeRootResource(
            final Map<String, ExceptionMessage> messagesMap, 
            final String fileName,
            final Enumeration<URL> resources) throws InvalidInternationalizationFileException {
        if (resources.hasMoreElements()) {
            final URL rootResource = getResource(fileName);
            
            while (resources.hasMoreElements()) {
                final URL nextElement = resources.nextElement();
                
                if (isRootResource(nextElement, rootResource)) {
                    continue;
                }
                
                loadMessagesFromAUrl(messagesMap, fileName, nextElement);
            }
            
            loadMessagesFromAUrl(messagesMap, fileName, rootResource);
        } else {
            logger.error(String.format(FILE_NOT_FOUND, fileName));
        }
    }

    private boolean isRootResource(final URL nextElement, final URL rootResource) {
        return nextElement.getFile().equals(rootResource.getFile());
    }

    private void loadMessagesFromAUrl(final Map<String, ExceptionMessage> messagesMap, 
            final String fileName,
            final URL resource) throws InvalidInternationalizationFileException {
        final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, ExceptionMessage.class);
        
        try(final InputStream stream = resource.openStream()) {
            messagesMap.putAll(mapper.readValue(stream, type));
        } catch (final Exception e) {
            throw new InvalidInternationalizationFileException(String.format(ERROR_READING_INVALID_JSON_FILE, fileName), e);
        }
    }
    
    /**
     * Retrieves a folder as URL.
     *
     * @return a folder as URL
     * @throws IOException if not possible to retrieve the folder URL.
     */
    protected Enumeration<URL> getResourceDirectory() throws IOException {
        /*
         * Getting resource with empty string means request a folder.
         * */
        return getClass().getClassLoader().getResources(StringUtils.EMPTY);
    }
}
