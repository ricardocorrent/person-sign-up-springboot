package com.ws.commons.server.messagebundle;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messageloader.CacheMessageQualifier;
import com.ws.commons.server.messageloader.MessageLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * This class handles internationalization of messages for specific exceptions.
 * It finds message for exception or cause(s).
 *
 * <p><b>Example:</b></p>
 * <pre><code>
 * exception-messages-en.json
 * 
 * {
 *   "java.lang.Throwable": {
 *     "code": "SOL-00001",
 *     "message": "Internal server error"
 *   },
 *   "java.lang.Exception": {
 *     "code": "SOL-00002",
 *     "message": "Internal server error"
 *   },
 *   "java.sql.SQLException": {
 *     "code": "SOL-000003",
 *     "message": "Error to access the database"
 *   }
 * }
 * </code></pre>
 *
 * @author  William Santos
 * @author  Diego A. Costa
 * @version 5.4.0 - 2017-12-14 - Added new internationalization methods.
 * @since   2.1.0 - 2016-07-13
 */
public class MessageExceptionBundle {

    private final Logger logger;
    private final MessageLoader messageLoader;

    /**
     * Default file name prefix for the messages.
     */
    public static final String FILE_NAME_PREFIX = "exception-messages";
    
    //TODO https://redmineproduto.wssim.com.br/issues/47789
    private static final String DEFAULT_EXCEPTION = Exception.class.getName();
    
    /**
     * Default constructor. Injected through CDI static injection.
     *
     * @author                  Diego A. Costa
     * @param messageLoader     to load internationalization files. Annotated with {@link CacheMessageQualifier}.
     */
    @Inject
    public MessageExceptionBundle(@CacheMessageQualifier final MessageLoader messageLoader) {
        this.messageLoader = messageLoader;
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * The {@link Locale} will be extracted from {@link HttpServletRequest} injected by {@link Context},
     * but case if is not possible to perform this extraction, the default {@link Locale} will be used.
     *
     * @param exception to be translated.
     * @return          a internationalized exception message created based on the exception(or cause) name and {@link Locale}.<br>
     */
    public ExceptionMessage getMessage(final Throwable exception) {
        Objects.requireNonNull(exception, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("exception"));

        logger.debug("Resolving exception message for '{}' using default locale", exception.getClass().getName());
        final Map<String, ExceptionMessage> messages = messageLoader.load(FILE_NAME_PREFIX);
        return getMessage(exception, messages);
    }
    
    /**
     * Resolves exception message's based on {@link Locale}.
     *
     * @param exception to be translated.
     * @param locale    to set the language.
     * @return          a internationalized exception message created based on the exception(or cause) name and {@link Locale}.
     */
    public ExceptionMessage getMessage(final Throwable exception, final Locale locale) {
        Objects.requireNonNull(exception, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("exception"));
        Objects.requireNonNull(locale, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("locale"));

        logger.debug("Resolving exception message for '{}' using locale {}", exception.getClass().getName(), locale.toLanguageTag());
        final Map<String, ExceptionMessage> messages = messageLoader.load(FILE_NAME_PREFIX, locale);
        return getMessage(exception, messages);
    }


    /**
     * Resolves exception message's using default {@link Locale}.
     *
     * @param exception to be translated.
     * @param messages  available internationalized messages
     * @return          an internationalized exception message created based on the exception(or cause) name.
     */
    protected ExceptionMessage getMessage(final Throwable exception, final Map<String, ExceptionMessage> messages) {
        if (exception == null) {
            logger.warn("Received exception was null. The default one will be used instead: {}.", DEFAULT_EXCEPTION);
            return messages.get(DEFAULT_EXCEPTION);
        }

        logger.debug("Resolving exception message for '{}' using default locale", exception.getClass().getName());
        return Optional
                .ofNullable(messages.get(exception.getClass().getName()))
                .orElse(getMessage(exception.getCause(), messages));
    }
}
