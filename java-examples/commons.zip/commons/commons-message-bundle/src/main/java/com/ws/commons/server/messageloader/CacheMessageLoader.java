package com.ws.commons.server.messageloader;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.exception.ExceptionMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * File resolver for messages that find message files based on the language. 
 * <p>Message files must be on JSON format. This class is used to avoid reloading message file on every request.</p>
 *
 * @author  William Santos
 * @author  Diego A. Costa
 * @author  Rogerio Kiihl
 * @version 5.4.0 - 2017-12-12 - Added new loading methods.
 * @version 6.0.0 - 2018-04-17 - Added new locale availability check methods.
 *                               Removed deprecated methods and dependencies.
 * @see     MessageLoaderFactory
 * @since   2.1.0 - 2016-08-25
 */
public class CacheMessageLoader extends AbstractMessageLoader implements MessageLoader{

    private static CacheMessageLoader instance;

    public static final String DEFAULT_FILENAME_PREFIX = "messages";
    private final Map<String, Map<String, ExceptionMessage>> localeCache = new HashMap<>();
    private final Logger logger = LoggerFactory.getLogger(getClass());
    
    private CacheMessageLoader() {}
    
    /**
     * Method to return a singleton instance of this class.
     *
     * @return a singleton instance of the class.
     */
    public static synchronized CacheMessageLoader getInstance() {
        if (instance == null) {
            instance = new CacheMessageLoader();
        }
        return instance;
    }

    /**
     * Returns the locale to be used as default.
     *
     * @author  Rogerio Kiihl
     * @return  {@link Locale#ENGLISH} as default
     * @since   6.0.0 - 2018-04-26
     */
    @Override
    public Locale getDefaultLocale() {
        return Locale.ENGLISH;
    }

    /**
     * Returns the default file name prefix used to name the localization files resource.
     *
     * @author  Rogerio Kiihl
     * @return  a default file name
     * @since   6.0.0 - 2018-04-26
     */
    @Override
    public String getDefaultFileNamePrefix() {
        return DEFAULT_FILENAME_PREFIX;
    }

    /**
     * Tries to find an available {@link Locale} within the {@code requestedLocales} parameter.
     *
     * @see     MessageLoader#getAvailableLocale(Enumeration)
     * @return  an available {@link Locale} if found, {@link Locale#ENGLISH} otherwise
     * @since   6.0.0 - 2018-04-17
     */
    @Override
    public Locale getAvailableLocale(Enumeration<Locale> requestedLocales) {
        logger.debug("Trying to find an available locale under the requested ones: {}", requestedLocales);
        while (requestedLocales.hasMoreElements()) {
            final Locale locale = requestedLocales.nextElement();

            if (isLocaleAvailable(locale)) {
                logger.debug("Available locale found: {}", locale.toLanguageTag());
                return locale;
            }
        }

        final Locale defaultLocale = getDefaultLocale();
        logger.debug("No available locale found within the requested ones. Using the default locale instead: {}.", defaultLocale.toLanguageTag());

        return defaultLocale;
    }

    /**
     * Checks if the requested {@link Locale} is available.
     *
     * @param locale    to be checked
     * @return          true if the localization is available
     * @since           6.0.0 - 2018-04-17
     */
    @Override
    public boolean isLocaleAvailable(Locale locale) {
        return !load(locale).isEmpty();
    }

    /**
     * Loads a message file based on default {@link Locale}.
     *
     * @return  a {@link Map} containing the loaded file messages.
     * @see     MessageLoader#load()
     * @see     AbstractMessageLoader#loadMessages(String, Locale)
     */
    @Override
    public Map<String, ExceptionMessage> load() {
        logger.debug("Loading messages using the default locale");
        return load(getDefaultFileNamePrefix(), getDefaultLocale());
    }
    
    /**
     * Loads a message file based on the {@link Locale} provided by parameter {@code locale}.
     *
     * @return  a {@link Map} containing the loaded file messages.
     * @see     MessageLoader#load(java.util.Locale)
     * @see     AbstractMessageLoader#loadMessages(String, Locale)
     */
    @Override
    public Map<String, ExceptionMessage> load(final Locale locale) {
        logger.debug("Loading messages for locale {}", locale.toLanguageTag());
        return load(getDefaultFileNamePrefix(), locale);
    }
    
    /**
     * <p>
     * Loads a message file based on {@code fileNamePrefix} parameter.
     * Example:
     * <pre>
     *      {@literal Map<String, ExceptionMessage> messages = load("pt-BR")};
     * </pre>
     * will load messages from "messages-pt-BR.json" file.
     * </p>
     *
     * @return  a {@link Map} containing the loaded file messages.
     * @see     MessageLoader#load(java.lang.String)
     * @see     AbstractMessageLoader#loadMessages(String, Locale)
     */
    @Override
    public Map<String, ExceptionMessage> load(String fileNamePrefix) {
        logger.debug("Loading messages using file name prefix '{}' and default locale", fileNamePrefix);
        return load(fileNamePrefix, getDefaultLocale());
    }
    
    /**
     * Loads a message file based on {@code fileNamePrefix} and {@code locale} parameters.
     *
     * @return  a {@link Map} containing the loaded file messages.
     * @see     MessageLoader#load(java.lang.String, java.util.Locale)
     * @see     AbstractMessageLoader#loadMessages(String, Locale)
     */
    @Override
    public Map<String, ExceptionMessage> load(final String fileNamePrefix, final Locale locale) {
        Objects.requireNonNull(fileNamePrefix, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("fileNamePrefix"));
        Objects.requireNonNull(locale, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("locale"));

        if (fileNamePrefix.trim().isEmpty()) {
            throw new IllegalArgumentException(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("fileNamePrefix"));
        }
        
        final String fileName = buildLanguageFileName(fileNamePrefix, locale);
        logger.debug("Target messages file is '{}'. Checking if a cached instance is available.", fileName);
        if (localeCache.containsKey(fileName)) {
            logger.debug("Cached values found for messages file '{}'", fileName);
            return localeCache.get(fileName);
        }

        logger.info("Loading i18n messages from file '{}'", fileName);
        
        final Map<String, ExceptionMessage> messagesMap = loadMessages(fileNamePrefix, locale);
        logger.info("{} messages loaded from file '{}'", messagesMap.size(), fileName);

        localeCache.put(fileName, messagesMap);
        return messagesMap;
    }
}
