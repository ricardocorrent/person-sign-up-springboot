package com.ws.commons.server.messageloader;

import com.ws.commons.server.exception.ExceptionMessage;
import org.junit.Test;
import org.mockito.Mockito;
import uk.org.lidalia.slf4jtest.LoggingEvent;
import uk.org.lidalia.slf4jtest.TestLogger;
import uk.org.lidalia.slf4jtest.TestLoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsMapContaining.hasEntry;
import static org.hamcrest.collection.IsMapContaining.hasKey;
import static org.junit.Assert.*;
import static org.mockito.Mockito.spy;


/**
 * Unit test cases for {@link AbstractMessageLoader}.
 *
 * <p>
 * This class contains validation methods to verify messages' files loading when any service prompts
 * a message from messages-xx.json file.
 * </p>
 *
 * @author  Diego Armange Costa
 * @author  Rogerio Kiihl
 * @author  Diego Armange Costa
 * @version 6.0.0 - 2018-04-19 - Changed messageLoader instance (removed deprecated class)
 * @version 7.2.5 - 2018-09-05 - Fix resource loader. Changed to Load the resource from all libraries.
 * @since   5.4.0 - 2017-12-12
 */
public class AbstractMessageLoaderUnitTest {
    private static final Locale LOCALE_WITH_COUNTRY = new Locale("tt", "TT");

    private static final String MESSAGES_FILE_PREFIX = "messages";
    
    private static final String KEY_ONLY_WITHOUT_COUNTRY = "tenth.message";
    
    private static final String KEY_TO_FROM_INTERNAL_LIB = "seventh.message";
    
    private static final String KEY_TO_MANY_COUNTRIES = "ninth.message";
    
    private static final String TRANSLATION_FOR_A_COUNTRY_ONLY = "with country.";

    private static CacheMessageLoader messageLoader = CacheMessageLoader.getInstance();

    private static TestLogger logger = TestLoggerFactory.getTestLogger(AbstractMessageLoader.class);
    private static final String FILE_NOT_FOUND = "Couldn't find the file: %s";

    /**
     * Test case to validate {@link LoggingEvent#getLevel()} functionality.
     * <p>
     * It must try load but should not propagate exceptions and return the log level warn.
     * </p>
     */
    @Test
    public void testGetLevel() {
        messageLoader.load("any", LOCALE_WITH_COUNTRY);
        final List<LoggingEvent> loggingEvents = logger.getLoggingEvents();
        final LoggingEvent event = loggingEvents.stream().filter(n -> n.toString().contains( String.format(FILE_NOT_FOUND, "any"))).findFirst().orElse(null);
        assertNotNull(event);
        assertEquals(event.getLevel().toString(), "ERROR");
    }

    /**
     * Validates if a {@link NullPointerException} is not thrown when loading an empty JSON.
     * <p>
     * It must try load but should not propagate exceptions.
     * </p>
     */
    @Test
    public void doNotThrowExceptionToEmptyJSON(){
        messageLoader.load("empty", LOCALE_WITH_COUNTRY);
    }
    
    /**
     * Validates if a {@link NullPointerException} is not thrown when loading an invalid JSON.
     * <p>
     * It must try load but should not propagate exceptions.
     * </p>
     */
    @Test
    public void doNotThrowExceptionToInvalidJSON(){
        messageLoader.load("invalid", LOCALE_WITH_COUNTRY);
    }

    /**
     * Validates if a {@link NullPointerException} is not thrown when loading a message's file with invalid prefix.
     * <p>
     * It must try load but should not propagate exceptions.
     * </p>
     */
    @Test
    public void doNotThrowExceptionToInvalidPrefix(){
        messageLoader.load("any", LOCALE_WITH_COUNTRY);
    }

    /**
     * Validates if message file is loaded even if its resource has different case.
     */
    @Test
    public void getMessageWhenResourceHasDifferentCase(){
        final CacheMessageLoader localMessageLoader = spy(CacheMessageLoader.getInstance());
        
        Mockito.doReturn(null).when(localMessageLoader).getResource(Mockito.anyString());
        
        final Map<String, ExceptionMessage> messagesMap = localMessageLoader.load(MESSAGES_FILE_PREFIX, LOCALE_WITH_COUNTRY);
        
        assertThat(messagesMap.size(), greaterThan(0));
    }

    /**
     * Validates if message file is loaded when resource is an empty directory.
     * <p>
     * It must return an empty message map when resource directory has no configuration.
     * </p>
     */
    @SuppressWarnings("javadoc")
    @Test
    public void getMessageWhenResourcesIsAnEmptyDirectory() throws IOException{
        final CacheMessageLoader localMessageLoader = spy(CacheMessageLoader.getInstance());
        
        Mockito.doReturn(getFakeEnumeration()).when(localMessageLoader).getResourceDirectory();
        
        final Map<String, ExceptionMessage> messagesMap = localMessageLoader.load("any", LOCALE_WITH_COUNTRY);
        
        assertThat(messagesMap.size(), is(0));
    }

    /**
     * Validates if the message file specific for a language is loaded when prompting messages from a {@link Locale} with country.
     * <p>
     * It must load both files when available. The country-specific and the language-specific ones.
     * </p>
     */
    @Test
    public void itShouldLoadMessagesWithoutACountryEvenIfItsPrompted4CountryMessages() {
        final Map<String, ExceptionMessage> messagesMap = messageLoader.load(MESSAGES_FILE_PREFIX, LOCALE_WITH_COUNTRY);
        
        assertThat(messagesMap.size(), greaterThan(0));
        
        assertThat(messagesMap, hasKey(KEY_ONLY_WITHOUT_COUNTRY));
    }
    
    /**
     * In this case, if any internal LIB implements the same message key, 
     * these key should not replace the same key in any higher hierarchy level.
     */
    @Test
    public void itShouldNotReplaceATranslationForACountry4ATranslationWithoutACountry() {
        final Map<String, ExceptionMessage> messagesMap = messageLoader.load(MESSAGES_FILE_PREFIX, LOCALE_WITH_COUNTRY);
        
        assertThat(messagesMap.size(), greaterThan(0));
        
        ExceptionMessage exceptionMessage = messagesMap.get(KEY_TO_MANY_COUNTRIES);
        
        assertNotNull(exceptionMessage);
        
        assertEquals(exceptionMessage.getMessage(), TRANSLATION_FOR_A_COUNTRY_ONLY);
        
        assertThat(messagesMap, hasEntry(
                equalTo(KEY_TO_MANY_COUNTRIES), 
                hasProperty("message", equalTo(TRANSLATION_FOR_A_COUNTRY_ONLY))
            ));
    }

    /**
     * Validates if loaded message file contains specific key.
     */
    @Test
    public void itShouldLoadMessagesFromInternalAnyLib() {
        final Map<String, ExceptionMessage> messagesMap = messageLoader.load(MESSAGES_FILE_PREFIX, LOCALE_WITH_COUNTRY);
        
        assertThat(messagesMap.size(), greaterThan(0));
        
        assertThat(messagesMap, hasKey(KEY_TO_FROM_INTERNAL_LIB));
    }
    
    private Enumeration<URL> getFakeEnumeration() {
        return new Enumeration<URL>() {
            /**
             * @see java.util.Enumeration#hasMoreElements()
             */
            @Override
            public boolean hasMoreElements() {
                return false;
            }

            /**
             * @see java.util.Enumeration#nextElement()
             */
            @Override
            public URL nextElement() {
                return null;
            }
        };
    }
}
