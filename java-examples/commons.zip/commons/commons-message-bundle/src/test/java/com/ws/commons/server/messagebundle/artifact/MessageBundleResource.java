package com.ws.commons.server.messagebundle.artifact;

import com.ws.commons.server.messagebundle.MessageBundle;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Resource-based class created only for testing purposes.
 * <p>This class is used to to provide a resource layer for integration tests.</p>
 *
 * @author  Diego A. Costa
 * @since   5.4.0 - 2017-12-15
 */
@Path("message-bundle-artifact")
public class MessageBundleResource {

    @Inject
    private MessageBundle messageBundle;
    
    /**
     * HTTP GET handler method.
     *
     * @return an internationalized message and status code 200 (OK) when the request is processed successfully.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response getDefaultMessage() {
        final String message = messageBundle.getDefaultMessage("fourth.message").getMessage();
        
        return Response.ok().entity(message).build();
    }
}
