package com.ws.commons.server.messagebundle;

import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.messageloader.CacheMessageLoader;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import javax.inject.Inject;
import java.sql.SQLException;
import java.util.Locale;

import static org.junit.Assert.assertEquals;

/**
 * Unit tests for {@link MessageExceptionBundle} class, an exception handler for specific exceptions.
 *
 * @author  Diego Armange Costa
 * @since   5.4.0 - 2017-12-15
 */
@RunWith(CdiTestRunner.class)
public class MessageExceptionBundleUnitTest {
    
    private static final Locale LOCALE_COUNTRY_TEST = new Locale("TT", "TT");

    @Inject
    private MessageExceptionBundle injectedMessageExBundle;
    
    private CacheMessageLoader spiedCacheMessageLoader;
    
    private MessageExceptionBundle spiedMessageExBundle;
    
    /**
     * Method called before test execution.
     * <p>It creates spies and mocks.</p>
     */
    @Before
    public void beforeTest() {
        spiedCacheMessageLoader = Mockito.spy(CacheMessageLoader.getInstance());
        
        spiedMessageExBundle = Mockito.spy(new MessageExceptionBundle(spiedCacheMessageLoader));
        
        Mockito.doReturn(LOCALE_COUNTRY_TEST).when(spiedCacheMessageLoader).getDefaultLocale();
    }
    
    /**
     * Tests retrieving an {@link ExceptionMessage} passing a {@link Locale} via parameter.
     * <p>Expects to return the internationalized message.</p>
     */
    @Test
    public void getMessagePassingLocale() {
        assertEquals("Error to access the database", injectedMessageExBundle.getMessage(new SQLException(), LOCALE_COUNTRY_TEST).getMessage());
    }

    /**
     * Tests retrieving an {@link ExceptionMessage} without passing a {@link Locale} via parameter.
     * <p>Expects to return the internationalized message, retrieved by default {@link Locale}.</p>
     */
    @Test
    public void getMessageWithoutLocale() {
        assertEquals("Error to access the database", spiedMessageExBundle.getMessage(new SQLException()).getMessage());
    }

    /**
     * Tests retrieving an {@link ExceptionMessage} from an error which cause is not an {@link SQLException}.
     * <p>Expects to return the internationalized message, pointing an internal server error.</p>
     */
    @Test
    public void getMessageWithNotMappedException() {
        assertEquals("Internal server error", spiedMessageExBundle.getMessage(new NullPointerException()).getMessage());
    }
    
    /**
     * Tests retrieving a message from an exception's cause.
     * <p>Expects to return the internationalized message.</p>
     */
    @Test
    public void getMessageFromExceptionCause() {
        final NullPointerException exception = new NullPointerException();
        
        exception.initCause(new java.sql.SQLException());
        
        assertEquals("Error to access the database", spiedMessageExBundle.getMessage(exception).getMessage());
    }
    
    /**
     * Tries to retrieve a message passing {@code null} as the exception parameter to {@link MessageExceptionBundle}.
     * <p>Expects to throw a {@link NullPointerException}</p>
     */
    @Test(expected = NullPointerException.class)
    public void throwNPEWhenPassNullException() {
        spiedMessageExBundle.getMessage(null);
    }
}
