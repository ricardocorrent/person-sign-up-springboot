package com.ws.commons.server.messagebundle;

import com.sollar.test.BaseUnitTest;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.server.exception.ExceptionMessage;
import com.ws.commons.server.factory.MessageBundleLocaleFactory;
import com.ws.commons.server.factory.MessageBundleLocaleProvider;
import com.ws.commons.server.messagebundle.resource.LocaleProvider;
import com.ws.commons.server.messageloader.CacheMessageLoader;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link MessageBundle}'s internationalization based on {@link Locale}.
 *
 * @author  William Santos
 * @author  Diego A. Costa
 * @version 5.0.0 2017-10-24
 * @since   3.1.0 2016-10-24
 */
@RunWith(CdiTestRunner.class)
public class MessageBundleUnitTest extends BaseUnitTest {

    private static final Locale LOCALE_TEST_WITH_COUNTRY = new Locale("TT", "TT");

    private static final String PLURAL_KEY = "plural.text";
    
    private static final String NO_PARAMETER_MESSAGE = "fourth.message";
    
    private static final String INDEXED_PARAMETER_KEY = "fifth.message";
    
    private static final String NAMED_PARAMETER_KEY = "sixth.message";
    
    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    private CacheMessageLoader spiedMessageLoader;

    @Inject
    private MessageBundle injectedMessageBundle;
    
    private MessageBundle spiedMessageBundle;

    private MessageBundleLocaleFactory localeFactory;

    /**
     * Create spies and mocks.
     */
    @BeforeClass
    public static void beforeClass() {}
    
    /**
     * Methods called before the execution of the tests.
     * <p>Defines the default {@link Locale}.</p>
     */
    @Before
    public void beforeTest() {
        spiedMessageLoader = spy(CacheMessageLoader.getInstance());
        
        doReturn(LOCALE_TEST_WITH_COUNTRY).when(spiedMessageLoader).getDefaultLocale();
        
        spiedMessageBundle = spy(new MessageBundle(spiedMessageLoader));

        localeFactory = spy(new MessageBundleLocaleFactory(spiedMessageLoader));
    }

    /**
     * Validates the formatting of a message in plural.
     */
    @Test
    public void formatMessageWithParameterChoicesPassingThirdChoice() {
        final ExceptionMessage message = this.injectedMessageBundle.getMessage(PLURAL_KEY, LOCALE_TEST_WITH_COUNTRY, 123);
        
        assertEquals("There are 123 files", message.getMessage());
    }

    /**
     * Validates the formatting of a message in singular.
     */
    @Test
    public void formatMessageWithParameterChoicesPassingSecondChoice() {
        final ExceptionMessage message = this.injectedMessageBundle.getMessage(PLURAL_KEY, LOCALE_TEST_WITH_COUNTRY, 1);
        
        assertEquals("There is one file", message.getMessage());
    }

    /**
     * Validates the formatting of a message when the parameter is neutral (0).
     */
    @Test
    public void formatMessageWithParameterChoicesPassingFirstChoice() {
        final ExceptionMessage message = this.injectedMessageBundle.getMessage(PLURAL_KEY, LOCALE_TEST_WITH_COUNTRY, 0);
        
        assertEquals("There is no file", message.getMessage());
    }

    /**
     * Validates the message without passing parameters when they are needed.
     * <p>Expects to throw an {@link IllegalStateException} since the quantity parameter is not passed.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void noParametersTest() {
        this.injectedMessageBundle.getMessage(PLURAL_KEY, LOCALE_TEST_WITH_COUNTRY);
    }
    
    /**
     * Validates the message without passing the {@link Locale} parameter.
     * <p>Expects to retrieve the message with default {@link Locale} successfully.</p>
     */
    @Test
    public void getMessageWithoutLocale() {
        final ExceptionMessage message = spiedMessageBundle.getDefaultMessage(PLURAL_KEY, 0);
        
        assertEquals("There is no file", message.getMessage());
    }
    
    /**
     * Validates the message when the internationalization file does not exist.
     * <p>Expects to retrieve the message's key.</p>
     */
    @Test
    public void getMessageWithoutInternationalizationFile() {
        final ExceptionMessage message = this.injectedMessageBundle.getMessage(PLURAL_KEY, Locale.GERMANY, 0);
        
        assertEquals(PLURAL_KEY, message.getMessage());
    }
    
    /**
     * Tests the retrieval of a message without passing the message's key.
     * <p>Expects to throw a {@link NullPointerException}.</p>
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullKey() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("key"));
        
        injectedMessageBundle.getMessage(null, LOCALE_TEST_WITH_COUNTRY, 0);
    }
    
    /**
     * Tests the retrieval of a message without passing the parameter {@link Locale}.
     * <p>Expects to throw a {@link NullPointerException}.</p>
     */
    @Test
    public void throwsNullPointerExceptionWhenPassNullLocale() {
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("locale"));
        
        injectedMessageBundle.getMessage(PLURAL_KEY, null, 0);
    }
    
    /**
     * Success test case of a formatted message recovery passing all parameters.
     * <p>Must return a formatted message.</p>
     */
    @Test
    public void getMessageWithNamedParameter() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put("message", "message found");
        
        final ExceptionMessage message = injectedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, LOCALE_TEST_WITH_COUNTRY, parameters);
        
        assertEquals("Sixth message found.", message.getMessage());
    }
    
    /**
     * Success test case of a formatted message recovery without passing the {@link Locale} parameter.
     * <p>It must return a formatted message with the default {@link Locale} language.</p>
     */
    @Test
    public void getMessageWithNamedParameterWithoutLocale() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put("message", "message found");
        
        final ExceptionMessage message = spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
        
        assertEquals("Sixth message found.", message.getMessage());
    }

    /**
     * Success test case of a formatted message recovery with composed named parameter.
     * <p>It must return a formatted message composed with the parameter passed successfully.</p>
     */
    @Test
    public void getMessageWithComposedNamedParameter() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put("message", NO_PARAMETER_MESSAGE);
        
        final ExceptionMessage message = spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
        
        assertEquals("Sixth Fourth message..", message.getMessage());
    }
    
    /**
     * Tests retrieval of a message without sending named parameter.
     * <p>Expects to throw a, {@link IllegalStateException}.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void getMessageWithNamedParameterWhenSendEmpty() {
        final Map<String, Object> parameters = new HashMap<>();
        
        spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
    }
    
    /**
     * Tests retrieval of a message by sending {@code null} parameters to {@link MessageBundle}.
     * <p>Expects to throw an {@link IllegalStateException}.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void getMessageWithNamedParameterWhenSendNullParameterValue() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put("123", null);
        
        spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
    }

    /**
     * Tests retrieval of a message by sending {@code null} message's key to {@link MessageBundle}.
     * <p>Expects to throw an {@link IllegalStateException}.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void getMessageWithNamedParameterWhenSendNullParameterKey() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put(null, "");
        
        spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
    }

    /**
     * Tests retrieval of a message by sending empty {@code parameters} and {@code key} to {@link MessageBundle}.
     * <p>Expects to throw an {@link IllegalStateException}.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void getMessageWithNamedParameterWhenSendEmptyParameterKey() {
        final Map<String, Object> parameters = new HashMap<>();
        
        parameters.put("", "");
        
        spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, parameters);
    }

    /**
     * Tests retrieval of a message by sending {@code null} parameters, which refers to the {@link Map} of messages,
     * to {@link MessageBundle}.
     * <p>Expects to throw an {@link IllegalStateException}.</p>
     */
    @Test(expected = IllegalStateException.class)
    public void getMessageWithNamedParameterWhenNoSendParameters() {
        spiedMessageBundle.getNamedParameterMessage(NAMED_PARAMETER_KEY, null);
    }
    
    /**
     * Success retrieval test of a message that doesn't require parameters to build it.
     * <p>It must return a formatted message.</p>
     */
    @Test
    public void getNamedParameterMessageWhenIsNotNecessaryParameters() {
        spiedMessageBundle.getNamedParameterMessage(NO_PARAMETER_MESSAGE, null);
    }
    
    /**
     * Test to retrieve a message which {@link Locale} message's file is not found in the project files.
     * <p>It must return the message's key.</p>
     */
    @Test
    public void getMessageWithNamedParameterWithoutFileMessages() {
        doReturn("noFile").when(spiedMessageLoader).getDefaultFileNamePrefix();
        
        final ExceptionMessage message = spiedMessageBundle.getNamedParameterMessage(NO_PARAMETER_MESSAGE, null);
        
        assertEquals(NO_PARAMETER_MESSAGE, message.getMessage());
    }
    
    /**
     * Tests formatted message indexing parameters.
     * <p>It must return the formatted message with the passed parameter.</p>
     */
    @Test
    public void getMessageWithIndexedParameter() {
        final ExceptionMessage message = injectedMessageBundle.getMessage(INDEXED_PARAMETER_KEY, LOCALE_TEST_WITH_COUNTRY, "message found");
        
        assertEquals("Fifth message found.", message.getMessage());
    }

    /**
     * Test to retrieve a message with indexed parameters which {@link Locale} message's file is not found in the project files.
     * <p>It must return the message's key.</p>
     */
    @Test
    public void getMessageWithIndexedParameterWithoutFileMessages() {
        doReturn("noFile").when(spiedMessageLoader).getDefaultFileNamePrefix();
        
        final ExceptionMessage message = spiedMessageBundle.getMessage(INDEXED_PARAMETER_KEY, LOCALE_TEST_WITH_COUNTRY, "message found");
        
        assertEquals(INDEXED_PARAMETER_KEY, message.getMessage());
    }

    /**
     * Test to retrieve a message with composed and indexed parameter.
     * <p>It must return the formatted message.</p>
     */
    @Test
    public void getMessageWithComposedIndexedParameter() {
        final ExceptionMessage message = injectedMessageBundle.getMessage(INDEXED_PARAMETER_KEY, LOCALE_TEST_WITH_COUNTRY, NO_PARAMETER_MESSAGE);
        
        assertEquals("Fifth Fourth message..", message.getMessage());
    }

    /**
     * Success retrieval test of a message that doesn't require parameters to build it.
     * <p>It must return the formatted message.</p>
     */
    @Test
    public void getIndexedParameterMessageWhenIsNotNecessaryParameters() {
        spiedMessageBundle.getDefaultMessage(NO_PARAMETER_MESSAGE);
    }
    
    /**
     * Tests retrieval of a message using the {@link MessageBundle#getMessage(String, Object[], Locale)} deprecated method.
     * <p>It must return the formatted message.</p>
     */
    @Test
    public void getMessageWithIndexedParameterDeprecated() {
        final ExceptionMessage message = injectedMessageBundle.getMessage(INDEXED_PARAMETER_KEY, new Object[] {"message found"}, LOCALE_TEST_WITH_COUNTRY);
        
        assertEquals("Fifth message found.", message.getMessage());
    }

    /**
     * Test case for {@link MessageBundle#getDefaultLocale()} to validate if a {@link Locale} is returned
     * even when a {@link Exception} occurs.
     *
     * @author  Lucas Dillmann
     * @since   7.3.2 - 2018-09-14
     */
    @Test
    public void shouldReturnTheDefaultLocaleEvenWhenAnExceptionOccurs() {
        // scenario
        final HttpServletRequest request = mock(HttpServletRequest.class);
        doThrow(new RuntimeException()).when(request).getLocales();
        injectedMessageBundle.httpServletRequest = request;

        // execution
        final Locale locale = injectedMessageBundle.getDefaultLocale();

        // validation
        assertNotNull(locale);
        assertThat(locale, is(injectedMessageBundle.messageLoader.getDefaultLocale()));
    }

    /**
     * Tries to recover the {@link Locale} from {@link LocaleProvider}, which is an implementation of the {@link MessageBundleLocaleProvider}
     * interface.
     * <p>It may find the implementation through SPI strategies successfully.</p>
     */
    @Test
    public void getLocaleFromSpiImplementation() {
        final LocaleProvider provider = new LocaleProvider();
        final List<MessageBundleLocaleProvider> providers = new ArrayList<>();
        providers.add(provider);
        final Iterator<MessageBundleLocaleProvider> iterator = providers.iterator();

        Mockito.doReturn(iterator).when(localeFactory).getIteratorFromServiceLoader();

        Locale locale = localeFactory.getLocale();

        Assert.assertEquals(provider.getLocale(), locale);
    }

    /**
     * Tries to recover the {@link Locale} from {@link HttpServletRequest}.
     * <p>It may find the the servlet request through CDI static instance successfully.</p>
     */
    @Test
    public void getServletRequestLocaleFromLocaleFactory() {
        final HttpServletRequest mockedRequest = Mockito.mock(HttpServletRequest.class);
        Mockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        Mockito.doReturn(LOCALE_TEST_WITH_COUNTRY).when(mockedRequest).getLocale();

        final Locale locale = localeFactory.getLocale();

        Mockito.verify(localeFactory).getServletRequestFromCdi();
        Assert.assertEquals(LOCALE_TEST_WITH_COUNTRY, locale);
    }

    /**
     * Tries to recover the {@link Locale} from {@link LocaleProvider}, which is an implementation of the {@link MessageBundleLocaleProvider}
     * interface.
     * <p>It may find the implementation through CDI strategies successfully.</p>
     */
    @Test
    public void getLocaleFromCdiInstance() {
        final LocaleProvider provider = new LocaleProvider();

        Mockito.doReturn(provider).when(localeFactory).getLocaleProviderFromCdi();

        final Locale locale = localeFactory.getLocale();

        Mockito.verify(localeFactory).getLocaleProviderFromCdi();
        Assert.assertEquals(provider.getLocale(), locale);
    }

    /**
     * Tries to recover the client's {@link Locale} when it's not possible to extract it from the current {@link HttpServletRequest}
     * and when no implementation of {@link MessageBundleLocaleProvider} is found.
     * <p>It should return the default {@link Locale}</p>
     */
    @Test
    public void getDefaultLocaleFromLocaleFactory() {
        Mockito.doReturn(null).when(localeFactory).getServletRequestFromCdi();
        final Locale locale = localeFactory.getLocale();

        Mockito.verify(localeFactory).getServletRequestFromCdi();
        Assert.assertEquals(LOCALE_TEST_WITH_COUNTRY, locale);
    }

    /**
     * Tries to recover the client's {@link Locale} when there are multiple implementations of the {@link MessageBundleLocaleProvider}
     * interface.
     * <p>When SPI finds more than one implementation, the service may throw a {@link RuntimeException}</p>
     */
    @Test
    public void shouldThrowWhenMultipleImplementations() {
        final String expectedMessage = "Multiple implementations found using Java SPI for class " + MessageBundleLocaleProvider.class.getName() + ".";
        final LocaleProvider provider = new LocaleProvider();
        final List<MessageBundleLocaleProvider> providers = new ArrayList<>();

        thrown.expect(RuntimeException.class);
        thrown.expectMessage(expectedMessage);

        providers.add(provider);
        providers.add(provider);
        final Iterator<MessageBundleLocaleProvider> iterator = providers.iterator();

        Mockito.doReturn(iterator).when(localeFactory).getIteratorFromServiceLoader();
        localeFactory.getLocale();
    }
}
