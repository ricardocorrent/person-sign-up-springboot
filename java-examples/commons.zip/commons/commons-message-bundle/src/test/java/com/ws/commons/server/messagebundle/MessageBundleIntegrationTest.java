package com.ws.commons.server.messagebundle;

import com.ws.commons.server.factory.MessageBundleLocaleFactory;
import com.ws.commons.server.factory.MessageBundleLocaleProvider;
import com.ws.commons.server.messagebundle.artifact.MessageBundleResource;
import com.ws.commons.server.messagebundle.resource.LocaleProvider;
import com.ws.commons.server.messageloader.CacheMessageLoader;
import com.ws.commons.server.messageloader.CacheMessageQualifier;
import com.ws.commons.server.messageloader.MessageLoader;
import org.glassfish.hk2.api.Factory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.enterprise.util.AnnotationLiteral;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import java.util.*;

/**
 * Integration test cases for {@link MessageBundle}.
 *
 * @author  Diego A. Costa
 * @author  Rogerio Kiihl
 * @author  Hendric Gabriel Cechinato
 * @version 6.0.0 - 2018-04-17 - Tests targeting multiple locale request feature
 *                               Forced null return for the mocking invocation of {@link HttpServletRequest#getLocales()}
 * @version 7.3.4 - 2018-09-28 - Tests adapted to {@link MessageBundleLocaleFactory} behavior
 * @since   5.4.0 - 2017-12-15
 */
@SuppressWarnings("javadoc")
@RunWith(PowerMockRunner.class)
@PrepareForTest({MessageBundle.class})
public class MessageBundleIntegrationTest extends JerseyTest {

    @SuppressWarnings("serial")
    private static class CacheMessageQualifierImpl extends AnnotationLiteral<CacheMessageQualifier> implements CacheMessageQualifier {}

    private static final String RESOURCE_ARTIFACT_BASE_URI = "message-bundle-artifact";

    private ResourceConfig resourceConfig;

    private static HttpServletRequest mockedRequest = Mockito.mock(HttpServletRequest.class);

    private final MessageLoader messageLoader = CacheMessageLoader.getInstance();

    /**
     * Performs {@link JerseyTest} configuration to run tests.
     *
     * @see JerseyTest#configure
     */
    @Override
    public Application configure() {

        resourceConfig = new ResourceConfig(MessageBundleResource.class);

        resourceConfig.property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, true);

        resourceConfig.property(ServerProperties.PROCESSING_RESPONSE_ERRORS_ENABLED, true);

        resourceConfig.register(new AbstractBinder() {

            @SuppressWarnings({ "unchecked", "rawtypes", "synthetic-access" })
            @Override
            protected void configure() {
                enable(TestProperties.LOG_TRAFFIC);

                enable(TestProperties.DUMP_ENTITY);

                bindFactory(new Factory<HttpServletRequest>() {
                    /**
                     * @see Factory#provide()
                     */
                    @Override
                    public HttpServletRequest provide() {
                        return MessageBundleIntegrationTest.mockedRequest;
                    }

                    /**
                     * @see Factory#dispose(java.lang.Object)
                     */
                    @Override
                    public void dispose(final HttpServletRequest instance) {
                        //Do nothing
                    }

                }).to(HttpServletRequest.class);
                
                bindFactory( new Factory() {
                    /**
                     * @see Factory#provide()
                     */
                    @Override
                    public Object provide() {
                        return CacheMessageLoader.getInstance();
                    }

                    /**
                     * @see Factory#dispose(java.lang.Object)
                     */
                    @Override
                    public void dispose(final Object instance) {
                      //Do nothing
                    }

                }).to(MessageLoader.class)
                .qualifiedBy(new CacheMessageQualifierImpl());
                
                bind(MessageBundle.class).to(MessageBundle.class);
            }
        });
        return resourceConfig;
    }
    
    /**
     * Tests internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()} to
     * retrieve a {@link Locale} from the current {@link HttpServletRequest}, when the Locale is TT.
     * <p>It must return the internationalized message.</p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageUsingContextLocaleUsingTT() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(new Locale("TT", "TT")).when(mockedRequest).getLocale();
        PowerMockito.doReturn(null).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();
        Assert.assertEquals("Fourth message.", response.readEntity(String.class));
    }

    /**
     * Tests internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()} to
     * retrieve a {@link Locale} from the current {@link HttpServletRequest}, when the Locale is ZZ.
     * <p>
     * It must return the internationalized message.
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageUsingContextLocaleUsingZZ() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(new Locale("zz", "ZZ")).when(mockedRequest).getLocale();
        PowerMockito.doReturn(null).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Quarta mensagem.", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()}
     * to retrieve a {@link Locale} from the current {@link HttpServletRequest}, using an array of Locales as the feeder
     * to load the file.
     * <p>
     * In this test case, two {@link Locale}s are requested (TT and ZZ). It must return the internationalized message
     * valid to the first context locale (TT)
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithAllAvailable() throws Exception {

        ArrayList<Locale> localesRequest = new ArrayList<>();
        localesRequest.add(new Locale("tt", "TT"));
        localesRequest.add(new Locale("zz", "ZZ"));

        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(Collections.enumeration(localesRequest)).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Fourth message.", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()}
     * to retrieve a {@link Locale} from the current {@link HttpServletRequest}, using an array of Locales as the feeder
     * to load the file.
     * <p>
     * In this test case, two {@link Locale}s are requested (TT and XX). It must return the internationalized message
     * valid to the first context Locale (TT)
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithOnlyFirstAvailable() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));

        ArrayList<Locale> localesRequest = new ArrayList<>();
        localesRequest.add(new Locale("tt", "TT"));
        localesRequest.add(new Locale("XX", "XX"));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(Collections.enumeration(localesRequest)).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Fourth message.", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()}
     * to retrieve a {@link Locale} from the current {@link HttpServletRequest}, using an array of Locales as the feeder
     * to load the file.
     * <p>
     * In this test case, two {@link Locale}s are requested (XX and zz-ZZ). It must return the internationalized message
     * valid to the first context locale (zz-ZZ), because XX doesn't have its message file in project files.
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithOnlySecondAvailable() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));
        ArrayList<Locale> localesRequest = new ArrayList<>();
        localesRequest.add(new Locale("XX", "XX"));
        localesRequest.add(new Locale("zz", "ZZ"));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(Collections.enumeration(localesRequest)).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Quarta mensagem.", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of internationalization message's file using {@link MessageBundleLocaleFactory#getServletRequestFromCdi()}
     * to retrieve a {@link Locale} from the current {@link HttpServletRequest}, using an array of Locales as the feeder
     * to load the file.
     * <p>
     * In this test case, two {@link Locale}s are requested (XX and zz-ZZ). It must return no internationalized massage,
     * since all the provided Locales don't have message's files in the resources path.
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithNonAvailable() throws Exception{
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));

        ArrayList<Locale> localesRequest = new ArrayList<>();
        localesRequest.add(new Locale("XX", "XX"));
        localesRequest.add(new Locale("YY", "YY"));

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(mockedRequest).when(localeFactory).getServletRequestFromCdi();
        PowerMockito.doReturn(Collections.enumeration(localesRequest)).when(mockedRequest).getLocales();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("fourth.message", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of {@link MessageBundleLocaleProvider} implementation through SPI strategies.
     * <p>
     * It must find and return an internationalized message successfully.
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithAvailableLocaleFromSpiImplementation() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));
        final LocaleProvider provider = new LocaleProvider();
        final List<MessageBundleLocaleProvider> providers = new ArrayList<>();
        providers.add(provider);
        final Iterator<MessageBundleLocaleProvider> iterator = providers.iterator();

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        PowerMockito.doReturn(iterator).when(localeFactory).getIteratorFromServiceLoader();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Fourth message.", response.readEntity(String.class));
    }

    /**
     * Tests retrieval of {@link MessageBundleLocaleProvider} implementation through CDI static instance.
     * <p>
     * It must find and return an internationalized message successfully.
     * </p>
     *
     * @throws Exception if mocked class is null
     */
    @Test
    public void getMessageWithAvailableLocaleFromCdiInstance() throws Exception {
        final MessageBundleLocaleFactory localeFactory = PowerMockito.spy(new MessageBundleLocaleFactory(messageLoader));
        final LocaleProvider provider = new LocaleProvider();

        PowerMockito.whenNew(MessageBundleLocaleFactory.class).withAnyArguments().thenReturn(localeFactory);
        Mockito.doReturn(provider).when(localeFactory).getLocaleProviderFromCdi();

        final Response response = target(RESOURCE_ARTIFACT_BASE_URI).request().get();

        Assert.assertEquals("Fourth message.", response.readEntity(String.class));
    }
}
