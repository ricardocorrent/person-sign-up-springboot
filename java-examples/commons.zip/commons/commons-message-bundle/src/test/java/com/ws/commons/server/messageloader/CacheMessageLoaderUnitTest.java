package com.ws.commons.server.messageloader;

import com.ws.commons.server.exception.ExceptionMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.util.*;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.spy;

/**
 * Unit test cases for {@link CacheMessageLoader} class.
 *
 * @author  Diego Armange Costa
 * @author  Rogerio Kiihl
 * @version 6.0.0 - 2018-04-19 - Removed the DefaultMessageLoader dependency
 *                  2018-04-27 - Added tests previously directed to MessageLoader
 * @since   5.4.0 - 2017-12-12
 */
@RunWith(MockitoJUnitRunner.class)
public class CacheMessageLoaderUnitTest {

    private static final Locale LOCALE_TEST = new Locale("tt", "");
    private static final Locale LOCALE_COUNTRY_TEST = new Locale("tt", "TT");
    private static final Locale LOCALE_ALTERNATIVE = new Locale("zz", "ZZ");
    private static final Locale LOCALE_NOT_AVAILABLE = new Locale("XX");
    
    private static final int EXPECTED_MESSAGES_WITH_COUNTRY = 12;
    private static final int EXPECTED_MESSAGES_WITHOUT_COUNTRY = 6;

    private static CacheMessageLoader cacheMessageLoader = CacheMessageLoader.getInstance();

    /**
     * Method called before the execution of tests.
     * <p>
     * Spies the {@link CacheMessageLoader}.
     * </p>
     */
    @Before
    public void beforeTest() {
        resetCacheInstance();

        final CacheMessageLoader cache = CacheMessageLoader.getInstance();
        cacheMessageLoader = spy(cache);
        spy(AbstractMessageLoader.class);
    }

    private void resetCacheInstance() {
        try {
            Class<CacheMessageLoader> cacheClass = CacheMessageLoader.class;
            Field field = cacheClass.getDeclaredField("instance");
            field.setAccessible(true);
            field.set(null, null);
        }
        catch (Exception e)
        {
            Assert.fail("fail reseting cache: " + e.getMessage());
        }
    }

    /**
     * Verifies if default {@link Locale} is being retrieved properly.
     * <p>
     * It must return the default language from implementation.
     * </p>
     */
    @Test
    public void checkDefaultLocale() {
        assertThat(cacheMessageLoader.getDefaultLocale(), is(Locale.ENGLISH));
    }

    /**
     * Validates if message's file default filename is being retrieved properly.
     * <p>
     * It must return the default filename prefix.
     * </p>
     */
    @Test
    public void checkDefaultFileNamePrefix() {
        assertThat(cacheMessageLoader.getDefaultFileNamePrefix(), is(CacheMessageLoader.DEFAULT_FILENAME_PREFIX));
    }

    /**
     * Verifies if default message file without country is loaded properly.
     * <p>
     * It must load the messages from {@link CacheMessageLoader}.
     * </p>
     */
    @Test
    public void loadMessagesWithoutParametersWithoutCountry(){
        doReturn(LOCALE_TEST).when(cacheMessageLoader).getDefaultLocale();

        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load();

        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));
        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITHOUT_COUNTRY));
    }

    /**
     * Verifies if message file with country is loaded properly.
     * <p>
     * It must load the messages from {@link CacheMessageLoader}.
     * </p>
     */
    @Test
    public void loadMessagesWithoutParametersWithCountry(){
        doReturn(LOCALE_COUNTRY_TEST).when(cacheMessageLoader).getDefaultLocale();

        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load();

        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));
        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
    }

    /**
     * Validates if message file with only the {@link Locale} as parameter is loaded properly.
     * <p>
     * It must load the messages from {@link CacheMessageLoader}.
     * </p>
     */
    @Test
    public void loadMessagesWithLocaleWithoutCountry(){
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load(LOCALE_TEST);
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITHOUT_COUNTRY));
    }
    
    /**
     * Must load the messages from {@link CacheMessageLoader}.
     */
    @Test
    public void loadMessagesWithLocaleWithCountry(){
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load(LOCALE_COUNTRY_TEST);
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
    }

    /**
     * Verifies if message file is loaded properly when passing its filename prefix and {@link Locale}.
     * <p>
     * It must load the messages from {@link CacheMessageLoader}.
     * </p>
     */
    @Test
    public void loadMessagesWithLocaleWithPrefixWithoutCountry(){
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load("msg", LOCALE_TEST);
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(4));
    }

    /**
     * Verifies if message file is loaded properly when passing its filename prefix and a {@link Locale} with the
     * specific country.
     * <p>
     * It must load the messages from {@link CacheMessageLoader}.
     * </p>
     */
    @Test
    public void loadMessagesWithLocaleWithPrefixWithCountry(){
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load("msg", LOCALE_COUNTRY_TEST);
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(7));
    }

    /**
     * Verifies if message file is loaded properly when passing its {@link Locale} and country.
     * <p>
     * It must load the messages from {@link CacheMessageLoader} using both messages' files, the language-specific and the
     * country-specific.
     * </p>
     */
    @Test
    public void loadMessagesWithStringsPassingCountry(){
        final Map<String, ExceptionMessage> messagedMap = cacheMessageLoader.load("messages", new Locale("TT", "TT"));
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
    }
    
    /**
     * Validates if language-specific message's file is being loaded properly and stored successfully, when country is not
     * passed, without parameters.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithoutParametersWithoutCountry(){
        doReturn(LOCALE_TEST).when(cacheMessageLoader).getDefaultLocale();

        // First call
        cacheMessageLoader.load(LOCALE_COUNTRY_TEST);

        // Other call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load();

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITHOUT_COUNTRY));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader, times(2)).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if language-specific and country-specific messages' files are being loaded properly and stored successfully,
     * when country is passed, without parameters.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithoutParametersWithCountry(){
        doReturn(LOCALE_COUNTRY_TEST).when(cacheMessageLoader).getDefaultLocale();
        // First call
        cacheMessageLoader.load(LOCALE_COUNTRY_TEST);

        // Other call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load();

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if language-specific message's file is being loaded properly and stored successfully, when country is not
     * passed as parameter.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithLocaleWithoutCountry(){
        // First call
        cacheMessageLoader.load(LOCALE_TEST);

        // Other call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load(LOCALE_TEST);

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITHOUT_COUNTRY));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if language-specific and country-specific messages' files are being loaded properly and stored successfully,
     * when country is passed.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithLocaleWithCountry(){
        // First call
        cacheMessageLoader.load(LOCALE_COUNTRY_TEST);

        // Other call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load(LOCALE_COUNTRY_TEST);

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if language-specific message's file is being loaded properly and stored successfully, when country is not
     * passed as parameter but filename prefix is.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithLocaleWithPrefixWithoutCountry(){
        // First call
        cacheMessageLoader.load("msg", LOCALE_TEST);

        // Other call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load("msg", LOCALE_TEST);

        assertThat(messagedMap.size(), is(4));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));


    }

    /**
     * Validates if language-specific and country-specific messages' files are being loaded properly and stored successfully,
     * when country is passed, according to filename prefix provided.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void storeMessagesWithLocaleWithPrefixWithCountry(){
        // First call
        cacheMessageLoader.load("msg", LOCALE_COUNTRY_TEST);

        // Second call
        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load("msg", LOCALE_COUNTRY_TEST);

        assertThat(messagedMap.size(), is(7));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if language-specific and country-specific messages' files are being loaded properly and stored successfully,
     * according to filename prefix provided.
     * <p>
     * It must store the messages and load only once.
     * </p>
     */
    @Test
    public void loadMessagesWithoutParametersAndLocaleWithCountry(){
        doReturn(LOCALE_COUNTRY_TEST).when(cacheMessageLoader).getDefaultLocale();

        final Map<String,ExceptionMessage> messagedMap = cacheMessageLoader.load("msg");
        verify(cacheMessageLoader).load(Mockito.anyString(), Mockito.any(Locale.class));

        assertThat(messagedMap.size(), is(7));
    }
    
    /**
     * Validates if an {@link IllegalArgumentException} is thrown when an invalid prefix is provided.
     */
    @Test(expected = IllegalArgumentException.class)
    public void throwExceptionToInvalidPrefix(){
        cacheMessageLoader.load("", LOCALE_COUNTRY_TEST);
    }
    
    /**
     * Validates if a {@link NullPointerException} is thrown when a {@code null} prefix is provided.
     */
    @Test(expected = NullPointerException.class)
    public void throwExceptionToNullPrefix(){
        cacheMessageLoader.load(null, LOCALE_COUNTRY_TEST);
    }

    /**
     * Validates if a {@link NullPointerException} is thrown when a {@code null} {@link Locale} is provided.
     */
    @Test(expected = NullPointerException.class)
    public void throwExceptionToNullLocale(){
        cacheMessageLoader.load("msg", null);
    }

    /**
     * Validates if language-specific and country-specific messages' files are being loaded properly and stored successfully,
     * when country and language are passed as {@link String}, according to filename prefix provided.
     * <p>
     * It must store the messages and load twice.
     * </p>
     */
    @Test
    public void storeMessagesWithStringsPassingCountry() {
        // First call
        cacheMessageLoader.load(LOCALE_COUNTRY_TEST);

        // Other call
        final Map<String, ExceptionMessage> messagedMap = cacheMessageLoader.load("messages", new Locale("TT", "TT"));

        assertThat(messagedMap.size(), is(EXPECTED_MESSAGES_WITH_COUNTRY));
        verify(cacheMessageLoader, times(2)).load(Mockito.anyString(), Mockito.any(Locale.class));
        verify(cacheMessageLoader).loadMessages(Mockito.anyString(), Mockito.any(Locale.class));
    }

    /**
     * Validates if method {@link CacheMessageLoader#isLocaleAvailable(Locale)} return correctly when {@link Locale} is
     * not available.
     * <p>
     * It must negate the availability of a non-treated locale.
     * </p>
     */
    @Test
    public void isLocaleAvailableWithFalseResult() {
        assertFalse(cacheMessageLoader.isLocaleAvailable(LOCALE_NOT_AVAILABLE));
    }

    /**
     * Validates if method {@link CacheMessageLoader#isLocaleAvailable(Locale)} return correctly when {@link Locale} is
     * available.
     * <p>
     * It must confirm the availability of a treat locale.
     * </p>
     */
    @Test
    public void isLocaleAvailableWithPositiveResult() {
        assertTrue(cacheMessageLoader.isLocaleAvailable(LOCALE_TEST));
    }

    private Enumeration<Locale> getEnumerator(Locale... locales)
    {
        ArrayList<Locale> array = new ArrayList<>();
        for (Locale locale : locales) {
            array.add(locale);
        }

        return Collections.enumeration(array);
    }
    /**
     * Validates if method {@link CacheMessageLoader#getAvailableLocale(Enumeration)} picks the first available {@link Locale}
     * correctly.
     * <p>
     * It must choose the first {@link Locale} from the preference due availability of it.
     * </p>
     */
    @Test
    public void pickFirstPreferredLocale() {
        Locale locale = cacheMessageLoader.getAvailableLocale(getEnumerator(LOCALE_TEST, LOCALE_ALTERNATIVE, LOCALE_NOT_AVAILABLE));
        assertThat(locale, is(LOCALE_TEST));
    }

    /**
     * Validates if method {@link CacheMessageLoader#getAvailableLocale(Enumeration)} picks the first available {@link Locale}
     * correctly.
     * <p>
     * It must choose the second {@link Locale} from the preference, since the first one is not available.
     * </p>
     */
    @Test
    public void pickSecondPreferredLocale() {
        Locale locale = cacheMessageLoader.getAvailableLocale(getEnumerator(LOCALE_NOT_AVAILABLE, LOCALE_ALTERNATIVE, LOCALE_TEST));
        assertThat(locale, is(LOCALE_ALTERNATIVE));
    }

    /**
     * Validates if method {@link CacheMessageLoader#getAvailableLocale(Enumeration)} picks default {@link Locale}, since
     * there aren't any in the preference list available.
     */
    @Test
    public void pickDefaultLocaleSincePreferredIsNotAvailable() {
        Locale locale = cacheMessageLoader.getAvailableLocale(getEnumerator(LOCALE_NOT_AVAILABLE));
        assertThat(locale, is(cacheMessageLoader.getDefaultLocale()));
    }
}
