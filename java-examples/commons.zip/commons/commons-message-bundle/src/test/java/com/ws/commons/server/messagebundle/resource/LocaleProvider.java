package com.ws.commons.server.messagebundle.resource;

import com.ws.commons.server.factory.MessageBundleLocaleProvider;

import java.util.Locale;

/**
 * This class describes a {@link Locale} provider only for testing purposes.
 * <p>
 * Provides an implementation of {@link MessageBundleLocaleProvider} to retrieve its {@link Locale}.
 * </p>
 *
 * @author  Hendric Gabriel Cechinato
 * @since   7.3.4 - 2018-09-28
 */
public class LocaleProvider implements MessageBundleLocaleProvider {

    /**
     * Method to retrieve a custom {@link Locale} for testing purposes.
     *
     * @return a custom {@link Locale}.
     */
    @Override
    public Locale getLocale() {
        return new Locale("tt", "TT");
    }
}
