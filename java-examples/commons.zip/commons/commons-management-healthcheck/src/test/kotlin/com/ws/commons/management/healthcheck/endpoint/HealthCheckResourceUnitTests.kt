package com.ws.commons.management.healthcheck.endpoint

import com.nhaarman.mockito_kotlin.any
import com.nhaarman.mockito_kotlin.doAnswer
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.stub
import com.ws.commons.management.healthcheck.Health
import com.ws.commons.management.healthcheck.HealthCheckStatus
import com.ws.commons.management.healthcheck.Status
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import java.net.URI
import javax.ws.rs.core.Response
import javax.ws.rs.core.UriBuilder
import javax.ws.rs.core.UriInfo
import kotlin.random.Random
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
@RunWith(MockitoJUnitRunner.Silent::class)
class HealthCheckResourceUnitTests {

    @Mock
    private lateinit var configuration: HealthCheckConfiguration

    @Mock
    private lateinit var service: HealthCheckService

    @Mock
    private lateinit var uriInfo: UriInfo

    private lateinit var resource: HealthCheckResource
    private val baseUri = URI("http://unit-test")

    @Before
    fun setup() {
        stub {
            on { configuration.enabled() } doReturn true
            on { service.currentStatus() } doReturn HealthCheckStatus(Status.UP, null)
            on { service.currentStatus(any()) } doReturn Health.healthy().build()
            on { uriInfo.absolutePathBuilder } doAnswer { UriBuilder.fromUri(baseUri) }
            on { uriInfo.requestUri } doReturn baseUri
        }

        resource = HealthCheckResource(service, configuration)
        resource.uriInfo = uriInfo
    }

    @Test
    fun `when configuration is set as disabled it should tell management api that resource is disabled`() {
        // scenario
        stub {
            on { configuration.enabled() } doReturn false
        }

        // execution
        val componentEnabled = resource.isComponentEnabled()

        // validation
        assertFalse { componentEnabled }
    }

    @Test
    fun `when everything is up it should return response with status code 200`() {
        // execution
        val response = resource.getAll()

        // validation
        assertNotNull(response)
        assertTrue { response.status == Response.Status.OK.statusCode }
    }

    @Test
    fun `when something is down it should return response with status code 503`() {
        // scenario
        stub {
            on { service.currentStatus() } doReturn HealthCheckStatus(Status.DOWN, null)
        }

        // execution
        val response = resource.getAll()

        // validation
        assertNotNull(response)
        assertTrue { response.status == Response.Status.SERVICE_UNAVAILABLE.statusCode }

    }

    @Test
    fun `when an invalid check is requested by name it should return a response with 404 status`() {
        // scenario
        stub {
            on { service.currentStatus(any()) } doReturn null as Health?
        }

        // execution
        val response = resource.getOne(Random.nextInt().toString())

        // validation
        assertNotNull(response)
        assertTrue { response.status == Response.Status.NOT_FOUND.statusCode }
    }

    @Test
    fun `when check requested by name is up it should return response with status code 200`() {
        // scenario
        val name = Random.nextInt().toString()
        stub {
            on { service.currentStatus(name) } doReturn Health.healthy().build()
        }

        // execution
        val response = resource.getOne(name)

        // validation
        assertNotNull(response)
        assertTrue { response.status == Response.Status.OK.statusCode }
    }

    @Test
    fun `when check requested by name is down it should return response with status code 503`() {
        // scenario
        val name = Random.nextInt().toString()
        stub {
            on { service.currentStatus(name) } doReturn Health.unhealthy().build()
        }

        // execution
        val response = resource.getOne(name)

        // validation
        assertNotNull(response)
        assertTrue { response.status == Response.Status.SERVICE_UNAVAILABLE.statusCode }

    }
}