package com.ws.commons.management.healthcheck.endpoint

import com.nhaarman.mockito_kotlin.doAnswer
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.stub
import com.ws.commons.management.healthcheck.Health
import com.ws.commons.management.healthcheck.HealthCheckStatus
import com.ws.commons.management.healthcheck.Status
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import javax.enterprise.inject.Instance
import kotlin.random.Random
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
@RunWith(MockitoJUnitRunner::class)
class HealthCheckServiceUnitTests {

    @Mock
    private lateinit var configuration: HealthCheckConfiguration

    @Mock
    private lateinit var statusProducer: Instance<HealthCheckStatus>

    private lateinit var service: HealthCheckService

    private val detailsName = Random.nextInt().toString()
    private val detailsValue = Health.healthy(Random.nextDouble().toString()).build()

    @Before
    fun setup() {
        stub {
            on { statusProducer.get() } doAnswer {
                val details = mapOf(Pair(detailsName, detailsValue))
                HealthCheckStatus(Status.UP, details)
            }
            on { configuration.showDetails() } doReturn true
        }

        service = HealthCheckService(statusProducer, configuration)
    }

    @Test
    fun `when currentStatus method is called it should return current application health check status`() {
        // execution
        val currentValue = service.currentStatus()

        // validation
        assertNotNull(currentValue)
    }

    @Test
    fun `when currentStatus method is called it should return current check status`() {
        // execution
        val currentValue = service.currentStatus(detailsName)

        // validation
        assertNotNull(currentValue)
        assertTrue { currentValue.details == detailsValue.details }
        assertTrue { currentValue.status == detailsValue.status }
        assertTrue { currentValue.message == detailsValue.message }
    }

    @Test
    fun `when currentStatus is called and configuration is set to hide details it should return application status with details null`() {
        // scenario
        stub {
            on { configuration.showDetails() } doReturn false
        }

        // execution
        val currentValue = service.currentStatus()

        // validation
        assertNotNull(currentValue)
        assertNull(currentValue.details)
    }

}