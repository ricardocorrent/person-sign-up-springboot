package com.ws.commons.management.healthcheck

import com.nhaarman.mockito_kotlin.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import java.lang.IllegalArgumentException
import javax.enterprise.inject.Instance
import kotlin.random.Random
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
@RunWith(MockitoJUnitRunner::class)
class HealthCheckStatusProducerUnitTests {

    @get:Rule
    val expectedException = ExpectedException.none()

    @Mock
    private lateinit var checker1: HealthCheck
    @Mock
    private lateinit var checker2: HealthCheck
    @Mock
    private lateinit var checkers: Instance<HealthCheck>

    private lateinit var producer: HealthCheckStatusProducer

    @Before
    fun setup() {
        stub {
            on { checker1.check() } doReturn Health.healthy().build()
            on { checker1.name } doReturn Random.nextInt().toString()
            on { checker2.check() } doReturn Health.healthy().build()
            on { checker2.name } doReturn Random.nextInt().toString()
            on { checkers.iterator() } doAnswer { mutableListOf(checker1, checker2).iterator() }
        }

        producer = HealthCheckStatusProducer(checkers)
    }

    @Test
    fun `when production is called it should call HealthCheck implementations`() {
        // execution
        producer.produce()

        // validation
        verify(checker1, times(1)).check()
        verify(checker2, times(1)).check()
    }

    @Test
    fun `when producer is called and any HealthCheck implementation fails with exception it should return unhealthy status`() {
        // scenario
        stub {
            on { checker1.check() } doThrow RuntimeException()
        }

        // execution
        val result = producer.produce()

        // validation
        assertNotNull(result)
        assertTrue { result.status == Status.DOWN }
    }

    @Test
    fun `when producer is called it should call HealthCheck implementations and destroy CDI beans after invocation`() {
        // execution
        producer.produce()

        // validation
        verify(checker1, times(1)).check()
        verify(checker2, times(1)).check()
        verify(checkers, times(1)).destroy(checker1)
        verify(checkers, times(1)).destroy(checker2)
    }

    @Test
    fun `when producer is called and any check returns unhealthy it should return down status`() {
        // scenario
        stub {
            on { checker1.check() } doReturn Health.unhealthy().build()
            on { checker2.check() } doReturn Health.healthy().build()
        }

        // execution
        val result = producer.produce()

        // validation
        assertNotNull(result)
        assertTrue { result.status == Status.DOWN }
    }

    @Test
    fun `when producer is called and all check returns healthy it should return up status`() {
        // scenario
        stub {
            on { checker1.check() } doReturn Health.healthy().build()
            on { checker2.check() } doReturn Health.healthy().build()
        }

        // execution
        val result = producer.produce()

        // validation
        assertNotNull(result)
        assertTrue { result.status == Status.UP }
    }

    @Test
    fun `when producer is called and multiple HealthCheck implementations have same name it should throw exception`() {
        // scenario
        val name = Random.nextLong().toString()
        stub {
            on { checker1.name } doReturn name
            on { checker2.name } doReturn name
        }

        // validation
        expectedException.expect(IllegalArgumentException::class.java)
        expectedException.expectMessage("Multiple implementations detected for name $name: ${checkers.joinToString { it.javaClass.simpleName }}")

        // execution
        producer.produce()
    }

}