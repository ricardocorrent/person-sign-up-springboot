package com.ws.commons.management.healthcheck

import org.junit.Test
import java.lang.RuntimeException
import kotlin.random.Random
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
class HealthUnitTests {

    @Test
    fun `when requested a healthy status it should return an object with UP flag`() {
        // scenario
        val key = Random.nextInt().toString()
        val message = Random.nextInt().toString()
        val details = Random.nextInt()

        // execution
        val result = Health.healthy(message).withDetails(key, details).build()

        // validation
        assertNotNull(result)
        assertTrue { result.status == Status.UP }
        assertTrue { result.message == message }
        assertTrue { result.details.findLast { it.key == key }!!.value == details }
    }

    @Test
    fun `when requested a unhealthy status it should return an object with DOWN flag`() {
        // scenario
        val key = Random.nextInt().toString()
        val message = Random.nextInt().toString()
        val details = Random.nextInt()

        // execution
        val result = Health.unhealthy(message).withDetails(key, details).build()

        // validation
        assertNotNull(result)
        assertTrue { result.status == Status.DOWN }
        assertTrue { result.message == message }
        assertTrue { result.details.findLast { it.key == key }!!.value == details }
    }

    @Test
    fun `when requested an unhealthy status with an exception it should use exception message as unhealthy status message`() {
        // scenario
        val exception = RuntimeException(Random.nextInt().toString())

        // execution
        val result = Health.unhealthy(exception).build()

        // validation
        assertNotNull(result)
        assertTrue { result.message == exception.message }
    }

}