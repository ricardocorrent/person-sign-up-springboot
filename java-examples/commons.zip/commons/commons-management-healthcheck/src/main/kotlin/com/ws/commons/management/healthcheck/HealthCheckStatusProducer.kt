package com.ws.commons.management.healthcheck

import org.slf4j.LoggerFactory
import java.lang.IllegalArgumentException
import javax.enterprise.inject.Default
import javax.enterprise.inject.Instance
import javax.enterprise.inject.Produces
import javax.inject.Inject

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
@Default
class HealthCheckStatusProducer @Inject constructor(private val checkers: Instance<HealthCheck>) {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Produces [HealthCheckStatus] instances with current application status by invoking all available
     * [HealthCheck] implementations, collecting all results into a single object. If any [HealthCheck] fails to execute
     * or returns unhealthy status this class will consider as a unhealthy result.
     *
     * @return Current application status
     */
    @Produces
    fun produce(): HealthCheckStatus {
        logger.debug("Querying application enabled HeathChecks")
        val details = checkers.asSequence().also { validateNamesUniqueness(it) }.map { invokeAndRelease(it) }.toMap()
        val status = details.map { it.value.status }.firstOrNull { it == Status.DOWN } ?: Status.UP

        logger.debug("Query complete. Current status is $status.")
        return HealthCheckStatus(status, details)
    }

    private fun validateNamesUniqueness(checkers: Sequence<HealthCheck>) =
            checkers.groupBy { it.name }.asSequence().firstOrNull { it.value.size > 1 }
                    ?.apply { throw IllegalArgumentException("Multiple implementations detected for name $key: ${value.joinToString { it.javaClass.simpleName }}") }

    private fun invokeAndRelease(checker: HealthCheck) =
            checker.let { Pair(it.name, tryInvoke(it)) }.apply { checkers.destroy(checker) }

    /**
     * Invokes provided [HealthCheck] implementation under a try/catch statemet, returning an unhealthy status when any
     * exception happens
     *
     * @param checker Implementation to be invoked
     * @return Check result
     */
    private fun tryInvoke(checker: HealthCheck) =
            try {
                checker.check()
            } catch (exception: Exception) {
                logger.warn("Health Check implementation failed with an error", exception)
                Health.unhealthy(exception).build()
            }

}

