package com.ws.commons.management.healthcheck.endpoint.extensions

import com.ws.commons.management.healthcheck.HealthCheckStatus
import com.ws.commons.management.healthcheck.endpoint.HealthCheckResponse
import com.ws.commons.management.resource.toJsonHateoasLink
import javax.ws.rs.core.Link

/**
 * Extension function for simple conversion from [HealthCheckStatus] to [HealthCheckResponse] with optional list
 * of HATEOAS links
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
fun HealthCheckStatus.toResponse(links: List<Link> = emptyList()) =
        HealthCheckResponse(status, details, links.map { it.toJsonHateoasLink() })