package com.ws.commons.management.healthcheck

/**
 * Health Check provider definition
 *
 * This interface exposes the required method that any Health Check should provide to expose any application status.
 * All implementations are found using CDI producer at [HealthCheckStatusProducer.produce].
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
interface HealthCheck {

    /**
     * Returns the name of the check. Should be unique and formatted using camel case.
     */
    val name: String

    /**
     * Checks and returns the result of the application component state
     */
    fun check(): Health
}
