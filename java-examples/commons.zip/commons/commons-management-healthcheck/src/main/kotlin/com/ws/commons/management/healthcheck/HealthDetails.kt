package com.ws.commons.management.healthcheck

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-04-02
 */
data class HealthDetails(val key: String, val value: Any)