package com.ws.commons.management.healthcheck

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-04-02
 */
class HealthBuilder internal constructor(private val status: Status,
                                         private val message: String? = null) {

    private val details = mutableListOf<HealthDetails>()

    fun withDetails(key: String, value: Any): HealthBuilder {
        details += HealthDetails(key, value)
        return this
    }

    fun build() =
            Health(message, details.toList(), status)

}