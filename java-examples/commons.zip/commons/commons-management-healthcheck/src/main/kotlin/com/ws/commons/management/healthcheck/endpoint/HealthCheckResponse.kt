package com.ws.commons.management.healthcheck.endpoint

import com.fasterxml.jackson.annotation.JsonProperty
import com.ws.commons.management.healthcheck.Health
import com.ws.commons.management.healthcheck.Status
import com.ws.commons.management.resource.JsonHateoasLink

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-27
 */
data class HealthCheckResponse(val status: Status,
                               val details: Map<String, Health>?,
                               @JsonProperty("_links")
                               val links: List<JsonHateoasLink>?)

