package com.ws.commons.management.healthcheck

import org.eclipse.jetty.http.HttpStatus

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
enum class Status(val code: Int) {
    UP (HttpStatus.OK_200),
    DOWN (HttpStatus.SERVICE_UNAVAILABLE_503)
}

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
data class HealthCheckStatus(val status: Status, val details: Map<String, Health>?)
