package com.ws.commons.management.healthcheck.endpoint

import com.ws.commons.management.healthcheck.HealthCheckStatus
import javax.enterprise.inject.Instance
import javax.inject.Inject

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-09-25
 */
class HealthCheckService @Inject constructor(private val statusProducer: Instance<HealthCheckStatus>,
                                             private val configuration: HealthCheckConfiguration) {

    fun currentStatus() =
            removeDetailsIfShouldNotShow(statusProducer.get())

    fun currentStatus(checkId: String) =
            currentStatus().details?.get(checkId)

    /**
     * Checks if configuration properties don't allow details to be sent in response. If so, removes they from it.
     */
    private fun removeDetailsIfShouldNotShow(status: HealthCheckStatus) =
            status.takeIf { configuration.showDetails() } ?: HealthCheckStatus(status.status, null)

}