package com.ws.commons.management.healthcheck.endpoint

import org.apache.deltaspike.core.api.config.ConfigProperty
import org.apache.deltaspike.core.api.config.Configuration

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
@Configuration(prefix = "healthcheck.")
interface HealthCheckConfiguration {

    @ConfigProperty(name = "enabled", defaultValue = "true")
    fun enabled(): Boolean

    @ConfigProperty(name = "showdetails", defaultValue = "false")
    fun showDetails(): Boolean
}