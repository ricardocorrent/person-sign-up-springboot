package com.ws.commons.management.healthcheck

import com.ws.commons.management.healthcheck.Status.UP
import com.ws.commons.management.healthcheck.Status.DOWN

/**
 * Health Check status
 *
 * This class encapsulates a Health Check containing the response status (UP or DOWN),
 * response message and details
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-25
 */
data class Health(val message: String?,
                  val details: List<HealthDetails>,
                  val status: Status) {

    companion object {

        /**
         * Produces a healthy (UP) response builder
         *
         * @param message Check response message (optional)
         * @param details Check response details (optional)
         */
        @JvmStatic
        @JvmOverloads
        fun healthy(message: String? = null) =
                HealthBuilder(UP, message)

        /**
         * Produces a unhealthy (DOWN) response builder
         *
         * @param message Check response message (optional)
         */
        @JvmStatic
        @JvmOverloads
        fun unhealthy(message: String? = null) =
                HealthBuilder(DOWN, message)

        /**
         * Produces a unhealthy (DOWN) response builder from a [Throwable]
         *
         * @param exception Check response exception
         */
        @JvmStatic
        fun unhealthy(exception: Throwable) =
                HealthBuilder(DOWN, exception.message)
    }

}

