package com.ws.commons.management.healthcheck.endpoint

import com.ws.commons.management.ConditionalComponent
import com.ws.commons.management.ManagementComponent
import com.ws.commons.management.healthcheck.endpoint.extensions.toResponse
import javax.inject.Inject
import javax.ws.rs.GET
import javax.ws.rs.Path
import javax.ws.rs.PathParam
import javax.ws.rs.Produces
import javax.ws.rs.core.*

/**
 * JAX-RS resource for management API
 *
 * This JAX-RS based resource exposes health check information under management endpoints. Values returned
 * by this resource are retrieved from HealthCheck API.
 *
 * @see com.ws.commons.management.healthcheck.HealthCheckStatus
 */
@Path("/health")
@ManagementComponent
class HealthCheckResource @Inject constructor(private val service: HealthCheckService,
                                              private val configuration: HealthCheckConfiguration) : ConditionalComponent {

    @Context
    internal lateinit var uriInfo: UriInfo

    /**
     * @see ConditionalComponent.isComponentEnabled
     */
    override fun isComponentEnabled() =
            configuration.enabled()

    /**
     * Retrieves application global health status and details
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    fun getAll(): Response {
        val currentStatus = service.currentStatus()
        val self = Link.fromUri(uriInfo.requestUri).rel("self").build()
        val links = currentStatus.details
                ?.map { Link.fromUriBuilder(uriInfo.absolutePathBuilder.path(it.key)).rel(it.key).build() }
                ?.let { it + self }
                ?: listOf(self)

        return Response
                .status(currentStatus.status.code)
                .entity(currentStatus.toResponse(links))
                .build()
    }

    /**
     * Retrieves a single health check status details
     */
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    fun getOne(@PathParam("id") id: String) =
            service.currentStatus(id)
                    ?.let { Response.status(it.status.code).entity(it).build() }
                    ?: Response.status(Response.Status.NOT_FOUND).build()


}
