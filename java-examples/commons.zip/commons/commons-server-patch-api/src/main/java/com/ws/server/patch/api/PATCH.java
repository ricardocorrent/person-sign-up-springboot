package com.ws.server.patch.api;

import java.lang.annotation.*;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.NameBinding;

/**
 * JAX-RS {@link HttpMethod} annotation for Patch requests
 *
 * <p>This annotation extends JAX-RS API to provide support for PATCH requests. This annotation can be used in
 * JAX-RS resources methods to accept HTTP PATCH requests with partial updates.</p>
 *
 * <p>Please note that any JAX-RS resource with methods using this annotation needs to implement {@link PatchResource}
 * interface. {@link PatchReaderInterceptor} expects the implementation to do his job and allow {@link PATCH}
 * requests to work.</p>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-11
 */
@Target({ ElementType.METHOD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@HttpMethod("PATCH")
@Documented
@NameBinding
public @interface PATCH {}
