package com.ws.server.patch.api;

/**
 * Common-use patch compatible media types for JSON
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-11
 */
public final class PatchMediaType {

    /**
     * Private default constructor to avoid instances
     */
    private PatchMediaType() {
    }

    /**
     * RFC 7386 JSON Merge Patch
     */
    public static final String JSON_MERGE_PATCH = "application/merge-patch+json";

    /**
     * RFC 6902 JSON Patch
     */
    public static final String JSON_PATCH = "application/json-patch+json";
}
