package com.ws.server.patch.api;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

/**
 * JAX-RS {@link WebApplicationException} extension for {@link PATCH} related operations
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-11
 */
public final class PatchException extends WebApplicationException {

    /**
     * Construct a new instance with a supplied message and HTTP status code.
     *
     * @param message the detail message (which is saved for later retrieval
     *                by the {@link #getMessage()} method).
     */
    public PatchException(final String message) {
        this(message, Response.Status.UNSUPPORTED_MEDIA_TYPE);
    }

    /**
     * Construct a new instance with a supplied message and HTTP status code.
     *
     * @param message the detail message (which is saved for later retrieval
     *                by the {@link #getMessage()} method).
     * @param status  the HTTP status code that will be returned to the client.
     */
    public PatchException(final String message, final Response.Status status) {
        super(message, status);
    }

    /**
     * Construct a new instance with the supplied message, root cause and response.
     *
     * @param message  the detail message (which is saved for later retrieval
     *                 by the {@link #getMessage()} method).
     * @param cause    the underlying cause of the exception.
     * @param status  the HTTP status code that will be returned to the client.
     */
    public PatchException(final String message, final Response.Status status, final Throwable cause) {
        super(message, cause, status);
    }
}