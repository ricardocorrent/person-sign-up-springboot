# 7.10.0
- Correção do `NullPointerException` quando uma requisição de integração possuia corpo nulo ou vazio [#1312mk]
- Desativação da geração automática do WADL quando o estágio de configuração for `Production` [#1313pq]
- Evolução do `UserContext` para remoção da necessidade de existir ume scopo de requisição do CDI [#1312d7]
- Correção da exceção disparada na inicialização do serviço quando a configuração do `InjectTenants` está ausente ou incorreta [#13119v]
- Otimização da API de projeção do `AbstractDAO` para melhor integração com a API `Query` do Ebean [#12zjt2]
- Adicionado método `existsById` na classe `AbstractDAO` para verificar se o ID existe [#131vcy]
- Implementação da configuração automática da zona de tempo padrão da aplicação [#1311hh]
- Implementação do tratamento de erros durante a inicialização da aplicação [#1320rf]
- Implementação do resource de exposição da versão da aplicação no path `/service-details` [#131uy3]

# 7.9.0
- Otimizações e correções gerais no uso de injeção estática do CDI [#12zkce]
- Adicionado `InternalIdentificationSerializer`. [#12zrft]
- Depreciação do PojoConverter [#1304gf]
- Otimização das classes para permitir injeção via CDI com escopos personalizados [#130brd]

# 7.8.5
- Correção de vazamento de memória no motor de validação do `@BeanValidationIntegrated` [#63259]

# 7.8.4
- Correção da validação de permissão automática usando `ResourceUtils` [#z43up]

# 7.8.3
- Correção na validação de RFC e nome do pacote [#63094]

# 7.8.2
- Correção na conversão com @PojoColumnsMapper para considerar todos os fields mapeados e não apenas o primeiro [#63068]

# 7.8.1
- Correção do comportamento do Ebean ignorando registros durante a inserção dos eventos de reciclagem [#62646]

# 7.8.0
- Adicionado validação de CUIT, CUIL e RFC [#61844]

# 7.7.1
- Otimização da implementação da API de reciclagem. A ordem de execução foi alterada para usar o padrão de 
  prioridade do CDI. [#61839] 

# 7.7.0
- Suporte a operações em lote na API de validação de entidades [#61519]
- Evolução da API de reciclagem de objetos para permitir a personalização do fornecimento dos metadados. [#61380]
- Otimização das mensagens de resposta padrão do JAX-RS para falhas no processamento ou leitura de JSON [#61080]
- Otimização do nível de log de alguns eventos padrão emitidos pela biblioteca [#61432]
- Implementação do listener de eventos de shutdown da JVM para o encerramento adequado da aplicação [#61689]

# 7.6.1
- Otimização da integração entre o PojoConverter e Ebean [#59769]
- Evolução da anotação `@PojoColumnMapper`. Agora ela permite indicar se valores nulos devem ser convertidos. [#59769]

# 7.6.0
- Alterado LOG level em `LanguageIntegrationRequestCustomizer`. [#59199]
- Implementação da API de gerenciamento remoto e Health Check [#59162]
- Adicionado método `toJSONArray` e tornado público método `isJSON` na `AbstractIntegrationRequest`. [#57229]

# 7.5.8
- Otimização da API de persistência para um melhor tratamento de objetos em relacionamentos ToOne. [#60499]

# 7.5.7
- Correção do encaminhamento do idioma em requisições de clientes de integração. [#59784]
- Correção dos cabeçalhos `Content-encoding` com valor incorreto nos mapeamentos de exceção do JAX-RS. [#58498]
- Correção da consulta paginada do `AbstractDAO` retornando resultados sem o número da página. [#57512]
- Correção da conversão incompleta dos atributos de resultados paginados pelo `PojoConverter`. [#57512]
- Atualização da versão do Jetty. [#56944]
- Correção das mensagens de internacionalização sendo retornadas sem a substituição dos parâmetros. [#58493]

# 7.5.6
- Implementação da API de personalização da configuração do Ebean e correção da configuração do `ObjectMapper`
  padrão usado para conversões de/para JSON. [#59732] 
  
# 7.5.5
- Correção da desassociação em relacionamentos `ManyToMany` feitas incorretamente na API de persistência. [#59392]
- Correção dos links no e-mail de notificação de versão. [#59392]
- Atualização da relação dos JavaDoc dos módulos no `README` do projeto. [#59392]

# 7.5.4
- Implementação do suporte a `@ElementCollection` na API de persistência. [#59113]

# 7.5.3
- Atualização do `shiro-redis` para a versão `3.0.1` para correção do carregamento das permissões sendo feita usando 
  uma chave incorreta no Redis. [#59037] 

# 7.5.2
- Adicionado tratamento na `LanguageIntegrationRequestCustomizer` caso ocorrer erro ao extrair header da requisição original. [#57229]
- Atualização da URL de conexão com o SonarQube. [#57229]

# 7.5.1 
- Adicionada `MultiPartFeature` e método para requisição HTTP HEAD na `AbstractIntegrationRequest`. [#57229]

# 7.5.0
- Melhoria da documentação no `README`. As informações do documento foram atualizadas, exemplos e guias adicionados e 
  outros detalhes menores adicionados ou melhorados. [#54552]
- Criação do arquivo de documentação com as opções de configuração disponíveis antes relacionadas no `README`, ambas 
  revistas e atualizadas. [#54554]
- Melhorias pontuais na documentação JavaDoc. [#54554]
- Correções pontuais na emissão de eventos de log. [#54554]
- Correção dos eventos não sendo enviados em operações `batch` pelo `AbstractDAO` [#56009]
- Implementação de pontos de acesso simplificados para atributos comuns em sessões na classe `UserContext` [#55927]
- Implementação da API de configuração centralizada com suporte inicial para repositórios HTTP e Git [#56018]
- Integração da API de validação com o Bean Validation por meio de constraints para CPF e CNPJ. [#55907]
- Implementação de uma nova API para o JAX-RS de suporte a requisições HTTP PATCH. A API anterior foi depreciada. [#55916]
- Adicionado JSON View `Views.Public` no campo `PhysicalDeleteBaseEntity.externalId` para não enviar o mesmo ao mobile 
  dado que não é utilizado. [#49530]
- Correção da atualização indevida do Feign. [#56664]
- Atualização das dependências `Jersey` para a versão 2.28, `HK2` para a 2.5.0 e `Jackson` para a 2.9.8. [#55914]
- Atualização do `Bean Validation` para a versão 2.0.1.Final e do `Hibernate Validator` para a 6.0.11.Final. [#55908]
- Atualização da versão da integração do Apache Shiro com o Redis (`shiro-redis`) para a versão 3.0.0. [#50994]
- Integração da API de coleta de métricas com a inicialização da commons. [#56650] 
- Adicionado pacote `com.ws.commons.server.sessioncreator` para criar sessão no redis. [#57229]
- Adicionado pacote `com.ws.commons.integration.integrationrequest` para facilitar o uso do `Client` do `javax` para fazer requisições HTTP. [#57229]
- Adicionado pacote `com.ws.commons.integration.warmup` para executar uma integração de dados com um serviço. [#57229]
- Adicionado pacote `com.ws.commons.integration.tenants` para possibilitar a injeção de uma lista de tenants disponíveis do cloud-manager. [#57229]
- Evolução da API de clientes de integração para permitir a customização das solicitações HTTP feitas por ela [#57522]
- Implementação do encaminhamento do idioma (header `accept-language`) da request atual nas chamadas de clientes de 
  integração [#57522]
- Correções pontuais no README. [#57272]
- Implementação do provedor de configuração centralizada compatível com o Spring Cloud Config Server [#56565]

# 7.4.5
- Implementação da API de personalização da configuração do Ebean e correção da configuração do `ObjectMapper`
  padrão usado para conversões de/para JSON. [#59732] 

# 7.4.4
- Correção da parametrização de mensagens quando validações são executadas através de um `@DynamicValid` [#57342]
- Correção do `ConstraintViolationExceptionMapper` para enviar também o charset no header `Content-Type`. [#57342]

# 7.4.3
- Correção do laço infinito no PojoConverter durante a conversão de coleções de objetos que não implementam 
`IPojoConverter` [#56785]

# 7.4.2
- Alterado o `JaxRsExceptionMapper` para incluir o Content-Type no cabeçalho da resposta. [#55882]

# 7.4.1
- Adicionado implementação do `AbstractDAO#internalBatchMerge`, a ser executado via sync, informando ao `Record Permission` 
que as atualizações executadas por ele são de uso interno e não requerem validação de permissão. [#55583]
- Removido os caracteres ASCII para identificação com cores nos eventos de log e limpeza do contexto do log antes da 
  Thread que atendeu a requisição retorne ao pool do Jetty. [#55643]
- Correção de problemas de charset. [#55677]

# 7.4.0
- Alterado o pipeline do GitLab CI/CD para enviar uma mensagem para o canal Cloud - Desenvolvimento do Teams sempre que uma
  nova versão final da commons é disponibilizada. [#54545]
- Alterado provedor padrão de DataSource para o HikariCP e definições para ambiente de produção. [#55433]
- Otimização dos eventos de log registrados pela commons durante o fluxo de uma solicitação. Novos eventos foram criados 
  para melhorar o diagnóstico. [#55007]
- Atualização do formato dos eventos de log registrados para inclusão de novos marcadores de rastreabilidade. [#55007]
- Correção de brechas de segurança internas e atualização das dependências com correções de segurança importantes. [#54819]

# 7.3.8
- Alterados métodos da classe `PermissionResourcesResource` para permitir a customização do comportamento padrão. [#54309]
- Adicionado configuração que permite desativar o lançamento da exceção `RegisterNotFoundException` no `AbstractService`. [#54502]
- Otimização da implementação do `MergeEngine`. Agora ele é capaz de informar ao `Record Permission` que as consultas
  executadas por ele são de uso interno e não requerem validação de permissão. [#54312]
- Implementação da personalização da deserialização de objetos na RestQuery. [#54476]

# 7.3.7
- Adicionado método para executar o `LogicValidator`, desde que anotado com `@BeanValidationIntegrated`, de entidades filhas
anotadas com `@Valid` em uma entidade pai. [#53633]
- Adicionada configuração `dao.mapExceptionToLogicException` que permite controlar o mapeamento automático de exceções no `AbstractDAO`
para `LogicException` [#53765]

# 7.3.6
- Correção do registro e configuração dos provedores de serialização/deserialização de JSON. [#52859]

# 7.3.5
- Alterado o método de obtenção do `HttpServletRequest` no `MessageBundleLocaleFactory` para adquirir através do CDI no
 `com.ws.commons.server.factory.MessageBundleLocaleFactory.ContextWrapper`. [#52505]
- Adicionada a anotação @Alternative nas implementações padrão do `RestQueryAdapter` para permitir que o CDI utilize
corretamente uma classe de produção. [#52444]
- Corrigido um problema que ocorre ao enviar um predicado com um valor inválido de um `Enum` em uma `RestQueryUrl`. 
Uma vez que a propriedade não for reconhecida, agora é lançado uma `MessageException` indicando que não foi possível 
converter o valor enviado. [#52531]

# 7.3.4
- Correção de atribuição da variável `code` ao construir uma mensagem de validação a partir de um 
  `ConstraintViolationException`. [#52215]
- Remoção da depreciação da classe `PaginationSearch`. [#52285]
- Alterada a precedência de conversão do `PojoConverter`. Agora os campos anotados possuem prioridade à igualdade do nome
do atributo para realizar a conversão. [#52372]

# 7.3.3
- Alterado o funcionamento das verificações os parâmetros do `RestQueryUrlParams` para aplicar valor padrão do tamanho 
  de página quando o recebido estiver fora dos limites permitidos. [#52055]

# 7.3.2
- Otimização da implementação do `MessageBundle`, permitindo que ele funcione mesmo quando o `Locale` não pode ser
  extraido da requisição HTTP atual. [#51732]
- Expansão da API de interceptação de deserialização de JSON. Agora pode ser personalizado quais tipos de exceção ela
  deve tratar. [#51733]
- Adicionado verificações para os parâmetros do `RestQueryUrlParams` quando uma consulta via `RestQuery` é recebida, 
  aplicando valores padrão quando necessário. [#51890]
  
# 7.3.1 
- Otimização do fluxo do `MergeEngine` durante a inserção de entidades filhas cascateadas. Agora o 
 `OneToManyChildUpdateEngine` verifica se o atributo filho precisa ser processado. [#51767]
- Correção do charset do e-mail de notificação de liberação de versão. [#51734]

# 7.3.0
- Implementação da API de padronização da passagem de parâmetros para o `AbstratDAO` [#47843]
    - Depreciação do acoplamento direto do `AbstractDAO` com o `HttpServletRequest`
    - Implementação da API `RestQueryAdapter`
    - Implementação das fábricas, produtores e outros para cenários comuns cobertos pela `RestQueryAdapter`
    - Depreciação da API `PaginationSearch` em favor da `RestQuery`
- Otimização do formato e inicialização automática dos parâmetros das mensagens de log. [#50594]
- Inserido condição para tratar uma lista no arquivo de yml quando houver [#47871]
- Alterado o nivel do log de ERROR para WARN para quando não encontrar um arquivo i18n [#50520]
- Implementação da possibilidade de produção de instâncias do `EbeanServer` para um tenant
  específico em tempo de runtime [#50345] 
- Implementação de testes unitários para melhorar a cobertura em cenários com entidades com relacionamentos OneToOne [#50634]  
- Atualizado o README do projeto para inserção do link para o JavaDoc do módulo commons-quartz [#49532]
- Otimização da lógica de desassociação de relacionamentos `ManyToMany` em `ManyToManyDisassociationEngine` para ignorar
  atributos não alterados/carregados do banco de dados. [#51008]
- Implementação da API de interceptação e tratamento personalizado de exceções de deserialização de JSON. [#47844]
- Alterado o pipeline do GitLab CI/CD para enviar um e-mail de notificação para todo o time WealthLabs sempre que uma 
  nova versão final da commons é disponibilizada. [#51565]   
- Otimização do fluxo de atualização de entidades usando o `AbstractDAO`. Agora a entidade de comparação enviada ao 
  `MergeEngine` para identificação do que foi alterado é sempre obtida diretamente do banco de dados em uma
  transação diferente. [#51464]
- Expansão da API do `PojoConverter`, permitindo que a criação de instâncias seja interceptada ou personalizada através 
  da interface `PojoConverterInstanceProvider`. [#50410]
- Expansão da API de interceptação de exceções de deserialização de JSON. Agora ela também suporta interceptar e tratar 
  erros de instanciação de objetos durante a deserialização. [#49207]
- Atualização do gradle, da versão 4.3 para 4.10.1. [#51681]  

# 7.2.9
- Otimização do fluxo do `MergeEngine` durante a inserção de entidades filhas cascateadas. Agora o 
 `OneToManyChildUpdateEngine` verifica se o atributo filho precisa ser processado. [#51767]

# 7.2.8 
- Modificada classe PermissionResourcesResource melhorando a extensibilidade [#41670]

# 7.2.7 
- Correção do registro e configuração dos provedores de serialização/deserialização de JSON. [#52859]

# 7.2.6
- Inclusão de LOG de requisições para análise de comunicação REST.[#51794]

# 7.2.5
- Correção do carregamento de arquivos de mensagens do sistema. Com a correção, os arquivos de LIBs internas também são carregados.[#51414]
- Correção de supressão de log para exceções do banco de dados. [#51417]
- Correção da valiadação de IE do estado de São Paulo quando for do tipo produtor. [#51611]

# 7.2.4
- Otimização da implementação do `EbeanPojoConverterStrategy` para gerenciar caracteristicas do Ebean influenciadas
  pelo `PojoConverter` quando manipulando entidades como destino da conversão. [#51329]

# 7.2.3
- Adicionado listener `DeleteRecycleListener` para remover registros da `RecyclingEntity` quando um registro que foi
 deletado for inserido novamente. [#51034]
- Otimização da busca por desassociações em relacionamentos `ManyToMany` no `MergeEngine`. [#50921]

# 7.2.2
- Otimização da implementação da validação de `CPF`, `CNPJ` e `IE` [#47899]

# 7.2.1
- Atualização do `README.md` para inclusão das informações sobre a reciclagem e da configuração das mensagens de log. [#50601]
- Correção do "motor" de UPDATE que faz as associações Um-Para-Um. [#50604]

# 7.2.0
- Alterado path utilizado em `RecyclingEntity.resourceUri` para conter apenas a URI do recurso. [#50246]
- Removido `final` da classe `Views` para poder ser estendida. [#50246]
- Otimização do fluxo do `DAOLogicErrorMapper` para incluir no `LogicError` o nome da coluna do banco de dados
  que disparou a exceção [#50449]
- Correção da multiplicação de conexões com o banco de dados. [#49184]
- Alteração do formato das mensagens em log [#50102]
- Implementação do `PermissionsResourcesResource` para listagem de todos os resources da aplicação, que requerem permissões de uso. [#50485]

# 7.1.3
- Correção da geração do JSON quando originado de um DTO. Valores vazios em atributos/objetos eram construidos no JSON
  no lugar de serem omitidos, desrespeitando a configuração de serialização (`server.serialization.values.empty`). [#50158]

# 7.1.2
- Correção dos casos de teste e otimização da lógica de desassociação M2M em um `merge` ou `update` [#49935] 

# 7.1.1
- Implementação dos métodos de busca do `AbstractDAO` e `AbstractService` que recebem os parametros em um `Map` como
  alternativa aos métodos que recebem um `HttpServletRequest` [#49812]

# 7.1.0
- Implementação da ordenação dos resultados de uma consulta via `AbstractDAO` usando os nomes de atributos do DTO
  para a ordenação dos resultados [#47818]
- Parametrização do modo de trabalho do `AbstractDAO` em operações de atualização e do `PojoConverter` em operações
  de conversão entre entidade e DTO [#48348]
- Otimização do nome da classe de `DaoDtoSortMediator` para `DaoDtoMediator` uma vez que as responsabilidades dela vão
  além de ordenação [#49587]

# 7.0.3
- Correção da falha ao utilizar mensagens com parametros na validação de objetos [#49637]
- Atualização do MergeEngine para tratar de casos com relacionamentos M2M e fazer a desassociação recursivamente [#49539]

# 7.0.2
- Otimização da lógica de deserialização de datas usando `LocalDateDeserializer` [#49523]
- Correção da falha na internacionalização de mensagens através de `LogicException` ou `LogicError` [#49518]
- Alteração da conversão de PagedList do PojoConverter em função da alteração os atributos do PagedList, de primitivos para objetos inteiros. [#49541]
- Correção da falha na internacionalização de mensagens através de `LogicException` ou `LogicError` [#49518]

# 7.0.1
- Remoção do controle de permissão de acesso no `RecyclingEntityResource` [#49330]

# 7.0.0
- Alteração da versão MAJOR de 6 para 7 [#48669]
- Isolamento das instâncias criadas por injeção ou diretamente pelo `ObjectMapperResolver` e melhoria na documentação [#47799]
- Disponibilização de um link no arquivo `README`, para baixar o JAR do projeto no `NEXUS`.[#47827]
- Implementação do suporte a anotações `@Embedded` e `@Embeddable` e uso da interface `Identification` no lugar de `BaseModel` na API de persistência [#47822]
- Implementação do suporte de mensagens parameterizadas para o `LogicValidator` [#48041]
- Correção da geração do cliente de integração entre os microserviços. [#48651] 
  
  <b>Nota importante:</b>  Esta correção gerou uma quebra na API de persistência da `commons`. 
  O `BaseModel` deixou de ser uma `interface` para virar uma `abstract class`. Para maiores informações consulte
  o bug [48651](https://redmineproduto.wssim.com.br/issues/48651).

# 6.1.2
- Implementação do suporte de mensagens parameterizadas para o `LogicValidator` [#48041]
- Remoção do controle de permissão de acesso no `AbtractInternalResource` [#48608]
- Alteração para validar registros do `internalBatchMerge` no `AbstractInternalResource` [#46558]

# 6.1.1
- Definido o data source `Apache DBCP2` como padrão com otimização das configurações de conexão. [#47953]

# 6.1.0
- Implementado o modificador `unique` para expressões de filtro na RestQuery API. [#308]
- Implementado o suporte a grupo de expressões na RestQueryApi, permitindo definição explícita de precedência para condições. [#347]
- Corrigida limitação ao número de operadores lógicos manipuláveis em uma RestQuery API. [#348]
- Modularização do Jetty server. [#338]
- Atualização do `AbstractDAO` [#327]
    - Implementação dos novos métodos de operações em lote para inserção (`batchInsert`), atualização (`batchUpdate`) e remoção (`batchDelete`)
    com opção de disparo de exceções com relatório detalhado de erro por objeto
    - Depreciação dos métodos antigos de inserção (`insertAll`), atualização (`updateAll`) e remoção (`deleteAll`) em lote
- Implementação da persistência da Sync usando `merge` [#45072]
    - Implementação da lógica de `merge` no `AbstractDAO` 
    - Remoção das APIs POST e PUT de inserção e atualização em lote do `AbstractInternalResource`
    - Implementação das APIs PUT de `merge` em lote no `AbstractInternalResource` usando as mesmas definições da lógica
      anterior de inserção e/ou atualização
    - Testes de integração para garantir que o `merge` possui o mesmo comportamento do `MergeEngine`
      em operações em cascata
- Implementação da API de escuta de eventos de persitência `insert`, `delete` e `update`. [#307]
- Implementação do suporte a HTTP PATCH [#326]
- Otimização da implementação do suporte a HTTP PATCH [#364]
- Implementação do listener padrão de eventos de reciclagem de entidades deletadas [#372]
- Serialização customizada para valores BigDecimal, tratando-os como string [#322]
- Mudança na maneira como a `AbstractDAO` dispara eventos de `@Observer` para `insert`, `delete` e `update` afim de dar suporte ao uso de entidades parametrizadas [#367]
- Atualização do `AbstractDAO` para disparar `EntityNotFoundException` na chamada de métodos de deleção física quando a ID não existe [#378]
- Remoção do `RecycleBin` do `AbstractDAO` em favor do `DefaultRecycleListener` [#377]
- Correção do problema de deleção em cascata a partir de uma atualização [#376]
- Otimização da implementação do `PatchHandlerFactory` [#382]
- Implementação do suporte ao HikariCP e definição dele como o `DataSource` padrão [#231]
- Otimização do tratamento de erros disparados pelos `listeners` do `EventDispatcher` [#386]
- Correção do `MergeCollection` para operações de merge em entidades com associações herdadas [#381] 
- Adicionado controle de permissão de acesso aos métodos do `AbstractInternalResource` e do `RecyclingEntityResource` [#47691]
- Validação para a tabela de reciclagem ao inicializar ouvinte padrão de reciclagem. [#375]
- Ampliação da documentação de métodos de listagem de AbstractDAO. [#383]
- Ampliação da cobertura de testes do AbstractDAO. [#356]
- Construção de caso de teste para deleção em cascata a partir de uma atualização. [#363]
- Sumário com os links das páginas de JavaDoc dentro do README. [#331]
- Atualização/remoção de propriedades de configuração no README. [#355]
- Adicionado tratamento de `com.ws.commons.persistence.dao.exception.EntityNotFoundException` nos métodos batch do AbstractService. [#366]
- Isolamento de alterações no `ObjectMapper`, dentro do escopo de leitura de conversões com DTOs. [#365]

# 6.0.2
- Correção do `import` para `com.fasterxml.jackson.annotation.JsonIgnore` referente a anotação `@JsonIgnore` na classe `PhysicalDeleteBaseEntity`. [#360]
- Adicionada a propriedade `dao.throwRegisterNotFound` indicando se `AbstractDAO#findById` deve lançar uma exceção quando o registro não for encontrado. O comportamento padrão é não lançar exceção, retornando um valor nulo. [#361]
- Correção para `com.ws.commons.interceptor.pojoconverter.ReaderInterceptorEnginePojoConversion` para evitar alterações sobre o `ObjectMapper` de contexto do Jackson influenciar outros processos. [#365]

# 6.0.1
- Correções e implementações, a princípio realizadas na versão em progresso, 6.1.0, foram portadas para esta release [#358]
    - Implementado o modificador `unique` para expressões de filtro na RestQuery API. [#308]
    - Implementado o suporte a grupo de expressões na RestQueryApi, permitindo definição explícita de precedência para condições. [#347]
    - Corrigida limitação ao número de operadores lógicos manipuláveis em uma RestQuery API. [#348]

# 6.0.0
- Alterado de String para UUID os parâmetros representam IDs na classe `AbstractResource`. [#072]
- Adição da interface `BaseModel` como representação do modelo base de persistência. [#076]
- Remoção da casse `com.ws.commons.server.CustomException`. [#087]
- Remoção da casse `com.ws.commons.server.accesscontrol.AccountExceptionMapper`. [#088]
- Remoção do método `com.ws.commons.server.AbstractService.update(UUID, T)`. [#091]
- Refatoração do MessageBundle. [#095]
    - Adição de um produtor(CDI) para o `Locale` que retorna o objeto da requisição(`HttpServletRequest`) quando houver.
    - Desacoplameto do objeto de requisição(`HttpServletRequest`) da classe `com.ws.commons.server.messageloader.CacheMessageLoader`.
- Criação de estrutura(`com.ws.commons.server.ApplicationConfig`) para permitir a substituição de `Provider`s. [#101]
- Adição do objeto de requisição(`HttpServletRequest`) às interfaces da camada de `Resource`, para permitir o uso de projeções. [#105]
- Adição da inteface `Serializable` às classes `com.ws.commons.server.pagination.PaginationSearch` e `com.ws.commons.server.pagination.Sort`. [#134]
- Configuração para os campos com valores padrão para que __não__ sejam expostos automaticamente nas requisições(JSON). [#160]
- Remoção das implementações padrões da interface `MessageLoader`. [#200]
- Desacoplamento das mensagens de `RestQuery` do `MessageBundle`. [#202]
- Segregação de validação de valores nulos da anotação `com.ws.commons.server.validation.constraints.Email`. [#212]
- Refatoração do DAO. [#222]
    - Transferência de responsabilidade de retorno de status HTTP da classe `DAO` para a classe de `Service`.
    - Refatoração da estrutura de MERGE/Update.
- Correção da construção das consultas SQL pela `RestQuery`, com o operador lógico `OR`. [#223]
- Ampliação da interceptação pela classe `com.ws.commons.interceptor.PatchReaderInterceptor` a partir da interface `com.ws.commons.server.resource.IResourceGet<T>`. [#234]
- Otimização da classe `com.ws.commons.persistence.dao.update.MergeEngine`. [#246]
- Atualização do ORM Ebean. [#260]
    - Atualização do ORM Ebean. Da versão 10.4.7 para 11.15.4.
        - [Ebean milestones](https://github.com/ebean-orm/ebean/milestones?state=closed)
    - Atualização do plugin do gradle para o ORM Ebean. Da versão 10.2.3 para 11.10.1.
        - [Gradle plugin milestones](https://github.com/ebean-orm-tools/ebean-gradle-plugin/milestones?state=closed)
    - Atualização do agente do ORM Ebean. Da versão 10.1.2 para 11.11.1.
        - [Ebean agent milestones](https://github.com/ebean-orm/ebean-agent/milestones?state=closed)
- Reescrita de algumas seções do README, ajustes no índice e correção de typos. [#261]
- SYNC - Disponibilização de estrutura para deleção física em paralelo com a estrutura atual de deleção lógica. [#267]
    - Refatoração do modelo de deleção atual em função da adição do modelo de deleção físca.
    - Adição do modelo base de recliclagem/auditoria.
- Adição de Mapper(`javax.ws.rs.ext.ExceptionMapper<E>`) para MethodNotAllowed(`org.apache.http.HttpStatus`). [#272]
- SYNC - Adição de recurso de auditoria/reciclagem de deleções. [#273]
- Adição de suporte a requisições com múltiplas linguagens. [#274]
- Alteração da contagem de registros do `PagedList` para uma opção configurável. [#276]
- Remoção do operador `&&`(baseado em caractere reservado) da `RestQuery`. [#277]
- Adição de opção para ignorar a convenção de encapsulamento durante a reflexão de classes. [#278]
- Segregação do `externalId` em uma interface. [#279]
- Adição de suporte a consultas customizadas para o modelo de reciclagem. [#284]
- Adição do path com a versão MAJOR e o versionamento completo em novas colunas. [#285]
- Criar anotação para evitar reciclagem de tabelas que não necessitam desse recurso. [#286]
- Remoção do método `jacksonMapper` da classe `com.ws.commons.server.json.ObjectMapperResolver`. [#287]
- Adição de opção para o descarte de artefatos sintéticos durante a reflexão de classes. [#288]
- Remoção da classe depreciada `FieldReflectionHelper`. [#310]
- Correção do NullPointerException no método `buildPartitions(Collection<T>, Collection<T>)` da classe `com.ws.commons.persistence.dao.update.MergeCollectionMetadata` quando a ID do objeto ainda não foi populada [#349]

# 5.6.0
- Porte da versão 6.0.0 da RestQuery para a 5.6.0 [#330]
- Correção da origem usada para reflexão nas interfaces da camada RESOURCE [#332]
- Adição da anotação `@InjectPathParam` para métodos de resource, afim de permitir que valores de parâmetros da Url sejam injetados nos objetos alvo [#328]
- Adição de métodos em `AbstractDAO` com foco em como transações podem ser usadas. Os métodos de alteração de dados (`insert`, `update` e `delete`) e criação de transação (`beginTransaction`) tiveram sobrecargas adicionadas permitindo variações no controle de transações atual. [#329]

# 5.5.5
- Alteração do `com.ws.commons.interceptor.pojoconverter.ReaderInterceptorEnginePojoConversion` para injetar o `com.fasterxml.jackson.databind.ObjectMapper` do contexto da requisição. [#297]

# 5.5.4
- Adição/Correção de suporte a datas do Tipo `LocalDate` à RestQuery. [#290]
- Correção de quebra de versão indevida na classe `ObjectMapperResolver`. [#275]
- Correção da convenção de encapsulamento na classe de reflexão de métodos e atributos. [#278]
- Correção do POOL de conexões do DataSource. [#230]

# 5.5.3
- Adição do objeto de requisição(`HttpServletRequest`) à classe `com.ws.commons.server.messagebundle.MessageBundle` como opção implícita ao `Locale` padrão. [#244]
- Modificação no interceptador para execução de observadores(CDI) para a deleção em lote. Adição da anotação do interceptador no método deleteAllPermanent. [#236]

# 5.5.2
- Criado conversor de Enum na RestQuery.[#238]

# 5.5.1
- Disponibilizado o método 'deletePermanent' do Ebean no AbstractDAO.[#233]

# 5.5.0
- Atualizada as dependências do Shiro.[#175]
- Adicionado opção para propagação dos filtros dentro da hyerarquia de relacionamentos de entidades em consultas RestQuery.[#176]
- Adicionado novos testes de integração para o operador lógico de conjunção em consultas RestQuery.[#191]
- Adição da tradução para o espanhol. [#209]
- Corrigido a adição de cookies pelo proxy do Feign Client.[#215]

# 5.4.2
- Alterado o método updateAll delegando a persistência ao método update, para que o contrato do BaseEntity seja respeitado.[#220]
- Alterado o REGEX dos valores de data e hora das consultas por RestQuery, para permitir que os valor de milissegundos possam conter de 1 a 6 casas ou que sejam omitidos.[#221]
- Alterado os métodos insertAll e deleteAll delegando as persistências aos análogos por entidade dentro do AbstractDAO, para que o contrato do BaseEntity seja respeitado.[#225]

# 5.4.1
- Permitido a execução de filtro com datas sem deslocamento de timezone atravéz de RestQuery.[#216]

# 5.4.0
- As propriedades do tipo lista agora podem receber a anotacão `PojoColumnBackReference`.[#144]
- Ampliada a documentação da classe `LogicValidator`.[#208]
- RestQuery agora aceita filtro de data e hora com decimal até nanosegundos.[#192]
- RestQuery, correção das SQLs com mais de duas condições `OR`.[#195]
- Adição de testes que cobrem projeções aninhadas.[#177]
- Mudança no comportamento  padrão dos campos `createdAt` e `updatedAt`.[#184]
- RestQuery adicionada opção de filtro para retornar registros deletados.[#193]
- Adicionada parametrização nomeada para validações.[#205]
- Corrigido bug no update/patch que excluía listas.[#186]
- Corrigida leitura de classes ou atributos não públicos.[#190] 
- Correção na leitura dos parâmetros das mensagens internacionalizadas.[#185] 

# 5.3.0
- Adição da opção de definição de produção e/ou consumo de DTO por classe.[#152]
- Corrigido bug de update em cascata para entidades com mais de 2 níveis de hierarquia. [#156]
- Disponibilizados os métodos `updateAll` e `deleteAll`(Não atualiza o `parent`).[#167]
- Criação dos métodos `prePersist` e `preUpdate` para controlar a persistência dos campos `createdAt` e `updatedAt`.[#168]
- Adição de projeção de campos de uma classe DTO que representam múltiplos campos da entidade. [#163]
- Correção da leitura de campos aninhados em condições da RESTQuery. [#170]
- Aplicação de "novas" definições de sintaxe para as projeções em URL. [#164]

# 5.2.0
- Objetos podem ter validação de nulidade hierarquica em seus atributos através da anotação `@NotNull.List` [#99]
- É possível ignorar campos na definição de um resource. [#42]
- LogicValidator retorna mensagem internacionalizada [#128]
- Caso seja informado um filtro nulo no search, uma paginação default será aplicada trazendo todos os resultados. [#114]
- Buscas com projections inválidas retornam uma exceção [#110]
- Adicionado o operador lógico de disjunção (OR, "||") para composição de filtros REST. [#138]
- Filtros das consultas RESTQuery podem utilizar normalmente um path para um atributo [#139]
- Atributo "dao" da classe AbstractService passa a ser _protected_ [#153]
- Propriedades do banco de dados passam a ser obtidas da classe PersistenceProperties e não mais ServerProperties [#73]
- Depreciada a classe AccountExceptionMapper [#145]
- Ebean atualizado para a versão 10.4.7 [#117]


# 5.1.0
- MessageLoader: Incluída a busca pelo arquivo de mensagens com letras minúsculas(lower case). [#136]
- ConstraintViolationAdapter: Incluída a tradução dos campos mapeados para DTO, alterando o nome pelo target definido na anotação de mapeamento. [#41]
- Depreciação da classe com.ws.commons.server.CustomException. [#106]
- Projeção para classes DTO. [#43]
- ConstraintViolationAdapter: Correção do método que deve retornar a chave da mensagem. [#108]
- Emissão de exceções de validação de entidades(Constraints) estruturada em árvore. [#98]
- Parametrização do retorno de arrays nulos ou vazios no JSON. [#135]
- Correção de NPE no método "mergeCollection" da classe AbstractDAO. [#126]
- Disponibilizado métodos de raw query e update no AbstractDAO. [#127]

# 5.0.4
- Alterado o método commitTransaction da classe AbstractDAO para não finalizar a transação. [#133]

# 5.0.3
- AbstractDAO: Correção da leitura da anotação de persistência em cascata na operção de UPDATE para relações diferentes de M2M. [#122]

# 5.0.2
- Correção da internacionalização de mensagens parametrizadas na validação de entidades com mensagens indexadas. [#119]

- Correção de emissão de log para inserções no AbstractDAO. [#119]

# 5.0.1
- Correção da internacionalização de mensagens parametrizadas na validação de entidades. [#119]

# 5.0.0 
- Estrutura de conversão (manual e automatizada pelo JERSEY) de Objetos/Beans. [#32952, #68, #44]
- Recurso de tratamento de referência cíclica(mapeamento bidicerional) para a conversão de objetos/benas. [#77]
- Alteração na conversão de objetos, para priorização do acesso aos atributos por métodos do encapsulamento. [#80]
- Documentação da classe e ampliação do contrutor. (ConstraintViolationAdapter). [#92]
- Alterado o acoplamento da validação com a entidade para BaseEntity. [#89]
- Estrutura de inserção e deleção em lote. [#70]
- Segregação de interfaces para a exposição dos recursos de persistância sob os verbos HTTP.
- Corrigido mecanismo multi tenancy commons + ebean + postgres. [#65]
- Removido o método "getTransaction" da Commons (AbstractDAO). [#64]
- Criado um tratamento de exceção para o envio de JSON com estrutura inválida para as APIs. [#63]
- Limitar acesso à API do Ebean na lib Commons. Disponibilizado somente métodos de manipulação da persistência ou consulta a dados. [#62]
- Alteração dos pacotes das classes. De "com.sollar..." para "com.ws...". [#61]
- Remoção do suporte ao Kafka. [#60]
- Movida a classe MissingConfigException para o package server.exception. [#59]
- Atualizaçõa da dependência do Ebean segundo a versão 10.4.2 do ORM. [#56]
- Alterado o MessageBundle para não exigir o Locale e usar o Inglês como linguagem padrão. [#51]
- Adicionar opção para trabalhar com a Commons sem multi-tenancy. [#50]
- Suporte a YML em paralelo com o suporte ao apache deltaspike. [#46]

# 4.14.4
- Correção de falha que permitia exclusão de associações quando mapeadas com Cascade.ALL. [#154]

# 4.14.2
- Correção do método interno do AbstractDAO que verifica se os registros associados foram carregados(LAZY). [#150]

# 4.14.1
- Retirada a ordenação padrão que existia nas consultas de listagem do AbstractDAO. Não há mais qualquer ordenação padrão. Haverá somente a ordenação parametrizada na requisição, através do PaginationSearch [#75].

# 4.14.0
- Disponibilizado um recurso de filtro para as validações de entidade [#66].

# 4.13.0
- Disponibilizada uma nova implementação de validação de entidades [#66].

# 4.12.0
- Corrigido comportamento do método PATCH para chamar o método update da classe AbstractResource [#32868]
- Corrigidas dependências do framework Shiro [#32303]
- Alinhado com DBA que serão criadas restrições diretamente em banco de dados e adicionadas nos migrations [#32200]
- Depreciadas classes referentes ao suporte a comunicação com o framework Consul [#32303]
- Criada nova RestQuery com mais funcionalidades. Foi mantida compatibilidade com queries legadas [#32158, #32134, #30042]

# 4.11.0
- Removido arquivo test-ebean.properties do path de resources, não sendo mais carregado indevidamente [#32122]
- Aplicadas melhorias de Log no level INFO e definida implementação de logs Log4j2 (API Slf4j) como padrão [#17953]
- Merge de correção 4.10.1 para versão 4.11.0 [#32195}
- Atualizadas versões de diversas libs de terceiro com correções e novas funcionalidades (ficar atento à quebras de package) [#31956]
- Adicionado suporte ao método http PATCH de acordo com as devidas rfc7386 e rfc6902 [#24980]

# 4.10.1
- Adicionado campo conditions no PaginationSearch para aplicar filtros na query[#31751]
- Adicionado tratamento de UUID para aplicar filtros na query através de parâmetros enviados por GET[#31744]

# 4.10.0
- Corrigida aplicação de page size no retorno de uma PagedList na classe AbstractDAO[#31372]
- Método Abstract.addProjection definido como protected [#30982]
- Corrigido bug onde o Validator armazenva estado, retornando incorretamente validações concatenadas[#30662]

# 4.9.0
- Adicionado validação caso usuario passe um pageSize maior que o máximo permitido [#28889]
- Correção Bug concatenação exceptions [#30784]
- Adicionado suporte a ordenacao padrão para métodos list() e search() utilizando CREATEDAT e ID [#28862]
- Adicionado suporte para expor current transaction AbstractDAO (batch mode) [#26207]
- Criado excessão interna IntegrationException para encapsular mecanismo de lançamento de excessão FeignProxyClient [#29330]
- Resolvido problema com concatenação DefaultMessageLoader [#30682]

# 4.8.0
- Adicionada tratativa para não retornar indevidamente erros internos do servidor para o usuário final [#23966]
- Adicionado suporte básico ao método HTTP PATCH. Será evoluído em versões posteriores [#24980]
- Tornou-se possível informar o status de retorno em exceptions to tipo MessageException [#25517]
- Adicionada tratativa para não acontecer loop infinito que não conseguido comunicar com nó Kafka [#26172]
- Adicionado suporte à `*` nas projections para retornar todos os dados de uma determinada entidade [#27141]
- Adicionada melhoria de mensagem para informar melhor o desenvolvedor do ocorrido [#28336]
- Configurada integração entre container Jetty e CDI conforme documentação de referência [#28706]
- Adicionado suporte para serialização e deserialização do ENUM OriginEnvironment(commons) para JSON [#29749]
- Correção suporte ao Kafka [#30058]

# 4.6.0
- Melhorada classe RestAuthorizationRealm tornando possível customizar a chamada de rede para cenários específicos [#29220]

# 4.5.0
- Adicionando suporte à GZip nas requests das APIs [#28607]

# 4.3.0
- Atualizada versão do ORM Ebean para 10.2.1 para correção de bug utilizando soft-delete [#32]
- Corrigida abertura e fechamento de transação em momento indevido no AbstractDAO [#31 #28]
- Criada classe RootEntity que deve ser estendida por Entidades "raíz" na apliclação (entidades que sincronizam) [#27]
- Adicionado suporte a chamadas entre micro serviços de forma abstraída, utilizando a API criada pelo plugin gradle (generateClient task) [#35]

# 4.2.0
- Migrado lib Shiro Redis para lib Commons [#17]
- Suporte a consulta de deletados na API [#20]

# 4.1.0
- Adicionado método `public PagedList<T> list(Query query, Map<String, String[]> queryParams)` na classe AbstractDAO

# 4.0.0

- Adicionada tratativa no AbstractDAO para quando um recurso não for encontrado através da API #GET/{id} retornar o HttpStatus 404 [#25999]
- Aplicadas melhorias de código diversas [#25977]
- Criada classe RootEntity com o objetivo de ajudar nas tarefas de integração e sincronização [#25852]
- Devido a configuração default do DataSource o ORM Ebean não estava tratando corretamente as funções beginTrasaction(), commitTransaction() e rollbackTransaction() [#25535]
- Adicionadas melhorias de código com relação à injeção de variáveis [#25466]
- Adicionado atributo externalId na classe BaseEntity para auxílio na integração [#25431]
- Adicionado registro automático de microserviços em servidor Consul, dando maior independência para busca de micro serviços por parte do Gateway Heimdall. Task associada #21736 [#23187]
- Adicionado suporte a Proxy para chamadas transparentes entre micro serviços. Task associada #... [#22998]
- Revisadas dependências da lib Commons, visando remover o tamanho dos artefatos gerados e corrigir dependências transitivas [#17974]
- Aplicadas correções de erros apresentados em em testes de integração [#24829]
- Adicionado suporte a modelo mais dinâmico para adição de informações do User na sessão distribuída [#24701]
- Adicionado suporte para configurar ou estender métodos da classe RestAuthorizationRealm permitindo customizações com menor impacto caso sejam necessárias alterações futuras[#24548]
- Adicionada configuração default para forçar o uso de nomeção por underscore nas tabelas/colunas de banco de dados[#24465]
- Adicionada configuração que permite habilitar/desabilitar o uso do Kafka em um miroserviço [#24065]
- Removidas classes depreciadas em versões anteriores [#23979]
- Realizadas diversas alterações no modelo de envio/recebimento de mensagens do Kafka [#23964]
- Com suporte adicionado para executar as validações lógicas no mesmo contexto do BeanValidation, foram removidas as execuções do LogicValidation das classes Abstratas [#23670]
- Adicionado suporte para retornar array de validações no server [#23664]
- Utilizada API do EbeanValidation como nomenclatura [#23358]
- Correçoes diversas [#22875]
- Removidas classes de User contidas na lib commons, removendo a adição das mesmas nos scripts de banco de dados [#19255]
- Refatorados e implementados diversos testes unitários e integração [#17203]
- Adicionado suporte para UUID nas pesquisas genéricas via GET [#26108]
- Realizada correção de parse de registro no producer do Kafka. Task associada #23964 [#24924]
- Realizada correção para atualizar corretamente o campo version nos registros de banco de dados [#26190]
- Renomeados campos createDate e updateDate para createdAt e updatedAt [#26198]
- Adicionado suporte a deleção lógica na aplicação [#20341]
- Atualizado ORM Ebean para versão 9.5.1[#23585]
- Atualizada lib do orm Ebean para a versão 10.1.5 causando quebra de API [#26318]

Quebras versão 4.0.0

22875
- Necessário adicionar a configuração do ambiente em que está funcionando a aplicação, sendo Local, Docker ou CloudFoundry.
- Necessário adicionar essas configurações na subida do docker compose

23979
- Removida classe AuthorizationRealm, sendo necessário alterar o arquivo shiro.ini
- Removidas classes de User, Role e demais da lib Commons
- Removida classe Menu da lib Commons
- Removidas configurações de dockerApi e dockerHost

26318
- O package do projeto ebean foi alterado para io.ebean causando quebra em todas as classes que utilizem o mesmo

26198
- A alteração de nome dos campos pode afetar códigos que estejam utilizando os mesmos

# 3.3.0
- Adicionada API para fornecimento de recursos da Sincronzização [#24108]
- Adicionado suporte ao servido de descoberta quando em ambiente Cloud Foundry [#22602]
- Aplicadas melhorias no fluxo  das funções da classe AbstractDAO [#22275]
- Criado mecanismo de configuração de acesso a banco de dados e adicionada multi-tenância nativa do ORM Ebean [#19159]
- Corrigido bug na projections onde listas eram trazidas de forma indevida quando informada projection [#18279]

# 3.2.0
- Adicionado valor default para a propriedade kafka.consumer.schedule.timer [#23375]
- Depreciado acesso direto da lib commons no banco de dados user para buscar as permissões. Adicionado suporte para buscar a autorização do usuário via chamada rest para o micro serviço de user [#23159]
- Solucionado na task #23375 [#22692]
- Adicionadas melhorias na geração do migrations na lib commons [#18565]


# 3.1.0
- Atualizada versão do ORM Ebean para 8.6.+ permitindo assim utilizar os recursos do PostGis(estes ainda estão em processo e dev pelo Ebean ORM). [#23302]
- Adicionada anotação que permite executar as validações (LogicValidator) juntamente com o BeanValidation. [#22627]
- Adicionada exception que valida se não foi possível encontrar o arquivo de messages de internacionalizalção no lado server. [#22108]
- Adicionado suporte a formatação condicional ao messages no lado server, utilizando a API MessageFormat do java.[#20990]
- Melhorada documentação de uso da classe LogicValidator [#19014]

# 3.0.0
- Modificada forma de carregamento do arquivo ebean.properties, não sendo mais necessário ter o arquivo test-ebean.properties (o mesmo pode ser removido dos projetos). [#21876]
- Atualizada versão do Ebean para 8.5.1, causando assim a modificação da versão MAJOR da lib commons. Esta alteração pode gerar algumas quebras de código, principalmente nas classes DAO. [#21808]
- Adicionada validação no método get padrão dos AbstractResource, para que quando o registro não for encontrado, retornar Response.Status.NOT_FOUND [#21168]
- Adicionado suporte a consumir JSON no método Search do AbstractResourcer [#20726]
- Adicionado suporte a criar Consumers e Producers para comunicação com o Kafka. [#18636]
- Adicionado suporte à internacionalização e a MessageExceptions no lado server side, permitindo retornar mensagens já localizadas via API. [#18313]
- Corrigido para não carregar listas indevidamente quando utilizando projections no GET. [#18279]


# 2.1.0
- Validar auto commit no DAO [#17182]
- Falta adicionar o UncaughtException as configuração default [#18901]
- Validar throws Exception em métodos Abstract [#18680]
- Adicionar validação de registro não encontrado no UPDATE (404 NOT FOUND) [#18184]
- Tratamento de exception [#18026]
- Alterar mensagem para o usuário bloqueado temporariamente [#19007]
- Verificar aplicação de GroupValidator no AbstractService [#18456]
- Corrigir permissão de acesso AbstractResource [#20494]

# 1.0.2
- Revert da alteração em 1.0.1 com relação aos métodos updateDate e createDate
- Tornado métodos insert e update em void

- Adicionado parâmetro diplomat.register.host que permite configurar o IP que será cadastrado no servidor do consul.
- Atualizada documentação.

# 1.0.1
- Adicionado getter e setter para os atributos updateDate e createDate, devido à incompatibilidade com o framework Jackson
- Alterados testes unitários para simular o erro supracitado
