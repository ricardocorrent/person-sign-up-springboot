package com.ws.commons.server;

import org.apache.commons.io.IOUtils;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.ErrorHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Alternative;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * {@link ErrorHandler} overriding implementation for Jetty Server.
 * <p>
 * This class allows customizing Jetty Server's error handling behaviour, permitting to provide an
 * error page with custom data.
 * </p>
 * <p>Once this handler is registered through {@link JettyServer}, every Jetty-related error is handled by this class's
 * methods</p>
 *
 * <pre>
 *     Server server = new Server();
 *     server.setErrorHandler(new JettyErrorHandler());
 *
 *     ...
 *
 *     WebAppContext webAppContext = new WebAppContext();
 *     webAppContext.setErrorHandler(new JettyErrorHandler());
 *
 *     ...
 *
 *     final HandlerCollection handlers = new HandlerCollection();
 *     handlers.setHandlers(new Handler[]{webAppContext});
 *
 *     final Integer port = 8080;
 *     final Server server = new Server(port);
 *     server.setHandler(handlers);
 * </pre>
 *
 * @author  Lucas Dillmann
 * @author  Hendric Gabriel Cechinato
 * @since   7.4.0 - 2018-12-10
 */
@Alternative
class JettyErrorHandler extends ErrorHandler {

    private final Logger logger;
    private static final String TEMPLATE_FILE_PATH = "/META-INF/template/error-template.json";

    /**
     * Default constructor.
     */
    JettyErrorHandler() {
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Method called by Jetty whenever an error page needs to be rendered.
     *
     * @param request           http request
     * @param writer            error page writer
     * @param jettyErrorCode    error code
     * @param jettyErrorMessage error message
     * @param showStacks        flag to display or hide the stack trace
     * @throws IOException      when the page can't be written
     */
    @Override
    protected void writeErrorPage(final HttpServletRequest request,
                                  final Writer writer,
                                  final int jettyErrorCode,
                                  final String jettyErrorMessage,
                                  final boolean showStacks) throws IOException {

        logger.debug(
                "Error page requested to be rendered. Detected error is of code {} with message {}.",
                jettyErrorCode,
                jettyErrorMessage
        );

        final Throwable exception = (Throwable) request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
        final String stackTraceContent = showStacks ? getExceptionStackTrace(exception) : "";
        final String exceptionMessage = showStacks ? getExceptionRootMessage(exception) : "";
        final String errorMessage = Optional
                .ofNullable(exception)
                .map(Throwable::getLocalizedMessage)
                .orElse(jettyErrorMessage);
        final String serverDateTime = OffsetDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        final String requestParameters = Optional.ofNullable(request.getQueryString()).orElse("");
        final InputStream errorPage = getClass().getResourceAsStream(TEMPLATE_FILE_PATH);

        final String errorPageContent = IOUtils
                .toString(errorPage)
                .replace("${errorCode}", String.valueOf(jettyErrorCode))
                .replace("${errorMessage}", errorMessage)
                .replace("${requestUri}", request.getRequestURI())
                .replace("${requestParameters}", requestParameters)
                .replace("${serverDateTime}", serverDateTime)
                .replace("${exceptionMessage}", exceptionMessage)
                .replace("${exceptionStack}", stackTraceContent);

        writer.write(errorPageContent);
    }

    /**
     * Generates an acceptable error response for a mime type.
     *
     * <p>This method is called for each mime type in the users agent's
     * <code>Accept</code> header, until {@link Request#isHandled()} is true and a
     * response of the appropriate type is generated.
     *
     * @param baseRequest   the base request
     * @param request       the servlet request (may be wrapped)
     * @param response      the response (may be wrapped)
     * @param code          the http error code
     * @param message       the http error message
     * @param mimeType      the mimetype to generate (may be *&#47;*or other wildcard)
     * @throws IOException  if a response cannot be generated
     */
    @Override
    protected void generateAcceptableResponse(final Request baseRequest,
                                              final HttpServletRequest request,
                                              final HttpServletResponse response,
                                              final int code,
                                              final String message,
                                              final String mimeType) throws IOException {
        super.generateAcceptableResponse(baseRequest, request, response, code, message, mimeType);
        response.setContentType("application/json");
    }

    /**
     * Returns an acceptable writer for an error page.
     *
     * <p>Uses the user-agent's <code>Accept-Charset</code> to get response
     * {@link Writer}.  The acceptable charsets are tested in quality order
     * if they are known to the JVM and the first known is set on
     * {@link HttpServletResponse#setCharacterEncoding(String)} and the
     * {@link HttpServletResponse#getWriter()} method used to return a writer.
     * If there is no <code>Accept-Charset</code> header then
     * <code>ISO-8859-1</code> is used.  If '*' is the highest quality known
     * charset, then <code>utf-8</code> is used.
     * </p>
     *
     * @param baseRequest   the base request
     * @param request       the servlet request (may be wrapped)
     * @param response      the response (may be wrapped)
     * @return              a {@link Writer} if there is a known acceptable charset or null
     * @throws IOException  if a Writer cannot be returned
     */
    @Override
    protected Writer getAcceptableWriter(Request baseRequest, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setCharacterEncoding("utf-8");
        return response.getWriter();
    }

    /**
     * Returns the exception stack trace in a String object if exception isn't null.
     *
     * @param throwable exception to get the stack trace from
     * @return          stack trace in a String object when throwable isn't null, empty string otherwise
     */
    private String getExceptionStackTrace(Throwable throwable) {
        String stackTrace = "";
        while (throwable != null) {
            final StringWriter stringWriter = new StringWriter();
            final PrintWriter printWriter = new PrintWriter(stringWriter);

            throwable.printStackTrace(printWriter);
            printWriter.flush();

            stackTrace += stringWriter.getBuffer().toString();
            throwable = throwable.getCause();
        }
        return stackTrace;
    }

    /**
     * Returns the message from the root exception (if there's one).
     *
     * @param throwable detected exception
     * @return          root exception message if there's one, empty string otherwise
     */
    private String getExceptionRootMessage(Throwable throwable) {
        String rootMessage = "";
        while (throwable != null) {
            rootMessage = throwable.getMessage();
            throwable = throwable.getCause();
        }
        return rootMessage;
    }
}
