package com.ws.commons.server;

import com.ws.commons.ServerProperties;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.server.handler.ErrorHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.jboss.weld.environment.servlet.WeldServletLifecycle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Singleton;
import java.util.stream.StreamSupport;

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
public class JettyServerProducer {

    private static final Logger LOGGER = LoggerFactory.getLogger(JettyServerProducer.class);
    public static final String DEFAULT_CONNECTOR_NAME = "default";

    /**
     * @param errorHandler Error handler
     * @param context Context
     * @param customizers Server customizers
     * @return Server instance
     */
    @Produces
    @Singleton
    public Server server(final ErrorHandler errorHandler,
                         final WebAppContext context,
                         final Instance<JettyServerCustomizer> customizers) {

        final Server server = new Server();
        final Connector connector = connector(server);

        context.setServer(server);
        context.setVirtualHosts(new String[]{ "@" + connector.getName() });
        connector.addBean(context, true);

        server.setStopTimeout(5000);
        server.setErrorHandler(errorHandler);
        server.addConnector(connector);
        server.setStopAtShutdown(true);

        server.setHandler(new HandlerCollection(context));

        StreamSupport
                .stream(customizers.spliterator(), false)
                .forEach(customizer -> {
                    LOGGER.debug("Invoking Jetty customizer: {}", customizer.getClass().getName());
                    customizer.customize(server);
                    customizers.destroy(customizer);
                });

        LOGGER.debug("Jetty Server initialized");
        return server;
    }

    /**
     * Produces a {@link Connector} for Jetty {@link Server}
     *
     * @param server Target server for the connector
     * @return Connector instance
     */
    @Produces
    @Singleton
    protected Connector connector(final Server server) {
        final Integer port = ConfigResolver.resolve(ServerProperties.PORT)
                .as(Integer.class)
                .withCurrentProjectStage(true)
                .withDefault(80)
                .getValue();

        final HttpConfiguration httpConfiguration = new HttpConfiguration();
        httpConfiguration.setSendServerVersion(false);
        httpConfiguration.setSendXPoweredBy(false);

        final HttpConnectionFactory httpFactory = new HttpConnectionFactory(httpConfiguration);
        final ServerConnector connector = new ServerConnector(server, httpFactory);
        connector.setPort(port);
        connector.setName(DEFAULT_CONNECTOR_NAME);

        LOGGER.debug("Jetty default connector initialized");
        return connector;
    }

    /**
     * Produces a {@link WebAppContext} for Jetty {@link Server}
     *
     * @param beanManager CDI bean manager
     * @param errorHandler Jetty error handler
     * @return Context instance
     */
    @Produces
    @Singleton
    protected WebAppContext webAppContext(final BeanManager beanManager,
                                       final ErrorHandler errorHandler) {
        final WebAppContext context = new WebAppContext();
        context.setThrowUnavailableOnStartupException(true);
        context.setContextPath("/");
        context.setBaseResource(Resource.newClassPathResource("web"));
        context.setParentLoaderPriority(false);
        context.setErrorHandler(errorHandler);
        context.setAttribute(WeldServletLifecycle.BEAN_MANAGER_ATTRIBUTE_NAME, beanManager);
        context.setInitParameter("org.eclipse.jetty.servlet.Default.dirAllowed", "false");

        LOGGER.debug("Jetty default context initialized");
        return context;
    }

    /**
     * Produces a {@link ErrorHandler} for Jetty {@link Server}
     *
     * @return Error handler instance
     */
    @Produces
    @Singleton
    protected ErrorHandler errorHandler() {
        final ErrorHandler handler = new JettyErrorHandler();
        LOGGER.debug("Jetty default error handler initialized");

        return handler;
    }

}
