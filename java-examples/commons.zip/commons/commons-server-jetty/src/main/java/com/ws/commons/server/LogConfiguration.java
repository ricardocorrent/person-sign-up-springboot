package com.ws.commons.server;

import com.ws.commons.ServerProperties;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Optional;

/**
 * Utility class for log startup
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
class LogConfiguration {

    private static final String HOSTNAME_ENV_KEY = "service.hostname";
    private static final String SERVICENAME_ENV_KEY = "service.name";

    void initialize() {
        final String currentHostname = System.getProperty(HOSTNAME_ENV_KEY);
        if (StringUtils.isBlank(currentHostname)) {

            try {
                final String hostname = InetAddress.getLocalHost().getHostName();
                System.setProperty(HOSTNAME_ENV_KEY, hostname);
            } catch (final UnknownHostException ex) {
                // Exception is not logged because log subsystem isn't started yet. An empty hostname is used instead.
                System.setProperty(HOSTNAME_ENV_KEY, "");
            }
        }

        final String currentServiceName = System.getProperty(SERVICENAME_ENV_KEY);
        if (StringUtils.isBlank(currentServiceName)) {
            final String serviceName = Optional
                    .ofNullable(System.getenv(SERVICENAME_ENV_KEY))
                    .orElse(ConfigResolver.resolve(ServerProperties.SERVICE_NAME).getValue());
            System.setProperty(SERVICENAME_ENV_KEY, serviceName);
        }

        java.util.logging.LogManager.getLogManager().reset();
        SLF4JBridgeHandler.removeHandlersForRootLogger();
        SLF4JBridgeHandler.install();

        final String logLevel = ConfigResolver.resolve(ServerProperties.LOG_LEVEL).withDefault("INFO").getValue();
        Configurator.setRootLevel(Level.getLevel(logLevel.toUpperCase()));

        final Logger logger = LoggerFactory.getLogger(JettyServer.class);
        logger.info(
                "Log started using SLF4J with hostname '{}', service name '{}' and level '{}'",
                System.getProperty(HOSTNAME_ENV_KEY),
                System.getProperty(SERVICENAME_ENV_KEY),
                ConfigResolver.resolve(ServerProperties.LOG_LEVEL).getValue()
        );
    }

}
