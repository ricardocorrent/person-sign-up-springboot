package com.ws.commons.metrics.exception;

/**
 * Exception to be thrown when some config is not properly set on service.
 *
 * @author  Hendric Gabriel Cechinato
 * @since   7.5.0 - 2019-02-07
 */
public class MissingConfigException extends RuntimeException {

    /**
     * Default exception constructor with {@code message} initialization.
     *
     * @param message the exception message.
     */
    public MissingConfigException(final String message) {
        super(message);
    }

}
