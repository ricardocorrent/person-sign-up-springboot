package com.ws.commons.metrics;

import com.ws.commons.metrics.converter.ReporterEnumConverter;
import com.ws.commons.metrics.reporter.ReporterEnum;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * This class is responsible to define configuration properties for Metrics API.
 *
 * <p>the available properties declared here are used to activate or deactivate the collection of metrics related
 * to frameworks used to run the application.</p>
 *
 * <p>Metrics collector is disabled by default. To activate its features, set</p>
 * <pre>
 *     metrics.enable=true
 * </pre>
 * <p>in your apache-deltaspike.properties file.</p>
 *
 * <p>Other available configurations and its meanings are available at the
 * <a href=https://gitlab.wssim.com.br/platform/commons/blob/master/configuration-options.md>
 * Configuration options
 * </a>
 * file.
 * </p>
 *
 * @author  Hendric Gabriel Cechinato {@literal <hendric.cechinato@wssim.com.br>}
 * @since   7.5.0 - 2019-02-04
 */
@Configuration
public
interface MetricsConfig {

    @ConfigProperty(name = "metrics.enable", defaultValue = "false")
    Boolean isMetricsEnable();

    @ConfigProperty(name = "metrics.reporter", converter = ReporterEnumConverter.class)
    ReporterEnum getMetricsReporter();
}
