package com.ws.commons.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
class UncaughtExceptionHandler {

    /**
     * Initializes the handlers for any uncaught exceptions
     */
    void initialize() {
        Thread.setDefaultUncaughtExceptionHandler(this::logUncaughtException);
    }

    /**
     * @param thread Thread where exception has happened
     * @param exception Detected exception
     */
    private void logUncaughtException(final Thread thread, final Throwable exception) {
        final String exceptionMessage = "Uncaught exception detected in thread " + thread.getName() + ": " + exception.getMessage();
        getLogger().error(exceptionMessage, exception);
    }

    /**
     * @return Logger instance
     */
    private Logger getLogger() {
        return LoggerFactory.getLogger(getClass());
    }
}
