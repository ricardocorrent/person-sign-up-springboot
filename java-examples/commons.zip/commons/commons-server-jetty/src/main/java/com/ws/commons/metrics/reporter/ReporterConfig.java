package com.ws.commons.metrics.reporter;

import com.ws.commons.metrics.MetricsReporters;
import com.ws.commons.metrics.converter.TimeUnitConverter;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * This class is responsible to define configuration properties for the default {@link MetricsReporters}.
 *
 * <p>The Metric's reporter may be informed in configuration properties' file, otherwise the collection of metrics won't
 * work. To properly set the desired collector, use</p>
 * <pre>
 *     metrics.reporter={JMX or ELASTICSEARCH}
 * </pre>
 * <p>in your apache-deltaspike.properties file.</p>
 *
 * <p>When ELASTICSEARCH is configured to be used, some server properties may be informed. This class defines them.</p>
 *
 * <p>Other available configurations and its meanings are available at the
 * <a href=https://gitlab.wssim.com.br/platform/commons/blob/master/configuration-options.md>
 * Configuration options
 * </a>
 * file.
 * </p>
 */
@Configuration(prefix = "metrics.reporter.")
public interface ReporterConfig {

    /**
     * @return the configured Elasticsearch IP address or DNS to access the server
     */
    @ConfigProperty(name = "elasticsearch.host")
    String getElasticsearchHost();

    /**
     * @return the configured Elasticsearch port access the server
     */
    @ConfigProperty(name = "elasticsearch.port", defaultValue = "9200")
    Integer getElasticsearchPort();

    /**
     * @return true if SSL may be used to connect to the server
     */
    @ConfigProperty(name = "elasticsearch.usessl", defaultValue = "false")
    Boolean isElasticsearchUseSsl();

    /**
     * @return the index name to be used on Elasticsearch. Defaults to "metrics".
     */
    @ConfigProperty(name = "elasticsearch.index", defaultValue = "metrics")
    String getElasticsearchIndex();

    /**
     * @return the prefix name to be used to connect to Elasticsearch.
     */
    @ConfigProperty(name = "elasticsearch.prefix")
    String getElasticsearchPrefix();

    /**
     * @return the time unit that defines scheduling of data publishing in Elasticsearch
     */
    @ConfigProperty(name = "elasticsearch.intervalunit", converter = TimeUnitConverter.class)
    TimeUnit getElasticsearchIntervalUnit();

    /**
     * @return the amount of time units when the data will be published
     */
    @ConfigProperty(name = "elasticsearch.intervalcount", defaultValue = "30")
    Long getElasticsearchIntervalCount();
}
