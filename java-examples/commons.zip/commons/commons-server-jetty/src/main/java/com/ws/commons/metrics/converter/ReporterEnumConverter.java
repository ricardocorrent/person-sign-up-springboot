package com.ws.commons.metrics.converter;

import com.ws.commons.metrics.reporter.ReporterEnum;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * {@link ConfigResolver} converter implementation for {@link ReporterEnum} enumerations.
 *
 * @author Hendric Gabriel Cechinato {@literal <hendric.cechinato@wssim.com.br>}
 * @since  7.5.0 - 2019-02-06
 */
public final class ReporterEnumConverter implements ConfigResolver.Converter<ReporterEnum> {

    /**
     * Converts the string provided in the configuration properties file to the desired type.
     *
     * @param value the string value to be converted
     * @return      the corresponding {@link ReporterEnum} value
     */
    @Override
    public ReporterEnum convert(final String value) {
        LoggerFactory
                .getLogger(getClass())
                .debug("Converting {} to {}", value, ReporterEnum.class.getName());

        return Optional
            .ofNullable(value)
            .map(String::toUpperCase)
            .map(ReporterEnum::valueOf)
            .orElse(null);
    }
}
