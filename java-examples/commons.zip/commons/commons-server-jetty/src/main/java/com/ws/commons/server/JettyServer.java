package com.ws.commons.server;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.eclipse.jetty.server.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.ServerSocket;
import java.security.Security;

/**
 * Helper to create and configure the embedded server.
 *
 * <p>This is the main start point to start a Jetty container server in a microservice.</p>
 *
 * <p>Usage:</p>
 * <pre>
 *     public class Main {
 *         public static void main(String[] args) {
 *             JettyServer.start();
 *         }
 *     }
 * </pre>
 *
 * @author  Gustavo Bilert
 * @author  Ivan A. Reffatti
 * @author  Franciones Marmentini
 * @author  Hendric Gabriel Cechinato
 * @version 5.0.0 - 2017-08-18 - Implemented logger prop
 * @version 7.5.0 - 2019-02-07 - Integrated metrics API
 * @since   4.11.0 - 2017-07-21
 */
public class JettyServer {

    private static final Logger LOGGER = LoggerFactory.getLogger(JettyServer.class);
    private static Server server;

    private JettyServer() {
    }

    /**
     * Creates and starts an embedded Jetty server with default configuration,
     * leveraging Jersey and CDI.
     *
     * @author              Ivan A. Reffatti
     * @return              a new started {@link Server} instance
     * @throws  Exception   if an error occurs while starting the server
     * @since               4.11.0 - 2017-07-21
     */
    public static Server start() throws Exception {

        new UncaughtExceptionHandler().initialize();
        new LogConfiguration().initialize();

        LOGGER.info("Welcome to Backend Foundation");

        try {
            long start = System.currentTimeMillis();
            server = WeldContext
                    .getInstance()
                    .getContainer()
                    .select(Server.class)
                    .get();

            server.start();

            JvmShutdownListener.getInstance().start();
            long end = System.currentTimeMillis();
            LOGGER.info("Server started successfully after {} milliseconds", (end - start));

            return server;
        } catch (final Exception ex) {
            LOGGER.error("Application startup failed", ex);
            System.exit(1);
            return null;
        }
    }

    /**
     * Stops the current runner instance.
     *
     * @throws Exception if any error occurs while stopping the server
     */
    public static void stop() throws Exception {
        shutdown();
        System.exit(0);
    }

    /**
     * @author Lucas Dillmann
     * @since 7.7.0, 2019-05-06
     * @throws Exception When shutdown fails
     */
    static void shutdown() throws Exception {
        // Stops Jetty Server
        LOGGER.info("Stopping Jetty server");
        if (server != null && server.isRunning()) {
            server.stop();
        } else {
            LOGGER.warn("Jetty server isn't running. Skipping shutdown.");
        }

        // Stops Weld CDI container
        LOGGER.info("Stopping Weld CDI container");
        final WeldContext context = WeldContext.getInstance();
        if (context.getContainer().isRunning()) {
            context.getWeld().shutdown();
        } else {
            LOGGER.warn("Weld CDI container isn't running. Skipping shutdown.");
        }

        LOGGER.info("Application shutdown completed");
    }

    /**
     * Creates an embedded Jetty server with default configuration, leveraging
     * Jersey and CDI. The server is not started, you must call {@link #start()}.
     *
     * @return a created server instance with WELD container configuration
     * @deprecated Use CDI injection instead
     */
    @Deprecated
    public static Server create() {

        // Register Bouncy Castle provider to enable HMACSHA256 algorithm for
        // the JWT token
        Security.addProvider(new BouncyCastleProvider());

        LOGGER.info("Starting CDI using Weld as the provider");
        WeldContext.getInstance().getWeld();

        LOGGER.info("Starting application Jetty container");
        server = WeldContext.getInstance().getContainer().select(Server.class).get();

        return server;
    }

    /**
     * Returns a free port number on localhost.
     * <p>
     * Heavily inspired from org.eclipse.jdt.launching.SocketUtil (to avoid a
     * dependency to JDT just because of this). Slightly improved with close()
     * missing in JDT. And throws exception instead of returning -1.
     * https://gist.github.com/vorburger/3429822
     * </p>
     *
     * @return                          a free port number on localhost
     * @throws IllegalStateException    if unable to find a free port
     * @deprecated Deprecated as of 26-03-2019. Method isn't used anymore to start Jetty Server.
     */
    @Deprecated
    public static int findFreePort() {
        try (ServerSocket socket = new ServerSocket(0)) {
            socket.setReuseAddress(true);
            return socket.getLocalPort();
        } catch (final Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Returns Jetty server status.
     *
     * @return  Jetty server status. {@code true} means that it is running.
     * @author  Lucas Dillmann
     * @since   7.4.0 - 2018-12-10
     * @deprecated Use CDI injection instead and query status from {@link Server} object.
     */
    @Deprecated
    public static boolean isStarted() {
        return server != null && server.isStarted();
    }

    /**
     * Method that exposes jetty web container server. An {@link IllegalStateException} is thrown if the server was not
     * instantiated yet.
     *
     * @return  Jetty server
     * @author  Evaristo W. Benfatti
     * @since   4.0.0, 2017-02-03
     * @deprecated Use CDI injection instead
     */
    @Deprecated
    public static Server getServer() {
        if (server == null) {
            throw new IllegalStateException("Server not instantiated yet.");
        }

        return server;
    }

}
