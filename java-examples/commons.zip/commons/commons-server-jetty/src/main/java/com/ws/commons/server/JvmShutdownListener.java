package com.ws.commons.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Lucas Dillmann
 * @since 7.7.0, 2019-05-06
 */
public final class JvmShutdownListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(JvmShutdownListener.class);
    private static JvmShutdownListener instance;
    private final Thread listener;

    private JvmShutdownListener() {
        this.listener = new Thread(this::handleShutdownEvent);
    }

    public static synchronized JvmShutdownListener getInstance() {
        if (instance == null) {
            instance = new JvmShutdownListener();
        }

        return instance;
    }

    public void start() {
        LOGGER.debug("Starting JVM shutdown listener");
        Runtime.getRuntime().addShutdownHook(listener);
    }

    public void stop() {
        LOGGER.debug("Stopping JVM shutdown listener");
        Runtime.getRuntime().removeShutdownHook(listener);
    }

    private void handleShutdownEvent() {
        try {
            JettyServer.shutdown();
        } catch (final Exception ex) {
            LOGGER.error("Error stopping application on JVM shutdown", ex);
        }
    }
}
