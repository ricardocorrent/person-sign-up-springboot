package com.ws.commons.server.exception;

/**
 * Exception to be thrown when some config is not properly set on service.
 *
 * @author  Ivan A. Reffatti
 * @author  Franciones Marmentini
 * @version 5.0.0 - 2017-08-10
 * @since   4.12.0 - 2017-07-27
 *
 */
@SuppressWarnings("serial")
public class MissingConfigException extends RuntimeException {

    /**
     * Default exception constructor with {@code message} initialization.
     *
     * @param message the exception message.
     */
    public MissingConfigException(final String message) {
        super(message);
    }

}
