package com.ws.commons.server;

import org.eclipse.jetty.server.Server;

/**
 * Jetty server customizer interface
 *
 * <p>This interface allows the customization of the Jetty {@link Server} instance prior to being started. For example,
 * this interface can be used to install custom filters and interceptors in the container for domain specific needs
 * of the application.</p>
 *
 * <p>All implementations will be called using CDI.</p>
 *
 * @author  Lucas Dillmann
 * @since   7.4.0 - 2018-12-13
 */
public interface JettyServerCustomizer {

    /**
     * Customizes the Jetty Server instance.
     *
     * @param server Jetty Server instance
     */
    void customize(Server server);
}
