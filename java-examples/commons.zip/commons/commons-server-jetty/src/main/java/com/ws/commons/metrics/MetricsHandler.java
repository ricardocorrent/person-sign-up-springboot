package com.ws.commons.metrics;

import com.codahale.metrics.MetricRegistry;
import com.ws.commons.ServerProperties;
import com.ws.commons.metrics.collector.*;
import com.ws.commons.metrics.exception.MissingConfigException;
import com.ws.commons.metrics.reporter.MetricsReporter;
import com.ws.commons.metrics.reporter.ReporterConfig;
import com.ws.commons.metrics.reporter.ReporterEnum;
import com.ws.commons.server.JettyServerCustomizer;
import org.eclipse.jetty.server.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Handler class for {@link Metrics} configuration properties.
 *
 * <p>This class is responsible to retrieve all configurations provided through the DeltaSpike configuration
 * file and perform the integration of the {@link Metrics} API with {@code JettyServer} initialization.</p>
 *
 * <p>It is called during {@code JettyServer} initialization and is able to retrieve an instance of {@link Metrics} and
 * start the collectors ({@link JettyMetricsCollector}, {@link JvmMetricsCollector} and {@link Log4j2MetricsCollector})
 * - if they're configured to be ran. {@link JerseyMetricsCollector} is activated via {@code ApplicationConfig} or
 * {@code DefaultConfig} class.</p>
 *
 * @author Hendric Gabriel Cechinato {@literal <hendric.cechinato@wssim.com.br}
 * @since 7.5.0 - 2019-02-06
 */
public class MetricsHandler implements JettyServerCustomizer {

    private final Logger logger = LoggerFactory.getLogger(MetricsHandler.class);
    private final MetricsConfig metricsConfig;
    private final CollectorConfig collectorConfig;
    private final ReporterConfig reporterConfig;
    private final ServerProperties serverProperties;

    /**
     * CDI-enabled constructor with configuration properties initialization. This constructor is responsible to load the
     * metrics configurations available in DeltaSpike properties file.
     *
     * @param metricsConfig     the metrics configurations object
     * @param collectorConfig   the collector's configurations object
     * @param reporterConfig    the reporter's configurations object
     */
    @Inject
    public MetricsHandler(final MetricsConfig metricsConfig,
                          final CollectorConfig collectorConfig,
                          final ReporterConfig reporterConfig,
                          final ServerProperties serverProperties){
        this.metricsConfig = metricsConfig;
        this.collectorConfig = collectorConfig;
        this.reporterConfig = reporterConfig;
        this.serverProperties = serverProperties;
    }

    /**
     * Starts the metrics API and invokes the startup of configured collectors.
     */
    public void start(final Server server, final String serviceName) {
        Objects.requireNonNull(serviceName);
        Objects.requireNonNull(server);

        startMetrics(serviceName, resolveReporter());
        logger.info("Metrics started successfully.");

        resolveCollectors(server);
    }

    protected void startMetrics(final String serviceName, final MetricsReporter reporter) {
        Metrics.getInstance().initialize(serviceName, reporter, new MetricRegistry());
    }

    protected MetricsReporter resolveReporter() {
        final ReporterEnum reporter = metricsConfig.getMetricsReporter();
        if (reporter == null) {
            throw new MissingConfigException(
                    "The {metrics.reporter} configuration may not be null. " +
                            "Please choose JMX or ELASTICSEARCH."
            );
        }

        if (reporter.equals(ReporterEnum.JMX)) {
            return MetricsReporters.jmx();
        } else if (reporter.equals(ReporterEnum.ELASTICSEARCH)) {
            final String host = reporterConfig.getElasticsearchHost();
            final Integer port = reporterConfig.getElasticsearchPort();
            final boolean useSsl = reporterConfig.isElasticsearchUseSsl();
            final String index = reporterConfig.getElasticsearchIndex();
            final String prefix = reporterConfig.getElasticsearchPrefix();
            final TimeUnit intervalUnit = reporterConfig.getElasticsearchIntervalUnit();
            final Long intervalCount = reporterConfig.getElasticsearchIntervalCount();

            validatePropertyNotNull(host, "metrics.reporter.elasticsearch.host");
            validatePropertyNotNull(port, "metrics.reporter.elasticsearch.port");

            return MetricsReporters.elasticsearch(host, port, useSsl, index, prefix, intervalUnit, intervalCount);
        }
        throw new MissingConfigException(
                "Invalid configuration for {metrics.reporter}" +
                        "Please use JMX or ELASTICSEARCH values."
        );
    }

    protected void resolveCollectors(final Server server) {
        final Metrics instance = Metrics.getInstance();
        if (collectorConfig.isJvmEnable()) {
            instance.startCollector(MetricsCollectors.jvm());
        }
        if (collectorConfig.isJettyEnable()) {
            instance.startCollector(MetricsCollectors.jetty(server));
        }
        if (collectorConfig.isLog4j2Enable()) {
            instance.startCollector(MetricsCollectors.log4j2());
        }
    }

    private <T> void validatePropertyNotNull(T property, String propertyKey) {
        if (property == null) {
            throw new MissingConfigException("Missing configuration property for {" + propertyKey + "}.");
        }
    }

    @Override
    public void customize(final Server server) {
        if(metricsConfig.isMetricsEnable()) {
            final String serviceName = serverProperties.getServiceName();
            start(server, serviceName);
        }
    }
}
