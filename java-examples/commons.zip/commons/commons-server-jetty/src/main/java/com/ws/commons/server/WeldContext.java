package com.ws.commons.server;

import org.jboss.weld.environment.se.Weld;
import org.jboss.weld.environment.se.WeldContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CDI container instance holder
 *
 * <p>This class holds the current application CDI container instance provided by {@link Weld}.</p>
 *
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
public final class WeldContext {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeldContext.class);
    private static WeldContext instance;
    private final Weld weld;
    private final WeldContainer container;

    /**
     * Private constructor for singleton pattern
     */
    private WeldContext() {
        this.weld = new Weld();
        this.container = weld.initialize();
    }

    /**
     * Singleton access-point method
     *
     * @return Current holder instance
     */
    public static synchronized WeldContext getInstance() {
        if (instance == null) {
            LOGGER.info("Starting CDI container");
            instance = new WeldContext();
        }

        return instance;
    }

    /**
     * @return Weld instance
     */
    public Weld getWeld() {
        return weld;
    }

    /**
     * @return Weld container instance
     */
    public WeldContainer getContainer() {
        return container;
    }
}
