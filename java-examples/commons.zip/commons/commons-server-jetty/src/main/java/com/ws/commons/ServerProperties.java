package com.ws.commons;

import com.ws.commons.server.JettyServer;
import com.ws.commons.server.exception.MissingConfigException;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.webapp.WebAppContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.ServletRegistration;
import java.util.Collection;

/**
 * Provides Apache DeltaSpike custom server properties.
 *
 * <p>This class contains all parameters of a {@link JettyServer} configuration that can be customized through
 * Apache DeltaSpike properties file</p>
 *
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @version 4.11.0 - 2017-07-21
 * @since   1.1.0
 */
@ApplicationScoped
public class ServerProperties {

    private final Logger logger = LoggerFactory.getLogger(ServerProperties.class);

    public static final String DISCOVERY_SERVICE_ADDRESS = "discovery.service.address";
    public static final String HOST = "host";
    public static final String PORT = "port";

    public static final String LOG_LEVEL = "log.level";

    /**
     * @since 3.2.0 2016-11-25
     * */
    public static final String AUTHORIZATION_SERVICE_NAME = "authorization.service.name";
    public static final String AUTHORIZATION_SERVICE_API  = "authorization.service.api";

    public static final String SERVICE_NAME = "service.name";
    @Deprecated
    public static final String TEST_MOCK_USER = "test.mock.user";
    @Deprecated
    public static final String TEST_MOCK_USER_ID = "test.userid";
    @Deprecated
    public static final String TEST_MOCK_USER_USERNAME = "test.username";
    @Deprecated
    public static final String TEST_MOCK_USER_PASSWORD = "test.password";

    /**
     * @since 4.0.0, 2016-11-10
     */
    public static final String SERVICE_VERSION = "service.version";

    public static final String DOMAIN = "domain";
    public static final String JWT_TIMEOUT_EXPIRATION_SECONDS = "jwt.timeout.seconds";

    @Inject
    private ProjectStage stage;

    @Inject
    @ConfigProperty(name = HOST)
    private String host;

    @Inject
    @ConfigProperty(name = PORT, defaultValue = "80")
    private Integer port;

    @Inject
    @ConfigProperty(name = SERVICE_NAME)
    private String serviceName;

    @Inject
    @ConfigProperty(name = AUTHORIZATION_SERVICE_NAME, defaultValue = "user")
    private String authorizarionServiceName;

    @Inject
    @ConfigProperty(name = TEST_MOCK_USER_USERNAME)
    private String testUsername;

    @Inject
    @ConfigProperty(name = TEST_MOCK_USER_PASSWORD)
    private String testPassword;

    @Inject
    @ConfigProperty(name = TEST_MOCK_USER_ID)
    private String testUserId;

    @Inject
    @ConfigProperty(name = TEST_MOCK_USER, defaultValue = "false")
    private Boolean testMockUser;

    @Inject
    @ConfigProperty(name = DOMAIN, defaultValue = "sollar.com")
    private String domain;

    @Inject
    @ConfigProperty(name = JWT_TIMEOUT_EXPIRATION_SECONDS, defaultValue = "30")
    private Integer jwtTimeoutExpirationSeconds;

    @Inject
    @ConfigProperty(name = DISCOVERY_SERVICE_ADDRESS)
    private String discoveryServiceAddress;


    @Inject
    @ConfigProperty(name = LOG_LEVEL, defaultValue = "INFO")
    private String logLevel;

    /**
     * @since 4.0.0, 2016-11-10
     */
    @Inject
    @ConfigProperty(name = SERVICE_VERSION)
    private String serviceVersion;

    /**
     * The context API path.
     *
     * <p>Currently, when present, it is the "rest-application" servlet mapping in web.xml otherwise, the default context
     * path.</p>
     *
     * @since 4.0.0 - 2016-11-10
     */
    private String serviceApiRestContextPath;

    @Inject
    @ConfigProperty(name = AUTHORIZATION_SERVICE_API, defaultValue = "/users/self-permissions")
    private String authorizationServiceApi;

    public String getDiscoveryServiceAddress() {
        return discoveryServiceAddress;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getAuthorizarionServiceName() {
        return authorizarionServiceName;
    }

    public Integer getPort() {
        return port;
    }

    public String getTestUsername() {
        return testUsername;
    }

    public void setTestUsername(String testUsername) {
        this.testUsername = testUsername;
    }

    public String getTestPassword() {
        return testPassword;
    }

    public void setTestPassword(String testPassword) {
        this.testPassword = testPassword;
    }

    public String getTestUserId() {
        return testUserId;
    }

    public void setTestUserId(String testUserId) {
        this.testUserId = testUserId;
    }

    public Boolean isUserMocked() {
        return testMockUser;
    }

    public String getHost() {
        return host;
    }

    public String getServiceVersion() {
        return serviceVersion;
    }

    public String getServiceApiRestContextPath() {
        if(serviceApiRestContextPath == null)
            doConfigurePropertiesPostServerStart();
        return serviceApiRestContextPath;
    }

    private void setServiceApiRestContextPath(String serviceApiRestContextPath) {
        this.serviceApiRestContextPath = serviceApiRestContextPath;
    }

    public String getDomain() {
        return this.domain;
    }

    public Integer getJwtTimeoutExpirationSeconds(){
        return this.jwtTimeoutExpirationSeconds;
    }

    public String getAuthorizationServiceApi() {
        return authorizationServiceApi;
    }

    public String getLogLevel() {
        return logLevel;
    }

    /**
     * Validates the configuration done on apache-deltaspike.properties.
     *
     * @author  Ivan A. Reffatti
     * @author  Evaristo W. Benfatti
     * @since   2016-02-05
     * @since   4.0.0, 2017-02-03 - Added post start properties configuration support
     */
    @PostConstruct
    private void validateConfiguration(){
        // Perform configuration to properties which are filled out after server start
        //doConfigurePropertiesPostServerStart();

        logger.debug("Validating server properties...");
        logger.debug("{} = {} ", SERVICE_NAME, this.getServiceName());
        logger.debug("{} = {} ", SERVICE_VERSION, this.getServiceVersion());
        logger.debug("{} = {} ", DISCOVERY_SERVICE_ADDRESS, this.getDiscoveryServiceAddress());
        logger.debug("{} = {} ", PORT, this.getPort());
        logger.debug("{} = {} ", TEST_MOCK_USER, this.isUserMocked());

        final StringBuilder missingConfigBuffer = new StringBuilder();

        validateService(missingConfigBuffer);
        validateHost(missingConfigBuffer);
        validateUserToTests(missingConfigBuffer);

        final String missingConfigMsg = missingConfigBuffer.toString();
        if(!StringUtils.isEmpty(missingConfigMsg)){
            throw new MissingConfigException(missingConfigMsg);
        }
        logger.debug("Validating server properties finished.");
    }

    /**
     * Validates the service name and version.
     *
     * @param missingConfigBuffer to add the missing configs
     */
    private void validateService(final StringBuilder missingConfigBuffer ) {
        if (this.getServiceName() == null && !isIntegrationTestStage()) {
            missingConfigBuffer.append(SERVICE_NAME).append(" needs to be set in stage ").append(stage.toString()).append(". See commons lib documentation.\n");
        }
        if (this.getServiceVersion() == null && !isIntegrationTestStage()) {
            logger.warn("{} not set {}. We'll try to use default configuration.\n", SERVICE_VERSION, stage.toString());
        }
    }

    /**
     * Validates the user in case of test.
     *
     * @param missingConfigBuffer to add the missing configs
     */
    private void validateUserToTests(final StringBuilder missingConfigBuffer ) {
        if(this.isUserMocked() && (this.getTestPassword() == null || this.getTestUserId() == null || this.getTestUsername() == null)){
            missingConfigBuffer.append("When ").append(TEST_MOCK_USER).append(" is set, parameters ").append(TEST_MOCK_USER_ID).append(", ")
                    .append(TEST_MOCK_USER_USERNAME).append(", ").append(TEST_MOCK_USER_PASSWORD).append(" needs to be set too.\n");
        }

    }

    /**
     * Validates the host property.
     *
     * @param missingConfigBuffer to add the missing configs
     */
    private void validateHost(final StringBuilder missingConfigBuffer ) {
        if (this.getHost() == null && !isProductionOrStaging() && !isIntegrationTestStage()) {
            if(stage== null || StringUtils.isEmpty(stage.toString())){
                throw new MissingConfigException("Stage not found.");
            }
            missingConfigBuffer.append(HOST).append(" needs to be set in stage ").append(stage.toString()).append(". See commons lib documentation.\n");
        }
    }

    private Boolean isProductionOrStaging(){
        return (this.stage.equals(ProjectStage.Production) ||
                this.stage.equals(ProjectStage.Staging));
    }

    private Boolean isIntegrationTestStage(){
        return this.stage.equals(ProjectStage.IntegrationTest);
    }

    /**
     * Performs the post configuration after Jetty Server start. Actually it fill out the serviceApiRestContextPath to
     * the application.
     *
     * @author  Evaristo W. Benfatti
     * @since   4.0.0 - 2016-11-10
     */
    private void doConfigurePropertiesPostServerStart() {

        WebAppContext webAppContext = ((HandlerCollection) JettyServer.getServer().getHandler())
                .getChildHandlerByClass(WebAppContext.class);

        setServiceApiRestContextPath(getServiceApiRestContextPath(webAppContext));

    }

    /**
     * Gets the serviceApi context root path.
     *
     * <p>The servlet mapping used to do it is "rest-application". If it is not present, the default servlet mapping context
     * is returned.</p>
     *
     * @author              Evaristo W. Benfatti
     * @param webAppContext the web application context handler
     * @return              serviceApi context path
     * @since               4.0.0 - 2016-11-10
     */
    private String getServiceApiRestContextPath(final WebAppContext webAppContext) {

        ContextHandler.Context servletContext = webAppContext.getServletContext();

        ServletRegistration servletRegistration = servletContext.getServletRegistration("rest-application");

        if (servletRegistration == null) {
            servletRegistration = servletContext.getServletRegistration("default");
        }

        Collection<String> servletMappings = servletRegistration.getMappings();

        return servletMappings.isEmpty() ? null : servletMappings.iterator().next();
    }
}
