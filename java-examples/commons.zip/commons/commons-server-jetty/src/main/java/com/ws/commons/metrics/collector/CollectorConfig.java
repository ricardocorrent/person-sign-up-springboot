package com.ws.commons.metrics.collector;

import com.ws.commons.metrics.MetricsCollectors;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.config.Configuration;

/**
 * This class is responsible to define configuration properties for the default {@link MetricsCollectors}.
 *
 * <p>
 * These configurations mainly defines which collectors may be started with the application, such as Jersey and Jetty,
 * for example.
 * </p>
 *
 * <p>Metrics collectors are disabled by default. To activate its features, set</p>
 * <pre>
 *     metrics.collector.{desiredCollector}.enable=true
 * </pre>
 * <p>in your apache-deltaspike.properties file.</p>
 *
 * <p>Other available configurations and its meanings are available at the
 * <a href=https://gitlab.wssim.com.br/platform/commons/blob/master/configuration-options.md>
 * Configuration options
 * </a>
 * file.
 * </p>
 */
@Configuration(prefix = "metrics.collector.")
public interface CollectorConfig {

    /**
     * @return true if JVM collector is configured to be enabled
     */
    @ConfigProperty(name = "jvm.enable", defaultValue = "false")
    Boolean isJvmEnable();

    /**
     * @return true if Jersey collector is configured to be enabled
     */
    @ConfigProperty(name = "jersey.enable", defaultValue = "false")
    Boolean isJerseyEnable();

    /**
     * @return true if Jetty collector is configured to be enabled
     */
    @ConfigProperty(name = "jetty.enable", defaultValue = "false")
    Boolean isJettyEnable();

    /**
     * @return true if Log4j2 collector is configured to be enabled
     */
    @ConfigProperty(name = "log4j2.enable", defaultValue = "false")
    Boolean isLog4j2Enable();
}
