package com.ws.commons.metrics.reporter;

/**
 * Enumerator that defines the reporters that can be used in metrics collection.
 *
 * <p>Define it in your apache-deltaspike.properties file</p>
 * <pre>
 *     metrics.reporter=JMX
 * </pre>
 * <p>or</p>
 * <pre>
 *     metrics.reporter=ELASTICSEARCH
 * </pre>
 *
 * @author Hendric Gabriel Cechinato {@literal <hendric.cechinato@wssim.com.br>}
 * @since  7.5.0 - 2019-06-02
 */
public enum ReporterEnum {

    JMX, ELASTICSEARCH
}
