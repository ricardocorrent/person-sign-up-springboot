package com.ws.commons.server;

import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ErrorHandler;
import org.eclipse.jetty.util.thread.ThreadPool;
import org.eclipse.jetty.webapp.WebAppContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.BeanManager;

import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

/**
 * @author Lucas Dillmann
 * @since 7.6.0, 2019-03-28
 */
@RunWith(MockitoJUnitRunner.class)
public class JettyServerProducerUnitTests {

    @Mock
    private Server server;
    @Mock
    private WebAppContext context;
    @Mock
    private ErrorHandler errorHandler;
    @Mock
    private Instance<JettyServerCustomizer> customizers;
    @Mock
    private JettyServerCustomizer customizer;
    @Mock
    private BeanManager beanManager;
    @Mock
    private Handler handler;

    private JettyServerProducer producer;

    @Before
    public void setup() {
        doReturn(Collections.singletonList(customizer).spliterator()).when(customizers).spliterator();
        doReturn(mock(ThreadPool.class)).when(server).getThreadPool();
        doReturn(handler).when(server).getHandler();
        doReturn(new Handler[] { handler }).when(context).getChildHandlers();

        this.producer = new JettyServerProducer();
    }

    @Test
    public void whenProducerMethodForServerIsCalledItShouldProduceAnInstance() {
        // execution
        final Server server = producer.server(errorHandler, context, customizers);

        // validation
        assertNotNull(server);
    }

    @Test
    public void whenProducerMethodForServerIsCalledAndACustomizerIsAvailableItShouldInvokeThatCustomizer() {
        // execution
        producer.server(errorHandler, context, customizers);

        // validation
        verify(customizer, times(1)).customize(any(Server.class));
    }

    @Test
    public void whenProducerMethodForConnectorIsCalledItShouldProduceAnInstance() {
        // execution
        final Connector connector = producer.connector(server);

        // validation
        assertNotNull(connector);
    }

    @Test
    public void whenProducerMethodForContextIsCalledItShouldProduceAnInstance() {
        // execution
        final WebAppContext context = producer.webAppContext(beanManager, errorHandler);

        // validation
        assertNotNull(context);
    }

    @Test
    public void whenProducerMethodForErrorHandlerIsCalledItShouldProduceAnInstance() {
        // execution
        final ErrorHandler errorHandler = producer.errorHandler();

        // validation
        assertNotNull(errorHandler);
    }

}
