package com.ws.commons.pojoconverter.pojocolumnmapping.artifact;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Entity that stores location information only for {@link PojoConverter} testing purposes.
 *
 * @author  Diego Armange Costa
 * @since   6.0.0 - 2018-02-15
 */
@SuppressWarnings({ "javadoc", "serial" })
@Entity
public class Location extends SoftDeleteBaseEntity implements IPojoConverter{

    private static final UUID SERVICE_ID = UUID.randomUUID();
    
    private static final String FAKE_DESCRIPTION = "Fake location";
    
    private static final UUID AREA_SERVICE_ID = UUID.randomUUID();
    
    private static final String AREA_SERVICE_DESCRIPTION = "Fake area service";

    private static final UUID AREA_ID = UUID.randomUUID();
    
    private static final String AREA_DESCRIPTION = "Fake area";
    
    private String description;
    
    @PojoColumnMapper(target="service.id")
    private UUID serviceId;
    
    @PojoColumnMapper(target="area.service.id")
    private UUID areaServiceId;
    
    @PojoColumnMapper(target="area.service.description")
    private String areaServiceDescription;
    
    @PojoColumnMapper(target="area.id")
    private UUID areaId;
    
    @PojoColumnMapper(target="area.description")
    private String areaDescription;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "city_id")
    private City city;

    @ManyToOne
    @JsonBackReference(value = "location-customer")
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    private Customer customer;

    // Do not use this as Business rule, it's just for test purposes
    @OneToMany(mappedBy = "location", cascade = CascadeType.ALL)
    private List<City> citiesList;

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
    
    public UUID getServiceId() {
        return serviceId;
    }
    
    public void setServiceId(final UUID serviceId) {
        this.serviceId = serviceId;
    }
    
    public UUID getAreaServiceId() {
        return areaServiceId;
    }
    
    public void setAreaServiceId(final UUID areaServiceId) {
        this.areaServiceId = areaServiceId;
    }
    
    public String getAreaServiceDescription() {
        return areaServiceDescription;
    }

    public void setAreaServiceDescription(final String areaServiceDescription) {
        this.areaServiceDescription = areaServiceDescription;
    }
    
    public UUID getAreaId() {
        return areaId;
    }

    public void setAreaId(final UUID areaId) {
        this.areaId = areaId;
    }

    public String getAreaDescription() {
        return areaDescription;
    }

    public void setAreaDescription(final String areaDescription) {
        this.areaDescription = areaDescription;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<City> getCitiesList() {
        return citiesList;
    }

    public void setCitiesList(List<City> citiesList) {
        this.citiesList = citiesList;
    }

    /**
     * @return A fake {@link Location}
     */
    public static Location fakeLocation() {
        final Location location = new Location();
        
        location.setDescription(FAKE_DESCRIPTION);
        
        location.setServiceId(SERVICE_ID);
        
        location.setAreaServiceId(AREA_SERVICE_ID);
        
        location.setAreaServiceDescription(AREA_SERVICE_DESCRIPTION);
        
        location.setAreaId(AREA_ID);
        
        location.setAreaDescription(AREA_DESCRIPTION);

        location.setCity(City.fakeCity());

        location.setCitiesList(Collections.singletonList(City.fakeCity()));

        return location;
    }
}
