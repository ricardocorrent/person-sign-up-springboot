package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;

/**
 * Entity for testing purposes.
 *
 * @author Diego Armange Costa
 * @since 5.3.1 - 2017-12-04
 */
class RestrictedClass implements IPojoConverter {

    private String anyString;
    
    @SuppressWarnings("unused")
    private String getAnyString() {
        return anyString;
    }
    
    @SuppressWarnings("unused")
    private void setAnyString(final String anyString) {
        this.anyString = anyString;
    }
}
