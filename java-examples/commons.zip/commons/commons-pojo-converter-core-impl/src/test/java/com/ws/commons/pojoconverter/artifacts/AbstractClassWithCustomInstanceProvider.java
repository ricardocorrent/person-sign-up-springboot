package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.provider.AbstractClassPojoConverterInstanceProvider;

/**
 * Test artifact with custom instance provider.
 *
 * @author  Lucas Dillmann
 * @see     AbstractClassPojoConverterInstanceProvider
 * @since   7.3.0 - 2018-09-11
 */
@PojoInstanceProvider(AbstractClassPojoConverterInstanceProvider.class)
public abstract class AbstractClassWithCustomInstanceProvider implements IPojoConverter {

    private String testString;

    public String getTestString() {
        return testString;
    }

    public void setTestString(String testString) {
        this.testString = testString;
    }
}
