package com.ws.commons.pojoconverter.artifacts.provider;

import com.ws.commons.pojoconverter.artifacts.ClassNotConvertible;
import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;
import com.ws.commons.utils.reflection.ClassReflectionHelper;

/**
 * Test artifact for {@link PojoConverterInstanceProvider} for {@link ClassNotConvertible}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class ClassNotConvertibleTestPojoConverterInstanceProvider
        implements PojoConverterInstanceProvider<ClassNotConvertible> {

    /**
     * Produces an instance compatible with the given target class
     *
     * @param targetClass       target class where an instance is needed
     * @param sourceFieldValue  source value being converted for the needed instance, when available
     * @return                  object instance to be used in the target of the conversion
     */
    @Override
    public ClassNotConvertible produce(final Class<? extends ClassNotConvertible> targetClass, final Object sourceFieldValue) {
        return ClassReflectionHelper.newInstanceFromClass(targetClass);
    }

}
