package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;

/**
 * @author Lucas Dillmann
 * @since 7.6.1, 2019-04-30
 */
public class NullFieldConversionTO implements IPojoConverter {

    private String convertibleField;
    private boolean convertibleFieldChanged;

    private String notConvertibleField;
    private boolean notConvertibleFieldChanged;

    public String getConvertibleField() {
        return convertibleField;
    }

    public void setConvertibleField(String convertibleField) {
        this.convertibleField = convertibleField;
        this.convertibleFieldChanged = true;
    }

    public boolean isConvertibleFieldChanged() {
        return convertibleFieldChanged;
    }

    public String getNotConvertibleField() {
        return notConvertibleField;
    }

    public void setNotConvertibleField(String notConvertibleField) {
        this.notConvertibleField = notConvertibleField;
        this.notConvertibleFieldChanged = true;
    }

    public boolean isNotConvertibleFieldChanged() {
        return notConvertibleFieldChanged;
    }

}
