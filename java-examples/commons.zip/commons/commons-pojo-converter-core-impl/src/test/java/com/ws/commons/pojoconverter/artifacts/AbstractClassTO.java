package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;

/**
 * Test artifact.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class AbstractClassTO implements IPojoConverter {

    private String testString;

    public String getTestString() {
        return testString;
    }

    public void setTestString(String testString) {
        this.testString = testString;
    }
}
