package com.ws.commons.pojoconverter.pojocolumnmapping.artifact;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.PojoConverter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.List;

/**
 * Entity that stores information of a city used only for {@link PojoConverter} testing purposes.
 *
 * @author  Diego Armange Costa
 * @since   6.0.0 - 2018-02-15
 */
@SuppressWarnings({ "javadoc", "serial" })
@Entity
public class City extends SoftDeleteBaseEntity {

    private String name;

    private String state;

    @ManyToOne
    @JsonBackReference(value = "location-cities")
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    private Location location;

    @JsonBackReference
    @OneToMany(mappedBy = "city")
    private List<Location> locations;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<Location> getLocations() {
        return locations;
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    public static City fakeCity() {
        final City city = new City();

        city.setName("Great City");
        city.setState("Nice State");

        return city;
    }
}
