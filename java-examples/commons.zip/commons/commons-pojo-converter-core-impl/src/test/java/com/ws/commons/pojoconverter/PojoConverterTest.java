package com.ws.commons.pojoconverter;

import com.ws.commons.pojoconverter.artifacts.*;
import com.ws.commons.pojoconverter.artifacts.backreference.BackReferenceChildPojoDTO;
import com.ws.commons.pojoconverter.artifacts.backreference.BackReferenceParentPojo;
import com.ws.commons.pojoconverter.artifacts.backreference.BackReferenceParentPojoDTO;
import com.ws.commons.pojoconverter.provider.DefaultPojoConverterInstanceProvider;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.utils.reflection.ClassReflectionHelper;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.hamcrest.collection.IsEmptyCollection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.verifyPrivate;
import static org.powermock.api.mockito.PowerMockito.whenNew;

/**
 * Test cases for {@link PojoConverter}.
 * <p>Used to run different scenarios when converting entity objects to DTO and vice-versa.</p>
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-06-01
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({PojoConverter.class, ClassConvertible01TO.class, DefaultPojoConverterInstanceProvider.class, ClassReflectionHelper.class})
public class PojoConverterTest {

    private PojoConverter pojoConverter;
    
    /**
     * Creates a {@link PojoConverter} instance.
     */
    @Before
    public void init(){
        pojoConverter = new PojoConverter();
    }
    
    /**
     * Converts specific attributes.
     */
    @Test
    public void convertWithOnlyTwoColumns(){
        final ClassConvertible01 entity = new ClassConvertible01(1L);
        
        entity.setId(UUID.randomUUID());
        
        entity.setPrimitiveNumber(1);
        
        final ClassConvertible01TO viewObject = entity.convert(ClassConvertible01TO.class, "id", "primitiveNumber");
        
        Assert.assertNotNull(viewObject);
        
        final Long viewObjLongValue = (Long) FieldReflectionHelper.fromInstance(viewObject).getFieldValue("longObject");
        
        Assert.assertNull(viewObjLongValue);
        
        Assert.assertEquals(viewObject.getId(), entity.getId());
        
        Assert.assertEquals(viewObject.getPrimitiveNumber(), entity.getPrimitiveNumber());
    }
    
    /**
     * Converts an object and an inner object.
     */
    @Test
    public void convertWithConvertibleObject(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassConvertible02 childEntity = new ClassConvertible02();
        
        childEntity.setId(UUID.randomUUID());
        
        entity.setConvertibleObject(childEntity);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getConvertibleObject());
        
        Assert.assertNotEquals(viewObject.getConvertibleObject().getClass().hashCode(), entity.getConvertibleObject().getClass().hashCode());
        
        Assert.assertEquals(viewObject.getConvertibleObject().getId(), entity.getConvertibleObject().getId());
    }
    
    /**
     * Converts an object, but does not convert the inner object.
     */
    @Test
    public void convertWithNotConvertibleObject(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassNotConvertible childEntity = new ClassNotConvertible();
        
        childEntity.setId(UUID.randomUUID());
        
        entity.setClassNotConvertible(childEntity);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getClassNotConvertible());
        
        Assert.assertEquals(viewObject.getClassNotConvertible().getClass().hashCode(), entity.getClassNotConvertible().getClass().hashCode());
        
        Assert.assertEquals(viewObject.getClassNotConvertible().getId(), entity.getClassNotConvertible().getId());
    }
    
    /**
     * Converts an object and an inner list.
     */
    @Test
    public void convertWithConvertibleList(){
        final PojoConverter pojoConverter = PowerMockito.spy(new PojoConverter());
        
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final List<ClassConvertible02> convertibleObjectList = new ArrayList<>();
        
        final ClassConvertible02 classTest001 = new ClassConvertible02();
        
        classTest001.setId(UUID.randomUUID());
        
        convertibleObjectList.add(classTest001);
        
        entity.setConvertibleObjectList(convertibleObjectList);
        
        final Map<Class<?>, Class<?>> classMapper = new HashMap<Class<?>, Class<?>>();
        
        classMapper.put(entity.getClass(), ClassConvertible01TO.class);
        
        classMapper.put(classTest001.getClass(), ClassConvertible02TO.class);

        final ClassConvertible01TO viewObject = (ClassConvertible01TO) pojoConverter.convert(classMapper, entity);
        
        verify(pojoConverter, times(0)).convert(ClassConvertible02TO.class, entity);
        
        verify(pojoConverter, times(0)).convert(ClassConvertible02TO.class, classTest001);
        
        try {
            verifyPrivate(pojoConverter, times(0)).invoke("isConvertibleType", Class.class);
        } catch (Exception e) {
            e.printStackTrace();
            
            fail();
        }
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getConvertibleObjectList());
        
        Assert.assertNotEquals(viewObject.getConvertibleObjectList().get(0).getClass().hashCode(), entity.getConvertibleObjectList().get(0).getClass().hashCode());
        
        Assert.assertEquals(viewObject.getConvertibleObjectList().get(0).getId(), entity.getConvertibleObjectList().get(0).getId());
    }
    
    /**
     * Converts an object, but does not convert the inner list.
     */
    @Test
    public void convertWithNotConvertibleList(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final List<ClassNotConvertible> notConvertibleObjectList = new ArrayList<>();
        
        final ClassNotConvertible childEntity = new ClassNotConvertible();
        
        childEntity.setId(UUID.randomUUID());
        
        notConvertibleObjectList.add(childEntity);
        
        entity.setNotConvertibleObjectList(notConvertibleObjectList);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getNotConvertibleObjectList());
        
        Assert.assertEquals(viewObject.getNotConvertibleObjectList().get(0).getClass().hashCode(), entity.getNotConvertibleObjectList().get(0).getClass().hashCode());
        
        Assert.assertEquals(viewObject.getNotConvertibleObjectList().get(0).getId(), entity.getNotConvertibleObjectList().get(0).getId());
    }
    
    /**
     * Converts two attributes to the same destination / object.
     */
    @Test
    public void convertWithMappedColumnWithHierarchyToSingle(){
        final ClassConvertible01TO viewObject = new ClassConvertible01TO();
        
        final ClassNotConvertible childEntity = new ClassNotConvertible();
        
        childEntity.setId(UUID.randomUUID());
        
        viewObject.setClassNotConvertibleMapped(childEntity);
        
        final ClassConvertible01 entity = pojoConverter.convert(ClassConvertible01.class, viewObject);
        
        Assert.assertNotNull(entity);
        
        Assert.assertEquals(entity.getClassNotConvertibleId(), viewObject.getClassNotConvertibleMapped().getId());
    }
    
    /**
     * Converts an internal object by sending it to two different destinations.
     */
    @Test
    public void convertWithMappedColumnWithSingleToHierarchy(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        entity.setClassNotConvertibleId(UUID.randomUUID());
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertEquals(viewObject.getClassNotConvertibleMapped().getId(), entity.getClassNotConvertibleId());
    }
    
    /**
     * Sends an object to two different destinations without converting.
     */
    @Test
    public void convertWithMappedColumnWithHierarchyToNotConvertibleObject(){
        final ClassConvertible01TO viewObject = new ClassConvertible01TO();
        
        final ClassConvertible02TO childEntity = new ClassConvertible02TO();
        
        final ClassNotConvertible classNotConvertible = new ClassNotConvertible();
        
        classNotConvertible.setId(UUID.randomUUID());
        
        childEntity.setClassNotConvertible(classNotConvertible);
        
        viewObject.setHierarchyToNotConvertible(childEntity);
        
        final ClassConvertible01 entity = pojoConverter.convert(ClassConvertible01.class, viewObject);
        
        Assert.assertNotNull(entity);
        
        Assert.assertNotNull(entity.getNotConvertibleToHierarchy());
        
        Assert.assertEquals(entity.getNotConvertibleToHierarchy().getId(), viewObject.getHierarchyToNotConvertible().getClassNotConvertible().getId());
    }
    
    /**
     * Sends two attributes to a single destination without performing conversion.
     */
    @Test
    public void convertWithMappedColumnWithNotConvertibleObjectToHierarchy(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassNotConvertible classNotConvertible = new ClassNotConvertible();
        
        classNotConvertible.setId(UUID.randomUUID());
        
        entity.setNotConvertibleToHierarchy(classNotConvertible);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getHierarchyToNotConvertible());
        
        Assert.assertNotNull(viewObject.getHierarchyToNotConvertible().getClassNotConvertible());
        
        Assert.assertEquals(viewObject.getHierarchyToNotConvertible().getClassNotConvertible().getId(), entity.getNotConvertibleToHierarchy().getId());
    }
    
    /**
     * Converts by moving an object from within an internal object, sending it to a different structure.
     */
    @Test
    public void convertWithMappedColumnWithHierarchyToConvertibleObject(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassConvertible02 childEntity = new ClassConvertible02();
        
        final ClassConvertible03 classConvertible = new ClassConvertible03();
        
        classConvertible.setId(UUID.randomUUID());
        
        childEntity.setClassConvertible(classConvertible);
        
        entity.setHierarchyToConvertible(childEntity);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getConvertibleToHierarchy());
        
        Assert.assertEquals(viewObject.getConvertibleToHierarchy().getId(), entity.getHierarchyToConvertible().getClassConvertible().getId());

    }
    
    /**
     * Converts by moving an object from within an internal object, sending it to a different structure.
     */
    @Test
    public void convertWithMappedColumnWithConvertibleObjectToHierarchy(){
        final ClassConvertible01TO entity = new ClassConvertible01TO();
        
        final ClassConvertible03TO classConvertible = new ClassConvertible03TO();
        
        classConvertible.setId(UUID.randomUUID());
        
        entity.setConvertibleToHierarchy(classConvertible);
        
        final ClassConvertible01 viewObject = pojoConverter.convert(ClassConvertible01.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getHierarchyToConvertible());
        
        Assert.assertNotNull(viewObject.getHierarchyToConvertible().getClassConvertible());
        
        Assert.assertEquals(viewObject.getHierarchyToConvertible().getClassConvertible().getId(), entity.getConvertibleToHierarchy().getId());
    }
    
    /**
     * Tests merging attributes.
     */
    @Test
    public void convertTwoSourceValuesToOneTarget(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        entity.setIdMappedIntoConvertible(UUID.randomUUID());
        
        entity.setLongMappedIntoConvertible(1L);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getMappedToTwoTargets());
        
        Assert.assertEquals(viewObject.getMappedToTwoTargets().getId(), entity.getIdMappedIntoConvertible());
        
        Assert.assertEquals(viewObject.getMappedToTwoTargets().getLongObject(), entity.getLongMappedIntoConvertible());
    }
    
    /**
     * Tests dividing attributes.
     */
    @Test
    public void convertOneSourceValueToTwoTargets(){
        final ClassConvertible01TO viewObject = new ClassConvertible01TO();
        
        final ClassConvertible02TO child = new ClassConvertible02TO();
        
        child.setId(UUID.randomUUID());
        
        child.setLongObject(1L);
        
        viewObject.setMappedToTwoTargets(child);
        
        final ClassConvertible01 entity = pojoConverter.convert(ClassConvertible01.class, viewObject);
        
        Assert.assertNotNull(entity);
        
        Assert.assertEquals(entity.getIdMappedIntoConvertible(), viewObject.getMappedToTwoTargets().getId());
        
        Assert.assertEquals(entity.getLongMappedIntoConvertible(), viewObject.getMappedToTwoTargets().getLongObject());
    }
    
    /**
     * Tests ignoring attributes.
     */
    @Test
    public void ignoreFields(){
        final ClassConvertible01TO viewObject = new ClassConvertible01TO();
        
        final ClassConvertible02TO child = new ClassConvertible02TO();
        
        child.setId(UUID.randomUUID());
        
        child.setLongObject(1L);
        
        viewObject.setIgnoredField(child);
        
        final ClassConvertible01 entity = pojoConverter.convert(ClassConvertible01.class, viewObject);
        
        Assert.assertNotNull(entity);
        
        Assert.assertNull(entity.getIgnoredField());
    }
    
    /**
     * Sends primitive attributes by mapping.
     */
    @Test
    public void convertPrimitiveMappedFields(){
        final ClassConvertible01TO viewObject = new ClassConvertible01TO();
        
        viewObject.setPrimitiveNumberFromTO(1);
        
        final ClassConvertible01 entity = pojoConverter.convert(ClassConvertible01.class, viewObject);
        
        Assert.assertNotNull(entity);
        
        Assert.assertEquals(entity.getPrimitiveNumberFromEntity(), viewObject.getPrimitiveNumberFromTO());
    }
    
    /**
     * Converts a whole list.
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void convertList(){
        final ClassConvertible01 entity = new ClassConvertible01(0L);
        
        final List<ClassConvertible01> entityList = new ArrayList<ClassConvertible01>();
        
        entityList.add(entity);
        
        final List<ClassConvertible01TO> viewObjectList = (List) pojoConverter.convertList(ClassConvertible01TO.class, entityList);
        
        Assert.assertNotNull(viewObjectList);
        
        assertThat(viewObjectList, not(IsEmptyCollection.emptyCollectionOf(ClassConvertible01TO.class)));
        
        final Long longValueFromEntity = (Long) FieldReflectionHelper.fromInstance(entity).getFieldValue("longObject");
        
        final Long viewObjLongValue = (Long) FieldReflectionHelper.fromInstance(viewObjectList.get(0)).getFieldValue("longObject");
        
        Assert.assertEquals(viewObjLongValue, longValueFromEntity);
    }
    
    /**
     * Converts an entire paginated list.
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void convertPagedListWithANonEncapsulatedField(){
        final ClassConvertible01 entity = new ClassConvertible01(0L);
        
        final List<ClassConvertible01> entityList = new ArrayList<ClassConvertible01>();
        
        entityList.add(entity);
        
        final PagedList<ClassConvertible01> pagedList = new PagedList<>(entityList, 1);
        
        final PagedList newPagedList = pojoConverter.convertPagedList(ClassConvertible01TO.class, pagedList);
        
        final PagedList<ClassConvertible01TO> viewObjectList = newPagedList;
        
        Assert.assertNotNull(viewObjectList);
        
        assertThat(viewObjectList.getItems(), not(IsEmptyCollection.emptyCollectionOf(ClassConvertible01TO.class)));
        
        final Long longValueFromEntity = (Long) FieldReflectionHelper.fromInstance(viewObjectList.getItems().get(0)).getFieldValue("longObject");
        
        assertEquals(longValueFromEntity, longValueFromEntity);
    }
    
    /**
     * Converts by filters.
     */
    @Test
    public void convertWithFilteredField(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassConvertible02 child = new ClassConvertible02();
        
        child.setId(UUID.randomUUID());
        
        child.setLongObject(1L);
        
        child.setPrimitiveNumber(1);
        
        entity.setFilteredField(child);
        
        final ClassConvertible01TO converted = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(converted);
        
        Assert.assertNotNull(converted.getFilteredField());
        
        Assert.assertNull(converted.getFilteredField().getId());
        
        Assert.assertNotNull(converted.getFilteredField().getLongObject());
        
        Assert.assertEquals(converted.getFilteredField().getLongObject(), child.getLongObject());
        
        Assert.assertEquals(converted.getFilteredField().getPrimitiveNumber(), child.getPrimitiveNumber());
    }
    
    /**
     * Converts an internal list by filters.
     */
    @Test
    public void convertWithFilteredList(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassConvertible02 child = new ClassConvertible02();
        
        final ClassConvertible02 child2 = new ClassConvertible02();
        
        child.setId(UUID.randomUUID());
        
        child.setLongObject(1L);
        
        child.setPrimitiveNumber(1);
        
        child2.setId(UUID.randomUUID());
        
        child2.setLongObject(2L);
        
        child2.setPrimitiveNumber(2);
        
        final List<ClassConvertible02> list = new ArrayList<>();
        
        list.add(child);
        
        list.add(child2);
        
        entity.setFilteredList(list);
        
        final ClassConvertible01TO converted = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(converted);
        
        Assert.assertNotNull(converted.getFilteredList());
        
        Assert.assertNotNull(converted.getFilteredList().get(0));
        
        Assert.assertNull(converted.getFilteredList().get(0).getId());
        
        Assert.assertNotNull(converted.getFilteredList().get(0).getLongObject());
        
        Assert.assertEquals(converted.getFilteredList().get(0).getLongObject(), child.getLongObject());
        
        Assert.assertEquals(converted.getFilteredList().get(0).getPrimitiveNumber(), child.getPrimitiveNumber());
        
        Assert.assertNotNull(converted.getFilteredList().get(1));
        
        Assert.assertNull(converted.getFilteredList().get(1).getId());
        
        Assert.assertNotNull(converted.getFilteredList().get(1).getLongObject());
        
        Assert.assertEquals(converted.getFilteredList().get(1).getLongObject(), child2.getLongObject());
        
        Assert.assertEquals(converted.getFilteredList().get(1).getPrimitiveNumber(), child2.getPrimitiveNumber());
    }
    
    /**
     * Converts ignoring specific attributes of an internal attribute.
     */
    @Test
    public void convertWithIgnoredSubField(){
        final ClassConvertible01 entity = new ClassConvertible01();
        
        final ClassConvertible02 childEntity = new ClassConvertible02();
        
        childEntity.setId(UUID.randomUUID());
        
        childEntity.setLongObject(1L);
        
        entity.setConvertibleObject(childEntity);
        
        final ClassConvertible01TO viewObject = pojoConverter.convert(ClassConvertible01TO.class, entity);
        
        Assert.assertNotNull(viewObject);
        
        Assert.assertNotNull(viewObject.getConvertibleObject());
        
        Assert.assertNotEquals(viewObject.getConvertibleObject().getClass().hashCode(), entity.getConvertibleObject().getClass().hashCode());
        
        Assert.assertNull(viewObject.getConvertibleObject().getLongObject());
        
        Assert.assertEquals(viewObject.getConvertibleObject().getId(), entity.getConvertibleObject().getId());
    }
    
    /**
     * Converts with back referenced field with type different.
     */
    @Test
    public void convertWithBackReferenceWithTypeDifferent() {
        final BackReferenceParentPojoDTO parentDTO = new BackReferenceParentPojoDTO();
        
        parentDTO.setId(UUID.randomUUID());
        
        final BackReferenceChildPojoDTO childDTO = new BackReferenceChildPojoDTO();
        
        parentDTO.setChild(childDTO);
        
        final BackReferenceParentPojo parent = pojoConverter.convert(BackReferenceParentPojo.class, parentDTO);
        
        Assert.assertNotNull(parent);
        
        Assert.assertNotNull(parent.getChild());
        
        Assert.assertNotNull(parent.getChild().getParent());
        
        Assert.assertEquals(parent, parent.getChild().getParent());
    }
    
    /**
     * Must perform the setting and the getting directly by field in reflection.
     */
    @Test
    public void convertRestrictedClass() {
        final Class<?> dtoClass = ClassReflectionHelper.forName("com.ws.commons.pojoconverter.artifacts.RestrictedClassDTO");
        
        final Object restrictedDTO = ClassReflectionHelper.newInstanceFromClass(dtoClass);
        
        final String fieldName = "anyString";
        
        final Field field = FieldReflectionHelper.fromClass(dtoClass).getField(fieldName);
        
        final String value = "Test OK";
        
        FieldReflectionHelper.fromInstance(restrictedDTO).setFieldValue(field, value);
        
        final Class<?> entityClass = ClassReflectionHelper.forName("com.ws.commons.pojoconverter.artifacts.RestrictedClassDTO");
        
        /*
         * Mocking methods declared on non-public parent classes is not supported.
         * */
        
        final Object restrictedEntity = pojoConverter.convert(entityClass, restrictedDTO);
        
        Assert.assertNotNull(restrictedEntity);
        
        Assert.assertEquals(value, FieldReflectionHelper.fromInstance(restrictedEntity).getFieldValue(fieldName));
    }
    
    /**
     * Converts with back referenced field collection with type different.
     */
    @Test
    public void convertWithBackReferenceWithList() {
        final BackReferenceParentPojoDTO parentDTO = new BackReferenceParentPojoDTO();
        
        parentDTO.setId(UUID.randomUUID());
        
        final BackReferenceChildPojoDTO childDTO = new BackReferenceChildPojoDTO();
        
        parentDTO.setChilds(Arrays.asList(childDTO));
        
        final BackReferenceParentPojo parent = pojoConverter.convert(BackReferenceParentPojo.class, parentDTO, "id", "childs");
        
        Assert.assertNotNull(parent);
        
        Assert.assertNotNull(parent.getChilds());
        
        assertThat(parent.getChilds(), hasSize(1));
        
        Assert.assertNotNull(parent.getChilds().get(0).getParent());
        
        Assert.assertEquals(parent, parent.getChilds().get(0).getParent());
    }
    
    /**
     * Must do a conversion with null page attributes.
     */
    @Test
    public void convertPagedListWithNullPaginationSettings() {
        final ClassConvertible01 bean = new ClassConvertible01();
        
        final UUID randomUUID = UUID.randomUUID();
        
        bean.setId(randomUUID);
        
        final List<ClassConvertible01> beans = Arrays.asList(bean);
        
        final Integer count = null;
        
        final Integer page = null;
        
        final int pageSize = 0;
        
        final PagedList<ClassConvertible01> pagedList = new PagedList<>(beans, count, page, pageSize);
        
        final PagedList<ClassConvertible01TO> convertedPagedList = this.pojoConverter.convertPagedList(ClassConvertible01TO.class, pagedList);
        
        Assert.assertNotNull(convertedPagedList);
        
        assertThat(convertedPagedList, hasProperty("items", hasSize(1)));
        
        assertThat(convertedPagedList, hasProperty("items", hasItem(hasProperty("id", equalTo(randomUUID)))));
        
        assertThat(convertedPagedList, hasProperty("count", equalTo(count)));
        
        assertThat(convertedPagedList, hasProperty("page", equalTo(page)));
        
        assertThat(convertedPagedList, hasProperty("pageSize", equalTo(pageSize)));
    }

    /**
     * Test case for a conversion to a abstract class by using custom instance provider.
     *
     * @author  Lucas Dillmann
     * @since   7.3.0 - 2018-09-11
     */
    @Test
    public void shouldBeAbleToConvertToAbstractClassUsingCustomProvider() {
        // scenario
        final AbstractClassTO sourceDto = new AbstractClassTO();
        final String expectedStringValue = "TestString123";
        sourceDto.setTestString(expectedStringValue);

        // execution
        final AbstractClassWithCustomInstanceProvider convertedClass = new PojoConverter()
                .convert(AbstractClassWithCustomInstanceProvider.class, sourceDto);

        // validation
        assertNotNull(convertedClass);
        assertThat(convertedClass.getTestString(), is(expectedStringValue));
    }

    /**
     * Converts entity with two columns mapped.
     */
    @Test
    public void convertWithTwoColumnsMapped() {
        final ClassConvertible02 entity = new ClassConvertible02();
        entity.setId(UUID.randomUUID());
        entity.setAvailableBigDecimal(BigDecimal.TEN);

        final ClassConvertible02TO dto = new PojoConverter().convert(ClassConvertible02TO.class, entity);
        assertEquals(entity.getId(), dto.getId());
        assertEquals(entity.getAvailableBigDecimal(), dto.getAvailableBigDecimal());
        assertEquals(entity.getAvailableBigDecimal(), dto.getRemainingBigDecimal());
    }

    @Test
    public void whenFieldIsNullAndSetToConvertNullsItShouldCallSetMethodOnTarget() throws Exception {
        // scenario
        final NullFieldConversion source = new NullFieldConversion();

        // execution
        final NullFieldConversionTO target = new PojoConverter().convert(NullFieldConversionTO.class, source);

        // validation
        assertNotNull(target);
        assertNull(target.getConvertibleField());
        assertTrue(target.isConvertibleFieldChanged());
    }

    @Test
    public void whenFieldIsNullAndSetNotToConvertNullsItShouldNotCallSetMethodOnTarget() {
        // scenario
        final NullFieldConversion source = new NullFieldConversion();

        // execution
        final NullFieldConversionTO target = new PojoConverter().convert(NullFieldConversionTO.class, source);

        // validation
        assertNotNull(target);
        assertNull(target.getNotConvertibleField());
        assertFalse(target.isNotConvertibleFieldChanged());
    }
}
