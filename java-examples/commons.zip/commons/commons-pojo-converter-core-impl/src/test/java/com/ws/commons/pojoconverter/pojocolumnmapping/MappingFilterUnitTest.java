package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.pojocolumnmapping.artifact.Customer;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.lang.reflect.Field;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

/**
 * Unit test cases for {@link MappingFilter}.
 * 
 * @author  Diego Armange Costa
 * @since   5.1.0 2017-10-05
 */
public class MappingFilterUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Tries to get mapping annotations from field {@code serviceId} of {@link Customer} class.
     * It must return one annotation.
     * 
     * @throws NoSuchFieldException if field reflection fail
     * @throws SecurityException    if field reflection fail
     */
    @Test
    public void fromField() throws NoSuchFieldException, SecurityException {
        List<PojoColumnMapper> mappingAnnotations = MappingFilter
            .fromField(Customer.class.getDeclaredField("serviceId"))
            .getMappingAnnotations();
        
        assertThat(mappingAnnotations, hasSize(1));
    }
    
    /**
     * Tries to instantiate a {@link MappingFilter} from a {@code null} field.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void fromNullField() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("field"));
        
        MappingFilter.fromField(null);
    }
    
    /**
     * Tries to retrieve mapping annotations from field {@code location} of {@link Customer} class.
     * It must return one annotation.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException if field reflection fail.
     */
    @Test
    public void fromTarget() throws NoSuchFieldException, SecurityException {
        List<PojoColumnMapper> mappingAnnotations = MappingFilter
            .fromField(Customer.class.getDeclaredField("location"))
            .fromTarget("locationDescription")
            .getMappingAnnotations();
        
        assertThat(mappingAnnotations, hasSize(1));
    }
    
    /**
     * Tries to retrieve {@link MappingFilter} from {@code null} target.
     * It must throw an {@link IllegalArgumentException}.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromNullTarget() throws NoSuchFieldException, SecurityException {
        thrown.expect(IllegalArgumentException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("target"));
        
        MappingFilter
            .fromField(Customer.class.getDeclaredField("serviceId"))
            .fromTarget(null);
    }
    
    /**
     * Tries to retrieve mapping annotations from field {@code location} of {@link Customer} class.
     * It must return one annotation.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromSource() throws NoSuchFieldException, SecurityException {
        List<PojoColumnMapper> mappingAnnotations = MappingFilter
            .fromField(Customer.class.getDeclaredField("location"))
            .fromSource("location.description")
            .getMappingAnnotations();
        
        assertThat(mappingAnnotations, hasSize(1));
    }
    
    /**
     * Tries to retrieve a {@link MappingFilter} from {@code null} source.
     * Expects to throw an {@link IllegalArgumentException}.
     *
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromNullSource() throws NoSuchFieldException, SecurityException {
        thrown.expect(IllegalArgumentException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("source"));
        
        MappingFilter
            .fromField(Customer.class.getDeclaredField("serviceId"))
            .fromSource(null);
    }
    
    /**
     * Tries to retrieve mapping annotations from a field with empty mapping.
     * It must return a list without annotation.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromSourceWithEmptyMapping() throws NoSuchFieldException, SecurityException {
        List<PojoColumnMapper> mappingAnnotations = MappingFilter
            .fromField(Customer.class.getDeclaredField("name"))
            .fromSource("name")
            .getMappingAnnotations();
        
        assertThat(mappingAnnotations, hasSize(0));
    }
    
    /**
     * Tries to retrieve mapping annotations from a misspelled source.
     * It must return a list without annotation.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromSourceNoEquals() throws NoSuchFieldException, SecurityException {
        List<PojoColumnMapper> mappingAnnotations = MappingFilter
            .fromField(Customer.class.getDeclaredField("location"))
            .fromSource("locations")
            .getMappingAnnotations();
        
        assertThat(mappingAnnotations, hasSize(0));
    }
    
    /**
     * Tries to retrieve {@link MappingFilter} information fom source without getting mapping annotations.
     * It must return a list without annotation and must return the informed field when call getField method.
     * 
     * @throws NoSuchFieldException if field reflection fail.
     * @throws SecurityException    if field reflection fail.
     */
    @Test
    public void fromSourceNoMapping() throws NoSuchFieldException, SecurityException {
        final Field declaredField = FieldReflectionHelper.fromClass(Customer.class).getField("id");
        
        MappingFilter fromSource = MappingFilter
            .fromField(declaredField)
            .fromSource("locations");
        
        assertThat(fromSource.getMappingAnnotations(), hasSize(0));
        
        assertEquals(declaredField, fromSource.getField());
    }
}
