package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;

import java.util.List;
import java.util.UUID;

/**
 * DTO artifact used only to execute conversion tests.
 * 
 * @author  Diego A. Costa
 * @since   5.0.0 - 2017-06-08
 */
@SuppressWarnings("javadoc")
public class ClassConvertible01TO implements DefaultPojoConverter {
    private UUID id;
    
    private Long longObject;
    
    private int primitiveNumber;
    
    private ClassConvertible02TO convertibleObject;
    
    private List<Long> longObjectList;
    
    private List<ClassConvertible02TO> convertibleObjectList;
    
    private List<ClassNotConvertible> notConvertibleObjectList;
    
    @PojoColumnMapper(source="classNotConvertibleMapped.id", target="classNotConvertibleId")
    private ClassNotConvertible classNotConvertibleMapped;
    
    private ClassNotConvertible classNotConvertible;
    
    @PojoColumnMapper(source="hierarchyToNotConvertible.classNotConvertible", target="notConvertibleToHierarchy")
    private ClassConvertible02TO hierarchyToNotConvertible;
    
    @PojoColumnMapper(source="convertibleToHierarchy", target="hierarchyToConvertible.classConvertible")
    private ClassConvertible03TO convertibleToHierarchy;
    
    @PojoColumnsMapper({
        @PojoColumnMapper(source="mappedToTwoTargets.id", target="idMappedIntoConvertible"),
        @PojoColumnMapper(source="mappedToTwoTargets.longObject", target="longMappedIntoConvertible")})
    private ClassConvertible02TO mappedToTwoTargets;
    
    @PojoColumnIgnore()
    private ClassConvertible02TO ignoredField;
    
    @PojoColumnMapper(source="primitiveNumberFromTO", target="primitiveNumberFromEntity")
    private int primitiveNumberFromTO;
    
    private ClassConvertible02TO filteredField;
    
    private List<ClassConvertible02TO> filteredList;
    
    public ClassConvertible01TO() {}
    
    public ClassConvertible01TO(final Long longObject) {
        this.longObject = longObject;
    }
    
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public int getPrimitiveNumber() {
        return primitiveNumber;
    }

    public void setPrimitiveNumber(int primitiveNumber) {
        this.primitiveNumber = primitiveNumber;
    }

    public ClassConvertible02TO getConvertibleObject() {
        return convertibleObject;
    }

    public void setConvertibleObject(ClassConvertible02TO convertibleObject) {
        this.convertibleObject = convertibleObject;
    }

    public List<Long> getLongObjectList() {
        return longObjectList;
    }

    public void setLongObjectList(List<Long> longObjectList) {
        this.longObjectList = longObjectList;
    }

    public List<ClassConvertible02TO> getConvertibleObjectList() {
        return convertibleObjectList;
    }

    public void setConvertibleObjectList(List<ClassConvertible02TO> convertibleObjectList) {
        this.convertibleObjectList = convertibleObjectList;
    }

    public List<ClassNotConvertible> getNotConvertibleObjectList() {
        return notConvertibleObjectList;
    }

    public void setNotConvertibleObjectList(List<ClassNotConvertible> notConvertibleObjectList) {
        this.notConvertibleObjectList = notConvertibleObjectList;
    }

    public ClassNotConvertible getClassNotConvertibleMapped() {
        return classNotConvertibleMapped;
    }

    public void setClassNotConvertibleMapped(ClassNotConvertible classNotConvertibleMapped) {
        this.classNotConvertibleMapped = classNotConvertibleMapped;
    }

    public ClassNotConvertible getClassNotConvertible() {
        return classNotConvertible;
    }

    public void setClassNotConvertible(ClassNotConvertible classNotConvertible) {
        this.classNotConvertible = classNotConvertible;
    }

    public ClassConvertible02TO getHierarchyToNotConvertible() {
        return hierarchyToNotConvertible;
    }

    public void setHierarchyToNotConvertible(ClassConvertible02TO hierarchyToNotConvertible) {
        this.hierarchyToNotConvertible = hierarchyToNotConvertible;
    }

    public ClassConvertible03TO getConvertibleToHierarchy() {
        return convertibleToHierarchy;
    }

    public void setConvertibleToHierarchy(ClassConvertible03TO convertibleTohierarchy) {
        this.convertibleToHierarchy = convertibleTohierarchy;
    }

    public ClassConvertible02TO getMappedToTwoTargets() {
        return mappedToTwoTargets;
    }

    public void setMappedToTwoTargets(ClassConvertible02TO mappedToTwoTargets) {
        this.mappedToTwoTargets = mappedToTwoTargets;
    }

    public ClassConvertible02TO getIgnoredField() {
        return ignoredField;
    }

    public void setIgnoredField(ClassConvertible02TO ignoredField) {
        this.ignoredField = ignoredField;
    }

    public int getPrimitiveNumberFromTO() {
        return primitiveNumberFromTO;
    }

    public void setPrimitiveNumberFromTO(int primitiveNumberFromTO) {
        this.primitiveNumberFromTO = primitiveNumberFromTO;
    }

    public ClassConvertible02TO getFilteredField() {
        return filteredField;
    }

    public void setFilteredField(ClassConvertible02TO filteredField) {
        this.filteredField = filteredField;
    }

    public List<ClassConvertible02TO> getFilteredList() {
        return filteredList;
    }

    public void setFilteredList(List<ClassConvertible02TO> filteredList) {
        this.filteredList = filteredList;
    }

    public Long getLongObject() {
        return longObject;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ClassConvertible01TO other = (ClassConvertible01TO) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
