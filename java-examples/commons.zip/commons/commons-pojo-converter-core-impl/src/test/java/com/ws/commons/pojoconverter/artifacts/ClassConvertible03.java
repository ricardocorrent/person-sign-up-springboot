package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.util.UUID;

/**
 * Test artifact used only to execute conversion tests.
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-06-08
 */
public class ClassConvertible03 implements IPojoConverter {

    private UUID id;

    @SuppressWarnings("javadoc")
    public UUID getId() {
        return id;
    }

    @SuppressWarnings("javadoc")
    public void setId(UUID id) {
        this.id = id;
    }
}
