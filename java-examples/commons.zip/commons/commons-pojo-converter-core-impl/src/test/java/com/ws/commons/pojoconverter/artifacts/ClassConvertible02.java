package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

/**
 * Test artifact used only to execute conversion tests.
 * 
 * @author Diego A. Costa 
 * @since 5.0.0 2017-06-08
 */
public class ClassConvertible02 implements IPojoConverter{

    private UUID id;
    
    private Long longObject;
    
    private int primitiveNumber;
    
    private List<Long> longObjectList;
    
    @PojoColumnMapper(source="classNotConvertibleId", target="classNotConvertible.id")
    private UUID classNotConvertibleId;
    
    @PojoColumnMapper(source="classNotConvertibleMapped.id", target="classNotConvertibleMappedId")
    private ClassNotConvertible classNotConvertibleMapped;
    
    private ClassNotConvertible classNotConvertible;
    
    private ClassConvertible03 classConvertible;

    @PojoColumnsMapper({
        @PojoColumnMapper(target = "availableBigDecimal", source = "availableBigDecimal"),
        @PojoColumnMapper(target = "remainingBigDecimal", source = "availableBigDecimal")
    })
    private BigDecimal availableBigDecimal;

    @SuppressWarnings("javadoc")
    public UUID getId() {
        return id;
    }

    @SuppressWarnings("javadoc")
    public void setId(UUID id) {
        this.id = id;
    }

    @SuppressWarnings("javadoc")
    public Long getLongObject() {
        return longObject;
    }

    @SuppressWarnings("javadoc")
    public void setLongObject(Long longObject) {
        this.longObject = longObject;
    }

    @SuppressWarnings("javadoc")
    public int getPrimitiveNumber() {
        return primitiveNumber;
    }

    @SuppressWarnings("javadoc")
    public void setPrimitiveNumber(int primitiveNumber) {
        this.primitiveNumber = primitiveNumber;
    }

    @SuppressWarnings("javadoc")
    public List<Long> getLongObjectList() {
        return longObjectList;
    }

    @SuppressWarnings("javadoc")
    public void setLongObjectList(List<Long> longObjectList) {
        this.longObjectList = longObjectList;
    }

    @SuppressWarnings("javadoc")
    public UUID getClassNotConvertibleId() {
        return classNotConvertibleId;
    }

    @SuppressWarnings("javadoc")
    public void setClassNotConvertibleId(UUID classNotConvertibleId) {
        this.classNotConvertibleId = classNotConvertibleId;
    }

    @SuppressWarnings("javadoc")
    public ClassNotConvertible getClassNotConvertibleMapped() {
        return classNotConvertibleMapped;
    }

    @SuppressWarnings("javadoc")
    public void setClassNotConvertibleMapped(ClassNotConvertible classNotConvertibleMapped) {
        this.classNotConvertibleMapped = classNotConvertibleMapped;
    }

    @SuppressWarnings("javadoc")
    public ClassNotConvertible getClassNotConvertible() {
        return classNotConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setClassNotConvertible(ClassNotConvertible classNotConvertible) {
        this.classNotConvertible = classNotConvertible;
    }

    @SuppressWarnings("javadoc")
    public ClassConvertible03 getClassConvertible() {
        return classConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setClassConvertible(ClassConvertible03 classConvertible) {
        this.classConvertible = classConvertible;
    }

    @SuppressWarnings("javadoc")
    public BigDecimal getAvailableBigDecimal() {
        return availableBigDecimal;
    }

    @SuppressWarnings("javadoc")
    public void setAvailableBigDecimal(BigDecimal availableBigDecimal) {
        this.availableBigDecimal = availableBigDecimal;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ClassConvertible02 other = (ClassConvertible02) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
    
}
