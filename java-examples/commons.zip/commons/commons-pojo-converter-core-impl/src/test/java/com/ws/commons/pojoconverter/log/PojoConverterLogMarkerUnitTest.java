package com.ws.commons.pojoconverter.log;

import org.junit.Test;
import org.slf4j.Marker;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 * Test cases for {@link PojoConverterLogMarker}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class PojoConverterLogMarkerUnitTest {

    /**
     * Test case for {@link PojoConverterLogMarker#build()}.
     */
    @Test
    public void shouldReturnAValidMarkerInstance() {
        // scenario
        final String expectedMarkerValue = "POJO-CONVERTER";

        // execution
        final Marker marker = PojoConverterLogMarker.build();

        // validation
        assertNotNull(marker);
        assertNotNull(marker.getName());
        assertThat(marker.getName(), is(expectedMarkerValue));
    }
}
