package com.ws.commons.pojoconverter.artifacts.provider;

import com.ws.commons.pojoconverter.artifacts.AbstractClassWithCustomInstanceProvider;
import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;

/**
 * Test artifact for {@link AbstractClassWithCustomInstanceProvider}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class AbstractClassPojoConverterInstanceProvider
    implements PojoConverterInstanceProvider<AbstractClassWithCustomInstanceProvider> {

    /**
     * Produces an instance compatible with the given target class.
     *
     * @param targetClass       target class where an instance is needed
     * @param sourceFieldValue  source value being converted for the needed instance, when available
     * @return                  object instance to be used in the target of the conversion
     */
    @Override
    public AbstractClassWithCustomInstanceProvider produce(
            final Class<? extends AbstractClassWithCustomInstanceProvider> targetClass,
            final Object sourceFieldValue
    ) {
        return new AbstractClassWithCustomInstanceProvider() {};
    }
}
