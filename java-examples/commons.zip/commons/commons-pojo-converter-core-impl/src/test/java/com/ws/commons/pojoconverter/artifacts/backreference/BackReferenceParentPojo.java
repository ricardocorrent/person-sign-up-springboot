package com.ws.commons.pojoconverter.artifacts.backreference;

import com.ws.commons.persistence.model.BaseModel;
import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverterTest;
import com.ws.commons.pojoconverter.annotation.PojoColumnBackReference;

import java.io.Serializable;
import java.util.List;

/**
 * Artifact entity that declares a class which contains a child annotated with {@link PojoColumnBackReference}
 * for testing purposes.
 *
 * @author  Diego Armange Costa
 * @see     PojoConverterTest
 * @since   5.0.0 2017-09-06
 */
@SuppressWarnings({ "javadoc", "serial" })
public class BackReferenceParentPojo extends SoftDeleteBaseEntity implements IPojoConverter, Serializable {

    private BackReferenceChildPojo child;
    
    private List<BackReferenceChildPojo> childs;

    public BackReferenceChildPojo getChild() {
        return child;
    }

    public void setChild(BackReferenceChildPojo child) {
        this.child = child;
    }
    
    public List<BackReferenceChildPojo> getChilds() {
        return childs;
    }

    public void setChilds(List<BackReferenceChildPojo> childs) {
        this.childs = childs;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        
        int result = 1;
        
        return prime * result + ((getId() == null) ? 0 : getId().hashCode());
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final BaseModel other = (BaseModel) obj;
        
        if (getId() == null) {
            if (other.getId() != null) {
                return false;
            }
        } else if (!getId().equals(other.getId())) {
            return false;
        }
        
        return true;
    }
}
