package com.ws.commons.pojoconverter.instance;

import com.ws.commons.pojoconverter.artifacts.AbstractClassWithCustomInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.ClassConvertible01;
import com.ws.commons.pojoconverter.artifacts.ClassNotConvertible;
import com.ws.commons.pojoconverter.artifacts.field.TestFields;
import com.ws.commons.pojoconverter.artifacts.provider.AbstractClassPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.provider.ClassNotConvertibleTestPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.provider.DefaultPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;
import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.util.collections.Sets;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import java.lang.reflect.Field;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anySet;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.testng.Assert.assertNull;

/**
 * Test cases for {@link PojoConverterInstanceProviderFactory}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class PojoConverterInstanceProviderFactoryUnitTest {

    private PojoConverterInstanceProviderFactory factory;

    /**
     * Prepares the scenario before every test.
     */
    @Before
    public void setUp() {
        this.factory = new PojoConverterInstanceProviderFactory();
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#defaultProvider()}.
     */
    @Test
    public void shouldReturnADefaultProvider() {
        // execution
        final PojoConverterInstanceProvider provider = factory.defaultProvider();

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(DefaultPojoConverterInstanceProvider.class)));
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromAnnotation(Field)}
     * where the provided field has a {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider}
     * annotation.
     */
    @Test
    public void shouldReturnAProviderFromFieldAnnotationWhenAnnotationIsPresent() throws Exception {
        // scenario
        final Class providerClass = ClassNotConvertibleTestPojoConverterInstanceProvider.class;
        final Field field = TestFields.getClassNotConvertibleFieldWithValidProvider();

        // execution
        final PojoConverterInstanceProvider provider = factory.fromAnnotation(field);

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(providerClass)));
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromAnnotation(Field)}
     * where the provided field has a {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider}
     * annotation.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWhenFieldHasAnnotationWithIncompatibleProvider() throws Exception {
        // scenario
        final Field field = TestFields.getClassNotConvertibleFieldWithInvalidProvider();

        // execution
        factory.fromAnnotation(field);
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromAnnotation(Field)}
     * where the provided field don't has a {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider}
     * annotation.
     */
    @Test
    public void shouldntReturnAProviderFromFieldAnnotationWhenAnnotationIsntPresent() throws Exception {
        // scenario
        final Field field = TestFields.getClassNotConvertibleFieldWithoutProvider();

        // execution
        final PojoConverterInstanceProvider provider = factory.fromAnnotation(field);

        // validation
        assertNull(provider);
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromCdi(Class)} expecting a exception
     * when no CDI is available.
     */
    @Test(expected = IllegalStateException.class)
    public void shouldThrowExceptionWhenCdiIsntAvailable() {
        // scenario
        final Class<?> targetClass = ClassNotConvertible.class;

        // execution
        factory.fromCdi(targetClass);
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromCdi(Class, BeanManager)}
     * for a valid scenario.
     */
    @Test
    public void shouldReturnAValidProviderFromCdi() {
        // scenario
        final BeanManager beanManager = mock(BeanManager.class);
        final Bean bean = mock(Bean.class);
        final Class targetClass = ClassNotConvertible.class;
        final CreationalContext creationalContext = mock(CreationalContext.class);
        final PojoConverterInstanceProvider expectedProvider = mock(PojoConverterInstanceProvider.class);

        doReturn(creationalContext).when(beanManager).createCreationalContext(any());
        doReturn(Sets.newSet(bean)).when(beanManager).getBeans(any());
        doReturn(bean).when(beanManager).resolve(anySet());
        doReturn(expectedProvider).when(bean).create(creationalContext);

        // execution
        final PojoConverterInstanceProvider provider = factory.fromCdi(targetClass, beanManager);

        // validation
        assertNotNull(provider);
        assertThat(provider, is(expectedProvider));
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromAnnotation(Class)}
     * for a valid scenario.
     */
    @Test
    public void shouldReturnAValidProviderFromAnnotatedTargetClass() {
        // scenario
        final Class<?> targetClassWithAnnotation = AbstractClassWithCustomInstanceProvider.class;
        final Class<?> expectedProvider = AbstractClassPojoConverterInstanceProvider.class;

        // execution
        final PojoConverterInstanceProvider provider = factory.fromAnnotation(targetClassWithAnnotation);

        // validation
        assertNotNull(provider);
        assertThat(provider, is(instanceOf(expectedProvider)));
    }

    /**
     * Test case for {@link PojoConverterInstanceProviderFactory#fromAnnotation(Class)}
     * for a invalid scenario.
     */
    @Test
    public void shouldReturnNullFromNotAnnotatedTargetClass() {
        // scenario
        final Class<?> targetClassWithoutAnnotation = ClassConvertible01.class;

        // execution
        final PojoConverterInstanceProvider provider = factory.fromAnnotation(targetClassWithoutAnnotation);

        // validation
        assertNull(provider);
    }

}
