package com.ws.commons.pojoconverter.artifacts.backreference;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverterTest;
import com.ws.commons.pojoconverter.annotation.PojoColumnBackReference;

import java.io.Serializable;

/**
 * Artifact entity that contains a child annotated with {@link PojoColumnBackReference} for testing purposes.
 * 
 * @author  Diego Armange Costa
 * @see     PojoConverterTest
 * @since   5.0.0 2017-09-06
 */
@SuppressWarnings("serial")
public class BackReferenceChildPojo implements IPojoConverter, Serializable {

    @PojoColumnBackReference({"id"})
    private BackReferenceParentPojo parent;

    @SuppressWarnings("javadoc")
    public BackReferenceParentPojo getParent() {
        return parent;
    }

    @SuppressWarnings("javadoc")
    public void setParent(BackReferenceParentPojo parent) {
        this.parent = parent;
    }
}
