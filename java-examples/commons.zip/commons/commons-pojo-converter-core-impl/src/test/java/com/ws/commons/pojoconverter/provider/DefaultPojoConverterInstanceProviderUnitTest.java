package com.ws.commons.pojoconverter.provider;

import com.ws.commons.pojoconverter.artifacts.ClassNotConvertible;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 * Test cases for {@link DefaultPojoConverterInstanceProvider}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class DefaultPojoConverterInstanceProviderUnitTest {

    private PojoConverterInstanceProvider provider;

    /**
     * Prepares the test scenario before every test.
     */
    @Before
    public void setUp() {
        this.provider = new DefaultPojoConverterInstanceProvider();
    }

    /**
     * Test case for {@link DefaultPojoConverterInstanceProvider#produce(Class, Object)}.
     * It should create an instance successfully.
     */
    @Test
    public void shouldCreateAnInstance() {
        // scenario
        final Class<?> targetClass = ClassNotConvertible.class;
        final Object sourceValue = new Object();

        // execution
        final Object producedValue = provider.produce(targetClass, sourceValue);

        // validation
        assertNotNull(producedValue);
        assertThat(producedValue, is(instanceOf(targetClass)));
    }

}
