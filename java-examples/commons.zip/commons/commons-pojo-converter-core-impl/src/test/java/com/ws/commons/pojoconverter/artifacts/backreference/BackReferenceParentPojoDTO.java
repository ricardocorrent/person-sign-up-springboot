package com.ws.commons.pojoconverter.artifacts.backreference;

import com.ws.commons.persistence.dto.BaseDTO;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverterTest;
import com.ws.commons.pojoconverter.annotation.PojoColumnBackReference;

import java.io.Serializable;
import java.util.List;

/**
 * Artifact DTO for {@link BackReferenceParentPojo} that declares a class whick contains a child annotated with
 * {@link PojoColumnBackReference}  for testing purposes.
 *
 * @author  Diego Armange Costa
 * @see     PojoConverterTest
 * @since   5.0.0 2017-09-06
 */
@SuppressWarnings("serial")
public class BackReferenceParentPojoDTO extends BaseDTO implements IPojoConverter, Serializable {

    private BackReferenceChildPojoDTO child;
    
    private List<BackReferenceChildPojoDTO> childs;

    @SuppressWarnings("javadoc")
    public BackReferenceChildPojoDTO getChild() {
        return child;
    }

    @SuppressWarnings("javadoc")
    public void setChild(BackReferenceChildPojoDTO child) {
        this.child = child;
    }

    @SuppressWarnings("javadoc")
    public List<BackReferenceChildPojoDTO> getChilds() {
        return childs;
    }

    @SuppressWarnings("javadoc")
    public void setChilds(List<BackReferenceChildPojoDTO> childs) {
        this.childs = childs;
    }
}
