package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.util.UUID;

/**
 * Test artifact used only to execute conversion tests. This class does not implements {@link IPojoConverter} and it's
 * not convertible.
 * 
 * @author  Diego A. Costa
 * @since   5.0.0 - 2017-06-08
 */
public class ClassNotConvertible {

    private UUID id;

    @SuppressWarnings("javadoc")
    public UUID getId() {
        return id;
    }

    @SuppressWarnings("javadoc")
    public void setId(UUID id) {
        this.id = id;
    }
}
