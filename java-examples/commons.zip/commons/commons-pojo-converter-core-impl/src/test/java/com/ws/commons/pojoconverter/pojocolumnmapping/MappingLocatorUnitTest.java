package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.pojocolumnmapping.artifact.Customer;
import com.ws.commons.pojoconverter.pojocolumnmapping.artifact.Location;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import org.hamcrest.collection.IsMapContaining;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit testing cases for {@link MappingLocator}.
 * 
 * @author  Diego Armange Costa
 * @since   5.1.0 2017-10-05
 */
public class MappingLocatorUnitTest {

    /**
     * Exception test rule configured as {@link ExpectedException#none()}.
     * 
     * @see Rule
     * @see ExpectedException
     */
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    /**
     * Tries to generate locate metadata from {@code null} class.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void locateFromNullClass() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringClass"));
        
        MappingLocator.fromClass(null);
    }
    
    /**
     * Tries to generate locate metadata from {@code null} path.
     * It must throw a {@link NullPointerException}.
     */
    @Test
    public void locateFromNullPath() {
        thrown.expect(NullPointerException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("path"));
        
        MappingLocator.fromClass(Customer.class).withPath(null);
    }
    
    /**
     * Tries to generate locate metadata from an empty path.
     * It must throw an {@link IllegalArgumentException}.
     */
    @Test
    public void locateFromEmptyPath() {
        thrown.expect(IllegalArgumentException.class);
        
        thrown.expectMessage(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("path"));
        
        MappingLocator.fromInstance(new Customer()).withPath("");
    }
    
    /**
     * Tries to generate locate metadata from a valid path without mapping.
     * It must retrieve correctly without mapping.
     */
    @Test
    public void locateFromValidPathWithoutMapping() {
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath("name")
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertFalse(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("name", mappingMetadata.getUnmappedPath());
    }
    
    /**
     * Locates field from and gets mapping metadata by target mapping.
     * It must to locate the field correctly.
     */
    @Test
    public void locateFieldByTargetMapping() {
        final String path = "userId";
        
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath(path)
                .getMappingMetadata();
        
        final Field field = FieldReflectionHelper.fromClass(Customer.class).getField(path);
        
        assertNotNull(mappingMetadata);
        
        assertTrue(mappingMetadata.hasMappingFields());
        
        assertNotNull(mappingMetadata.getMappingFields());
        
        Assert.assertEquals(field, mappingMetadata.getMappingFields().get("user.id"));
    }
    
    /**
     * Tries to generate locate metadata from a valid path with mapping.
     * It must contain mapping on path with mapping.
     */
    @Test
    public void locateFromValidPathWithMapping() {
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath("service.id")
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("serviceId", mappingMetadata.getUnmappedPath());
    }
    
    /**
     * Tries to generate locate metadata from a valid path with sub-mapping.
     * It must contain mapping on path with sub-mapping.
     */
    @Test
    public void locateFromValidPathWithSubMapping() {
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath("anotherLocation.service.id")
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("anotherLocation.serviceId", mappingMetadata.getUnmappedPath());
    }
    
    /**
     * Tries to generate locate metadata from a valid composite path with sub-mapping.
     * It must contain mapping on composite path.
     */
    @Test
    public void locateFromValidCompositePathWithSubMapping() {
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath("mapping.path.location.service.id")
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("location.serviceId", mappingMetadata.getUnmappedPath());
    }
    
    /**
     * Tries to generate mapping metadata from source
     * It must contain the target searching.
     */
    @Test
    public void generateTargetMetadataFromSource() {
        final String sourcePath = "serviceId";
        
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath(sourcePath)
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("service.id", mappingMetadata.getTargetPaths().get(sourcePath));
    }
    
    /**
     * Tries to retrieve source mapping from the target mapping.
     */
    @Test
    public void getSourceMappingFromTargetMapping() {
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withoutPath()
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("serviceId", mappingMetadata.getSourcePaths().get("service.id"));
    }
    
    /**
     * Tries to generate locate metadata from the target.
     * It must contain the source searching.
     */
    @Test
    public void generatedSourceMetadataFromTarget() {
        final String targetPath = "service.id";
        
        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath(targetPath)
                .getMappingMetadata();
        
        assertNotNull(mappingMetadata);
        
        Assert.assertTrue(mappingMetadata.hasMappingFields());
        
        Assert.assertEquals("serviceId", mappingMetadata.getSourcePaths().get(targetPath));
    }
    
    /**
     * Tries to get mapping metadata of two fields from a single path.
     * It must return two fields for the path "user".
     */
    @Test
    public void getTwoFieldsBySinglePath() {
        final String flatNode = "user";

        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Customer())
                .withPath(flatNode)
                .getMappingMetadata();

        assertNotNull(mappingMetadata);
        
        assertTrue(mappingMetadata.hasMappingFields());

        final Map<String, Set<Field>> multipleMapping = mappingMetadata.getMultipleMapping();
        
        assertThat(multipleMapping, IsMapContaining.hasKey(flatNode));
        
        final Set<Field> actual = multipleMapping.get(flatNode);
        
        assertThat(actual, hasSize(2));
        
        assertThat(actual, allOf(
            //java.lang.reflect.Field
            hasItem(hasProperty("name", equalTo("userId"))),
            hasItem(hasProperty("name", equalTo("userName")))
        )); 
    }
    
    /**
     * Tries to get mapping metadata of four fields from a single path.
     * It must return four fields for the path "area".
     */
    @Test
    public void getFourFieldsBySinglePath() {
        final String flatNode = "area";

        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Location())
                .withPath(flatNode)
                .getMappingMetadata();

        assertNotNull(mappingMetadata);
        
        assertTrue(mappingMetadata.hasMappingFields());

        final Map<String, Set<Field>> multipleMapping = mappingMetadata.getMultipleMapping();
        
        assertThat(multipleMapping, IsMapContaining.hasKey(flatNode));
        
        final Set<Field> actual = multipleMapping.get(flatNode);
        
        assertThat(actual, hasSize(4));
        
        assertThat(actual, allOf(
            //java.lang.reflect.Field
            hasItem(hasProperty("name", equalTo("areaId"))),
            hasItem(hasProperty("name", equalTo("areaDescription"))),
            hasItem(hasProperty("name", equalTo("areaServiceId"))),
            hasItem(hasProperty("name", equalTo("areaServiceDescription")))
        )); 
    }
    
    /**
     * Tries to get mapping metadata of two fields from two path parts.
     * It must return two fields for the path "area.service".
     */
    @Test
    public void getTwoFieldsByTwoPathParts() {
        final String flatNode = "area.service";

        MappingMetaData mappingMetadata = MappingLocator
                .fromInstance(new Location())
                .withPath(flatNode)
                .getMappingMetadata();

        assertNotNull(mappingMetadata);
        
        assertTrue(mappingMetadata.hasMappingFields());

        final Map<String, Set<Field>> multipleMapping = mappingMetadata.getMultipleMapping();
        
        assertThat(multipleMapping, IsMapContaining.hasKey(flatNode));
        
        final Set<Field> actual = multipleMapping.get(flatNode);
        
        assertThat(actual, hasSize(2));
        
        assertThat(actual, allOf(
            //java.lang.reflect.Field
            hasItem(hasProperty("name", equalTo("areaServiceId"))),
            hasItem(hasProperty("name", equalTo("areaServiceDescription")))
        )); 
    }
}
