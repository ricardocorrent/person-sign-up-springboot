package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.DefaultPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

import java.util.List;
import java.util.UUID;

/**
 * Test artifact used only to execute conversion tests.
 * 
 * @author  Diego A. Costa
 * @since   5.0.0 - 2017-06-08
 */
public class ClassConvertible01 implements DefaultPojoConverter {
    private UUID id;
    
    @SuppressWarnings("unused")
    private Long longObject;
    
    private int primitiveNumber;
    
    @PojoColumnIgnore(fields = {"longObject"})
    private ClassConvertible02 convertibleObject;
    
    private List<Long> longObjectList;
    
    private List<ClassConvertible02> convertibleObjectList;
    
    private List<ClassNotConvertible> notConvertibleObjectList;
    
    //TODO Criar teste oposto a este cenario. 
    @PojoColumnMapper(source="classNotConvertibleId", target="classNotConvertibleMapped.id")
    private UUID classNotConvertibleId;
    
    private ClassNotConvertible classNotConvertible;
    
    @PojoColumnMapper(source="notConvertibleToHierarchy", target="hierarchyToNotConvertible.classNotConvertible")
    private ClassNotConvertible notConvertibleToHierarchy;
    
    @PojoColumnMapper(source="hierarchyToConvertible.classConvertible", target="convertibleToHierarchy")
    private ClassConvertible02 hierarchyToConvertible;
    
    @PojoColumnMapper(source="idMappedIntoConvertible", target="mappedToTwoTargets.id")
    private UUID idMappedIntoConvertible;
    
    @PojoColumnMapper(source="longMappedIntoConvertible", target="mappedToTwoTargets.longObject")
    private Long longMappedIntoConvertible;
    
    private ClassConvertible02TO ignoredField;
    
    private int primitiveNumberFromEntity;
    
    @PojoColumnFilter({"longObject", "primitiveNumber"})
    private ClassConvertible02 filteredField;
    
    @PojoColumnFilter({"longObject", "primitiveNumber"})
    private List<ClassConvertible02> filteredList;
    
    @SuppressWarnings("javadoc")
    public ClassConvertible01() {}
    
    @SuppressWarnings("javadoc")
    public ClassConvertible01(final Long longObject) {
        this.longObject = longObject;
    }
    
    @SuppressWarnings("javadoc")
    public UUID getId() {
        return id;
    }

    @SuppressWarnings("javadoc")
    public void setId(UUID id) {
        this.id = id;
    }

    @SuppressWarnings("javadoc")
    public int getPrimitiveNumber() {
        return primitiveNumber;
    }

    @SuppressWarnings("javadoc")
    public void setPrimitiveNumber(int primitiveNumber) {
        this.primitiveNumber = primitiveNumber;
    }

    @SuppressWarnings("javadoc")
    public ClassConvertible02 getConvertibleObject() {
        return convertibleObject;
    }

    @SuppressWarnings("javadoc")
    public void setConvertibleObject(ClassConvertible02 convertibleObject) {
        this.convertibleObject = convertibleObject;
    }

    @SuppressWarnings("javadoc")
    public List<Long> getLongObjectList() {
        return longObjectList;
    }

    @SuppressWarnings("javadoc")
    public void setLongObjectList(List<Long> longObjectList) {
        this.longObjectList = longObjectList;
    }

    @SuppressWarnings("javadoc")
    public List<ClassConvertible02> getConvertibleObjectList() {
        return convertibleObjectList;
    }

    @SuppressWarnings("javadoc")
    public void setConvertibleObjectList(List<ClassConvertible02> convertibleObjectList) {
        this.convertibleObjectList = convertibleObjectList;
    }

    @SuppressWarnings("javadoc")
    public List<ClassNotConvertible> getNotConvertibleObjectList() {
        return notConvertibleObjectList;
    }
    
    @SuppressWarnings("javadoc")
    public void setNotConvertibleObjectList(List<ClassNotConvertible> notConvertibleObjectList) {
        this.notConvertibleObjectList = notConvertibleObjectList;
    }

    @SuppressWarnings("javadoc")
    public UUID getClassNotConvertibleId() {
        return classNotConvertibleId;
    }

    @SuppressWarnings("javadoc")
    public void setClassNotConvertibleId(UUID classNotConvertibleId) {
        this.classNotConvertibleId = classNotConvertibleId;
    }

    @SuppressWarnings("javadoc")
    public ClassNotConvertible getClassNotConvertible() {
        return classNotConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setClassNotConvertible(ClassNotConvertible classNotConvertible) {
        this.classNotConvertible = classNotConvertible;
    }

    @SuppressWarnings("javadoc")
    public ClassNotConvertible getNotConvertibleToHierarchy() {
        return notConvertibleToHierarchy;
    }

    @SuppressWarnings("javadoc")
    public void setNotConvertibleToHierarchy(ClassNotConvertible notConvertibleToHierarchy) {
        this.notConvertibleToHierarchy = notConvertibleToHierarchy;
    }

    @SuppressWarnings("javadoc")
    public ClassConvertible02 getHierarchyToConvertible() {
        return hierarchyToConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setHierarchyToConvertible(ClassConvertible02 hierarchyToConvertible) {
        this.hierarchyToConvertible = hierarchyToConvertible;
    }

    @SuppressWarnings("javadoc")
    public UUID getIdMappedIntoConvertible() {
        return idMappedIntoConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setIdMappedIntoConvertible(UUID idMappedIntoConvertible) {
        this.idMappedIntoConvertible = idMappedIntoConvertible;
    }

    @SuppressWarnings("javadoc")
    public Long getLongMappedIntoConvertible() {
        return longMappedIntoConvertible;
    }

    @SuppressWarnings("javadoc")
    public void setLongMappedIntoConvertible(Long longMappedIntoConvertible) {
        this.longMappedIntoConvertible = longMappedIntoConvertible;
    }

    @SuppressWarnings("javadoc")
    public ClassConvertible02TO getIgnoredField() {
        return ignoredField;
    }

    @SuppressWarnings("javadoc")
    public void setIgnoredField(ClassConvertible02TO ignoredField) {
        this.ignoredField = ignoredField;
    }

    @SuppressWarnings("javadoc")
    public int getPrimitiveNumberFromEntity() {
        return primitiveNumberFromEntity;
    }

    @SuppressWarnings("javadoc")
    public void setPrimitiveNumberFromEntity(int primitiveNumberFromEntity) {
        this.primitiveNumberFromEntity = primitiveNumberFromEntity;
    }

    @SuppressWarnings("javadoc")
    public ClassConvertible02 getFilteredField() {
        return filteredField;
    }

    @SuppressWarnings("javadoc")
    public void setFilteredField(ClassConvertible02 filteredField) {
        this.filteredField = filteredField;
    }

    @SuppressWarnings("javadoc")
    public List<ClassConvertible02> getFilteredList() {
        return filteredList;
    }

    @SuppressWarnings("javadoc")
    public void setFilteredList(List<ClassConvertible02> filteredList) {
        this.filteredList = filteredList;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ClassConvertible01 other = (ClassConvertible01) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
