package com.ws.commons.pojoconverter.artifacts;

import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

/**
 * @author Lucas Dillmann
 * @since 7.6.1, 2019-04-30
 */
public class NullFieldConversion implements IPojoConverter {

    @PojoColumnMapper(convertNulls = true)
    private String convertibleField;

    @PojoColumnMapper(convertNulls = false)
    private String notConvertibleField;

    public String getConvertibleField() {
        return convertibleField;
    }

    public void setConvertibleField(String convertibleField) {
        this.convertibleField = convertibleField;
    }

    public String getNotConvertibleField() {
        return notConvertibleField;
    }

    public void setNotConvertibleField(String notConvertibleField) {
        this.notConvertibleField = notConvertibleField;
    }
}
