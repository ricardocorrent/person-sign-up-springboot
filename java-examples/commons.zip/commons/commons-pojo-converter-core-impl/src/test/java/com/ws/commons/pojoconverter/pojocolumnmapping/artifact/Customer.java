package com.ws.commons.pojoconverter.pojocolumnmapping.artifact;

import com.ws.commons.persistence.model.SoftDeleteBaseEntity;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Entity that stores customer information of and is used only for {@link PojoConverter} testing purposes.
 *
 * @author  Diego Armange Costa
 * @since   6.0.0 - 2018-02-15
 */
@SuppressWarnings({ "javadoc", "serial" })
@Entity
public class Customer extends SoftDeleteBaseEntity implements IPojoConverter{

    private static final String FAKE_NAME = "Fake customer";

    private static final UUID SERVICE_UUID = UUID.randomUUID();

    private static final UUID USER_UUID = UUID.randomUUID();

    private static final String FAKE_USER_NAME = "Fake user name";

    @PojoColumnsMapper({})
    private String name;
    
    @PojoColumnMapper(target="service.id")
    private UUID serviceId;
    
    @PojoColumnMapper(target="user.id")
    private UUID userId;
    
    @PojoColumnMapper(target="user.name")
    private String userName;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "location_id")
    @PojoColumnsMapper({
        @PojoColumnMapper(source="location.id", target="locationId"),
        @PojoColumnMapper(source="location.description", target="locationDescription"),
        @PojoColumnMapper(target="mapping.path.location")
    })
    private Location location;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "another_location_id")
    private Location anotherLocation;


    // Do not use this as Business rule, it's just for test purposes
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private List<Location> locationsList;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public UUID getServiceId() {
        return serviceId;
    }

    public void setServiceId(final UUID serviceId) {
        this.serviceId = serviceId;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(final UUID userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(final Location location) {
        this.location = location;
    }
    
    public Location getAnotherLocation() {
        return anotherLocation;
    }

    public void setAnotherLocation(Location anotherLocation) {
        this.anotherLocation = anotherLocation;
    }

    public List<Location> getLocationsList() {
        return locationsList;
    }

    public void setLocationsList(List<Location> locationsList) {
        this.locationsList = locationsList;
    }

    /**
     * @return A fake {@link Customer}
     */
    public static Customer fakeCustomer() {
        final Customer customer = new Customer();
        
        customer.setName(FAKE_NAME);
        
        customer.setServiceId(SERVICE_UUID);
        
        customer.setUserId(USER_UUID);
        
        customer.setUserName(FAKE_USER_NAME);
        
        customer.setLocation(Location.fakeLocation());
        
        customer.setAnotherLocation(Location.fakeLocation());

        customer.setLocationsList(Collections.singletonList(Location.fakeLocation()));

        return customer;
    }
}
