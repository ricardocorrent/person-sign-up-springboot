package com.ws.commons.pojoconverter.artifacts.field;

import com.ws.commons.pojoconverter.annotation.PojoInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.AbstractClassWithCustomInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.ClassNotConvertible;
import com.ws.commons.pojoconverter.artifacts.provider.ClassNotConvertibleTestPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.artifacts.provider.TestPojoConverterInstanceProvider;
import java.lang.reflect.Field;

/**
 * Test field artifacts.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public final class TestFields {

    @PojoInstanceProvider(ClassNotConvertibleTestPojoConverterInstanceProvider.class)
    private ClassNotConvertible classNotConvertibleFieldWithValidProvider;

    @PojoInstanceProvider(TestPojoConverterInstanceProvider.class)
    private ClassNotConvertible classNotConvertibleFieldWithInvalidProvider;

    private ClassNotConvertible classNotConvertibleFieldWithoutProvider;

    private AbstractClassWithCustomInstanceProvider abstractClassWithCustomInstanceProvider;

    private TestFields() {}

    public static Field getClassNotConvertibleFieldWithValidProvider() throws Exception {
        return TestFields.class.getDeclaredField("classNotConvertibleFieldWithValidProvider");
    }

    public static Field getClassNotConvertibleFieldWithInvalidProvider() throws Exception {
        return TestFields.class.getDeclaredField("classNotConvertibleFieldWithInvalidProvider");
    }

    public static Field getClassNotConvertibleFieldWithoutProvider() throws Exception {
        return TestFields.class.getDeclaredField("classNotConvertibleFieldWithoutProvider");
    }

    public static Field getAbstractClassWithCustomInstanceProvider() throws Exception {
        return TestFields.class.getDeclaredField("abstractClassWithCustomInstanceProvider");
    }
}
