package com.ws.commons.pojoconverter.instance;

import com.ws.commons.pojoconverter.artifacts.ClassNotConvertible;
import com.ws.commons.pojoconverter.artifacts.field.TestFields;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 * Integration test cases for {@link PojoConverterInstanceFacade}.
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 */
public class PojoConverterInstanceFacadeIntegrationTest {

    /**
     * Test case for {@link PojoConverterInstanceFacade#createInstance(Class, Object)}.
     */
    @Test
    public void shouldCreateAnInstanceUsingClassType() {
        // scenario
        final Class<?> targetClass = ClassNotConvertible.class;
        final Object sourceValue = new Object();

        // execution
        final Object producedValue = PojoConverterInstanceFacade.createInstance(targetClass, sourceValue);

        // validation
        assertNotNull(producedValue);
        assertThat(producedValue, is(instanceOf(targetClass)));
    }

    /**
     * Test case for {@link PojoConverterInstanceFacade#createInstance(Field, Object)}.
     */
    @Test
    public void shouldCreateAnInstanceUsingFieldObject() throws Exception {
        // scenario
        final Class<?> targetClass = ClassNotConvertible.class;
        final Object sourceValue = new Object();

        final Field field = TestFields.getClassNotConvertibleFieldWithoutProvider();

        // execution
        final Object producedValue = PojoConverterInstanceFacade.createInstance(field, sourceValue);

        // validation
        assertNotNull(producedValue);
        assertThat(producedValue, is(instanceOf(targetClass)));
    }

}
