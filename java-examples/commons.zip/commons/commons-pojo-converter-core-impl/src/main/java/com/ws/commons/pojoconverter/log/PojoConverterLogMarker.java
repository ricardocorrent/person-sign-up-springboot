package com.ws.commons.pojoconverter.log;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import com.ws.commons.pojoconverter.PojoConverter;

/**
 * Log {@link Marker} factory class for {@link PojoConverter} related operations.
 *
 * <p>Use method {@link #build()} for building a marker instance for PojoConverter log entry:</p>
 * <pre>
 *     final Marker marker = PojoConverterLogMarker.build();
 * </pre>
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 * @deprecated
 */
@Deprecated
public final class PojoConverterLogMarker {

    private static final String MARKER_NAME = "POJO-CONVERTER";

    /**
     * Private constructor to avoid this class instances.
     */
    private PojoConverterLogMarker() {
    }

    /**
     * Build a new {@link Marker} instance for {@link PojoConverter} related log entries
     *
     * @return a {@link Marker} for PojoConverter log entries
     */
    public static Marker build() {
        return MarkerFactory.getMarker(MARKER_NAME);
    }
}
