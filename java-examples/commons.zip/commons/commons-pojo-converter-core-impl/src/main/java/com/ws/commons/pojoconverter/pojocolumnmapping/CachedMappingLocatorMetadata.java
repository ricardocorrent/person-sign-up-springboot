package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.google.common.cache.CacheLoader;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

/**
 * This class is meant to cache the {@link MappingLocatorMetadata}.
 * 
 * @author  Diego Armange Costa
 * @since   5.1.0 2017-10-04
 * @deprecated
 */
@Deprecated
@SuppressWarnings("javadoc")
class CachedMappingLocatorMetadata extends CacheLoader<Class<?>, MappingLocatorMetadata>{

    /**
     * @see CacheLoader#load(java.lang.Object)
     */
    @Override
    public MappingLocatorMetadata load(Class<?> declaringClass) {
        return generateLocatorMetadata(declaringClass);
    }
    
    @SuppressWarnings("unchecked")
    private MappingLocatorMetadata generateLocatorMetadata(final Class<?> declaringClass) {
        final MappingLocatorMetadata newMappingLocatorMetadata = new MappingLocatorMetadata();
        
        FieldReflectionHelper
            .fromClass(declaringClass)
            .fieldFilter()
            .containingAnnotations(PojoColumnsMapper.class, PojoColumnMapper.class)
            .getFieldSet(newMappingLocatorMetadata::append);
        
        return newMappingLocatorMetadata;
    }
}
