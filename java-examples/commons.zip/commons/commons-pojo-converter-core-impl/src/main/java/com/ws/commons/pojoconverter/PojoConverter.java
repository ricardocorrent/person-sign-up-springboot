package com.ws.commons.pojoconverter;

import com.ws.commons.PojoConverterProperties;
import com.ws.commons.core.service.ServiceLoader;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.pojoconverter.exception.PojoConverterException;
import com.ws.commons.pojoconverter.instance.PojoConverterInstanceFacade;
import com.ws.commons.pojoconverter.strategy.PojoConverterStrategy;
import com.ws.commons.server.pagination.PagedList;
import com.ws.commons.utils.reflection.TypeReflectionHelper;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is responsible to convert POJOs that implement the IPojoConverter interface.
 *
 * <p>Here's an example of how the entities may be structure to perform the conversion between the objects
 * correctly:</p>
 * <pre>
 *      public class Entity implements IPojoConverter {
 *          Long id;
 *  
 *          {@code @PojoColumnMapper(target="service.id")}
 *          Long serviceId;
 *      }
 *  
 *      public class ViewObject implements IPojoConverter {
 *          Long id;
 *  
 *          {@code @PojoColunmMapper(source="service.id", target="serviceId")}
 *          ServiceVO service;
 *      }
 *  
 *      public class ServiceVO {
 *          Long id;
 *      }
 * </pre>
 *
 * @author  Diego A. Costa
 * @author  Diego A. Costa
 * @author  Lucas Dillmann
 * @version 5.3.1 - 2017-12-04 - Control of field reading added. A field with a restricted getter will be read only
*                                by direct field access.
 * @version 7.0.2 - 2018-08-07 - Changed {@link PagedList} settings from primitive to Object.<br>
 * @version 7.1.0 - 2018-08-10 - Added the optional conversion strategy to only convert the changed fields between DTO and entity.
 * @version 7.2.4 - 2018-09-03 - Optimized internal logic to validate if the registered {@link PojoConverterStrategy}
 *                               instances allow the conversion of any given field.
 * @version 7.3.0 - 2018-09-11 - Now, when this class needs to create a object instance, Java Reflection API isn't used
 *                               anymore and all requests to do that will be forwarded to {@link PojoConverterInstanceFacade}.
 *                               This allows the instance creation process be intercepted and personalized.
 * @version 7.3.4 - 2018-01-10 - Changed field's conversion precedence. Now, it converts annotated fields first and then
 *                               searches for fields with the same name to convert.
 * @see     PojoColumnMapper
 * @see     IPojoConverter
 * @since   5.0.0 - 2017-06-01
 * @deprecated
 */
@Deprecated
@RequestScoped
public class PojoConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(PojoConverter.class);

    private static final String UNCHECKED = "unchecked";
    private static final String RAWTYPES = "rawtypes";
    private static final String SOURCE_OBJECT_PARAMETER_DESCRIPTION = "sourceObject";
    private static final String TARGET_CLASS_PARAMETER_DESCRIPTION = "targetClass";
    private static final String REGEX_COLUMN_MAPPER_SEPARATOR = "\\.";
    
    private boolean forceChangeFinalField;
    private boolean ignoreFinalField = true;
    private Map<Class<?>, Class<?>> classMapper = new HashMap<>();
    
    private final Map<Object, Object> backReferenceMapper = new HashMap<>();
    private final Set<PojoConverterStrategy> pojoConverterStrategies;

    /**
     * Default constructor with internal {@link PojoConverterStrategy} initialization.
     *
     * @author  Lucas Dillmann
     * @since   7.2.0 - 2018-08-17
     */
    public PojoConverter() {
        this.pojoConverterStrategies = ServiceLoader
                .forClass(PojoConverterStrategy.class)
                .getImplementations();
    }

    /**
     * Forces the conversion on final fields.
     *
     * @return the PojoConverter instance.
     */
    public PojoConverter forceChangeFinalField() {
        LOGGER.debug("PojoConverter configured to force the conversion on final fields instead of ignoring them");

        forceChangeFinalField = true;
        ignoreFinalField = false;
        return this;
    }
    
    /**
     * <p>Converts the POJO to the informed class.</p>
     * <p>Both classes must implement {@link IPojoConverter}.</p>
     * <p>Mutual mapping between POJOs is mandatory.</p>
     *
     * <p>Usage example using the classes described in this class' javadoc</p>
     * <pre>
     *      Example example = new Example();
     *      Entity entity = new Entity();
     *      ViewObject viewObject = new ViewObject();
     *      viewObject.service = new ServiceVO();
     *
     *      // Converts entity to VO
     *      new PojoConverter().convert(ViewObject.class, entity);
     *
     *      //Converts VO to entity
     *      new PojoConverter().convert(Entity.class, viewObject);
     *  }
     * </pre>
     * 
     * @author              Diego A. Costa
     * @param <L>           as result of conversion.
     * @param <R>           as object to be converted.
     * @param targetClass   as class of the result of the conversion
     * @param sourceObject  as the source of the conversion
     * @return              converted POJO.
     * @see                 IPojoConverter
     * @see                 PojoColumnMapper
     * @see                 PojoColumnIgnore
     * @since               3.0.0 2017-06-01
     */
    public <L extends IPojoConverter, R extends IPojoConverter> R convert(final Class<R> targetClass, final L sourceObject) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(TARGET_CLASS_PARAMETER_DESCRIPTION));
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));

        LOGGER.debug("Starting the conversion from '{}' to '{}'", sourceObject, targetClass.getName());
        return this.convertTo(targetClass, sourceObject, new FieldProcessing());
    }
    
    /**
     * <p>Converts the POJO to the informed class using only the informed fields.</p>
     * <p>Both classes must implement {@link IPojoConverter}.</p>
     * <p>Mutual mapping between POJOs is mandatory.</p>
     *
     * <p>Usage example using the classes described in this class' javadoc</p>
     * <pre>
     *      Example example = new Example();
     *      Entity entity = new Entity();
     *      ViewObject viewObject = new ViewObject();
     *      viewObject.service = new ServiceVO();
     *
     *      // Converts entity to VO
     *      new PojoConverter().convert(ViewObject.class, entity);
     *
     *      //Converts VO to entity
     *      new PojoConverter().convert(Entity.class, viewObject);
     *  }
     * </pre>
     * 
     * @author              Diego A. Costa
     * @param <L>           as result of conversion.
     * @param <R>           as object to be converted.
     * @param targetClass   as class of the result of the conversion
     * @param sourceObject  as the source of the conversion
     * @param fields        as fields to convert
     * @return              converted POJO.
     * @see                 IPojoConverter
     * @see                 PojoColumnMapper
     * @see                 PojoColumnIgnore
     * @since               3.0.0 2017-07-03
     */
    public <L extends IPojoConverter, R extends IPojoConverter> R convert(final Class<R> targetClass, final L sourceObject, final String... fields) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(TARGET_CLASS_PARAMETER_DESCRIPTION));
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));

        LOGGER.debug("Starting the conversion from '{}' to '{}'. Only converting fields '{}'.", sourceObject, targetClass.getName(), ArrayUtils.toString(fields));
        return this.convertTo(targetClass, sourceObject, createFieldProcessing(fields));
    }
    
    /**
     * <p>Converts the POJO to the informed class.</p>
     * <p>Both classes do not need to implement {@link IPojoConverter}.</p>
     *
     * <p>Usage example using the classes described in this class' javadoc</p>
     * <pre>
     *      Example example = new Example();
     *      Entity entity = new Entity();
     *      ViewObject viewObject = new ViewObject();
     *      viewObject.service = new ServiceVO();
     *
     *      // Converts entity to VO
     *      new PojoConverter().convert(ViewObject.class, entity);
     *
     *      //Converts VO to entity
     *      new PojoConverter().convert(Entity.class, viewObject);
     *  }
     * </pre>
     * 
     * @author              Diego A. Costa
     * @param classMapper   as a map containing the target classes mapped by source classes
     * @param sourceObject  as the source of the conversion
     * @return              converted POJO.
     * @see                 PojoColumnMapper
     * @see                 PojoColumnIgnore
     * @since               3.0.0 2017-06-13
     */
    public Object convert(final Map<Class<?>, Class<?>> classMapper, final Object sourceObject) {
        Objects.requireNonNull(classMapper, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("classMapper"));
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));

        this.classMapper = classMapper;
        
        Class<?> targetClass = this.classMapper.get(sourceObject.getClass());
        Objects.requireNonNull(targetClass, EPojoConverterMessage.TARGET_CLASS_NOT_FOUND_FOR_SOURCE_CLASS.getMessage(sourceObject.getClass().getName()));

        LOGGER.debug("Starting the conversion from '{}' to '{}' using a custom class mapping", sourceObject, targetClass.getName());
        return convertTo(targetClass, sourceObject, new FieldProcessing());
    }
    
    /**
     * Converts the {@code sourceObject} to {@code targetClass}.
     *
     * @param targetClass   as class of the result of the conversion
     * @param sourceObject  as the source of the conversion
     * @param fields        as field names to be filtered in the conversion.
     * @return              converted POJO.
     */
    protected Object convert(final Class<?> targetClass, final Object sourceObject, final String... fields) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(TARGET_CLASS_PARAMETER_DESCRIPTION));
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));

        LOGGER.debug("Starting the conversion from '{}' to '{}'. Conversion will be done only for fields '{}'.", sourceObject, targetClass.getName(), ArrayUtils.toString(fields));
        final FieldProcessing fieldProcessing = new FieldProcessing(fields);
        return convert(targetClass, sourceObject, fieldProcessing);
    }
    
    /**
     * Converts the {@code sourceObject} to {@code targetClass}, ignoring the conversion of fields declared
     * in {@code fields} parameter.
     *
     * @param targetClass   as class of the result of the conversion
     * @param sourceObject  as the source of the conversion
     * @param fields        as field names to be ignored in the conversion
     * @return              converted POJO
     */
    protected Object convertIgnoring(final Class<?> targetClass, final Object sourceObject, final String... fields) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(TARGET_CLASS_PARAMETER_DESCRIPTION));
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));

        LOGGER.debug("Starting the conversion from '{}' to '{}'. Conversion will be done ignoring the fields '{}'.", sourceObject, targetClass.getName(), ArrayUtils.toString(fields));
        final FieldProcessing fieldProcessing = new FieldProcessing(true, fields);
        return convert(targetClass, sourceObject, fieldProcessing);
    }
    
    @SuppressWarnings({ RAWTYPES, UNCHECKED })
    private Object convert(final Class<?> targetClass, final Object sourceObject, final FieldProcessing fieldProcessing) {
        if (List.class.isAssignableFrom(sourceObject.getClass())) {
            LOGGER.debug("List detected in the source object. Conversion will be done using the list contents.");
            return this.convertList(targetClass, (List)sourceObject, fieldProcessing);
        } else if (sourceObject instanceof com.ws.commons.server.pagination.PagedList) {
            LOGGER.debug("PagedList detected in the source object. Conversion will be done using the paged list contents.");
            final PagedList pagedList = (com.ws.commons.server.pagination.PagedList) sourceObject;
            
            final int pageSize = pagedList.getPageSize();
            final Integer page = pagedList.getPage();
            final Integer count = pagedList.getCount();
            final List items = pagedList.getItems();
            final List<?> result = convertList(targetClass, items, fieldProcessing);
            
            return new PagedList<>(result, count, page, pageSize);
        } else if (sourceObject.getClass().isArray()) {
            LOGGER.debug("Array detected in the source object. Conversion will be done using the array contents.");
            return this.convertArray(targetClass, (Object[])sourceObject, fieldProcessing);
        } else {
            validateIPojoConverterDeclaration(targetClass, sourceObject);
        }
        
        return convertTo(targetClass, sourceObject, fieldProcessing);
    }
    
    /**
     * <p>
     * Returns the corresponding class within the {@link Map}, either as value or as key.
     * </p>
     * 
     * @param classMap      as map containing class pairs
     * @param classSource   as the class from which you wish to find the matching pair
     * @return              the corresponding class within the Map, either as value or key
     */
    public Class<?> getCorrespondingClass(final Map<Class<?>, Class<?>> classMap, final Class<?> classSource) {
        Objects.requireNonNull(classMap, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("classMap"));
        Objects.requireNonNull(classSource, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("classSource"));
        
        Class<?> correspondingClass = classMap.get(classSource);
        
        if (correspondingClass == null) {
            for (Entry<Class<?>, Class<?>> entry : classMap.entrySet()) {
                if (entry.getValue().equals(classSource)) {
                    return entry.getKey();
                }
            }
        }

        LOGGER.debug("Detected class '{}' as the target for conversion from '{}'", correspondingClass, classSource.getName());
        return correspondingClass;
    }
    
    /**
     * <p>
     * Performs a {@link List} of objects conversion without validating {@link IPojoConverter} interface implementation.
     * </p>
     * @param <T>               as class type
     * @param targetClass       as class of the result of the conversion
     * @param sourceObjectList  as the source list of the conversion
     * @param fields            as field names to conversion
     * @return                  converted POJO
     */
    public <T> List<T> convertList(final Class<T> targetClass, final List<? extends Object> sourceObjectList, final String... fields) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(TARGET_CLASS_PARAMETER_DESCRIPTION));
        Objects.requireNonNull(sourceObjectList, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("sourceObjectList"));
        
        List<T> targetObjectList = new ArrayList<>();
        
        for (Object sourceObject : sourceObjectList) {
            targetObjectList.add(convertTo(targetClass, sourceObject, createFieldProcessing(fields)));
        }
        
        return targetObjectList;
    }
    
    private <T> List<T> convertList(final Class<T> targetClass, final List<? extends Object> sourceObjectList, final FieldProcessing fieldProcessing) {
        final List<T> targetObjectList = new ArrayList<>();
        
        for (Object sourceObject : sourceObjectList) {
            targetObjectList.add(convertTo(targetClass, sourceObject, fieldProcessing));
        }
        
        return targetObjectList;
    }
    
    /**
     * Performs conversion without validating {@link IPojoConverter} interface implementation.
     *
     * @param <T>           as target type
     * @param targetClass   as class of the result of the conversion
     * @param pagedList     as the source of the conversion
     * @param fields        as field names to conversion
     * @return              converted POJO
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public <T> PagedList<T> convertPagedList(final Class<T> targetClass, final PagedList<?> pagedList, final String... fields) {
        final Integer pageSize = pagedList.getPageSize();
        final Integer page = pagedList.getPage();
        final Integer count = pagedList.getCount();
        final Integer firstRow = pagedList.getFirstRow();
        final List items = pagedList.getItems();
        final List<T> result = convertList(targetClass, items, fields);
        
        return new PagedList<>(result, count, firstRow, page, pageSize);
    }

    private FieldProcessing createFieldProcessing(final String... fields) {
        return new FieldProcessing(fields);
    }
    
    private void validateIPojoConverterDeclaration(final Class<?> targetClass, final Object sourceObject) {
        Class<?> targetType = TypeReflectionHelper.getGenericType(targetClass, 0);
        
        boolean targetClassImplementation = IPojoConverter.class.isAssignableFrom(targetType);
        
        if (!targetClassImplementation) {
            throw new PojoConverterException(EPojoConverterMessage.CLASS_NOT_IMPLEMENTS_INTERFACE.
                    getMessage(targetType.getName(), IPojoConverter.class.getName()));
        }
        
        Class<?> sourceType = TypeReflectionHelper.getGenericType(sourceObject.getClass(), 0);
        
        boolean sourceObjectImplementation = IPojoConverter.class.isAssignableFrom(sourceType);
        
        if (!sourceObjectImplementation) {
            throw new PojoConverterException(EPojoConverterMessage.CLASS_NOT_IMPLEMENTS_INTERFACE.
                    getMessage(sourceType.getName(), IPojoConverter.class.getName()));
        }
    }
    
    @SuppressWarnings(UNCHECKED)
    private <T> T[] convertArray(final Class<T> targetClass, final Object[] sourceObjectArray, final FieldProcessing fieldProcessing) {
        Objects.requireNonNull(sourceObjectArray, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("sourceObjectArray"));
        
        Object[] targetObjectList = new Object[sourceObjectArray.length];
        
        for (int i = 0; i < sourceObjectArray.length; i++) {
            targetObjectList[i] = convertTo(targetClass, sourceObjectArray[i], fieldProcessing);
        }
        
        return (T[]) targetObjectList;
    }
    
    /**
     * @author              Lucas Dillmann
     * @param <T>           as the class of the object that will be returned
     * @param targetClass   as the class of the object that will be returned
     * @param sourceObject  as object containing the values to be converted
     * @return              converted object.
     * @since               7.3.0 - 2018-09-11
     */
    private <T> T convertTo(final Class<T> targetClass, final Object sourceObject, FieldProcessing fieldProcessing) {
        Objects.requireNonNull(sourceObject, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage(SOURCE_OBJECT_PARAMETER_DESCRIPTION));
        
        Objects.requireNonNull(fieldProcessing, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("fieldProcessing"));
        
        final T targetObject = PojoConverterInstanceFacade.createInstance(targetClass, sourceObject);
        
        if (isFilterProcessing(fieldProcessing)) {
            final List<Field> sourceFieldArray = FieldReflectionHelper.fromClass(sourceObject.getClass()).getFields(fieldProcessing.getFields());
            
            convertFields(sourceObject, sourceFieldArray, targetObject, fieldProcessing);
        } else {
            final List<Field> sourceFieldArray = FieldReflectionHelper.fromClass(sourceObject.getClass()).getFields();
            
            convertFields(sourceObject, sourceFieldArray, targetObject, fieldProcessing);
        }
        
        return targetObject;
    }

    /**
     * Converts a provided collection of fields from the source to the target object.
     *
     * <p>This method will handle the provided fields under {@code sourceFieldArray} collection and convert the value
     * from them to the target object. This is achieved by validating the value and the field, checking if the value
     * needs to (and is allowed to) be converted from mapping configuration prior to copying the value from source to target.
     * All registered {@link PojoConverterStrategy} instances will also be called to check if the value is allowed to be
     * converted by the foreign implementations.</p>
     *
     * <p>When all validations pass and strategies allow the conversion, then the metadata of the field will be collected
     * and forwarded to the implementation per-se of the conversion, where the copy really occurs, in method
     * {@link #processTargetFieldConversion(Class, Object, FieldWrapper)}.</p>
     *
     * @author                  Lucas Dillmann
     * @param sourceObject      source object of the conversion
     * @param sourceFieldArray  collections of fields who can be converted
     * @param targetObject      target object of the conversion
     * @param fieldProcessing   field processing metadata object
     * @since                   7.2.4 - 2018-09-03
     */
    private void convertFields(final Object sourceObject, final List<Field> sourceFieldArray, final Object targetObject, final FieldProcessing fieldProcessing) {
        if(sourceFieldArray != null) {
            for (Field field : sourceFieldArray) {

                LOGGER.debug(
                        "Converting field '{}' from class '{}'",
                        field.getName(),
                        field.getDeclaringClass().getName()
                );
                final FieldWrapper sourceField = createFieldWrapper(sourceObject, field);

                boolean allowedByStrategies = pojoConverterStrategies
                        .stream()
                        .map(strategy -> {
                            final boolean conversionAllowed = strategy.shouldConvert(sourceObject, targetObject, sourceField);
                            if (!conversionAllowed) {
                                LOGGER.debug(
                                        "Conversion of the field '{}' from class '{}' disallowed by strategy '{}'",
                                        field.getName(),
                                        field.getDeclaringClass().getName(),
                                        strategy.getClass().getName()
                                );
                            }

                            return conversionAllowed;
                        })
                        .reduce(true, (strategyResultA, strategyResultB) -> strategyResultA && strategyResultB);

                if (!allowedByStrategies) {
                    continue;
                }

                boolean processed;
                
                boolean hasNoContentAndIsNotBackReferenced =
                        isNullFieldContentAndIsNotBackReference(sourceField);
                
                if (hasNoContentAndIsNotBackReferenced
                        || isIgnoredField(sourceField, targetObject.getClass()) 
                        || isIgnoredSubfield(fieldProcessing, sourceField)) {
                    if (hasNoContentAndIsNotBackReferenced) {
                        logNullField(sourceField);
                    }

                    LOGGER.debug(
                            "Conversion of the field '{}' from class '{}' skipped. Value is null or the field is ignored.",
                            field.getName(),
                            field.getDeclaringClass().getName()
                    );
                    continue;
                }
                
                handleBackReference(sourceField);
                
                processed = processTargetFieldConversion(targetObject.getClass(), targetObject, sourceField);
                
                if (!processed) {
                    String fieldName = sourceField.getField().getName();
                    
                    String declaringClassName = sourceField.getField().getDeclaringClass().getName();
                    
                    LOGGER.debug(EPojoConverterMessage.UNPROCESSED_FIELD.getMessage(fieldName, declaringClassName));
                }
            }
        }
    }
    
    private boolean isNullFieldContentAndIsNotBackReference(final FieldWrapper field) {
        final boolean skipNulls = field
                .getMapping()
                .map(PojoColumnMapper::convertNulls)
                .orElse(false);
        final boolean nullValue = field.getContent() == null;

        return nullValue && !skipNulls && !field.isBackReference();
    }
    
    private boolean isFilterProcessing(FieldProcessing fieldProcessing) {
        return fieldProcessing != null && !ArrayUtils.isEmpty(fieldProcessing.getFields()) && !fieldProcessing.isIgnoreFields();
    }
    
    private FieldWrapper createFieldWrapper(final Object sourceObject, final Field field) {
        return new FieldWrapper(field, sourceObject);
    }
    
    private boolean isIgnoredSubfield(final FieldProcessing fieldProcessing, FieldWrapper sourceField) {
        if (ArrayUtils.isNotEmpty(fieldProcessing.getFields()) && fieldProcessing.isIgnoreFields()) {
            return ArrayUtils.contains(fieldProcessing.getFields(), sourceField.getField().getName());
        }

        return false;
    }

    private boolean processTargetFieldConversion(final Class<?> targetClass, final Object targetObject, final FieldWrapper sourceField) {
        boolean processed = false;
        
        for (final Field field : FieldReflectionHelper.fromClass(targetClass).getFields()) {
            final FieldWrapper targetField = createFieldWrapper(targetObject, field);
            
            if (convertField(sourceField, targetField)) {
                processed = true;
                break;
            }
        }
        
        return processed;
    }

    private boolean convertField(final FieldWrapper sourceField, final FieldWrapper targetField) {
        LOGGER.debug(
                "Converting field '{}' from '{}' to field '{}' from '{}'",
                sourceField.getField().getName(),
                sourceField.getField().getDeclaringClass().getName(),
                targetField.getField().getName(),
                targetField.getField().getDeclaringClass().getName()
        );
        boolean result = false;

        if (getPojoColunmMapper(sourceField, targetField) != null) {
            LOGGER.debug(
                    "Custom mapping detected for field '{}' from '{}'",
                    sourceField.getField().getName(), sourceField.getField().getDeclaringClass().getName()
            );
            result = copyAnnotatedSourceFieldsToTarget(sourceField, targetField);
        } else if (isSameFieldNames(sourceField, targetField)) {
            LOGGER.debug(
                    "No custom mapping detected for field '{}' from '{}'. Conversion will be done using field name match.",
                    sourceField.getField().getName(), sourceField.getField().getDeclaringClass().getName()
            );
            if (isSameFieldType(sourceField, targetField)) {
                targetField.setContent(sourceField.getContent());

                result = processValueIntoField(targetField);
            } else if (isNotNullFieldOrBackReferenced(sourceField) && !isAnnotatedFieldMapped(sourceField)) {
                result = copySourceFieldsToSameFieldsInsideTarget(sourceField, targetField);
            } else {
                LOGGER.warn(
                        "Conversion of the field '{}' of '{}' to field '{}' of '{}' was skipped. The source and the target types didn't match.",
                        sourceField.getField().getName(),
                        sourceField.getField().getDeclaringClass().getName(),
                        targetField.getField().getName(),
                        targetField.getField().getDeclaringClass().getName()
                );
            }
        }
        return result;
    }
    
    @SuppressWarnings("unchecked")
    private void handleBackReference(final FieldWrapper field) {
        final Object content = field.getContent();
        
        if (content instanceof Collection) {
            Collection.class.cast(content)
                .forEach(item -> this.backReferenceMapper.put(item, field.getDeclaringInstance()));
        } else {
            this.backReferenceMapper.put(field.getContent(), field.getDeclaringInstance());
        }
    }
    
    private boolean isNotNullFieldOrBackReferenced(FieldWrapper field) {
        return !isNullFieldContentAndIsNotBackReference(field);
    }
    
    private boolean isAnnotatedFieldMapped(final FieldWrapper field) {
        final PojoColumnMapper pojoColumnMapper = field.getField().getAnnotation(PojoColumnMapper.class);
        
        final PojoColumnsMapper pojoColumnsMapper = field.getField().getAnnotation(PojoColumnsMapper.class);
        
        return pojoColumnMapper != null || pojoColumnsMapper != null;
    }

    private boolean isIgnoredField(final FieldWrapper sourceField, final Class<?> targetClass) {
        Class<?>[] pojoColumnIgnoreValue = sourceField.getPojoColumnIgnoreValue();
        
        if (ArrayUtils.isNotEmpty(pojoColumnIgnoreValue)) {
            for (Class<?> targetClassFound : pojoColumnIgnoreValue) {
                if (targetClassFound.equals(targetClass)) {
                    return ArrayUtils.isEmpty(sourceField.getPojoColumnIgnoreFields());
                }
            }
            
            return false;
        } 
        
        return pojoColumnIgnoreValue != null && ArrayUtils.isEmpty(sourceField.getPojoColumnIgnoreFields());
    }

    private boolean isSameFieldType(final FieldWrapper sourceField, final FieldWrapper targetField) {
        if (targetField.getField().getType().equals(sourceField.getField().getType())) {
            Class<?> genericTargetFieldType = TypeReflectionHelper.getGenericFieldType(targetField.getField(), 0);
            
            Class<?> genericSourceFieldType = TypeReflectionHelper.getGenericFieldType(sourceField.getField(), 0);
            
            return isSameClass(genericTargetFieldType, genericSourceFieldType);
        }
        
        return false;
    }
    
    private boolean isSameClass(final Type leftClass, final Type rightClass) {
        Objects.requireNonNull(leftClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("leftClass"));
        
        Objects.requireNonNull(rightClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("rightClass"));
        
        return leftClass.equals(rightClass);
    }

    private boolean copySourceFieldsToSameFieldsInsideTarget(final FieldWrapper sourceField, final FieldWrapper targetField) {
        final Class<?> actualSourceFieldType = TypeReflectionHelper.getGenericType(sourceField.getField().getType(), 0);

        final Class<?> mappedClass = getMappedClass(actualSourceFieldType);

        if (mappedClass != null || isConvertibleType(actualSourceFieldType)) {
            return setTargetValueFromConvertedSourceValue(sourceField, targetField);
        } else if (List.class.isAssignableFrom(actualSourceFieldType)) {
            return convertSourceListToTargetList(sourceField, targetField);
        }
        
        return false; 
    }
    
    private boolean setTargetValueFromConvertedSourceValue(final FieldWrapper sourceField, final FieldWrapper targetField) {
        final Class<?> currentTargetFieldType = TypeReflectionHelper.getGenericType(targetField.getField().getType(), 0);
        
        if (sourceField.isBackReference()) {
            final Object backReferenceInstance = backReferenceMapper.get(sourceField.getDeclaringInstance());
            
            targetField.setContent(
                    this.convertTo(
                            currentTargetFieldType, 
                            backReferenceInstance, 
                            new FieldProcessing(sourceField.getBackReferenceAttributes())));
            
            return processValueIntoField(targetField);
        }
        
        if (sourceField.getContent() != null || !isOnlyConvertChangedValues()) {
            targetField.setContent(this.convertTo(currentTargetFieldType, sourceField.getContent(), sourceField.getFieldProcessing()));

            return processValueIntoField(targetField);
        } else {
            logNullField(sourceField);
        }
        
        return false;
    }

    private void logNullField(final FieldWrapper sourceField) {
        String fieldName = sourceField.getField().getName();
        
        String declaringClassName = sourceField.getField().getDeclaringClass().getName();
        
        LOGGER.debug(EPojoConverterMessage.NULL_FIELD.getMessage(fieldName, declaringClassName));
    }
    
    private Class<?> getMappedClass(Class<?> type) {
        return classMapper != null ? classMapper.get(type) : null; 
    }

    private boolean isSameFieldNames(final FieldWrapper sourceField, final FieldWrapper targetField) {
        return targetField.getField().getName().equals(sourceField.getField().getName());
    }

    @SuppressWarnings({ RAWTYPES, UNCHECKED })
    private boolean convertSourceListToTargetList(final FieldWrapper sourceField, final FieldWrapper targetField) {
        final Class<?> targetType = TypeReflectionHelper.getGenericFieldType(targetField.getField(), 0);
        final List sourceEntries = (List) sourceField.getContent();
        final List targetEntries = new ArrayList();

        targetField.setContent(sourceEntries == null ? null : targetEntries);

        final Class<?> actualSourceFieldType = TypeReflectionHelper.getGenericFieldType(sourceField.getField(), 0);

        if (CollectionUtils.isNotEmpty(sourceEntries)) {
            if (isConvertibleType(actualSourceFieldType) || isMappedType(targetType, actualSourceFieldType)) {

                //Enviar os wrappers
                convertSourceEntriesToTargetEntries(targetType, sourceField, targetField);
            } else {
                //Precisa garantir que os tipos são compatíveis com o esperado
                //Caso não sejam compativeis deve ser gerado um LOG de warning
                for (Iterator iter = sourceEntries.iterator(); iter.hasNext();) {
                    targetEntries.add(iter.next());
                }
            }
        }

        return processValueIntoField(targetField);
    }

    private boolean isMappedType(final Class<?> targetType, final Class<?> sourceType) {
        final Class<?> mappedClass = getMappedClass(sourceType);
        
        return mappedClass != null && mappedClass.hashCode() == targetType.hashCode();
    }

    @SuppressWarnings({ RAWTYPES, UNCHECKED })
    private void convertSourceEntriesToTargetEntries(final Class<?> targetType, final FieldWrapper sourceField, final FieldWrapper targetField) {
        List sourceEntries = (List) sourceField.getContent();
        
        List targetEntries = (List) targetField.getContent();
        
        for (Iterator iter = sourceEntries.iterator(); iter.hasNext();) {
            
            final Object newSourceObject = iter.next();
            
            //Warning: Field pairs may have the same name, but the generic type may be different.
            final Object newTargetObject = this.convertTo(targetType, newSourceObject, sourceField.getFieldProcessing());
            
            targetEntries.add(newTargetObject);
        }
    }

    /**
     * Copies {@code sourceField} mapped through {@link PojoColumnMapper} into {@code targetField}.
     *
     * @author              Lucas Dillmann
     * @param sourceField   source field to copy values from
     * @param targetField   target field to copy values to
     * @return              result of the copy, being true when it was successful
     *
     */
    private boolean copyAnnotatedSourceFieldsToTarget(final FieldWrapper sourceField, final FieldWrapper targetField) {
        PojoColumnMapper[] pojoColumnMapperArray = getPojoColunmMapper(sourceField, targetField);
        
        if (pojoColumnMapperArray != null) {
            for (PojoColumnMapper pojoColumnMapper : pojoColumnMapperArray) {
                final Object mappedContent = getAnnotedSourceFieldValue(sourceField, pojoColumnMapper);
                
                setAnnotedTargetValue(targetField, sourceField, pojoColumnMapper, mappedContent);
            }
        }
        return false;
    }

    private boolean isConvertibleType(final Class<?> type) {
        //Precisa verificar se existe mapeamento de conversão 
        return IPojoConverter.class.isAssignableFrom(type);
    }
    
    private PojoColumnMapper[] getPojoColunmMapper(final FieldWrapper sourceField, final FieldWrapper targetField) {
        final PojoColumnMapper pojoColumnMapper = sourceField.getField().getAnnotation(PojoColumnMapper.class);
        
        final PojoColumnsMapper pojoColumnsMapper = sourceField.getField().getAnnotation(PojoColumnsMapper.class);
        
        PojoColumnMapper[] result = null;
        
        if (pojoColumnMapper != null && isValidPojoColumnMapper(pojoColumnMapper, targetField.getField(), sourceField.getField())) {
            result = createPojoColumnMapper(pojoColumnMapper);
        } else if (pojoColumnsMapper != null && pojoColumnsMapper.value() != null) {
            final List<PojoColumnMapper> columns = new ArrayList<>();
            for (PojoColumnMapper pojoColumnMapperFromArray : pojoColumnsMapper.value()) {
                if (isValidPojoColumnMapper(pojoColumnMapperFromArray, targetField.getField(), sourceField.getField())) {
                    columns.add(pojoColumnMapperFromArray);
                }
            }
            result = columns.stream().toArray(PojoColumnMapper[]::new);
        }
        
        return result;
    }

    private PojoColumnMapper[] createPojoColumnMapper(PojoColumnMapper pojoColumnMapperFromArray) {
        return new PojoColumnMapper[]{pojoColumnMapperFromArray};
    }
    
    private boolean isValidPojoColumnMapper(final PojoColumnMapper pojoColumnMapper, final Field targetField, final Field sourceField) {
        final String sourceColumnMapped = pojoColumnMapper.source().isEmpty() ? sourceField.getName() : pojoColumnMapper.source();
        
        final boolean sourceMatched = validateAnnotationValue(sourceField, sourceColumnMapped);
        
        final boolean targetMatched = validateAnnotationValue(targetField, pojoColumnMapper.target());
        
        return sourceMatched && targetMatched;
    }

    private boolean validateAnnotationValue(final Field field, final String annotationValue) {
        if (!(annotationValue == null || annotationValue.isEmpty())) {
            final String[] annotationValueMapper = annotationValue.split(REGEX_COLUMN_MAPPER_SEPARATOR);
            
            if (annotationValueMapper.length > 0) {
                return compareTargetLevelRecursively(annotationValueMapper, field);
            }else if (isAnnotationValueMatched(field, annotationValue)) {
                return true; 
            }
        }
        
        return false;
    }

    private boolean compareTargetLevelRecursively(final String[] annotationValueMapper, final Field field) {
        final int level = 0;
        
        final boolean levelMached = field.getName().equals(annotationValueMapper[level]);
        
        if (levelMached) {
            if (annotationValueMapper.length > level+1) {
                return compareTargetLevelRecursively(annotationValueMapper, FieldReflectionHelper.fromClass(field.getDeclaringClass()).getFields(), level);
            }
            
            return true;
        }
        
        return false;
    }

    private boolean compareTargetLevelRecursively(final String[] annotationValueMapper, final List<Field> levelFields, final int level) {
        if (level < annotationValueMapper.length) {
            for (Field field : levelFields) {
                if (field.getName().equals(annotationValueMapper[level])) {
                    final List<Field> fields = FieldReflectionHelper.fromClass(field.getType()).getFields();
                    
                    if (hasFields(fields) && hasNodes(annotationValueMapper, level)) {
                        return compareTargetLevelRecursively(annotationValueMapper, fields, level+1);
                    } else if (!hasNodes(annotationValueMapper, level)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    private boolean isAnnotationValueMatched(final Field field, final String annotationValue) {
        return field.getName().equals(annotationValue);
    }

    private boolean hasNodes(final String[] targetSplit, final int level) {
        return level+1 < targetSplit.length;
    }

    private boolean hasFields(final List<Field> fields) {
        return fields != null && !fields.isEmpty();
    }
    
    private Object getAnnotedSourceFieldValue(final FieldWrapper sourceField, final PojoColumnMapper pojoColunmMapper) {
        final String sourceColumn = pojoColunmMapper.source();
        
        final String[] columnNodeMapper = sourceColumn.split(REGEX_COLUMN_MAPPER_SEPARATOR);
        
        /*
         * @see setFieldValueRecursivelyByMapperLevel(...)
         */
        if (columnNodeMapper.length > 1 && sourceField.getContent() != null) {
            return getFieldValueRecursivelyByMapperLevel(sourceField, columnNodeMapper, 1);
        }
        return sourceField.getContent();
    }
    
    private Object getFieldValueRecursivelyByMapperLevel(final FieldWrapper sourceField, final String[] columnNodeMapper, final int node) {
        final String column = columnNodeMapper[node];

        final FieldWrapper subField = new FieldWrapper(FieldReflectionHelper.fromClass(sourceField.getField().getType()).getField(column), sourceField.getContent());
        
        if (columnNodeMapper.length <= node+1) {
            return subField.getContent();
        } else {
            return getFieldValueRecursivelyByMapperLevel(subField, columnNodeMapper, node+1);
        }
    }

    /**
     * Defines the target value using annotation.
     *
     * @author                  Lucas Dillmann
     * @param targetField       target field
     * @param sourceField       source field
     * @param pojoColunmMapper  field annotation details
     * @param content           field value
     * @return                  the result of the procedure, being true when successful
     */
    private boolean setAnnotedTargetValue(final FieldWrapper targetField,
                                          final FieldWrapper sourceField,
                                          final PojoColumnMapper pojoColunmMapper,
                                          final Object content) {
        final String column = pojoColunmMapper.target();
        
        final String[] columnNodeMapper = column.split(REGEX_COLUMN_MAPPER_SEPARATOR);
        
        return setFieldValueRecursivelyByMapperLevel(targetField, sourceField, columnNodeMapper, 0, content);
    }

    /**
     * Defines a value into a field using a recursive strategy.
     *
     * @author                  Lucas Dillmann
     * @param targetField       target field to receive the value
     * @param sourceField       source field from where the value came from
     * @param columnNodeMapper  full path to the target field
     * @param node              current node inside the provided full path
     * @param content           content to be set into the target field
     * @return                  the result of the operation, being true when successful
     */
    private boolean setFieldValueRecursivelyByMapperLevel(final FieldWrapper targetField,
                                                          final FieldWrapper sourceField,
                                                          final String[] columnNodeMapper,
                                                          final int node,
                                                          final Object content) {
        final String column = columnNodeMapper[node];

        final FieldWrapper subField = new FieldWrapper(
                FieldReflectionHelper.fromClass(targetField.getField().getDeclaringClass()).getField(column),
                targetField.getDeclaringInstance()
        );
        
        if (columnNodeMapper.length <= node+1) {
            final Class<?> actualSourceFieldType = TypeReflectionHelper.getGenericType(subField.getField().getType(), 0);

            if (content != null && isConvertibleType(actualSourceFieldType)) {
                final Object convertedValue = this.convertTo(actualSourceFieldType, content, new FieldProcessing());
                
                subField.setContent(convertedValue);

                return processValueIntoField(subField);
            } else {
                subField.setContent(content);
                
                return processValueIntoField(subField);
            }
        } else {

            if (subField.getContent() == null) {
                final Object subFieldContent = PojoConverterInstanceFacade.createInstance(
                        subField.getField(),
                        sourceField.getContent()
                );

                subField.setContent(subFieldContent);
                processValueIntoField(subField);
            }
            
            final FieldWrapper nextSubField = new FieldWrapper(
                    FieldReflectionHelper.fromClass(subField.getField().getType()).getField(columnNodeMapper[node+1]),
                    subField.getContent()
            );
            
            return setFieldValueRecursivelyByMapperLevel(nextSubField, sourceField, columnNodeMapper, node+1, content);
        }
    }

    /**
     * Returns the conversion strategy for PojoConversion fetched via project configuration. When {@code true}
     * the strategy is to only convert values that were changed from the default ones on the target entity. When
     * {@code false} all fields will be converted regardless of the value of it.
     *
     * @author  Lucas Dillmann
     * @return  current conversion strategy
     * @since   7.1.0 - 2018-08-10
     */
    private boolean isOnlyConvertChangedValues() {
        return ConfigResolver
                .resolve(PojoConverterProperties.POJO_ONLY_CONVERT_CHANGED_VALUES)
                .as(Boolean.class)
                .withDefault(false)
                .getValue();
    }

    private boolean processValueIntoField(final FieldWrapper field) {
        if (field.getDeclaringInstance() != null && isProcessableField(field)) {
            try {

                if (isOnlyConvertChangedValues()) {
                    final Object currentValue = FieldReflectionHelper.fromInstance(field.getDeclaringInstance()).getFieldValue(field.getField());
                    final Object newValue = field.getContent();

                    if (Objects.equals(currentValue, newValue)) {
                        return true;
                    }
                }

                if (!FieldReflectionHelper.fromInstance(field.getDeclaringInstance()).setFieldValueBySetter(field.getField(), field.getContent())) {
                    processFinalField(field.getField());
                    
                    FieldReflectionHelper.fromInstance(field.getDeclaringInstance()).setFieldValue(field.getField(), field.getContent());
                }
            } catch(ReflectionException exception) {
                if (exception.getCause() instanceof IllegalAccessException) {
                    processFinalField(field.getField());
                    
                    FieldReflectionHelper.fromInstance(field.getDeclaringInstance()).setFieldValue(field.getField(), field.getContent());
                } else {
                    throw exception;
                }
            }
            return true;
        }
        return false;
    }

    private void processFinalField(final Field field) {
        if (forceChangeFinalField) {
            try {
                Field modifiersField = Field.class.getDeclaredField("modifiers");
                
                modifiersField.setAccessible(true);
                
                modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
                LOGGER.debug(
                        "Field '{}' from '{}' unlocked: final modifier was removed to allow conversion.",
                        field.getName(), field.getDeclaringClass().getName()
                );
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException exception) {
                throw new PojoConverterException(exception);
            }
        }
    }
    
    private boolean isProcessableField(final FieldWrapper field) {
        return !Modifier.isFinal(field.getField().getModifiers()) || !ignoreFinalField;
    }
}
