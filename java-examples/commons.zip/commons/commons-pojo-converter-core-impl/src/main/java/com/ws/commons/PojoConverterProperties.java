package com.ws.commons;

import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import org.apache.deltaspike.core.api.config.ConfigProperty;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 * Property class that determines some settings around POJO converter behavior.
 * <p>{@link ConfigProperty} is used to make all these configurations available to be changed via apache-deltaspike.properties.</p>
 * <p>Example:</p>
 * <p>When a request is sent, if you want to convert only changed values during {@link PojoConverter} process, please add</p>
 * <pre>
 *     pojo.onlyConvertChangedValues
 * </pre>
 * <p>to your DeltaSpike configuration's file.</p>
 *
 * @author  Diego Armange Costa
 * @author  Lucas Dillmann
 * @version 7.1.0 - 2018-08-10 - Added the configuration property for the conversion strategy, defining if it
 *                               should be done by using the field from DTO ou by using getter/setter methods
 * @since   6.0.0 - 2018-02-15
 * @deprecated
 */
@Deprecated
@ApplicationScoped
public class PojoConverterProperties {

    /**
     * @since 5.1.0, 2017-10-04
     */
    public static final String POJO_COLUMN_MAPPER_METADATA_CACHE_LIMIT = "pojo.column.mapper.metadata.cache.limit";

    /**
     * Determines the conversion strategy for PojoConverter. When true, the API will only migrate the values from
     * DTO object to the Entity object when the value already present in Entity is different from the value present in
     * DTO.
     *
     * @since 7.1.0 - 2018-08-10
     */
    public static final String POJO_ONLY_CONVERT_CHANGED_VALUES = "pojo.onlyConvertChangedValues";
    
    /**
     * Determines the replacement of the field name when it has mapping.
     * 
     * @see     PojoConverter
     * @see     PojoColumnMapper
     * @see     PojoColumnMapper#target()
     * @see     PojoColumnMapper#source()
     * @since   5.1.0 - 2017-10-04
     * */
    public static final String FIND_DTO_TARGET_ON_READING_FIELD_NAME = "find.dto.target.on.reading.field.name";

    @Inject
    @ConfigProperty(name = POJO_COLUMN_MAPPER_METADATA_CACHE_LIMIT, defaultValue = "10")
    private Integer pojoColumnMapperMetadataCacheLimit;
    
    @Inject
    @ConfigProperty(name = FIND_DTO_TARGET_ON_READING_FIELD_NAME, defaultValue = "false")
    private Boolean findDTOTargetOnReadingFieldName;

    @Inject
    @ConfigProperty(name = POJO_ONLY_CONVERT_CHANGED_VALUES, defaultValue = "false")
    private Boolean onlyConvertChangedValues;

    /**
     * @return  the cache limit value
     * @see     #POJO_COLUMN_MAPPER_METADATA_CACHE_LIMIT
     */
    public Integer getPojoColumnMapperMetadataCacheLimit() {
        return pojoColumnMapperMetadataCacheLimit;
    }
    
    /**
     * @return  the strategy for reading the field name
     * @see     #FIND_DTO_TARGET_ON_READING_FIELD_NAME
     */
    public Boolean getFindDTOTargetOnReadingFieldName() {
        return findDTOTargetOnReadingFieldName;
    }

    /**
     * @author  Lucas Dillmann
     * @return  if the PojoConversion should always convert all fields from DTO to the entity ones
     *          or only do the conversion on the fields where the value present in DTO is different from the one found
     *          in entity
     * @see     #POJO_ONLY_CONVERT_CHANGED_VALUES
     * @since   7.1.0 - 2018-08-10
     */
    public Boolean isOnlyConvertChangedValues() {
        return onlyConvertChangedValues;
    }
}
