package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Class created to store the field mapping {@link PojoColumnMapper} and {@link PojoColumnsMapper} information for conversions.
 *
 * @author  Diego Armange Costa
 * @version 5.3.0 - 2017-11-13 Added multiple mappings.
 * @see     #appendMultipleMapping(String, Set)
 * @see     #getSourcePaths()
 * @see     #getUnmappedPath()
 * @since   5.1.0 - 2017-10-03 *
 * @deprecated
 */
@Deprecated
public class MappingMetaData {
    
    private static final char PATH_DELIMITER = '.';
    
    private static final char PATH_SEPARATOR = ',';

    String rawPath;
    
    private final StringBuilder unmappedPath = new StringBuilder();
    
    private final Map<String, Field> mappingFields = new HashMap<>();
    
    private final Map<String, String> targetPaths = new HashMap<>();
    
    private final Map<String, String> sourcePaths = new HashMap<>();
    
    private final Map<String, Set<Field>> multipleMapping = new HashMap<>();
    
    void merge(final MappingLocatorMetadata mappingLocatorMetadata) {
        mappingLocatorMetadata.merge(this);
    }
    
    /**
     * Stores information about the field that contains mapping.
     * 
     * @param targetPath    representing the mapping({@link PojoColumnMapper#target()}) configured in the field.
     * @param field         that contains mapping(s).
     */
    void appendMapping(final String targetPath, final Field field) {
        final String sourcePath = findSourcePath(targetPath, field);
        
        appendUnmappedPath(sourcePath);
        
        mappingFields.put(targetPath, field);
        
        targetPaths.put(field.getName(), targetPath);
        
        sourcePaths.put(targetPath, sourcePath);
    }
    
    /**
     * Stores information about the field that composes a unique structure formed by multiple mappings.
     * 
     * <pre>
     *  public class Any {
     *     {@literal @PojoColumnMapper(target="child.id")}
     *      private UUID childId;
     *      
     *     {@literal @PojoColumnMapper(target="child.description")}
     *      private String childDescription;
     *  }
     *  
     *  public class anyDTO  {
     *      //Structure formed by multiple mappings.
     *      private ChildDTO child;
     *  }
     *  
     *  public class ChildDTO {
     *      private UUID id;
     *      
     *      private String description;
     *  }
     * </pre>
     * Stored information:<br>
     * <ul>
     *  <li>Path {@literal ->} "child"</li>
     *  <li>Fields(java.lang.reflect.Field) {@literal ->} id, description</li>
     * </ul>
     * <br>
     * 
     * @param targetPath    representing the mapping({@link PojoColumnMapper#target()}) configured in the field.
     * @param fields        that contains mapping(s).
     * @since               5.3.0 2017-10-03
     */
    void appendMultipleMapping(final String targetPath, final Set<Field> fields) {
        multipleMapping.put(targetPath, fields);
        
        fields.forEach(field -> appendMultipleUnmappedPath(field.getName()));
    }
    
    private void appendMultipleUnmappedPath(final String sourcePath) {
        if (unmappedPath.length() == 0) {
            unmappedPath.append(sourcePath);
        } else {
            unmappedPath.append(PATH_SEPARATOR).append(sourcePath);
        }
    }
    
    /**
     * Stores information about the field that does not contain mapping.
     * 
     * @param field that not contains mapping(s).
     */
    void appendUnmappedPathPart(final String path, final Field field) {
        final String sourcePath = findSourcePath(path, field);
        
        appendUnmappedPath(sourcePath);
    }

    private void appendUnmappedPath(final String sourcePath) {
        if (unmappedPath.length() == 0) {
            unmappedPath.append(sourcePath);
        } else {
            unmappedPath.append(PATH_DELIMITER).append(sourcePath);
        }
    }

    private String findSourcePath(final String path, final Field field) {
        final List<PojoColumnMapper> mappingAnnotation = MappingFilter
                .fromField(field)
                .fromTarget(path)
                .getMappingAnnotations();
        
        return findSourcePath(field, mappingAnnotation);
    }

    private String findSourcePath(final Field field, final List<PojoColumnMapper> mappingAnnotations) {
        if (CollectionUtils.isNotEmpty(mappingAnnotations)) {
            final PojoColumnMapper mappingAnnotation = mappingAnnotations.get(0);
            
            return StringUtils.isNotEmpty(mappingAnnotation.source()) ? mappingAnnotation.source() : field.getName();
        }
        
        return field.getName();
    }
    
    /**
     * Gets the raw path that was used to locate the mapping(s).
     *
     * @return the raw path that can contain mapping(s).<br>
     */
    public String getRawPath() {
        return rawPath;
    }
    
    /**
     * <b>Multiple fields mapped to same path:</b>
     * <pre>
     *  public class Customer {
     *     {@literal @PojoColumnMapper(target="user.id")}
     *      private UUID userId;
     *  
     *     {@literal @PojoColumnMapper(target="user.name")}
     *      private String userName;
     *  }
     *  
     *  MappingMetaData mappingMetadata = MappingLocator
     *      .fromInstance(customer)
     *      .withPath("user")
     *      .getMappingMetadata();
     * </pre>
     * <b>It would return:</b> "userId,userName"<br><br> 
     * <b>***OR***</b><br><br>
     * <b>Single fields mapped to distinct paths:</b>
     * <pre>
     *  public class Customer {
     *     {@literal @PojoColumnMapper(target="location.area")}
     *      private Area locationArea;
     *  }
     *  
     *  MappingMetaData mappingMetadata = MappingLocator
     *      .fromInstance(customer)
     *      .withPath("location.area.description")
     *      .getMappingMetadata();
     * </pre>
     * <b>It would return:</b> "locationArea.description"<br>
     * 
     * @return  when there are multiple fields mapped to same path, it will return these fields separated by comma.
     *          However, when there are just single fields mapped to distinct paths, it will return a path composed by these fields, using the dot delimiter.
     */
    public String getUnmappedPath() {
        return unmappedPath.toString();
    }

    /**
     * Key - target path as {@link PojoColumnMapper#target()}<br> 
     * Value - field object that contains any mapping.<br>
     *     
     * @return the {@link Map} containing the fields that contains any mapping.
     */
    public Map<String, Field> getMappingFields() {
        return Collections.unmodifiableMap(mappingFields);
    }

    /**
     * Key - source path as {@link PojoColumnMapper#source()}<br>
     * Value - target path as {@link PojoColumnMapper#target()}<br>
     *     
     * @return the {@link Map} containing the target paths.
     */
    public Map<String, String> getTargetPaths() {
        return Collections.unmodifiableMap(targetPaths);
    }
    
    /**
     * Key - target path as {@link PojoColumnMapper#target()}<br>
     * Value - source path as {@link PojoColumnMapper#source()}<br>
     *     
     * @return the {@link Map} containing the source paths.
     */
    public Map<String, String> getSourcePaths() {
        return Collections.unmodifiableMap(sourcePaths);
    }
    
    /**
     * The fields that are mapped under some common structure can be obtained using the flat node as key.
     * 
     * <pre>
     * public class AnyEntity {
     *    {@literal @PojoColumnMapper(target = "user.id")}
     *     private UUID userId;
     *     
     *    {@literal @PojoColumnMapper(target = "user.login")}
     *     private String userLogin;
     * }
     * 
     * {@literal Map<String, Set<Field>>} map = mappingMetaData.getMultipleMapping();
     * 
     * {@literal Set<Field>} fieldSet = map.get("user");
     * 
     * <i>The fieldSet contain the <b>userId</b> and <b>userLogin</b>s fields.</i>
     * 
     * <b>Key</b> - part of target path as {@link PojoColumnMapper#target()}
     * <i>If the full mapping target is passed instead of only the relevant part of the mapping target, nothing will be returned.
     * To these cases, use only</i> {@link #getMappingFields()}.
     * <b>Value</b> - Field Set that contains any mapping.
     * </pre>
     *
     * @return the {@link Map} containing the fields' mapping.
     */
    public Map<String, Set<Field>> getMultipleMapping() {
        return Collections.unmodifiableMap(multipleMapping);
    }
    
    /**
     * @return {@code true} if any field with any mapping was found.
     */
    public boolean hasMappingFields() {
        return !mappingFields.isEmpty() || !multipleMapping.isEmpty();
    }
}
