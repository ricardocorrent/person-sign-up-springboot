package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import org.apache.commons.lang3.StringUtils;
import org.jboss.weld.exceptions.IllegalArgumentException;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * This class is meant to find mapping annotation {@link PojoColumnMapper} from target {@link PojoColumnMapper#target()}
 * or source {@link PojoColumnMapper#source()}.
 * 
 * @author  Diego Armange Costa
 * @since   5.1.0 2017-10-05
 * @deprecated
 */
@Deprecated
public final class MappingFilter {

    private final Field field;
    
    private List<PojoColumnMapper> mappingAnnotations;
    
    private MappingFilter(final Field field) {
        this.field = field;
    }
    
    /**
     * Searches for a field annotated with the desired annotation.
     *
     * @param field where will be searched the annotation
     * @return      a {@link MappingFilter} instance with a field
     */
    public static MappingFilter fromField(final Field field) {
        Objects.requireNonNull(field, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("field"));
        
        final MappingFilter mappingFilter = new MappingFilter(field);
        
        mappingFilter.mappingAnnotations = mappingFilter.getMappings();
        
        return mappingFilter;
    }
    
    /**
     * Finds the mapping annotation {@link PojoColumnMapper} that contains a target value.
     * 
     * @param target    that was defined in mapping annotation
     * @return          a {@link MappingFilter} instance with the mapping annotation if it's found
     * 
     * @see PojoColumnMapper#target()
     */
    public MappingFilter fromTarget(final String target) {
        if (StringUtils.isEmpty(target)) {
            throw new IllegalArgumentException(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("target"));
        }
        
        mappingAnnotations.clear();
        
        getMappings()
            .stream()
            .filter(mappingAnnotation -> mappingAnnotation.target().equals(target))
            .findFirst()
            .ifPresent(mapping -> mappingAnnotations = Arrays.asList(mapping));
        
        return this;
    }

    /**
     * Finds the mapping annotation {@link PojoColumnMapper} that contains a source value.
     * 
     * @param source    that was defined in mapping annotation
     * @return          a {@link MappingFilter} instance with the mapping annotation if it's found
     * 
     * @see PojoColumnMapper#source()
     */
    public MappingFilter fromSource(final String source) {
        if (StringUtils.isEmpty(source)) {
            throw new IllegalArgumentException(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("source"));
        }
        
        mappingAnnotations.clear();
        
        getMappings().forEach(currentMapping -> {
            if (currentMapping.source().equals(source)) {
                this.mappingAnnotations = Arrays.asList(currentMapping);
                
                return;
            }
        });
        
        return this;
    }
    
    private List<PojoColumnMapper> getMappings() {
        final PojoColumnsMapper pojoColumnsMapper = field.getAnnotation(PojoColumnsMapper.class);

        final ArrayList<PojoColumnMapper> annotations = new ArrayList<>();

        if (pojoColumnsMapper != null) {
            annotations.addAll(Arrays.asList(pojoColumnsMapper.value()));
        } else {
            final PojoColumnMapper pojoColumnMapper = field.getAnnotation(PojoColumnMapper.class);

            if (pojoColumnMapper != null) {

                annotations.add(pojoColumnMapper);
            } 
        }

        return annotations;
    }
    
    /**
     * @return the field where was searched the mapping annotation {@link PojoColumnMapper}.
     */
    public Field getField() {
        return field;
    }
    
    /**
     * @return the mapping annotations found.
     */
    public List<PojoColumnMapper> getMappingAnnotations() {
        return mappingAnnotations;
    }
}
