package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;

/**
 * This class represents a key that defines a mapping search result in {@link PathKey}.
 * 
 * @author  Diego Armange Costa
 * @see     #getPath()
 * @since   5.1.0 2017-10-05
 * @deprecated
 */
@Deprecated
@SuppressWarnings("javadoc")
class PathKey {

    private final Class<?> declaringClass;
    
    private final String path;
    
    /**
     * Default constructor.
     *
     * @param declaringClass    that contains the path.
     * @param path              that represents the field.
     */
    PathKey(final Class<?> declaringClass, final String path) {
        this.declaringClass = declaringClass;
        
        this.path = path;
    }

    /**
     * @return the declaring class that contains the desired mapping.
     */
    public Class<?> getDeclaringClass() {
        return declaringClass;
    }

    /**
     * Retrieves the path that contains mappings.
     *
     * <b>Example:</b>
     * <br/>
     * <i>Field serviceId mapped to service.id.</i>
     * <pre>
     *     ...
     *         {@literal @PojoColumnMapper (target = "service.id")}
     *         private UUID serviceId;
     *     ...
     * </pre>
     * <i>With the above scenario:</i>
     * <br/>
     * <b>mappedPath</b> = service.id
     * <br/>
     * <b>unmappedPath</b> = serviceId
     *
     * @return  the path that contains mapping(s).
     * @see     PojoColumnMapper#source()
     * @see     PojoColumnMapper#target()
     */
    public String getPath() {
        return path;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((declaringClass == null) ? 0 : declaringClass.hashCode());
        result = prime * result + ((path == null) ? 0 : path.hashCode());
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        return isKeyEquals((PathKey)obj);
    }

    private boolean isKeyEquals(PathKey other) {
        if (declaringClass == null) {
            if (other.declaringClass != null) {
                return false;
            }
        } else if (!declaringClass.equals(other.declaringClass)) {
            return false;
        }
        
        if (path == null) {
            if (other.path != null) {
                return false;
            }
        } else if (!path.equals(other.path)) {
            return false;
        }
        
        return true;
    }
}
