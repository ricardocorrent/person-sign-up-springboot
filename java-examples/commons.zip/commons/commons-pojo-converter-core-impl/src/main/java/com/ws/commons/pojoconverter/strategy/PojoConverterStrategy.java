package com.ws.commons.pojoconverter.strategy;

import com.ws.commons.pojoconverter.FieldWrapper;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.IPojoConverter;


/**
 * {@link PojoConverter}'s strategy definition interface.
 *
 * <p>This functional interface provides to PojoConverter the required methods to know what actions and/or strategies
 * should be used during conversion between DTO and entity. It also enables the interception of the PojoConverter flow
 * for customized needs, allowing to stop the flow or change the field properties (like it's value) in runtime.</p>
 *
 * <p>Any implementation of this interface will be found and loaded using ServiceLoader strategy. If your application
 * needs to implement a custom strategy to control the PojoConverter flow, please read the
 * <a href="https://docs.oracle.com/javase/8/docs/api/java/util/ServiceLoader.html">JDK documentation</a> for
 * important information on how that works and how to declare inside your aplication the required files to
 * allow to PojoConverter to find your implementation.</p>
 *
 * <p>If you are in a hurry or don't want to read the documentation above, to let PojoConverter find your class
 * create the following file in your project and use the fully qualified name of your class as the content:</p>
 *
 * <pre>META-INF/services/com.ws.commons.pojoconverter.strategy.PojoConverterStrategy</pre>
 *
 * @author  Lucas Dillmann
 * @since   7.1.3 - 2018-08-17
 * @deprecated
 */
@Deprecated
public interface PojoConverterStrategy {

    /**
     * This method is called by the PojoConverter to validate if a field should be converted or not.
     *
     * <p>This method will be called before the conversion of each field in PojoConverter flow. If the returned value
     * is false, the PojoConverter will ignore the field and continue to the next one. If return is true, PojoConverter
     * will continue the flow and run it's internal secondary analysis to see if the conversion is needed.</p>
     *
     * <p>Please be aware that returning true by this method doesn't guarantee that the field will be converted.
     * For example, if the field contains no mapping (and there is no field in target class with same name)
     * or contains {@link PojoColumnIgnore} annotation, even if this method returns true it will not be converted.</p>
     *
     * <p>Last but not least, PojoConverter only supports classes which implements the {@link IPojoConverter}
     * interface. If any object which doesn't implement the interface is sent to PojoConverter, an Exception will be thrown
     * and this method will never be called, regardless of the object class has mapping annotations or not.</p>
     *
     * @param sourceObject  source object from the conversion
     * @param targetObject  target object of the conversion
     * @param fieldDetails  field details object (name, type and etc)
     * @return              result of the validation if the field should be converted or not.
     */
    boolean shouldConvert(final Object sourceObject, final Object targetObject, final FieldWrapper fieldDetails);

}
