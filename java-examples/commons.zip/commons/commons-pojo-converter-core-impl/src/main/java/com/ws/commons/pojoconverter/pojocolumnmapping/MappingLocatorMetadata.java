package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.pojoconverter.annotation.PojoColumnsMapper;
import com.ws.commons.utils.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * This class stores field mapping information {@link PojoColumnMapper} and {@link PojoColumnsMapper} grouped by class.<br/>
 * Each class can contain metadata with field and annotation information relative to the mapping used in conversion.
 * 
 * @author  Diego Armange Costa
 * @see     #getMappedMultipleFields(PathKey)
 * @since   5.1.0 2017-10-03
 * @deprecated
 */
@Deprecated
class MappingLocatorMetadata {

    private static final String PATH_SEPARATOR_REGEX = "\\.";

    private static final String PATH_SEPARATOR = ".";

    private final Map<PathKey, Field> mappedFields = new HashMap<>();
    
    private final Map<PathKey, Field> unmappedFields = new HashMap<>();
    
    private final Map<PathKey, String> targetPaths = new HashMap<>();
    
    private final Map<PathKey, Set<Field>> mappedMultipleFields = new HashMap<>();
    
    /**
     * @param key   being composed by the declaring class and the mapping target({@link PojoColumnMapper#target()}).
     * @return      the field that contains mapping(s).
     */
    Field getMappedField(final PathKey key) {
        return mappedFields.get(key);
    }
    
    /**
     * @param key   being composed by the declaring class and the field name.
     * @return      the field that not contains mapping(s).
     */
    Field getUnmappedField(final PathKey key) {
        return unmappedFields.get(key);
    }
    
    /**
     * @param key   being composed by the declaring class and the mapping source({@link PojoColumnMapper#source()}).
     * @return      the mapping target({@link PojoColumnMapper#target()}).
     */
    String getTargetPath(final PathKey key) {
        return targetPaths.get(key);
    }
    
    /**
     * The fields that are mapped under a common structure can be obtained using the flat node as key.
     * 
     * <pre>
     * public class AnyEntity {
     *    {@literal @PojoColumnMapper(target = "user.id")}
     *     private UUID userId;
     *     
     *    {@literal @PojoColumnMapper(target = "user.login")
     *     private String userLogin;
     * }
     * 
     * {@literal Set<Field>} fieldSet = mappingLocatorMetadata.getMappedMultipleFields("user");
     * 
     * <i>The fieldSet contain the <b>userId</b> and <b>userLogin</b>s fields.</i>
     * </pre>
     * 
     * @param key   being composed of the declaring class and a part of mapping target ({@link PojoColumnMapper#target()}).
     *              If the full mapping target is passed instead of only the relevant part of the mapping target, nothing will be returned.
     *              In these cases, use only {@link #getMappedField(PathKey)}.
     * @return      the fields that contains mapping(s).
     *              Considering the flat node as a part of a tree, will be returned all fields that are mapped under this structure or any hierarchical structure bellow of this.
     * @since       5.3.0 2017-10-03
     */
    Set<Field> getMappedMultipleFields(final PathKey key) {
        return mappedMultipleFields.get(key);
    }
    
    /**
     * @param annotation    as {@link PojoColumnMapper} or {@link PojoColumnsMapper}. It can be null when the field contains no mapping.
     * @param field         found in class.
     */
    void append(final Annotation annotation, final Field field) {
        if (annotation == null || hasEmptyTarget(annotation)) {
            unmappedFields.put(new PathKey(field.getDeclaringClass(), field.getName()), field);
         } else if (annotation instanceof PojoColumnsMapper) {
             PojoColumnsMapper columnsMapper = PojoColumnsMapper.class.cast(annotation);
             
             for (PojoColumnMapper columnMapper : columnsMapper.value()) {
                 buildMetadata(field, columnMapper);
             }
         } else {
             PojoColumnMapper columnMapper = PojoColumnMapper.class.cast(annotation);
             
             buildMetadata(field, columnMapper);
         }
    }

    private boolean hasEmptyTarget(final Annotation annotation) {
        if (annotation instanceof PojoColumnsMapper) {
            return ArrayUtils.isEmpty(PojoColumnsMapper.class.cast(annotation).value());
        } 
        
        return StringUtils.isEmpty(PojoColumnMapper.class.cast(annotation).target());
    }

    private void buildMetadata(Field field, PojoColumnMapper columnMapper) {
        mappedFields.put(new PathKey(field.getDeclaringClass(), columnMapper.target()), field);

        targetPaths.put(new PathKey(field.getDeclaringClass(), 
                StringUtils.isNotEmpty(columnMapper.source()) ? columnMapper.source() : field.getName()), 
                columnMapper.target());
        
        findFlatNodes(field, columnMapper);
    }

    private void findFlatNodes(final Field field, final PojoColumnMapper columnMapper) {
        if (columnMapper.target().contains(PATH_SEPARATOR)) {
            final String[] targetPathArray = columnMapper.target().split(PATH_SEPARATOR_REGEX);
            
            final String[] nodeArray = ArrayUtils.subarray(targetPathArray, 0, targetPathArray.length -1);
            
            for (int index = 0; index < nodeArray.length; index++) {
                final String flatNode = createFlatNodeUntilIndex(nodeArray, index + 1);
                
                addInSetOrCreateSet(generateKey(field, flatNode), field);
            }
        }
    }

    /*
     * Sonar: Avoid instantiating objects in loops
     * */
    private PathKey generateKey(final Field field, final String flatNode) {
        return new PathKey(field.getDeclaringClass(), flatNode);
    }

    private String createFlatNodeUntilIndex(final String[] nodeArray, int index) {
        return String.join(PATH_SEPARATOR, ArrayUtils.subarray(nodeArray, 0, index));
    }

    private void addInSetOrCreateSet(final PathKey pathKey, final Field field) {
        final Set<Field> fieldSet = mappedMultipleFields.get(pathKey);
        
        if (fieldSet != null) {
            fieldSet.add(field);
        } else {
            final Set<Field> newSet = new HashSet<>();
            
            newSet.add(field);
            
            mappedMultipleFields.put(pathKey, newSet);
        }
    }
    
    /**
     * Method to merge the {@link MappingMetaData} with this {@link MappingLocatorMetadata}, adding all information collected.
     * 
     * @param mappingMetaData to merge with this {@link MappingLocatorMetadata}
     */
    void merge(final MappingMetaData mappingMetaData) {
        mergeMappedFields(mappingMetaData);
        
        mergeUnmappedFields(mappingMetaData);
        
        mergeMappedMultipleFields(mappingMetaData);
    }
    
    private void mergeMappedFields(final MappingMetaData mappingMetaData) {
        mappedFields
            .entrySet()
                .stream()
                    .forEach(entry -> mappingMetaData.appendMapping(
                            entry.getKey().getPath(), entry.getValue()));
    }

    private void mergeUnmappedFields(final MappingMetaData mappingMetaData) {
        unmappedFields
            .entrySet()
                .stream()
                    .forEach(entry -> mappingMetaData.appendUnmappedPathPart(
                            entry.getKey().getPath(), entry.getValue()));
    }

    private void mergeMappedMultipleFields(final MappingMetaData mappingMetaData) {
        mappedMultipleFields
            .entrySet()
                .stream()
                    .forEach(entry -> mappingMetaData.appendMultipleMapping(
                            entry.getKey().getPath(), entry.getValue()));
    }
}
