package com.ws.commons.pojoconverter;

import com.ws.commons.message.IFormattedMessage;
import com.ws.commons.pojoconverter.exception.PojoConverterException;

/**
 * This class defines messages to use during the POJO conversion process.
 *
 * <p>This messages must be used in a {@link PojoConverterException} or though the logger to provide
 * useful information about the conversion process.</p>
 *
 * <pre>
 *     throw new PojoConverterException(EPojoConverterMessage.CLASS_NOT_IMPLEMENTS_INTERFACE.
 *                     getMessage(Entity.class.getName(), IPojoConverter.class.getName());
 * </pre>
 * will return en exception with message:
 * <pre>
 *     "The class Entity does not implement the IPojoConverter interface."
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @see     PojoConverter
 * @since   5.0.0 2017-06-01
 * @deprecated
 */
@Deprecated
enum EPojoConverterMessage implements IFormattedMessage {

    /**
     * Unformatted message: The class {0} does not implement the {1} interface.
     */
    CLASS_NOT_IMPLEMENTS_INTERFACE("The class {0} does not implement the {1} interface."),
    
    /**
     * Unformatted message: The target class of conversion was not found for the source class {0}.
     */
    TARGET_CLASS_NOT_FOUND_FOR_SOURCE_CLASS("The target class of conversion was not found for the source class {0}."),
    
    /**
     * The field {0} of class {1} has not been processed. It has not been mapped and has no corresponding.
     */
    UNPROCESSED_FIELD("The field {0} of class {1} has not been processed. It has not been mapped and has no corresponding."),
    
    /**
     * Unformatted message: The field {0} of class {1} is null.
     */
    NULL_FIELD("The field {0} of class {1} is null."),
    
    ;
    
    private String unformattedMessage;
    
    EPojoConverterMessage(final String unformattedMessage) {
        this.unformattedMessage = unformattedMessage;
    }
    
    /**
     * @see com.ws.commons.message.IFormattedMessage#getUnformattedMessage()
     */
    @Override
    public String getUnformattedMessage() {
        return this.unformattedMessage;
    }
}
