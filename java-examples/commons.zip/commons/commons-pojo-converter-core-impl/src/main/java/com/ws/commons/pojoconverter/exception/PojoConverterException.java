package com.ws.commons.pojoconverter.exception;

import com.ws.commons.pojoconverter.PojoConverter;

/**
 * {@link PojoConverterException} exception class.
 *
 * <p>This exception is used to encapsulate and rethrow every time an error occurs during {@link PojoConverter} process.</p>
 *
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-07
 * @deprecated
 */
@Deprecated
@SuppressWarnings("serial")
public class PojoConverterException extends RuntimeException {

    /**
     * @see RuntimeException#RuntimeException()
     */
    public PojoConverterException() {
        super();
    }
    
    /**
     * @param message   the exception message.
     * @see             RuntimeException#RuntimeException(String)
     */
    public PojoConverterException(final String message) {
        super(message);
    }
    
    /**
     * @param cause the exception cause.
     * @see         RuntimeException#RuntimeException(Throwable)
     */
    public PojoConverterException(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message   the exception message
     * @param cause     the exception cause.
     * @see             RuntimeException#RuntimeException(String, Throwable)
     */
    public PojoConverterException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
