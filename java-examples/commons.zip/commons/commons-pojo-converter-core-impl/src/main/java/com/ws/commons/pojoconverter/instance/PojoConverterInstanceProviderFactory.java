package com.ws.commons.pojoconverter.instance;

import com.ws.commons.pojoconverter.annotation.PojoInstanceProvider;
import com.ws.commons.pojoconverter.log.PojoConverterLogMarker;
import com.ws.commons.pojoconverter.provider.DefaultPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;
import com.ws.commons.utils.CDIUtils;
import com.ws.commons.utils.reflection.ClassReflectionHelper;
import com.ws.commons.utils.reflection.TypeReflectionHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.spi.BeanManager;
import java.lang.reflect.Field;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * {@link PojoConverterInstanceProvider} factory class.
 *
 * <p>This class provides simple methods to create {@link PojoConverterInstanceProvider} instances from multiple
 * possible sources.</p>
 *
 * @author  Lucas Dillmann
 * @see     PojoConverterInstanceProvider
 * @since   7.3.0 - 2018-09-10
 * @deprecated
 */
@Deprecated
class PojoConverterInstanceProviderFactory {

    private final Logger logger;

    /**
     * Package-protected default constructor with logger initialization.
     */
    PojoConverterInstanceProviderFactory() {
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Searches and returns a {@link PojoConverterInstanceProvider} instance from {@link PojoInstanceProvider} annotation in a
     * field.
     *
     * <p>This method will look into the {@link PojoInstanceProvider} annotation under the provided field (if there's any)
     * to create the {@link PojoConverterInstanceProvider} instance. When no value is provided in the annotation or
     * there isn't any annotation in the field at all, this method will simple return a null value.</p>
     *
     * <p>When a provider class can be found using the field annotation, the creation of it will be forwarded to Java
     * Reflection API. An exception will be thrown when no default public constructor is found in the target provider class.</p>
     *
     * @param field field to look into and retrieve the provider
     * @return      {@link PojoConverterInstanceProvider} found using provided field
     */
    <T> PojoConverterInstanceProvider<T> fromAnnotation(final Field field) {
        logger.debug(
                PojoConverterLogMarker.build(),
                "Trying to retrieve a provider instance using the class declared in the {} annotation in the {} field of the {} class",
                PojoInstanceProvider.class.getSimpleName(),
                field.getName(),
                field.getDeclaringClass().getName()
        );

        try {
            final PojoInstanceProvider annotation = getFieldAnnotation(field);
            return getProviderFromAnnotation(field, annotation);
        } catch (final NoSuchElementException ex) {
            return null;
        }

    }

    /**
     * Searches and returns a {@link PojoConverterInstanceProvider} instance from {@link PojoInstanceProvider} annotation in
     * the class itself.
     *
     * <p>This method will look into the {@link PojoInstanceProvider} annotation under the provided class (if there's any)
     * to create the {@link PojoConverterInstanceProvider} instance. When no value is provided in the annotation or
     * there isn't any annotation in the class at all, this method will simply return a null value.</p>
     *
     * <p>When a provider class can be found using the class annotation the creation of it will be forwarded to Java
     * Reflection API. An exception will be thrown when no default public constructor is found in the target provider class.</p>
     *
     * @param targetClass   target class to look into and retrieve the provider
     * @return              {@link PojoConverterInstanceProvider} found using provided field
     */
    <T> PojoConverterInstanceProvider<T> fromAnnotation(final Class<T> targetClass) {
        logger.debug(
                PojoConverterLogMarker.build(),
                "Trying to retrieve a provider instance using the class declared in the {} annotation in the {} class",
                PojoInstanceProvider.class.getSimpleName(),
                targetClass.getName()
        );

        try {
            final PojoInstanceProvider annotation = getClassAnnotation(targetClass);
            return getProviderFromAnnotation(targetClass, annotation);
        } catch (final NoSuchElementException ex) {
            return null;
        }
    }

    /**
     * Retrieves and validates a {@link PojoConverterInstanceProvider} instance from the given annotation of given
     * field when a custom and valid/compatible provider is found. This method never returns null, when no custom
     * provider is found or the provider isn't compatible with the field a exception will be thrown instead.
     *
     * @param field                     target field of the provider
     * @param annotation                annotation from the given field
     * @param <T>                       generic type
     * @return                          provider instance found
     * @throws NoSuchElementException   when no custom provider is found
     * @throws IllegalArgumentException when a custom provider is found that is incompatible with the target field type
     */
    private <T> PojoConverterInstanceProvider<T> getProviderFromAnnotation(
            final Field field, final PojoInstanceProvider annotation
    ) throws NoSuchElementException {

        final Class<? extends PojoConverterInstanceProvider> providerClass = annotation.value();

        if (PojoConverterInstanceProvider.class.equals(providerClass)) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "No custom provider found in {} annotation of field {} from class {}",
                    PojoInstanceProvider.class.getSimpleName(),
                    field.getName(),
                    field.getDeclaringClass().getName()
            );

            throw new NoSuchElementException();
        }

        validateProviderGenericType(providerClass, field);
        return ClassReflectionHelper.newInstanceFromClass(providerClass);

    }

    /**
     * Retrieves and validates a {@link PojoConverterInstanceProvider} instance from the given annotation of given
     * class when a custom and valid/compatible provider is found. This method never returns null, when no custom
     * provider is found or the provider isn't compatible with the field a exception will be thrown instead.
     *
     * @param clazz                     target class of the provider
     * @param annotation                annotation from the given field
     * @param <T>                       generic type
     * @return                          provider instance found
     * @throws NoSuchElementException   when no custom provider is found
     * @throws IllegalArgumentException when a custom provider is found that is incompatible with the target field type
     */
    private <T> PojoConverterInstanceProvider<T> getProviderFromAnnotation(
            final Class<?> clazz, final PojoInstanceProvider annotation
    ) throws NoSuchElementException {

        final Class<? extends PojoConverterInstanceProvider> providerClass = annotation.value();

        if (PojoConverterInstanceProvider.class.equals(providerClass)) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "No custom provider found in {} annotation of class {}",
                    PojoInstanceProvider.class.getSimpleName(),
                    clazz.getName()
            );

            throw new NoSuchElementException();
        }

        validateProviderGenericType(providerClass, clazz);
        return ClassReflectionHelper.newInstanceFromClass(providerClass);

    }

    /**
     * Validates if the given provider is able to generate instances for the given field.
     *
     * <p>This method retrieves the generic type of the given provider and validate if the type is
     * compatible with the field type. When a scenario is found where both types aren't compatible, then
     * an {@link IllegalArgumentException} will be thrown.</p>
     *
     * @param providerClass             provider class to be validated
     * @param targetField               target field to validate provider on
     * @throws IllegalArgumentException when the provider can't produce instances compatible with the given field
     */
    private void validateProviderGenericType(final Class<? extends PojoConverterInstanceProvider> providerClass,
                                             final Field targetField) {
        final Class<?> expectedType = targetField.getType();
        final Class<?> foundType = TypeReflectionHelper.getGenericTypeFromInterface(
                providerClass, PojoConverterInstanceProvider.class, 0
        );

        if (foundType == null || !expectedType.isAssignableFrom(foundType)) {
            final String foundTypeString = Optional.ofNullable(foundType)
                    .map(Class::getName)
                    .orElse("<null/not generic typed>");

            final String exceptionMessage = StringUtils.join(
                    "An incompatible type error was found within the PojoConverter flow. ",
                    "The field ", targetField.getName(), " from class ", targetField.getDeclaringClass().getName(),
                    " has a ", PojoInstanceProvider.class.getSimpleName(), " annotation that declares the instance provider",
                    " as the class ", providerClass.getName(), ", which is able to create ",
                    foundTypeString, " objects that are incompatible with the field target type, ", expectedType.getName(),
                    ". Please fix or remove the instance provider from the mentioned field annotation and try again."
            );
            throw new IllegalArgumentException(exceptionMessage);
        }
    }

    /**
     * Validates if the given provider is able to generate instances for the given class.
     *
     * <p>This methods retrieves the generic type of the given provider and validates if the type is
     * compatible with the class type. When a scenario is found where both types aren't compatible, then
     * an {@link IllegalArgumentException} will be thrown.</p>
     *
     * @param providerClass             provider class to be validated
     * @param targetClass               target class to validate provider on
     * @throws IllegalArgumentException when the provider can't produce instances compatible with the given field
     */
    private void validateProviderGenericType(final Class<? extends PojoConverterInstanceProvider> providerClass,
                                             final Class<?> targetClass) {
        final Class<?> foundType = TypeReflectionHelper.getGenericTypeFromInterface(
                providerClass, PojoConverterInstanceProvider.class, 0
        );

        if (foundType == null || !targetClass.isAssignableFrom(foundType)) {
            final String foundTypeString = Optional.ofNullable(foundType)
                    .map(Class::getName)
                    .orElse("<null/not generic typed>");

            final String exceptionMessage = StringUtils.join(
                    "An incompatible type error was found within the PojoConverter flow. The target class ",
                    targetClass.getName(),
                    " has a ", PojoInstanceProvider.class.getSimpleName(), " annotation that declares the instance provider",
                    " as the class ", providerClass.getName(), ", which is able to create ",
                    foundTypeString, " objects that are incompatible with the target class. ",
                    "Please fix or remove the instance provider from the mentioned field annotation and try again."
            );
            throw new IllegalArgumentException(exceptionMessage);
        }
    }

    /**
     * Extracts the {@link PojoInstanceProvider} annotation from the provided field, if there's one. This method
     * never returns null, when no annotation is found a {@link NoSuchElementException} will be thrown instead.
     *
     * @param field                     field to extract the annotation from
     * @return                          the annotation instance found in the field
     * @throws NoSuchElementException   when there isn't any annotation in the field
     */
    private PojoInstanceProvider getFieldAnnotation(final Field field) throws NoSuchElementException {
        final PojoInstanceProvider annotation = field.getAnnotation(PojoInstanceProvider.class);
        if (annotation == null) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "{} annotation not found in {} field of {} class. Skipping provider resolution using field.",
                    PojoInstanceProvider.class,
                    field.getName(),
                    field.getDeclaringClass().getName()
            );

            throw new NoSuchElementException();
        }

        return annotation;
    }

    /**
     * Extracts the {@link PojoInstanceProvider} annotation from the provided class, if there's one. This method
     * never returns null, when no annotation is found a {@link NoSuchElementException} will be thrown instead.
     *
     * @param clazz                     target class to extract the annotation from
     * @return                          the annotation instance found in the class
     * @throws NoSuchElementException   when there isn't any annotation in the class
     */
    private PojoInstanceProvider getClassAnnotation(final Class<?> clazz) throws NoSuchElementException {
        final PojoInstanceProvider annotation = clazz.getAnnotation(PojoInstanceProvider.class);
        if (annotation == null) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "{} annotation not found in {} class. Skipping provider resolution using target class.",
                    PojoInstanceProvider.class,
                    clazz.getName()
            );

            throw new NoSuchElementException();
        }

        return annotation;
    }

    /**
     * Searches and returns a {@link PojoConverterInstanceProvider} using CDI API.
     *
     * <p>This method will search for a {@link PojoConverterInstanceProvider} implementation using the CDI to do the
     * search and instantiation, including bean resolution when needed.</p>
     *
     * @return {@link PojoConverterInstanceProvider} found using CDI API
     */
    <T> PojoConverterInstanceProvider<T> fromCdi(final Class<T> targetType) {
        logger.debug(PojoConverterLogMarker.build(), "Trying to retrieve a provider instance using CDI");

        return CDIUtils
                .usingStaticInjection()
                .getSingleBean(
                        PojoConverterInstanceProvider.class,
                        targetType
                );
    }

    /**
     * Searches and returns a {@link PojoConverterInstanceProvider} using CDI API with given BeanManager.
     *
     * <p>This method will search for a {@link PojoConverterInstanceProvider} implementation using the CDI to do the
     * search and instantiation, including bean resolution when needed.</p>
     *
     * @param beanManager   CDI BeanManager to be used
     * @return              {@link PojoConverterInstanceProvider} found using CDI API
     */
    <T> PojoConverterInstanceProvider<T> fromCdi(final Class<T> targetType, final BeanManager beanManager) {
        logger.debug(PojoConverterLogMarker.build(), "Trying to retrieve a provider instance using CDI");

        return CDIUtils
                .usingBeanManager(beanManager)
                .getSingleBean(
                        PojoConverterInstanceProvider.class,
                        targetType
                );
    }

    /**
     * Creates and returns a default implementation of the {@link PojoConverterInstanceProvider}.
     *
     * <p>This method will create and return a default implementation of the {@link PojoConverterInstanceProvider} which
     * always tries to create an object instance by using simple Java Reflection API.</p>
     *
     * @return {@link PojoConverterInstanceProvider} with default instance creation strategy
     */
    PojoConverterInstanceProvider defaultProvider() {
        logger.debug(PojoConverterLogMarker.build(), "Retrieving a new default provider instance");
        return new DefaultPojoConverterInstanceProvider();
    }

}
