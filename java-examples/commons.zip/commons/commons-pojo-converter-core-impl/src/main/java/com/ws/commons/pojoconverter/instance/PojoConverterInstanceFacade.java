package com.ws.commons.pojoconverter.instance;

import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.log.PojoConverterLogMarker;
import com.ws.commons.pojoconverter.provider.DefaultPojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.utils.CDIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Objects;

/**
 * Facade class for instantiation-related tasks from {@link PojoConverter}.
 *
 * <p>This class holds methods related to instantiation of objects suitable to PojoConverter flow needs. In other words,
 * this class is able to correctly identify and return an object instance even when the target class is an abstract class
 * or is an interface and it can't be created directly from Java Reflection API.</p>
 *
 * @author  Lucas Dillmann
 * @see     PojoConverterInstanceProvider
 * @see     PojoConverter
 * @since   7.3.0 - 2018-09-10
 * @deprecated
 */
@Deprecated
public final class PojoConverterInstanceFacade {

    private static final Logger logger = LoggerFactory.getLogger(PojoConverterInstanceFacade.class);

    /**
     * Private constructor to avoid this class instances.
     */
    private PojoConverterInstanceFacade() {
    }

    /**
     * Searches for a provider able to create an instance of the target class, fires the provider and returns the instance.
     *
     * <p>This methods tries to create an instance compatible with the {@code targetClass} using a
     * {@link PojoConverterInstanceProvider} implementation. The provider implementation that will be used will be
     * searched using the following list of sources, sorted by precedence (bigger to lower).</p>
     * <ol>
     * <li>Provider declared in {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider} annotation on the
     * target class</li>
     * <li>Provider implementation identified using CDI API for the target class</li>
     * <li>Using {@link DefaultPojoConverterInstanceProvider} implementation</li>
     * </ol>
     *
     * <p>This method is recommended for scenarios where the target class of the conversion can hold an abstract and/or an
     * interface, where both of them can't be instantiated using simple Java Reflection API.</p>
     *
     * @param targetClass   target class of the object to be created
     * @param sourceObject  source object of the conversion, when available
     * @param <T>           generic type of the object
     * @return              created instance from the provided target class
     */
    public static <T> T createInstance(final Class<T> targetClass, final Object sourceObject) {
        Objects.requireNonNull(targetClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("targetClass"));

        logger.debug(
                PojoConverterLogMarker.build(),
                "Trying to create an instance for {} using a provider",
                targetClass.getName()
        );
        final PojoConverterInstanceProvider<T> provider = getProvider(targetClass);
        try {
            return provider.produce(targetClass, sourceObject);
        } finally {
            CDIUtils.destroy(provider);
        }
    }

    /**
     * Searches for a provider able to create an instance of the target field, fires the provider and returns the instance.
     *
     * <p>This method tries to create an instance suitable to fit inside the {@code targetField} using a
     * {@link PojoConverterInstanceProvider} implementation. The provider implementation that will be used will be
     * searched using the following list of sources, sorted by precedence (bigger to lower).</p>
     * <ol>
     * <li>Provider declared in {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider} annotation on the
     * target field</li>
     * <li>Provider declared in {@link com.ws.commons.pojoconverter.annotation.PojoInstanceProvider} annotation on the class
     * type of the target field</li>
     * <li>Provider implementation identified using CDI API for the target type of the field</li>
     * <li>Using {@link DefaultPojoConverterInstanceProvider} implementation</li>
     * </ol>
     *
     * <p>This method is recommended for scenarios where the target field of the conversion can hold an abstract and/or an
     * interface, where both of them can't be instantiated using simple Java Reflection API.</p>
     *
     * @param targetField       field from the target class of the conversion
     * @param sourceFieldValue  source value from the conversion, when available
     * @param <T>               generic field instance type
     * @return                  generated instance value from one of the provider
     */
    public static <T> T createInstance(final Field targetField,
                                       final Object sourceFieldValue) {
        Objects.requireNonNull(targetField, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("targetField"));

        logger.debug(
                PojoConverterLogMarker.build(),
                "Trying to create an instance for field {} of class {} with type {}",
                targetField.getName(),
                targetField.getDeclaringClass().getName(),
                targetField.getType().getName()
        );
        return (T) getProvider(targetField).produce(targetField.getType(), sourceFieldValue);
    }

    /**
     * Searches for a {@link PojoConverterInstanceProvider} and returns it
     *
     * <p>This method searches for a {@link PojoConverterInstanceProvider} from field annotation, returning a fallback
     * instance from {@link #getProvider(Class)} when it can't be retrieved.</p>
     *
     * @param field field to look for the declared provider using annotation
     * @return      found provider able to handle the request
     */
    private static PojoConverterInstanceProvider getProvider(final Field field) {
        logger.debug(
                PojoConverterLogMarker.build(),
                "Searching for a instance provider able to produce instances for {}",
                field.getType().getName()
        );
        final PojoConverterInstanceProviderFactory factory = new PojoConverterInstanceProviderFactory();

        final PojoConverterInstanceProvider fieldAnnotationProvider = factory.fromAnnotation(field);
        if (fieldAnnotationProvider != null) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "Found implementation {} using annotation from target field",
                    fieldAnnotationProvider.getClass().getName()
            );
            return fieldAnnotationProvider;
        }

        return getProvider(field.getType());
    }

    /**
     * Searches for a {@link PojoConverterInstanceProvider} and returns it
     *
     * <p>This method searches for a {@link PojoConverterInstanceProvider} using the target class annotation or from CDI
     * (in that order), returning a fallback instance from {@link DefaultPojoConverterInstanceProvider} when none is found. </p>
     *
     * @param targetType Target type class that the provider should be able to produce instances
     * @return Found provider able to handle the request
     */
    private static PojoConverterInstanceProvider getProvider(final Class<?> targetType) {
        logger.debug(
                PojoConverterLogMarker.build(),
                "Searching for a instance provider able to produce instances for {}",
                targetType
        );
        final PojoConverterInstanceProviderFactory factory = new PojoConverterInstanceProviderFactory();

        final PojoConverterInstanceProvider classAnnotationProvider = factory.fromAnnotation(targetType);
        if (classAnnotationProvider != null) {
            logger.debug(
                    PojoConverterLogMarker.build(),
                    "Found implementation {} using annotation from target class",
                    classAnnotationProvider.getClass().getName()
            );
            return classAnnotationProvider;
        }

        try {
            final PojoConverterInstanceProvider cdiProvider = factory.fromCdi(targetType);
            if (cdiProvider != null) {
                logger.debug(PojoConverterLogMarker.build(), "Found implementation {} using CDI", cdiProvider.getClass().getName());
                return cdiProvider;
            }
        } catch (final IllegalStateException ex) {
            logger.warn(
                    PojoConverterLogMarker.build(),
                    "CDI instance couldn't be retrieved, possibly the CDI isn't available right now. Skipping provider search using it.",
                    ex
            );
        }

        logger.debug(PojoConverterLogMarker.build(), "No custom provider found. Using the default one instead.");
        return factory.defaultProvider();
    }
}
