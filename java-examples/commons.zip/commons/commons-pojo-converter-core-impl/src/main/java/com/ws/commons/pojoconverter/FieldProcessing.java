package com.ws.commons.pojoconverter;

/**
 * This class represents the processing of fields during the conversion of POJOs.
 * 
 * @author  Diego Armange Costa
 * @since   5.0.0 2017-08-09
 * @deprecated
 */
@Deprecated
class FieldProcessing {

    private String[] fields;
    
    private boolean ignoreFields;

    /**
     * Constructor with {@code fields} initialization.
     *
     * @param fields fields to be processed
     */
    FieldProcessing(final String... fields) {
        this.fields = fields;
    }

    /**
     * Constructor with {@code ignoreFields} and {@code fields} array initialization.
     *
     * @param ignoreFields  boolean to indicate field ignoring
     * @param fields        fields to be processed
     * @deprecated          use {@link #FieldProcessing(boolean, String...)} instead
     */
    @Deprecated
    FieldProcessing(String[] fields, boolean ignoreFields) {
        this.fields = fields;
        
        this.ignoreFields = ignoreFields;
    }

    /**
     * Constructor with {@code ignoreFields} and {@code fields} array initialization.
     *
     * @param ignoreFields  boolean to indicate field ignoring
     * @param fields        fields to be processed
     */
    FieldProcessing(boolean ignoreFields, String... fields) {
        this.ignoreFields = ignoreFields;
        
        this.fields = fields;
    }

    public String[] getFields() {
        return fields;
    }

    public void setFields(String[] fields) {
        this.fields = fields;
    }

    public boolean isIgnoreFields() {
        return ignoreFields;
    }

    public void setIgnoreFields(boolean ignoreFields) {
        this.ignoreFields = ignoreFields;
    }
}
