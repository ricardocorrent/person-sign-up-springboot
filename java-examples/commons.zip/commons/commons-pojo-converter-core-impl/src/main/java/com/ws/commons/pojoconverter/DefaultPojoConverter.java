package com.ws.commons.pojoconverter;

import com.ws.commons.pojoconverter.exception.PojoConverterException;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default POJO converter interface.
 *
 * <p>This interface provides the default implementation for conversion of DTO fields into entity fields, forwarding
 * the self conversion to {@link PojoConverter}.</p>
 *
 * <pre>
 *     public class EntityDTO implements DefaultPojoConverter {
 *         ...
 *     }
 * </pre>
 * <p>will have its fields converted to</p>
 * <pre>
 *     public class Entity implements DefaultPojoConverter {
 *         ...
 *     }
 * </pre>
 * <p>when calling</p>
 * <pre>
 *     final DefaultPojoConverter defaultConverter = new DefaultPojoConverter();
 *     final EntityDTO entityDto = new EntityDTO();
 *     final Entity entity = defaultConverter.convert(Entity.class, entityDto);
 * </pre>
 *
 * @author  Diego A. Costa
 * @see     IPojoConverter
 * @since   6.0.0 - 2018-04-30
 * @deprecated
 */
@Deprecated
public interface DefaultPojoConverter extends IPojoConverter {

    Logger LOGGER = LoggerFactory.getLogger(DefaultPojoConverter.class);

    /**
     * Converts the values of this object to the generic type defined in the {@link IPojoConverter} interface declaration.
     *
     * @param targetClass   that determines the class to which the POJO will be converted
     * @param <T>           generic type that extends {@link IPojoConverter}
     * @return              converted POJO
     * @see                 PojoConverter
     * @see                 IPojoConverter
     */
    default <T extends IPojoConverter> T convert(final Class<T> targetClass) {
        if (targetClass != null) {
            LOGGER.debug("Self converting to {} using PojoConverter", targetClass.getName());
            return new PojoConverter().convert(targetClass, this);
        }
        
        throw new PojoConverterException("The targetClass cannot be null.");
    }
    
    /**
     * Converts the specific field values of this object to the generic type defined in the {@link IPojoConverter} interface declaration.
     *
     * @param targetClass   that determines the class to which the POJO will be converted
     * @param <T>           generic type that extends {@link IPojoConverter}
     * @param fields        field to convert
     * @return              converted POJO
     * @see                 PojoConverter
     * @see                 IPojoConverter
     */
    default <T extends IPojoConverter> T convert(final Class<T> targetClass, final String... fields){
        if (targetClass != null) {
            LOGGER.debug("Converting current instance to {} using only fields {}", targetClass.getName(), ArrayUtils.toString(fields));
            return new PojoConverter().convert(targetClass, this, fields);
        }
        
        throw new PojoConverterException("The targetClass cannot be null.");
    }
}
