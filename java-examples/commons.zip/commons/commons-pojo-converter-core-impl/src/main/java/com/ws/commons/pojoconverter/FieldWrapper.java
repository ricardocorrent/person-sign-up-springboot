package com.ws.commons.pojoconverter;

import com.ws.commons.pojoconverter.annotation.PojoColumnBackReference;
import com.ws.commons.pojoconverter.annotation.PojoColumnFilter;
import com.ws.commons.pojoconverter.annotation.PojoColumnIgnore;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import com.ws.commons.utils.reflection.field.FieldReflectionHelper;
import java.util.Optional;
import java.lang.reflect.Field;

/**
 * Wrapper class created to represent the {@link Field} class.
 *
 * <p>It is used to optimize the POJO conversion process.</p>
 * <p>This class provides methods to find annotated fields with {@link PojoConverter} API annotations
 * and recover its values if desired.</p>
 *
 * @author  Diego A. Costa
 * @version 5.3.1 - 2017-12-04 - Control of field reading added.
 *                               A field with a restricted getter will be read only by direct field access.
 * @since   5.0.0 - 2017-06-24
 * @deprecated
 */
@Deprecated
public class FieldWrapper {

    private Field field;
    
    private Object content;
    
    private Object declaringInstance;
    
    private String[] backReferenceAttributes;

    /**
     * Constructor with {@code field} and {@code declaringInstance} initialization.
     *
     * @param field             a {@link Field}
     * @param declaringInstance the object that contains the field
     */
    FieldWrapper(Field field, Object declaringInstance) {
        this.field = field;
        
        this.declaringInstance = declaringInstance;
        
        handleBackReference();
        
        handleValueFromField();
    }

    private void handleBackReference() {
        final PojoColumnBackReference backRefAnnot = this.field.getAnnotation(PojoColumnBackReference.class);
        
        if (backRefAnnot != null) {
            this.backReferenceAttributes = backRefAnnot.value();
        }
    }
    
    private Object handleValueFromField() {
        if (content == null && declaringInstance != null) {
            try {
                content = FieldReflectionHelper.fromInstance(declaringInstance).getFieldValueByGetterIgnoringConvention(field);
                
                if (FieldReflectionHelper.MethodReturnStatus.METHOD_NOT_FOUND == content) {
                    content = FieldReflectionHelper.fromInstance(declaringInstance).getFieldValue(field.getName());
                }
            } catch(ReflectionException exception) {
                if (exception.getCause() instanceof IllegalAccessException) {
                    content = FieldReflectionHelper.fromInstance(declaringInstance).getFieldValue(field.getName());
                } else {
                    throw exception;
                }
            }
        }

        return content;
    }

    /**
     * Instantiate a {@link FieldProcessing} for the current field if it is not ignored by {@link PojoConverter}.
     *
     * @return a {@link FieldProcessing} instance for a field
     */
    public FieldProcessing getFieldProcessing() {
        PojoColumnFilter filterAnnot = this.field.getAnnotation(PojoColumnFilter.class);
        
        if (filterAnnot == null) {
            PojoColumnIgnore ignore = this.field.getAnnotation(PojoColumnIgnore.class);
            
            return ignore != null ? new FieldProcessing(true, ignore.fields()) : new FieldProcessing();
        }
        
        return new FieldProcessing(filterAnnot.value());
    }

    /**
     * Looks for {@link PojoColumnIgnore} annotation in field and returns if it's ignored during {@link PojoConverter}
     * process.
     *
     * @return the target class when the field is not ignorable, {@code null} otherwise
     */
    public Class<?>[] getPojoColumnIgnoreValue() {
        PojoColumnIgnore ignoreAnnot = this.field.getAnnotation(PojoColumnIgnore.class);
        
        return ignoreAnnot != null ? ignoreAnnot.value() : null;
    }

    /**
     * Searches for fields annotated with {@link PojoColumnIgnore} annotation.
     *
     * @return a {@link String} array that stores all fields with {@link PojoColumnIgnore} annotation
     */
    public String[] getPojoColumnIgnoreFields() {
        PojoColumnIgnore ignoreAnnot = this.field.getAnnotation(PojoColumnIgnore.class);
        
        return ignoreAnnot != null ? ignoreAnnot.fields() : null;
    }

    public Optional<PojoColumnMapper> getMapping() {
        return Optional.ofNullable(field.getAnnotation(PojoColumnMapper.class));
    }

    /**
     * Checks if the current field is annotated with {@link PojoColumnBackReference}.
     *
     * @return {@code true} if field is annotated with {@link PojoColumnBackReference}
     */
    public boolean isBackReference() {
        return this.field.getAnnotation(PojoColumnBackReference.class) != null;
    }
    
    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public Object getDeclaringInstance() {
        return declaringInstance;
    }

    public void setDeclaringInstance(Object declaringInstance) {
        this.declaringInstance = declaringInstance;
    }

    public String[] getBackReferenceAttributes() {
        return backReferenceAttributes;
    }
}
