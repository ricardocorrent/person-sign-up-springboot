package com.ws.commons.pojoconverter.provider;

import com.ws.commons.pojoconverter.log.PojoConverterLogMarker;
import com.ws.commons.pojoconverter.PojoConverter;
import com.ws.commons.utils.reflection.ClassReflectionHelper;
import com.ws.commons.utils.reflection.exception.ReflectionException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default fallback implementation for {@link PojoConverterInstanceProvider}.
 *
 * <p>This implementation acts as the default and fallback implementation of a {@link PojoConverterInstanceProvider}.
 * When used, this class doesn't do any special treatment to create the objects instances, it just uses Java Reflection
 * API to get it done.</p>
 *
 * <p>As mentioned before, this is a default fallback implementation and should only be used when no other specific
 * implementation is found since it can't handle special cases, like abstract or interfaces that can't be instantiated
 * using the Reflection API.</p>
 *
 * @author  Lucas Dillmann
 * @see     PojoConverterInstanceProvider
 * @see     PojoConverter
 * @since   7.3.0 - 2018-09-10
 * @deprecated
 */
@Deprecated
public class DefaultPojoConverterInstanceProvider implements PojoConverterInstanceProvider<Object> {

    private final Logger logger;

    /**
     * Default constructor
     */
    public DefaultPojoConverterInstanceProvider() {
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Produces an instance compatible with the given target class.
     *
     * <p>This methods will simple use the provided target class to send to Java Reflection API to create an instance
     * since it is a default behaviour/implementation. Any exception thrown by the API will not be handled here.</p>
     *
     * @param targetClass       target class where a instance is needed
     * @param sourceFieldValue  source value being converted
     * @return                  object instance to be used in the target field of the conversion
     */
    @Override
    public Object produce(final Class<?> targetClass,
                          final Object sourceFieldValue) {
        logger.debug(
                PojoConverterLogMarker.build(),
                "Creating a simple {} instance using Java Reflection API",
                targetClass.getName()
        );

        try {
            return ClassReflectionHelper.newInstanceFromClass(targetClass);
        } catch (final ReflectionException ex) {
            final String exceptionMessage = StringUtils.join(
                    "Failed to create a ", targetClass.getName(), " instance using simple Java Reflections API. ",
                    "Maybe the target class is a abstract class or a interface, if that's the case you can use a custom ",
                    "PojoConverter instance provider for any field using it. If isn't a abstract class or a interface, ",
                    "please check if the class has a public default constructor."
            );

            throw new IllegalArgumentException(exceptionMessage, ex);
        }
    }
}
