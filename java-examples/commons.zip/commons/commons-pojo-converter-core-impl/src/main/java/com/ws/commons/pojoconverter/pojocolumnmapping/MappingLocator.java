package com.ws.commons.pojoconverter.pojocolumnmapping;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.ws.commons.PojoConverterProperties;
import com.ws.commons.message.EDefaultMessage;
import com.ws.commons.pojoconverter.IPojoConverter;
import com.ws.commons.pojoconverter.annotation.PojoColumnMapper;
import com.ws.commons.utils.Numbers;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigResolver;

import java.lang.reflect.Field;
import java.util.Objects;
import java.util.Set;

/**
 * This class is meant to find and generate metadata of mappings.
 *
 * <p>The following process is used to locate and retrieve metadata from a DTO:</p>
 * <pre>
 *     final MappingMetaData metaData = MappingLocator.fromClass(AnyDTO.class)
 *                                                    .withoutPath()
 *                                                    .getMappingMetadata();
 * </pre>
 *
 * @author  Diego Armange Costa
 * @version 5.3.0 - 2017-11-16 - Added multiple mapped fields feature.
 * @since   5.1.0 2017-10-02
 * @deprecated
 */
@Deprecated
public final class MappingLocator {
    private static final String PATH_DELIMITER = ".";

    private static final String PATH_DELIMITER_REGEX = "\\.";
    
    private static final LoadingCache<Class<?>, MappingLocatorMetadata> METADATA_CACHE;
    
    private final Class<?> declaringClass;

    private MappingLocatorMetadata mappingLocatorMetadata = new MappingLocatorMetadata();
    
    private final MappingMetaData mappingMetadata = new MappingMetaData();
    
    static {
        final Integer maximumCacheSize = ConfigResolver.resolve(PojoConverterProperties.POJO_COLUMN_MAPPER_METADATA_CACHE_LIMIT)
            .as(Integer.class)
            .withCurrentProjectStage(true)
            .withDefault(10)
            .getValue();
        
        METADATA_CACHE = CacheBuilder.newBuilder()
                .maximumSize(maximumCacheSize)
                .build(new CachedMappingLocatorMetadata());
    }

    private MappingLocator(final Class<?> declaringClass) {
        this.declaringClass = declaringClass;
    }
    
    private MappingLocator(final IPojoConverter declaringInstance) {
        this.declaringClass = declaringInstance.getClass();
    }
    
    /**
     * Creates an instance of {@link MappingLocator} containing the {@code declaringClass};
     *
     * @param declaringClass    that contains the desired mapping.
     * @return                  a {@link MappingLocator} instance containing the declaring class.
     */
    public static MappingLocator fromClass(final Class<?> declaringClass) {
        Objects.requireNonNull(declaringClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringClass"));
        
        return new MappingLocator(declaringClass);
    }
    
    /**
     * Creates an instance of a {@link MappingLocator} containing the {@code declaringInstance}.
     *
     * @param <T>               generic type that extends {@link IPojoConverter}.
     * @param declaringInstance that contains the desired mapping.
     * @return                  a {@link MappingLocator} instance containing the declaring instance and declaring class.
     */
    public static <T extends IPojoConverter> MappingLocator fromInstance(final T declaringInstance) {
        Objects.requireNonNull(declaringInstance, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("declaringInstance"));
        
        return new MappingLocator(declaringInstance);
    }

    /**
     * Creates the metadata corresponding to the path argument.
     *  
     * @param path  that contains any mapped({@link PojoColumnMapper#target()}) field.
     * @return      a {@link MappingLocator}'s instance, containing the path that have mappings.
     */
    public MappingLocator withPath(final String path) {
        Objects.requireNonNull(path, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("path"));
        
        if (StringUtils.isEmpty(path)) {
            throw new IllegalArgumentException(EDefaultMessage.PARAMETER_CANNOT_BE_EMPTY.getMessage("path"));
        }
        
        mappingMetadata.rawPath = path;
        
        generateMappingMetadata(declaringClass, mappingMetadata.getRawPath());
        
        return this;
    }
    
    private void generateMappingMetadata(final Class<?> declaringClass, final String rawPath) {
        mappingLocatorMetadata = METADATA_CACHE.getUnchecked(declaringClass);
        
        findMappingInPath(declaringClass, rawPath);
    }

    /**
     * @since 5.1.0 - 2017-10-02
     */
    private void findMappingInPath(final Class<?> declaringClass, final String targetPath) {
        final String[] splittedRawPath = targetPath.split(PATH_DELIMITER_REGEX);
        
        final PathKey key = key(declaringClass, targetPath);
        
        final Field mappedField = mappingLocatorMetadata.getMappedField(key);

        if (mappedField != null) {
            mappingMetadata.appendMapping(targetPath, mappedField);
        } else {
            final Set<Field> fields = mappingLocatorMetadata.getMappedMultipleFields(key);
            
            if (CollectionUtils.isNotEmpty(fields)) {
                mappingMetadata.appendMultipleMapping(targetPath, fields);
            } else {
                findMappingInSubPath(declaringClass, splittedRawPath);
            }
        }
    }

    private void findMappingInSubPath(final Class<?> declaringClass, final String[] splittedRawPath) {
        for (int partToCompose = 0; partToCompose < splittedRawPath.length; partToCompose++) {
            final String path = composeUntilAt(splittedRawPath, partToCompose);
            
            Field fieldMatched = handlePathAsTarget(declaringClass, path);
                    
            if (fieldMatched == null) {
                fieldMatched = handlePathNotAsTarget(declaringClass, path);
            }
            
            if (fieldMatched != null) {
                final String subPath = String.join(PATH_DELIMITER, composeStartingBy(splittedRawPath, partToCompose));
                
                generateMappingMetadata(fieldMatched.getType(), subPath);
                
                break;
            }
        }
    }
    
    private String composeUntilAt(final String[] splittedMappedPath, int partToCompose) {
        if (partToCompose > 0) {
            return String.join(PATH_DELIMITER, ArrayUtils.subarray(splittedMappedPath, 0, partToCompose));
        }

        return splittedMappedPath[partToCompose];
    }

    private Field handlePathAsTarget(final Class<?> declaringClass, final String path) {
        final PathKey key = key(declaringClass, path);
        
        Field mappedField = mappingLocatorMetadata.getMappedField(key);
        
        String targetPath = null;
        
        if (mappedField == null) {
            targetPath = mappingLocatorMetadata.getTargetPath(key);
            
            mappedField = mappingLocatorMetadata
                    .getMappedField(key(declaringClass, targetPath));
        }
        
        if (mappedField != null) {
            mappingMetadata.appendMapping(targetPath != null ? targetPath: path, mappedField);
        }
        
        return mappedField;
    }
    
    private Field handlePathNotAsTarget(final Class<?> declaringClass, final String path) {
        final PathKey key = key(declaringClass, path);
        
        final Field unmappedField = mappingLocatorMetadata.getUnmappedField(key);
        
        if (unmappedField != null) {
            mappingMetadata.appendUnmappedPathPart(path, unmappedField);
        }
        
        return unmappedField;
    }
    
    private PathKey key(final Class<?> declaringClass, final String mappedPath) {
        return new PathKey(declaringClass, mappedPath);
    }
    
    private String[] composeStartingBy(final String[] splittedMappedPath, int partToCompose) {
        if (partToCompose == 0) {
            return ArrayUtils.removeAll(splittedMappedPath, 0);
        } else {
            return ArrayUtils.removeAll(splittedMappedPath, Numbers.range(partToCompose));
        }
    }
    
    /**
     * Generates a {@link MappingLocator} instance, with all the available mappings.
     *
     * @return  a {@link MappingLocator}'s instance, containing all the mappings found.
     * @since   5.3.0 - 2017-11-16
     */
    public MappingLocator withoutPath() {
        generateMappingMetadata(declaringClass);
        
        return this;
    }
    
    /**
     * @since 5.3.0 - 2017-11-16
     */
    private void generateMappingMetadata(final Class<?> declaringClass) {
        mappingLocatorMetadata = METADATA_CACHE.getUnchecked(declaringClass);
        
        mappingMetadata.merge(mappingLocatorMetadata);
    }
    
    /**
     * @return the metadata containing information about the mappings found.
     */
    public MappingMetaData getMappingMetadata() {
        return mappingMetadata;
    }
}
