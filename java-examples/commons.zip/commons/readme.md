# Backend Foundation

Também conhecida como `commons`, a Backend Foundation é uma biblioteca que visa auxiliar o desenvolvimento de serviços 
de backend fornecendo um conjunto de ferramentas e APIs.

## Introdução

Este documento tem como intuito servir como um ponto de partida para o uso e entendimento da Backend Foundation. Aqui
você encontrará informações importantes, guias, exemplos, boas práticas e recomendações. **Se você está caindo agora de 
paraquedas no mundo Wealth Systems, este documento é um excelente ponto de partida para você quando o assunto é backend.**

É importante destacar que o aprofundamento de como as coisas funcionam ou por que não é o intuito deste documento. Esses 
detalhes assim como informações mais técnicas podem ser encontrados no [JavaDoc](#javadoc) do projeto. O link está logo 
abaixo, na seção de links úteis.

Esta é a segunda versão deste arquivo. Se você gostaria de consultar a versão anterior você pode encontrar ela 
[aqui](old-readme.md).

## Links úteis

- [Artefatos no repositório Nexus](http://nexus.wssim.com.br/#browse/search/custom=group.raw%3Dbr.com.wealthsystems%20AND%20keyword%3Dcommons-*)
- [Histórico de alterações](changes.md)
- [Histórico de versões](https://gitlab.wssim.com.br/platform/commons/tags)

## JavaDoc

Cada módulo da Backend Foundation possui o seu JavaDoc. A relação abaixo contém os links para eles.

- [Geral (raiz do projeto)](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons/index.html)
- [Core](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-core/index.html)
- [Management](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-management/index.html)
- [Management Security](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-management-security/index.html)
- [Health Check](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-management-healthcheck/index.html)
- [Message](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-message/index.html)
- [MessageBundle (i18n)](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-message-bundle/index.html)
- [Metrics](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-metrics/index.html)
- [Persistence Model](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-persistence-model/index.html)
- [PojoConverter API](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-api/index.html)
- [PojoConverter Core](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-core-impl/index.html)
- [PojoConverter Ebean Integration](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-ebean-impl/index.html)
- [Quartz](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-quartz/index.html)
- [Remote Config](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-remote-config/index.html)
- [Security](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-security/index.html)
- [Jetty](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-jetty/index.html)
- [JSON](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-json/index.html)
- [Pagination](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-pagination/index.html)
- [Patch API](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-patch-api/index.html)
- [Patch Json Merge Patch](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-patch-jsonmergepatch/index.html)
- [Patch Json Patch](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-patch-jsonpatch/index.html)
- [Utils](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-utils/index.html)
- [Validation](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-validation/index.html)


## Índice

- [Iniciando um novo projeto](#iniciando-um-novo-projeto)
    - [Criando um projeto vazio do Gradle](#criando-um-projeto-vazio-do-gradle)
    - [Inclusão da Backend Foundation como dependência](#inclusão-da-backend-foundation-como-dependência)
    - [Classes de apoio](#classes-de-apoio)
    - [Configuração da Backend Foundation](#configuração-da-backend-foundation)
- [Configuração](#configuração)
    - [Estágios de configuração](#estágios-de-configuração)
    - [Opções de configuração da Backend Foundation](#opções-de-configuração-da-backend-foundation)
    - [Configuração centralizada](#configuração-centralizada)
        - [Funcionamento](#funcionamento-da-configuração-centralizada)
        - [Tipos de repositórios remotos suportados](#tipos-de-repositórios-remotos-suportados)
- [Funcionalidades disponíveis](#funcionalidades-disponíveis)
    - [Container HTTP](#container-http)
    - [Internacionalização](#internacionalização)
    - [Segurança](#segurança)
        - [Acesso aos dados do usuário autenticado](#acesso-aos-dados-do-usuario-autenticado)
    - [Paginação](#paginação)
    - [Clientes de integração](#clientes-de-integração)
        - [Customização das chamadas de clientes de integração](#customização-das-chamadas-de-clientes-de-integração)
    - [Requisição HTTP com JAX-RS client API](#requisição-http-com-jax-rs-client-api)
    - [Injeção de lista de tenants disponíveis](#injeção-de-lista-de-tenants-disponíveis)
    - [Criador de sessão](#criador-de-sessão)
    - [Warm Up](#warm-up)
    - [Resources REST](#resources-rest)
        - [Mapeamento de exceções](#mapeamento-de-exceções)
        - [Requisições PATCH](#requisições-patch)
    - [Services](#services)
    - [RestQuery](#restquery)
        - [Funcionamento da RestQuery](#funcionamento-da-restquery)
        - [Sintaxe da RestQuery](#sintaxe-da-restquery)
        - [Personalização da deserialização da RestQuery](#personalização-da-deserialização-da-restquery)
        - [Integração da RestQuery com o DAO](#integração-da-restquery-com-o-dao)
        - [Retrocompatibilidade](#retrocompatibilidade)
    - [PojoConverter](#pojoconverter)
        - [Personalização dos objetos criados pelo PojoConverter](#personalização-dos-objetos-criados-pelo-pojoconverter)
        - [Conversão automática em resources REST](#conversão-automática-em-resources-rest)
    - [Persistência](#persistência)
        - [DAO](#dao)
        - [Controle automático de transações usando anotações](#controle-automático-de-transações-usando-anotações)
        - [Escuta por eventos de persistência](#escuta-por-eventos-de-persistência)
        - [Multitenancy](#multitenancy)
        - [Data source e pool de conexões](#data-source-e-pool-de-conexões)
        - [Reciclagem de entidades](#reciclagem-de-entidades)
    - [Validação](#validação)
        - [Logic validator](#logic-validator)
        - [Bean validation integrated](#bean-validation-integrated)
        - [Grupos de validações](#grupos-de-validações)
        - [Constraints adicionais disponíveis](#constraints-adicionais-disponíveis)
    - [Log](#log)
        - [Rastreamento de comunicação REST (requisições e respostas)](#log-requests)
    - [Serialização e deserialização (JSON)](#serialização-e-deserialização-json)
    - [CDI](#cdi)
    - [Coleta e publicação de métricas](#coleta-e-publicação-de-métricas)
        - [Funcionamento da API de métricas](#funcionamento-da-api-de-métricas)
        - [Implementações disponíveis para uso](#implementações-disponíveis-para-uso)
            - [Repórters](#reporters)
            - [Coletores](#coletores)
        - [Passo-a-passo e exemplos de uso da API de métricas](#passo-a-passo-e-exemplos-de-uso-da-api-de-métricas)
            - [Métricas em resources REST](#metricas-em-resources-rest)
    - [Gerenciamento remoto](#gerenciamento-remoto)
        - [Publicação de recursos na API de gerenciamento remoto](#publicação-de-recursos-na-api-de-gerenciamento-remoto)
        - [Health Check](#health-check)
- [Outras informações úteis](#outras-informações-úteis)

## Iniciando um novo projeto

Um novo projeto usando a Backend Foundation pode ser criado usando alguns passos simples. É importante entretanto que 
você leia algumas das seções deste manual antes de começarmos:

- [Configuração](#configuração)
- [Opções de configuração da Backend Foundation](#opções-de-configuração-da-backend-foundation)

De conhecimento das informações acima, a criação de um novo projeto pode resumir-se a:
1. Criação de um projeto vazio com o Gradle
2. Inclusão da Backend Foundation como dependência
3. Criação das classes de apoio
4. Configuração da Backend Foundation

### Criando um projeto vazio do Gradle

Um novo projeto do Gradle pode ser criado usando sua IDE compatível de preferência ou linha de comando. As 
orientações detalhadas estão disponíveis [no site do projeto](https://guides.gradle.org/building-java-applications/).

### Inclusão da Backend Foundation como dependência

Compilações da Backend Foundation estão disponíveis no [repositório da Wealth Systems](http://nexus.wssim.com.br/#browse/search/custom=group.raw%3Dbr.com.wealthsystems%20AND%20keyword%3Dcommons-*).
Lembre-se de adicionar ele como repositório do seu projeto no arquivo `build.gradle`.

```groovy
buildscript {
    repositories {
        maven { url 'http://nexus.wssim.com.br/repository/cloud-all/' }
    }
}
repositories {
    maven { url 'http://nexus.wssim.com.br/repository/cloud-all/' }
}

``` 

Depois de configurado os repositórios você já pode incluir a Backend Foundation como dependência. O exemplo abaixo 
utiliza a versão 7.4.0, lembre-se de conferir qual é a versão mais recente e usar ela no lugar.

```groovy
dependencies {
    compile "br.com.wealthsystems:commons:7.4.0"
}
```

### Classes de apoio

Algumas classes são necessárias para a Backend Foundation funcionar. Elas servem como apoio fornecendo dados importantes,
como os de usuários e permissões.

- `Main`: Responsável por inicializar o projeto

```java
public class Main {
    
    public static void main(String[] args) {
        JettyServer.start();
    }
}
```

- `Application`: Responsável por aplicar configurações JAX-RS padrão no projeto e permitir a personalização delas

```java
public class Application extends ResourceConfig {
    
    public Application() {
        
        final ApplicationConfig applicationConfig = ApplicationConfig.setResourceConfig(this);
        applicationConfig.registerPackage(getClass().getPackage().getName());
        applicationConfig.configureJersey();
    }
    
}
```

- `ApplicationRestAuthorizationRealm`: Responsável por fornecer os dados de autenticação e de permissões de acesso. 
O exemplo abaixo depende do cliente de integração do serviço do user.

```java
public class UserGateway {

    @InjectProxy
    private UserResource resource;

    @Inject
    private ObjectMapper objectMapper;

    public SimpleAuthorizationInfo getPermissions() {
        final Response response = resource.permission();
        if (response == null || response.getStatus() != HttpStatus.SC_OK) {
            throw new RuntimeException("Error reading user permissions from service. Response is invalid.");
        }

        final InputStream responseContent = (InputStream) response.getEntity();
        try {
            return objectMapper.readValue(responseContent, SimpleAuthorizationInfo.class);
        } catch (final IOException ex) {
            throw new RuntimeException("Error reading user permissions from service", ex);
        }
    }
}

public class ApplicationRestAuthorizationRealm extends RestAuthorizationRealm {

    @Override
    protected SimpleAuthorizationInfo getSimpleAuthorizationInfo() throws IOException {
        return CDI.current().select(UserGateway.class).get().getPermissions();
    }
}
```

### Configuração da Backend Foundation

Algumas configurações são necessárias para que a Backend Foundation possa inicializar corretamente. O trecho abaixo
contém elas, personalize os valores conforme necessário. Para a relação completa de configurações consulte
[este link](configuration-options.md).

- `resources/META-INF/apache-deltaspike.properties`: Propriedades de configuração da Backend Foundation

```properties
# PROJECT 
org.apache.deltaspike.ProjectStage=Development
org.apache.deltaspike.LogLevel="warn"

# CONTAINER
port=8080

service.version=v1
service.name=example
authorization.service.api=/api/user/users/self-permissions
integration.address=http://example.com
host=http://example.com

# DATABASE
db.url=jdbc:postgresql://localhost/example
db.username=postgres
db.password=example

# SESSION CREATOR
redis.session.user=admin@cloud.com

# REDIS
redis.host=redis.example.com
redis.port=6371
redis.expire=1000
redis.timeout=0
```

- `resources/shiro.ini`: Configuração da autenticação e segurança via Apache Shiro

```
[main]
redisManager = com.ws.shiro.RedisManager

redisSessionDAO = com.ws.shiro.RedisSessionDAO
redisSessionDAO.redisManager = $redisManager
sessionManager = org.apache.shiro.web.session.mgt.DefaultWebSessionManager
sessionManager.sessionDAO = $redisSessionDAO
securityManager.sessionManager = $sessionManager

cacheManager = com.ws.shiro.RedisCacheManager
cacheManager.redisManager = $redisManager
securityManager.cacheManager = $cacheManager

authRealm = <project realm class goes here>
securityManager.realm = $authRealm

[users]

[filters]

[urls]

```

- `resources/META-INF/beans.xml`: Configurações do CDI para o projeto

```xml
<?xml version="1.0" encoding="utf-8"?>
<beans xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns="http://xmlns.jcp.org/xml/ns/javaee"
       xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee
        http://xmlns.jcp.org/xml/ns/javaee/beans_1_1.xsd"
       bean-discovery-mode="all">
</beans>
```

- `resources/WEB-INF/web.xml`: Configurações dos serviços web (filtragem, servlet e outros)

```xml
<?xml version="1.0" encoding="utf-8"?>
<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://java.sun.com/xml/ns/javaee"
         xsi:schemaLocation="http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd"
         version="3.0">

    <servlet>
        <servlet-name>rest-application</servlet-name>
        <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
        <init-param>
            <param-name>javax.ws.rs.Application</param-name>
            <param-value>your.project.package.Application</param-value>
        </init-param>
    </servlet>

    <servlet-mapping>
        <servlet-name>rest-application</servlet-name>
        <url-pattern>/api/project-name/*</url-pattern>
    </servlet-mapping>

    <context-param>
        <param-name>shiroConfigLocations</param-name>
        <param-value>classpath:shiro.ini</param-value>
    </context-param>

    <listener>
        <listener-class>org.apache.shiro.web.env.EnvironmentLoaderListener</listener-class>
    </listener>

    <filter>
        <filter-name>ShiroFilter</filter-name>
        <filter-class>org.apache.shiro.web.servlet.ShiroFilter</filter-class>
    </filter>

    <filter-mapping>
        <filter-name>ShiroFilter</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>

</web-app>
```

## Configuração

A configuração de projetos usando a Backend Foundation é feita utilizando a API da [Apache Deltaspike](https://deltaspike.apache.org/).
O arquivo de propriedades padrão fica localizado em `META-INF/apache-deltaspike.properties` no projeto e é um arquivo
baseado em chave-valor.

```properties
chave=valor
```
```properties
example.configuration.loremIpsum=test
example.configuration.otherValue=25
```

As propriedades de configuração são obtidas de diversas fontes na configuração padrão e o arquivo mencionado acima é
apenas uma delas. A relação abaixo contém elas em ordem de precedência.

- Propriedades do sistema
- Propriedades do ambiente
- Valores JNDI
- Arquivo de configuração em `META-INF/apache-deltaspike.properties` do projeto
- Arquivo de configuração na pasta home do usuário em `~/.deltaspike/apache-deltaspike.properties`

Essa precedência pode ser utilizada em cenários em que a configuração muda conforme o ambiente. Em outras palavras,
pode-se usar de variáveis de ambiente que possuem uma precedência maior para sobreescrever propriedades definadas
em arquivo de configuração. 

**É importante salientar que o Deltaspike permite que pontos sejam substituidos por underline ao usar as 
variáveis de ambiente quando o shell em uso não suporta os pontos, mas ele ainda irá diferenciar minúsculas de 
maiúsculas**. Ou seja, a chave `example.testValue` pode ser usada como `example_testValue` mas não pode ser declarada
como `EXAMPLE_TESTVALUE`.

### Estágios de configuração

O Deltaspike fornece um mecanismo de estágios de configuração. Esse mecanismo permite mudar um conjunto de propriedades 
baseado no estágio de desenvolvimento. 

A identificação do estágio é feita adicionando o nome do estágio ao final da chave de configuração. A omissão do nome
do estágio na chave significa que aquele valor é o valor padrão.

```properties
org.apache.deltaspike.ProjectStage=Production

example.database.host=localhost
example.database.host.Production=prodserver
example.database.host.Tests=testserver
example.database.host.Staging=stgserver
```

É importante salientar de que o valor definido em um estágio tem maior precedência sobre valores padrão (sem estágio).

### Opções de configuração da Backend Foundation

A relação completa de chaves de configuração utilizadas pela Backend Foundation pode ser consultada [neste link](configuration-options.md).

### Configuração centralizada

A Backend Foundation permite que valores de configuração sejam resolvidos usando um repositório central remoto. Essa
possibilidade é fornecida pelo módulo `commons-remote-config` que disponibiliza uma extensão para a API do Apache Deltaspike 
com essa funcionalidade. 

#### Funcionamento da configuração centralizada

A API deste módulo funciona baseada em 2 classes principais:

- Classe `RemoteConfigSource`: Atua como uma ponte entre a API de resolução remota de configuração e a API do Deltaspike.
Ela implementa a interface `ConfigSource` do Deltaspike e é registrada automaticamente usando SPI.
- Interface `RemoteConfigProvider`: Abstração usada pela `RemoteConfigSource` para obter os dados dos repositórios 
remotos. A implementação `GitRemoteConfigProvider`, por exemplo, é uma implementação da interface capaz de obter
os valores de configuração de um repositório Git.

A classe `RemoteConfigSource` não substitui as demais implementações de `ConfigSource` no contexto do Deltaspike, apenas
complementa eles. Isso significa que a API vai atuar como um complemento ao atual mecanismo de resolução do Deltaspike
respeitando a ordem de precedência a seguir:

0. Propriedades do sistema (ordinal 400)
0. Variáveis do ambiente (ordinal 300)
0. Valores JNDI (ordinal 200)
0. **Repositório central remoto (ordinal 150)**
0. Arquivo de configuração no projeto (ordinal 100)
0. Arquivo de configuração na pasta home do usuário (ordinal 100)

Ainda que o módulo esteja habilitado por padrão, o uso de um repositório remoto requer configurações adicionais. Em
outras palavras, a configuração padrão é usar o provedor `NoOpRemoteConfigSource` que, como o nome indica, não faz nada.

**Confira os detalhes de como configurar o módulo [aqui](configuration-options.md#configuração-centralizada).**

#### Tipos de repositórios remotos suportados

A implementação do módulo fornece três implementações padrão para uso de repositórios remotos:

- `HttpRemoteProvider`: Implementação simplificada que resolve valores de configuração usando um serviço REST
HTTP remoto. Quando um valor não está disponível em seu cache interno, a implementação dispara uma solicitação HTTP GET
para um serviço remoto para obter o valor necessário.
- `GitRemoteProvider`: Implementação capaz de ler arquivos de propriedades Java em repositórios Git remotos.
- `ConfigServerProvider`: Implementação capaz de resolver propriedades de configuração usando um servidor baseado em 
Spring Cloud Config Server. 

Cada uma das implementações acima requer configurações adicionais, como o endereço do repositório que deve ser usado.
Confira os detalhes de configuração delas [aqui](configuration-options.md#configuração-centralizada)

Para cenários em que as implementações padrão não são adequadas, a interface `RemoteProvider` permite implementaçeõs
personalizadas para a resolução de valores de outros tipos de repositórios.


## Funcionalidades disponíveis

A relação abaixo contém informações importantes e úteis a respeito de cada funcionalidade oferecida pela Backend Foundation. 

### Container HTTP

A Backend Foundation fornece um container HTTP usando o `Jetty` como provedor. O container é automaticamente configurado
e integrado aos demais recursos, como o JAX-RS, e seu uso resume-se em inicializar ele. 

O trecho abaixo contém um exemplo de como fazer isso. Geralmente esse trecho será chamado no `psvm` da sua aplicação.

```java
public class Example {
    public static void main(String[] args) {
        JettyServer.start();
    }
}
```

Caso haja a necessidade de personalização do container você pode fazer isso acessando a instância do `Jetty`.

```java
public class Example {
    public static void main(String[] args) {
        JettyServer.start();
        
        final Server server = JettyServer.getServer();
        final ErrorHandler customErrorHandler = ...;
        server.setErrorHandler(customErrorHandler);
    }
}
```

Mais informações e opções de configuração podem ser obtidas [neste link](configuration-options.md).

### Internacionalização

O módulo `commons-message-bundle` oferece uma API de internacionalização de mensagens. Ela consiste em carregar 
as mensagens de arquivos de internacionalização disponíveis no classpath e oferecer elas condicionalmente baseadas no 
idioma atual da solicitação.

Em outras palavras, trata-se de um mecanismo capaz de identificar qual o `Locale` da solicitação e retornar as mensagens
adequadas para o idioma. As mensagens são identificadas usando o padrão de `chave=valor`.

Todas as mensagens são carregadas de arquivos de internacionalização. Um arquivo de internacionalização é um arquivo 
`JSON` com estrutura exemplificada a seguir. Ele contém uma chave que identifica a mensagem e como conteúdo o código 
(opcional) e valor da mensagem para o idioma do arquivo.

```json
{
  "backendFoundation.example.operationSuccessfull": {
    "code": "EXMP-0001",
    "message": "Example writed succesfully"
  }
}
```

O idioma de uma mensagem é identificado usando o nome do arquivo de internacionalização. Por exemplo, `messages-en-US.json`
indica que as mensagens presente naquele arquivo são mensagens para o idioma `Inglês dos Estados Unidos`. 

A API de internacionalização procura por arquivos de mensagens no projeto e em todas as bibliotecas que o projeto usa.
A busca é feita lendo os arquivos `messages-<idioma>.json` na raiz da biblioteca (JAR). A API aceita arquivos que 
identificam o idioma (como `messages-pt.json`) bem como arquivos com identificação da variação (como `messages-pt-BR.json`).
No caso de existência de vários arquivos de internacionalização para um mesmo idioma, as mensagens presentes no
arquivo com identificação da variação tem precedência sobre os demais.

O acesso programático as mensagens pode ser feito através da classe `MessageBundle` com exemplos a seguir.

```java
public class Example {
    
    @Inject 
    private MessageBundle messageBundle;
    
    @Inject
    private HttpServletRequest request;
    
    public String getExampleMessage() {
        return messageBundle
            .getMessage(
                "backendFoundation.example.operationSuccessfull",
                 request.getLocale()
            )
            .getMessage();
    }
}
```

Mais informações e opções de configuração podem ser obtidas [neste link](configuration-options.md).

### Segurança

A autenticação e controle de permissões é oferecido na Backend Founation através do `Apache Shiro`. Ele funciona baseado 
em 3 conceitos básicos:

- Subject
- SecurityManager
- Realm

O primeiro, `Subject`, nada mais é do que a identificação do usuário, seja ele um usuário conhecido (um usuário autenticado)
ou um usuário anônimo. Um objeto de `Subject` é responsável por gerenciar as operações de segurança relativas a um único
usuário como login, logout, acesso a informações do usuário, validações e mais.

O segundo, `SecurityManager`, é o responsável pela gestão da segurança "por baixo dos panos". Em outras palavras,
enquanto o `Subject` administra operações de segurança relacionadas a um usuário, o `SecurityManager` administra
as operações que envolvem todos os usuários.

O último e não menos importante, `Realm`, funciona como um repositório de usuários e permissões. De certa forma pode-se
dizer que o `Realm` é um DAO para acesso aos usuários.

O exemplo abaixo demonstra um `Realm` que consulta os dados de autenticação e permissão de um usuário encaminhando eles
para o serviço `user`.

```java
public class ExampleRestAuthorizationRealm extends RestAuthorizationRealm {

    @Override
    protected SimpleAuthorizationInfo getSimpleAuthorizationInfo() throws IOException {
        return CDI
            .current()
            .select(UserGateway.class)
            .get()
            .getPermissions();
    }
}
```

Na Backend Foundation o Apache Shiro é integrado e habilitado por padrão, ficando responsabilidade do serviço a 
configuração do Shiro. Isso é feito através do arquivo `shiro.ini` que define algumas opções importantes, como qual
`Realm` deve ser usado. Os detalhes de como funciona o arquivo e qual a sintaxe/opções disponíveis você pode consultar 
no [site do projeto](https://shiro.apache.org/configuration.html).

Uma vez configurado o Shiro pode ser usado nos resources REST com duas anotações básicas: `@RequiresAuthentication`, que
valida que determinado método só pode ser acessado por usuários autenticados, e `@RequiresPermission` que declara
que determinado método só pode ser acessado por usuários autenticados e que detem a permissão necessária de acesso.

```java
public class ExampleResource {
    
    @GET
    @RequiresAuthentication
    public Response getHello() {
        return Response.ok("Hello world").build();
    }
    
    @POST
    @RequiresPermission("example-application:example-resource:write")
    public Response postHello(final Example example) {
        return Response.ok("Hello " + example.getNameToGreet()).build();
    }
    
}
```

Além das anotações ainda há a opção de validação programática das permissões por meio da classe `ResourceUtils`.

```java
public class ExampleResource {
    
    @GET
    public Response getHello() {
        ResourceUtils.checkReadPermission(ExampleResource.class);
        return Response.ok("Hello world").build();
    }
    
    @POST
    public Response postHello(final Example example) {
        ResourceUtils.checkWritePermission(ExampleResource.class);
        return Response.ok("Hello " + example.getNameToGreet()).build();
    }
    
}
```

Há ainda mais informações (como configuração) disponíveis tanto para a Backend Foundation como para o Shiro. Recomendamos
você consultar o JavaDoc do primeiro [aqui](#javadoc) e a documentação do segundo [aqui](https://shiro.apache.org/documentation.html).

#### Acesso aos dados do usuário autenticado

O acesso aos dados do usuário autenticado no contexto do Shiro pode ser feito através do objeto de sessão. 

```java
final Session session = SecurityUtils.getSubject().getSession();
final Object exampleAttribute = session.getAttribute("example_attribute");
```

Quando o contexto de CDI está disponível, esse acesso aos atributos do usuário pode ser feito pela classe `UserContext`.
Ela dispõe de pontos de acesso simplificados a atributos de uso comum de usuários, tais como:

- ID
- Nome
- Usuário (login)
- ID do tenant
- Status de administrador (se o usurário é ou não um)
- ID do grupo
- Regiões
- Hierarquia
- IDs das empresas

```java
class Example {
    
    @Inject
    private UserContext userContext;
    
    public void example() {
        final String userId = userContext.getId().orElse(null);
        final String userName = userContext.getName().orElse(null);
    }
}
```

O acesso a atributos adicionais também pode ser feito através da classe `UserContext`, como exemplificado abaixo.

```java
final String exampleAttribute = userContext
        .getSessionAttribute("example_attribute")
        .map(Object::toString)
        .orElse(null);
```

### Paginação

Paginação resume-se em obter os dados de um serviço em partes (páginas). Esse mecanismo é oferecido pela Backend 
Foundation através da API de persistência ([DAO](#dao)).

A API de paginação resume-se em 3 classes:
- `PagedList`: Resultado paginado de consultas. Contém os dados retornados e os detalhes da página (tamanho, offset, número, etc)
- `Sort`: Contém as instruções de ordenação, como nome do campo e direção.
- `PaginationSearch`: Classe de abstração de consultas paginadas. Contém as instruções de filtragem e paginação para buscas
e pode ser extendida pelo projeto para uso de filtros adicionais personalizados.

Vale salientar que **o uso desta API não é recomendado**. A API da [RestQuery](#restquery) permite atingir os mesmos 
resultados com uma dinamicidade maior e verbosidade menor.

```java
public class ExamplePaginationSearch extends PaginationSearch {
    
    private UUID id;
    private String description;
    
    public UUID getId() {
        return id;
    }
    
    public void setId(final UUID id) {
        this.id = id;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
}

public class ExampleDAO extends AbstractDAO<Example> {
    
    @Override
    public Class<Example> getEntityClass() {
        return Example.class;
    }
    
    public PagedList<Example> findPagedResults(final ExamplePaginationSearch pageRequest) {
        final Query<Example> query = find();
        
        if (pageRequest.getId() != null) {
            query.where().idEq(pageRequest.getId());
        }
        
        if (!StringUtils.isEmpty(pageRequest.getDescription())) {
            query.where().icontains("description", pageRequest.getDescription());
        }
            
        return getPagedList(query, pageRequest);
    }
}
```

### Clientes de integração

Um cliente de integração pode ser definido como objetos para comunicação de um serviço com o outro. Eles abstraem a 
complexidade de comunicações como essa que geralmente incluem a execução de chamadas HTTP.

A Backend Foundation entrega a API de clientes de integração usando o [Feign](https://github.com/OpenFeign/feign) 
como provedor e [Wayland](https://gitlab.wssim.com.br/platform/wayland) como plugin responsável pela geração das
interfaces de definição dos clientes.

Uma instância de um cliente de integração pode ser obtida através do CDI com a anotação `InjectProxy`. Todas as chamadas
feitas aos objetos de integração serão automaticamente roteados para o serviço de destino seguindo as definições feitas
em configuração.

```java
public class ExampleGateway {
    
    @InjectProxy
    private ExampleResource resource;
   
    @Inject
    private ObjectMapper objectMapper;
    
    public Example getExample() {
        final Response response = resource.getExemple();
        if (response.getStatus() != HttpStatus.SC_OK) {
            throw new RuntimeException("Error retrieving response from upstream server: " + response.getStatus());
        } 
        
        final InputStream responseInput = (InputStream) response.getEntity();
        return objectMapper.readValue(responseInput, Example.class);
    }
}
```

#### Customização das chamadas de clientes de integração

A API de clientes de integração permite que todas as chamadas feitas por ela possam ser customizadas através da 
interface `IntegrationRequestCustomizer`. Qualquer implementação dessa interface será identificada utilizando o CDI
e acionada sempre que um cliente de integração for utilizado.

Exemplo de implementação: 

```java
public class ExampleCustomizer implements IntegrationRequestCustomizer {
    
    @Override
    public void customize(RequestTemplate template, Class<?> clientDefinition) {
        final String headerName = ...;
        final String headerValue = ...;
        
        template.header(headerName, headerValue);
    }
    
}
```

A Backend Foundation possui algumas implementações padrão da interface para comportamentos padrão, como o encaminhamento
do cookie de sessão. A relação abaixo contêm as atuais implementações e suas responsabilidades. 

- `com.ws.commons.integration.customizer.AuthenticationIntegrationRequestCustomizer`: Encaminha nas requisições de clientes
de integração o cookie `JSESSIONID` se houver um usuário autenticado no serviço.
- `com.ws.commons.integration.customizer.LanguageIntegrationRequestCustomizer`: Encaminha nas requisições dos clientes
de integração o idioma da requisição recebida (presente no header `accept-language`).
- `com.ws.commons.integration.customizer.RequestTracingIntegrationRequestCustomizer`: Adiciona nas requisições os 
cabeçalhos utilizados pela API de rastreamento das requisições.

### Requisição HTTP com JAX-RS client API

Além dos clientes de integração, também é possível fazer a comunicação entre serviços com a JAX-RS client API.

Para facilitar seu uso é possível utilizar a classe `IntegrationRequest`, a qual possui vários métodos para executar
requisições HTTP, possibilitando especificar URI, cabeçalhos HTTP, filtro rest query, entre outros. Em todas as
 requisições é utilizado como URL base (concatenando a URI especificada) o valor configurado na váriavel de ambiente
 `integration.address`. Uma instância da `IntegrationRequest` pode ser obtida através do CDI.

Também é possível utilizar a classe `IntegrationRequestCloudManager`, similar a `IntegrationRequest`, diferindo-se
 por utilizar a váriavel de ambiente `integration.address.cloud.manager` como URL base. Ela pode ser utilizada para se
 comunicar com o cloud-manager, o qual pode estar em uma URL diferente da dos serviços. Também é possível configurar a
 variável de ambiente `integration.token.cloud.manager` para adicionar o token de autorização do cloud-manager. Uma
 instância da `IntegrationRequestCloudManager` também pode ser obtida através do CDI.

```java
public class Example {

    private final IntegrationRequest integration;
    private final IntegrationRequestCloudManager integrationCloudManager;

    @Inject
    public Example(final IntegrationRequest integration,
                   final IntegrationRequestCloudManager integrationCloudManager) {
        this.integration = integration;
        this.integrationCloudManager = integrationCloudManager;
    }
    
}
```

Maiores informações do uso da JAX-RS client API [aqui](https://docs.oracle.com/javaee/7/api/javax/ws/rs/client/package-summary.html).

### Injeção de lista de tenants disponíveis

A anotação `@InjectTenants` permite injetar uma lista de tenants disponíveis provenientes do cloud-manager.

Essa lista é produzida pela `TenantsProducer`, a qual faz uso da `IntegrationRequestCloudManager`. Dessa forma, é
 necessário a configuração das variáveis de ambiente da `IntegrationRequestCloudManager` e rodar o `cloud-manager` com
 uma versão >= 6.0.0
 
Exemplo:
 ```java
private final List<String> tenants;

@Inject
public Example(@InjectTenants final List<String> tenants) {
    this.tenants = tenants;
}
```

### Criador de sessão

`SessionCreator` é uma classe que possibilita criar uma sessão no redis, a qual pode ser obtida através do CDI. Essa
 sessão será associada a um tenant informado via parâmetro e a um usuário que pode ser informado via parâmetro ou 
 utilizar o da variável de ambiente `redis.session.user`.

Normalmente a criação de sessão é necessária em integrações, onde não há uma sessão ativa de um usuário do sistema e é
 preciso criar uma para, por exemplo, acessar o banco de dados do tenant associado.

```java
public class Example {

    private final SessionCreator sessionCreator;

    @Inject
    public Example(final SessionCreator sessionCreator) {
        this.sessionCreator = sessionCreator;
    }

    public void run(final String tenant) {
        sessionCreator.create(tenant, "example@example.com");
        // or
        sessionCreator.create(tenant);
    }

}
```

### Warm Up

`WarmUp` é uma interface que permite configurar a integração de dados de um recurso (entidade) de um serviço através de
 requisições HTTP GET. Todas as classes que implementam a `WarmUp` são automaticamente executadas pela `WarmUpRunner`
 quando o container do CDI é inicializado (ao iniciar o serviço), caso esteja habilitada.

  - Por padrão a execução é desabilitada. É possível habilitá-la através da variável de ambiente `warm.up.enabled`.

      ```properties
      warm.up.enabled=true
      ```

O objetivo da `WarmUp` é para quando um serviço é inicializado pela primeira vez, integrar todos os dados necessários
 para seu funcionamento provenientes de outros serviços. Após isso, é possível utilizar a
 [mensageria](https://gitlab.wssim.com.br/platform/hermod/merge_requests/1) para manter os dados atualizados.

Para utilizá-la, é preciso:
 
1. Criar uma classe que implemente `WarmUp`.

    Exemplo:
    ```java
    private class RecordPermissionWarmUp implements WarmUp<AccessGroup> {

        private static final String ACCOUNTS_SERVICE_VERSION = "accounts.service.version";
        private static final String ACCOUNTS_SERVICE_VERSION_DEFAULT_VALUE = "v3";
    
        private final String accountsVersion;
    
        @Inject
        public RecordPermissionWarmUp(
            @ConfigProperty(name = ACCOUNTS_SERVICE_VERSION, defaultValue = ACCOUNTS_SERVICE_VERSION_DEFAULT_VALUE) final String accountsVersion
        ) {
            this.accountsVersion = accountsVersion;
        }
    
        @Override
        public Class<AccessGroup> getDataClass() {
            return AccessGroup.class;
        }
    
        @Override
        public String getPath() {
            return String.format("/api/%s/accounts/access-groups/internal-list", this.accountsVersion);
        }
    
        @Override
        public String getRestQueryParams() {
            return null;
        }

        @Override
        public boolean process(final List<AccessGroup> list) {
            // Persist the list.
            return true;
        }

    }
    ```

2. Rodar o `cloud-manager` com uma versão >= 6.0.0, ele é necessário para obter todos os tenants disponíveis do sistema
 através da anotação `@InjectTenants`.

3. Configurar as variáveis utilizadas pela `IntegrationRequest` e pela `IntegrationRequestCloudManager`.

### Resources REST

A Backend Foundation utiliza a API do JAX-RS para prover uma estrutura compatível com resources REST.
A implementação da API em uso é o Jersey.

Um resource REST pode ser definido como um ponto de acesso a um conjunto de dados, oferecendo operações para manipular 
esses dados. Uma operação é identificada pelo tipo de solictação HTTP e os tipos mais utilizados são:

- `GET`: Consulta um determinado recurso
- `POST`: Cria um novo recurso
- `PUT`: Cria ou substitui um recurso
- `DELETE`: Remove um recurso
- `PATCH`: Efetua uma atualização parcial de um recurso
- `TRACE`: Efetua um teste de loopback no resource para identificar problemas de comunicação
- `HEAD`: Similar a um GET mas a resposta contém apenas os cabeçalhos. Permite operações como consulta de tamanho antes
de efetuar download de um arquivo grande.

Os resources em uma aplicação podem ser escritos usando apenas a API do JAX-RS ou utilizar das APIs da Backend Foundation
para facilitar o processo de desenvolvimento. Um exemplo dessa API é a `AbstractResource`, que abstrai um CRUD completo.

```java
public class ExampleResource extends AbstractResource<Example> {
    @Override
    public Response delete(UUID id) {
        return Response.status(Status.NOT_IMPLEMENTED).build();
    }
}
```

Quando determinado recurso não requer um CRUD completo, como nos casos em que deleção não está disponível, há ainda
interfaces que permitem a abstração baseado na operação. A relação de interfaces disponíveis está disposta a seguir.

- IResourceBatchDelete
- IResourceBatchInsert
- IResourceBatchPatch
- IResourceDelete
- IResourceGet
- IResourceInsert
- IResourceList
- IResourcePatch
- IResourceUpdate

Há ainda interfaces que permitem a [conversão automática para DTO](#conversão-automática-em-resources-rest).

- IDTOResourceBatchInsert
- IDTOResourceBatchPatch
- IDTOResourceGet
- IDTOResourceInsert
- IDTOResourceList
- IDTOResourcePatch
- IDTOResourceUpdate

Exemplo de implementação para os métodos `GET`, `POST` e `PUT` usando as interfaces `IResourceGet`, `IResourceInsert`
e `IResourceUpdate` respectivamente:

```java
public class ExampleResource implements IResourceGet<Example>, 
                                        IResourceInsert<Example>, 
                                        IResourceUpdate<Example> {
    @Inject
    private AbstractService<Example> service;
    
    @Override
    public AbstractService<Example> getService() {
        return service;
    }
}
```

#### Mapeamento de exceções

Exceções são parte do desenvolvimento de aplicações. A API de REST permite a criação de implementações que detectam
quando exceções não tratadas acontecem e permitem que uma mensagem adequada seja retornada para o consumidor da API.

Essas implementações são feitas através da interface `ExceptionMapper` do JAX-RS. 

```java
public class ExampleExceptionMapper implements ExceptionMapper<ExampleException> {
    
    @Override
    public Response toResponse(ExampleException exception) {
        return Response.serverError().build();
    }
    
}
```

Uma implementação do `ExceptionMapper` deve ser detectada e usada automaticamente. Quando isso não acontecer você 
precisará registrar ela no `ApplicationConfig`.

A Backend Foundation já fornece alguns mapeadores de exceções como de validação, assim como um mapeador padrão.
Os mapeadores fornecidos atualmente são:

- Exceções de deserialização/serialização de/para JSON
- Exceções baseadas em `LogicException`
- Falhas de validação
- Exceções baseadas em `RequestException`
- Exceções baseadas em `NotAllowedException`
- Exceções internacionalizadas baseadas em `MessageException`

Se o seu projeto não precisa de um mapeador fornecido automaticamente ele pode ser
removido usando o `ApplicationConfig`.

#### Requisições PATCH

A Backend Foundation fornece através do módulo `commons-server-patch-api` uma extensão para o JAX-RS de suporte a 
requisições HTTP PATCH. O módulo funciona baseado em 4 pontos:

- Anotação `PATCH`: Identifica o tipo da requisição HTTP, assim como acontece com as anotações `GET`, `POST` e afins.
- Interceptador `PatchReaderInterceptor`: Implementação da API de interceptação do JAX-RS responsável por executar
a lógica de atualização parcial, substituindo as instruções recebidas na request pela entidade atualizada seguindo
essas instruções.
- Interface `PatchResource`: Classes de resource JAX-RS que aceitam requisições PATCH precisam implementar a interface
`PatchResource`. Através dela a `PatchReaderInterceptor` irá obter qual o objeto sob o qual as instruções recebidas
na requisição devem ser aplicadas.
- Interface `PatchProcessor`: A classe `PatchReaderInterceptor` irá procurar via CDI implementações da interface 
`PatchProcessor` compatíveis com o `Content-Type` da requisição. Implementações da interface são as responsáveis por
interpretar as instruções e aplicar elas no objeto.

Além do módulo de API, a Backend Foundation também disponibiliza os módulos `commons-server-patch-jsonpatch` e
`commons-server-patch-jsonmergepatch` que contêm implementações da interface `PatchProcessor` para, respectivamente,
requisições compatíveis com JSON Patch ([RFC 6902](https://tools.ietf.org/html/rfc6902)) e JSON Merge Patch 
([RFC 7386](https://tools.ietf.org/html/rfc7386)).

É importante salientar que a necessidade de implementação da interface `PatchResource` pelas classes de resource
JAX-RS se faz necessária devido ao fluxo que o JAX-RS utiliza (detalhes do fluxo disponíveis 
[neste link](https://access.redhat.com/documentation/en-us/red_hat_fuse/7.2/html/apache_cxf_development_guide/jaxrs20filters)). 
Uma requisição de PATCH contêm instruções do que precisa ser feito, cabe ao servidor identificar através da URI do 
resource o objeto onde essas instruções devem ser aplicadas. Uma vez que o interceptador que aplica as instruções é 
executado antes do método da classe de resource e também não conhece os detalhes daquele resource, a interface serve 
como um meio simplificado da aplicação informar qual o objeto a ser usado para a requisição de PATCH. 

O método `getPatchTargetObject` da interface `PatchResource` disponibiliza dois objetos nunca nulos em todas as 
invocações para permitir a identificação da requisição. O primeiro parâmetro `ResourceInfo` dispõe dos detalhes 
do resource, como método que será disparado e afins, e o segundo prâmetro `UriInfo` os detalhes da URI da requisição, 
como os parâmetros dela e afins.

Implementação de exemplo:

```java
public class ExampleResource implements PatchResource {
    
    @Inject
    private ExampleService service;
    
    @PATCH
    @Path("/{id}")
    @Consumes({PatchMediaType.JSON_MERGE_PATCH, PatchMediaType.JSON_PATCH})
    public Response patch(final Example updatedObject) {
        service.update(updatedObject);
        return Response.ok().build();
    }
    
    public Optional<?> getPatchTargetObject(final ResourceInfo resourceInfo, final UriInfo uriInfo) {
        final UUID id = Optional
            .ofNullable(uriInfo)
            .map(UriInfo::getPathParameters)
            .map(params -> params.getFirst("id"))
            .map(UUID::fromString)
            .orElseThrow(NotFoundException::new);
        
        return Optional.ofNullable(service.get(id));
    }
    
}
```

Requisições PATCH também são compatíveis com as implementações abstratas da Backend Foundation relacionadas abaixo.
Vale mencionar que as implementações abaixo já utilizam a nova API de PATCH descrita neste documento.

- `AbstractResource`
- `IResourcePatch`
- `IDTOResourcePatch`

### Services

Em uma aplicação multi camadas, a de serviço geralmente é responsável por executar as regras de negócio da aplicação,
intermediando a camada de acesso a dados ([DAO](#dao)) e de comunicação ([Resources REST](#resources-rest)).

A Backend Foundation oferece a abstração `AbstractService` para facilitar o desenvolvimento dos services. Seu uso
geralmente é feito em conjunto com as interfaces e abstrações dos [Resources REST](#resources-rest).

```java
public class ExampleService extends AbstractService<Example> {
    
    @Inject
    public ExampleService(final AbstractDAO<Example> dao) {
        super(dao);
    }
}
```

### RestQuery

A API da RestQuery é um mecanismo que permite aos consumidores dos serviços executar consultas personalizadas nos 
resources REST. Em outras palavras, é uma maneira personalizável de obter dados sem a necessidade de implementar 
manualmente a consulta nos resources.

Uma RestQuery também pode ser definida como uma [DSL](https://pt.wikipedia.org/wiki/Linguagem_de_dom%C3%ADnio_espec%C3%ADfico) 
de consultas. Elas são recebidas em formato de String e interpretadas para posterior conversão para SQL usando a API 
do ORM.

#### Funcionamento da RestQuery

A interpretação e tradução de uma RestQuery é feita automaticamente pela camada de persistência (`AbstractDAO`) através
da interface `RestQueryAdapter`. Uma instância da interface pode ser obtida por meio de injeção do CDI ou através da 
fábrica `RestQueryAdapterFactory`.

Na solicitação, usando a configuração padrão, a consulta RestQuery é extraida usando o conteúdo do parametro `q` 
da `URI`.

`http://example.com/api/v1/example?q=`**`{distinct}{description->eq->example}{orderby->[createdAt desc]}`** 

#### Sintaxe da RestQuery

A sintaxe da RestQuery é baseada em grupos, expressões lógicas ou de configuração e de operadores. Cada um deles é 
usado com os delimitadores `{` e `}`. Por exemplo, a expressão de configuração `DISTINCT` é representada na DSL como
`{distinct}`.

Uma expressão pode ou não receber parâmetros. Quando é o caso, como na expressão de projeção `SELECT`, o conjunto
de parâmetros é separado usando `->`. A quantidade de parâmetros varia conforme a expressão.

```
{select->[id, description, createdAt]}
```

```
{age->btw->12->17}
```

Assim como a existência de parâmetros varia conforme a expressão, também varia o uso de operadores. Um operador realiza
operações em cima de uma consulta. Ou seja, operadores permitem executar condições e similares em cima dos dados.

Um operador é representado como parâmetro em uma consulta. A critério de exemplo, filtrar os dados para consultar
todos os clientes com idade maior ou igual que 18 anos pode ser feito usando o operador `ge` no campo `age`.

```
{age->ge->18}
``` 

Por fim, expressões podem ser agrupadas usando operadores lógicos, permitindo operações como filtragem condicional 
usando `OR` ou `AND`. Um grupo consiste em expressões unidas por operadores lógicos (`AND` com `&&` ou `OR` com `||`) encapsulados entre 
`(` e `)`.

```
({age->ge->18}||{emancipated->eq->true})
```

```
({deliveryAddress->eq->true}||{defaultAddress->eq->true}){description->like->example}({personType->eq->juridica}&&{document->isnnull})
```

As relações de operadores e expressões existentes estão dispostas a seguir.

##### Expressões de configuração

- `distinct`: Apenas registros distintos
- `firstRow`: Primeiro resultado a ser retornado
- `page`: Número da página
- `pageSize`: Tamanho da página
- `select`: Projeção; campos a serem retornados
- `filter`: Filtragem; campos a serem filtrados
- `orderBy`: Ordenação
- `deleted`: Incluir registros deletados (quando o projeto usa soft delete)
- `noCount`: Não incluir a contagem de registros no resultado


##### Operadores de filtragem

- `eq` (equals)
- `ieq` (case-insensitive equals)
- `neq` (not equals)
- `like` 
- `ilike`
- `gt` (maior que) 
- `ge` (maior ou igual que)
- `lt` (menor que)
- `le` (menor ou igual que)
- `in` (incluso em; está presente em)
- `nin` (não incluso em; não está presente em)
- `isNull`
- `isNNull` (é não nulo)
- `btw` (está entre) 

##### Operadores lógicos

- `||` (ou)
- `&&` (e)

**Nota importante a respeito do `&&`:** O caracter `&` é reservado em URLs. Por este motivo o uso do `&&` é opcional,
omitir ele deixa implicito para a RestQuery que trata-se de um operador lógico `AND` entre dois grupos sem nenhum operador.
É possível ainda usar a maneira alternativa de representação dele usando `%26`.

#### Personalização da deserialização da RestQuery

Nativamente a RestQuery é capaz de interpretar e traduzir tipos nativos do Java, como Integer, BigDecimal, OffsetDateTime
e outros. Esse suporte pode ser personalizado e estendido para objetos específicos do domínio da aplicação usando a 
interface `RestQueryDeserializer` que, como o nome indica, permite a criação de deserializadores para a API.

Exemplo de implementação:

```java
public class ExampleDeserializer implements RestQueryDeserializer<Example> {
    
    @Override
    public Example deserialize(String value) throws IOException {
        if (value == null) {
            return null;
        }
        
        return Example.valueOf(value);
    }
}
```

Implementações da interface são descobertas e usadas automaticamente pela RestQuery usando o CDI. O critério de busca
é o tipo genérico da interface na implementação. Em outras palavras, sempre que a RestQuery precisar traduzir uma String
para `Example` ela vai procurar uma classe que implementa `RestQueryDeserializer<Example>`.

É importante salientar que implementações personalizadas da interface tem maior precedência do que o mecanismo padrão
de conversão. Ou seja, você pode implementar `RestQueryDeserializer<Integer>` se precisar personalizar como um valor
String é traduzido para `Integer`.

#### Integração da RestQuery com o DAO

A integração da RestQuery com o [DAO](#dao) ocorre através da interface `RestQueryAdapter`. Essa interface é responsável
por fornecer ao `AbstractDAO` de maneira padronizada os dados oferecidos pela RestQuery.

Uma instância da RestQuery pode ser obtida usando injeção do CDI ou a classe fábrica `RestQueryAdapterFactory`. No caso
do acesso via injeção do CDI, é importante lembrar que isso depende de um escopo de requisição ativo.

```java
public class Example {
    
    @Inject
    private RestQueryAdapter instanceFromCdi;
    
    private RestQueryAdapter instanceFromFactory = RestQueryAdapterFactory.fromString("{example->eq->true}");
    
}
```

De posse de uma instância da interface você já pode usar o `AbstractDAO` para obter os resultados paginados.

```java
public class ExampleDAO extends AbstractDAO<Example> {
    
    @Override
    public Class<Example> getEntityClass() {
        return Example.class;
    }
}

public class ExampleService extends AbstractService<Example> {
    
    private final AbstractDAO<Example> dao;
    
    @Inject
    public ExampleService(final AbstractDAO<Example> dao) {
        super(dao);
        this.dao = dao;
    }

    public PagedList<Example> search(final RestQueryAdapter restQuery) {
        return dao.list(restQuery);
    }

}

@Path("/example")
public class ExampleResource {
    
    @Inject
    private RestQueryAdapter restQuery;
    
    @Inject
    private AbstractService<Example> service;
    
    @GET
    public Response search() {
        final PagedList<Example> pagedResults = service.search(restQuery); 
        return Response.ok(pagedResults).build();
    }
    
}
```

#### Retrocompatibilidade

É recomendável que os serviços migrem da API PaginationSearch para a RestQuery assim que possível. Para facilitar
essa migração a interface `RestQueryAdapter` injetada por CDI é capaz de detectar os parâmetros da API antiga e
traduzir automaticamente para os da RestQuery.

É importante salientar entretanto que apenas o uso padrão é traduzido automaticamente. Em outras palavras, campos
personalizados não são detectados ou interpretados no momento.

### PojoConverter

O PojoConverter é um mecanismo oferecido pela Backend Foundation capaz de mapear e converter dois beans. Em outras 
palavras, o Pojo Converter permite converter uma entidade de/para um DTO de maneira simples.

O processo de conversão pode ser feito de maneira automática, usando a associação direta ao comparar os nomes dos campos
de origem e destino bem como os tipos, assim como pode ser feita através de mapeamentos personalizados. Mapear uma 
entidade consiste em adicionar anotações às classes envolvidas, como exemplificado abaixo.

```java
public class ExampleEntity {
    
    private UUID id;
    private String description;
    
    @PojoColumnMapper(target = "dateOfPublication")
    private OffsetDateTime createdAt;
    
}

public class ExampleDto {
    
    private String description;
    
    @PojoColumnMapper(target = "createdAt")
    private OffsetDateTime dateOfPublication;
    
}
```

Executar a conversão pode ser feito manualmente usando a classe `PojoConverter` ou automaticamente usando a integração
nativa com resources REST JAX-RS. O exemplo abaixo demonstra a conversão manual.

```java
ExampleEntity sourceValue = new ExampleEntity();
ExampleDto convertedValue = new PojoConverter().convert(ExampleDto.class, sourceValue);
```

#### Personalização dos objetos criados pelo PojoConverter

Há casos em que se faz necessário personalizar como o PojoConverter cria um objeto durante a conversão, como aqueles em
que o destino da conversão usa uma classe abstrata e o mecanismo padrão de criação irá falhar. Para esses casos a API do
PojoConverter disponibiliza a interface `PojoConverterInstanceProvider` que, como o nome indica, atua como um provedor
de instâncias.

Exemplo de implementação da interface.

```java
public class ExampleInstanceProvider implements PojoConverterInstanceProvider<Example> {
    
    @Override
    public Example produce(final Class<? extends Example> targetClass, final Object sourceFieldValue) {
        return new ConcreteImplementationOfExample();
    }
}
```

A interface requer a definição de um tipo genérico nas implementações. O tipo genérico atua como identificador do tipo
de destino da conversão. Ou seja, quando o PojoConverter precisar de uma instância da classe `Example` ele irá procurar
uma classe que implementa `PojoConverterInstanceProvider` com o tipo genérico `Example`.

**O PojoConverter identifica uma implementação da `PojoConverterInstanceProvider` de três maneiras diferentes**, que são
(em ordem de precedência):

- Através da anotação `PojoInstanceProvider` no campo de destino da conversão.

Quando houver a anotação `PojoInstanceProvider` em um campo da classe de destino da conversão (entidade ou DTO), o pojo
converter irá utilizar a classe definida na anotação para obter instâncias para aquele campo.

```java
public class ExampleDto {
    
    @PojoInstanceProvider(AbstractExampleInstanceProvider.class)
    private AbstractExample loremIpsum;
}

```

- Através da anotação `PojoInstanceProvider` na classe a ser instanciada.

Quando o PojoConverter precisar de uma instância da classe `X` e essa classe tiver a anotação `PojoInstanceProvider`,
o provedor definido na anotação será usado em todas as conversões que utilizam instancias da classe `X`.

```java
@PojoInstanceProvider(AbstractExampleInstanceProvider.class)
public abstract class AbstractExample {
    
}
```

- Usando o CDI

Além do uso da anotação, o PojoConverter também procura por implementações da `PojoConverterInstanceProvider` através do
CDI. A busca é feita usando a classe de destino para o qual se precisa de uma instância como tipo genérico da interface.

#### Conversão automática em resources REST

O processo de conversão usando o PojoConverter pode ser automatizado em resources REST por meio de anotações, evitando
que a chamada manual para a classe `PojoConverter` tenha de ser feita.

O trecho abaixo contém um exemplo de como isso funciona.

```java
@Path("/example")
public class ExampleResource {
    
    @Inject
    private ExampleService service;
    
    @PUT
    @ConversionConsumes(ExampleCreateRequestDto.class)
    @ConversionProduces(ExampleCreateResultDto.class)
    public Response create(final @Consumer Example example) {
        service.create(example);
        return Response.ok(example).build();
    }
    
}
```

A conversão automática é baseada em 7 anotações, que são:
- `ConversionConsumes` que identifica o DTO que será recebido em uma request. Em outras palavras, é o DTO de entrada 
que o consumidor da API irá enviar.
- `ConversionProduces`, que identifica o DTO que será enviado em uma request. Em outras palavras, é o DTO de saída 
produzido pelo resource.
- `Consumer`, que identifica o tipo de destino da conversão. É através dessa anotação que o PojoConverter sabe para qual 
classe ele deve converter a entrada definida na anotação `ConversionConsumes`.
- `ConversionMapConsumes`, `ConversionMapProduces`, `ConversionMap` e `ConversionMapEntry` que permitem a configuração
da conversão de dados em um `Map`.

É importante salientar que a conversão automática funciona apenas quando as classes abaixo estão registradas no provedor 
do JAX-RS (Jersey). Esse registro é feito automaticamente se você utiliza a `ApplicationConfig` no seu projeto.
- `ConversionConsumeInterceptor`
- `ConversionConsumeMapInterceptor`
- `ConversionProductionInterceptor`
- `ConversionProductionMapInterceptor`

### Persistência

A Backend Foundation fornece um mecanismo de persistência utilizando o ORM [Ebean](https://ebean.io/) como provedor.

#### DAO

O `AbstractDAO` pode ser definido como a principal API do mecanismo de persistência. Ele oferece as operações básicas
de interação com o banco de dados como inserção, atualização, consulta, remoções e transações. O uso do `AbstractDAO` 
requer implementações concretas dele. 

```java
public class ExampleDAO extends AbstractDAO<Example> {
    @Override
    public Class<Example> getEntityClass() {
        return Example.class;
    }
}
```

O `AbstractDAO` herda de seu provedor (o Ebean) o controle automático de transações. Isso significa que a abertura manual
de uma transação não é necessária. Uma transação é aberta e confirmada (commit) automaticamente para cada operação feita.

**O mecanismo de transações automáticas deve ser evitado em cenários mais complexos como aqueles em que mais de uma
entidade será criada ou atualizada e não é possível atingir isso usando relacionamentos. Usar transações automáticas
em cenários como esse não garantem a atomicidade da operação e deve-se efetuar tais operações usando um controle manual, 
similar ao exemplo abaixo.**

```java
public class SaleExampleService {
    
    @Inject
    private AbstractDAO<Sale> saleDao;
    
    @Inject
    private AbstractDAO<AuditEvent> auditDao;
    
    public void update(Sale saleToUpdate) {
        final AuditEvent auditEvent = AuditEventFactory.fromSale(saleToUpdate);
        final Transaction transaction = saleDao.beginTransaction(TxScope.requiresNew());
        
        try {
            saleDao.updateWithTransaction(saleToUpdate, transaction);
            auditDao.insertWithTransaction(auditEvent, transaction);
            transaction.commit();
        } catch (final RuntimeException exception) {
            transaction.rollback();
            throw ex;
        } finally{
            transaction.close();
        }
    }
}

```

A relação completa de funcionalidades oferecidas e uso dele em cenários mais pontuais pode ser obtida através do
[JavaDoc](#javadoc).

#### Controle automático de transações usando anotações

Quando o controle de transações manual é necessário o Ebean disponibiliza anotações que permitem diminuir a verbosidade
que isso requer. Considerando o exemplo da seção acima ([DAO](#dao)), o exemplo abaixo atinge o mesmo resultado
usando a anotação `Transactional`.

```java
public class SaleExampleService {
    
    @Inject
    private AbstractDAO<Sale> saleDao;
    
    @Inject
    private AbstractDAO<AuditEvent> auditDao;
    
    @Transactional
    public void update(Sale saleToUpdate) {
        final AuditEvent auditEvent = AuditEventFactory.fromSale(saleToUpdate);
        
        saleDao.update(saleToUpdate);
        auditDao.insert(auditEvent);
    }
}
```

O funcionamento da anotação é relativamente simples: tudo o que acontecer dentro do contexto da anotação vai ser feito 
usando a mesma transação, confirmada (commit) automaticamente ao final ou cancelada (rollback) quando uma exceção acontecer.

Quando um método X que usa a anotação chama um método Y que também tem a anotação, a chamada interna irá utilizar a mesma
transação aberta no método X. Quando o método Y encerrar a transação não será confirmada, isso apenas acontecerá quando
o método que abriu a transação encerrar (que neste caso é o X).

A anotação pode ser usada em métodos como no exemplo acima, mas também pode ser usada em classes.

#### Escuta por eventos de persistência

Operações efetuadas na camada de persistência podem ser ouvidas e interceptadas. Duas são as maneiras disponíveis de se
fazer isso: Através da interface `EventListener` e do CDI.

A primeira, através da interface `EventListener`, permite observar e interceptar todos os eventos de persistência 
(inserção, atualização, remoção e etc) em todos os estágios (pré e pós).

```java
public class ExampleEventListener implements EventListener {
    
    public boolean isSupported(Class<?> entityType, EventType eventType) {
        return EventType.PRE_INSERT.equals(eventType) 
            && Identification.class.isAssignableFrom(entityType);
    }
    
    public void onRegister() {
        // fired when listener will start receiving events
    }
    
    public void onDeregister() {
        // fired when listener will not receive more events
    }
    
    public <T> boolean notify(EventDetailsAdapter<T> event) {
        final Identification entity = (Identification) event.getBean();
        if (entity.getId() == null) {
            event.getTransaction().rollback();
            throw new RuntimeException("All entities must have an ID. Automatic generation isn't supported.");
        }
    }
    
}
```

Implementações da interface precisam ser registradas através da classe `EventDispatcher`. Para maiores informações a 
respeito desse processo consulte o [JavaDoc](#javadoc).

A segunda maneira, via CDI, consiste no uso de anotações em métodos que devem ser disparados quando um evento acontecer.
As anotações disponíveis atualmente são:

- `Inserted`
- `Updated`
- `Deleted`

Eventos disparados desta forma suportam entidades que em algum momento estendem `BaseModel` ou implementam `Identification`.
A seguir estão relacionados alguns exemplos de ouvintes usando CDI.

```java
public class ExampleListener {
    
    public void onInsert(@Observes @Inserted ExampleEntity insertedEntity) {
    }
    
    public void onUpdate(@Observes @Updated ExampleEntity updatedEntity) {
    }
    
    public void onUpdate(@Observes @Updated Pair<ExampleEntity, ExampleEntity> updatedEntityPair) {
        final ExampleEntity entityBeforeUpdate = updatedEntityPair.getLeft();
        final ExampleEntity entityAfterUpdate = updatedEntityPair.getRight();
    }
    
    public void onDelete(@Observes @Deleted ExampleEntity deletedEntity) {
    }
    
}
```

#### Multitenancy

Multitenancy pode ser resumido como uma arquitetura em que uma única instância de um software é capaz de atender
múltiplos tenants simultaneamente. Em outras palavras trata-se de uma maneira de separar os dados dos clientes (tenants) 
que utilizam uma mesma instância de um software. Essa separação pode ser física usando banco de dados diferentes como
também pode ser lógica usando schemas diferentes, colunas de identificação (partições) ou outros.
 
A API de persistência disponibilizada pela Backend Foundation têm suporte a multitenancy habilitado por padrão. O modo
padrão de separação dos dados do tenant é por schema, e a identificação do tenant é feita usando a API de 
[autenticação e segurança](#segurança).

Você não precisa se preocupar com questões de multitenancy se estiver um cenário convencional (como um resource REST) e
estiver usando definições padrão no projeto. Toda e qualquer chamada ao `AbstractDAO` terá questões de multitenancy 
efetuadas automaticamente.

Para os casos em que é necessário ter conhecimento de qual tenant a aplicação está executando em determinado momento a
classe `UserContext` pode providenciar esse valor. 

```java
public class Example {
    
    @Inject
    private UserContext userContext;
    
    public String buildHello() {
        return "Hello " + userContext.getTenantId();
    }
    
}
```

Para os casos em que se faz necessário informar manualmente qual o tenant deve ser usado pode-se sobreescrever a classe
responsável pela produção da identificação usando CDI.

```java
public class ExampleCustomTenantProvider extends UserContextFactory {
    
    @Override
    @Specializes
    public UserContext createUserContext() {     
        final String customTenantId = "example";
        return new UserContext(customTenantId);
    }
}
```

Para os cenários em que o escopo de request do CDI não está disponível a recomendação é utilizar a produção de 
instâncias personalizadas do `Ebean`, informando o tenant no momento de sua criação para posterior uso em um `AbstractDAO`.

```java
public class ExampleDao extends AbstractDAO<Example> {
    
    @Inject 
    private EbeanMultiTenancyFactory factory;
    
    @Inject
    private DetachedDataSourceProvider detachedProvider;
    
    @PostConstruct
    public void init() {
        final String tenantId = "exampleTenantId";
        
        this.ebeanServer = factory
            .usingAlternativeProvider(detachedProvider)
            .produce(tenantId);
    }
    
    @Override
    public Class<Example> getEntityClass() {
        return Example.class;
    }
    
}
```

#### Data source e pool de conexões

Um `DataSource` cordena a criação de conexões com o banco de dados no contexto da persistência de uma aplicação. A 
Backend Foundation disponibiliza duas opções aos projetos para serem usadas, 
[Apache DBCP2](https://commons.apache.org/proper/commons-dbcp/) e [HikariCP](https://github.com/brettwooldridge/HikariCP), 
sendo a segunda a padrão. Os detalhes de configuração e funcionamento de cada uma delas estão dispostos no 
[JavaDoc](#javadoc).

Para os casos em que o projeto tem necessidades pontuais em relação ao gerenciamento de conexões com o banco de dados,
como a personalização mais fina das configurações do `DataSource`, a interface `DataSourceProvider` permite o 
fornecimento desse `DataSource` personalizado.

```java
public class ExampleDataSourceProvider implements DataSourceProvider {
    
    @Override
    public DataSource produce(Object tenantId) {
        return new CustomDataSource(tenantId);
    }
    
    @Override
    public String getName() {
        return "EXAMPLE-CUSTOM-DATASOURCE-PROVIDER";
    }
    
}
```

Instâncias de implementações da `DataSourceProvider` são localizadas usando o CDI. O valor retornado no método `getName`
identifica o provedor; é através do valor retornado por esse método e o valor definido no arquivo de configuração do 
Deltaspike que a Backend Foundation vai definir qual provedor será usado.

```properties
ds.provider=EXAMPLE-CUSTOM-DATASOURCE-PROVIDER
```

#### Reciclagem de entidades

A API de persistência da Backend Foundation dispõe de um mecanismo que permite registrar quando uma entidade é deletada do banco de dados. 
Essa operação visa manter um histórico de deleções para posterior uso em uma sincronização.

O mecanismo de registro das remoções é ativado por padrão e depente de uma tabela no banco de dados (consulte o [JavaDoc](#javadoc) 
para maiores informações a respeito da criação da tabela). Quando necessário o mecanismo pode ser desativado por completo
usando as [opções de configuração](configuration-options.md) ou condicionalmente por entidade usando a anotação `PreventRecycling`.

```java
@Entity
@PreventRecycling
public class ExampleEntity {
}
```

##### Metadados de reciclagem

Durante o processo de registro da deleção de uma entidade a API utiliza de alguns metadados para salvar o registro. Por padrão
esses dados são obtidos da requisição JAX-RS que gerou a deleção, mas nos demais casos a API requer uma implementação 
complementar da interface `RecycleMetadataProvider` que seja capaz de fornecer tais dados.

```java 
public class ExampleRecycleMetadataProvider implements RecycleMetadataProvider {
    
    public <T> Optional<String> getResourceIdentification(final EventDetailsAdapter<T> event) {
        if (/* implementation can handle request */) {
            return Optional.of("example");
        } else {
            return Optional.empty();
        }
    }
    
    public Integer getPriority() {
        return 100;
    }
    
}
```

É importante destacar que implementações da interface serão carregadas usando CDI tomando o retorno do método `getPriority` para
a ordenação da execução (quanto maior o valor maior a prioridade). As implementações da interface apenas devem retornar um 
valor quando forem capazes de fornecer ele, em todos os demais casos um `Optional` vazio deve ser retornado. O primeiro valor 
não-vazio retornado por uma implementação será usado pela API, levando a uma exceção quando nenhuma implementação for capaz 
de fornecer um valor.

### Validação

A Backend Foundation utiliza o [Bean Validation](https://beanvalidation.org/) como mecanismo de validações de objetos, 
estendendo ela para fornecer ferramentas adicionais que visam facilitar o desenvolvimento de aplicações.

Isso significa que todas as anotações e funcionalidades nativas do Bean Validation podem ser usadas para executar as
validações. A Backend Foundation deixa a API pré-configurada e integrada ao JAX-RS e internacionalização.

```java
public class ExampleEntity {
    @NotNull(message = "exampleApplication.validationError.nullValue")
    private UUID id;
    
    @NotNull(message = "exampleApplication.validationError.nullValue")
    @NotEmpty(message = "exampleApplication.validationError.emptyValue")
    @Length(max = 255, message = "exampleApplication.validationError.valueTooBig")
    private String description;
}

public class ExampleResource {
    @POST
    public Response create(@Valid ExampleEntity exampleEntity) {
    }
}
``` 

#### Logic validator

A API do Logic Validator fornece um mecanismo simplificado de validação de objetos. O processo de validação consiste em
aplicar uma série de regras em um objeto, retornando as violações encontradas ou disparando elas em forma de exceção.

Uma parte importante da API é a classe `LogicValidator` que abstrai o processo de validação e permite ao desenvolvedor
apenas escrever as regras de validação. 

Os métodos da implementação com as anotações `@Valid` ou `@DynamicValid` serão chamados quando a validação for iniciada.
A diferença entre as anotações consiste na maneira que a mensagem será gerada quando uma violação for encontrada.
A `@Valid` deve ser usada quando a validação é especifica para um campo enquanto a `@DynamicValid` quando a validação
é para elementos que não estão diretamente associados a um campo (como nos casos em que a implementação valida uma String). 

```java
public class ExampleValidator extends LogicValidator<Example> {
    
    @Valid(field = "description", message = "example.validation.invalidDescription")
    public boolean isDescriptionValid(Example example) {
        return !Strings.isNullOrEmpty(example.getDescription());
    }
}
```

Métodos de validação devem retornar o resultado da validação. Ou seja, **os métodos precisam ter um retorno e ele 
nunca pode ser nulo**.

A API é compatível com os seguintes tipos de retorno:
- `boolean`: Indica de maneira simples o resultado da validação. `true` significa que o valor é válido.
- `ValidObject`: Complementa um resultado de validação baseado em `boolean` ao permitir informar parâmetros adicionais. 
Esses parâmetros podem ser usados na mensagem de internacionalização definida na anotação `@Valid`.
- `BuilderLogicError`: Permite que a validação retorne mais de uma mensagem de violação. A classe `ListBuilderLogicError`
pode ser usada como implementação da interface.

#### Bean validation integrated

O Bean Validation Integrated é uma extensão da API nativa do Bean Validation que integra a API Logic Validator a ela.

O funcionamento é igual a API do Logic Validator, a única diferença é a adição da anotação `BeanValidationIntegrated`.
É através dela que o Bean Validation localiza as classes de validação do Logic Validator que devem ser executadas. 
A busca das classes é feita usando o CDI.

```java
@BeanValidationIntegrated(Example.class)
public class ExampleValidator implements LogicValidator<Example> {
    @Valid(field = "id", message = "exampleApplication.validationError.missingId")
    public boolean validateId(Example example) {
        return example.getId() != null;
    }
}
```

O valor esperado pela anotação identifica o tipo que é compatível com a validação. Ou seja, usar 
`@BeanValidationIntegrated(Example.class)` indica que a classe é capaz de validar instâncias de `Example`.

#### Grupos de validações

A API do Bean Validation tem suporte a grupos de validações. Um grupo de validação pode ser usado para executar validações
parciais condicionais ao estado do objeto.

```java
public final class SaleValidationGroups {
    public static final class Draft {}
    public static final class Confirmation {}
}

public class Sale {
    @NotNull(
        message = "exampleApplication.validationError.nullValue",
        groups = { SaleValidationGroups.Draft.class, SaleValidationGroups.Confirmation.class }
    )
    private UUID id;
    
    @NotNull(
        message = "exampleApplication.validationError.nullValue",
        groups = SaleValidationGroups.Confirmation.class
    )
    private ClientAddress invoiceAddress;
}

public class SalesResource {
    @Inject
    private AbstractService<Sale> service;
    
    @POST
    public Response createDraft(Sale sale) {
        final Set<ConstraintViolation> violations = Validation
            .buildDefaultValidatorFactory()
            .getValidator()
            .validate(sale, SaleValidationGroups.Draft.class);
        
        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
        
        service.createDraft(sale);
        return Response.ok(sale).build();
    }
    
    @POST
    @Path("/{id}/confirm")
    public Response confirm(@PathParam("id") UUID id, Sale sale) {
        final Set<ConstraintViolation> violations = Validation
            .buildDefaultValidatorFactory()
            .getValidator()
            .validate(sale, SaleValidationGroups.Confirmation.class);
                
         if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
          }
                
         service.confirm(sale);
         return Response.ok(sale).build();
    }
}
```

#### Anotações de validação personalizadas

A API do Bean Validation permite criar anotações para execução de validações. Isso possibilita automatizar as validações
rotineiras, como de `CPF` e `CNPJ`.

Uma anotação de validação personalizada consiste em duas classes: a anotação e o validador associado a ela.

```java
@Target({
    ElementType.FIELD, 
    ElementType.METHOD, 
    ElementType.PARAMETER, 
    ElementType.ANNOTATION_TYPE
})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = CpfConstraintValidator.class)
public @interface CPF {
    boolean allowEmpty() default false;
    String message();
}

public class CpfConstraintValidator implements ConstraintValidator<CPF, String> {
    
    private CPF constraintAnnotation;
    
    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {
         // validation logic goes here
    }
    
    @Override
    public void initialize(final CPF constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }
}
```

#### Constraints adicionais disponíveis

O módulo `commons-validation` da Backend Foundation expõe algumas constraints adicionais para o Bean Validation voltadas
a validações de CPF e CNPJ. As anotações de mesmo nome integram a validação disponível no módulo com a API do Bean 
Validation, facilitando seu uso.

```java
public class Example {
    
    @CPF(allowEmpty = false, message="validation.example.invalidCpf")
    private String cpf;
    
    @CNPJ(allowEmpty = false, message="validation.example.invalidCnpj")
    private String cnpj;
    
}
```

Validação da Inscrição Estadual não está disponível para uso através do Bean Validation. A necessidade de informar
para qual estado será feita a validação de maneira dinâmica não permite que ela seja usada em anotações (que precisam
ter informações disponíveis em tempo de compilação).

### Log

A Backend Foundation utiliza o [SLF4J](https://www.slf4j.org/) como API de logs e o [Log4j](https://logging.apache.org/log4j) 
como implementação da API.

Eventos de log podem ser criados através da classe `Logger` do SLF4J. Instâncias dela podem ser obtidas por injeção
ou programaticamente.

```java
final Logger logger = LoggerFactory.getLogger(Example.class);
```

```java
public class Example {
    @Inject
    private Logger logger;
}
```

#### Rastreamento de comunicação REST (requisições e respostas). <a name="log-requests"></a>

As requisições feitas para serviços que utilizam a commons possuem rastreamento ativado por padrão a partir da versão 
7.4.0. O rastreamento consiste em uma série de informações apresentadas em log que auxiliam na identificação de cenários
problemáticos, especialmente aqueles que envolvem mais de um serviço.

Toda solicitação processada pelos serviços recebe uma ID única automaticamente e essa ID é exibida nos eventos de log 
(veja a relação de marcadores na relação abaixo). Quando um serviço envia uma solicitação para outro serviço usando
um cliente de integração a mesma ID é compartilhada entre os serviços.

Esse reuso de informações para o rastreamento é feito através de cabeçalhos HTTP adicionais que a commons utiliza, 
interpreta ou adiciona nas solicitações. A relação abaixo contem uma relação dos atributos e cabeçalhos envolvidos
no rastreamento.

|Cabeçalho|Atributo|Origem do cabeçalho|Descricação|
|---|---|---|---|
|X-Request-Id|requestId|Heimdall ou commons|Identificação única da solicitação|
|X-Request-Caller|requestCaller|Heimdall ou commons|Nome do serviço que originou a solicitação (upstream caller)|
|X-Forwarded-Host|originHost|Heimdall|Nome do host (dominio) recebido na request pelo API gateway|
|X-Forwarded-Proto|originProto|Heimdall|Protocolo da request recebida pelo API gateway|
|X-Forwarded-For|originFor|Heimdall|IP ou nome DNS (hostname) do computador que enviou a solicitação ao API gateway|
|X-Forwarded-Port|originPort|Heimdall|Porta de destino da solicitação recebida pelo API gateway|
|X-Forwarded-Prefix|originPrefix|Heimdall|Prefixo da URI utilizada para roteamento pelo API gateway|

Além dos cabeçalhos há ainda outros atributos exibidos nos eventos de log pela commons com informações de diagnóstico. A
tabela abaixo contem a relação deles.

|Atributo|Descrição|
|---|---|
|tenantId|Identificação do tenant no banco de dados (nome do schema)|
|tenantName|Nome do tenant (subdominio)|
|userId|Identificação (UUID) do usuário no tenant|
|userLogin|Nome de usuário (e-mail) de autenticação|
|resourceClass|Nome simples da classe de resource reponsável pelo processamento da request|
|resourceMethod|Nome do método na classe de resource que foi executado para processar a request|
|requestMethod|Método HTTP da requisição|
|requestUri|URI da requisição recebida|
|requestQuery|Query string da requisição recebida|

Todos os atributos podem ser acessados a qualquer momento usando a classe `LogContext`. É importante salientar que os
atributos são de escopo de requisição (anexados a Thread ativa) e os valores retornados ou definidos usando o 
`LogContext` são válidos apenas para a solicitação atual. 

Nos eventos de log, cada atributo acima é representado entre colchetes. Cada evento de log possui as seguintes informações
(listadas por ordem de exibição):

1. Nível do evento
2. Data e hora (formato ISO 8601)
3. Nome do serviço (via propriedade de configuração `service.name`)
4. Nome do host em que o serviço está executando
5. ID do tenant (tenantId)
6. Nome do tenant (tenantName)
7. ID do usuário (userId)
8. Login do usuário (userLogin)
9. ID da requisição (requestId)
10. Serviço de origem da requisição (requestCaller)
11. Método HTTP da solicitação (requestMethod)
12. URI da solicitação (requestUri)
13. Query da solicitação (requestQuery)
14. Host de origem da requisição recebido pelo API gateway (originHost)
15. IP ou nome do solicitante que enviou a solicitação para o API gateway (originFor)
16. Protocolo utilizado na requisição enviada para o API gateway (originProto)
17. Porta utilizada pelo API gateway (originPort)
18. Prefixo usado pelo API gateway para o roteamento (originPrefix)
19. Classe de resource REST responsável por processar a requisição (resourceClass)
20. Método da classe de resource REST (resourceMethod)
21. Marcador opcional que o serviço pode utilizar (ver API do SLF4J para `Marker` no `Logger`)
22. Nome do logger ou da classe que emitiu o evento de log
23. Mensagem do log e stacktrace (se houver)
     
### Serialização e deserialização (JSON)

A Backend Foundation fornece a conversão de e para JSON usando o [Jackson](https://github.com/FasterXML/jackson) 
como provedor. A API permite conversões complexas e personalizadas bem como simples e rápidas.

```java
public class Example {
    
    @Inject
    private ObjectMapper objectMapper;
    
    public <T> String toJson(T object) {
        return objectMapper.writeValueAsString(object);
    }
    
    public <T> T fromJson(String json, Class<T> targetType) {
        return objectMapper.readValue(json, targetType);
    }
}
```

Um dos pontos chave da conversão é o `ObjectMapper`. A classe é o ponto de partida inicial para as conversões, sejam
elas automáticas ou manuais, e é também o ponto de configuração das conversões,

A Backend Foundation é capaz de produzir instâncias do `ObjectMapper` previamente configuradas através de injeção do 
CDI ou do contexto do JAX-RS. 

```java
public class Example {
    @Inject
    private ObjectMapper instanceFromCdi;
    
    @Context
    private ObjectMapper instanceFromContext;
}
```

Os objetos do `ObjectMapper` podem ser personalizadas para atingir as espectativas do projeto. Uma instância obtida do
contexto (não se aplica a uma obtida via CDI) pode ser personalizada e todas as alterações serão válidas para aquela
request apenas. 

Na necessidade de personalização do `ObjectMapper` cujas alterações sejam aplicadas para toda a aplicação isso pode ser
feito de duas maneiras. A primeira é sobreescrevendo a produção das instâncias com um 
[produtor do JAX-RS](https://docs.oracle.com/javaee/7/api/javax/ws/rs/ext/ContextResolver.html) personalizado,
excluindo o fornecido pela Backend Foundation do `ApplicationConfig` ou especializando ele (via extensão e anotação `@Specializes`). 

```java
@Provider
public class ExampleObjectMapperProducer implements ContextResolver<ObjectMapper> {
    
    @Override
    public ObjectMapper getContext(Class<?> ignored) {
        final ObjectMapper mapper = new ObjectMapper();
        // ...
        return mapper;
    }
    
}
```

A segunda é através do qualificador de injeção `ApplicationObjectMapper`. Usar essa qualificação leva a Backend Foundation
entregar na injeção a instância modelo do `ObjectMapper` e qualquer alteração feita nela será usada em todas as requests 
futuras.

```java
public class Example {
    @Inject
    @ApplicationObjectMapper
    private ObjectMapper mapper;
    
    @PostConstruct
    public void customize() {
        mapper.addDeserializer(ExampleType.class, ExampleTypeDeserializer.class);
    }
}
```
 
Para maiores informações consulte o 
[JavaDoc do ObjectMapper](https://fasterxml.github.io/jackson-databind/javadoc/2.7/com/fasterxml/jackson/databind/ObjectMapper.html).

### CDI

CDI é um mecanismo de injeção de dependências e gerenciamento do ciclo de vida contextual de uma aplicação. Em outras 
palavras, CDI é um mecanismo que permite aplicar o principio e inversão de responsabilidade (IoC).

A Backend Foundation disponibiliza CDI utilizando o [Weld](http://weld.cdi-spec.org/) como provedor na [versão 1.1 da
especificação](https://jcp.org/en/jsr/detail?id=346). 

O CDI é uma ferramenta que oferece recursos interessantes para a aplicação como um todo. 
[Consulte a documentação](http://cdi-spec.org/#overview) para conhecer todos esses recursos e entender como eles podem 
ser úteis. 

### Coleta e publicação de métricas

A Backend Foundation permite a coleta e publicação de métricas de desempenho da aplicação por meio da API disponibilizada
pelo módulo `commons-metrics` baseada na implementação do [Dropwizard Metrics](https://metrics.dropwizard.io/).

O termo "métrica" refere-se a estatísticas gerais e medidas de desempenho da aplicação. Ele pode ser entendido como um 
meio de mensuração de desempenho por meio de uma coleção de dados específicos ou gerais. 

Exemplos de métricas são:
- Porcentagem de uso de processador
- Porcentagem do uso do heap da JVM
- Tempos e quantidades de execuções do Garbage Colletor
- Quantidade de requests recebidas em um método de um resource

#### Funcionamento da API de métricas

A API de métricas funciona baseada em três pontos: Coletores, Registro e Repórteres.

- Registro: Repositório das métricas coletadas e disponíveis para consulta. Todos os dados disponíveis são sempre instantâneos 
ou os ultimos coletados/disponíveis.
- Coletor: Componente responsável por identificar, calcular os valores de métricas e publicar elas no registro. Um exemplo de
coletor é aquele que acompanha o status da JVM e publica valores de consumo de recursos (memória, processador e etc), do heap,
Garbage Collector e outros.
- Repórter: Responsável por monitorar as métricas disponíveis no registro e exportar elas
para outros meios, tornando-as disponíveis para consulta e análise. Exemplos de exportação é tornar as métricas disponíveis
para consulta em um endpoint REST, em um cluster Elasticsearch ou via JMX. A coleta dos valores disponíveis pode ou não ser
em tempo real, sob demanda ou agendado; varia conforme a implementação do repórter.

#### Implementações disponíveis para uso

A API de Métricas disponibiliza algumas implementações padrão para uso. A relação
abaixo contêm quais são eles e qual o seu uso.

##### Repórters

- Elasticsearch: Coleta as métricas disponíveis no registro e publica elas
automaticamente em um cluster Elasticsearch a cada 30 segundos (o tempo
de publicação pode ser personalizada).
- JMX: Coleta as métricas disponíveis no registro e torna elas disponíveis
para consulta sob demanda via API JMX do Java.

Instâncias dos repórters relacionados acima podem ser obtidas através da classe
`MetricsReporters`.

##### Coletores

- JVM: Monitora e coleta os valores da JVM. Os valores coletados incluem dados
do consumo de memória, atributos da JVM, estatísticas do Garbage Collector, 
estatísticas das threads da aplicação e dos buffers da JVM.
- Jetty: Monitora e coleta os dados das solicitações e repostas gerenciadas 
pelo Jetty. Os dados publicados incluem quantidades de requests por tipo (GET,
POST, PUT, etc), quantidades de respostas por status (200, 201, 404, etc),
dentre outros.
- Jersey: Coleta e publicação de estatisticas de quantidades de execução e 
tempos para execução, dentre outros, dos métodos de resources JAX-RS 
devidamente anotados.
- Log4j2: Monitoramento e publicação de informações a respeito dos eventos de log,
como quantidade de eventos por nível (DEBUG, INFO, ERROR, etc).

Instâncias dos coletores relacionados acima podem ser obtidas através da classe
`MetricsCollectors`.

#### Passo-a-passo e exemplos de uso da API de métricas

A implementação da API de métricas resume-se a 1 classe e 2 interfaces que são `Metrics`, 
`MetricsColletor` e `MetricsReporter`. As duas últimas são as interfaces da API para 
coletores e repórters respectivamente, enquanto a primeira é o ponto central da API
para controle dela. Há ainda as classes utilitárias `MetricsCollectors` e `MetricsReporters` 
que permitem acesso simplificado a instâncias das interfaces mencionadas para cenários comuns.

O primeiro passo para uso da API é a inicialização dela. A inicialização consistem em informar
qual o repórter que deve ser usado bem como identificação (nome) da aplicação em execução.

```java
Metrics.getInstance().initialize(
    "ExampleApplication",
    MetricsReporters.jmx()
);
```

Após inicializada, o segundo passo é o registro dos coletores que devem funcionar na aplicação.

```java
// Instância do Jetty Server
final Server jettyServer = ...;

// Instância do objeto de configuração do Jersey
final ResourceConfig jerseyConfig = ...;

Metrics
    .getInstance()
    .startCollector(MetricsCollectors.jvm())
    .startCollector(MetricsCollectors.log4j())
    .startCollector(MetricsCollectors.jersey(jerseyConfig))
    .startCollector(MetricsCollectors.jetty(jettyServer))
    .startCollector(new MyCustomExampleCollector());
```

##### Métricas em resources REST

Diferente das demais implementações padrão de coletores, o do Jersey para resources REST baseados em JAX-RS
não coleta e publica métricas automagicamente, é necessário instruir a API quais métodos e resources
precisam ser monitorados e quais informações devem ser publicadas.

Essa identificação é feita por meio de anotações nos resources. As anotações disponíveis são:
- `@Metered`: Registra e publica métricas gerais do método, como execução e tempos.
- `@Counted`: Registra e publica valores quantitativos de execução do método.
- `@Gauge` e `@CachedGauge`: Métodos anotados como `Gauge` terão seu valor de retorno usado como o valor
da métrica de nome definido na anotação. Em outras palavras, o valor que o método anotado retornar
será publicado como uma métrica no registro.
- `@ExceptionMetered`: Monitora as exceções em um método publicando informações a respeito delas quando elas 
acontecem.
- `@Metric`:  Qualificador de injeção de objetos de métricas (como o `Histogram`) para lançamento manual ou personalizado de métricas bem como consultas.
- `@ResponseMetered`: Monitora as respostas do método publicando dados como o status (2XX, 3XX, etc)
- `@Timed`: Monitora o tempo de execução do método

Exemplo de uso das anotações em um resource:

```java
public class ExampleResource {

    @Inject
    private ExampleService service;

    @Metric(name = "applicationDomainExampleMetric")
    private Histogram histrogram;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Timed
    @Counted
    @ResponseMetered
    public Response getExample() {
        final Example response = service.doSomething();

        if (response == null) {
            return Response.notFound();
        }

        histogram.update(response.getSomething());
        return Response.ok(response).build();
    }
}
```

## Gerenciamento remoto

O gerenciamento remoto consiste na exposição de APIs administrativas da aplicação em um contexto isolado do JAX-RS 
na aplicação em uma porta HTTP adicional configurável (geralmente 8082).

Neste contexto são expostos recursos que forecem informações de caráter administrativo, como o status da aplicação 
(detalhado na seção [Health Check](#health-check)), permitindo que automações verifiquem a situação interna de execução da aplicação.

A API de gerenciamento remoto não é inicializada por padrão. Consulte as [opções de configuração](configuration-options.md#gerenciamento-remoto)
para maiores informações de como ativar.

### Publicação de recursos na API de gerenciamento remoto

Qualquer implementação compatível com o JAX-RS pode ser publicada no contexto de gerenciamento através da anotação `ManagementComponent`, 
seja ela um `Resource`, `Feature`, `Filter` ou outros.

```java
@ManagementComponent
@Path("/example")
public class ExampleResource {
    
    @GET
    public Response sayHello() {
        return Response.ok("Hello").build();
    }
}
```

Opcionalmente, quando o registro deve ser feito condicionalmente baseado em regras internas da implementação, há a interface
`ConditionalComponent` que permite indicar à API quando o componente deve ser inicializado.

```java
@ManagementComponent
@Path("/example")
public class ExampleResource implements ConditionalComponent {
    
    @Override
    public boolean isComponentEnabled() {
        return true;
    }
}
```

### Health Check

A API de Health Check consiste na validação de pontos internos da aplicação, como status da conexão do banco de dados, para
permitir que agentes externos consigam consultar o status de integridade da aplicação em tempo de execução.

O recurso funciona baseado em dois pontos:
- Implementações da interface `HealthCheck`, responsáveis por executar as validações e retornar o status da aplicação
- Recurso JAX-RS exposto na API de gerenciamento remoto que permite a consulta do status da aplicação

Por padrão a Backend Foundation disponibiliza duas implementações da `HealthCheck`, que são:
- `DatabaseHealthCheck`, responsável por validar o status da conexão com o banco de dados
- `HttpHealthCheck`, responsável por validar se o contexto do JAX-RS está online

Implementações personalizadas da interface `HealthCheck` serão identificadas e registradas automaticamente através do CDI.
Vale salientar que implementações precisam fornecer um nome de identificação e este nome precisa ser único.

```java
public class Example implements HealthCheck {
    
    @Override
    public String getName(){ 
        return "example";
    }
    
    @Override
    public Health check() {
        return Health.healthy();
    }
}
``` 

## Outras informações úteis

Boa parte dos recursos disponibilizados pela Backend Foundation baseiam-se em componentes do Java EE. Se você já tem um 
conhecimento prévio das especificações irá se sentir confortável no entendimento da biblioteca.

Em cada seção desde documento que descreve uma funcionalidade você geralmente irá encontrar qual a implemetação usada 
pela Backend Foundation para entregar a funcionalidade. A leitura da documentação desses provedores é recomendada e 
pode auxiliar na resolução de dúvidas e problemas.