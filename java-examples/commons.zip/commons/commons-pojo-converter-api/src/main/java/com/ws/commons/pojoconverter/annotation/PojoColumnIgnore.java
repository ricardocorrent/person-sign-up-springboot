package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>
 * Annotation created to flag the fields that should be ignored in the POJO conversion process.
 * Ignoring any POJO field reduces data processing, resulting in better POJO conversion performance.
 * </p>
 *  <pre>
 *      public class ClassConvertible01 implements DefaultPojoConverter {
 *          // Means that field 'longObject' will be ignored from 'ClassConvertible02'
 *         {@literal @PojoColumnIgnore(fields = {"longObject"})}
 *          private ClassConvertible02 convertibleObject;
 *      }
 *
 *      public class ClassConvertible02 implements IPojoConverter {
 *          private Long longObject;
 *      }
 *  </pre>
 *
 * @author  Diego Armange Costa
 * @see     IPojoConverter
 * @since   5.0.0 2017-06-13
 * @deprecated
 */
@Target({FIELD})
@Retention(RUNTIME)
@Deprecated
public @interface PojoColumnIgnore {
    
    /**
     *  Defines the target class of the conversion, for which this annotation will take effect.
     *  
     *  @return the target class
     */
    Class<?>[] value() default {};
    
    /**
     * Defines which fields should be ignored.
     * 
     * @return the ignored fields.
     */
    String[] fields() default {};
}
