package com.ws.commons.pojoconverter.provider;

import com.ws.commons.pojoconverter.annotation.PojoInstanceProvider;

/**
 * PojoConverter custom instance provider.
 *
 * <p>This interface defines the required method fired by PojoConverter to resolve an object instance when converting
 * between DTO and entity when the instance in the source object isn't already compatible with the target object.
 * The instance returned by this class implementation will be used as the target instance of any given field during the
 * conversion flow, allowing to intercept and personalize object instantiation in PojoConverter API.</p>
 *
 * <p>Please be aware that any instance produced using this interface will not be validated by the PojoConverter. In
 * another words, double-check if your implementation always returns a valid instance in all calls or a exception
 * (eg, {@link NullPointerException} or {@link ClassCastException}) can be thrown.</p>
 *
 * <p>Any implementation of this class can be CDI compatible and be discovered using it, but there's no guarantee that
 * the call will always happens using CDI since any implementation can also be discovered using {@link PojoInstanceProvider}
 * annotation.</p>
 *
 * @param <T>   the generic target type that this implementation can produce instances of
 * @author      Lucas Dillmann
 * @since       7.3.0 - 2018-09-10
 * @deprecated
 */
@Deprecated
public interface PojoConverterInstanceProvider<T> {

    /**
     * Produces a instance compatible with the given target class.
     *
     * @param targetClass      target class where a instance is needed
     * @param sourceFieldValue source value being converted for the needed instance, when available
     * @return                 Object instance to be used in the target of the conversion
     */
    T produce(final Class<? extends T> targetClass,
              final Object sourceFieldValue);

}
