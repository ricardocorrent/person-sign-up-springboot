package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>
 * Annotation created to map the source and target of the conversion of an attribute of the class that implements {@link PojoColumnMapper}.
 * This mapping should be used when the attribute name of the source class is not the same as the target class attribute,
 * or when they do not have the same hierarchical structure.
 * </p>
 * <pre>
 *  public class Example {
 *  
 *      public static void main(String[] args) {
 *          Example example = new Example();
 *          Entity entity = example.new Entity();
 *          entity.id = 1L;
 *          entity.serviceId = 2L;
 *          
 *          ViewObject viewObject = example.new ViewObject();
 *          viewObject.id = 3L;
 *          viewObject.service = example.new ServiceDTO();
 *          viewObject.service.id = 4L;
 *          
 *          System.out.println("\nEntity to VO: ");
 *          System.out.println(PojoConverter.getInstance().convert(ViewObject.class, entity).id);
 *          System.out.println(PojoConverter.getInstance().convert(ViewObject.class, entity).service.id);
 *          System.out.println("\nVO to Entity: ");
 *          System.out.println(PojoConverter.getInstance().convert(Entity.class, viewObject).id);
 *          System.out.println(PojoConverter.getInstance().convert(Entity.class, viewObject).serviceId);
 *      }
 *      
 *      public class Entity implements {@literal IPojoConverter<ViewObject>} {
 *          Long id;
 *  
 *          {@literal @PojoColunmMapper(target="service.id")}
 *          Long serviceId;
 *      }
 *  
 *      public class ViewObject implements {@literal IPojoConverter<Entity>} {
 *          Long id;
 *  
 *          {@literal @PojoColunmMapper(source="service.id", target="serviceId")}
 *          ServiceDTO service;
 *      }
 *  
 *      public class ServiceDTO {
 *          Long id;
 *      }
 *  }
 * </pre>
 * 
 * @author  Diego Armange Costa
 * @see     IPojoConverter
 * @since   5.0.0 2017-06-01
 * @deprecated
 */
@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Repeatable(PojoColumnsMapper.class)
@Deprecated
public @interface PojoColumnMapper {
    /**
     * <pre>
     *  Sets the path for access to the source attribute. When the path represents a hierarchy of attributes, a period (.) must be used as the separator.
     *  
     *  ...
     *  public class Entity implements IPojoConverter{@code <ViewObject>} {
     *      Long id;
     *  
     *     {@literal @PojoColunmMapper(target="service.id")}
     *      Long serviceId;
     *  }
     *  
     *  public class ViewObject implements IPojoConverter{@code <Entity>} {
     *      Long id;
     *  
     *     {@literal @PojoColunmMapper(source="service.id", target="serviceId")}
     *      ServiceDTO service;
     *  }
     *  ...
     *  
     * </pre>
     * 
     * @return  source column path
     * @see     PojoColumnMapper
     */
    String source() default "";
    
    /**
     * <pre>
     *  Sets the path for access to the target attribute. When the path represents a hierarchy of attributes, a period (.) must be used as the separator.
     *  
     *  ...
     *  public class Entity implements IPojoConverter{@code <ViewObject>} {
     *      Long id;
     *  
     *     {@literal @PojoColunmMapper(target="service.id")}
     *      Long serviceId;
     *  }
     *  
     *  public class ViewObject implements IPojoConverter{@code <Entity>} {
     *      Long id;
     *  
     *     {@literal @PojoColunmMapper(source="service.id", target="serviceId")}
     *      ServiceDTO service;
     *  }
     *  ...
     * </pre>
     * 
     * @return  target column path
     * @see     PojoColumnMapper
     */
    String target() default "";

    /**
     * Defines if a null value should be converted for the given field or should be skipped
     */
    boolean convertNulls() default false;
}
