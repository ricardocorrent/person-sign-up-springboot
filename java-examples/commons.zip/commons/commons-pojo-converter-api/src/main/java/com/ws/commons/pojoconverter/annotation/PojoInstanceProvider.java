package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.provider.PojoConverterInstanceProvider;
import java.lang.annotation.*;

/**
 * Annotation to define a custom instance provider for a field or class.
 *
 * <p>This annotation allows to intercept and personalize the instance creation made by PojoConverter for any
 * given field or class. Among others, a custom instance provider allow the conversion between DTO and entity using
 * fields with type to an abstract class or a interface (and can't be directly instantiated using Java Reflection API).</p>
 *
 * @author  Lucas Dillmann
 * @since   7.3.0 - 2018-09-11
 * @deprecated
 */
@Target({ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Deprecated
public @interface PojoInstanceProvider {

    /**
     * Defines the {@link PojoConverterInstanceProvider} implementation that should be used to resolve and return the target
     * object instance of the annotated field or class during the conversion.
     *
     * <p>This parameter allows to intercept and customize the object instantiation during the PojoConversion flow. When
     * provided, the factory class will be called to create and return the correct object instance to be used in the
     * target field of the conversion.</p>
     *
     * <p>This factory can be used in special cases where the target class uses or are abstract classes or interfaces that can't
     * be directly instantiated by the PojoConverter using Java Reflection API.</p>
     *
     * <p>When provided, this implementation should always return an instance that is compatible with the target field
     * of the conversion or an exception will be thrown.</p>
     *
     * <p>When no value is provided then the PojoConverter API will try to locate a implementation of the
     * {@link PojoConverterInstanceProvider} using CDI strategies or, when not available, PojoConverter will use it's
     * default strategy to create an instance by using the target field type class.</p>
     *
     * @return Implementation class of a {@link PojoConverterInstanceProvider} able to create instances for the
     * annotated field or class
     */
    Class<? extends PojoConverterInstanceProvider> value();

}
