package com.ws.commons.pojoconverter;

/**
 * This interface should be used to determine which class artifacts (fields) should have their attributes converted.
 *
 * <p>Interface used to map the conversion between POJOs. Any class that needs to be converted using PojoConverter must
 * implement this interface. Otherwise, the conversion won't be done.</p>
 *
 * <pre>
 *  public class Entity implements IPojoConverter {
 *      private Long id;
 *      private Child child;
 *      ...
 *  }
 *  
 *  // When an Entity class object is converted, the child field object will also be converted, as it has the signature of this interface.
 *  public class Child implements IPojoConverter {
 *      private Long id;
 *      
 *      {@code @PojoColunmMapper(target="service.id")}
 *      private Long serviceId;
 *      ...
 *  }
 *  
 *  public class EntityDTO implements IPojoConverter {
 *      private Long id;
 *      private ChildDTO child;
 *      ...
 *  }
 *  
 *  public class ChildDTO implements IPojoConverter {
 *      private Long id;
 *
 *      {@code @PojoColunmMapper(source="service.id", target="serviceId")}
 *      private ServiceDTO service;
 *      ...
 *  }
 *  
 *  public class ServiceDTO implements IPojoConverter {
 *      private Long id;
 *      ...
 *  }
 * </pre>
 *
 * @author  Diego Armange Costa
 * @version 6.0.0 - 2018-02-15 - Default implementations removed.
 * @since   5.0.0 - 2017-06-01
 * @deprecated
 */
@Deprecated
public interface IPojoConverter {}
