package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>Allows you to reference the declaring instance at any hierarchical level.</p>
 * <p>Can be applied to singular objects or collections of objects.</p>
 * <p>However, when applied in collections, it can reduce performance, since for each item in the collection,
 * a hash combined with the referenced upper instance will be stored to conversion scope.</p>
 *
 * <pre><code>
 * //Conversion source
 * public class Customer {
 * 
 *     private Location location;
 *     
 *     //OR
 *     
 *     private List{@literal <Location>} location;
 * }
 * 
 * public class Location {
 * 
 *    {@literal @PojoColumnBackReference({"id"})}
 *     private Customer customer;
 * }
 * </code></pre>
 *
 * @author  Diego Armange Costa
 * @see     IPojoConverter
 * @since   5.0.0 - 2017-06-01
 * @deprecated
 */
@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Deprecated
public @interface PojoColumnBackReference {
    /**
     * <b>Caution:</b>
     * Bi-directionally mapped attributes will cause cyclic referencing.
     * @return the name of the attributes that must be converted.<br>
     */
    String[] value();
}
