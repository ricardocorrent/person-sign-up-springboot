package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>
 * Annotation created to filter specific fields within a convertible field.
 * </p>
 * <pre>
 * {@literal public class ParentPojo implements IPojoConverter<ClassConvertible01TO>} {
 *
 *  ...
 *
 *     {@literal @PojoColumnFilter({"id", "description"})}
 *      private ChildPojo filteredField;
 *
 *  ...
 *
 *  }
 * </pre>
 *
 * @author  Diego Armange Costa
 * @see     IPojoConverter
 * @since   5.0.0 2017-07-03
 * @deprecated
 */
@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Deprecated
public @interface PojoColumnFilter {
    /**
     * @return the columns list to be filtered.
     */
    String[] value();
}
