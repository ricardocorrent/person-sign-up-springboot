package com.ws.commons.pojoconverter.annotation;

import com.ws.commons.pojoconverter.IPojoConverter;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>Annotation to define an array of {@link PojoColumnMapper}.</p>
 *
 * <p>This annotation is used to define which fields may be mapped from received DTO (source) to a POJO, the target entity
 * declared in the parent one.</p>
 *
 * <p>Example usage:</p>
 *
 * <pre>
 *     public class Customer extends SoftDeleteDatabase implements IPojoConverter {
 *         {@literal @PojoColumnsMapper}({
 *              {@literal @PojoColumnMapper}(source="location.id", target="locationId"),
 *              {@literal @PojoColumnMapper}(source="location.description", target="locationDescription"),
 *              {@literal @PojoColumnMapper}(target="mapping.path.location")
 *          })
 *          private Location location;
 *     }
 *
 *     public class Location implements IPojoConverter {
 *         private UUID id;
 *         private String description;
 *     }
 * </pre>
 *
 * <p>By receiving a request with the JSON like:</p>
 * <pre>
 * {
 *     "location": {
 *         "id": "8c8fe715-7ae3-4007-ba52-ad75b33a7274"
 *         "description": "Any location"
 *     }
 * }
 * </pre>
 * <p>the fields location.id and location.description will be mapped to attributes 'id' and 'description' from the Location
 * class.</p>
 * 
 * @author  Diego Armange Costa
 * @see     PojoColumnMapper
 * @see     IPojoConverter
 * @since   5.0.0 2017-06-01
 * @deprecated
 */
@Target({FIELD})
@Retention(RUNTIME)
@Documented
@Deprecated
public @interface PojoColumnsMapper {
    
    /**
     * @return  Pojo column mapper
     * @see     PojoColumnMapper
     */
    PojoColumnMapper[] value();
}
