package com.ws.server.patch.jsonpatch.artifacts;

/**
 * Test artifact for {@link com.ws.server.patch.jsonpatch.JsonPatchProcessorUnitTests}
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
public class PatchEntity {

    private Long id;
    private String description;
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
