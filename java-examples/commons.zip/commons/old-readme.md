# Commons

#### Links úteis
- [JavaDoc do projeto e seus módulos](#documentacao)
- [Artefato no Nexus](http://nexus.wssim.com.br/#browse/search=group.raw%3Dbr.com.wealthsystems%20AND%20name.raw%3Dcommons)
- [Histórico de aterações](changes.md)

#### Status do pipeline

|master|development|
|------|-----------|
|![master build status](https://gitlab.wssim.com.br/platform/commons/badges/master/build.svg)|![development build status](https://gitlab.wssim.com.br/platform/commons/badges/development/build.svg)|

## Sumário

<!-- TOC depthFrom:1 depthTo:4 orderedList:false withLinks:false anchorMode:gitlab.com -->

- 1 - [Introdução](#introducao)
    - 1.1 [Dependências](#dependencias)
- 2 - [Propriedades](#propriedades)
    - 2.1 - [Formatação do `application.yml`](#propriedades.app)
    - 2.2 - [Formatação `apache-deltaspike.properties`](#propriedades.prop)
    - 2.3 - [Propriedades Válidas](#propriedades.val)
- 3 - [Server](#server)
    - 3.1 - [URL Base](#server.url)
    - 3.2 - [Serialização e Deserialização JSON](#server.json)
        - 3.2.1 - [Exemplo de `Serializer`](#server.json.ex1)
        - 3.2.2 - [Exemplo de `Deserializer`](#server.json.ex2)
        - 3.2.3 - [`DateSerializer`](#server.json.ex3)
        - 3.2.4 - [Tratamento personalizado de exceções de deserialização de JSON](#server.json.exceptionHandling)
    - 3.3 - [Validação](#server.validation)
        - 3.3.1 - [`BeanValidation`](#server.validation.bean)
        - 3.3.2 - [Validações lógicas](#server.validation.logic)
        - 3.3.3 - [`LogicError`](#server.validation.logicerror)
        - 3.3.4 - [`IndexedLogicError`](#server.validation.indexed)
        - 3.3.5 - [Integrando com o `BeanValidation` - `@BeanValidationIntegrated`](#server.validation.beanintegrated)
        - 3.3.6 - [Exception lógicas](#server.validation.logicalexceptions)
        - 3.3.7 - [Validações para entidades](#server.validation.entity)
            - 3.3.7.1 - [Validações sem filtros](#server.validation.entity.nofilter)
            - 3.3.7.2 - [Validações com filtros](#server.validation.entity.withfilter)
    - 3.4 - [Classes abstratas](#server.abstractclasses)
        - 3.4.1 - [`AbstractResource<T extends BaseEntity, P extends PaginationSearch>`](#server.abstractclasses.resource)
        - 3.4.2 - [`AbstractService<T extends BaseEntity>`](#server.abstractclasses.service)
        - 3.3.3 - [`AbstractDAO<T extends BaseEntity>`](#server.abstractclasses.dao)
    - 3.5 - [Projections REST](#server.projections)
    - 3.6 - [Filtros REST](#server.filters)
        - 3.6.1 - [Usando o Builder e Parser](#server.filters.builder)
    - 3.7 - [`PagedList<T>`](#server.pagedlist)
    - 3.8 - [`RestAuthorizationRealm` (Autorizações Shiro)](#server.authrealm)
    - 3.9 - [Autenticação/Autorização via JWT](#autenticacao.jwt)
    - 3.10 - [Sessão Redis](#server.redis)
    - 3.11 - [`UserContext`](#server.usercontext)
    - 3.12 - [REST PATCH](#server.restpatch)
    - 3.13 - [Resource Interfaces](#server.interfaces)
        - 3.13.1 - [Interfaces Disponiveis](#server.interfaces.available)
        - 3.13.2 - [Exemplos](#server.interfaces.examples)
- 4 - [Persistence](#persistence)
    - 4.1 - [Configuração Banco de dados](#persistence.dbconfig)
    - 4.2 - [`Ebean`](#persistence.ebean)
        - 4.2.1 - [Produção de instâncias do EbeanServer para um tentant específico](#persistence.ebean.specificTenant)
    - 4.3 - [Tenant](#persistence.tenant)
    - 4.4 - [DAOs](#persistence.dao)
        - 4.4.1 - [RestQueryAdapter](#persistence.dao.restQueryAdapter)
    - 4.5 - [Ordenação de resultados usando os nomes dos atributos de um DTO](#persistence.dtoSort)
    - 4.6 - [Vault](#persistence.vault)
    - 4.7 - [Reciclagem](#persistence.recycling)
        - 4.7.1 - [DefaultRecycleListener](#persistence.recycling.defaultRecycler)
- 5 - [Diplomat](#diplomat)
    - 5.1 - [Configuração](#diplomat.config)
    - 5.2 - [Uso](#diplomat.usage)
- 6 - [Logging](#logging)
    - 6.1 - [Informação](#logging.info)
    - 6.2 - [Rastreamento de comunicação REST (requisições e respostas)](#logging.requests)
- 7 - [Transactions](#transactions)
- 8 - [Sincronização](#sync)
- 9 - [DTO - Data transfer object e Conversões de POJO.](#dto)
     - 9.1 - [Utilizando anotações.](#dto.usage)
        - 9.1.1 - [Anotações disponíveis.](#dto.usage.annotations)
        - 9.1.2 - [Exemplos](#dto.usage.examples)
     - 9.2 - [Conversão de classes(manual).](#dto.classconvert)
     - 9.3 - [Conversão por mapeamento(manual).](#dto.mapconvert)
     - 9.4 - [Localização de mapeamentos de campos por entidade(MappingLocator).](#dto.mappinglocator)
        - 9.4.1 - [Acessando o nome do campo no DTO pelo nome do campo na entidade.](#dto.mappinglocator.dtofield)
        - 9.4.2 - [Acessando o nome do campo na entidade pelo nome do campo no DTO.](#dto.mappinglocator.entityfield)
        - 9.4.3 - [Convertendo um caminho com subcampos de DTO para um caminho com subcampos de entidade.](dto.mappinglocator.convert)
     - 9.5 - [Interceptação e personalização da criação de instâncias de objetos durante a conversão](#dto.instanceProvider)
- 10 - [Conversão automatica na camada de Resource.](#resourceautoconvert)
     - 10.1 - [Conversão automática para classes que implementam IPojoConverter.](#resourceautoconvert.withpojo)
     - 10.2 - [Conversão automática por mapeamento de classes.](#resourceautoconvert.withmap)
        - 10.2.1 - [Exemplo mapeamento de classes](#resourceautoconvert.withmap.examples)
     - 10.3 - [Anotações disponíveis](#resourceautoconvert.availableAnnotations)
- 11 - [Configuração da aplicação](#appconfig)
     - 11.1 - [Inicialização padrão](#appconfig.default)
     - 11.2 - [Inicialização personalizada](#appconfig.custom)
     
<!-- /TOC -->

# 1 - Introdução <a name="introducao"></a>

A lib commons tem por objetivo fornecer a base necessária para levantar e desenvolver um micro serviço nos padrões propostos na aplicação Sollar.

As funcionalidades/tecnologias que esta lib provê são:

Persistência -> [Ebean ORM](http://ebean-orm.github.io/)
Server -> [Embedded Jetty](http://www.eclipse.org/jetty/documentation/current/embedding-jetty.html)
REST -> [Jersey Jax-RS](https://jersey.java.net/)
Log -> [Logback](http://logback.qos.ch/)
JSON -> [Jackson](http://wiki.fasterxml.com/JacksonHome)
Injeção de dependencias -> [CDI](http://weld.cdi-spec.org/)
Configuração -> [Apache Deltaspike](https://deltaspike.apache.org/)
Fila de mensagem -> [Apache Kafka](https://kafka.apache.org/)

Visando facilitar o uso e agrupamento destas tecnologias a lib commons abstrai e facilita o uso das tecnologias supracitadas.


## 1.1 - Dependências <a name="dependencias"></a>

- Wayland 4.0.0
- Commons-test 3.0.0
- Record-Permission 3.0.0-SNAPSHOT

**OBS**: O grupo do artefato foi [alterado](http://nexus.wssim.com.br/#browse/search=keyword%3Dcommons:dfbef09efe1644ea54f157aa1fa50d1b:8b675a96581b72802343c473e6f418b7) de `com.ws` para `br.com.wealthsystems`

# 2 - Propriedades <a name="propriedades"></a>

As propriedades serão buscadas por padrão no arquivo `META-INF/application.yml`, caso o arquivo não exista, será seguido o [padrão ordinal do deltaspike](https://deltaspike.apache.org/documentation/configuration.html).

No serviço `org.apache.deltaspike.core.spi.config.ConfigSource` define-se a classe padrão para a leitura do arquivo de configuração.

Dentro do arquivo `application.yml` poderá existir uma key chamada `org.apache.deltaspike.ProjectStage`. Caso haja valor, será buscado um arquivo `META-INF/application-{value}.yml`. Os valores das keys nesse arquivo irão sobreescrever as já carregadas pelo primeiro arquivo. Caso o arquivo não exista, serão mantidos os valores de `META-INF/application.yml`.

Caso não seja possivel converter as propriedades contidas no arquivo, o sistema irá disparar um erro.


## 2.1 - Formatação `application.yml`<a name="propriedades.app"></a>

No yml as divisões por ponto serão substituidas por identação e dois pontos.
```yml
redis:
    host: '10.24.7.101'
    port: '6379'
    expire: '1000'
    timeout: '0s'
    session: 
        enabled: 'True'
```
Os valores devem ser informados entre aspas simples e as chaves devem ser identadas com no mínimo 2 espaços.
Entre os dois pontos da key e o valor deve haver 1 espaço


## 2.2 - Formatação `apache-deltaspike.properties`<a name="propriedades.prop"></a>
```yml
redis.host=192.168.99.100
redis.port=6379
redis.expire=1000
redis.timeout=0s
redis.session.enabled:true
```
os valores devem ser informados diretamente, sem aspas simples, e as keys devem ser divididas por ponto.


## 2.3 - Propriedades válidas <a name="propriedades.val"></a>

| Propriedade                               | Tipo          | Default value | Observação                    |
|--------------------------------------     |---------------|---------------|------------------------------ |
| `org.apache.deltaspike.ProjectStage`      | String        | null          | Nome do perfil de desenvolvimento para carregar o segundo arquivo de coniguração |
| `service.name`                            | String        | null          | Nome do módulo/micro serviço   |
| `authorization.service.name`              | String        | user          | Nome do módulo/micro serviço em que devem ser buscadas as autorizações do usuário logado  |
| `authorization.service.api`               | String        | /users/self-permissions | URI da API que fornece as permissões do usuário |
| `port`                                    | Integer       | 80            | Porta que o microserviço expõe |
| `host`                                    | String        | null          | Ip que o microserviços registrará no servidor de descoberta (Consul) |
| `discovery.service.address`               | String        | null          | Ip do servidor de descoberta   |
| `diplomat.environment`                    | String        | local         | Define a partir de qual ambiente a lib commons estará ao se registrar no servidor de descoberta. Outros valores são "cloudfoundry" e "docker"|
| `db.url`                                  | String        | null          | URL do banco de dados          |
| `db.username`                             | String        | null          | Usuário de banco de dados      |
| `db.password`                             | String        | null          | Senha de banco de dados        |
| `db.driver`                               | String        | null          | Driver de conexão ao banco de dados       |
| `db.schema`                               | String        | null          | Schema de banco de dados (Utilizado somente em stage Development, permitindo simular o tenant)  |
| `db.platform`                             | String        | com.avaje.ebean.config.dbplatform.PostgresPlatform| Plataforma de base de dados que está sendo utlizada |
| `redis.host`                              | String        | 127.0.0.1     | Ip do servidor Redis           |
| `redis.port`                              | Integer       | 6379          | Porta do servidor Redis        |
| `redis.password`                          | Integer       | 6379          | Senha de acesso ao servidor Redis     |
| `redis.expire`                            | Integer       | 0             | Tempo de duração da sessão do usuário |
| `redis.timeout`                           | Integer       | 0             | Timeout de conexão com o server Redis |
| `redis.session.enabled`                   | Boolean       | true          | Habilita a conexão com o servidor Redis para buscar a sessão do usuário |
| `test.mock.user`                          | String        | false         | Indica se deseja-se criar simular um usuário autenticado para o server(**Depreciado**) |
| `test.userid`                             | String(UUID)  | null          | UUID a ser utilizado para simular a sessão do usuário. (Pode ser um valor de UUID aleatório)(**Depreciado**)|
| `test.username`                           | String        | null          | USERNAME a ser utilizado para simular a sessão do usuário. (Deve condizer com os valores informanfod no arquivo shiro.ini)(**Depreciado**)|
| `test.password`                           | String        | null          | PASSWORD a ser utilizado para simular a sessão do usuário. (Deve condizer com os valores informanfod no arquivo shiro.ini)(**Depreciado**)|
| `org.apache.deltaspike.ProjectStage`      | String        | Production    | Estágios de desenvolvimento https://deltaspike.apache.org/documentation/projectstage.html  |
| `tenant.mode`                             | String        | SCHEMA        | Forma como a persistencia irá trabalhar, com tenant por schema ou db, valores validos(SCHEMA, DB) |
| `ds.removeAbandonedOnBorrow`              | Boolean       | true          | Remove as conexões abandonadas se excederem o ds.removeAbandonedTimeout |
| `ds.removeAbandonedTimeout`               | Integer       | 600           | Tempo em segundos antes que uma conexão abandonada seja removida |
| `ds.removeAbandonedOnMaintenance`         | Boolean       | true          | Remove as conexões abandonadas no ciclo de manutenção, esta propriedade só tem efeito se a ds.timeBetweenEvictionRunsMillis  estiver com valor positivo |
| `ds.timeBetweenEvictionRunsMillis`        | Integer       | 300000        | Tempo de espera entre as execuções do ciclo de manutenção, valor negativo não vai executar nenhum ciclo |
| `ds.softMinEvictableIdleTimeMillis`       | Integer       | 300000        | Tempo minimo para uma conexão ociosa ficar no pool antes que seja eleita para close na proxima manutenção, esta quantidade respeita o ds.minIdle |
| `ds.minEvictableIdleTimeMillis`           | Integer       | 300000        | Tempo minimo que um objeto pode permanecer ocioso no pool antes que seja eleito para despejo |
| `ds.minIdle`                              | Integer       | 0             | Número minimo de conexões que podem ficar ociosas no pool. Zero para não manter nenhuma |
| `ds.maxIdle`                              | Integer       | -1            | Número máximo de conexões que podem permanecer ociosas no pool. Negativo para nenhum limite |
| `ds.logAbandoned`                         | Boolean       | false         | Flag para rastreamento de pilha para o código que abandonou uma conexão. Adiciona sobrecarga a cada declaração de conexão |
| `ds.maxConnLifetimeMillis`                | Integer       | -1            | Tempo máximo de vida para um conexão, após o tempo excedido esta será fechada. Número negativo significa vida útil infinita |
| `ds.maxTotal`                             | Integer       | -1            | Número maximo de conexões ativas que podem ser mantidas no pool. Negativo não define limite |
| `ds.logExpiredConnections`                | Boolean       | false         | Registra uma mensagem indicando que uma conexão está sendo fechada pelo pool devido a maxConnLifetimeMillis excedido |
| `ds.testOnBorrow`                         | Boolean       | true          | O pool faz uma validação na conexão antes de entregar a aplicação, caso falhe é utilizado outra conexão |
| `ds.testOnReturn`                         | Boolean       | false         | O pool faz uma validação na conexão antes de aceitar novamente esta |
| `ds.testWhileIdle`                        | Boolean       | false         | Flag para indicar se o objeto dese ser validado enquanto esta no pool |
| `vault.host`                              | String        | null          | Host para acesso a API do Vault |
| `vault.token`                             | String        | null          | Token para autenticar a requisição a Rest API do vault |
| `vault.api`                               | String        | v1/secret     | Endereço da Rest API do Vault para consumir os dados de conexão com as bases |
| `vault.protocol`                          | String        | http          | Protocolo a ser utilizado na comunicação com o Vault |
| `ebean.server.name`                       | String        | EbeanMultiTenancyServer | Define o nome da instancia do Ebean Server |
| `db.migration.path`                       | String        | filesystem:dbmigration | Caminho para a pasta dbmigration, usar prefixo "classpath:" se estiver dentro do jar |
| `domain`                                  | String        | sollar.com    | Dominio que será utilizado para gerar o token |
| `jwt.timeout.seconds`                     | Integer       | 30            | Tempo para o token expirar |
| `service.version`                         | String        | null          | Versão do módulo/micro serviço  |
| `pojo.column.mapper.metadata.cache.limit` | Integer       | 10            | Determina o limite do CACHE para armazenamento do metadata das classes lidas pelo mecanismo de localização de mapeamento(MappingLocator).|
| `pojo.onlyConvertChangedValues`           | Boolean       | false         | Determina a estratégia de conversão entre DTO e entidade a ser usada pelo `PojoConverter`. Quado definido como `false` o `PojoConverter` irá sempre converter todos os atributos indiferente se eles estão iguais ou não entre o DTO e a entidade. Este comportamento afeta diretamente como o  `AbstractDAO` realiza um posterior `update` ou `merge`, fazendo com que todos os atributos da entidade sejam salvos no banco de dados invariante se eles mudaram ou não. Quando definido como `true`, o `PojoConverter` apenas irá fazer a conversão dos atributos que possuem valores diferentes não-nulos, levando o  `AbstractDAO` a atualizar no banco de dados apenas as mudanças explicitas nos dados (leia a respeito da interceptação das alterações feitas em entidades na documentação do Ebean para maiores informações de como isso funciona). |
| `find.dto.target.on.reading.field.name`   | Boolean       | false         | Define o retorno do nome do campo validado em uma exceção. Retorna o nome do campo da classe DTO quando TRUE ou o nome do campo da entidade quando FALSE.|
| `server.serialization.values.empty`       | Boolean       | true          | Define o retorno padrão para arrays em um JSON. Retorna array vazio quando TRUE ou omite o array do JSON quando FALSE. |
| `server.deserialization.disableDefaultExceptionHandlers` | Boolean       | false          | Define se as implementações padrão da interface `DeserializationExceptionHandler` fornecidas pela commons devem ser usadas ou não. |
| `server.deserialization.disableInterceptionOfMappingExceptions` | Boolean       | false          | Define quais tipos de erro de deserialização de JSON devem ser interceptados. Quando `true`, a API apenas irá encaminhar erros de valor inválido de campos para uma implementação da interface  `DeserializationExceptionHandler` e ignorar as demais exceções. |
| `server.deserialization.disableInterceptionOfAllExceptions` | Boolean       | false          | Define se a API de interceptação e tratamento de exceções de deserialização de JSON deve estar habilitada. Quando `true`, todas as exceções de deserialização não serão tratadas automaticamente ou encaminhadas para uma implementação de `DeserializationExceptionHandler`. |
| `ds.provider`                             | Boolean       | HIKARICP      | Identificação de qual DataSource deve ser usado. Opções disponíveis por padrão: `APACHE_DBCP2` e `HIKARICP`. |
| `ds.connectionTimeoutMillis`              | Integer       | 10000         | Tempo máximo que o DataSource irá aguardar para estabelecer uma conexão com o banco de dados antes de disparar uma exceção |
| `dao.throwRegisterNotFound`               | Boolean       | false         | Flag para indicar se `RegisterNotFoundException` deve ser lançada ao não encontrar um registro com `AbstractDAO#findById` |
| `dao.onlyUpdateChangedFields`             | Boolean       | true          | Define a estratégia de atualizações (`update` ou `merge`) do `AbstractDAO`. Quando `true`, a SQL gerada de `UPDATE` apenas irá conter as colunas com os valores alterados na entidade. Quando `false`, a SQL irá conter todas as colunas invariante se o valor foi alterado ou não. |
| `recycling.disableDefaultRecycler`        | Boolean       | false         | Define se o `DefaultRecycleListener` deve ser ignorado na inicialização da aplicação. O `DefaultRecycleListener` é a implementação padrão da commons responsável por manter o histórico de entidades deletadas do banco de dados. |
| `dao.merge.skipManyToManyDisassociation`  | Boolean       | false         | Define se o componente `ManyToManyDisassociationEngine` do `MergeEngine`, responsável por desassociações em relacionametos ManyToMany, deve ser desabilitado. |
| `dao.mapExceptionToLogicException`        | Boolean       | true          | Flag para indicar se deve ocorrer o mapeamento de qualquer `Exception` lançada para `LogicException` no `AbstractDAO`. |
| `service.throwRegisterNotFound`           | Boolean       | true          | Flag para indicar se `RegisterNotFoundException` deve ser lançada ao não encontrar um registro com `AbstractService#get`. |
** *O estágio **Development** deve ser utilizado em conjunto com a configuração `db.schema`, quando levantado o micro serviço na IDE*

** *Alguns dos dados acima podem ser sobrescritos por algum comportamento da aplicação*

# 3 - Server <a name="server"></a>

## 3.1 - URL Base <a name="server.url"></a>

A URL padrão da API REST deve ser configurada no arquivo web.xml do projeto e seguir o padrão:

```java
http://{host}:{port}/api/{modulename}/{resource}
```
 onde:
```
    {host} - Endereço onde o serviço irá rodar
    {port} - Porta onde o serviço irá ouvir
    {modulename} - Nome do modulo
    {resource} - Recurso que será acessado nessa url
``` 
   Ex.: `http://localhost:8080/api/accesscontrol/users`

O `/api/{modulename}` é adicionado automaticamente com base na configuração do arquivo `web.xml`.

O resource é definido através das annotations do [JAX-RS](https://en.wikipedia.org/wiki/Java_API_for_RESTful_Web_Services) nas classes de Resource e devem seguir o padrão definido no [Documento de API](http://produto.wssim.com.br/sollar/api/).

## 3.2 - Serialização e Deserialização JSON <a name="server.json"></a>

Os Objetos que precisarem de serialização especial ou tratamento de dados para a conversão, necessitarão de uma implementação especifica de `Serializer` e `Deserializer`.

> O `Serializer` receberá o objeto por parametro na hora da conversão, e deverá retornar uma `String` equivalente, para montar o JSON.

> O `Deserializer` receberá a `String` do JSON, e deverá retornar um `Object` equivalente, para montar o Object.

** *A criação destes objetos deve ser encapsulada na lib commons*

### 3.2.1 - Exemplo de Serializer <a name="server.json.ex1"></a>
```java
public class LocalDateSerializer extends JsonSerializer<LocalDate> {

    @Override
    public void serialize(LocalDate value, JsonGenerator gen,
        SerializerProvider serializers)
            throws IOException, JsonProcessingException {

        if (value != null) {
            gen.writeString(value.toString());
        }
    }

}
```
### 3.2.2 - Exemplo de Deserializer <a name="server.json.ex2"></a>
```java
public class LocalDateDeserializer extends JsonDeserializer<LocalDate> {

    @Override
    public LocalDate deserialize(JsonParser jsonParser,
        DeserializationContext ctxt)
            throws IOException, JsonProcessingException {
        ObjectCodec oc = jsonParser.getCodec();
        JsonNode node = oc.readTree(jsonParser);

        LocalDate date = null;
        if (node != null) {
            date = LocalDate.parse(node.asText(),
                DateTimeFormatter.ISO_LOCAL_DATE);
        }

        return date;
    }

}

```
Os `Serializers` e `Deserializers` devem ser registrados na class `ObjectMapperResolver.configureJacksonSerializer()`.
  
#### Exemplo
```java
// Serializer
module.addSerializer(LocalDate.class, new LocalDateSerializer());

// Deserializer
module.addDeserializer(LocalDate.class, new LocalDateDeserializer());
```

### 3.2.3 - `DateSerializer` <a name="server.json.ex3"></a>
Está lib provê suporte de serialização/deserialização para os seguintes `Objects date`
- `LocalDate.class`
- `LocalTime.class`
- `OffsetDateTime.class`
- `OffsetTime.class`

*Caso seja necessario realizar manipulação de datas, estes objetos **devem** ser utilizados*

#### Quando?

> `LocalDate`: Sempre que se desejar manipular uma data, como no formato `2001-01-18`

> `LocalTime`: Sempre que se desejar manipular uma hora, como no formato `22:30:40.050`

> `OffsetDateTime`: Sempre que se desejar manipular uma data com hora, com ou sem o TimeZone, como no formato `2001-01-18T22:30:40.050-03:00`

> `OffsetTime`: Sempre que se desejar manipular uma hora com TimeZone, como no formato `22:30:40.050-03:00`


### 3.2.4 - Tratamento personalizado de exceções de deserialização de JSON <a name="server.json.exceptionHandling"></a>

Exceções de deserialização podem acontecer sempre que um valor inesperado é recebido ou for incompatível com o tipo de 
dados de destino, impossibilitando que a conversão de JSON para objeto seja concluída. 

A commons permite que essas exceções de deserialização sejam interceptadas e tratadas de maneira personalizada por 
meio da interface `DeserializationExceptionHandler`. A atual implementação do provider responsável pela leitura do JSON
irá sempre procurar por uma implementação capaz de tratar a falha para determinado tipo de dados de destino 
(Date, Double, Boolean, etc), delegando para a implementação esse tratamento quando houver uma ou, para os demais casos, 
disparando `InvalidJSONFieldException` e permitindo que esse problema seja tratado em outro momento usando um mapper.

Existem implementações padrão da `DeserializationExceptionHandler` capazes de tratar exceções de conversão para os 
tipos de dados relacionados abaixo.

- BigDecimal
- Boolean
- Character
- Date
- Double
- Float
- Integer
- List
- LocalDate
- LocalDateTime
- LocalTime
- Long
- OffsetDateTime
- OffsetTime
- Set
- Temporal
- UUID
- ZonedDateTime

Caso as implementações padrão não são capazes de atender a sua aplicação de maneira adequada ou não cobrem um tipo de 
dados usado por seu projeto, basta implementar a interface `DeserializationExceptionHandler` em seu projeto para que 
ela substitua automaticamente a implementação padrão da commons. 

Também há a possibilidade de desativar por completo todas as implementações padrão diponibilizadas pela commons. Para
isso utilize a propriedade de configuração `server.deserialization.disableDefaultExceptionHandlers` com o valor `true`.

Para desabilitar o tratamento de exceções de mapeamento (como campos inexistentes), levando a API a apenas interceptar
exceções de valores inválidos em campos válidos, utilize a propriedade de configuração 
`server.deserialization.disableInterceptionOfMappingExceptions` com o valor `true`.

Por fim, para desabilitar a API por completo e tratar todas as exceções manualmente, utilize a propriedade
`server.deserialization.disableInterceptionOfAllExceptions` com o valor `true`.


## 3.3 - Validação <a name="server.validation"></a>

Atualmente existem dois cenários de validação em um mesmo requisito, sendo eles `BeanValidation` e `LogicValidation` sendo necessário analisar a abordagem adequada ao cenário.

### 3.3.1 - `BeanValidation` <a name="server.validation.bean"></a>

Essa validação é realizada diretamente sobre o atributo de uma entidade, onde valores podem ser validados individualmente por meio de Annotations.

Para implementar esta validação basta seguir dois passos.

1°. De acordo com a necessidade, anotar os campos da entidade com as seguintes annotations.

```java

// ##
// import from javax.validation.constraints
// ##
@Size(max = 80, min = 3)   // Define o tamanho max e min de caracteres.
@Digits                    // Define a quantidade digitos.
@Max                       // Define um valor numerico máximo para o campo.
@Min                       // Define um valor numerico mínimo para o campo.

// ##
// import from com.sollar.commons.server.validation.constraints
// ##
@Past                   // Define que um campo de data seja uma data passada.(suporte LocalDate)
@Future                 // Define que um campo de data seja uma data futura.(suporte LocalDate)
@Email                  // Valida o formato de email.
@NotNull                // Define o atributo como obrigatório

//Define os determinados relacionamentos do atributo como obrigatórios
@NotNull.List({
    @NotNull(requiredAttribute = "id"),
    @NotNull(requiredAttribute = "description")
})

```

2°. Adicionar a annotation `javax.validation.@Valid` nos parâmetros do método do Resource.

Exemplo completo de uso do BeanValidation:
```java

// Entidade
@Entity
public class Customer extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Size(max = 80)
    @NotNull
    @Column(length = 80)
    private String name;

    /*...*/

}

// Resource
@Path("/customers")
public class CustomerResource {

    @POST
    public Response insert(@Valid Customer customer) throws Exception {
        /*...*/
    }
}

```

### 3.3.2 - Validações lógicas  <a name="server.validation.logic"></a>
  * Nas validações lógicas que forem necessário lançar `Exception` deve ser utilizado `LogicException`, já existe todo o tratamento necessário no server para utilização da mesma
  * O método que irá executar a validação deve ter a anotação `@Valid` para que seja chamado, este método pode ter dois retornos: `java.lang.Boolean` ou `ValidObject`
       * `java.lang.Bolean` -> para quando a validação não precisa retornar parametros, apenas o `field` e `message`
       * `ValidObject` -> deve ser utilizado quando precisa retornar algum parametro, exemplo : data atual de ser maior que `%CURRENT_DATE%`, neste caso os parametros são adicionados através de um `Map` 
  * Caso seja necessário validações em tempo de execução, exemplo Cadastro de Customer é possivel utilizar a anotação `@DynamicValid` e deve ser retornado um `ListBuilderLogicError`
   
Ex:
```java
public class ObjectValidator extends LogicValidator<Object> {

      @Valid(field = "preco", message = "notnull")
      public boolean valid1(Object value) {
         return value != null;
      }

      @Valid(field = "preco", message = "notempty")
      public ValidObject valid2(Object value) {
         ValidObject valid = new ValidObject();
         if (value.equals("")) {
             valid.setValid(false);
             valid.setParams(parameters);
             return valid;
         }
         valid.setValid(true);
         return valid;
      }

      @DynamicValid
      public ListBuilderLogicError valid3(Object value){
         ListBuilderLogicError builder = new ListBuilderLogicError();
         if(value == null){
             builder.addError(new LogicError("preco", "notnull"));
         }
         if(value.equals("")){
             builder.addError(new LogicError("preco", "notempry"));
         }
         return builder;
      }
}
```

A classe de validação deve estender `LogicValidation<?>` e conter um método para cada validação desejada. Esse método deve ser anotado com a annotation `@Valid` e devem retornar um boolean ou um `ValidObject`.
Através do atributo `restMethods` é possível definir para quais métodos REST a validação será aplicada, permitindo assim diferenciar a execução de validações para updates, inserts ou listagens.
No exemplo a abaixo o método de validação será realizado apenas em chamadas POST ou PUT:

Ex de utilização:

```java

    @Inject
    ObjectValidator validator;

    public void insert(final Object value) {
         validator.valid(value);
         dao.insert(value);
    }
```
**ATENÇÃO: O método `valid` lançará uma `LogicException` que estende `RuntimeException` quando a validação falhar. Não é necessario que esta `LogicException` seja tratada explicitamente, pois a mesma será capturada em uma tratativa global do container.**
### 3.3.3 - `LogicError`  <a name="server.validation.logicerror"></a>

`LogicError` representa um erro qualquer que tenha ocorrido durante as validações, neste objeto podemos informar o campo que foi validado e também a mensagem de erro. Quando é necessário realizar uma validação para subentidades, por exemplo "`Culture` -> `CultureLocation` -> `description`", é possível informar o campo como um path, para assim identificar onde realmente ocorreu o erro. Quando for necessário realizar uma validação em uma lista, podemos informar a posição no item na lista, ex: `Culture` -> `CultureLocation` -> `3` -> `description`.

Exemplo de `LogicError` para field direto de Culture.
```java
    new LogicError("description", "cannot.be.null");
```
Exemplo de `LogicError` para sub-entidades de Culture
```java
    new LogicError("cultureLocation.description", "cannot.be.null");
```
Exemplo de `LogicError` para sub-entidade com tratamento da posição na lista
```java
    new LogicError("cultureLocation.3.description", "cannot.be.null");
```

### 3.3.4 - `IndexedLogicError`  <a name="server.validation.indexedlogic"></a>

Este tipo de `Exception` segue o mesmo conceito do `LogicError`, porém está estruturada em árvore, onde cada nó possuirá uma lista de elementos, podendo qualquer um desses elementos ser um novo nó que conterá uma nova lista de elementos.

#### Implementação

 - Com mensagem estática:
 
```java
    IndexedLogicError indexedLogicError = new IndexedLogicError(0, "any field", "any.message");
    
    AnotherIndexedLogicError indexedLogicError = new IndexedLogicError(1, "any field", "any.message");
    
    //... adds and throws exceptions. (Vide item 3.3.7.X)
```

 - Com mensagem parametrizada:

```java
    Map<String, Object> params = new HashMap<>();
        
    params.put("{0}", "first");
        
    IndexedLogicError indexedLogicParamError = new IndexedLogicError(0, "any field", "any.parameterized.message", "value", params);
    
    //... thows exception. (Vide item 3.3.7.X)
```
#### Retorno

```json
{  
   "0":[  
      {  
         "field":"any field",
         "value":null,
         "message":"any.message",
         "text":null,
         "params":{  
            "message":"any.message"
         }
      }
   ], 
   "1":[  
      {  
         "field":"any field",
         "value":null,
         "message":"any.message",
         "text":null,
         "params":{  
            "message":"any.message"
         }
      }
   ]
}
```

### 3.3.5 - Integrando com o `BeanValidation` - `@BeanValidationIntegrated`  <a name="server.validation.beanintegrated"></a>

Essa integração adiciona a possibilidade de executar as validações lógicas juntamente com o `BeanValidation`, evitando que ocorra validação em dois passos. Para utilizar basta adicionar a anotação `@BeanValidationIntegrated` no seu validator.
Os validadores que possuem a anotação são executados juntamente com o `BeanValidation` na entrada de dados da API.

**ATENÇÃO! Como ainda executamos a validação nos services, é essencial ter a anotação `@Default` juntamente com a `@BeanValidationIntegrated`, para que seja carregado corretamente no service.**

**ATENÇÃO! As validações realizadas no `AbstractService` serão removidas, sendo necessário que todos os validadores(`class {name} extends LogicValidator`) migrem para executar com o `BeanValidation`, através da anotação citada acima e exemplo abaixo.**
```java
@BeanValidationIntegrated(Object.class)
@Default
public class ObjectValidator extends LogicValidator< Object > {

      @Valid(field = "price", message = "lesserThanOrigin")
      public boolean valid1(Object value) {
         return value.getPrice() > value.getOriginPrice();
      }

      @Valid(field = "price", message = "lesserThanOrigin")
      public ValidObject valid2(Object value) {
         ValidObject valid = new ValidObject();
         if (value.getPrice() < value.getOriginPrice()) {
             valid.setValid(false);
             valid.setParams(parameters); //Map com as informações complementares. Ex: minimumPrice = 110,00
         } else {
            valid.setValid(true);
         }
         return valid;
      }

      @DynamicValid
      public ListBuilderLogicError valid3(Object value){
         ListBuilderLogicError builder = new ListBuilderLogicError();
         if (value.getPrice() < value.getOriginPrice()) {
             builder.addError(new LogicError("price", "lesserThanOrigin"));
         }
         if (value.getPrice() < minimumPrice) {
             builder.addError(new LogicError("price", "lesserThanMinimum", value, parameters)); //Map com informações complementares. Ex: minimumPrice = 110,00
         }
         return builder;
      }
}
```

### 3.3.6 - Exceções lógicas  <a name="server.validation.logicalexceptions"></a>
  * Nos casos onde é necessário lançar uma exceção com uma mensagem para o usuário, é possível utilizar o `MessageException`. Este tipo de exceção tem todo o tratamento necessário para retornar a mensagem internacionalizada com base na linguagem enviada na request.
  * Para a internacionalização da chave, a `Exception` recebe uma chave da mensagem no seu construtor e possíveis parametros que devem ser aplicados.
  * Em cada módulo(microservice) que deseja utilizar esta internacionalização, deve criar um arquivo chamado `messages-{language}-{country}.json`, a exemplo do arquivo `exception-messages-en.json`. O conteúdo do arquivo deve ser escrito em JSON, no formato, chaveI18N : {codigoErro, msgErro}
```java
    //Class java que lança a exception com a chave de internacionalização
     public void validLogin(final String login) {
        if(!validAdLogin(login)) {
            throw new MessageException("invalid.login.ad");
        }
     }
```
* Seu arquivo `messages-en.json` deverá estar no seguinte padrao
```json
    {
        "invalid.login.ad": {
            "code": "Não obrigatório",
            "message": "Cannot sign in, check username and password"
          }
    }
```
  * Caso seja necessário passar parametro para a mensagem, é possível fazer isso da seguinte forma.
```java
  //Class java que lança a exception com a chave de internacionalização
   public void validLogin(final String login) {
      if(!validAdLogin(login)) {
          throw new MessageException("invalid.login.ad", "3");
      }
   }
```
  * Seu arquivo `messages-en.json` deverá estar no seguinte padrao
```json
  {
      "invalid.login.ad": {
          "code": "Não obrigatório",
          "message": "Cannot sign in, check username and password, limit of tries {0}"
        }
  }
```
  * Onde `{0}` será substituido pelo valor passado na `Exception`, para este caso por `3`

### 3.3.7 Validações para entidades.  <a name="server.validation.entity"></a>

O objetivo da estrutura de validação a seguir, é garantir que:
 - As implementações de validação sejam chamadas manualmente(pela API consumidora) dentro do escopo/camada apropriado(a).
 - Seja possível criar filtros de validação segundo escopos específicos.
 - Seja possível indexar as mensagens para o Front-End, permitindo ligar a mensagem ao seu objeto originador, mesmo quando dentro de uma hierarquia de objetos (Árvore de mensagens).
 - Seja abstraida para o desenvolvimento somente as implementações de organização e lançamento das exceções.
 - Seja possível lançar exceções lógicas e exceções da API BeanValidations dentro do mesmo escopo, retornando-as em uma resposta única ou dividida, conforme a necessidade da API consumidora.
 
 Estas validações podem emitir dois tipos de retornos:
 
 - `LogicError` (Vide item 3.3.3).
 
 - `IndexedLogicError` (Vide item 3.3.4).
 
#### 3.3.7.1 Validações sem filtros. <a name="server.validation.entity.nofilter"></a>
 
 Abaixo um exemplo de implementação em que a API consumidora centraliza as validações em um único método, e **NÃO** realiza filtros de validação.
 
 ```java
@RequestScoped
public class CropYieldValidator extends AbstractIndexedEntityValidator<CropYield> {

    // ...
    
    @Override
    public void validate(CropYield entity, final Integer index, final IValidationFilter... filter) {
        //...

        if(!validateAgriculturalFieldNotNull(entity)) {
            addError(new IndexedLogicError(index, "agriculturalField", "cropYield.validation.agriculturalField.required"), entity);
        }

        if(entity.getYieldType() != null) {
            if (!validObtainedProduction(entity)) {
                addError(new IndexedLogicError(index, "yieldType", "cropYield.validation.obtainedProduction.twice"), entity);
            }

            if (!validEstimatedProduction(entity)) {
                addError(new IndexedLogicError(index, "yieldType", "cropYield.validation.estimatedProduction.sameDate"), entity);
            }
        }
        
        //...
    }
    
    //...
}
 ``` 

#### 3.3.7.2 Validações com filtros. <a name="server.validation.entity.withfilter"></a>

Abaixo um exemplo de implementação em que a API consumidora centraliza as validações em um único método, e realiza filtros de validação.

```java
@RequestScoped
public class CropYieldValidator extends AbstractIndexedEntityValidator<CropYield> {

    //...
    
    @Override
    public void validate(CropYield entity, final Integer index, final IValidationFilter... filter) {
        //...

        List<MyEnumValidationFilter> filterList = Arrays.asList((MyEnumValidationFilter[]) filter);
        
        filterList.forEach(eFilter -> {
            switch (eFilter) {
            case DELETE:
                //...
                break;
            case INSERT:
                //...
                break;
            case SOME_FILTER:
                //...
                break;
            case UPDATE:
                //...
                break;
            default:
                //...
                break;
            }
        });
        
        //...
    }
    
    //...
}
```
## 3.4 - Classes abstratas <a name="server.abstractclasses"> </a>

### 3.4.1 - `AbstractResource<T extends BaseEntity, P extends PaginationSearch>`<a name="server.abstractclasses.resource"> </a>

A classe `AbstractResource` tem por objetivo trazer as implementações padrões de uma API a ser exposta, fornecendo métodos prontos de **insert, update, get, list, delete**, juntamente com o mapeamento da API.
Por padrão estes métodos, além de suas funções básicas, também trarão a validação de permissão, retornando o status `401` quando o usuário não possuir a mesma.

**É possível sobrescrever os métodos do
 Resource, não sendo necesário adicionar as anotações de mapeamento REST**

### 3.4.2 - `AbstractService<T extends BaseEntity>`<a name="server.abstractclasses.service"> </a>

A classe `AbstractService` tem por objetivo realizar de forma transparente a ponte entre os acessos de resource e DAO, também sendo capaz de invocar as classes de validação que estendem `LogicValidation<T>`
e implementam `T`, aplicando assim as validações básicas da aplicação.    

### 3.4.3 - `AbstractDAO< T extends BaseEntity >` <a name="server.abstractclasses.dao"> </a>

Traz implementações padrões de acessos ao banco de dados, como **insert, update, get, list, delete**. Vide 4.4 - DAOS

## 3.5 - Projections REST <a name="server.projections"> </a>

A utilização das classes abstratas traz por padrão a funcionalidade de projections, permitindo que uma busca retorne apenas os campos desejados de uma determinada entidade.
**GET:**
Para aplicar a projection em um método GET, é necessário informar o query param "select" passando os campos que se deseja retornar. Exemplo:
`/customers?select=name,type,address.country`
`/customers/{id}?select=name,type,address.country`

**POST(search)**
Para aplicar a projection em um método POST(/search) é necessário adicionar no json de pesquisa o atributo select. Exemplo:
```json
{
    "select" : "name,type,address.country"
}
```

## 3.6 - Filtros REST <a name="server.filters"></a>

A utilização das classes abstratas traz por default a funcionalidade de filtros básicos para chamadas **GET**, permitindo filtrar o resultado pelos atributos do recurso sendo buscado.
Exemplo:
`/customers?q={name->eq->Gandalf The Grey}{type->eq->mage}`

O filtro permite as seguintes instruções:

- `eq` para propriedade igual ao valor. `/customers?q={name->eq->Gandalf The Grey}`
- `ieq` para propriedade igual ao valor, porem não é case sensitive. `/customers?q={name->ieq->Gandalf The Grey}`
- `neq` para propriedade não igual ao valor . `/customers?q={name->neq->Gandalf The Grey}`
- `like` para propriedade usando o operador LIKE do banco de dados. `/customers?q={name->like->Gandalf%}` ou `/customers?q={name->like->%ndalf The Grey}` ou ainda `/customers?q={name->like->%ndalf%}`
- `ilike` funcionamento similar ao LIKE, porem não é case sentitive `/customers?q={name->ilike->%andalf%}` é a mesma coisa que  `/customers?q={name->like->%ANDALF%}`
- `gt` para propriedade maior que o valor. `/customers?q={age->gt->20}`, irá retornar todos que são maiores que `20`
- `ge` para propriedade maior ou igual ao valor. `/customers?q={age->ge->20}`, irá retornar todos que são iguais ou maiores que `20`
- `lt` para propriedade menor que o valor. `/customers?q={age->lt->20}`, irá retornar todos que são menores que `20`
- `le` para propriedade menor ou igual ao valor. `/customers?q={age->le->20}`, irá retornar todos que são iguais ou menores que `20`
- `in` para propriedade dentro de uma coleção de valores. `/customers?q={age->in->[20,30,40]}`, irá retornar todos que são iguais a `20`, `30` ou `40`.
- `nin` para propriedade que não esta dentro de uma coleção de valores. `/customers?q={age->nin->[20,30,40]}`, irá retornar todos que não são iguais a `20`, `30` ou `40`.
- `isnull` para propriedade que não possui valor. `/customers?q={address->isnull}`, irá retornar todos que estejam com a propriedade nula
- `isnnull` para propriedade que possui valor. `/customers?q={address->isnnull}`, irá retornar todos que estejam com a propriedade com algum valor.
- `btw` para propriedade entre 2 valores de varios tipos. 
    - Exemplo de datas: `/customers?q={updatedAt->btw->2003-12-22T11:00:00-03:00->2018-12-10T01:11:00-03:00}`;
    - Exemplo com numeros inteiros: `/customers?q={updatedAt->btw->123->333}`;

O filtro também permite modificadores que adicionam comportamentos diferenciados:
- `unique` obriga o filtro validar se um, e apenas um registro existe. `/customers?q={unique->class->eq->witcher}` irá trazer o único registro que atenda o filtro usado com o operador `eq`. Se houver mais de um registro com a propriedade "class" igual a "witcher", nenhum resultado será retornado. Já a query `/customers?q={name->eq->Gandalf The Grey}||{unique->class->eq->witcher}` trará o registro que tenha o atributo `nome` igual a `Gandalf The Grey`, podendo haver vários resultados, ou então tenha um único resultado em que o atributo `class` seja igual a `witcher`.

Além dos filtros, existem outros modificadores de query que permitem o agrupamento diferenciado dos dados, são eles:

- `select` permite selecionar quais campos serão retornados. `/customers?q={select->[name, age, description]}` vai retornar somente os fields mencionados da entidade customers
- `distinct` para quando é necessário eliminar valores duplicados do resultado. `/customers?q={distinct}{name->eq->Gandalf}` retorna apenas 1 registro onde o nome seja Gandalf, independente da existencia de mais de um Gandalf no banco.
- `orderby` permite definir o orderBy da consulta. `/customers?q={orderby->[createdAt desc, address asc]}` retorna os registros em order decrescente de criação e por segundo o address em ordem crescente.
- `pagesize` define quantos registros devem retornar por página. `/customers?q={pagesize->20}` retorna `20` registros por pagina.
- `page` define qual pagina será retornada. `/customers?q={page->3}` retorna a 3a pagina da consulta
- `deleted` permite trazer os registros removidos. `/customers?q={deleted}`
- `filter` filtra as entidades aninhadas para retornar registros específicos e não a coleção toda. `/customers?q={emails.address->eq->A1}{filter->[emails]}`. Retorna apenas os emails do customer que contenham o address igual a A1. 

Para a composição de múltiplos filtros, podem ser utilizados o operador lógico explícito: 
- `||` para identificar uma disjunção entre dois ou mais filtros. `/customers?q={name->like->Gandalf%}||{name->like->Mithrandir%}` 
 
E na forma implícita para um conjunção entre dois ou mais filtros. `/customers?q={name->like->Gandalf%}{name->like->%Grey}` 
O operador `&&` não é aceito pois o símbolo `&` é um caracter reservado da URI. 

Seguindo o padrão de banco de dados no tratamento para comandos de seleção, o operador AND terá precedência sobre o operador OR. Diante da necessidade de precedência específica, pode-se definir grupos, tal qual em um comando de seleção:
- Parênteses são usados para delimitar um grupo de expressões. `/customers?q={active->eq->true}({standard->eq->true}||{name->like->Master%})`
- Grupos também permitem grupos dentre suas expressões.

## 3.6.1 - Usando o `Builder` e `Parser` <a name="server.filters.builder"> </a>

Para a construção das queries, existe uma classe utilitaria `RestQueryUrlBuilder` que permite criar os parametros para a URL. Segue exemplo:

```java
new RestQueryUrlBuilder().distinct()
                        .equals("description", "SOJA")
                        .page(5)
                        .getUrlQueryParams())

```
Neste exemplo o resultado vai ser `{distinct}{description->eq->SOJA}{page->5}`

```java
         restQueryUrlBuilder
                        .select("name", "description", "createdAt")
                        .like("name", "joao%")
                        .greaterThan("areaSize", "20.23")
                        .orderBy(
                                new OrderBy("createdAt", OrderByDirection.ASC),
                                new OrderBy("address"))
                        .getUrlQueryParams());
```
Neste outro exemplo o resultado vai ser `{select->[name, description, createdAt]}{name->like->joao%}{areaSize->gt->20.23}{orderby->[createdAt asc, address asc]}`

Da mesma forma, caso seja necessário extrair os parametros das queries, tambem existe uma classe utilitaria chamada `RestQueryUrlParser` para fazer o parser das expressões recebidas pela URL. Segue exemplo:

```java
        RestQueryUrlParams restQueryUrlParams = new RestQueryUrlParser(bundle, locale)
        .parseUrl("{distinct}{description->eq->SOJA}{id->eq->05b2bde8-cfbd-43ca-8984-a005ff0cc87b}{updatedAt->btw->2003-12-22T11:00:00-03:00->2018-12-10T01:11:00-03:00}{orderby->[createdAt desc, address]}");
```
O objeto `restQueryUrlParams` vai conter a estrutura de todos os parametros recebidos via URL.


**O filtro básico não realiza consultas com JOIN. Para isto é necessário implementar o search**

## 3.7 - `PagedList<T>` <a name="server.pagedlist"> </a>

Toda consulta que retornar uma lista deve retornar o tipo `PagedList<T>`, retornando assim um objeto com informações úteis para a lista, como paginação.
 
A `PagedList`, por padrão irá realizar a ordenação dos objetos retornados. Por padrao será ordenado por "createdAt" e "id", que são campos existentes na classe `BaseEntity`.
Abaixo exemplo de como será a ordenação padrão em todo REQUEST que nao tiver ordenção definida:

#### SQL:<br>
```sql
order by createdAt asc, id asc
```
 
#### API REST: <br/>
```
"?sort=createdAt,asc&sort=id,asc"
```

## 3.8 - `RestAuthorizationRealm` (Autorizações Shiro)<a name="server.authrealm"> </a>

A Lib `commons` utiliza o framework [Shiro](https://shiro.apache.org/) para controle de autenticação e autorização.
Para carregar as autorizações a lib `commons` fornece a classe `RestAuthorizationRealm`, que em primeiro momento tenta buscar
as informações na ferramenta Redis (acessível pela lib [shiro-redis](http://ws-srvsource01.sollar.ws1/sollar-platform/shiro-redis).  
Caso as autorizações não estejam acessíveis na sessão em cache no Redis, a aplicaçao tentará buscar estas autorizações
em uma API. O método `doGetAuthorizationInfo` tentará buscar, por padrão, os dados na API constituída pelo método 
 `getPermissionsApiAddress`.

Para configuração do serviço e da API que fornece os dados para o usuário, é possível utilizar as configurações abaixo
 na seção **# 2 - Propriedades**.
 ```yaml
authorization.service.name
authorization.service.api
```    
É possível customizar o endereço da API sobrescrevendo o método `getPermissionsApiAddress`.  
Para customizações mais avançadas, também é possível sobrescrever o método `doGetAuthorizationInfo`.  
Para utilizar a classe `RestAuthorizationRealm`, é necessário registrar as mesmas no arquivo `shiro.ini`, conforme exemplo abaixo:  
```yaml
authRealm = RestAuthorizationRealm
securityManager.realm = $authRealm
```  
Para utilizar uma implementação customizada é necessário configurar o arquivo `shiro.ini` conforme abaixo:
```yaml
authRealm = com.sollar.commons.server.accesscontrol.{YourClassWithOverridenMethods}
securityManager.realm = $authRealm
```

## 3.9 - Autenticação/Autorização via JWT<a name="autenticacao.jwt"></a>

Para verificação de JWT foi criada uma abstração para o serviço [Hofund](https://gitlab.wssim.com.br/platform/hofund) presente na Stack Wealthsystems Cloud.

A autenticação via JWT pode ser realizada utilizando o Filter `JwtAuthenticationFilter`, que, a toda requisição, validará
se a requisição possui uma [Bearer token](https://tools.ietf.org/html/rfc6750#section-6.1.1) válida e, caso não haja, não permitirá o acesso ao recurso.
Para realizar esta verificação, é necessário configurar as classes utilizadas na aplicação através do arquivo shiro.ini:

```ini
; Permite o uso do JWT como chave de sessão
sessionManager = br.com.wealthsystems.security.jwt.JwtSessionManager
sessionFactory = br.com.wealthsystems.security.jwt.JwtSessionFactory
sessionManager.sessionFactory = $sessionFactory
securityManager.sessionManager = $sessionManager

; Permite o acesso à dados presentes no Redis com base em dados presentes no JWT, por default a claim "sub"
redisManager = com.ws.shiro.RedisManager
redisSessionDAO = br.com.wealthsystems.security.jwt.JwtRedisDAO
redisSessionDAO.redisManager = $redisManager
securityManager.sessionManager.sessionDAO = $redisSessionDAO

; Permite a criação do subject de acordo com os valores que são providos acima
subjectFactory = br.com.wealthsystems.security.jwt.JwtSubjectFactory
securityManager.subjectFactory = $subjectFactory
; Permite a verificação de assinatura do JWT de acordo com uma Chave Pública
jwtRealm = br.com.wealthsystems.security.hofund.HofundAuthorizingRealm
securityManager.realm = $jwtRealm

[filters]
; Filtro que deve interceptar todas as requisições e verificar o JWT
filter = br.com.wealthsystems.security.jwt.JwtAuthenticationFilter

[urls]
; Configuração do filtro para interceptar todas as requisições
/** = filter
```

Para o correto funcionamento, é necessário configurar algumas propriedades no arquivo de configuração `apache-deltaspike.properties`, sendo estas:

```properties
# Valores ilustrativos
# Define o clientId para comunicação com o serviço de Autenticação
security.oauth2.client.clientId=web_app
# Define o clientSecret para comunicação com o serviço de Autenticação
security.oauth2.client.clientSecret=changeit
# Define o endereço web para buscar a chave Pública para validação das JWT(JWS)
security.oauth2.server.jwkAddress=http://localhost:9999/api/v1/uaa
# Define o resource aplicado à security.oauth2.server.jwkAddress
security.oauth2.server.jwkResource=/oauth/token_key
# Define a chave de acesso única a um serviço para retornar dados da sessão do usuário
security.oauth2.client.shiroRedisKey=cloud
```

A implementação padrão da classe `HofundAuthorizingRealm` tenta ler as permissões de acesso do usuário da sessão do Redis, por meio da configuração já existente, sendo necessário apenas informar o DAO `JwtRedisDAO`.

No fluxo de autenticação, é necessário o "download" da chave pública para validação das JWTs (JWSs). Para este "download", existe a implementação da classe `HofundJwkParseCacheLoader` que estende `CacheLoader<String, PublicKey>`, gerando assim um cache desta chave, não sendo necessário o acesso constante ao serviço que a provê.
É possível estender a class `HofundJwkParseCacheLoader` e adicionar comportamentos conforme necessidades. (Comumente não deve ser necessário realizar essa estensão)
Na classe `HofundAuthorizingRealm` é possível estender praticamente todos os métodos e adicionar comportamentos específicos na parte de verificação/autenticação da JWT, bem como definir tratativas específicas em casos de validação da mesma. (Comumente não deve ser necessário realizar essa estensão)
A classe `JwtUtils` serve como auxiliar quando houver a necessidade de extrair ou manipular dados da JWT.

## 3.10 - Sessão Redis<a name="server.redis"></a>
A lib `commons` oferece suporte transparente para o uso do database Redis para armazenamento de sessão distribuída para
o usuario.

Para isto é necessário configurar o arquivo `shiro.ini` conforme abaixo:

```yaml
#============redisSessionDAO=============
redisSessionDAO = com.ws.shiro.RedisSessionDAO
redisSessionDAO.redisManager = $redisManager
sessionManager = org.apache.shiro.web.session.mgt.DefaultWebSessionManager
sessionManager.sessionDAO = $redisSessionDAO
securityManager.sessionManager = $sessionManager

#============redisCacheManager===========
cacheManager = com.ws.shiro.RedisCacheManager
cacheManager.redisManager = $redisManager
#custom your redis key prefix, if you doesn't define this parameter shiro-redis will use 'shiro_redis_session:' as default prefix
#cacheManager.keyPrefix = user:security:authz:
securityManager.cacheManager = $cacheManager
```
**As propriedades de conexão ao Redis podem ser verificadas na sessão 2 - Propriedades**

## 3.11 - `UserContext` <a name="server.usercontext"></a>

Há a possibilidade de acessar os dados no contexto do usuário logado realizando a injeção da classe `UserContext`:

```java
@Inject
UserContext userContext;

public void usesUserContext(){

    // É possível acessar a sessão do usuário e consumir ou adicionar atributos que possam ser importantes serem mantidos
    // em sessão.
    // A sessão não deve ser tratada para armazenar dados específicos do usuário, tais como id, username,
    // Nome do usuário, Data de nascimento entre outros, pois estes devem estar disponíveis através do método
    // getUserAttributes().
    userContext.getSession().setAttribute("id", "c8d5c90f-72da-447f-973f-1f1e84b34c07");
    UUID uuid = UUID.fromString(userContext.getSession().getAttribute("id"));
}

```
<font color="red"> Os atributos do usuário são fornecidos conforme forem sendo carregados pela origem, comumente sendo o
ponto de autenticaçao do login.</font>

## 3.12 - REST PATCH <a name="server.restpatch"></a>
RESOURCE do sistema, que segue a implementaçao de COMMONS, contará com o REST PATCH.
Com O PATCH podemos solicitar pequenas alterações no objeto, sem necessidade de passar todo objeto para o servidor, evitando assim fazer um payload de JSON muito grande.
Como padrão utilizamos as especificações RFC (Request For Comments) listadas abaixo:
- [RFC-6902 - PATCH](https://tools.ietf.org/html/rfc6902)
- [RFC-7386 - MERGE PATCH](https://tools.ietf.org/html/rfc7386)

Outras referências importantes para o PATCH:
- [Jersey HTTP-PATCH](https://github.com/jersey/jersey/tree/master/examples/http-patch)
- [JSON PATCH](http://jsonpatch.com/)

Para maiores informações da implementação da COMMONS para REST PATCH com instruções de uso, funcionameno, notas de uso,
sobreescrita e implementações personalizadas e outros consulte o [JavaDoc do pacote da implementação](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons/index.html?com/ws/commons/interceptor/patch/package-summary.html) 
(`com.ws.commons.interceptor.patch`). 

Exemplo de REST PATCH (RFC-6902):


| Propriedade  | Conteúdo                                                             | Descrição                                               |
|--------------|----------------------------------------------------------------------|---------------------------------------------------------|
| URL          | {baseUrl}/api/v1/agricultural/cultures/{UUID}                        | URL com o ID do objeto no final.                        |
| HEADER       | Content-Type:application/json-patch+json                             | Tipo do conteúdo a ser enviado, sem isso ocorrerá erro. |
| METHOD       | PATCH                                                                | Método do HTTP, similar a GET/POST/PUT/DELETE           |
| BODY/PAYLOAD | ```[{"op": "replace", "path": "/active", "value": "true"}] ```  | Array com uma lista de operações a serem feitas. [1-N]  |

Exemplos de BODY/PAYLOAD:

1:
```java
[
	{
		"op": "replace", 
		"path": "/description", 
		"value": "Teste Rest Patch 1"
	}
]
```

2:
```java
[
	{
		"op": "replace", 
		"path": "/active", 
		"value": "false"
	},
	{
		"op": "replace", 
		"path": "/description", 
		"value": "Teste Rest - Patch (RFC6902)"
	}
]
```

<font color="red"> Todas as "op" ou "operações" aceitas estão nas links acima.</font>

Exemplo de REST MERGE PATCH (RFC-7386):


| Propriedade  | Conteúdo                                                             | Descrição                                               |
|--------------|----------------------------------------------------------------------|---------------------------------------------------------|
| URL          | {baseUrl}/api/v1/agricultural/cultures/{UUID}                        | URL com o ID do objeto no final.                        |
| HEADER       | Content-Type: application/merge-patch+json                           | Tipo do conteúdo a ser enviado, sem isso ocorrerá erro. |
| METHOD       | PATCH                                                                | Método do HTTP, similar a GET/POST/PUT/DELETE           |
| BODY/PAYLOAD | ```{ 'description' : 'Test Rest - MERGE PATCH (RFC7386)' } ```  | Os campos do objeto que você deseja alterar             |

Exemplos de BODY/PAYLOAD:

1:
```java
	{
		"active": "Test Rest - MERGE PATCH (RFC7386)"
	}
```

2:
```java
	{
		"description": "Test Rest - MERGE PATCH (RFC7386)",
		"active": true
	}
```

## 3.13 - Resource Interfaces <a name="server.interfaces"></a>

Oferece as implementações padrão de persistencia e consulta a dados, baseados no framework Jersey para RESTful Web Services.

##### Referências: 

 - https://jersey.github.io/
 - https://www.w3.org/2001/sw/wiki/REST

### 3.13.1 - Interfaces Disponiveis <a name="server.interfaces.available"></a>

|Interface | Funcionalidade|
| --- | --- |
| `IResourceBatchDelete` | Oferece a estrutura(implementação padrão) necessária para expor o recurso de deleção em lote, operando sob o verbo HTTP POST. |
| `IResourceBatchInsert` | Oferece a estrutura(implementação padrão) necessária para expor o recurso de inserção em lote, operando sob o verbo HTTP POST.|
|`IResourceDelete`| Oferece a estrutura(implementação padrão) necessária para expor o recurso de deleção, operando sob o verbo HTTP DELETE.|
|`IResourceGet`| Oferece a estrutura(implementação padrão) necessária para expor o recurso de obtenção de dados por chave única, operando sob o verbo HTTP GET.|
|`IResourceInsert`| Oferece a estrutura(implementação padrão) necessária para expor o recurso de inserção, operando sob o verbo HTTP POST.|
| `IResourceList`| Oferece a estrutura(implementação padrão) necessária para expor o recurso de obtenção de dados em lista, operando sob o verbo HTTP GET.|
|`IResourceUpdate`| Oferece a estrutura(implementação padrão) necessária para expor o recurso de atualização de dados, operando sob o verbo HTTP PUT.|
|`IDTOResourceBatchInsert`|Oferece a estrutura(implementação padrão) necessária para expor o recurso de inserção em lote, **com conversão de tipos**, operando sob o verbo HTTP POST.|
| `IDTOResourceGet`|Oferece a estrutura(implementação padrão) necessária para expor o recurso obtenção de dados por chave única, **com conversão de tipos**, operando sob o verbo HTTP GET.|
|`IDTOResourceInsert`|Oferece a estrutura(implementação padrão) necessária para expor o recurso de inserção, **com conversão de tipos**, operando sob o verbo HTTP POST.|
|`IDTOResourceList`|Oferece a estrutura(implementação padrão) necessária para expor o recurso de obtenção de dados em lista, **com conversão de tipos**, operando sob o verbo HTTP GET.|
|`IDTOResourceUpdate`|Oferece a estrutura(implementação padrão) necessária para expor o recurso de atualização de dados, **com conversão de tipos**, operando sob o verbo HTTP PUT.|

### 3.13.2 - Exemplos <a name="server.interfaces.examples"></a>

- `IResourceBatchDelete`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceBatchDelete<ResourceEntityArtifact>{

    //...
}
```

- `IResourceBatchInsert`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceBatchInsert<ResourceEntityArtifact> {

    //...
}
```

- `IResourceDelete`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceDelete<ResourceEntityArtifact> {

    //...
}
```

- `IResourceGet`
```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceGet<ResourceEntityArtifact> {

    //...
}
```

- `IResourceInsert`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceInsert<ResourceEntityArtifact> {

    //...
}
```

- `IResourceList`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceList<ResourceEntityArtifact> {

    //...
}
```

- `IResourceUpdate`

```java
@Path("/resource-artifact")
public class ResourceArtifact implements
    IResourceUpdate<ResourceEntityArtifact> {

    //...
}
```

- `IDTOResourceBatchInsert`



 [***Para a conversão de tipos, vide item 9.**](#dto)

```java
@Path("/resource-dto-artifact")
public class ResourceWithDTOArtifact implements
    IDTOResourceBatchInsert<ResourceEntityArtifact, ResourceDTOArtifact> {

    //...
}
```

- `IDTOResourceGet`

 [***Para a conversão de tipos, vide item 9.**](#dto)

```java
@Path("/resource-dto-artifact")
public class ResourceWithDTOArtifact implements
    IDTOResourceGet<ResourceEntityArtifact, ResourceDTOArtifact> {

    //...
}
```

- `IDTOResourceInsert`

 [***Para a conversão de tipos, vide item 9.**](#dto)

```java
@Path("/resource-dto-artifact")
public class ResourceWithDTOArtifact implements
    IDTOResourceInsert<ResourceEntityArtifact, ResourceDTOArtifact> {

    //...
}
```

- `IDTOResourceList`



 [***Para a conversão de tipos, vide item 9.**](#dto)

```java
@Path("/resource-dto-artifact")
public class ResourceWithDTOArtifact implements
    IDTOResourceList<ResourceEntityArtifact, ResourceDTOArtifact> {

    //...
}
```


### 3.13.3 `IDTOResourceUpdate`

 [***Para a conversão de tipos, vide item 9.**](#dto)

```java
@Path("/resource-dto-artifact")
public class ResourceWithDTOArtifact implements
    IDTOResourceUpdate<ResourceEntityArtifact, ResourceDTOArtifact> {

    //...
}
```
# 4 - Persistence<a name="persistence"></a>

## 4.1 - Configuração Banco de dados<a name="persistence.dbconfig"></a>

Para controle de datasource a lib `commons` utiliza por padrão o [HikariCP](https://github.com/brettwooldridge/HikariCP). 
  O [Apache DBCP2](https://commons.apache.org/proper/commons-dbcp/) também está disponível para uso mediante configuração.

A configuração de acesso ao banco de dados deve ser realizada no arquivo `apache-deltaspike.properties` através das seguintes propriedades:

| Propriedade                               | Tipo    | Implementações | Default value | Observação                       |
|-------------------------------------------|---------|----------------|---------------|--------------------------------- |
| `db.url`                                  | String  | DBCP; HikariCP | null          | URL do banco de dados             |
| `db.username`                             | String  | DBCP; HikariCP | null          | Usuário de banco de dados         |
| `db.password`                             | String  | DBCP; HikariCP | null          | Senha de banco de dados           |
| `db.driver`                               | String  | DBCP; HikariCP | null          | Driver de banco de dados          |
| `db.schema`                               | String  | DBCP; HikariCP | null          | Schema de banco de dados (Utilizado somente em stage Development, permitindo simular o tenant)  |
| `authorization.db.url`                    | String  | DBCP; HikariCP | null          | URL do banco de dados de user     |
| `authorization.db.username`               | String  | DBCP; HikariCP | null          | Usuário de banco de dados de user |
| `authorization.db.password`               | String  | DBCP; HikariCP | null          | Senha de banco de dados de user   |
| `authorization.db.driver`                 | String  | DBCP; HikariCP | null          | Driver de banco de dados de user  |
| `db.platform`                             | String  | DBCP; HikariCP | `com.avaje.ebean.config.dbplatform.PostgresPlatform`| Plataforma de base de dados que está sendo utlizada |
| `ds.removeAbandonedOnBorrow`              | Boolean | DBCP           | true          | Remove as conexões abandonadas se excederem o ds.removeAbandonedTimeout |
| `ds.removeAbandonedTimeout`               | Integer | DBCP           | 600           | Tempo em segundos antes que uma conexão abandonada seja removida |
| `ds.removeAbandonedOnMaintenance`         | Boolean | DBCP           | true          | Remove as conexões abandonadas no ciclo de manutenção, esta propriedade só tem efeito se a `ds.timeBetweenEvicionRunsMillis`  estiver com valor positivo |
| `ds.timeBetweenEvictionRunsMillis`        | Integer | DBCP           | 300000        | Tempo de espera entre as execuções do ciclo de manutenção, valor negativo não vai executar nenhum ciclo |
| `ds.softMinEvictableIdleTimeMillis`       | Integer | DBCP           | 300000        | Tempo minimo para uma conexão ociosa ficar no pool antes que seja eleita para close na proxima manutenção, esta quantidade respeita o `ds.minIdle` |
| `ds.minEvictableIdleTimeMillis`           | Integer | DBCP           | 300000        | Tempo minimo que um objeto pode permanecer ocioso no pool antes que seja eleito para despejo |
| `ds.connectionTimeoutMillis`              | Integer | DBCP; HikariCP | 10000         | Tempo máximo que o pool irá aguardar para estabelecer uma conexão com o banco de dados antes de disparar uma exceção |
| `ds.minIdle`                              | Integer | DBCP; HikariCP | 5             | Número minimo de conexões que podem ficar ociosas no pool. Zero para não manter nenhuma |
| `ds.maxIdle`                              | Integer | DBCP           | 10            | Número máximo de conexões que podem permanecer ociosas no pool. Negativo para nenhum limite |
| `ds.logAbandoned`                         | Boolean | DBCP           | false         | Flag para rastreamento de pilha para o código que abandonou uma conexão. Adiciona sobrecarga a cada declaração de conexão |
| `ds.maxConnLifetimeMillis`                | Integer | DBCP; HikariCP | 1800000       | Tempo máximo de vida para um conexão, após o tempo excedido esta será fechada. Número negativo significa vida útil infinita |
| `ds.maxTotal`                             | Integer | DBCP; HikariCP | 20            | Número maximo de conexões ativas que podem ser mantidas no pool. Negativo não define limite |
| `ds.logExpiredConnections`                | Boolean | DBCP           | false         | Registra uma mensagem indicando que uma conexão está sendo fechada pelo pool devido a `ds.maxConnLifetimeMillis` excedido |
| `ds.testOnBorrow`                         | Boolean | DBCP           | true          | O pool faz uma validação na conexão antes de entregar a aplicação, caso falhe é utilizado outra conexão |
| `ds.testOnReturn`                         | Boolean | DBCP           | false         | O pool faz uma validação na conexão antes que a mesma seja aceita novamente |
| `ds.testWhileIdle`                        | Boolean | DBCP           | false         | Flag para indicar se o objeto deve ser validado enquanto esta no pool |
| `ds.provider`                             | Boolean | DBCP; HikariCP | HIKARICP      | Identificação de qual DataSource deve ser usado. Opções disponíveis por padrão: `APACHE_DBCP2` e `HIKARICP`*. |
| `dao.throwRegisterNotFound`               | Boolean | DBCP; HikariCP | false         | Flag para indicar se `RegisterNotFoundException` deve ser lançada ao não encontrar um registro com `AbstractDAO#findById` |
| `dao.onlyUpdateChangedFields`             | Boolean | DBCP; HikariCP | true          | Define a estratégia de atualizações (`update` ou `merge`) do `AbstractDAO`. Quando `true`, a SQL gerada de `UPDATE` apenas irá conter as colunas com os valores alterados na entidade. Quando `false`, a SQL irá conter todas as colunas invariante se o valor foi alterado ou não. |
| `dao.merge.skipManyToManyDisassociation`  | Boolean | DBCP; HikariCP | false         | Define se o componente `ManyToManyDisassociationEngine` do `MergeEngine`, responsável por desassociações em relacionametos ManyToMany, deve ser desabilitado. |

** A `commons` oferece por padrão o `Apache DBCP2` e o `HikariCP` como provedores de `DataSource`. 
Se a sua aplicação possui necessidade de uma terceira opção ou de personalizações não disponíveis nativamente você pode implementar a 
interface `com.ws.commons.persistence.datasource.DataSourceProvider` com a lógica necessária, utilizando o valor retornado em 
`DataSourceProvider#getName` como o valor da chave de configuração `ds.provider`. Isto é o suficiente para a `commons` carregar via 
CDI sua implementação e utilizar-a na camada de persistência. 
 
## 4.2 - `Ebean` <a name="persistence.ebean"></a>

A lib `commons` se utiliza do ORM [Avaje Ebean](http://ebean-orm.github.io/)

O [ORM](https://en.wikipedia.org/wiki/Object-relational_mapping) `Ebean` possui uma configuração padrão na lib `commons`, 
porém comumente é necessário sobrescrever esta configuração. Isto é possível adicionando o arquivo `ebean.properties` no 
diretório `resources/ebean.properties`.

O ORM `Ebean` a partir da versão 9.3.1 suporta multi-tenancia, sendo possível configurar por DB ou SCHEMA. Hoje a 
configuração padrão esta por SCHEMA, onde é necessário uma base de dados para cada micro-serviço e um esquema para 
cada cliente.

Instâncias do `EbeanServer` produzidas através do CDI são entregues com a configuração de multi-tenancia habilitada
por padrão. O tenant ativo é obtido automaticamente do contexto da requisição ativa por meio dos dados do usuário
autenticado no serviço.

## 4.2.1 - Produção de instâncias do EbeanServer para um tentant específico <a name="persistence.ebean.specificTenant"></a>

Em um cenário convencional, instâncias do `EbeanServer` obtidas através do CDI serão produzidas utilizando a configuração
de multi-tenancia habilitada, sempre obtendo o tenant ativo do contexto de requisição atual.

Para casos em que há a necessidade de informar qual o tenant deve ser usado pelo `EbeanServer`, sobreescrevendo o 
comportamento padrão de obter essa informação do contexto da requisição, pode-se obter uma instância em tempo de runtime 
usando o método `produce(String)` da classe `EbeanMultiTenancyFactory`. Mais informações a respeito estão disponíveis
no JavaDoc do método mencionado.

Exemplo de produção de uma instância do `EbeanServer` para um tenant específico:

```java
public class Example {
    
    @Inject
    private EbeanMultiTenancyFactory factory;
    
    public EbeanServer getEbeanServer(final String tenantId) {
        return factory.produce(tentantId);
    }
    
}
```

É importante destacar que a produção de um `EbeanServer` para um tenant especifico apenas deve ser usado em situações
em que acessar um tenant diferente daquele no contexto da requisição (ex: do usuário autenticado no serviço) é
extremamente necessário. Em todos os outros cenários o uso desta possibilidade é altamente desencorajado.

## 4.3 - `Tenant` <a name="persistence.tenant"></a>

Devido ao modelo de funcionamento da aplicação Sollar, é necessário definir o Tenant(database schema) em que as operações serão realizadas.
Utilizando a lib `commons`, o Tenant já é abstraído, sendo necessário apenas seguir o modelo apresentado no item *4.4 - DAOs*.

## 4.4 - DAOs <a name="persistence.dao"></a>

Ao criar uma classe DAO é necessário estender a classe `AbstractDAO`, conforme exemplo abaixo:

```java
  public class PersonDAO  extends AbstractDAO<Person>{...}
```

Para instanciar o objeto DAO de forma correta, é necessário realizar a injeção do mesmo utilizando o CDI, conforme exemplo abaixo:

```java
  @Inject
  private PersonDAO personDAO;
```

## 4.4.1 - RestQueryAdapter <a name="persistence.dao.restQueryAdapter"></a>

O `AbstractDAO` permite a paginação, projeção e filtragem de consultas por meio de parâmetros dispostos na solicitação 
HTTP. Para isso existem duas APIs, a PaginationSearch e a RestQuery, e a implementação do `RestQueryAdapter`
existe em favor de uma padronização dessas duas APIs dentro do contexto do `AbstractDAO`, bem como permitir o desacoplamento 
da camada de persistência com o `HttpServletRequest` (ou o seu mapa de parâmetros).  

Além disso, a interface `RestQueryAdapter` também tem como intuito permitir que tais parâmetros para as consultas sejam 
coletados das mais diversas fontes, bem como permitir de maneira simples o suporte a novas no futuro 
(como Websockets), encaminhando de maneira padronizada para execução pelo `AbstractDAO` usando a RestQuery como maneira 
de representação dos dados. 

A `commons` dispõe de implementações padrões capazes de atender aos cenários mais comuns. Uma instância de `RestQueryAdapter` 
pode ser obtida de duas maneiras:
1. Através de uma injeção do CDI com a instrução `@Inject RestQueryAdapter restQueryAdapter`, o que irá retornar uma instância
   baseada na solicitação atual (usando o `HttpServletRequest` como fonte dos dados).
2. Por meio da classe fábrica `RestQueryAdapterFactory`, que dispõe dos métodos a seguir.
   - `fromHttpRequest(HttpServletRequest)`
   - `fromString(String)`
   - `fromRequestParameters(Map)`
   - `customAdapter()`
   - `emptyAdapter()`
   
É importante salientar que, mesmo que o `RestQueryAdapter` utilize como padrão a API do RestQuery para representar os parâmetros, 
a PaginationSearch também é suportada (mas com uma precedência menor) e, quando for detectado o seu uso, será automaticamente 
convertida para um objeto RestQuery. Portanto, e por este motivo, a implementação do `RestQueryAdapter` também depreciou as 
implementações/classes da PaginationSearch mantendo as funcionalidades da API ativas.

## 4.5 - Ordenação de resultados usando os nomes dos atributos de um DTO <a name="persistence.dtoSort"></a>

O `AbstractDAO` permite a ordenação dos resultados de uma consulta usando os nomes dos atributos de um DTO da entidade 
através da classe `DaoDtoMediator`.

A implementação padrão do `DaoDtoMediator` possui os métodos relacionados abaixo. A maneira como a busca no banco de 
dados é conduzida nesses métodos é igual ao funcionamento dos métodos de mesma assinatura do `AbstractDAO`, exceto pela 
tradução automática dos nomes dos campos de um DTO para a respectiva entidade.
- list(QueryAdapter)
- list(QueryAdapter, Query)
- list(RestQueryUrlParams)
- list(RestQueryUrlParams, Query)
- listSync(QueryAdapter)
- listSync(QueryAdapter, Query)
- internalList(QueryAdapter)
- internalList(QueryAdapter, Query)

Os métodos relacionados abaixo também estão disponíveis para uso, mas estão depreciados e seu uso não é recomendado:
- list(HttpServletRequest)
- list(HttpServletRequest, Query)
- list(Map)
- list(Map, Query)
- listSync(Map)
- listSync(Map, Query)
- internalList(Map)
- internalList(Map, Query)
- internalList(String, Query)

Caso a relação de métodos acima não atenda a todas as necessidades de sua aplicação, a classe `DaoDtoMediator` foi 
mantida aberta para extensões. A relação de métodos abaixo pode facilitar o processo de tradução de nomes e ordenação 
na sua classe de implementação personalizada:
- getEntityFieldName(String)
- getTranslatorInterceptor()
- translateFieldNames(QueryAdapter)
- translateFieldNames(RestQueryUrlParams)

Além dos métodos auxiliares mencionados acima, há também os métodos abaixo mas também estão depreciados e não são recomendados:
- getPaginationSearch(Map)
- getPaginationSearch(RestQueryUrlParams)
- parseRestQueryParameters(String, Query)

Uma instância de `DaoDtoMediator` pode ser obtida diretamente através de seu construtor ou, ainda, de maneira mais 
simples e prática, através do método `usingDTO(Class)` do `AbstractDAO` informando por parâmetro qual é a classe de 
DTO a ser levada em consideração (o DTO precisa implementar a interface IPojoConverter). 

É importante salientar de que o `DaoDtoMediator` tem apenas a responsabilidade de efetuar a tradução dos nomes dos 
campos de um DTO para nomes de campos de uma entidade. Uma vez traduzido, as chamadas de métodos serão encaminhadas para 
os respectivos métodos no `AbstractDAO` ou conduzidas da mesma maneira. Para maiores informações de como cada busca é 
feita, consulte o JavaDoc do `AbstractDAO`. 

## 4.6 `Vault` <a name="persistence.vault"></a>

[Vault](https://www.vaultproject.io/) é uma ferramenta para armazenamento de informações de forma segura, onde cada usuário que deseje ter acesso precisa de uma chave para isso, esta chave deve ser informada no `vault.token`.
Ao utilizar multi-tenancia por cliente(um banco de dados para cada cliente e um esquema para cada micro-serviço), o Vault é ativado, pois as conexões devem estar salvas nele, de onde serão recuperadas.
O Vault oferece um Rest API para POST e GET das informações, sempre respeitando a chave de cada cliente.

## 4.7 - Reciclagem <a name="persistence.recycling"></a>

O processo de reciclagem consiste em manter um histórico de todas as entidades que foram removidas do banco de dados para 
que, posteriormente, essas mesmas entidades possam ser removidas de dispositivos móveis por meio de uma sincronização.

Implementações da reciclagem podem ser feitas por meio da interface `RecycleListener` da API de eventos do `AbstractDAO`,
o `EventDispatcher`. Para maiores informações, consulte o JavaDoc da interface (os links para o JavaDoc estão dispostos 
no rodapé deste arquivo).

### 4.7.1 - DefaultRecycleListener <a name="persistence.recycling.defaultRecycler"></a>

A commons oferece uma implementação pronta para o processo de reciclagem por meio da classe `DefaultRecycleListener`. 
A classe mencionada funciona baseada na API de eventos do `AbstractDAO`, observando todas as deleções de entidades 
que implementam a interface `Identification` e registrando automaticamente essas deleções através da entidade 
`RecyclingEntity`.

Por padrão a `DefaultRecycleListener` será configurada para registrar automaticamente todas as deleções, sejam elas 
soft-delete ou physical delete. Existem duas formas de alterar este comportamento: 

1. Para desativar a reciclagem para uma única entidade, anote-a com `@PreventRecycling`;
2. Para desativar a reciclagem automática para todas as entidades e evitar que o `DefaultRecycleListener` seja 
registrado na inicialização da aplicação, configure (através do Deltaspike) a chave `recycling.disableDefaultRecycler` 
com o valor `true`.

É importante salientar que o `DefaultRecycleListener` utiliza a entidade`RecyclingEntity` mas não cria a tabela para 
essa entidade automaticamente no banco de dados. Durante a inicialização da aplicação, no momento em
que a `DefaultRecycleListener` é registrada/inicializada, ocorre a validação para confirmar se a tabela existe. 
Se for constatado que ela está ausente uma exceção será disparada, interrompendo o fluxo.

Para criar a tabela necessária para o funcionamento da `DefaultRecycleListener` a SQL abaixo deve ser utilizada. 
A recomendação é integrar a instrução abaixo em seu subsistema de versionamento do banco de dados, como o Flyway.

```sql
create table recycling_entity (  
  id                            uuid not null,
  resource_uri                  varchar(255),
  performed_at                  timestamptz,
  constraint pk_recycling_entity primary key (id)
);
```

# 5 - `Diplomat` <a name="diplomat"></a>

O diplomat tem por objetivo facilitar a comunicação com demais serviços da aplicação, abstraindo tarefas como registro do container no serviço de descoberta e, caso necessário, permitindo a comunicação com o mesmo.

## 5.1 - Configuração <a name="diplomat.config"></a>

Para o correto funcionamento da comunicação com o servidor de descoberta, é necessário adicionar as propriedades referentes ao objeto Diplomat no arquivo `apache-deltaspike.properties`.

| Propriedade                        | Tipo    | Default value  | Observação                     |
|------------------------------------|---------|----------------|------------------------------- |
| `diplomat.register.enabled`          | Boolean | true           | Habilita a conexão com o servidor de descoberta |

## 5.2 - Uso <a name="diplomat.usage"></a>

```java
  @Inject
  private Diplomat diplomat;
```

# 6 - Logging <a name="logging"></a>

## 6.1 - Informação <a name="logging.info"></a>

 * Gerenciamento de logs utilizando a API de SLF4J e implementaçao log4j2
 * É possível definir o level de log através da configuração `log.level` utilizando os levels de acesso [SLF4J](https://logging.apache.org/log4j/2.0/index.html)

## 6.2 - Rastreamento de comunicação REST (requisições e respostas). <a name="logging.requests"></a>

O rastreamento das requisições pode ser feito com a definição do nível do LOG para TRACE. Ao definir o nível como TRACE, 
várias informações das requisições e também das respostas serão impressas no LOG, as quais podem ser localizadas pela 
String de [MARKER](https://logging.apache.org/log4j/2.0/manual/markers.html) "REQUEST".

O rastreamento é feito através do filtro `RequestTracingFilter`. A classe é registrada automaticamente quando sua
aplicação utiliza o `DefaultConfig` ou o `ApplicationConfig` fornecidos pela commons. Se sua aplicação não utiliza 
esses mecanismos de configuração do servidor é necessário efetuar o registro manualmente.

Segue abaixo um resumo das informações que serão impressas:

 - Requisições
     - request-id
     - request-hash-code
     - acceptable-languages 
     - acceptable-media-types
     - cookies
     - date
     - headers
     - language
     - length
     - media-type
     - method
     - property-names
     - absolute-path
     - request-uri
     - query-parameters
     - authentication-scheme
     - user-principal
     - entity
     
 - Respostas
     - request-id
     - response-from-request-hash-code
     - allowed-methods
     - entity-class
     - cookies
     - date
     - headers
     - language
     - length
     - media-type
     - last-modified
     - status
     - status-reason-phrase
     - status-family
     - body
 

# 7 - Trasactions <a name="transactions"></a>
O [Ebean permite fazer controle de transactions](http://ebean-orm.github.io/docs/transactions/) quando desejamos trabalhar com registros em lote utilizando `EbeanServer.beginTransaction` e `EbeanServer.commitTransaction`. Todo o controle dentro de um bloco de transação deve ser feito manualmente, incluindo o tratamento de exceptions com `try-catch-finally` e o rollback da transação em caso de falha. Testes com a annotation `@Transactional` apresentaram problemas com a passagens de parametros colocados na annotation.

Exemplo retirado da documentação do `ebean`
```java
Transaction transaction = ebeanServer.beginTransaction();
try {
  // turn of cascade persist
  transaction.setCascadePersist(false);

  // control the jdbc batch mode and size
  // transaction.setBatchMode(true); // equivalent to transaction.setBatch(PersistBatch.ALL);
  // transaction.setBatchMode(false); // equivalent to transaction.setBatch(PersistBatch.NONE);
  transaction.setBatch(PersistBatch.ALL); // PersistBatch: NONE, INSERT, ALL
  transaction.setCascadeBatch(PersistBatch.INSERT); // PersistBatch: NONE, INSERT, ALL
  transaction.setBatchSize(30);


  // for a large batch insert if you want to skip
  // getting the generated keys
  transaction.setBatchGetGeneratedKeys(false);

  // for batch processing via raw SQL you can inform
  // Ebean what tables were modified so that it can
  // clear the appropriate L2 caches
  String tableName = "o_customer";
  boolean inserts = true;
  boolean upates = true;
  boolean deletes = false;
  transaction.addModification(tableName, inserts, updates, deletes);

  ...
} finally {
  transaction.end();
}
```

# 8 - Sincronização <a name="sync"></a>

A sincronização utiliza a API padrão do microserviço, não deve ser necessário nenhum tratamento especial pois a maior parte das necessidades de filtragem já devem estar sendo atendidas pela permissão de acesso aos dados.
 
Se houver necessidade de utilizar **consultas diferentes para cada cliente**, pode ser feito desta forma:

  -  A consulta deve ser feita em uma classe que implemente `SyncQuery` e possua a annotation `@Named`, com um nome que
identifique a finalidade da mesma. O nome da consulta deve ser uma chave de internacionalização. Exemplo:
```java
@Named("customer.sync.active")
public class CustomerActiveSyncQuery implements SyncQuery {

    @Override
    public Expression getQuery(ExpressionFactory exp, UserContext userContext, Class entity) {
        return exp.eq("active", true);
    }
}
```
  - O método `listSync` do `AbstractDAO` deve ser sobrescrito, segue implementação de referência:
```java
public PagedList<T> listSync(Map<String, String[]> queryParams) {

        // Load configurations from database
        List<String> queryNames = ebeanServer().createQuery(CustomSyncQuery.class)
                .select("queryName").where().eq("entity", getEntityClass().getSimpleName()).findSingleAttributeList();

        Query<T> query = this.find();

        // Inject each query specified in the configuration
        SyncQueryManager.addNamedRestrictions(query, queryNames, userContext);

        // Add normal GET parameters
        restQuery.createGETQueryFilter(queryParams, this.clazz, query);

        PaginationSearch search = getPaginationSearch(queryParams);
        return getPagedList(query, search);
    }
```
   O `SyncQueryManager` é um utilitário para recuperar as consultas via injeção de dependências, que também permite listar as consultas disponíveis na aplicação.  
  
  - A entidade` CustomSyncQuery` deve ser criada no microserviço, ela guarda as consultas que o cliente escolheu para cada entidade:
```java
@Entity
public class CustomSyncQuery extends BaseEntity {

    private String entity;

    private String queryName;
    
    // getters and setters
}
```
  - <font color="red">**Lembre-se: esta forma de consulta só é necessária quando não for possível atender a necessidade com as permissões** </font>

# 9 - DTO - Data transfer object e Conversões de POJO. <a name="dto"> </a>

A representação de uma classe em DTO pode ser construída de duas formas:
 1. Podem ser incluídas anotações nos atributos da classe de origem, para determinar a visibilidade dos dados ou como estes dados serão expostos na classe de destino. 
 2. Assumindo que somente os atributos cujo o nome está igualmente representado na classe de destino, devem ser expostos. Os atributos da classe origem, que não possuirem nenhum tipo de anotação que altera a visibilidade para a classe de destino, serão expostos automaticamente caso exista um atributo com o mesmo nome e tipo na classe de destino.

A conversão de POJO consiste em transferir dados de um objeto qualquer para uma nova instância de uma classe específica. Para que uma classe possa ser considerada no processo de conversão, ela precisará estar mapeada com annotations(vide 11.3), ou implementar a Interface `IPojoConverter`.

## 9.1 - Utilizando anotações. <a name="dto.usage"> </a>

#### **Exemplo I** - De entidade para DTO.

##### _Classe de destino para o exemplo II._

```java
public class Customer implements IPojoConverter {

    // Será exposto caso exista um atributo com o mesmo nome e tipo na entidade de destino.
    private UUID id;
    
    // Será exposto caso exista um atributo com o mesmo nome e tipo na entidade de destino.
    private String name;
    
    // A anotação determina que este atributo seja ignorado. Não será processado durante a conversão.
    @PojoColumnIgnore
    private boolean active;
    
    // A anotação determina que este atributo seja ignorado. Não será processado durante a conversão.
    @PojoColumnIgnore
    private boolean standard;

    // A anotação determina que o valor deste atributo seja exposto na classe de destino, dentro de um objeto [user], através do atributo [id] do objeto [user].
    @PojoColumnMapper(target = "user.id")
    private UUID userId;
    
    // A anotação determina que o valor deste atributo seja exposto na classe de destino, dentro de um objeto [user], através do atributo [name] do objeto [user].
    @PojoColumnMapper(target = "user.name")
    private String userName;
    
    // A anotação determina que somente os atributos [id] e [description] da classe [Contact] serão expostos. Todos os demais atributos desta classe serão ignorados.
    @PojoColumnFilter({"id", "description"})
    private List<Contact> contacts;
    
    // A anotação determina que somente o atributo [customer] da classe [CustomerGroup] seja ignorado. Todos os demais atributos desta classe serão expostos.
    @PojoColumnIgnore(fields = {"customer"})
    private List<CustomerGroup> customerGroups;
}
```

#### **Exemplo II** - De DTO para entidade.

##### _Classe de destino para o exemplo I._

```java
public class CustomerTO implements IPojoConverter{

    private UUID id;
    
    private String name;

    // A anotação determina que os valores [id] e [name] deste atributo serão transferidos respectivamente para 
    // os atributos [userId] e [userName] da classe de destino.
    @PojoColumnsMapper({
            @PojoColumnMapper(source = "user.id", target = "userId"),
            @PojoColumnMapper(source = "user.name", target = "userName"),
    })
    private User user;
    
    // Não há anotações de filtros ou restrições. Todos os atributos da classe [ContactTO] serão processados. 
    private List<ContactTO> contacts;
    
    //Não há anotações de filtros ou restrições. Todos os atributos da classe [CustomerGroupTO] serão processados. 
    private List<CustomerGroupTO> customerGroups;
}
```

#### **Exemplo III** - Referência cíclica / Mapeamento bidirecional.

```java
public class Customer implements IPojoConverter {

    private UUID id;
    
    private Location location;
    
    //...
}

public class Location implements IPojoConverter {
    
    private UUID id;
    
    // Indica que o objeto utilizado para gerar a conversão deste(a) atributo/instância será a mesma referência de memória do(a) valor/instância da classe [Customer], que é a declarante de [Location] neste exemplo.
    // Ao iniciar a conversão deste objeto(customer), somente os atributos informados na anotação serão convertidos. Neste exemplo, o valor final de Customer será uma instância com apenas o valor ID convertido/copiado.
    // Como o processo de conversão utilizará uma referência/instância pré-existente, o valor deste atributo(antes da conversão) será descartado.   
    @PojoColumnBackReference({ "id" })
    private Customer customer;
    
    //...
}
```

### 9.1.1 - Anotações disponíveis. <a name="dto.usage.annotations"> </a>

|Annotation|Descricao|
|---|---|
|`@PojoColumnFilter`| Indica a realização de filtro por atributo. Permitindo que sejam expostos somente os atributos indicados por esta anotação.|
|`@PojoColumnIgnore`| Pode ser usado de duas formas. Indicando que o atributo anotado deve ser ignorado, ou indicando quais subatributos da classe/atributo devem ser ignorados.|
|`@PojoColumnMapper`| Indica que o atributo anotado será exposto em uma outra estrutura.|
|`@PojoColumnsMapper`| Permite indicar/alterar a estrutura de exposição dos subatributos.|
|`@PojoColumnBackReference`| Define que o objeto utilizado para gerar a conversão do atributo anotado, será a mesma instancia/referência de memória do declarante da classe à qual o atributo pertence. (Vide 10.1 - Exemplo III) |
|`@PojoInstanceProvider`| Define qual a implementação da interface `PojoConverterInstanceProvider` deve ser usada para obter instâncias para o atributo (`field`) ou a classe/interface. Quanto a anotação não está presente, uma implementação padrão será fornecida automaticamente pelo `PojoConverter`. |

### 9.1.2 - Exemplos: <a name="dto.usage.examples"> </a>


 - `@PojoColumnFilter` 
```java
    // Somente os atributos [id] e [description] da classe [Contact] serão expostos.
    @PojoColumnFilter({"id", "description"})
    private List<Contact> contacts;
```
  
 - `@PojoColumnIgnore`
 
a) Indicando que o atributo deve ser ignorado.
 
```java
    // O atributo active será ignorado no processo de conversão.
    @PojoColumnIgnore
    private boolean active;
```

b) Indicando quais subatributos da classe/atributo devem ser ignorados.

```java
    // Somente o atributo [customer] da classe [CustomerGroup] será ignorado.
    @PojoColumnIgnore(fields = {"customer"})
    private List<CustomerGroup> customerGroups;
```

 - `@PojoColumnMapper`
 
 ```java
    // O valor deste atributo será exposto na classe de destino, através do subatributo [id] do atributo [user].
    @PojoColumnMapper(target = "user.id")
    private UUID userId;
 ```
 
 - `@PojoColumnsMapper`
 
 ```java
    // Determina que os valores [id] e [name] deste atributo serão transferidos respectivamente para 
    // os atributos [userId] e [userName] da classe de destino.
    @PojoColumnsMapper({
        @PojoColumnMapper(source = "user.id", target = "userId"),
        @PojoColumnMapper(source = "user.name", target = "userName"),
    })
    private User user;
 ```
 
## 9.2 - Conversão de classes(manual). <a name="dto.classconvert"> </a>
 ```java
    Customer customer = new Customer();
    
    customer.set...(...);
    ...
        
    // A classe [Customer] implementa a interface [IPojoConverter], portanto já possui uma implementação padrão de conversão.
    // A conversão processará todos os atributos, expondo-os de acordo com as anotações, nomes e tipos.
    customer.convert(CustomerTO.class);
    
    // A conversão processará somente os atributos [id] e [name], expondo-os de acordo com as anotações, nomes e tipos.
    customer.convert(CustomerTO.class, "id", "name");
    
    // Também é possível converter um objeto, independentemente da implementação da interface [IPojoConverter], através do conversor [PojoConverter].
    // A conversão processará todos os atributos, expondo-os de acordo com as anotações, nomes e tipos.
    new PojoConverter().convert(CustomerTO.class, customer);
    
    // A conversão processará somente os atributos [id] e [name], expondo-os de acordo com as anotações, nomes e tipos.
    new PojoConverter().convert(CustomerTO.class, customer, "id", "name");
 ```

## 9.3 - Conversão por mapeamento(manual). <a name="dto.mapconvert"> </a>

A conversão por mapeamento considera que as classes envolvidas não podem ser, ou não são assinadas com a interface `IPojoConverter`.

```java
    Customer customer = new Customer();
    
    customer.set...(...);
    ...
    
    Map<Class<?>, Class<?>> classMap = new HashMap<>();
        
    classMap.put(Customer.class, CustomerTO.class);
    classMap.put(CustomerGroup.class, CustomerGroupTO.class);
    classMap.put(Contact.class, ContactTO.class);
    
    CustomerTO customerTO = new PojoConverter().convert(classMap, customer);
```

## 9.4 - Localização de mapeamentos de campos por entidade(`MappingLocator`). <a name="dto.mappinglocator">

Com o objetivo de acessar rapidamente informações relativas ao mapeamento de campos para classes DTO, a classe `MappingLocator` disponibiliza a geração de um metadata, onde é possível acessar tais informações.

### 9.4.1 - Acessando o nome do campo no DTO pelo nome do campo na entidade. <a name="dto.mappinglocator.dtofield"></a>

```java
    final String entityFieldName ="serviceId";
    
    final MappingMetaData mappingMetadata = MappingLocator
                    .fromClass(Customer.class)
                    .withPath(entityFieldName)
                    .getMappingMetadata();
                    
    final String dtoFieldName = mappingMetadata.getTargetPaths().get(entityFieldName);
    // dtoFieldName == "service.id"
```

### 9.4.2 - Acessando o nome do campo na entidade pelo nome do campo no DTO. <a name="dto.mappinglocator.entityfield"></a>


```java
    final String dtoFieldName ="service.id";
    
    final MappingMetaData mappingMetadata = MappingLocator
                    .fromClass(Customer.class)
                    .withPath(dtoFieldName)
                    .getMappingMetadata();
                    
    final String entityFieldName = mappingMetadata.getSourcePaths().get(dtoFieldName);
    // entityFieldName == "serviceId" 
```

### 9.4.3 - Convertendo um caminho com subcampos de DTO para um caminho com subcampos de entidade. <a name="dto.mappinglocator.convert"></a>

```java
    final String dtoPath ="location.service.id";
    
    final MappingMetaData mappingMetadata = MappingLocator
                    .fromClass(Customer.class)
                    .withPath(dtoPath)
                    .getMappingMetadata();
                    
    final String entityPath = mappingMetadata.getUnmappedPath();
    // entityPath == "location.serviceId"
```
## 9.5 - Interceptação e personalização da criação de instâncias de objetos durante a conversão <a name="dto.instanceProvider"></a>

A API do `PojoConverter` permite que a criação de instâncias de objetos durante o fluxo de conversão entre DTO e entidade
seja personalizado e/ou interceptado, possibilitando que o `PojoConverter` funcione mesmo em cenários mais complexos que
utilizam classes abstratas ou interfaces.

Para permitir essa interceptação a API disponibiliza a interface `PojoConverterInstanceProvider` com tipo genérico para 
a classe de destino a ser instanciada pela implementação. O exemplo a seguir demonstra uma implementação dessa 
interface para um cenário onde a classe destino é uma classe abstrata. Nesse cenário, sem a implementação, o `PojoConverter`
iria falhar ao tentar criar uma instância direta de classe abstrata.

```java
public class CustomValueProvider implements PojoConverterInstanceProvider<AbstractClass> {
    
    public AbstractClass produce(final Class<? extends AbstractClass> targetClass,
                                 final Object sourceObject) {
        return new ConcreteClass();
    }
}
```

Qualquer implementação da interface de produção de instâncias pode ser localizada de três formas diferentes, que são:
- Por meio da anotação `PojoInstanceProvider` no atributo de destino da conversão
- Por meio da anotação `PojoInstanceProvider` na classe a ser instanciada de maneira personalizada
- Dinamicamente usando o CDI

A implementação da interface é opcional para usar o `PojoConverter` e tem finalidade apenas de permitir a expansão das 
funcionalidades nativas da API. Uma implementação padrão da interface é sempre fornecida automaticamente quando uma
personalizada não for encontrada.
       
# 10 - Conversão automatica na camada de Resource. <a name="resourceautoconvert"></a>

Para cada Resource disponível, é possível configurar a conversão por meio de anotações.

Assim como nas conversões manuais, há dois caminhos para a conversão automática. Pode ser configurada pelas classes que implementam a interface `IPojoConverter`, ou pode ser configurada com mapeamento de classes para os casos em que as classes não podem conter a implementação de `IPojoConverter`.

## 10.1 - Conversão automática para classes que implementam `IPojoConverter`. <a name="resourceautoconvert.withpojo"></a>

a) Disparando a conversão na fase de produção do Resource.

```java
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    // O retorno será convertido para ObjectColumnTO.
    @ConversionProduces(ObjectColumnTO.class)
    public Response get() {
        return Response.ok().entity(new ObjectColumnEntity()).build();
    }
```

b) Filtrando o retorno na fase de produção do Resource, expondo apenas os campos definidos.

```java
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    // O retorno será convertido para ObjectColumnTO, mas somente o atributo [id] será exposto.
    @ConversionProduces(value = ObjectColumnTO.class, fields = {"id"})
    @Path("/id")
    public Response getId() {
        return Response.ok().entity(new ObjectColumnEntity()).build();
    }
```

c) Filtrando o retorno na fase de produção do Resource, ignorando(não expondo) os campos definidos.

```java
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    // O retorno será convertido para ObjectColumnTO, mas o atributo [description] não será exposto.
    @ConversionProduces(value = ObjectColumnTO.class, fields = {"description"}, ignore = true)
    @Path("/id")
    public Response getId() {
        return Response.ok().entity(new ObjectColumnEntity()).build();
    }
```

d) Disparando a conversão na fase de consumo do Resource.

**OBS:** _Quando houver mais de um parâmetro no método do Resource, será necessário indicar qual deles receberá os dados da conversão. A indicação deve ser feita por meio da anotação_ `@Consumer`.
 
 ```java
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    // A entrada de dados será convertida de ObjectColumnTO para ObjectColumnEntity.
    @ConversionConsumes(ObjectColumnTO.class)
    public Response post(@Consumer ObjectColumnEntity param) {
        return Response.ok().entity(param).build();
    }
 ```

## 10.2 - Conversão automática por mapeamento de classes. <a name="resourceautoconvert.withmap"></a>
 
**OBS:** _Para o exemplo de conversão por mapeamento, considere a classe abaixo._

```java
    public class NonIPojoEntity {
        private UUID id;
    
        private Boolean active;
    
        private Integer code;
    
        private String description;
    
        private NonIPojoChildEntity child;
```
 
### 10.2.1 - Exemplo mapeamento de classes. <a name="resourceautoconvert.withmap.examples"></a>
 
```java
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    // A entrada de dados será convertida de NonIPojoTO para NonIPojoEntity.
    @ConversionMapConsumes(
            @ConversionMap({
                @ConversionMapEntry(from = NonIPojoTO.class, to = NonIPojoEntity.class),
                @ConversionMapEntry(from = NonIPojoChildTO.class, to = NonIPojoChildEntity.class)
            })
        )
    // O retorno será convertido para NonIPojoTO.
    @ConversionMapProduces(
            @ConversionMap({
                @ConversionMapEntry(from = NonIPojoEntity.class, to = NonIPojoTO.class),
                @ConversionMapEntry(from = NonIPojoChildEntity.class, to = NonIPojoChildTO.class)
            })
        )
    @Path("/mapped")
    public Response postMapped(@Consumer NonIPojoEntity param) {
        return Response.ok().entity(param).build();
    }
```

## 10.3 - Anotações disponíveis <a name="resourceautoconvert.availableAnnotations"></a>

|   Annotation   |   Descrição   |
|---             |     ---       |
|`@ConversionConsumes` |  Indica a conversão na fase de consumo do Resource. (Vide 11.1 - c)|
|`@Consumer` |  Indica o parâmetro que consumirá os dados(resultado) da conversão. (Vide 11.1 - c)|
|`@ConversionProduces`|Indica a conversão na fase de produção do Resource. (Vide 11.1 - a,b)|
|`@ConversionMapConsumes`|Indica a conversão na fase de consumo do Resource, configurada por mapeamento de classe. (Vide 11.2)|
|`@ConversionMap`|Permite criar um array de `@ConversionMapEntry`. (Vide 11.2)|
|`@ConversionMapEntry`|Permite criar uma entrada para o mapeamento de classe. (Vide 11.2)|
|`@ConversionMapProduces`|Indica a conversão na fase de consumo do Resource, configurada por mapeamento de classe. (Vide 11.2)|
 
 Indica a conversão na fase de consumo do Resource, configurada por mapeamento de classe. (Vide 11.2)
 
 
# 11 - Configuração da aplicação <a name="appconfig"></a>

 Para inicialização do sistema.
 
## 11.1 Inicialização padrão <a name="appconfig.default"></a>
	 Inicialização com as configurações padrão.
	 Para mais informações consulte ApplicationConfig.

```java
	public Application() {
          ApplicationConfig.setResourceConfig(this)
         .setPackage(getClass().getPackage().getName()).configureJersey();

    }	
```
## 11.2 Inicialização personalizada <a name="appconfig.custom"></a>

   Personalizar a inicialização, modificando o padrão, adicionando e/ou removendo registros.
   Ex.:
  
```java
	public Application() {

         ApplicationConfig.setResourceConfig(this).setPackage(getClass().getPackage().getName()).register(AnyClass.class).register(new SomeObject()).removeClass(OtherClasss.class).configureJersey();

    }	
```
    Ignorando os registros definidos por padrão.
 
 ```java
 	public Application() {
        final String basePackage = getClass().getPackage().getName();
        final Set<Class<?>> classes = anyMethodThatReturnClassSet();
        
        ApplicationConfig.setResourceConfig(this).setPackage(basePackage)
            .ignoreDefaultRegisters().registerClasses(classes).configureJersey();
 
     }	
 ```
# Documentação <a name="documentacao"></a>

  Cada módulo da lib **commons**, além do principal *root*, tem sua documentação disponível separadamente:

  * [Root](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons/index.html)
  * [Message Bundle](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-message-bundle/index.html)
  * [Persistence Model](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-persistence-model/index.html)
  * [Pojo Converter API](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-api/index.html)
  * [Pojo Converter Core IMPL](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-core-impl/index.html)
  * [Pojo Converter Ebean IMPL](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-pojo-converter-ebean-impl/index.html)
  * [Security](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-security/index.html)
  * [Server JSON](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-json/index.html)
  * [Server Pagination](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-server-pagination/index.html)
  * [Utils](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-utils/index.html)
  * [Quartz](http://platform.pages.gitlab.wssim.com.br/commons/javadoc/commons-quartz/index.html)