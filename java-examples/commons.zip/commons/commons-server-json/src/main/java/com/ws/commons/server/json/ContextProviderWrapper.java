package com.ws.commons.server.json;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Providers;

/**
 * Wrapper class used to help {@link ObjectMapperResolver} retrieve a server context and, if
 * available, check if is the default Commons resolver.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-20
 */
public class ContextProviderWrapper {

    @Context
    private Providers providers;

    private ContextResolver<ObjectMapper> contextResolver;

    private static final Logger LOGGER = LoggerFactory.getLogger(ObjectMapperResolver.class);

    /**
     * Confirms if injection of server context was successful.
     *
     * @return {@code true} if a server context is reachable
     */
    public boolean isContextFound() {
        return providers != null;
    }

    /**
     * Confirms if the possible find server context has a resolver for {@link ContextResolver} of {@link ObjectMapper}.
     *
     * @return {@code true} if a context resolver for {@link ObjectMapper} is available
     */
    public boolean isResolverFound() {
        return getResolver() != null;
    }

    /**
     * Confirms if the possible {@link ContextResolver} of {@link ObjectMapper} available is the Commons default
     * {@link ObjectMapperResolver}.
     *
     * @return {@code true} if the context resolver found is the Commons implementation
     */
    public boolean isDefaultCommonResolverFound() {
        return isResolverFound() && contextResolver instanceof ObjectMapperResolver;
    }

    /**
     * Returns the resolver for {@link ObjectMapper} if {@link #isContextFound()} is true.
     *
     * @return a {@link ContextResolver} of {@link ObjectMapper} if context is available with a resolver registered
     */
    public ContextResolver<ObjectMapper> getResolver() {
        if (contextResolver == null && isContextFound()) {
            try {
                contextResolver = providers.getContextResolver(ObjectMapper.class, MediaType.APPLICATION_JSON_TYPE);
            } catch (final Exception exception) {
                LOGGER.debug("No resolvers found for ObjectMapper");
            }
        }

        return contextResolver;
    }

    /**
     * Returns the {@link ObjectMapper} resolved by {@link #getResolver()}, if any is available.
     *
     * @return an {@link ObjectMapper} if {@link #isResolverFound()} is true
     */
    public ObjectMapper getObjectMapperFromResolver() {
        if (isResolverFound()) {
            return contextResolver.getContext(Object.class);
        } else {
            return null;
        }
    }
}
