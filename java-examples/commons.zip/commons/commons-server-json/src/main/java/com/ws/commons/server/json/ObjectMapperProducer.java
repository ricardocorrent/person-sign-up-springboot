package com.ws.commons.server.json;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.enterprise.inject.Produces;

/**
 * Produces instances of {@link ObjectMapper} to CDI injection.
 *
 * @author  Thyago Volpatto
 * @author  Rogerio Kiihl
 * @version 7.0.0 - 2018-07-16 - New injections qualifiers
 * @since   5.4.0 - 2017-12-21
 */
public class ObjectMapperProducer {

    /**
     * Produces <strong>a new instance</strong> of ObjectMapper. That instance will
     * be a copy from the {@link ObjectMapper} found in current server context. When
     * no context is found, makes a copy from the static internal instance template
     * ruled by Commons implementation.
     *
     * @return  a clone {@link ObjectMapper} from current application template
     * @see     ObjectMapperResolver#createDefaultObjectMapper(boolean)
     */
    @Produces
    public ObjectMapper producesObjectMapper(){
        return ObjectMapperResolver.createDefaultObjectMapper(false);
    }

    /**
     * Produces the ObjectMapper application template, allowing changes to default
     * configurations and injections. The resulting mapper is acquired from the
     * server context only. Using this qualified injection with no context available will
     * throw {@link com.ws.commons.server.json.exception.ContextRequiredException}.
     *
     * @return  the static default {@link ObjectMapper} instance used as template
     * @see     ObjectMapperResolver#getApplicationObjectMapper
     */
    @Produces
    @ApplicationObjectMapper
    public ObjectMapper producesApplicationObjectMapper() {
        return ObjectMapperResolver.getApplicationObjectMapper(true);
    }
}
