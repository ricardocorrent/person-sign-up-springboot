package com.ws.commons.server.json;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ws.commons.JsonProperties;
import com.ws.commons.server.json.exception.ContextRequiredException;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import org.apache.deltaspike.core.util.ProjectStageProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.spi.CDI;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.inject.Inject;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Manages how {@link ObjectMapper} instances are provided to injections - be it CDI injections or
 * Rest context - besides allowing changes to default configuration or build a specific one.
 *
 * <p><strong>CDI injection</strong></p>
 *
 * <p>Injections with {@link Inject} annotation use producer class {@link ObjectMapperProducer}. How
 * are those injections built, tho, is responsibility of this class and follow these rules:</p>
 * <ul>
 *     <li><strong>Default injection</strong>: if no qualifier were used to restrict injection production, the injected
 *     value will a simple <em>copy of template instance</em>. That copy instance has current default configuration and
 *     will be managed by the scope of the injected field. Any changes made to this copy instance will not affect any
 *     other injection.
 *
 *     <p>If a server context is available <strong>and</strong> some different implementation of {@link ContextResolver}
 *     is registered, value get from {@link ContextResolver#getContext(Class)} will be the source for copying. If no context
 *     is available <strong>or</strong> the Commons implementation resolver is found, {@link ObjectMapperResolver#getInternalInstance()}
 *     will be source to be copied.</p></li>
 *
 *     <li><strong>Application template injection</strong>: with the {@link ApplicationObjectMapper} qualifier, unlike
 *     other injection, will give the same instance being used as template for all injections (any kind) or constructions
 *     made by this class. Should only be used when there is no risk of changing any value on it or, if changes are made,
 *     <font color="red">remember that those changes will be spread all over other injections or constructions made
 *     after that point.</font>
 *
 *     <p>If a server context is available <strong>and</strong> some different implementation of {@link ContextResolver}
 *     is registered, value get from {@link ContextResolver#getContext(Class)} will be injected. If the Commons
 *     implementation resolver is found in the context, instance from {@link ObjectMapperResolver#getInternalInstance()}
 *     will be injected.</p>
 *
 *     <p>If no context is found at all, a {@link ContextRequiredException} will be thrown. An alternative way to access
 *     the application template even without available context is using {@link ObjectMapperResolver#getApplicationObjectMapper(boolean)}
 *     with a {@code FALSE} parameter indicating that context is not required.</p></li>
 * </ul>
 *
 * <p><strong>REST context</strong></p>
 *
 * <p>ObjectMapperResolver is also the provider class for contexts requisitions of ObjectMapper. Our libraries and
 * frameworks will look in the context for the mapper suited for serialization operations. Fields decorated with
 * {@link Context} annotation will create an instance of this class and invoke {@link #getContext(Class)} method
 * to have a ObjectMapper instance.</p>
 *
 * <p>The mapper produced in this case is the same produced with <em>Default Injection</em> (see more above) and changes
 * made on it will not be used or kept in template or even in the context. That means any other point where {@link #getContext(Class)}
 * is invoked, a new instance will be created.</p>
 *
 * <p>Commons implementation of ObjectMapper resolver is not mandatory, tho, at some point, an ObjectMapper must be
 * supplied for REST serializations. If some different resolver is registered - and not this one - above REST functionality
 * will be ignored</p>
 *
 * <p><strong>Direct invocation</strong></p>
 *
 * <p>ObjectMapperResolver can be directed used providing same result of injections. It follows a Builder pattern
 * allowing callers choose default values or change any part of configuration.</p>
 *
 * <p>Attempt to reach a server context is always made, bringing from that found context the source for any Builder operation.
 * Desired behavior for scenarios without context can be set with {@link #requiresContextInstance(boolean)}. Default
 * behavior is not thrown exceptions, using the local implementation em favor of always producing a mapper. </p>
 *
 * <p>Following there are some examples of Builder can be used and its equivalence relation with methods for injections:</p>
 *
 * <ul>
 *     <li><em>Default mappers</em> can be reached in two ways: getting an instance and creating without any
 *     change on it, like this:</li>
 *
 *     <code><pre>
 *         ObjectMapperResolver
 *             .getInstance()
 *             .createMapper();
 *     </pre></code>
 *
 *     <p>or using the static method:</p>
 *
 *     <code><pre>
 *         ObjectMapperResolver.createDefaultObjectMapper(false);
 *     </pre></code>
 *
 *     <p>Result is the same, including the value get with {@link Inject} without any qualifier.</p>
 *
 *     <li><em>Non default mappers</em> are easy to make since the Build pattern used here allow access to most
 *     used modifiers of {@link ObjectMapper}:</li>
 *
 *     <code><pre>
 *         // Creates a instance without any configuration from template and disable a specific feature
 *         ObjectMapperResolver
 *             .getInstance()
 *             .ignoreCommonsDefault()
 *             .disable(MapperFeature.USE_GETTERS_AS_SETTERS)
 *             .createMapper();
 *
 *         // Creates a instance with all template configuration registering a new serializer
 *         ObjectMapperResolver
 *             .getInstance()
 *             .registerModule(CustomSerializer.class)
 *             .createMapper();
 *     </pre></code>
 *
 *     <p><em>Note that even changing configuration, if {@link #ignoreCommonsDefault()} method <strong>is not used</strong>, those
 *     changes will be joined to default configuration coming from template.</em></p>
 *
 *     <li>At last, <em>accessing default template</em> is easily done with {@link ObjectMapperResolver#getApplicationObjectMapper(boolean)}
 *     but that <font color="red"><em>all warnings and cares already said must be followed.</em></font></li>
 * </ul>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Thyago Volpatto
 * @author  Rogerio Kiihl
 * @version 5.5.4
 * @version 7.0.0 - 2018-07-16
 * @since   2016-02-05
 */
@Provider
@Produces(MediaType.APPLICATION_JSON)
public class ObjectMapperResolver implements ContextResolver<ObjectMapper> {

    /**
     * Internal enumeration used to distinguish kinds of configurations supported
     * by builder.
     */
    private enum ConfigOperation {
        REGISTER,
        ENABLE,
        DISABLE
    }

    private static final Boolean DEFAULT_SERIALIZATION_VALUES_EMPTY = Boolean.TRUE;
    private static final Object INSTANCE_LOCKER = new Object();
    private static ObjectMapper internalInstance;

    private final Map<ConfigOperation, ArrayList<Object>> configMap = new HashMap<>();
    private Boolean ignoreDefault = Boolean.FALSE;
    private Boolean isContextInstanceRequired = Boolean.FALSE;
    private Boolean useJacksonDateSerializer = Boolean.FALSE;

    private static final Logger LOGGER = LoggerFactory.getLogger(ObjectMapperResolver.class);

    /**
     * Gets a generic array list being able to hold any kind of values (features or modules)
     * attached to {@code operation} parameter value.
     *
     * @author          Rogerio Kiihl
     * @param operation type of operation to acquire values
     * @return          a generic array list with values already configured and able to receive more
     * @since           7.0.0 - 2018-07-16
     */
    private ArrayList<Object> getConfigFor(final ConfigOperation operation) {
        if (configMap.containsKey(operation)) {
            return configMap.get(operation);
        } else {
            final ArrayList<Object> config = new ArrayList<>();
            configMap.put(operation, config);

            return  config;
        }
    }

    /**
     * Allows iteration over all values previous added for the asked {@code operation} parameter.
     * Consumer parameter will be only used for values that are instance of given class.
     *
     * @author          Rogerio Kiihl
     * @param operation type of operation to iterate values
     * @param clazz     type of object of configuration. Will filter only values instance of this value
     * @param consumer  consumer to be executed with any value found
     * @param <T>       generic type allowing casting for operations
     * @since           7.0.0 - 2018-07-16
     */
    private <T> void forEach(final ConfigOperation operation, final Class<T> clazz, final Consumer<T> consumer) {
        final ArrayList<Object> config = configMap.get(operation);

        if (config != null) {
            for (final Object value : config) {
                if (clazz.isInstance(value)) {
                    consumer.accept(clazz.cast(value));
                }
            }
        }
    }

    /**
     * Value returned to context invocations are <strong>always default copy of application template</strong>.
     *
     *{@link  ContextResolver#getContext(Class)}
     */
    @Override
    public ObjectMapper getContext(final Class<?> type) {
        return createInstanceFromTemplate(getInternalInstance());
    }

    /**
     * Creates a new instance of the ObjectMapperResolver.
     */
    public ObjectMapperResolver() {
    }

    /**
     * Constructor to return a new instance of ObjectMapperResolver,
     * and creates a ObjectMapper that can be personalized.
     *
     * <p>Example:</p>
     * <pre>
     *      ObjectMapperResolver.getInstance().registerModule(Module).createMapper();
     * </pre>
     *
     * @author              Rogerio Kiihl
     * @param fromBuilder   {@code true} if wants to modify
     * @deprecated          lost its purpose in version 7.0.0 since new instances are always used except when explicit
     *                      required to not
     */
    @Deprecated
    public ObjectMapperResolver(final Boolean fromBuilder){
    }

    /**
     * Returns the instance of {@link ObjectMapperResolver}.
     *
     * @author Rogerio Kiihl
     * @return new instance of the {@link ObjectMapperResolver}
     */
    public static ObjectMapperResolver getInstance() {
        return new ObjectMapperResolver();
    }

    /**
     * Method to ignore the default properties of template.
     *
     * @return this builder
     */
    public ObjectMapperResolver ignoreCommonsDefault() {
        ignoreDefault = Boolean.TRUE;
        return this;
    }

    /**
     * Sets a Boolean value indicating if a server context is required to
     * create the {@link ObjectMapper} instance. With a {@code true} value in {@code isContextInstanceRequired},
     * {@link #createMapper()} will demand that a server context is available.
     * If the context is required but none is found, a {@link ContextRequiredException} will be thrown.
     *
     * <p><strong>The default value is FALSE</strong>, making builder firstly looks for a context. If none is
     * found, the default implementation is used instead of throwing an exception</p>
     *
     * @param isContextInstanceRequired {@code true} if instance <strong>must</strong> come from a server context
     * @return                          this builder
     */
    public ObjectMapperResolver requiresContextInstance(final boolean isContextInstanceRequired) {
        this.isContextInstanceRequired = isContextInstanceRequired;
        return this;
    }

    /**
     * Registers a new module.
     *
     * @param module    to be registered
     * @return          this builder
     */
    public ObjectMapperResolver registerModule(final Module module) {
        getConfigFor(ConfigOperation.REGISTER).add(module);
        return this;
    }

    /**
     * Registers new modules.
     *
     * @param modules   the modules to register
     * @return          this builder
     */
    public ObjectMapperResolver registerModules(final Iterable<Module> modules) {
        getConfigFor(ConfigOperation.REGISTER)
                .addAll(StreamSupport
                        .stream(modules.spliterator(), false)
                        .collect(Collectors.toList()));
        return this;
    }

    /**
     * Enables a serialization feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .enable(SerializationFeature.WRAP_ROOT_VALUE)
     *         .createMapper();
     *
     * </pre></code>
     * @param serializationFeature  a {@link SerializationFeature} instance
     * @return                      this builder
     */
    public ObjectMapperResolver enable(final SerializationFeature serializationFeature) {
        getConfigFor(ConfigOperation.ENABLE)
                .add(serializationFeature);

        return this;
    }

    /**
     * Enables a deserialization feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
     *         .createMapper();
     * </pre></code>
     *
     * @param deserializationFeature    a {@link DeserializationFeature} instance
     * @return                          this builder
     */
    public ObjectMapperResolver enable(final DeserializationFeature deserializationFeature) {
        getConfigFor(ConfigOperation.ENABLE)
                .add(deserializationFeature);

        return this;
    }

    /**
     * Enables a mapper feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .enable(MapperFeature.USE_GETTERS_AS_SETTERS)
     *         .createMapper();
     * </pre></code>
     *
     * @param mapperFeature a {@link MapperFeature} instance
     * @return              this builder
     */
    public ObjectMapperResolver enable(final MapperFeature mapperFeature) {
        getConfigFor(ConfigOperation.ENABLE)
                .add(mapperFeature);

        return this;
    }

    /**
     * Disables a serialization feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .disable(SerializationFeature.INDENT_OUTPUT)
     *         .createMapper();
     * </pre></code>
     *
     * @param serializationFeature  a {@link SerializationFeature} instance
     * @return                      this builder
     */
    public ObjectMapperResolver disable(final SerializationFeature serializationFeature) {
        getConfigFor(ConfigOperation.DISABLE)
                .add(serializationFeature);

        return this;
    }

    /**
     * Disables a deserialization feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .disable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
     *         .createMapper();
     * </pre></code>
     *
     * @param deserializationFeature    a {@link DeserializationFeature} instance
     * @return                          this builder
     */
    public ObjectMapperResolver disable(final DeserializationFeature deserializationFeature) {
        getConfigFor(ConfigOperation.DISABLE)
                .add(deserializationFeature);

        return this;
    }

    /**
     * Disables a createMapper feature.
     *
     * <code><pre>
     *     ObjectMapperResolver
     *         .getInstance()
     *         .disable(MapperFeature.USE_GETTERS_AS_SETTERS)
     *         .createMapper();
     * </pre></code>
     *
     * @param mapperFeature a {@link MapperFeature} instance
     * @return              this mapper
     */
    public ObjectMapperResolver disable(final MapperFeature mapperFeature) {
        getConfigFor(ConfigOperation.DISABLE)
                .add(mapperFeature);

        return this;
    }

    /**
     * Sets builder to register the modules {@link Jdk8Module} and {@link JavaTimeModule}
     * to serialize Java 8 date types.
     *
     * This does NOT consider the TIME ZONE.
     * @return this builder;
     */
    public ObjectMapperResolver useJacksonDateTypeSerializer(){
        useJacksonDateSerializer = Boolean.TRUE;
        return this;
    }

    /**
     * Resolves the {@link ObjectMapper} value for an injection with {@link ApplicationObjectMapper} qualifier.
     * It first looks in a server context for a {@link ContextResolver} different from this implementation.
     * If any is found, will get value from there. Otherwise, uses the static instance of this class.
     *
     * <strong><p><font color="red">Changes made for this instance will be spread to all injections
     * or builds after this point</font></p></strong>
     *
     * @author                          Rogerio Kiihl
     * @param isContextRequired         indicates if the server context is required and the <strong>only acceptable</strong>
     *                                  source for the desired ObjectMapper. If a context is required but none is
     *                                  found, an exception will be thrown. Otherwise, default implementation may be used.
     * @return                          an ObjectMapper expected to be the application template
     * @throws ContextRequiredException if parameter {@code isContextRequired} is True and no context is found
     * @since                           7.0.0 - 2018-07-23
     */
    public static ObjectMapper getApplicationObjectMapper(final boolean isContextRequired) {
        final ContextProviderWrapper wrapper = createContextProviderWrapper(isContextRequired);

        try {
            if (isACustomResolverFound(wrapper)) {
                LOGGER.debug("A non-Common implementation Resolver for ObjectMapper is found. This resolver will be used to acquire application mapper instance ");
                return wrapper.getObjectMapperFromResolver();
            } else {
                LOGGER.debug("No custom Resolvers for ObjectMapper were found. Since one is not required, internal and default ObjectMapper implementation will be used");
                return getInternalInstance();
            }
        } finally {
            if (wrapper != null) {
                CDI.current().destroy(wrapper);
            }
        }
    }

    /**
     * Returns {@code true} if, in the given context wrapper, a server context is available AND a
     * {@link ContextResolver} different from {@link ObjectMapperResolver} is found.
     *
     * @author          Rogerio Kiihl
     * @param wrapper   the wrapper context with server context information
     * @return          {@code true} if a non-common resolver is found
     * @since           7.0.0 - 2018-07-23
     */
    private static boolean isACustomResolverFound(final ContextProviderWrapper wrapper) {
        return wrapper != null && wrapper.isResolverFound() && !wrapper.isDefaultCommonResolverFound();
    }

    /**
     * Makes sure a shared application instance is ready to be used. This instance
     * will be used as template for all {@link ObjectMapper} generated by this resolver.
     *
     * @author  Rogerio Kiihl
     * @return  the shared application ObjectMapper instance
     * @since   7.0.0 - 2018-07-23
     */
    public static ObjectMapper getInternalInstance() {
        synchronized (INSTANCE_LOCKER) {
            if (internalInstance == null)
                createApplicationObjectMapperInstance();

            return internalInstance;
        }
    }

    /**
     * Tries to create the wrapper which can answer if a context is available and what resolver is in it.
     *
     * @author                          Rogerio Kiihl
     * @param isRequired                {@code true} if an exception must be thrown when no contexts are found
     * @return                          a server context wrapper or null if any is found.
     * @throws ContextRequiredException if parameter {@code isRequired} is True and no context is found
     * @since                           7.0.0 - 2018-07-24
     */
    private static ContextProviderWrapper createContextProviderWrapper(final boolean isRequired) {
        ContextProviderWrapper wrapper = null;

        try {
            wrapper = CDI.current().select(ContextProviderWrapper.class).get();
        } catch (final Throwable anyException) {
            // Fails trying to acquire context information should not interrupt flow
            LOGGER.warn("Failed trying to get ContextProviderWrapper from CDI: {}", anyException.getMessage());
        }

        if (isRequired && ( wrapper == null || !wrapper.isContextFound())) {
            throw new ContextRequiredException("The ObjectMapper construction requires a server context but none was found. " +
                    "Use ObjectMapperResolver builder to avoid this exception with default implementations." );
        }

        return wrapper;
    }


    /**
     * Creates a new instance of {@link ObjectMapper} keeping all configuration found in current
     * default template. The default template follow rules from {@link #getApplicationObjectMapper(boolean)}.
     *
     * @author                          Rogerio Kiihl
     * @param isContextRequired         Indicates if the template for the new ObjectMapper instance <strong>must</strong>
     *                                  come from a server context. If a context is required but none is found, an exception
     *                                  will be thrown. Otherwise, default implementation may be used.
     * @return                          a copy instance of default template
     * @throws ContextRequiredException if parameter {@code isContextRequired} is True and no context is found
     * @since                           7.0.0 - 2018-06-18
     */
    public static ObjectMapper createDefaultObjectMapper(final boolean isContextRequired) {
        return createInstanceFromTemplate(getApplicationObjectMapper(isContextRequired));
    }

    /**
     * Creates a clone from given template.
     *
     * @author                      Rogerio Kiihl
     * @param objectMapperTemplate  the source template to clone
     * @return                      a copy from given template
     * @since                       7.0.0 - 2018-06-18
     */
    private static ObjectMapper createInstanceFromTemplate(final ObjectMapper objectMapperTemplate) {
        return objectMapperTemplate.copy();
    }


    /**
     * Allows the destruction of current default template. All previous changes made to template
     * will be lost and a new one - with default common configuration - will be created.
     *
     * @author  Rogerio Kiihl
     * @since   7.0.0 - 2018-06-18
     */
    static void resetApplicationObjectMapper() {
        synchronized (INSTANCE_LOCKER) {
            createApplicationObjectMapperInstance();
        }
    }

    /**
     * Instantiates and apply default configuration to template instance. It is a method for
     * internal use only and must <strong>always</strong> be invoked in a <strong><em>synchronized block
     * using {@link #INSTANCE_LOCKER} locker instance</em></strong>.
     *
     * @author  Rogerio Kiihl
     * @since   7.0.0 - 2018-06-18
     */
    private static void createApplicationObjectMapperInstance() {
        internalInstance = new ObjectMapper();
        setDefaultConfiguration(internalInstance);
        configureJacksonSerializer(internalInstance);
    }

    /**
     * Looks in configuration values for value set for {@link JsonProperties#SERVER_SERIALIZATION_VALUES_EMPTY}.
     *
     * @return value found in configuration
     */
    private static Boolean isEmptyValuesSerialized() {
        return ConfigResolver.resolve(JsonProperties.SERVER_SERIALIZATION_VALUES_EMPTY)
                .as(Boolean.class)
                .withDefault(DEFAULT_SERIALIZATION_VALUES_EMPTY)
                .getValue();
    }

    /**
     * Applies in the given {@link ObjectMapper} instance the default commons configuration.
     *
     * @param mapper a mapper instance to set with default values
     */
    private static void setDefaultConfiguration(final ObjectMapper mapper) {
        final Include inclusionMethod = isEmptyValuesSerialized() ? Include.NON_NULL : Include.NON_EMPTY;
        mapper.setSerializationInclusion(inclusionMethod);

        mapper.disable(MapperFeature.USE_GETTERS_AS_SETTERS);
        mapper.writerWithDefaultPrettyPrinter();

        final ProjectStage stage = ProjectStageProducer.getInstance().getProjectStage();
        if(!stage.equals(ProjectStage.Production)){
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
        }
    }

    /**
     * Configure the custom serializer/deserializer to date types.
     *
     * @param mapper a mapper instance to set serializers
     */
    private static void configureJacksonSerializer(final ObjectMapper mapper) {
        final SimpleModule module = new SimpleModule("module", new Version(1, 0, 0, null, null, null));

        // Serializer
        module.addSerializer(Temporal.class, new TemporalSerializer());

        // Deserializer
        module.addDeserializer(String.class, new StringDeserializer());
        module.addDeserializer(LocalDate.class, new LocalDateDeserializer());
        module.addDeserializer(LocalTime.class, new LocalTimeDeserializer());
        module.addDeserializer(OffsetDateTime.class, new OffsetDateTimeDeserializer());
        module.addDeserializer(OffsetTime.class, new OffsetTimeDeserializer());

        mapper.registerModule(module);
    }

    /**
     * Applies in the given {@link ObjectMapper} instance configuration gather by modifier
     * methods before invocation of {@link #createMapper()}.
     *
     * @param mapper a mapper instance to set the custom configuration so far informed
     *
     * @author  Rogerio Kiihl
     * @since   7.0.0 - 2018-06-18
     */
    private void applyInstanceConfiguration(final ObjectMapper mapper) {
        if (!configMap.isEmpty()) {
            forEach(ConfigOperation.REGISTER, Module.class, mapper::registerModule);

            forEach(ConfigOperation.ENABLE, SerializationFeature.class, mapper::enable);
            forEach(ConfigOperation.ENABLE, DeserializationFeature.class, mapper::enable);
            forEach(ConfigOperation.ENABLE, MapperFeature.class, mapper::enable);

            forEach(ConfigOperation.DISABLE, SerializationFeature.class, mapper::disable);
            forEach(ConfigOperation.DISABLE, DeserializationFeature.class, mapper::disable);
            forEach(ConfigOperation.DISABLE, MapperFeature.class, mapper::disable);
        }
    }

    /**
     * Return the ObjectMapper with the properties previously set up.
     *
     * <p>Examples:</p>
     * <code><pre>
     *
     *     // Builds a default copy of template mapper
     *     ObjectMapperResolver
     *         .getInstance()
     *         .createMapper();
     *
     *     // Builds a non default copy with some module registered
     *     ObjectMapperResolver
     *         .getInstance()
     *         .ignoreDefault()
     *         .registerModule(anyModule)
     *         .createMapper();
     *
     * </pre></code>
     *
     * @return this mapper
     */
    public ObjectMapper createMapper(){
        final ObjectMapper mapper = ignoreDefault ? new ObjectMapper() : createDefaultObjectMapper(isContextInstanceRequired);

        if (useJacksonDateSerializer) {
            mapper.registerModule(new Jdk8Module()).registerModule( new JavaTimeModule())
                    .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        }

        applyInstanceConfiguration(mapper);

        return mapper;
    }
}
