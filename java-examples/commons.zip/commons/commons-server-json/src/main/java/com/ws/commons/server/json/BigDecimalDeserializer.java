package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * JSON deserializer prepared for {@link BigDecimal} expressed as regular strings.
 *
 * <p>Client consumer applications may have the need to treat big decimal values as string due its
 * limitations, like JavaScript. By this deserializer, those number values expressed as strings in
 * JSON's will be converted to a Java {@link BigDecimal}</p>
 *
 * <p>A regular json with {@link BigDecimal} like:</p>
 * <pre><code>
 *   {
 *      "decimalField" : 100.58
 *   }
 * </code></pre>
 * <p>must be in the bellow format to be used with this deserializer:</p>
 * <pre><code>
 *   {
 *      "decimalField" : "100.58"
 *   }
 * </code></pre>
 *
 * <p>This customized deserialization <strong>only affects</strong> {@link BigDecimal} fields with
 * {@link JsonSerialize} indicating this serializer. Otherwise, the regular number deserialization will be used.</p>
 *
 * <pre><code>
 *    {@literal @JsonSerialize(using = BigDecimalDeserializer.class)}
 *     private BigDecimal decimalField;
 * </code></pre>
 *
 * <p>Before using this deserializer have in mind resource application consumers and its ability to
 * generate JSON numbers as a string value. Also remember of the serializer {@link BigDecimalSerializer}
 * when resources will also send JSON parameters with a string representation of a number.</p>
 *
 * @author  Rogerio Kiihl
 * @see     BigDecimalSerializer
 * @see     JsonSerialize
 * @since   6.1.0 - 2018-06-22
 */
public class BigDecimalDeserializer extends JsonDeserializer<BigDecimal> {

    /**
     * Tries to deserialize a big decimal value from a string value.
     *
     * @param jsonParser                parser used for reading JSON content
     * @param context                   context that can be used to access information about this deserialization activity
     * @return                          deserialized {@link BigDecimal} value
     * @throws IOException              may be thrown while parsing the json value node
     * @throws NumberFormatException    if JSON value is not a valid representation of a {@code BigDecimal}
     */
    @Override
    public BigDecimal deserialize(final JsonParser jsonParser, final DeserializationContext context) throws IOException {
        final ObjectCodec objectCodec = jsonParser.getCodec();
        final JsonNode jsonNode = objectCodec.readTree(jsonParser);

        if (jsonNode != null && !StringUtils.isEmpty(jsonNode.asText())) {
            return new BigDecimal(jsonNode.asText());
        } else {
            return null;
        }
    }
}
