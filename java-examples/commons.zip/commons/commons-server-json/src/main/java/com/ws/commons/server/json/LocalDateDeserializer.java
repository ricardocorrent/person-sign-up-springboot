package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * JSON deserializer prepared for {@link LocalDate} expressed as regular strings.
 *
 * <p>Client consumer applications may have the need to treat provided values as string due its
 * incompatibilities, like JavaScript haves too. By this deserializer, those number values expressed as strings in
 * JSON's will be converted to a Java {@link LocalDate}.</p>
 *
 * <p>A regular JSON with {@link LocalDate} like:</p>
 * <pre><code>
 *   {
 *      "date" : 2019-01-01
 *   }
 * </code></pre>
 * <p>must be in the bellow format to be used with this deserializer:</p>
 * <pre><code>
 *   {
 *      "date" : "2019-01-01"
 *   }
 * </code></pre>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @author  Lucas Dillmann
 * @version 5.5.5 - 2018-04-18 - Fix standard deserializer.
 * @version 7.0.2 - 2018-08-04 - Changes to parse flow to try to deserialize using
 *                               ISO_LOCAL_DATE and, if it fails, using ISO_OFFSET_DATE_TIME
 * @since   2016-01-20
 */
public class LocalDateDeserializer extends JsonDeserializer<LocalDate> {

    /**
     * @see JsonDeserializer#deserialize(JsonParser, DeserializationContext)
     */
    @Override
    public LocalDate deserialize(final JsonParser jsonParser, final DeserializationContext context) throws IOException {
        final ObjectCodec objectCodec = jsonParser.getCodec();
        final JsonNode jsonNode = objectCodec.readTree(jsonParser);

        return jsonNode != null ? deserialize(jsonNode.asText()) : null;
    }

    /**
     * Tries to deserialize a {@link LocalDate} value from a string value.
     *
     * @param date          to deserialize.
     * @return              the date as object.
     * @throws IOException  if {@link LocalDate#parse(CharSequence)} fails.
     *
     */
    public LocalDate deserialize(final String date) throws IOException {
        try {
            return LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (final DateTimeParseException exception) {
            LoggerFactory
                    .getLogger(getClass())
                    .warn("Failed to decode '" + date + "' as a LocalDate using ISO_LOCAL_DATE. " +
                            "Trying to decode using ISO_OFFSET_DATE_TIME format instead.");

            return LocalDate.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        }
    }
}
