package com.ws.commons.server.json.exception;

import com.ws.commons.server.json.ObjectMapperResolver;

/**
 * Runtime exception thrown by {@link ObjectMapperResolver} when operations which demands a context do not find any running.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-24
 */
public class ContextRequiredException extends RuntimeException {

    public ContextRequiredException(final String message) {
        super(message);
    }
}
