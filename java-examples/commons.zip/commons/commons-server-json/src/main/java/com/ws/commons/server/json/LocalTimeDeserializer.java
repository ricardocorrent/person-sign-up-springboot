package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * JSON deserializer prepared for {@link LocalTime} expressed as regular strings.
 *
 * <p>Client consumer applications may have the need to treat provided values as string due its
 * incompatibilities, like JavaScript haves too. By this deserializer, those number values expressed as strings in
 * JSON's will be converted to a Java {@link LocalTime}.</p>
 *
 * <p>A regular json with {@link LocalTime} like:</p>
 * <pre><code>
 *   {
 *      "time" : 10:15:30
 *   }
 * </code></pre>
 * <p>must be in the bellow format to be used with this deserializer:</p>
 * <pre><code>
 *   {
 *      "time" : "10:15:30"
 *   }
 * </code></pre>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @version 5.5.5 - 2018-04-18 - Fix standard deserializer.
 * @since   2016-01-20
 */
public class LocalTimeDeserializer extends JsonDeserializer<LocalTime> {

    /**
     * @see JsonDeserializer#deserialize(JsonParser, DeserializationContext)
     */
    @Override
    public LocalTime deserialize(final JsonParser jsonParser, final DeserializationContext context) throws IOException {
        final ObjectCodec objectCodec = jsonParser.getCodec();
        final JsonNode jsonNode = objectCodec.readTree(jsonParser);

        return jsonNode != null ? deserialize(jsonNode.asText()) : null;
    }

    /**
     * Tries to deserialize a {@link LocalTime} value from a string value.
     *
     * @param time          to deserialize
     * @return              the date as object
     * @throws IOException  if {@link LocalDate#parse(CharSequence)} fails
     */
    public LocalTime deserialize(final String time) throws IOException {
        return LocalTime.parse(time,DateTimeFormatter.ISO_TIME);
    }
}
