package com.ws.commons.server.json;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Qualifier to decorate {@link ObjectMapper} injections when access
 * to shared application template instance is desired.
 *
 * <p>The ObjectMapper injected with this qualifier is supposed to be the template for all others injection -
 * be it with {@link javax.inject.Inject} or {@link javax.ws.rs.core.Context} or instances created with
 * {@link ObjectMapperResolver}.</p>
 *
 * <p>If a server context is available <em>and</em> the {@link javax.ws.rs.ext.ContextResolver} found
 * on it is the default Commons resolver {@link ObjectMapperResolver} <strong>OR, </strong> no server context
 * is found, the resulting mapper will be the static instance retrieved from {@link ObjectMapperResolver#getInternalInstance()} ()}</p>
 *
 * <p>With a context available different from Commons resolver, the resulting mapper will be the value get from
 * {@link javax.ws.rs.ext.ContextResolver#getContext(Class)} using a {@link Object} as parameter.</p>
 *
 * <p><font color="red"><strong>It is highly recommended to only use this when configuration changes <em>must</em>
 * affect all mappers produced</strong></font></p>
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-16
 */
@Qualifier
@Retention(RUNTIME)
@Target({TYPE, FIELD, PARAMETER, METHOD})
public @interface ApplicationObjectMapper {
}
