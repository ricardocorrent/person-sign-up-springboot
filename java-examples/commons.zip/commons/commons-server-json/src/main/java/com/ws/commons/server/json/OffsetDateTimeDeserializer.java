package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

/**
 * JSON deserializer prepared for {@link OffsetDateTime} expressed as regular strings.
 *
 * <p>Client consumer applications may have the need to treat provided values as string due its
 * incompatibilities, like JavaScript haves too. By this deserializer, those number values expressed as strings in
 * JSON's will be converted to a Java {@link OffsetDateTime}.</p>
 *
 * <p>A regular json with {@link OffsetDateTime} like:</p>
 * <pre><code>
 *   {
 *      "date" : 2007-12-03T10:15:30+01:00
 *   }
 * </code></pre>
 * <p>must be in the bellow format to be used with this deserializer:</p>
 * <pre><code>
 *   {
 *      "date" : "2007-12-03T10:15:30+01:00"
 *   }
 * </code></pre>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @version 5.5.5 - 2018-04-18 - Fix standard deserializer.
 * @since   2016-01-20
 */
public class OffsetDateTimeDeserializer extends JsonDeserializer<OffsetDateTime> {
    
    /**
     * @see JsonDeserializer#deserialize(JsonParser, DeserializationContext)
     */
    @Override
    public OffsetDateTime deserialize(final JsonParser jsonParser, final DeserializationContext context)
            throws IOException {
        final ObjectCodec objectCodec = jsonParser.getCodec();
        final JsonNode jsonNode = objectCodec.readTree(jsonParser);

        return jsonNode != null ? deserialize(jsonNode.asText()) : null;
    }

    /**
     * Tries to deserialize a {@link OffsetDateTime} value from a string value.
     *
     * @param date          to deserialize
     * @return              the date as object
     * @throws IOException  if {@link OffsetDateTime#parse(CharSequence)} fails
     */
    public OffsetDateTime deserialize(final String date) throws IOException {
        return StringUtils.isEmpty(date) ? null : OffsetDateTime
                .parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }
}
