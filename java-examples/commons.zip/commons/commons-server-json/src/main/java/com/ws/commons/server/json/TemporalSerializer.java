package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.time.temporal.Temporal;

/**
 * Serializer making a {@link Temporal} be written as a string value at the output Jackson JSON.
 *
 * <p>Client consumer applications may have the need to treat {@link Temporal} values as string due its
 * incompatibilities, like JavaScript haves too. By this serializer, the value will be converted to a {@link String} and put on
 * the JSON as a string.</p>
 *
 * <p>This customized deserialization <strong>only affects</strong> {@link Temporal} fields with
 * {@link JsonSerialize} indicating this serializer. Otherwise, the regular number serialization will be used.</p>
 *
 * <pre><code>
 *     {@literal @JsonSerialize(using = TemporalSerializer.class)}
 *     private BigDecimal decimalField;
 * </code></pre>
 *
 * @author  Sezar Thiago Caldeira
 * @author  Ivan A. Reffatti
 * @author  Diego A. Costa
 * @version 5.5.5 - 2018-04-18 - Fix standard serializer.
 * @since   2016-01-20
 */
public class TemporalSerializer extends JsonSerializer<Temporal> {

    /**
     * Method that can be called to ask implementation to serialize
     * values of type this serializer handles.
     *
     * @param value         value to serialize; can <b>not</b> be null
     * @param generator     generator used to output resulting Json content
     * @param serializers   provider that can be used to get serializers for
     *                      serializing Objects value contains, if any
     * @see                 StdSerializer#serialize(Object, JsonGenerator, SerializerProvider)
     */
    @Override
    public void serialize(final Temporal value, 
            final JsonGenerator generator, 
            final SerializerProvider serializers) throws IOException {
        if (value != null && generator != null) {
            generator.writeString(value.toString());
        }
    }
}
