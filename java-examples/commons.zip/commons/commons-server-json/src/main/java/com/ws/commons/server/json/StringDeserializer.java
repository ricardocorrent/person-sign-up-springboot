package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

/**
 * Applies {@link String#trim()} or return null if is empty.
 *
 * @author  Sezar Thiago Caldeira
 * @author  Diego A. Costa
 * @version 5.5.5 - 2018-04-18 - Fix standard deserializer.
 * @since   2016-06-02
 */
public class StringDeserializer extends JsonDeserializer<String> {

    /**
     * @see JsonDeserializer#deserialize(JsonParser, DeserializationContext)
     */
    @Override
    public String deserialize(final JsonParser jsonParser, final DeserializationContext context) throws IOException {
        final ObjectCodec objectCodec = jsonParser.getCodec();
        final JsonNode jsonNode = objectCodec.readTree(jsonParser);
        final String asText = jsonNode != null ? jsonNode.asText().trim() : StringUtils.EMPTY;

        return asText.isEmpty() ? null : asText;
    }
}
