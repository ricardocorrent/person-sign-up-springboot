package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Serializer making a {@link BigDecimal} be written as a string value at the output Jackson JSON.
 *
 * <p>Client consumer applications may have the need to treat big decimal values as string due its
 * limitations, like JavaScript. By this serializer, the value will be converted to a {@link String} and put on
 * the JSON as a string.</p>
 *
 * <p>The result is regular generated json with a {@link BigDecimal}:</p>
 *
 * <pre><code>
 *   {
 *      "decimalField" : 100.58
 *   }
 * </code></pre>
 * <p>becoming:</p>
 * <pre><code>
 *   {
 *      "decimalField" : "100.58"
 *   }
 * </code></pre>
 *
 * <p>This customized deserialization <strong>only affects</strong> {@link BigDecimal} fields with
 * {@link JsonSerialize} indicating this serializer. Otherwise, the regular number serialization will be used.</p>
 *
 * <pre><code>
 *     {@literal @JsonSerialize(using = BigDecimalSerializer.class)}
 *     private BigDecimal decimalField;
 * </code></pre>
 *
 * <p>Before using this serializer have in mind resource application consumers and its ability to
 * treat the given string as decimal number. Also remember of the deserializer {@link BigDecimalDeserializer}
 * when resources will receive JSON parameters with a string representation of a number.</p>
 *
 * @author  Rogerio Kiihl
 * @see     JsonSerialize
 * @since   6.1.0 - 2018-06-22
 */
public class BigDecimalSerializer extends JsonSerializer<BigDecimal> {

    /**
     * Serializes the given {@link BigDecimal} value as a String, if any value is present.
     *
     * @param value         the big decimal value to serialize. If it is null, no output is written
     * @param generator     generator used to output resulting JSON content
     * @param serializers   provider that can be used to get serializers for serialization
     * @throws IOException  may be thrown if {@link JsonGenerator#writeString(String)} fails
     */
    @Override
    public void serialize(final BigDecimal value, final JsonGenerator generator, final SerializerProvider serializers) throws IOException {
        if (generator != null && value != null) {
            generator.writeString(value.toString());
        }
    }
}
