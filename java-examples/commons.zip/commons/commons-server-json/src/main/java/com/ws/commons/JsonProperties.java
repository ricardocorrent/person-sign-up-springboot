package com.ws.commons;

import org.apache.deltaspike.core.api.config.ConfigProperty;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 * Properties configuration to customize JSON serializing and deserializing through apache-deltaspike.properties
 * file.
 *
 * @author  Diego Armange Costa
 * @author  Lucas Dillmann
 * @version 7.3.0 - 2018-09-06 - Added configuration to disable default deserialization exception handlers
 * @since   6.0.0 - 2018-02-14
 */
@ApplicationScoped
public class JsonProperties {

    /**
     * Indicates whether Jackson should serialize empty array members.
     * <p>If {@code false}, {@code null} and empty arrays will be disregarded during serialization.</p>
     * Key: server.serialization.values.empty
     *
     * @since 5.1.0 - 2017-10-10
     */
    public static final String SERVER_SERIALIZATION_VALUES_EMPTY = "server.serialization.values.empty";

    /**
     * Defines if, when a deserialization exception from JSON to object happens, an default implementation of
     * DeserializationExceptionHandler provided by the commons library should be used or not to handle that exception.
     *
     * @since 7.3.0 - 2018-09-06
     */
    public static final String SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS = "server.deserialization.disableDefaultExceptionHandlers";
    public static final String DEFAULT_SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS = "false";

    /**
     * Defines if, when a deserialization exception from JSON to object happens, the interception API should ignore
     * mapping exceptions and only handle field value exceptions.
     *
     * @since 7.3.2 - 2018-09-06
     */
    public static final String SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS = "server.deserialization.disableInterceptionOfMappingExceptions";
    public static final String DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS = "false";

    /**
     * Defines if, when a deserialization exception from JSON to object happens, the interception API should ignore
     * the exception and rethrow it.
     *
     * @since 7.3.2 - 2018-09-06
     */
    public static final String SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS = "server.deserialization.disableInterceptionOfAllExceptions";
    public static final String DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS = "false";

    /**
     * @see #SERVER_SERIALIZATION_VALUES_EMPTY
     */
    @Inject
    @ConfigProperty(name = SERVER_SERIALIZATION_VALUES_EMPTY, defaultValue = "true")
    private Boolean serverSerializationValuesEmpty;

    /**
     * @see #SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS
     * @see #DEFAULT_SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS
     */
    @Inject
    @ConfigProperty(
            name = SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS,
            defaultValue = DEFAULT_SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS
    )
    private Boolean serverDeserializatinDisableDefaultExceptionHandlers;

    /**
     * @see #SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS
     * @see #DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS
     */
    @Inject
    @ConfigProperty(
            name = SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS,
            defaultValue = DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS
    )
    private Boolean serverDeserializatinDisableInterceptionOfMappingExceptions;

    /**
     * @see #SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS
     * @see #DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS
     */
    @Inject
    @ConfigProperty(
            name = SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS,
            defaultValue = DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS
    )
    private Boolean serverDeserializatinDisableInterceptionOfAllExceptions;

    /**
     * @return  serialization setting.
     * @see     #SERVER_SERIALIZATION_VALUES_EMPTY
     */
    public Boolean isServerSerializationValuesEmpty() {
        return serverSerializationValuesEmpty;
    }

    /**
     * @author  Lucas Dillmann
     * @see     #SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS
     * @see     #DEFAULT_SERVER_DESERIALIZATION_DISABLE_DEFAULT_EXCEPTION_HANDLERS
     * @since   7.3.0 - 2018-09-06
     */
    public Boolean isServerDeserializatinDisableDefaultExceptionHandlers() {
        return serverDeserializatinDisableDefaultExceptionHandlers;
    }

    /**
     * @author  Lucas Dillmann
     * @see     #SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS
     * @see     #DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_ALL_EXCEPTIONS
     * @since   7.3.2 - 2018-09-14
     */
    public Boolean isServerDeserializatinDisableInterceptionOfAllExceptions() {
        return serverDeserializatinDisableInterceptionOfAllExceptions;
    }

    /**
     * @author  Lucas Dillmann
     * @see     #SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS
     * @see     #DEFAULT_SERVER_DESERIALIZATION_DISABLE_INTERCEPTION_OF_MAPPING_EXCEPTIONS
     * @since   7.3.2 - 2018-09-14
     */
    public Boolean isServerDeserializatinDisableInterceptionOfMappingExceptions() {
        return serverDeserializatinDisableInterceptionOfMappingExceptions;
    }
}
