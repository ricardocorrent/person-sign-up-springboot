package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.exceptions.base.MockitoException;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Class test targeting {@link BigDecimal} serialization with the custom classes
 * {@link BigDecimalSerializer} and {@link BigDecimalDeserializer}.
 *
 * @author  Rogerio Kiihl
 * @since   6.1.0 - 2018-06-22
 */
public class BigDecimalSerializationUnitTest {

    private static final BigDecimal SMALL_DECIMAL_VALUE = new BigDecimal(1.05);
    private static final BigDecimal HUGE_DECIMAL_VALUE = new BigDecimal(Double.MAX_VALUE);
    private static final String SMALL_DECIMAL_STRING_VALUE = "1.05";
    private static final String HUGE_DECIMAL_STRING_VALUE = "1.7976931348623157E+308";

    /**
     * Serializes the given {@code value} expecting the result to equals {@link BigDecimal#toString()}.
     *
     * @param value the big decimal generatedValue to be serialized
     * @return      the serialized generatedValue
     */
    private String assertSerialization(final BigDecimal value) {
        return assertSerialization(value, value.toString(), 1);
    }

    /**
     * Serializes the given {@code value} expecting the result to equals {@code expectedString} parameter
     *
     * @param value                 the big decimal generatedValue to be serialized
     * @param expectedString        the expected generatedValue from the serialization
     * @param writeTimesExpected    number of times the {@link JsonGenerator#writeString(String)} is executed
     * @return                      the serialized generatedValue
     */
    private String assertSerialization(final BigDecimal value, final String expectedString, final int writeTimesExpected) {

        final JsonGenerator generator = mock(JsonGenerator.class);
        final SerializerProvider provider = mock(SerializerProvider.class);
        final ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        try {

            final BigDecimalSerializer serializer = new BigDecimalSerializer();
            serializer.serialize(value, generator, provider);

            verify(generator, times(writeTimesExpected)).writeString(argumentCaptor.capture());
            assertEquals(expectedString, argumentCaptor.getValue());

        } catch (final MockitoException mockitoException) {
            // Mockito's no captured argument only acceptable if the given BigDecimal value is also null
            if (value == null) {
                return null;
            } else {
                throw mockitoException;
            }
        } catch (final Exception exception) {
            org.junit.Assert.fail("Failed to assertSerialization BigDecimal while no exceptions was expected");
        }

        return argumentCaptor.getValue();
    }

    /**
     * Deserializes the given {@code value} expecting the result to equals {@link BigDecimal#(String)}.
     *
     * @param value the string generatedValue to be deserialized
     * @return      the deserialized generatedValue
     */
    private BigDecimal assertDeserialization(final String value) {
        final BigDecimal expected = new BigDecimal(value);
        return assertDeserialization(value, expected);
    }

    /**
     * Deserializes the given {@code value} expecting the result to equals {@code expectedDecimal} parameter.
     *
     * @param value             the string generatedValue to be deserialized
     * @param expectedDecimal   the expected generatedValue from the serialization
     * @return                  the deserialized generatedValue
     */
    private BigDecimal assertDeserialization(final String value, final BigDecimal expectedDecimal) {

        final JsonParser jsonParser = mock(JsonParser.class);
        final DeserializationContext context = mock(DeserializationContext.class);
        final ObjectCodec objectCodec = mock(ObjectCodec.class);
        final JsonNode jsonNode = mock(JsonNode.class);

        BigDecimal deserializerValue = null;

        try {
            doReturn(objectCodec).when(jsonParser).getCodec();
            doReturn(jsonNode).when(objectCodec).readTree(any(JsonParser.class));
            doReturn(value).when(jsonNode).asText();

            final BigDecimalDeserializer deserializer = new BigDecimalDeserializer();
            deserializerValue = deserializer.deserialize(jsonParser, context);

            assertEquals(expectedDecimal, deserializerValue);
        } catch (final Exception exception) {
            org.junit.Assert.fail("Failed to assertSerialization BigDecimal while no exceptions was expected");
        }

        return deserializerValue;
    }

    /**
     * Creates a serialization roundtrip with the given {@code sourceDecimal}, starting with serialization:
     *
     * <ol>
     *   <li>Serializes {@code sourceDecimal}</li>
     *   <li>Deserializes step 1 result</li>
     *   <li>Asserts step 2 result expecting it to equals {@code sourceDecimal}</li>
     *</ol>
     *
     * @param sourceDecimal the big decimal generatedValue to be tested
     */
    private void assertRoundTrip(final BigDecimal sourceDecimal) {
        final String serializeValue = assertSerialization(sourceDecimal);
        assertDeserialization(serializeValue, sourceDecimal);
    }

    /**
     * Creates a serialization roundtrip with the given {@code sourceDecimal}, starting with deserialization:
     * <ol>
     *   <li>Deserializes {@code sourceString}</li>
     *   <li>Serializes step 1 result</li>
     *   <li>Asserts step 2 result expecting it to equals {@code sourceString}</li>
     * </ol>
     *
     * @param sourceString the string generatedValue to be tested
     */
    private void assertRoundTrip(final String sourceString) {
        final BigDecimal deserializerValue = assertDeserialization(sourceString);
        assertSerialization(deserializerValue, sourceString, 1);
    }

    /**
     * Test serialization of a small decimal value.
     */
    @Test
    public void serializeSmallValue() {
        assertSerialization(SMALL_DECIMAL_VALUE);
    }

    /**
     * Test serialization of a really big decimal value.
     */
    @Test
    public void serializeHugeValue() {
        assertSerialization(HUGE_DECIMAL_VALUE);
    }

    /**
     * Test serialization of a small negative decimal value.
     */
    @Test
    public void serializeNegativeSmallValue() {
        assertSerialization(SMALL_DECIMAL_VALUE.negate());
    }

    /**
     * Test serialization of a really big negative decimal value.
     */
    @Test
    public void serializeNegativeHugeValue() {
        assertSerialization(HUGE_DECIMAL_VALUE.negate());
    }

    /**
     * Tests serialization of a null {@link BigDecimal} expecting for a {@code null} result.
     */
    @Test
    public void serializeNullValue() {
        assertSerialization(null, null, 0);
    }

    /**
     * Test deserialization of a small decimal value.
     */
    @Test
    public void deserializeSmallValue() {
        assertDeserialization(SMALL_DECIMAL_STRING_VALUE);
    }

    /**
     * Test deserialization of a really big decimal value.
     */
    @Test
    public void deserializeHugeValue() {
        assertDeserialization(HUGE_DECIMAL_STRING_VALUE);
    }

    /**
     * Test deserialization of a small negative decimal value.
     */
    @Test
    public void deserializeNegativeSmallValue() {
        assertDeserialization("-" + SMALL_DECIMAL_STRING_VALUE);
    }

    /**
     * Test deserialization of a really big negative decimal value.
     */
    @Test
    public void deserializeNegativeHugeValue() {
        assertDeserialization("-" + HUGE_DECIMAL_STRING_VALUE);
    }

    /**
     * Tests a round trip serialization saga for small value starting at serialization.
     */
    @Test
    public void roundTripSmallValue() {
        assertRoundTrip(SMALL_DECIMAL_VALUE);
        assertRoundTrip(SMALL_DECIMAL_STRING_VALUE);
    }

    /**
     * Tests a round trip serialization saga for big value starting at serialization.
     */
    @Test
    public void roundTripHugeValue() {
        assertRoundTrip(HUGE_DECIMAL_VALUE);
        assertRoundTrip(HUGE_DECIMAL_STRING_VALUE);
    }

    /**
     * Tests a round trip serialization saga for small value starting at deserialization.
     */
    @Test
    public void roundTripNegativeSmallValue() {
        assertRoundTrip(HUGE_DECIMAL_VALUE.negate());
        assertRoundTrip("-" + HUGE_DECIMAL_STRING_VALUE);
    }

    /**
     * Tests a round trip serialization saga for big value starting at deserialization.
     */
    @Test
    public void roundTripNegativeHugeValue() {
        assertRoundTrip(HUGE_DECIMAL_VALUE.negate());
        assertRoundTrip("-" + HUGE_DECIMAL_STRING_VALUE);
    }
}
