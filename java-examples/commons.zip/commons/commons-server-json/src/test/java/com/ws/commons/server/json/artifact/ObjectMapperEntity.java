package com.ws.commons.server.json.artifact;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.server.json.OffsetDateTimeDeserializer;
import com.ws.commons.server.json.TemporalSerializer;

import java.time.OffsetDateTime;

/**
 * This class has no business value and is intended to be used just for tests.
 *
 * @author  Thyago Volpatto
 * @since   5.4.0 - 2017-12-21
 */
@SuppressWarnings("javadoc")
public class ObjectMapperEntity {

    private OffsetDateTime offsetDateTimeWithoutSerializer;

    @JsonSerialize(using = TemporalSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime offsetDateTimeWithSerializer;

    public OffsetDateTime getOffsetDateTimeWithoutSerializer() {
        return offsetDateTimeWithoutSerializer;
    }

    public void setOffsetDateTimeWithoutSerializer(OffsetDateTime offsetDateTimeWithoutSerializer) {
        this.offsetDateTimeWithoutSerializer = offsetDateTimeWithoutSerializer;
    }

    public OffsetDateTime getOffsetDateTimeWithSerializer() {
        return offsetDateTimeWithSerializer;
    }

    public void setOffsetDateTimeWithSerializer(OffsetDateTime offsetDateTimeWithSerializer) {
        this.offsetDateTimeWithSerializer = offsetDateTimeWithSerializer;
    }
}
