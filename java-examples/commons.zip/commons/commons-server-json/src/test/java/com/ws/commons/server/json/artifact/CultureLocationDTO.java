package com.ws.commons.server.json.artifact;

/**
 * This DTO class has no business value and is intended to be used just for tests.
 *
 * @author  Cristopher Zanchetta
 * @since   5.1.0 2017-10-16
 */
@SuppressWarnings("javadoc")
public class CultureLocationDTO {

    private String description;

    private String country;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
