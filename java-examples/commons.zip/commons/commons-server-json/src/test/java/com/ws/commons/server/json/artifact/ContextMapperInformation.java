package com.ws.commons.server.json.artifact;

/**
 * Class used in ObjectMapper tests with server integration, bringing information about
 * configuration found in context.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-20
 */
public class ContextMapperInformation {
    private boolean isContextFound;
    private boolean isRunningWithCommonsResolver;
    private boolean isRunningWithCustomResolver;

    public boolean isContextFound() {
        return isContextFound;
    }

    public void setContextFound(final boolean contextFound) {
        isContextFound = contextFound;
    }

    public boolean isRunningWithCommonsResolver() {
        return isRunningWithCommonsResolver;
    }

    public void setRunningWithCommonsResolver(final boolean runningWithCommonsResolver) {
        isRunningWithCommonsResolver = runningWithCommonsResolver;
    }

    public boolean isRunningWithCustomResolver() {
        return isRunningWithCustomResolver;
    }

    public void setRunningWithCustomResolver(final boolean runningWithCustomResolver) {
        isRunningWithCustomResolver = runningWithCustomResolver;
    }
}
