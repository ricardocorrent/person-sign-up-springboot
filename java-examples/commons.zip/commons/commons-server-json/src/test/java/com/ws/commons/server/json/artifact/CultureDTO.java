package com.ws.commons.server.json.artifact;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ws.commons.server.json.BigDecimalDeserializer;
import com.ws.commons.server.json.BigDecimalSerializer;

import java.math.BigDecimal;
import java.util.List;

/**
 * This DTO class has no business value and is intended to be used just for tests.
 *
 * @author  Cristopher Zanchetta
 * @author  Rogerio Kiihl
 * @since   2017-10-16 5.1.0
 * @version 6.1.0 - 2018-06-22 - Added {@link BigDecimal} fields for serializing testing purpose
 */
@SuppressWarnings("javadoc")
public class CultureDTO {

    private String description;

    private BigDecimal someDecimal;

    @JsonSerialize(using = BigDecimalSerializer.class)
    @JsonDeserialize(using = BigDecimalDeserializer.class)
    private BigDecimal someOtherDecimal;

    private List<CultureLocationDTO> cultureLocations;

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public List<CultureLocationDTO> getCultureLocations() {
        return cultureLocations;
    }

    public void setCultureLocations(List<CultureLocationDTO> cultureLocations) {
        this.cultureLocations = cultureLocations;
    }

    public BigDecimal getSomeOtherDecimal() {
        return someOtherDecimal;
    }

    public BigDecimal getSomeDecimal() {
        return someDecimal;
    }

    public void setSomeOtherDecimal(BigDecimal someOtherDecimal) {
        this.someOtherDecimal = someOtherDecimal;
    }

    public void setSomeDecimal(BigDecimal someDecimal) {
        this.someDecimal = someDecimal;
    }
}
