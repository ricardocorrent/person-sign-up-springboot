package com.ws.commons.server.json;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.server.json.artifact.ContextMapperInformation;
import com.ws.commons.server.json.artifact.ContextMapperResourceTest;
import com.ws.commons.server.json.artifact.CustomObjectMapperResolver;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.test.JerseyTest;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.MethodRule;
import org.junit.runner.RunWith;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;

import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ContextResolver;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static org.junit.Assert.*;

/**
 * Integration test for {@link ObjectMapperProducer} and {@link ObjectMapperResolver}
 * simulating server scenarios where Commons implementation can be used or some custom
 * resolver is set.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-20
 */
@RunWith(CdiTestRunner.class)
public class ObjectMapperFromContextIntegrationTest  extends JerseyTest {

    private final static String BASE_URI = "object-mapper-resource";
    private final static int RUN_WITH_COMMONS_RESOLVER = 1;
    private final static int RUN_WITH_CUSTOM_RESOLVER = 2;

    /**
     * Internal annotation used to decorated tests methods with information
     * about which configuration the test expects from the Jersey server.
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD})
    public @interface RunWithConfig {
        int runWith();
    }

    /**
     * Helper class implementing {@link MethodRule} that will be invoked before
     * every method of this class. It will extract the {@link RunWithConfig} annotation
     * of target method test and expose to Jersey server configuration how to set it.
     */
    public class ServerConfigurationRule implements MethodRule {

        @Override
        public Statement apply(Statement base, FrameworkMethod method, Object target) {

            final RunWithConfig expectedConfigAnnotation = method.getAnnotation(RunWithConfig.class);

            if (expectedConfigAnnotation == null) {
                throw new RuntimeException("Tests methods for this Class Test MUST use @RunWithConfig annotation");
            } else {
                expectedResolver = expectedConfigAnnotation.runWith();
            }

            return base;
        }
    }

    private int expectedResolver;

    @Rule
    public ServerConfigurationRule rule = new ServerConfigurationRule();

    /**
     * Mandatory Jersey server configuration method. Besides basic configuration - including
     * the exclusive use of {@link ContextMapperResourceTest} resource - the resolver for
     * an {@link ObjectMapper} will use a callback binder to respond.
     *
     * <p>Since this method is executed before our {@link ServerConfigurationRule}, it is not
     * able to set at once what resolver the tests expects, what makes mandatory using a callback
     * binder.</p>
     *
     * <p>For each tests in the class, the following calling order is used:</p>
     * <ul>
     *     <li>A new instance of this class created</li>
     *     <li>This configuration method is executed and sets a callback binder</li>
     *     <li>{@link ServerConfigurationRule} is executed. It extracts information about what resolver the method
     *     about to be executed expects and keeps in {@link #expectedResolver} integer value</li>
     *     <li>The target test method is invoked</li>
     *     <li>Test will demand an {@link ObjectMapper}</li>
     *     <li>Our binder callback configuration will check {@link #expectedResolver} value and, based on it,
     *     create Commons implementation ({@link #RUN_WITH_COMMONS_RESOLVER}) or a custom implementation ({@link #RUN_WITH_CUSTOM_RESOLVER})</li>
     * </ul>
     *
     * @return the Jersey Server configuration for next test
     */
    @Override
    public Application configure() {
        final ResourceConfig resourceConfig = new ResourceConfig(ContextMapperResourceTest.class);

        resourceConfig.property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, true);
        resourceConfig.property(ServerProperties.PROCESSING_RESPONSE_ERRORS_ENABLED, true);

        resourceConfig.register(new AbstractBinder() {
            @Override
            protected void configure() {
                if (expectedResolver == RUN_WITH_COMMONS_RESOLVER) {
                    bind(ObjectMapperResolver.class)
                            .to(ContextResolver.class);

                } else if (expectedResolver == RUN_WITH_CUSTOM_RESOLVER) {
                    bind(CustomObjectMapperResolver.class)
                            .to(ContextResolver.class);
                }
            }
        });

        return resourceConfig;
    }

    /**
     * Only makes sure a test decorated with {@link #RUN_WITH_COMMONS_RESOLVER} sets the expected
     * environment with Commons implementation.
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_COMMONS_RESOLVER)
    public void validateConfigWithCommonsResolver() {
        final Response response = target(BASE_URI).path("/check-config").request().get();
        final ContextMapperInformation entity = response.readEntity(ContextMapperInformation.class);

        assertNotNull("Failed to get any response entity", entity);
        assertTrue("No context injection done", entity.isContextFound());
        assertTrue("Should be using Commons resolver", entity.isRunningWithCommonsResolver());
        assertFalse("Should not using custom resolver", entity.isRunningWithCustomResolver());
    }

    /**
     * Only makes sure a test decorated with {@link #RUN_WITH_CUSTOM_RESOLVER} sets the expected
     * environment with test custom implementation.
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_CUSTOM_RESOLVER)
    public void validateConfigWithCustomResolver() {
        final Response response = target(BASE_URI).path("/check-config").request().get();
        final ContextMapperInformation entity = response.readEntity(ContextMapperInformation.class);

        assertNotNull("Failed to get any response entity", entity);
        assertTrue("No context injection done", entity.isContextFound());
        assertFalse("Should not using Commons resolver", entity.isRunningWithCommonsResolver());
        assertTrue("Should be using custom resolver", entity.isRunningWithCustomResolver());
    }

    /**
     * Running with a custom resolver, expects {@link ObjectMapperProducer} to produces the same instance
     * of {@link com.ws.commons.server.json.artifact.CustomObjectMapperResolver.CustomObjectMapper} found
     * in {@link CustomObjectMapperResolver}.
     *
     * <p>Asserts if the number of copies after resource invocation is one - and only ONE - greater than
     * before the invocation. That extra copy is expected because {@link ContextMapperResourceTest} has two injections:
     * The injection expecting the application instance - subject of this test - will not increase copies counting; but
     * the second injection - the one which needs a copy - will increase it.</p>
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_CUSTOM_RESOLVER)
    public void produceTemplateMapperInCustomEnvironment() {
        final Integer copiesCount = target(BASE_URI)
                .path("custom-mapper-count")
                .request()
                .get()
                .readEntity(Integer.class);

        final Integer copiesCountAfterProducing = target(BASE_URI)
                .path("produce-application-template-with-count")
                .request()
                .get()
                .readEntity(Integer.class);

        assertNotEquals((Integer)0, copiesCountAfterProducing);
        assertEquals(Integer.valueOf(copiesCount + 1), copiesCountAfterProducing);
    }

    /**
     * Running with a custom resolver, expects {@link ObjectMapperProducer} to produces a new instance
     * of {@link com.ws.commons.server.json.artifact.CustomObjectMapperResolver.CustomObjectMapper} created
     * by {@link CustomObjectMapperResolver}.
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_CUSTOM_RESOLVER)
    public void produceDefaultMapperInCustomEnvironment() {
        final Integer copiesCount = target(BASE_URI)
                .path("custom-mapper-count")
                .request()
                .get()
                .readEntity(Integer.class);

        final Integer copiesCountAfterProducing = target(BASE_URI)
                .path("produce-default-mapper-with-count")
                .request()
                .get()
                .readEntity(Integer.class);

        assertNotEquals((Integer)0, copiesCountAfterProducing);
        assertTrue(copiesCount < copiesCountAfterProducing);
    }

    /**
     * Running with commons implementation resolver, expects {@link ObjectMapperProducer} to produces the same instance
     * found in {@link ObjectMapperResolver#getInternalInstance()}.
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_COMMONS_RESOLVER)
    public void produceTemplateMapperInCommonsEnvironment() {

        final boolean assertSuccess = target(BASE_URI)
                .path("produce-application-template-with-assert")
                .request()
                .get()
                .readEntity(Boolean.class);

        assertTrue("Produced ObjectMapper must be the same instance of ObjectMapperResolver().getCommonsApplicationObjectMapper", assertSuccess);
    }

    /**
     * Running with commons implementation resolver, expects {@link ObjectMapperProducer} to produces a copied instance
     * from the one found in {@link ObjectMapperResolver#getInternalInstance()}.
     */
    @Test
    @RunWithConfig(runWith = RUN_WITH_COMMONS_RESOLVER)
    public void produceDefaultMapperInCommonsEnvironment() {
        final boolean assertSuccess = target(BASE_URI)
                .path("produce-default-mapper-with-assert")
                .request()
                .get()
                .readEntity(Boolean.class);

        assertTrue("Produced ObjectMapper must NOT be the same instance of ObjectMapperResolver().getCommonsApplicationObjectMapper", assertSuccess);
    }
}
