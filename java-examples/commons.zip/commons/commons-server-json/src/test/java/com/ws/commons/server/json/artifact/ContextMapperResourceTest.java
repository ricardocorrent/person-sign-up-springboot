package com.ws.commons.server.json.artifact;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.server.json.ApplicationObjectMapper;
import com.ws.commons.server.json.ContextProviderWrapper;
import com.ws.commons.server.json.ObjectMapperProducer;
import com.ws.commons.server.json.ObjectMapperResolver;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Resource test with only purpose of giving ObjectMapper integration tests with server
 * information about {@link ObjectMapperResolver} behavior.
 *
 * <p>No business logic is used or provided in this class.</p>
 *
 * @since 7.0.0 - 2018-07-20
 * @author Rogerio Kiihl
 */
@Path("/object-mapper-resource")
public class ContextMapperResourceTest {

    @Inject
    private ContextProviderWrapper contextProviderWrapper;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    @ApplicationObjectMapper
    private Instance<ObjectMapper> applicationObjectMapper;

    /**
     * Provides information about the configuration found in current context.
     *
     * @return a response with {@link ContextMapperInformation} bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/check-config")
    public Response checkConfig() {
        final ContextMapperInformation entity = new ContextMapperInformation();

        entity.setContextFound(contextProviderWrapper.isContextFound());

        if (contextProviderWrapper.isDefaultCommonResolverFound()) {
            entity.setRunningWithCommonsResolver(true);
        } else {
            entity.setRunningWithCustomResolver(true);
        }

        return Response.ok(entity).build();
    }

    /**
     * Provides counting for how many copies of {@link CustomObjectMapperResolver} were made.
     *
     * @return A response with an Integer bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/custom-mapper-count")
    public Response checkCustomMapperCount() {
        return Response.ok(CustomObjectMapperResolver.copiesCount).build();
    }

    /**
     * Uses the {@link ObjectMapperProducer} to produces an Application ObjectMapper
     * and provides back the counting for how many copies of {@link CustomObjectMapperResolver} were made.
     *
     * @return a response with an Integer bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/produce-application-template-with-count")
    public Response produceApplicationTemplateAndReturnsCount() {
        int result = 0;

        if (isApplicationObjectMapperSatisfied()) {
            result = CustomObjectMapperResolver.copiesCount;
        }

        return Response.ok(result).build();
    }

    /**
     * Uses the {@link ObjectMapperProducer} to produces a default ObjectMapper
     * and provides back the counting for how many copies of {@link CustomObjectMapperResolver}
     * were made.
     *
     * @return a response with an Integer bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/produce-default-mapper-with-count")
    public Response produceDefaultMapperAndReturnsCount() {
        int result = 0;

        if (isApplicationObjectMapperSatisfied()) {
            result = CustomObjectMapperResolver.copiesCount;
        }

        return Response.ok(result).build();
    }

    /**
     * Uses the {@link ObjectMapperProducer} to produces an Application {@link ObjectMapper}
     * and provides back {@code true} if the {@link ObjectMapper} produced is the same internal shared
     * instance from {@link ObjectMapperResolver} were made.
     *
     * @return a response with an Boolean bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/produce-application-template-with-assert")
    public Response produceApplicationTemplateAndAssertWithCommons() {
        boolean result = false;

        if (isApplicationObjectMapperSatisfied()) {
            result = applicationObjectMapper.get().equals(ObjectMapperResolver.getInternalInstance());
        }

        return Response.ok(result).build();
    }

    /**
     * Returns {@code true} if the injection was successful;
     *
     * @return a Boolean indicating if field was injected
     */
    private boolean isApplicationObjectMapperSatisfied() {
        return !applicationObjectMapper.isUnsatisfied();
    }

    /**
     * Uses the {@link ObjectMapperProducer} to produces a default {@link ObjectMapper}
     * and provides back {@code true} if the {@link ObjectMapper} produced is NOT the same internal
     * shared instance from {@link ObjectMapperResolver} were made.
     *
     * @return A response with an Boolean bound in it
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/produce-default-mapper-with-assert")
    public Response produceDefaultMapperAndAssertWithCommons() {
        return Response.ok(isNoAInternalObjectMapper()).build();
    }

    /**
     * Returns {@code true} if inject value to field {@link #objectMapper} does not equal
     * value from {@link ObjectMapperResolver#getInternalInstance()}.
     *
     * @return {@code true} if both questioned instances are not the same
     */
    private boolean isNoAInternalObjectMapper() {
        return !objectMapper.equals(ObjectMapperResolver.getInternalInstance());
    }
}