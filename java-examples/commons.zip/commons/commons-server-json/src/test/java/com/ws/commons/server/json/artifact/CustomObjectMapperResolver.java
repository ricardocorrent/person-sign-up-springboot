package com.ws.commons.server.json.artifact;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.ext.ContextResolver;

/**
 * A fake resolver for {@link ObjectMapper} used in integration tests with the
 * purpose of simulating scenario with a non-Commons resolver in action.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-20
 */
public class CustomObjectMapperResolver implements ContextResolver<ObjectMapper> {

    /**
     * Internal ObjectMapper to be produced by this fake resolver. The {@link ObjectMapper#copy()}
     * is overridden to always create a new copy and increase the copies counting.
     */
    public class CustomObjectMapper extends ObjectMapper {
        @Override
        public ObjectMapper copy() {
            copiesCount++;
            return new ObjectMapper();
        }
    }

    static int copiesCount = 1;

    /**
     * Context resolver method creating the internal and fake {@link ObjectMapper}.
     *
     * @param type  type of class to be considered in mapper filter. This value is ignored.
     * @return      an instance of {@link CustomObjectMapper} only useful for tests
     */
    @Override
    public ObjectMapper getContext(Class<?> type) {
        return new CustomObjectMapper();
    }
}
