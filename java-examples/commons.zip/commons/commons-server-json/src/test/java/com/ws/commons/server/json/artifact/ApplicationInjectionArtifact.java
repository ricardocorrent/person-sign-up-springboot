package com.ws.commons.server.json.artifact;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.commons.server.json.ApplicationObjectMapper;
import com.ws.commons.server.json.exception.ContextRequiredException;

import javax.inject.Inject;

/**
 * Artifact class without any purpose but be instantiated by CDI and fail trying to inject
 * {@link #applicationTemplateInjection} field with {@link ContextRequiredException} exception.
 *
 * @author  Rogerio Kiihl
 * @since   7.0.0 - 2018-07-24
 */
public class ApplicationInjectionArtifact {

    @Inject
    @ApplicationObjectMapper
    private ObjectMapper applicationTemplateInjection;
}
