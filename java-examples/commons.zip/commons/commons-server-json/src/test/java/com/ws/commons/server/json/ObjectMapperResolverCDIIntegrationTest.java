package com.ws.commons.server.json;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sollar.test.TestProjectStages.IncludeNonEmpty;
import com.sollar.test.TestProjectStages.IncludeNonNull;
import com.ws.commons.server.json.artifact.ApplicationInjectionArtifact;
import com.ws.commons.server.json.artifact.CultureDTO;
import com.ws.commons.server.json.artifact.CultureLocationDTO;
import com.ws.commons.server.json.artifact.ObjectMapperEntity;
import com.ws.commons.server.json.exception.ContextRequiredException;
import org.apache.deltaspike.testcontrol.api.TestControl;
import org.apache.deltaspike.testcontrol.api.junit.CdiTestRunner;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import javax.enterprise.inject.spi.CDI;
import javax.inject.Inject;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * {@link ObjectMapperResolver} integration tests using CDI as runner to provide a container instance for text execution.
 *
 * @author  Cristopher Zanchetta
 * @author  Rogerio Kiihl
 * @version 6.1.0 - 2018-06-21 - Added integration tests for {@link BigDecimal} serialization
 * @version 7.0.0 - 2018-07-16 - Tests concerning injections and building instances
 * @since   5.1.0 2017-10-11
 */
@RunWith(CdiTestRunner.class)
@SuppressWarnings("javadoc")
public class ObjectMapperResolverCDIIntegrationTest {

    @Inject
    private ObjectMapper defaultInjection;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private CultureDTO getCultureWithEmptyLocation() {
        CultureDTO cultureDTO = new CultureDTO();
        cultureDTO.setDescription("Some Culture");

        List<CultureLocationDTO> cultLocations = new ArrayList<>();
        cultureDTO.setCultureLocations(cultLocations);

        return cultureDTO;
    }

    /**
     * Simulates the parameter SERVER_SERIALIZATION_VALUES_EMPTY as {@code true}, so empty
     * array members should be considered during class serialization.
     * <p>Expected result: Serialized class {@link CultureDTO} will contain an empty {@link CultureLocationDTO} list</p>
     */
    @Test
    @TestControl(projectStage = IncludeNonNull.class)
    public void serializationIncludesEmptyArrayMembers() throws IOException {
        // TestControl changes initialization values. We must destroy previous static instance to create a new one
        // aware of those changes
        ObjectMapperResolver.resetApplicationObjectMapper();
        ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();

        String serializedCulture = mapper.writeValueAsString(getCultureWithEmptyLocation());
        Assert.assertNotNull(mapper.readValue(serializedCulture, CultureDTO.class).getCultureLocations());

        // Make sures other tests get default instance
        ObjectMapperResolver.resetApplicationObjectMapper();
    }

    /**
     * Simulates the parameter SERVER_SERIALIZATION_VALUES_EMPTY as {@code false}, so empty
     * array members should <b>not</b> be considered during class serialization.
     * <p>Expected result: Serialized class {@link CultureDTO} will not contain any empty list/array member at all.</p>
     */
    @Test
    @TestControl(projectStage = IncludeNonEmpty.class)
    public void serializationIgnoresEmptyArrayMembers() throws IOException {
        // TestControl changes initialization values. We must destroy previous static instance to create a new one
        // aware of those changes
        ObjectMapperResolver.resetApplicationObjectMapper();
        ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();

        String serializedCulture = mapper.writeValueAsString(getCultureWithEmptyLocation());
        Assert.assertNull(mapper.readValue(serializedCulture, CultureDTO.class).getCultureLocations());

        // Make sures other tests get default instance
        ObjectMapperResolver.resetApplicationObjectMapper();
    }

    /**
     * Tests ignoring the default properties of {@link ObjectMapperResolver} then
     * must thrown an exception when deserializing a date type.
     */
    @Test
    public void deserializeOffsetDateTimeWithoutDefaultAndCustomSerializer() throws IOException {
        thrown.expect(JsonMappingException.class);
        
        ObjectMapperEntity objectMapperEntity = new ObjectMapperEntity();
        objectMapperEntity.setOffsetDateTimeWithoutSerializer(OffsetDateTime.now());

        ObjectMapper mapper = ObjectMapperResolver.getInstance().ignoreCommonsDefault()
                .disable(MapperFeature.USE_GETTERS_AS_SETTERS).createMapper();
        String serializedEntity = mapper.writeValueAsString(objectMapperEntity);

        mapper.readValue(serializedEntity, ObjectMapperEntity.class);
    }

    /**
     * Expects to deserialize with default configuration and without error.
     */
    @Test
    public void deserializeOffsetDateTimeWithDefaultModules() throws IOException {
        ObjectMapperEntity objectMapperEntity = new ObjectMapperEntity();
        objectMapperEntity.setOffsetDateTimeWithoutSerializer(OffsetDateTime.now());

        ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();
        String serializedEnity = mapper.writeValueAsString(objectMapperEntity);

        ObjectMapperEntity deserializedEntity = mapper.readValue(serializedEnity, ObjectMapperEntity.class);
        assertNotNull(deserializedEntity);

    }

    /**
     * Expects to deserialize a property with annotated with {@link JsonSerialize}.
     */
    @Test
    public void deserializeOffsetDateTimeWithAnnotadedCustomSerializer() throws IOException {
        ObjectMapperEntity objectMapperEntity = new ObjectMapperEntity();
        objectMapperEntity.setOffsetDateTimeWithSerializer(OffsetDateTime.now());

        ObjectMapper mapper = ObjectMapperResolver.getInstance().ignoreCommonsDefault()
                .disable(MapperFeature.USE_GETTERS_AS_SETTERS).createMapper();
        String serializedEntity = mapper.writeValueAsString(objectMapperEntity);

        ObjectMapperEntity deserializedEntity = mapper.readValue(serializedEntity, ObjectMapperEntity.class);

        assertNotNull(deserializedEntity);
    }

    /**
     * Tests Jackson structure when serializing a {@link BigDecimal} NOT annotated
     * with {@link JsonSerialize}.
     *
     * Asserts the round trip {@link CultureDTO} regular serialized decimal and
     * asserts the generated Json expecting a number representation.
     */
    @Test
    public void serializeBigDecimalOnRegularBasis() throws IOException {
        final ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();
        final CultureDTO culture = new CultureDTO();

        culture.setSomeDecimal(new BigDecimal(new Random().nextDouble()));

        final String writtenString = mapper.writeValueAsString(culture);
        final CultureDTO readCulture = mapper.readValue(writtenString, CultureDTO.class);
        final JsonFactory jsonFactory = new JsonFactory();
        final JsonParser jsonParser = jsonFactory.createParser(writtenString);

        // Asserts the round trip result value
        assertEquals(culture.getSomeDecimal(), readCulture.getSomeDecimal());

        // Asserts the json content
        jsonParser.nextToken();

        assertEquals("someDecimal", jsonParser.nextFieldName());
        assertTrue(jsonParser.nextToken().isNumeric());
    }

    /**
     * Tests Jackson structure when serializing a {@link BigDecimal} annotated
     * with {@link JsonSerialize}.
     *
     * Asserts the round trip {@link CultureDTO} custom serialized decimal and
     * asserts the generated Json expecting a string representation.
     */
    @Test
    public void serializeBigDecimalWithCustomSerializer() throws IOException {
        final ObjectMapper mapper = ObjectMapperResolver.getInstance().createMapper();
        final CultureDTO culture = new CultureDTO();

        culture.setSomeOtherDecimal(new BigDecimal(new Random().nextDouble()));

        final String writtenString = mapper.writeValueAsString(culture);
        final CultureDTO readCulture = mapper.readValue(writtenString, CultureDTO.class);
        final JsonFactory jsonFactory = new JsonFactory();
        final JsonParser jsonParser = jsonFactory.createParser(writtenString);

        // Asserts the round trip result value
        assertEquals(culture.getSomeOtherDecimal(), readCulture.getSomeOtherDecimal());

        // Asserts the json content
        jsonParser.nextToken();

        assertEquals("someOtherDecimal", jsonParser.nextFieldName());
        assertFalse(jsonParser.nextToken().isNumeric());
    }

    /**
     * Makes sure two instances provided by {@link ObjectMapperResolver} will not
     * share their changes.
     */
    @Test
    public void createDifferentInstances() {
        final ObjectMapper mapper1 = ObjectMapperResolver
                .getInstance()
                .enable(MapperFeature.USE_GETTERS_AS_SETTERS)
                .createMapper();

        final ObjectMapper mapper2 = ObjectMapperResolver
                .getInstance()
                .disable(MapperFeature.USE_GETTERS_AS_SETTERS)
                .createMapper();

        assertNotEquals(mapper1, mapper2);
        assertTrue(mapper1.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
        assertFalse(mapper2.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
    }

    /**
     * Makes sure a non default instance does not have Template configuration.
     */
    @Test
    public void createNonDefaultInstance() {
        final ObjectMapper mapperDefault = ObjectMapperResolver
                .getInstance()
                .createMapper();

        final ObjectMapper mapperNonDefault = ObjectMapperResolver
                .getInstance()
                .ignoreCommonsDefault()
                .createMapper();

        assertNotEquals(mapperDefault, mapperNonDefault);
        assertFalse(mapperDefault.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
        assertTrue(mapperNonDefault.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
    }

    /**
     * Makes sure changes made in any instance provided from any {@link ObjectMapperResolver} method
     * (except for {@code .getApplicationObjectMapper()}) will not affect default instance.
     */
    @Test
    public void changeMapperConfigurationWithoutChangingApplicationTemplate() {
        final ObjectMapper mapper = ObjectMapperResolver
                .getInstance()
                .createMapper();

        mapper.enable(MapperFeature.USE_GETTERS_AS_SETTERS);
        mapper.enable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        mapper.disable(SerializationFeature.FAIL_ON_SELF_REFERENCES);

        final ObjectMapper template = ObjectMapperResolver
                .getInternalInstance();

        assertNotEquals(mapper, template);

        assertTrue(mapper.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
        assertTrue(mapper.isEnabled(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES));
        assertFalse(mapper.isEnabled(SerializationFeature.FAIL_ON_SELF_REFERENCES));

        assertFalse(template.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
        assertFalse(template.isEnabled(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES));
        assertTrue(template.isEnabled(SerializationFeature.FAIL_ON_SELF_REFERENCES));
    }

    /**
     * Changes the default template and after that, creates new default instances
     * expecting that new instance has those before made.
     */
    @Test
    public void createInstanceFromChangedApplicationTemplate() {
        // Makes sure we will find a default application template
        ObjectMapperResolver.resetApplicationObjectMapper();

        final ObjectMapper appTemplate = ObjectMapperResolver
            .getInternalInstance();

        appTemplate.enable(MapperFeature.USE_GETTERS_AS_SETTERS);
        appTemplate.enable(SerializationFeature.FAIL_ON_SELF_REFERENCES);
        appTemplate.enable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

        final ObjectMapper instance = ObjectMapperResolver
                .getInstance()
                .createMapper();

        assertNotNull(instance);
        assertTrue(instance.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
        assertTrue(instance.isEnabled(SerializationFeature.FAIL_ON_SELF_REFERENCES));
        assertTrue(instance.isEnabled(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES));

        // Make sures other tests get default instance
        ObjectMapperResolver.resetApplicationObjectMapper();
    }

    /**
     * Validates the injection of default mapper. The injected field is expected to be
     * a copy of default template with same configurations of it.
     */
    @Test
    public void validateDefaultInjection() {
        assertNotNull(defaultInjection);
        assertNotEquals(defaultInjection, ObjectMapperResolver.getInternalInstance());
        assertFalse(defaultInjection.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS));
    }

    /**
     * Expects for {@link ContextRequiredException} exception if injection of
     * the application object mapper (using the {@link ApplicationObjectMapper} qualifier)
     * fails looking for a context.
     */
    @Test(expected = ContextRequiredException.class)
    public void throwsExceptionWithApplicationObjectMapperInjectionWithoutContext() {
        CDI.current().select(ApplicationInjectionArtifact.class).get();
    }
}
