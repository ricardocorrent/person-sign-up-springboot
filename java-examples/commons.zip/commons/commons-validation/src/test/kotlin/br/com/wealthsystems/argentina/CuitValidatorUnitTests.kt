package br.com.wealthsystems.argentina

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test cases for [CuitAndCuilValidator]
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
class CuitValidatorUnitTests {

    @Test
    fun `should return 30-60069766-4 with mask as a valid CUIT value`() {
        // scenario
        val value = "30-60069766-4"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 30-60069766-4 without mask as a valid CUIT value`() {
        // scenario
        val value = "30600697664"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 30-60069766-5 with mask as an invalid CUIT value`() {
        // scenario
        val value = "30-60069766-5"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 30-60069766-5 without mask as an invalid CUIT value`() {
        // scenario
        val value = "30600697665"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 00-00000000-0 without mask as an invalid CUIT value`() {
        // scenario
        val value = "00000000000"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }
}