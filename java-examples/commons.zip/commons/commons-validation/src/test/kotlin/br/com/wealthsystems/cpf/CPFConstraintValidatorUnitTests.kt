package br.com.wealthsystems.cpf

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.runners.MockitoJUnitRunner
import javax.enterprise.util.AnnotationLiteral

/**
 * Test cases for [CPFConstraintValidator]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-15
 */
@RunWith(MockitoJUnitRunner::class)
class CPFConstraintValidatorUnitTests {

    @Mock
    private var annotationInstance: CPF? = null
    private val validator = CPFConstraintValidator()

    @Before
    fun setup() {
        validator.initialize(annotationInstance)
    }

    @Test
    fun `should validate 38253869029 without mask as a valid value`() {
        // scenario
        val input = "38253869029"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 38253869029 with mask as a valid value`() {
        // scenario
        val input = "382.538.690-29"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 40364164057 without mask as an invalid value`() {
        // scenario
        val input = "40364164057"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

    @Test
    fun `should validate 40364164057 with mask as an invalid value`() {
        // scenario
        val input = "403.641.640-57"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

}