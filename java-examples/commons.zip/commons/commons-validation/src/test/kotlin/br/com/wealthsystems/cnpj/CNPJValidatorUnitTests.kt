package br.com.wealthsystems.cnpj

import br.com.wealthsystems.cpf.CPFValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test cases for [CNPJValidator]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
class CNPJValidatorUnitTests {

    @Test
    fun `should return 69742234000100 with mask as a valid CNPJ value`() {
        // scenario
        val value = "69.742.234/0001-00"

        // execution
        val validationResult = CNPJValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 69742234000100 without mask as a valid CNPJ value`() {
        // scenario
        val value = "69742234000100"

        // execution
        val validationResult = CNPJValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 85736210003145 with mask as an invalid CNPJ value`() {
        // scenario
        val value = "85.736.210/0031-45"

        // execution
        val validationResult = CPFValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 85736210003145 without mask as an invalid CNPJ value`() {
        // scenario
        val value = "85736210003145"

        // execution
        val validationResult = CNPJValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }
}