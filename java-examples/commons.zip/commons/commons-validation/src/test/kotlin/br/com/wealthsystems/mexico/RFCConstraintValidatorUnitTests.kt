package br.com.wealthsystems.mexico

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.runners.MockitoJUnitRunner

/**
 * Test cases for [RFCConstraintValidator]
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
@RunWith(MockitoJUnitRunner::class)
class RFCConstraintValidatorUnitTests {

    @Mock
    private lateinit var annotationInstance: RFC
    private val validator = RFCConstraintValidator()

    @Before
    fun setup() {
        validator.initialize(annotationInstance)
    }

    @Test
    fun `should validate if MASP870810KT1 is valid value`() {
        // scenario
        val input = "MASP870810KT1"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate if MASP870810KT2 is invalid value`() {
        // scenario
        val input = "MASP870810KT2"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

}