package br.com.wealthsystems.cpf

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test cases for [CPFValidator]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
class CPFValidatorUnitTests {

    @Test
    fun `should return 30170296032 with mask as a valid CPF value`() {
        // scenario
        val value = "301.702.960-32"

        // execution
        val validationResult = CPFValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 30170296032 without mask as a valid CPF value`() {
        // scenario
        val value = "30170296032"

        // execution
        val validationResult = CPFValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 30183294080 with mask as an invalid CPF value`() {
        // scenario
        val value = "301.832.940-80"

        // execution
        val validationResult = CPFValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 30183294080 without mask as an invalid CPF value`() {
        // scenario
        val value = "30183294080"

        // execution
        val validationResult = CPFValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

}