package br.com.wealthsystems.argentina

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test cases for [CuitAndCuilValidator]
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
class CuilValidatorUnitTests {

    @Test
    fun `should return 20-04109098-8 with mask as a valid CUIL value`() {
        // scenario
        val value = "20-04109098-8"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 20-04109098-8 without mask as a valid CUIL value`() {
        // scenario
        val value = "20041090988"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return 20-04109095-5 with mask as an invalid CUIL value`() {
        // scenario
        val value = "20-04109095-5"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 20-04109000-0 without mask as an invalid CUIL value`() {
        // scenario
        val value = "20041090000"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return 00-00000000-0 without mask as an invalid CUIL value`() {
        // scenario
        val value = "00000000000"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }
}