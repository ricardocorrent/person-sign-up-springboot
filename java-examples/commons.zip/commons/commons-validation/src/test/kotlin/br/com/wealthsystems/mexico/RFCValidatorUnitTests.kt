package br.com.wealthsystems.cpf

import br.com.wealthsystems.mexico.RFCValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test cases for [RFCValidator]
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
class RFCValidatorUnitTests {

    @Test
    fun `should return if MASP870810KT1 is valid RFC value`() {
        // scenario
        val value = "MASP870810KT1"

        // execution
        val validationResult = RFCValidator.isValid(value)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return if IMS421231I45 is valid RFC value with generic true and moral true`() {
        // scenario
        val value = "IMS421231I45"

        // execution
        val validationResult = RFCValidator.isValid(value, true, true)

        // validation
        assertTrue(validationResult)
    }

    @Test
    fun `should return if MASP870810KT2 is invalid RFC value`() {
        // scenario
        val value = "MASP870810KT2"

        // execution
        val validationResult = RFCValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }

    @Test
    fun `should return if IMS421231I44 is invalid RFC value with generic true and moral true`() {
        // scenario
        val value = "IMS421231I44"

        // execution
        val validationResult = RFCValidator.isValid(value, true, true)

        // validation
        assertFalse(validationResult)
    }
}