package br.com.wealthsystems.inscricaoestadual

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized
import java.util.*

/**
 * Test cases for [BrazilStateRegisterValidator]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-15
 */
@RunWith(Parameterized::class)
class BrazilStateRegisterValidatorUnitTests(private val testPair: Pair<String, String>) {

    companion object {

        @JvmStatic
        @Parameterized.Parameters(name = "Validation test for {index}")
        fun testData() = arrayOf(
                "AC" to "0192263315485",
                "AL" to "248432192",
                "AP" to "037489372",
                "AM" to "508747040",
                "BA" to "41110841",
                "CE" to "683903306",
                "DF" to "0735158700195",
                "ES" to "482442280",
                "GO" to "156078724",
                "MA" to "120903725",
                "MT" to "65897466483",
                "MS" to "287526534",
                "MG" to "1136818480514",
                "PA" to "158465563",
                "PB" to "941640396",
                "PR" to "1755280166",
                "PE" to "136289509",
                "PI" to "711577269",
                "RJ" to "57672161",
                "RN" to "205693822",
                "RS" to "0437292550",
                "RO" to "51583890519695",
                "RR" to "247780571",
                "SP" to "101312016830",
                "SC" to "941679721",
                "SE" to "949869929",
                "TO" to "22031169067"
        )
    }

    @Test
    fun `should validate as a valid registration number`() {
        // scenario
        val registrationNumber = testPair.second
        val federationUnit = testPair.first

        // execution
        val validationResult = BrazilStateRegisterValidator.isValid(registrationNumber, federationUnit)

        // validation
        assertTrue("$registrationNumber isnt a valid value for $federationUnit", validationResult)
    }

    @Test
    fun `should validate as an invalid registration number`() {
        // scenario
        var modifiedLastNumber: Char
        do { modifiedLastNumber = Random().nextInt().toString().last() }
        while (modifiedLastNumber == testPair.second.last())

        val registrationNumber = "${testPair.second.substring(0, testPair.second.length - 1)}$modifiedLastNumber"
        val federationUnit = testPair.first

        // execution
        val validationResult = BrazilStateRegisterValidator.isValid(registrationNumber, federationUnit)

        // validation
        assertFalse("$registrationNumber isnt an invalid value for $federationUnit", validationResult)
    }

}