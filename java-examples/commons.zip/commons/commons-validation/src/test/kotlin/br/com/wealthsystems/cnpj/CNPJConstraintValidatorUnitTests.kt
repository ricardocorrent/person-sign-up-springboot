package br.com.wealthsystems.cnpj

import org.junit.Assert
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.runners.MockitoJUnitRunner
import javax.enterprise.util.AnnotationLiteral

/**
 * Test cases for [CNPJConstraintValidator]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-15
 */
@RunWith(MockitoJUnitRunner::class)
class CNPJConstraintValidatorUnitTests {

    @Mock
    private var annotationInstance: CNPJ? = null
    private val validator = CNPJConstraintValidator()

    @Before
    fun setup() {
        validator.initialize(annotationInstance)
    }

    @Test
    fun `should validate 63451557000169 without mask as a valid value`() {
        // scenario
        val input = "63451557000169"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 63451557000169 with mask as a valid value`() {
        // scenario
        val input = "63.451.557/0001-69"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 89900462000106 without mask as an invalid value`() {
        // scenario
        val input = "89900462000106"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

    @Test
    fun `should validate 89900462000106 with mask as an invalid value`() {
        // scenario
        val input = "89.900.462/0001-06"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

}