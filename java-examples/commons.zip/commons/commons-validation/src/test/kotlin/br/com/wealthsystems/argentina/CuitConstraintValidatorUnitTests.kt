package br.com.wealthsystems.argentina

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.runners.MockitoJUnitRunner

/**
 * Test cases for [CuitConstraintValidator]
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
@RunWith(MockitoJUnitRunner::class)
class CuitConstraintValidatorUnitTests {

    @Mock
    private lateinit var annotationInstance: CUIT
    private val validator = CuitConstraintValidator()

    @Before
    fun setup() {
        validator.initialize(annotationInstance)
    }

    @Test
    fun `should validate 20041090988 without mask as a valid value`() {
        // scenario
        val input = "20041090988"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 20-04109098-8 with mask as a valid value`() {
        // scenario
        val input = "20-04109098-8"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertTrue(result)
    }

    @Test
    fun `should validate 20041090955 without mask as an invalid value`() {
        // scenario
        val input = "20041090955"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

    @Test
    fun `should validate 20-04109095-5 with mask as an invalid value`() {
        // scenario
        val input = "20-04109095-5"

        // execution
        val result = validator.isValid(input, null)

        // validation
        assertFalse(result)
    }

    @Test
    fun `should validate 00-00000000-0 without mask as an invalid CUIT value`() {
        // scenario
        val value = "00000000000"

        // execution
        val validationResult = CuitAndCuilValidator.isValid(value)

        // validation
        assertFalse(validationResult)
    }
}