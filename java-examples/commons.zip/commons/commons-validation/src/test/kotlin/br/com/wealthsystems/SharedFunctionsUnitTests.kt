package br.com.wealthsystems

import org.hamcrest.Matchers.`is`
import org.junit.Assert.assertThat
import org.junit.Test

/**
 * Test cases for SharedFunctions
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-15
 */
class SharedFunctionsUnitTests {

    @Test
    fun `should return value without mask`() {
        // scenario
        val input = "1.2.3.4/9.6-58"
        val expectedValue = "12349658"

        // execution
        val actualValue = removeMask(input)

        // validation
        assertThat(actualValue, `is`(expectedValue))
    }

    @Test
    fun `should return value without mask using additional allowed chars`() {
        // scenario
        val input = "KE1.2.V3.4/9.6-58P"
        val expectedValue = "12V349658"
        val additionalAllowedChars = arrayOf('V')

        // execution
        val actualValue = removeMask(input, additionalAllowedChars)

        // validation
        assertThat(actualValue, `is`(expectedValue))
    }

}