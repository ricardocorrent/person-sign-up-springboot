package br.com.wealthsystems.inscricaoestadual

import br.com.wealthsystems.removeMask
import org.slf4j.LoggerFactory

/**
 * Class used to help calculate a valid value of State Register of Brazil
 *
 * @author peterson.schmitt
 * @since 7.2.0 - 2018-08-08
 * @author Lucas Dillmann
 * @version 7.5.0, 2019-01-14 - Enhancement of the implementation and separation of responsibilities
 */
object BrazilStateRegisterValidator {

    private val ISENT_OF_REGISTRATION = "ISENTO"
    private val REGISTRATION_P = 'P'

    /**
     * Validates if the given registration number is sintatically valid for the given federation unit
     *
     * @param registrationNumber Registration number
     * @param federationUnit Federation unit (abbreviated using 2 chars)
     * @return Result of the validation
     */
    @JvmStatic
    fun isValid(registrationNumber: String, federationUnit: String): Boolean {
        LoggerFactory.getLogger(BrazilStateRegisterValidator::class.java)
                .debug("Validating if '{}' is a valid state registry for federation unit '{}'", registrationNumber, federationUnit)

        if (registrationNumber.equals(ISENT_OF_REGISTRATION, ignoreCase = true)) return true
        if (federationUnit.length != 2) throw IllegalArgumentException("Federation Unit must be 2 chars long")

        val unmaskedRegistrationNumber = removeMask(registrationNumber.toUpperCase(), additionalAllowedChars = arrayOf(REGISTRATION_P))
        return getStateRegistrationValidator(federationUnit).isValid(unmaskedRegistrationNumber)
    }

}