package br.com.wealthsystems.cnpj

import javax.validation.Constraint
import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import kotlin.reflect.KClass

/**
 * Bean Validation constraint for CNPJ values
 *
 * Bean Validation extension constraint for CNPJ attributes, allowing simple validation of values. All validations
 * are forwarded to [CNPJValidator].
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
@Constraint(validatedBy = [CNPJConstraintValidator::class])
annotation class CNPJ (val allowEmpty: Boolean = false,
                       val message: String = "{br.com.wealthsystems.cnpj}",
                       val groups: Array<KClass<*>> = arrayOf())

/**
 * [ConstraintValidator] implementation for [CNPJ] annotations
 *
 * This class extends Bean Validation API providing [CNPJ] validations using annotation constraints. Validation
 * is done using [CNPJValidator].
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
internal class CNPJConstraintValidator: ConstraintValidator<CNPJ, String> {

    private var constraintAnnotation: CNPJ? = null

    /**
     * Implements the validation logic.
     * The state of `value` must not be altered.
     *
     *
     * This method can be accessed concurrently, thread-safety must be ensured
     * by the implementation.
     *
     * @param value object to validate
     * @param context context in which the constraint is evaluated
     *
     * @return `false` if `value` does not pass the constraint
     */
    override fun isValid(value: String?, context: ConstraintValidatorContext?): Boolean
            = value?.takeUnless { it.isBlank() }?.let { CNPJValidator.isValid(it) } ?: constraintAnnotation!!.allowEmpty

    /**
     * Initializes the validator in preparation for
     * [.isValid] calls.
     * The constraint annotation for a given constraint declaration
     * is passed.
     *
     *
     * This method is guaranteed to be called before any use of this instance for
     * validation.
     *
     * @param constraintAnnotation annotation instance for a given constraint declaration
     */
    override fun initialize(constraintAnnotation: CNPJ?) {
        this.constraintAnnotation = constraintAnnotation
    }
}