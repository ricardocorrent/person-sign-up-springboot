package br.com.wealthsystems.inscricaoestadual

/**
 * Factory method for [StateRegistrationValidator] implementation for any given state
 *
 * This method is able to produce [StateRegistrationValidator] instances compatible with the provided state abbreviation
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 * @throws IllegalStateException when supplied abbreviation isn't a valid abbreviation of a Brazil state name
 */
internal fun getStateRegistrationValidator(state: String) = when (state.toUpperCase()) {
    "AC" -> AcreValidator()
    "AL" -> AlagoasValidator()
    "AP" -> AmapaValidator()
    "AM" -> AmazonasValidator()
    "BA" -> BahiaValidator()
    "CE" -> CearaValidator()
    "ES" -> EspiritoSantoValidator()
    "GO" -> GoiasValidator()
    "MA" -> MaranhaoValidator()
    "MT" -> MatoGrossoValidator()
    "MS" -> MatoGrossoDoSulValidator()
    "MG" -> MinasGeraisValidator()
    "PA" -> ParaValidator()
    "PB" -> ParaibaValidator()
    "PR" -> ParanaValidator()
    "PE" -> PernambucoValidator()
    "PI" -> PiauiValidator()
    "RJ" -> RioDeJaneiroValidator()
    "RN" -> RioGrandeDoNorteValidator()
    "RS" -> RioGrandeDoSulValidator()
    "RO" -> RondoniaValidator()
    "RR" -> RoraimaValidator()
    "SC" -> SantaCatarinaValidator()
    "SP" -> SaoPauloValidator()
    "SE" -> SergipeValidator()
    "TO" -> TocantinsValidator()
    "DF" -> DistritoFederalValidator()
    else -> throw IllegalArgumentException("Unknown federation unit: $state")
}

/**
 * State registration validator interface
 *
 * This interface provides an unified validation mechanism across all Brazilian Federation Units
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
internal interface StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    fun isValid(registrationNumber: String): Boolean
}

/**
 * [StateRegistrationValidator] implementation for Acre
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class AcreValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 13) return false

        for (i in 0..1)
            if (registrationNumber[i].toString().toInt() != i) return false

        var sum = 0
        var initialweight = 4
        var finalweight = 9
        for (i in 0 until registrationNumber.length - 2) {
            sum += if (i < 3) registrationNumber[i].toString().toInt() * initialweight--
            else registrationNumber[i].toString().toInt() * finalweight--
        }
        val verificationDigit1 = (11 - sum % 11).takeUnless { it in 10..11 } ?: 0

        sum = verificationDigit1 * 2
        initialweight = 5
        finalweight = 9
        for (i in 0 until registrationNumber.length - 2)
            sum += if (i < 4) registrationNumber[i].toString().toInt() * initialweight--
            else registrationNumber[i].toString().toInt() * finalweight--
        val verificationDigit2 = (11 - sum % 11).takeUnless { it in 10..11 } ?: 0

        return registrationNumber.substring(registrationNumber.length - 2) == "$verificationDigit1$verificationDigit2"
    }
}

/**
 * [StateRegistrationValidator] implementation for Alagoas
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class AlagoasValidator : StateRegistrationValidator {

    private val expectedDigits = intArrayOf(0, 3, 5, 7, 8)

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "24") return false

        var containsExpectedDigit = expectedDigits.any { registrationNumber[2].toString().toInt() == it }
        if (!containsExpectedDigit) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val verificationDigit = ((sum * 10) % 11).takeIf { it != 10 } ?: 0
        return registrationNumber.last().toString() == verificationDigit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Amapá
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class AmapaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "03") return false

        var internalDigit = -1
        var sum = -1
        var weight = 9

        val x = registrationNumber.substring(0, registrationNumber.length - 1).toLong()
        when {
            x in 3017001..3019022 -> {
                internalDigit = 1
                sum = 9
            }
            x in 3000001..3017000 -> {
                internalDigit = 0
                sum = 5
            }
            x >= 3019023L -> {
                internalDigit = 0
                sum = 0
            }
        }

        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        var verificationDigit = (11 - sum % 11).takeIf { it != 10 } ?: 0
        if (verificationDigit == 11) verificationDigit = internalDigit

        return registrationNumber.last().toString() == verificationDigit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Amazonas
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class AmazonasValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1) {
            sum += registrationNumber[i].toString().toInt() * weight
            weight--
        }

        var verificationDigit = 11 - sum % 11
        if (sum < 11) {
            verificationDigit = 11 - sum
        } else if (sum % 11 <= 1) {
            verificationDigit = 0
        }

        return registrationNumber.substring(registrationNumber.length - 1) == verificationDigit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Bahia
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class BahiaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length !in 8..9) return false

        var modulus = 10
        val firstDigit = registrationNumber[if (registrationNumber.length == 8) 0 else 1].toString().toInt()
        if (firstDigit in arrayOf(6, 7, 9)) modulus = 11

        var sum = 0
        var weight = if (registrationNumber.length == 8) 7 else 8
        for (i in 0 until registrationNumber.length - 2)
            sum += registrationNumber[i].toString().toInt() * weight--

        var rest = sum % modulus
        var digit2 = (modulus - rest).takeUnless { rest == 0 || it == 10 } ?: 0

        sum = digit2 * 2
        weight = if (registrationNumber.length == 8) 8 else 9
        for (i in 0 until registrationNumber.length - 2)
            sum += registrationNumber[i].toString().toInt() * weight--

        rest = sum % modulus
        var digit1 = (modulus - rest).takeUnless { rest == 0 || it == 10 } ?: 0

        return registrationNumber.substring(registrationNumber.length - 2) == "$digit1$digit2"
    }
}

/**
 * [StateRegistrationValidator] implementation for Ceara
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class CearaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        var digit = (11 - sum % 11).takeIf { it !in 10..11 } ?: 0
        return registrationNumber.substring(registrationNumber.length - 1) == "$digit"
    }
}

/**
 * [StateRegistrationValidator] implementation for Espirito Santo
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class EspiritoSantoValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        var digit = -1
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val rest = sum % 11
        digit = when {
            rest < 2 -> 0
            rest > 1 -> 11 - rest
            else -> digit
        }

        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Goias
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class GoiasValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) !in arrayOf("10", "11", "15")) return false

        if (registrationNumber.substring(0, registrationNumber.length - 1) == "11094402")
            return registrationNumber.last() in arrayOf('0', '1')

        var sum = 0
        var weight = 9
        var digit = -1
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val rest = sum % 11
        val mainPart = registrationNumber.substring(0, registrationNumber.length - 1).toLong()

        when (rest) {
            0 -> digit = 0
            1 -> digit = if (mainPart in 10103105..10119997) 1 else 0
            !in arrayOf(0, 1) -> digit = 11 - rest
        }

        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Maranhão
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class MaranhaoValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "12") return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        var verificationDigit = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0
        return registrationNumber.last().toString() == verificationDigit.toString()
    }
}

/**
 * [StateValalidator] implementation for Mato Grosso
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class MatoGrossoValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 11) return false

        var sum = 0
        var initialWeight = 3
        var finalWeight = 9

        for (i in 0 until registrationNumber.length - 1) {
            sum += if (i < 2) registrationNumber[i].toString().toInt() * initialWeight--
            else registrationNumber[i].toString().toInt() * finalWeight--
        }

        var digit = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0

        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Mato Grosso do Sul
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class MatoGrossoDoSulValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "28") return false

        var sum = 0
        var weight = 9
        var digit = -1
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val rest = sum % 11
        val result = 11 - rest
        when {
            rest == 0 -> digit = 0
            rest > 0 && result > 9 -> digit = 0
            rest > 0 && result < 10 -> digit = result
        }

        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Minas Gerais
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class MinasGeraisValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 13) return false

        var firstDigitValidation = ""

        for (i in 0 until registrationNumber.length - 2)
            registrationNumber[i]
                    .takeIf { it.isDigit() }
                    ?.apply { firstDigitValidation += if (i == 3) "0" + registrationNumber[i] else registrationNumber[i] }

        var sum = 0
        var initialWeight = 1
        var finalWeight = 2
        for (i in 0 until firstDigitValidation.length) {
            sum += if (i % 2 == 0) {
                val element = (firstDigitValidation[i].toString().toInt() * initialWeight).toString()
                element.toCharArray().sumBy { it.toString().toInt() }
            } else {
                val element = (firstDigitValidation[i].toString().toInt() * finalWeight).toString()
                element.toCharArray().sumBy { it.toString().toInt() }
            }

        }

        var upperExactTen = (sum % 10).let { if (it > 0) sum + 10 else sum }.let { (it / 10) * 10 }
        var digit1 = upperExactTen - sum

        sum = digit1 * 2
        initialWeight = 3
        finalWeight = 11
        for (i in 0 until registrationNumber.length - 2) {
            sum += registrationNumber[i].toString().toInt() * if (i < 2) initialWeight-- else finalWeight--
        }

        val digit2 = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0
        return "$digit1$digit2" == registrationNumber.substring(registrationNumber.length - 2, registrationNumber.length)
    }
}

/**
 * [StateRegistrationValidator] implementation for Para
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class ParaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "15") return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Paraíba
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class ParaibaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - (sum % 11)).takeUnless { it in 10..11 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Paraná
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class ParanaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 10) return false

        var sum = 0
        var initialWeight = 3
        var finalWeight = 7
        for (i in 0 until registrationNumber.length - 2) {
            sum += if (i < 2) registrationNumber[i].toString().toInt() * initialWeight--
            else registrationNumber[i].toString().toInt() * finalWeight--
        }

        var digit1 = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0

        sum = digit1 * 2
        initialWeight = 4
        finalWeight = 7
        for (i in 0 until registrationNumber.length - 2) {
            sum += if (i < 3) registrationNumber[i].toString().toInt() * initialWeight--
            else registrationNumber[i].toString().toInt() * finalWeight--
        }

        var digit2 = (11 - sum % 11).takeUnless { sum % 11 in 0..1 } ?: 0
        return registrationNumber.substring(registrationNumber.length - 2, registrationNumber.length) == "$digit1$digit2"
    }
}

/**
 * [StateRegistrationValidator] implementation for Pernambuco
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class PernambucoValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        return when (registrationNumber.length) {
            9 -> validateNewFormat(registrationNumber)
            14 -> validateOldFormat(registrationNumber)
            else -> false
        }
    }

    /**
     * Validates if the registration number is a valid registration using new format with 9 chars long
     */
    private fun validateNewFormat(registrationNumber: String): Boolean {

        var sum = 0
        var weight = 8
        for (i in 0 until registrationNumber.length - 2) {
            sum += registrationNumber[i].toString().toInt() * weight--
        }
        var digit1 = (11 - (sum % 11)).takeUnless { sum % 11 in 1..0 }?.takeUnless { it > 9 } ?: 0

        sum = 0
        weight = 9
        for (i in 0 until registrationNumber.length - 1) {
            sum += registrationNumber[i].toString().toInt() * weight--
        }
        var digit2 = (11 - (sum % 11)).takeUnless { sum % 11 in 1..0 } ?: 0

        return registrationNumber.substring(registrationNumber.length - 2) == "$digit1$digit2"
    }

    /**
     * Validates if the registration number is a valid registration using old format with 14 chars long
     */
    private fun validateOldFormat(registrationNumber: String): Boolean {
        val number = mutableListOf<Long>()

        var sum1: Long = 0
        for (i in 0..6) {
            number[i] = (registrationNumber[i].toString().toInt() - 48).toLong()
            sum1 += number[i] * (8 - i)
        }
        (sum1 % 11).takeIf { it !in 0..1 }?.let { number[7] = 11 - it } ?: apply { number[7] = 0 }


        var sum2 = number[7] * 2
        for (i in 0..6) {
            sum2 += number[i] * (9 - i)
        }
        (sum2 % 11).takeIf { it !in 0..1 }?.let { number[8] = 11 - it } ?: apply { number[8] = 0 }

        return registrationNumber.substring(registrationNumber.length - 2, registrationNumber.length) == "${number[7]}${number[8]}"
    }
}

/**
 * [StateRegistrationValidator] implementation for Piaui
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class PiauiValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - (sum % 11)).takeIf { it !in 10..11 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Rio de Janeiro
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class RioDeJaneiroValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 8) return false

        var sum = registrationNumber[0].toString().toInt() * 2
        var weight = 7
        for (i in 1 until registrationNumber.length - 1) {
            sum += if (i == 0) registrationNumber[i].toString().toInt() * 2
            else registrationNumber[i].toString().toInt() * weight--
        }

        val digit = (11 - (sum % 11)).takeUnless { sum % 11 <= 1 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Rio Grande do Norte
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class RioGrandeDoNorteValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.substring(0, 2) != "20") return false

        return when (registrationNumber.length) {
            10 -> validateNewFormat(registrationNumber)
            9 -> validateOldFormat(registrationNumber)
            else -> false
        }
    }

    /**
     * Validates if the registration number is a valid registration using old format with 9 chars long
     */
    private fun validateOldFormat(registrationNumber: String): Boolean {
        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = ((sum * 10) % 11).takeIf { it != 10 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }

    /**
     * Validates if the registration number is a valid registration using new format with 10 chars long
     */
    private fun validateNewFormat(registrationNumber: String): Boolean {
        var sum = 0
        var weight = 10
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = ((sum * 10) % 11).takeIf { it != 10 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Rio Grande do Sul
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class RioGrandeDoSulValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 10) return false

        var sum = registrationNumber[0].toString().toInt() * 2
        var weight = 9
        for (i in 1 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - (sum % 11)).takeIf { it !in 10..11 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Rondonia
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class RondoniaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length !in arrayOf(14, 9)) return false

        val validationValue = if (registrationNumber.length == 9) registrationNumber.substring(3) else registrationNumber
        var sum = 0
        var initialWeight = 6
        var finalWeight = 9

        for (i in 0 until validationValue.length - 1) {
            sum += if (i < 5) validationValue[i].toString().toInt() * initialWeight--
            else validationValue[i].toString().toInt() * finalWeight--
        }

        val digit = (11 - (sum % 11)).let { if (it in 10..11) it - 10 else it }
        return validationValue.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Roraima
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class RoraimaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false
        if (registrationNumber.substring(0, 2) != "24") return false

        var sum = 0
        var weight = 1
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight++

        var digit = sum % 9
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Santa Catarina
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class SantaCatarinaValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - sum % 11).takeIf { sum % 11 !in 0..1 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for São Paulo
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class SaoPauloValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 12) return false

        var sum = 0
        var weight = intArrayOf(1, 3, 4, 5, 6, 7, 8, 10)

        for (i in 0 until registrationNumber.length - 4) {
            sum += registrationNumber[i].toString().toInt() * weight[i]
        }
        val digit1 = (sum % 11).toString().last()

        sum = 0
        var initialWeight = 3
        var finalWeight = 10
        for (i in 0 until registrationNumber.length - 1) {
            sum += registrationNumber[i].toString().toInt() * if (i < 2) initialWeight-- else finalWeight--
        }
        var digit2 = (sum % 11).toString().last()

        return registrationNumber[8] == digit1 && registrationNumber[11] == digit2
    }

}

/**
 * [StateRegistrationValidator] implementation for Sergipe
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class SergipeValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 9) return false

        var sum = 0
        var weight = 9
        for (i in 0 until registrationNumber.length - 1)
            sum += registrationNumber[i].toString().toInt() * weight--

        val digit = (11 - sum % 11).takeIf { it !in 10..11 } ?: 0
        return registrationNumber.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Tocantins
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class TocantinsValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length !in arrayOf(9, 11)) return false
        val validationValue = if (registrationNumber.length == 9) registrationNumber.substring(0, 2) + "02" + registrationNumber.substring(2)
        else registrationNumber

        var sum = 0
        var weight = 9
        for (i in 0 until validationValue.length - 1)
            i.takeIf { it !in 2..3 }?.apply { sum += validationValue[i].toString().toInt() * weight-- }

        val digit = (11 - (sum % 11)).takeUnless { sum % 11 < 2 } ?: 0
        return validationValue.last().toString() == digit.toString()
    }
}

/**
 * [StateRegistrationValidator] implementation for Distrito Federal
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
private class DistritoFederalValidator : StateRegistrationValidator {

    /**
     * Validates if the given registration number is a valid value
     *
     * @param registrationNumber Registration number to be validated
     * @return Result of the validation
     */
    override fun isValid(registrationNumber: String): Boolean {
        if (registrationNumber.length != 13) return false

        var sum = 0
        var initialWeight = 4
        var finalWeight = 9
        for (i in 0 until registrationNumber.length - 2) {
            sum += if (i < 3) registrationNumber[i].toString().toInt() * initialWeight--
            else registrationNumber[i].toString().toInt() * finalWeight--
        }
        val digit1 = (11 - (sum % 11)).takeUnless { it in 10..11 } ?: 0

        sum = digit1 * 2
        initialWeight = 5
        finalWeight = 9
        for (i in 0 until registrationNumber.length - 2) {
            sum += if (i < 4) registrationNumber[i].toString().toInt() * initialWeight--
            else registrationNumber[i].toString().toInt() * finalWeight--
        }
        val digit2 = (11 - (sum % 11)).takeUnless { it in 10..11 } ?: 0

        return registrationNumber.substring(registrationNumber.length - 2, registrationNumber.length) == "$digit1$digit2"
    }
}