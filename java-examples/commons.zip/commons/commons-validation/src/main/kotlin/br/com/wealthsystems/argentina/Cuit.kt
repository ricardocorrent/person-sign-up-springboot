package br.com.wealthsystems.argentina

import javax.validation.Constraint
import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import kotlin.reflect.KClass

/**
 * Bean Validation constraint for Cuit values
 *
 * Bean Validation extension constraint for Cuit attributes, allowing simple validation of values. All validations
 * are forwarded to [CuitAndCuilValidator].
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
@Constraint(validatedBy = [CuitConstraintValidator::class])
annotation class CUIT(val allowEmpty: Boolean = false,
                      val message: String = "{br.com.wealthsystems.cuit}",
                      val groups: Array<KClass<*>> = arrayOf())

/**
 * [ConstraintValidator] implementation for [CUIT] annotations
 *
 * This class extends Bean Validation API providing [CUIT] validations using annotation constraints. Validation
 * is done using [CuitAndCuilValidator].
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-134
 */
internal class CuitConstraintValidator : ConstraintValidator<CUIT, String> {

    private lateinit var constraintAnnotation: CUIT

    /**
     * Implements the validation logic.
     * The state of `value` must not be altered.
     *
     * This method can be accessed concurrently, thread-safety must be ensured
     * by the implementation.
     *
     * @param value object to validate
     * @param context context in which the constraint is evaluated
     *
     * @return `false` if `value` does not pass the constraint
     */
    override fun isValid(value: String?, context: ConstraintValidatorContext?): Boolean
            = value?.takeUnless { it.isBlank() }?.let { CuitAndCuilValidator.isValid(it) } ?: constraintAnnotation.allowEmpty

    /**
     * Initializes the validator in preparation for
     * [.isValid] calls.
     * The constraint annotation for a given constraint declaration
     * is passed.
     *
     * This method is guaranteed to be called before any use of this instance for
     * validation.
     *
     * @param constraintAnnotation annotation instance for a given constraint declaration
     */
    override fun initialize(constraintAnnotation: CUIT) {
        this.constraintAnnotation = constraintAnnotation
    }
}