package br.com.wealthsystems.cpf

import javax.validation.Constraint
import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import kotlin.reflect.KClass

/**
 * Bean Validation constraint for CPF values
 *
 * Bean Validation extension constraint for CPF attributes, allowing simple validation of values. All validations
 * are forwarded to [CPFValidator].
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
@Constraint(validatedBy = [CPFConstraintValidator::class])
annotation class CPF (val allowEmpty: Boolean = false,
                      val message: String = "{br.com.wealthsystems.cpf}",
                      val groups: Array<KClass<*>> = arrayOf())

/**
 * [ConstraintValidator] implementation for [CPF] annotations
 *
 * This class extends Bean Validation API providing [CPF] validations using annotation constraints. Validation
 * is done using [CPFValidator].
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-14
 */
internal class CPFConstraintValidator : ConstraintValidator<CPF, String> {

    private var constraintAnnotation: CPF? = null

    /**
     * Implements the validation logic.
     * The state of `value` must not be altered.
     *
     * This method can be accessed concurrently, thread-safety must be ensured
     * by the implementation.
     *
     * @param value object to validate
     * @param context context in which the constraint is evaluated
     *
     * @return `false` if `value` does not pass the constraint
     */
    override fun isValid(value: String?, context: ConstraintValidatorContext?): Boolean
            = value?.takeUnless { it.isBlank() }?.let { CPFValidator.isValid(it) } ?: constraintAnnotation!!.allowEmpty

    /**
     * Initializes the validator in preparation for
     * [.isValid] calls.
     * The constraint annotation for a given constraint declaration
     * is passed.
     *
     * This method is guaranteed to be called before any use of this instance for
     * validation.
     *
     * @param constraintAnnotation annotation instance for a given constraint declaration
     */
    override fun initialize(constraintAnnotation: CPF?) {
        this.constraintAnnotation = constraintAnnotation
    }
}