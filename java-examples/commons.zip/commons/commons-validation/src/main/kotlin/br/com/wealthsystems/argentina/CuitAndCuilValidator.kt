package br.com.wealthsystems.argentina

import br.com.wealthsystems.removeMask

/**
 * This class is used to perform validations of Cuit/Cuil from Argentina.
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
object CuitAndCuilValidator {

    /**
     * Calculates the digit for the input value
     *
     * @param value Input value to calculate the digit
     * @return Calculated digit value
     */
    private fun validate(input: String): Boolean {
        val weights = arrayOf(5, 4, 3, 2, 7, 6, 5, 4, 3, 2)
        val sum = (0..9).map { input[it].toString().toInt() * weights[it] }.sum()
        val digit = (11 - sum % 11).takeUnless { it == 11 } ?: 0
        return input[10].toString().toInt() == digit
    }

    /**
     * Check if is a valid Cuit/Cuil
     *
     * @param input to validate
     * @return True if is valid, false otherwise.
     */
    @JvmStatic
    fun isValid(input: String) =
            removeMask(input)
                    .takeUnless { it.length != 11 || it.matches("${it[0]}{11}".toRegex()) }
                    ?.let { validate(it) }
                    ?: false
}