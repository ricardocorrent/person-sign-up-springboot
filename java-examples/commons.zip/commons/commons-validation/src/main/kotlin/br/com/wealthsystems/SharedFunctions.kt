package br.com.wealthsystems

/**
 * Removes the mask if present from input. Return value will be only numbers and characters set in additional allowed
 * chars array variable.
 *
 * @param input Registration number to remove the mask
 * @param additionalAllowedChars Additional array of allowed characters. Values are case-sensitive.
 * @return Registration number without mask
 */
fun removeMask(input: String, additionalAllowedChars: Array<Char> = arrayOf())
        = input.filter { it.isDigit() || it in additionalAllowedChars }