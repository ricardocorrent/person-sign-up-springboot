package br.com.wealthsystems.mexico

import java.text.Normalizer

/**
 * This class is used to perform validations of RFC from Mexico.
 *
 * @author Peterson Schmitt
 * @since 7.8.0 - 2019-05-13
 */
object RFCValidator {

    private val REGEX_UNACCENT = "\\p{InCombiningDiacriticalMarks}+".toRegex()
    private val GENERIC_RFC = arrayOf("XAXX010101000", "XEXX010101000")
    private val BAD_WORDS  = arrayOf("BUEI","BUEY", "CACA", "CACO", "CAGA", "CAGO", "CAKA", "COGE", "COJA", "COJE", "COJI", "COJO", "CULO",
                "FETO", "GUEY", "JOTO", "KACA", "KACO", "KAGA", "KAGO", "KAKA", "KOGE", "KOJO", "KULO", "MAME", "MAMO",
                "MEAR", "MEON", "MION", "MOCO", "MULA", "PEDA", "PEDO", "PENE", "PUTA", "PUTO", "QULO", "RATA", "RUIN")
    private const val REGEX = "^([ A-ZÑ&]?[A-ZÑ&]{3}) ?(?:- ?)?(\\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\\d|3[01])) ?(?:- ?)?([A-Z\\d]{2})([A\\d])$"
    private const val DICTIONARY = "0123456789ABCDEFGHIJKLMN&OPQRSTUVWXYZ Ñ"

    /**
     * Check if is a valid RFC
     *
     * @param input to validate
     * @return True if is valid, false otherwise.
     */
    @JvmStatic
    fun isValid(input: String, generic: Boolean = true, moral: Boolean = false): Boolean {
        if(isGeneric(input)) return generic

        val matcher = REGEX.toPattern().matcher(input.toUpperCase()).takeIf { it.matches() } ?: return false
        val mainValue = with(matcher) { "${group(1)}${group(2)}${group(3)}" }
        val currentDigit = matcher.group(4)
        val interratorValue = if (moral) 10 else 11
        val sum = (0..interratorValue).map { DICTIONARY.indexOf(mainValue[it]) * (input.length - it) }.sum()
        val expectedDigit = (11 - getSum(sum, moral) % 11).toString().let {
            when (it) {
                "11" -> "0"
                "10" -> "A"
                else -> it
            }
        }

        return currentDigit == expectedDigit && checkBadWords(input)
    }

    /**
     * Sum 481 in value if it is of the moral type
     *
     * @param value to calculate
     * @param moral if persona moral
     * @return total sum
     */
    private fun getSum(value: Int, moral: Boolean) = if (moral) value.plus(481) else value

    /**
     * Check if it's the generic type
     *
     * @param input to validate
     * @return true if a generic type
     */
    private fun isGeneric(input: String) = GENERIC_RFC.contains(normalize(input))

    /**
     * Check if the key contains words that can not be used
     *
     * @param input to validate
     * @return true if you have a malicious word
     */
    private fun checkBadWords(input: String): Boolean {
        val value = normalize(input)
        val hasBadWord = BAD_WORDS.filter { word -> word == value.take(4) }
        return hasBadWord.isEmpty()
    }

    /**
     * Remove special characters
     *
     * @param input to validate
     * @return without special characte
     */
    private fun normalize(input: String): String {
        val value = Normalizer.normalize(input, Normalizer.Form.NFD)
        return REGEX_UNACCENT.replace(value, "")
                .toUpperCase()
                .replace("/[\u0300-\u036f]/g","")
    }
}
