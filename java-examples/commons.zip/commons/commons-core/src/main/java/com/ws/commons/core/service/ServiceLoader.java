package com.ws.commons.core.service;

import com.ws.commons.message.EDefaultMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * <p>
 * Simple ServiceLoader utility class to provide a simplified way of retrieving all implementations
 * available for a given interface or class using ServiceLoader pattern.
 * </p>
 *
 * <p>
 * Usage example:
 * </p>
 * <pre>
 *     ServiceLoader
 *          .forClass(AnyClass.class)
 *          .getImplementations()
 * </pre>
 * <p>
 * will build and look for any implementations of ´AnyClass´ using SPI strategies.\
 * </p>
 *
 * @author      Lucas Dillmann
 * @param <T>   generic target class type
 * @since       7.1.3 - 2018-08-17
 */
public class ServiceLoader<T> {

    private final Class<T> serviceClass;
    private final Logger logger;

    /**
     * Private constructor with target service class initialization.
     *
     * @param serviceClass target service class
     */
    private ServiceLoader(final Class<T> serviceClass) {
        this.serviceClass = serviceClass;
        this.logger = LoggerFactory.getLogger(getClass());
    }

    /**
     * Public ServiceLoader builder-like access method to begin the search for implementations classes, passing
     * the desired target class.
     *
     * @param serviceClass target service class
     * @param <T>          generic service class type
     * @return             a {@link ServiceLoader} instance for given class
     */
    public static <T> ServiceLoader<T> forClass(final Class<T> serviceClass) {
        Objects.requireNonNull(serviceClass, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("serviceClass"));
        return new ServiceLoader<>(serviceClass);
    }

    /**
     * Returns all available implementations of current target service class. This method never returns null.
     * If no implementations are found, an empty {@link Set} will be returned.
     *
     * @return a collection of found implementations for the desired class
     */
    public Set<T> getImplementations() {
        logger.debug("Looking for SPI available implementations for {}", serviceClass.getName());
        final java.util.ServiceLoader<T> serviceLoader = java.util.ServiceLoader.load(serviceClass);
        final Iterator<T> iterator = serviceLoader.iterator();

        final Set<T> implementations = StreamSupport
                .stream(Spliterators.spliteratorUnknownSize(iterator, Spliterator.ORDERED), false)
                .collect(Collectors.toSet());

        logger.debug("{} implementations found for {} using SPI", implementations.size(), serviceClass.getName());
        return implementations;
    }
}
