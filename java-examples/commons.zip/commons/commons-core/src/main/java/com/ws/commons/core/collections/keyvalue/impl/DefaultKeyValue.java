package com.ws.commons.core.collections.keyvalue.impl;

import com.ws.commons.core.collections.keyvalue.KeyValue;

/**
 * Default implementation for {@link KeyValue} with Java Bean style behaviour.
 *
 * @author      Lucas Dillmann
 * @param <K>   generic key type
 * @param <V>   generic value type
 * @see         KeyValue
 * @since       7.2.3 - 2018-08-28
 */
public class DefaultKeyValue<K, V> implements KeyValue<K, V> {

    private K key;
    private V value;

    /**
     * Default constructor.
     */
    public DefaultKeyValue() {
    }

    /**
     * Default constructor with {@code key} and {@code value} initialization.
     *
     * @param key   key object
     * @param value value object
     */
    public DefaultKeyValue(final K key, final V value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public K getKey() {
        return key;
    }

    @Override
    public void setKey(final K key) {
        this.key = key;
    }

    @Override
    public V getValue() {
        return value;
    }

    @Override
    public void setValue(final V value) {
        this.value = value;
    }

}
