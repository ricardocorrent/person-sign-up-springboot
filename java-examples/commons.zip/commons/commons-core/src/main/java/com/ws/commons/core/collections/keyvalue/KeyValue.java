package com.ws.commons.core.collections.keyvalue;

import com.ws.commons.core.collections.keyvalue.impl.DefaultKeyValue;
import com.ws.commons.core.collections.keyvalue.impl.UnmodifiableKeyValue;

/**
 * Key-value pair definition interface.
 *
 * <p>This interface defines a simple but key-value object for all commons scenarios where
 * is needed to send a pair of correlated objects in the application flow (like in a return statement).
 * Available methods follows Java Beans pattern.</p>
 *
 * <p>An instance of this interface can be obtained through the {@link KeyValueFactory} factory class or by
 * using the provided {@link DefaultKeyValue} and {@link UnmodifiableKeyValue} implementations.</p>
 *
 * @author      Lucas Dillmann
 * @param <K>   generic key type
 * @param <V>   generic value type
 * @since       7.2.3 - 2018-08-28
 */
public interface KeyValue<K, V> {

    K getKey();

    V getValue();

    void setKey(K key);

    void setValue(V value);

}
