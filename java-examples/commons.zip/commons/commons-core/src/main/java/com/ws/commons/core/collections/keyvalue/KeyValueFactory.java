package com.ws.commons.core.collections.keyvalue;

import com.ws.commons.core.collections.keyvalue.impl.DefaultKeyValue;
import com.ws.commons.core.collections.keyvalue.impl.UnmodifiableKeyValue;
import com.ws.commons.message.EDefaultMessage;

import java.util.Map;
import java.util.Objects;

/**
 * Factory class for {@link KeyValue}.
 *
 * <p>
 * This factory class provides access for common use-cases instances of a {@link KeyValue} object by using
 * the default implementations.
 * </p>
 *
 * <p>
 * For example, if you need to extract a {@link KeyValue} object that associates a field (key) with an object (value)
 * you should simply call statically
 * </p>
 * <pre>
 *     KeyValue{@literal <Field, Object>} value = KeyValueFactory.newInstance(field, object);
 * </pre>
 * <p>
 * or, if it may be unmodifiable
 * </p>
 * <pre>
 *     KeyValue{@literal <Field, Object>} value = KeyValueFactory.newUnmodifiableInstance(field, object);
 * </pre>
 *
 * @author  Lucas Dillmann
 * @see     KeyValue
 * @see     DefaultKeyValue
 * @see     UnmodifiableKeyValue
 * @since   7.2.3 - 2018-08-28
 */
public class KeyValueFactory {

    /**
     * Private constructor to avoid class instances.
     */
    private KeyValueFactory() {
    }

    /**
     * Creates a new {@link KeyValue} instance by using {@link Map.Entry} value.
     *
     * @param entry entry values to be used
     * @param <K>   generic key type
     * @param <V>   generic key value
     * @return      the created KeyValue instance
     */
    public static <K, V> KeyValue<K, V> newInstance(final Map.Entry<K, V> entry) {
        Objects.requireNonNull(entry, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entry"));
        return new DefaultKeyValue<>(entry.getKey(), entry.getValue());
    }

    /**
     * Creates a new {@link KeyValue} instance by using provided objects.
     *
     * @param key   key object to be used
     * @param value value object to be used
     * @param <K>   generic key type
     * @param <V>   generic key value
     * @return      the created KeyValue instance
     */
    public static <K, V> KeyValue<K, V> newInstance(final K key, final V value) {
        return new DefaultKeyValue<>(key, value);
    }

    /**
     * Creates a new unmodifiable {@link KeyValue} instance by using {@link Map.Entry} value.
     *
     * @param entry entry values to be used
     * @param <K>   generic key type
     * @param <V>   generic key value
     * @return      the created KeyValue instance
     */
    public static <K, V> KeyValue<K, V> newUnmodifiableInstance(final Map.Entry<K, V> entry) {
        Objects.requireNonNull(entry, EDefaultMessage.PARAMETER_CANNOT_BE_NULL.getMessage("entry"));
        return new UnmodifiableKeyValue<>(entry.getKey(), entry.getValue());
    }

    /**
     * Creates a new unmodifiable {@link KeyValue} instance by using provided objects.
     *
     * @param key   key object to be used
     * @param value value object to be used
     * @param <K>   generic key type
     * @param <V>   generic key value
     * @return      created KeyValue instance
     */
    public static <K, V> KeyValue<K, V> newUnmodifiableInstance(final K key, final V value) {
        return new UnmodifiableKeyValue<>(key, value);
    }
}
