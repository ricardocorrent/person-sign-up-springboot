package com.ws.commons.core.collections.keyvalue.impl;

import com.ws.commons.core.collections.keyvalue.KeyValue;

import java.text.MessageFormat;

/**
 * Unmodifiable implementation for {@link KeyValue}
 *
 * @author      Lucas Dillmann
 * @param <K>   generic key type
 * @param <V>   generic value type
 * @see         KeyValue
 * @since       7.2.3 - 2018-08-28
 */
public class UnmodifiableKeyValue<K, V> implements KeyValue<K, V> {

    private static final String UNSUPPORTED_EXCEPTION = "This KeyValue instance don't allow updates on {0} object";

    private final K key;
    private final V value;

    /**
     * Constructor with {@code key} and {@code value} initialization
     *
     * @param key   key object
     * @param value value object
     */
    public UnmodifiableKeyValue(final K key, final V value) {
        this.key = key;
        this.value = value;
    }

    /**
     * Getter for key object.
     *
     * @return the key object
     */
    @Override
    public K getKey() {
        return key;
    }

    /**
     * Getter for the value object.
     *
     * @return the value object
     */
    @Override
    public V getValue() {
        return value;
    }

    /**
     * Setter for the key object. As this class is unmodified, it throws {@link UnsupportedOperationException}.
     *
     * @param key the key to be set
     * @throws UnsupportedOperationException as this class is unmodifiable
     */
    @Override
    public void setKey(final K key) {
        throw new UnsupportedOperationException(MessageFormat.format(UNSUPPORTED_EXCEPTION, "key"));
    }

    /**
     * Setter for the value object. As this class is unmodified, it throws {@link UnsupportedOperationException}.
     *
     * @param value the key to be set
     * @throws UnsupportedOperationException as this class is unmodifiable
     */
    @Override
    public void setValue(final V value) {
        throw new UnsupportedOperationException(MessageFormat.format(UNSUPPORTED_EXCEPTION, "value"));
    }
}
