package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import org.eclipse.jetty.server.Handler
import org.eclipse.jetty.server.Server
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import org.junit.runner.RunWith
import org.mockito.Matchers.any
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.powermock.api.mockito.PowerMockito.doReturn
import org.powermock.api.mockito.PowerMockito.mock
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.junit4.PowerMockRunner

/**
 * Test cases for [JettyMetricsCollector]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
@RunWith(PowerMockRunner::class)
@PrepareForTest(Server::class)
class JettyMetricsCollectorUnitTests {

    @Rule
    @JvmField
    val expectedException: ExpectedException = ExpectedException.none()

    private val registry = mock(MetricRegistry::class.java)
    private val server = mock(Server::class.java)
    private val handler = mock(Handler::class.java)
    private var collector =  JettyMetricsCollector(server)

    @Before
    fun setup() {
        doReturn(arrayOf(handler)).`when`(server).handlers
    }

    @Test
    fun `should register metrics collector under Jetty`() {
        // execution
        collector.install(registry)

        // validation
        verify(server, times(1)).handler = any(Handler::class.java)
    }

}