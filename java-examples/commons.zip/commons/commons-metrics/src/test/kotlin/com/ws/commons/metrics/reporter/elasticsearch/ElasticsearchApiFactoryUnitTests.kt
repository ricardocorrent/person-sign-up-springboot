package com.ws.commons.metrics.reporter.elasticsearch

import com.ws.commons.metrics.ELASTICSEARCH_MAXIMUM_TCP_PORT
import com.ws.commons.metrics.ELASTICSEARCH_MINIMUM_TCP_PORT
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException

/**
 * Test cases for [ElasticsearchApiFactory]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class ElasticsearchApiFactoryUnitTests {

    @Rule
    @JvmField
    val expectedException: ExpectedException = ExpectedException.none()

    private val factory = ElasticsearchApiFactory()

    @Test
    fun `should produce Api instances`() {
        // scenario
        val host = "localhost"
        val port = 12345
        val prefix: String? = null
        val useSsl = false

        // execution
        val producedInstance: ElasticsearchApi? = factory.build(host, port, prefix, useSsl)

        // validation
        assertTrue(producedInstance is ElasticsearchApi)
    }

    @Test
    fun `should throw exception when an invalid TCP port lower than 1 is supplied`() {
        // scenario
        val host = "localhost"
        val port = ELASTICSEARCH_MINIMUM_TCP_PORT - 1
        val prefix: String? = null
        val useSsl = false

        expectedException.expect(IllegalArgumentException::class.java)
        expectedException.expectMessage("Port $port is not a valid TCP port. Valid values are from ${ELASTICSEARCH_MINIMUM_TCP_PORT} to ${ELASTICSEARCH_MAXIMUM_TCP_PORT}.")

        // execution
        factory.build(host, port, prefix, useSsl)
    }

    @Test
    fun `should throw exception when an invalid TCP port bigger than 65535 is supplied`() {
        // scenario
        val host = "localhost"
        val port = ELASTICSEARCH_MAXIMUM_TCP_PORT + 1
        val prefix: String? = null
        val useSsl = false

        expectedException.expect(IllegalArgumentException::class.java)
        expectedException.expectMessage("Port $port is not a valid TCP port. Valid values are from ${ELASTICSEARCH_MINIMUM_TCP_PORT} to ${ELASTICSEARCH_MAXIMUM_TCP_PORT}.")

        // execution
        factory.build(host, port, prefix, useSsl)
    }
}