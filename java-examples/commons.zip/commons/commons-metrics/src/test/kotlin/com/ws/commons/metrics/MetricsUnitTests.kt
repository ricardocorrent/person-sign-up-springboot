package com.ws.commons.metrics

import com.codahale.metrics.MetricRegistry
import com.ws.commons.metrics.collector.MetricsCollector
import com.ws.commons.metrics.reporter.MetricsReporter
import org.junit.After
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import org.mockito.Mockito.*
import java.util.*

/**
 * Test cases for [Metrics]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
class MetricsUnitTests {

    @Rule
    @JvmField
    val expectedException: ExpectedException = ExpectedException.none()

    private val collector = mock(MetricsCollector::class.java)
    private val registry = mock(MetricRegistry::class.java)
    private val reporter = mock(MetricsReporter::class.java)
    private val serviceName = Random().nextDouble().toString()

    @After
    fun teardown() = Metrics.instance.shutdown()

    @Test
    fun `should throw exception when starting collector without initializing Metrics`() {
        // scenario
        expectedException.expect(IllegalStateException::class.java)
        expectedException.expectMessage("Metrics API needs to be initialized before use")

        // execution
        Metrics.instance.startCollector(collector)
    }

    @Test
    fun `should call init on MetricsCollector when collector is started`() {
        // scenario
        Metrics.instance.initialize(serviceName, reporter, registry)

        // execution
        Metrics.instance.startCollector(collector)

        // validation
        verify(collector, times(1)).install(registry)
    }

}