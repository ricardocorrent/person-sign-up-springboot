package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import org.glassfish.jersey.server.ResourceConfig
import org.glassfish.jersey.server.monitoring.ApplicationEventListener
import org.junit.Test
import org.mockito.Mockito.*

/**
 * Test cases for [JerseyMetricsCollector]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
class JerseyMetricsCollectorUnitTests {

    private val resourceConfig = mock(ResourceConfig::class.java)
    private val registry = mock(MetricRegistry::class.java)
    private val collector =  JerseyMetricsCollector(resourceConfig)

    @Test
    fun `should register under Jersey the metrics collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(resourceConfig, times(1)).register(any(ApplicationEventListener::class.java))
    }
}