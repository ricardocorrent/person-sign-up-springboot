package com.ws.commons.metrics.reporter.elasticsearch

import com.codahale.metrics.MetricRegistry
import org.junit.After
import org.junit.Assert
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import org.mockito.Mockito
import java.util.*

class ElasticsearchMetricsReporterUnitTests {

    @Rule
    @JvmField
    val expectedException: ExpectedException = ExpectedException.none()

    private val reporter = ElasticsearchMetricsReporter(host = "localhost", port = 12345)
    private val registry = Mockito.mock(MetricRegistry::class.java)
    private val serviceName = Random().nextDouble().toString()

    @After
    fun teardown() {
        reporter.takeIf { it.isRunning() }?.apply { reporter.stop() }
    }

    @Test
    fun `should throw exception when not initialized but requested to start`() {
        // scenario
        expectedException.expect(IllegalStateException::class.java)
        expectedException.expectMessage("Reporter isn't initialized yet")

        // execution
        reporter.start()
    }

    @Test
    fun `should throw exception when not initialized but requested to stop`() {
        // scenario
        expectedException.expect(IllegalStateException::class.java)
        expectedException.expectMessage("Reporter isn't initialized yet")

        // execution
        reporter.stop()
    }

    @Test
    fun `should start after initialized`() {
        // execution
        reporter.init(registry, serviceName)
        reporter.start()

        // validation
        Assert.assertTrue(reporter.isRunning())
    }

}