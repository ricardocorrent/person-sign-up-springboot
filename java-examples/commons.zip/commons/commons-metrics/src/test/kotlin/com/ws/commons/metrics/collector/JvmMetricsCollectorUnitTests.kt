package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.jvm.*
import org.junit.Test
import org.mockito.Matchers.any
import org.mockito.Matchers.isA
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.powermock.api.mockito.PowerMockito.mock

/**
 * Test cases for [JvmMetricsCollector]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
class JvmMetricsCollectorUnitTests {

    private val registry = mock(MetricRegistry::class.java)
    private val collector = JvmMetricsCollector()

    @Test
    fun `should install JVM attributes collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(registry, times(1))
                .register(any(String::class.java), isA(JvmAttributeGaugeSet::class.java))
    }

    @Test
    fun `should install JVM memory stats collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(registry, times(1))
                .register(any(String::class.java), isA(MemoryUsageGaugeSet::class.java))
    }

    @Test
    fun `should install JVM Garbage Collector stats collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(registry, times(1))
                .register(any(String::class.java), isA(GarbageCollectorMetricSet::class.java))
    }

    @Test
    fun `should install JVM threads stats collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(registry, times(1))
                .register(any(String::class.java), isA(ThreadStatesGaugeSet::class.java))
    }

    @Test
    fun `should install JVM buffer pool collector`() {
        // execution
        collector.install(registry)

        // validation
        verify(registry, times(1))
                .register(any(String::class.java), isA(BufferPoolMetricSet::class.java))
    }
}