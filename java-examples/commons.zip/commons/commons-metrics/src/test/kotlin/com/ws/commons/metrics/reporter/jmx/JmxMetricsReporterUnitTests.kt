package com.ws.commons.metrics.reporter.jmx

import com.codahale.metrics.MetricRegistry
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import org.mockito.Mockito.mock
import java.util.*

/**
 * Test cases for [JmxMetricsReporter]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
class JmxMetricsReporterUnitTests {

    @Rule
    @JvmField
    val expectedException: ExpectedException = ExpectedException.none()

    private val reporter = JmxMetricsReporter()
    private val registry = mock(MetricRegistry::class.java)
    private val serviceName = Random().nextDouble().toString()

    @After
    fun teardown() {
        reporter.takeIf { it.isRunning() }?.apply { reporter.stop() }
    }

    @Test
    fun `should throw exception when not initialized but requested to start`() {
        // scenario
        expectedException.expect(IllegalStateException::class.java)
        expectedException.expectMessage("Reporter not initialized yet")

        // execution
        reporter.start()
    }

    @Test
    fun `should throw exception when not initialized but requested to stop`() {
        // scenario
        expectedException.expect(IllegalStateException::class.java)
        expectedException.expectMessage("Reporter not initialized yet")

        // execution
        reporter.stop()
    }

    @Test
    fun `should start after initialized`() {
        // execution
        reporter.init(registry, serviceName)
        reporter.start()

        // validation
        assertTrue(reporter.isRunning())
    }
}