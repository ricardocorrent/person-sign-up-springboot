package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.log4j2.InstrumentedAppender
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.core.LoggerContext
import org.apache.logging.log4j.core.config.Configuration
import org.apache.logging.log4j.core.config.LoggerConfig
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Matchers.any
import org.mockito.Matchers.isA
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.powermock.api.mockito.PowerMockito.*
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.junit4.PowerMockRunner

/**
 * Test cases for [Log4j2MetricsCollector]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
@RunWith(PowerMockRunner::class)
@PrepareForTest(LogManager::class)
class Log4j2MetricsCollectorUnitTests {

    private val registry = mock(MetricRegistry::class.java)
    private val collector = Log4j2MetricsCollector()
    private val loggerContext = mock(LoggerContext::class.java)
    private val configuration = mock(Configuration::class.java)
    private val loggerConfig = mock(LoggerConfig::class.java)

    @Before
    fun setup() {
        mockStatic(LogManager::class.java)
        doReturn(loggerContext).`when`(LogManager::class.java, "getContext")
        doReturn(configuration).`when`(loggerContext).configuration
        doReturn(loggerConfig).`when`(configuration).getLoggerConfig(any())
    }

    @Test
    fun `should install metrics collector appender under Log4j2`() {
        // execution
        collector.install(registry)

        // validation
        verify(loggerConfig, times(1))
                .addAppender(isA(InstrumentedAppender::class.java), any(), any())
    }

}