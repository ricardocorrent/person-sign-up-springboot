package com.ws.commons.metrics

/**
 * Constants for Metrics API
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-11
 */
const val JETTY_COLLECTOR_PREFIX = "jetty"
const val JVM_COLLECTOR_PREFIX = "jvm."
const val ELASTICSEARCH_DOCUMENT_TYPE = "_doc"
const val ELASTICSEARCH_INDEX_DATE_FORMAT = "yyyy-MM-dd"
const val ELASTICSEARCH_SERVICE_NAME_FIELD = "service_name"
const val ELASTICSEARCH_METRIC_TYPE_FIELD = "metric_type"
const val ELASTICSEARCH_METRIC_NAME_FIELD = "metric_name"
const val ELASTICSEARCH_METRIC_TIMESTAMP_FIELD = "@timestamp"
const val ELASTICSEARCH_MINIMUM_TCP_PORT = 1
const val ELASTICSEARCH_MAXIMUM_TCP_PORT = 65535