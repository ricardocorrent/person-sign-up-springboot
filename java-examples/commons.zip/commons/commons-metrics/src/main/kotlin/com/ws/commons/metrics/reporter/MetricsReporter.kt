package com.ws.commons.metrics.reporter

import com.codahale.metrics.MetricRegistry

/**
 * Metrics reporter interface
 *
 * This interface defines the API for metrics reporters. A reporter is an object that can collect metrics of a registry
 * and make them available to query or export them to another place.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
interface MetricsReporter {

    /**
     * Initializes the reporter
     *
     * This method will be called by the Metrics API when the reporter is about to begin it's work. Arguments
     * provide a context for the reporter, like the registry where he needs to listen on and the application name.
     *
     * @param registry Registry where the metrics values are available
     * @param serviceName Application nae
     */
    fun init(registry: MetricRegistry, serviceName: String)

    /**
     * Starts the reporting
     */
    fun start()

    /**
     * Stops the reporting
     */
    fun stop()

    /**
     * Checks if reporter is running
     *
     * @return Reporter state
     */
    fun isRunning(): Boolean

}
