package com.ws.commons.metrics.reporter.jmx

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.jmx.JmxReporter
import com.ws.commons.metrics.reporter.MetricsReporter
import org.slf4j.LoggerFactory
import java.util.concurrent.TimeUnit

/**
 * [MetricsReporter] implementation for Java JMX
 *
 * This class collects metrics values under [MetricRegistry] and make them available to query under Java JMX API
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class JmxMetricsReporter: MetricsReporter {

    private val logger = LoggerFactory.getLogger(javaClass)
    private var running = false
    private var reporter: JmxReporter? = null

    /**
     * Initializes the reporter
     *
     * This method will be called by the Metrics API when the reporter is about to begin it's work. Arguments
     * provide a context for the reporter, like the registry where he needs to listen on and the application name.
     *
     * @param registry Registry where the metrics values are available
     * @param serviceName Application nae
     */
    override fun init(registry: MetricRegistry, serviceName: String) {
        this.reporter = JmxReporter
                .forRegistry(registry)
                .inDomain(serviceName)
                .convertRatesTo(TimeUnit.SECONDS)
                .convertDurationsTo(TimeUnit.SECONDS)
                .build()
    }

    /**
     * Starts the reporting
     */
    override fun start() {
        logger.info("Starting JMX metrics reporter")
        reporter?.start() ?: throw IllegalStateException("Reporter not initialized yet")
        running = true
    }

    /**
     * Stops the reporting
     */
    override fun stop() {
        logger.info("Stopping JMX metrics reporter")
        reporter?.stop() ?: throw IllegalStateException("Reporter not initialized yet")
        running = false
    }

    /**
     * Checks if reporter is running
     *
     * @return Reporter state
     */
    override fun isRunning() = running

}
