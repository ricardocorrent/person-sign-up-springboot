package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry

/**
 * Metrics collector interface
 *
 * A metric collector is an object capable of collecting environment and runtime values that can be later on
 * used as indicator metrics. For example,
 */
@FunctionalInterface
interface MetricsCollector {

    /**
     * Installs the collector under provided [MetricRegistry] instance
     *
     * @param registry Registry to be installed on
     */
    fun install(registry: MetricRegistry)
}
