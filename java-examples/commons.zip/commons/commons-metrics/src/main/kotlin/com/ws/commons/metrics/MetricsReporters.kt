package com.ws.commons.metrics

import com.ws.commons.metrics.reporter.MetricsReporter
import com.ws.commons.metrics.reporter.elasticsearch.ElasticsearchMetricsReporter
import com.ws.commons.metrics.reporter.jmx.JmxMetricsReporter
import java.util.concurrent.TimeUnit

/**
 * Set of native [MetricsReporter] implementations
 *
 * This class provides an easy access to native implementations of [MetricsReporter], like JMX and Elasticsearch
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-10
 */
object MetricsReporters {

    /**
     * Produces a [ElasticsearchMetricsReporter] capable of exporting metrics to a Elasticsearch cluster
     *
     * @param host IP or DNS name of the elasticsearch cluster or host
     * @param port Port number of the elasticsearch cluster or host
     * @param index The index name template to be used (current date will be added at the end using - as separator).
     * Defaults to "metrics".
     * @param prefix The prefix to be used in Elasticsearch HTTP API URL. Usefull when a shared cluster is used and a
     * prefix is required to identify the tenant. Prefix value is optional, defautls to null, and will be used in
     * the API URL on REST calls to Elasticsearch.
     * @param intervalUnit Metrics are sent to Elasticsearch in scheduled intervals. This parameter defines the [TimeUnit]
     * of the intervals. Defaults to TimeUnit#SECONDS.
     * @param intervalCount Metrics are sent to Elasticsearch in scheduled intervals. This parameter defines the amount
     * of [TimeUnits] to be used. Defaults to 30.
     * @return Elasticsearch metrics reporter
     */
    @JvmOverloads
    @JvmStatic
    fun elasticsearch(
            host: String,
            port: Int,
            useSsl: Boolean = false,
            index: String = "metrics",
            prefix: String? = null,
            intervalUnit: TimeUnit = TimeUnit.SECONDS,
            intervalCount: Long = 30L
    ) = ElasticsearchMetricsReporter(host, port, useSsl, index, prefix, intervalUnit, intervalCount)

    /**
     * Produces a [JmxMetricsReporter] capable of exporting metrics to JMV JMX
     *
     * @return JMX metrics exporter
     */
    @JvmStatic
    fun jmx() = JmxMetricsReporter()

}