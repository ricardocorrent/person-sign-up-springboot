package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.MetricSet
import com.codahale.metrics.jvm.*
import com.ws.commons.metrics.JVM_COLLECTOR_PREFIX
import org.slf4j.LoggerFactory
import java.lang.management.ManagementFactory

/**
 * [MetricsCollector] implementation for JVM metrics
 *
 *
 * This implementation is able to collect and forward JVM related information, like heap size and usage,
 * garbage collector operations and more.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class JvmMetricsCollector: MetricsCollector {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Installs the collector under provided [MetricRegistry] instance
     *
     * @param registry Registry to be installed on
     */
    override fun install(registry: MetricRegistry) {
        logger.debug("Starting JVM metrics collector")

        register(registry, "attributes", JvmAttributeGaugeSet())
        register(registry, "memory", MemoryUsageGaugeSet())
        register(registry, "garbageCollector", GarbageCollectorMetricSet())
        register(registry, "threads", ThreadStatesGaugeSet())
        register(registry, "bufferPool", BufferPoolMetricSet(ManagementFactory.getPlatformMBeanServer()))
    }

    /**
     * Registers the provided [MetricSet] under [MetricRegistry] using provided name
     */
    private fun register(registry: MetricRegistry, name: String, metricSet: MetricSet) {
        logger.debug("Starting JVM $name collector using ${metricSet.javaClass.simpleName}")
        registry.register(JVM_COLLECTOR_PREFIX + name, metricSet)
    }

}
