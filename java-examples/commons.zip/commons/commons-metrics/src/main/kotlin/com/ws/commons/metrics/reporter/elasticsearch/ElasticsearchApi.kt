package com.ws.commons.metrics.reporter.elasticsearch

import feign.Headers
import feign.Param
import feign.RequestLine

/**
 * Elasticsearch interface definition for Feign generated clients
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
internal interface ElasticsearchApi {

    /**
     * Publishes a document under Elasticsearch API
     */
    @RequestLine("POST /{index}/{type}")
    @Headers("Content-type: application/json")
    fun publish(@Param("index") index: String, @Param("type") type: String, body: Any)

}