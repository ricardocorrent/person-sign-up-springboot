package com.ws.commons.metrics.reporter.elasticsearch

import com.codahale.metrics.MetricRegistry
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import com.ws.commons.metrics.*
import com.ws.commons.metrics.reporter.MetricsReporter
import org.slf4j.LoggerFactory
import java.text.SimpleDateFormat
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * [MetricsReporter] implementation for Elasticsearch
 *
 * This reporter is able to collect metrics from registry and export them to a Elasticsearch cluster,
 * allowing later analysis of the collected metrics.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class ElasticsearchMetricsReporter @JvmOverloads constructor(
        private val host: String,
        private val port: Int,
        private val useSsl: Boolean = false,
        private val index: String = "metrics",
        private val prefix: String? = null,
        private val intervalUnit: TimeUnit = TimeUnit.SECONDS,
        private val intervalCount: Long = 30L
): MetricsReporter {

    private var forwarder: Forwarder? = null
    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Initializes the reporter
     *
     * This method will be called by the Metrics API when the reporter is about to begin it's work. Arguments
     * provide a context for the reporter, like the registry where he needs to listen on and the application name.
     *
     * @param registry Registry where the metrics values are available
     * @param serviceName Application nae
     */
    override fun init(registry: MetricRegistry, serviceName: String) {
        val api = ElasticsearchApiFactory().build(host, port, prefix, useSsl)
        this.forwarder = Forwarder(api, registry, index, serviceName, intervalUnit, intervalCount)

        logger.info("Elasticsearch metrics reporter initialized. Metrics will be sent to host $host at port $port " +
                "using index $index at every $intervalCount $intervalUnit when started.")
    }

    /**
     * Starts the reporting
     */
    override fun start() = forwarder?.start() ?: throw IllegalStateException("Reporter isn't initialized yet")

    /**
     * Stops the reporting
     */
    override fun stop() = forwarder?.stop() ?: throw IllegalStateException("Reporter isn't initialized yet")

    /**
     * Checks if reporter is running
     *
     * @return Reporter state
     */
    override fun isRunning() = forwarder?.isStarted ?: false
}

/**
 * Elasticsearch scheduled forwarder
 *
 * This class collects metrics available on [MetricRegistry] and forwards to Elasticsearch cluster using its HTTP api
 * and JSON.
 *
 * The forward is executed at every X units of time as set by the user. If a forward fails this class will log the error
 * and continue, if a retry can be done it will be done automatically by Feing at his level and internal impl.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
private class Forwarder(private val api: ElasticsearchApi,
                        private val registry: MetricRegistry,
                        private val indexName: String,
                        private val serviceName: String,
                        private val intervalUnit: TimeUnit,
                        private val intervalCount: Long) {

    private val mapper = ObjectMapper()
    private val executor = Executors.newScheduledThreadPool(1)
    private var runningTask: ScheduledFuture<*>? = null

    val isStarted
        get() = runningTask != null

    private val indexNameWithCurrentDate
        get() = "$indexName-${SimpleDateFormat(ELASTICSEARCH_INDEX_DATE_FORMAT).format(Date())}"

    private val formattedCurrentTimestamp
        get() = DateTimeFormatter.ISO_ZONED_DATE_TIME.format(OffsetDateTime.now())

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Starts the scheduled forwarder
     */
    fun start() {
        logger.info("Starting Elasticsearch metrics reporter")
        runningTask?.apply { throw IllegalStateException("Forwarder is already running") }
        runningTask = executor.scheduleAtFixedRate({ forward() }, intervalCount, intervalCount, intervalUnit)
    }

    /**
     * Stops the scheduled forwarder
     */
    fun stop() {
        logger.info("Stopping Elasticsearch metrics reporter")
        runningTask?.cancel(true) ?: throw IllegalStateException("Forwarder can't be stopped since it isn't running")
        runningTask = null
    }

    /**
     * Executes the forward procedure, collecting current metrics available at registry and sending them to Elasticsearch
     */
    private fun forward() {
        logger.debug("Forwarding current metrics to Elasticsearch")

        with(registry) {
            gauges.entries.forEach { forwardDocument(it.key, "gauge", it.value) }
            counters.entries.forEach { forwardDocument(it.key, "counter", it.value) }
            histograms.entries.forEach { forwardDocument(it.key, "histogram", it.value) }
            meters.entries.forEach { forwardDocument(it.key, "meter", it.value) }
            timers.entries.forEach { forwardDocument(it.key, "timer", it.value) }
        }
    }

    /**
     * Forwards a single document to Elasticsearch using [ElasticsearchApi]
     */
    private fun forwardDocument(name: String, type: String, document: Any) {
        val node = mapper.valueToTree<ObjectNode>(document)
        with(node) {
            put(ELASTICSEARCH_SERVICE_NAME_FIELD, serviceName)
            put(ELASTICSEARCH_METRIC_TYPE_FIELD, type)
            put(ELASTICSEARCH_METRIC_NAME_FIELD, name)
            put(ELASTICSEARCH_METRIC_TIMESTAMP_FIELD, formattedCurrentTimestamp)
        }

        logger.debug("Publishing document to Elasticsearch: $node")

        try {
            api.publish(indexNameWithCurrentDate, ELASTICSEARCH_DOCUMENT_TYPE, node)
        } catch (ex: Exception) {
            logger.warn("Error forwarding document (metrics) to Elasticsearch", ex)
        }

    }

}
