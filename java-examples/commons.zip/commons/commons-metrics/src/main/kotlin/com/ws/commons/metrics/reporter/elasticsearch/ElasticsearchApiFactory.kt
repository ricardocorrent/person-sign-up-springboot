package com.ws.commons.metrics.reporter.elasticsearch

import com.ws.commons.metrics.ELASTICSEARCH_MAXIMUM_TCP_PORT
import com.ws.commons.metrics.ELASTICSEARCH_MINIMUM_TCP_PORT
import feign.Feign
import feign.jackson.JacksonDecoder
import feign.jackson.JacksonEncoder
import feign.okhttp.OkHttpClient
import org.slf4j.LoggerFactory

/**
 * [ElasticsearchApi] factory class
 *
 * This class produces dynamic, runtime proxies for [ElasticsearchApi] using Feign as backing executor.
 * Produced instances will act as a gateway to the Elasticsearch HTTP API.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
internal class ElasticsearchApiFactory {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Produces an instance of [ElasticsearchApi] using Feign
     *
     * @param host Hostname to be used
     * @param port Port where server is running
     * @param prefix Prefix of the path to be used on API calls
     * @return Produced ElasticsearchApi instance
     */
    fun build(host: String, port: Int, prefix: String?, useSsl: Boolean): ElasticsearchApi {

        logger.info("Starting production of Elasticsearch API gateway for metrics reporting")

        if (port < ELASTICSEARCH_MINIMUM_TCP_PORT || port > ELASTICSEARCH_MAXIMUM_TCP_PORT)
            throw IllegalArgumentException("Port $port is not a valid TCP port. Valid values are from $ELASTICSEARCH_MINIMUM_TCP_PORT to $ELASTICSEARCH_MAXIMUM_TCP_PORT.")

        val apiUrl = "${if (useSsl) "https" else "http"}://$host:$port${prefix ?: ""}"
        logger.info("Target Elasticsearch API URL is $apiUrl")

        return Feign
                .builder()
                .client(OkHttpClient())
                .encoder(JacksonEncoder())
                .decoder(JacksonDecoder())
                .target(ElasticsearchApi::class.java, apiUrl)
    }

}