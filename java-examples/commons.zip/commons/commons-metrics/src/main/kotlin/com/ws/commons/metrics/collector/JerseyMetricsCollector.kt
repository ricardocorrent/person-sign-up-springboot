package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.annotation.*
import com.codahale.metrics.jersey2.InstrumentedResourceMethodApplicationListener
import org.glassfish.jersey.server.ResourceConfig
import org.slf4j.LoggerFactory

/**
 * [MetricsCollector] implementation for Jersey JAX-RS
 *
 * This class installs under [Metrics] and Jersey the required objects to collect metrics from JAX-RS resources, but
 * it limitate himself to do only it. JAX-RS resources need to provide additional information about what should be metered.
 *
 * In another words, you need to use [Counted], [ExceptionMetered], [Gauge], [CachedGauge], [Metered], [Metric],
 * [ResponseMetered] and [Timed] annotations on JAX-RS resources alongside of this collector to collect metrics
 * from your API.
 *
 * Check Dropwizard Metrics for Jersey documentation for more details about what every annotation do (and what is meant
 * for) and others.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class JerseyMetricsCollector(private val resourceConfig: ResourceConfig): MetricsCollector {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Installs the collector under provided [MetricRegistry] instance
     *
     * @param registry Registry to be installed on
     */
    override fun install(registry: MetricRegistry) {
        logger.debug("Starting metrics collection from Jersey")

        val listener = InstrumentedResourceMethodApplicationListener(registry)
        resourceConfig.register(listener)
    }
}
