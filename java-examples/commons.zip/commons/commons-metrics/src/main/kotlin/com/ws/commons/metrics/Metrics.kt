package com.ws.commons.metrics

import com.codahale.metrics.MetricRegistry
import com.ws.commons.metrics.collector.MetricsCollector
import com.ws.commons.metrics.reporter.MetricsReporter
import org.slf4j.LoggerFactory

/**
 * Metrics control class
 *
 * This class controls the collection and reporting of application metrics and acts as a single access point for them.
 * You can use it to start [MetricsCollector]s and [MetricsReporter] at any point of the application.
 *
 * Please note that this object requires initialization. Call {@link #initilize(String, MetricsReporter, MetricRegistry)}
 * before starting any collector.
 *
 * Example of use:
 * <pre>
 *      Metrics
 *          .getInstance()
 *          .initialize("ExampleApplication", MetricsCollectors.jmx())
 *          .startCollector(MetricsCollectors.jvm())
 *          .startCollector(MetricsCollectors.log4j2())
 *          .startCollector(new MyCustomCollector())
 * </pre>
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class Metrics private constructor() {

    /**
     * Singleton companion for [Metrics]
     */
    companion object {
        @JvmStatic
        val instance = Metrics()
    }

    var registry: MetricRegistry? = null
    private set
    var reporter: MetricsReporter? = null
    private set

    private var serviceName: String? = null
    private var initialized = false
    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Initialized the Metrics API
     *
     * This method initializes the Metrics API with basic, required objects.
     *
     * @param serviceName Current application name
     * @param reporter Metrics reporter to be used
     * @param registry Registry to be used. Defaults to [MetricRegistry].
     */
    @Synchronized
    @JvmOverloads
    fun initialize(serviceName: String,
                   reporter: MetricsReporter,
                   registry: MetricRegistry = MetricRegistry()): Metrics {

        logger.info("Initializing Metrics for $serviceName using ${reporter.javaClass.simpleName} reporter")
        if (initialized) throw IllegalStateException("Metrics was already initialized")

        this.registry = registry
        this.reporter = reporter
        this.serviceName = serviceName

        with(reporter) {
            init(registry, serviceName)
            start()
        }

        this.initialized = true
        logger.debug("Metrics API initialized successfully")

        return this
    }

    /**
     * Starts a [MetricsCollector] under current Metrics context
     *
     * @param collector Collector to be started
     */
    fun startCollector(collector: MetricsCollector): Metrics {
        logger.info("Starting metrics collector ${collector.javaClass.simpleName}")

        checkInitialization()
        collector.install(registry!!)
        return this
    }

    /**
     * Shutdowns the Metrics API and stops the reporter
     *
     * This method stops the metrics reporter and shutdown Metrics API. If this method is called and Metrics API will
     * be later on used a new initialization will be required.
     */
    @Synchronized
    fun shutdown() {
        logger.info("Stopping Metrics API")

        reporter?.stop()
        reporter = null
        registry = null
        serviceName = null
        initialized = false
    }

    /**
     * Checks if Metrics is initialized. If not, throws [IllegalStateException].
     */
    private fun checkInitialization()
            = takeIf { !initialized }?.apply { throw IllegalStateException("Metrics API needs to be initialized before use") }

}
