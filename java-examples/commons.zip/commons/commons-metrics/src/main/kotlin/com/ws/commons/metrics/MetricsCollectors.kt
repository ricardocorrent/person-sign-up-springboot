package com.ws.commons.metrics

import com.ws.commons.metrics.collector.*
import org.eclipse.jetty.server.Server
import org.glassfish.jersey.server.ResourceConfig

/**
 * Set of native [MetricsCollector] implementations
 *
 * This class provides an easy access to native implementations of [MetricsCollector]
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
object MetricsCollectors {

    /**
     * Produces a [JvmMetricsCollector] capable of collecting metrics from JVM, like resources usage, heap, garbage
     * collector and more
     *
     * @return JMV metrics collector
     */
    @JvmStatic
    fun jvm() = JvmMetricsCollector()

    /**
     * Produces a [JettyMetricsCollector] capable of collecting metrics of the provided [Server] like requests
     * and responses counts, types of requests and responses and more
     *
     * @param server Jetty server instance to collect metrics from
     * @return Metrics collector for Jetty
     */
    @JvmStatic
    fun jetty(server: Server) = JettyMetricsCollector(server)

    /**
     * Produces a [JerseyMetricsCollector] capable of collecting metrics of the JAX-RS context, like resources, methods
     * and more
     *
     * @param resourceConfig Jetty resource config to collect metrics from
     * @return Metrics collector for Jersey
     */
    @JvmStatic
    fun jersey(resourceConfig: ResourceConfig) = JerseyMetricsCollector(resourceConfig)

    /**
     * Produces a [Log4j2MetricsCollector] capable of collecting metrics of the log events, like counts, active
     * loggers and more
     *
     * @return Metrics collector for Log4j
     */
    @JvmStatic
    fun log4j2() = Log4j2MetricsCollector()
}
