package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.log4j2.InstrumentedAppender
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.slf4j.LoggerFactory
import org.apache.logging.log4j.core.LoggerContext as CoreLoggerContext
import org.apache.logging.log4j.spi.LoggerContext as ApiLoggerContext

/**
 * [MetricsCollector] implementation for Log4J based logs
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class Log4j2MetricsCollector: MetricsCollector {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Installs the collector under provided [MetricRegistry] instance
     *
     * @param registry Registry to be installed on
     */
    override fun install(registry: MetricRegistry) {
        logger.debug("Starting Log4j metrics collector")

        val loggerContext = LogManager.getContext()
        if (loggerContext is CoreLoggerContext) {
            val appender = InstrumentedAppender(registry)
            with(loggerContext) {
                configuration
                        .getLoggerConfig(LogManager.ROOT_LOGGER_NAME)
                        .addAppender(appender, Level.ALL, null)
                updateLoggers(configuration)
            }

            logger.debug("Log4j2 metrics collector installed and configuration reloaded successfully")
        }
        else {
            throw RuntimeException(
                    "Current log context isn't supported. " +
                    "Expected type is ${CoreLoggerContext::class.java.name} but ${loggerContext.javaClass.name} was " +
                    "detected."
            )
        }
    }
}
