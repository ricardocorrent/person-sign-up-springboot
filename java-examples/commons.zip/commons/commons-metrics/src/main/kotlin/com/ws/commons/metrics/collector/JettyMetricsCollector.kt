package com.ws.commons.metrics.collector

import com.codahale.metrics.MetricRegistry
import com.codahale.metrics.jetty9.InstrumentedHandler
import com.ws.commons.metrics.JETTY_COLLECTOR_PREFIX
import org.eclipse.jetty.server.Handler
import org.eclipse.jetty.server.Server
import org.eclipse.jetty.server.handler.HandlerCollection
import org.slf4j.LoggerFactory

/**
 * [MetricsCollector] implementation for Jetty container
 *
 * This class collects metrics from Jetty container instances and publish them under Metrics API. Some values
 * collected are request counts, response types, request types and more.
 *
 * Please note that this implementation expects to be called before Jetty is started since a [Handler]
 * will be installed on it. If received [Server] is started an [IllegalStateException] will be thrown.
 *
 * @author Lucas Dillmann
 * @since 7.5.0, 2019-01-09
 */
class JettyMetricsCollector(private val server: Server): MetricsCollector {

    private val logger = LoggerFactory.getLogger(javaClass)

    /**
     * Installs the collector under provided [MetricRegistry] instance
     *
     * @param registry Registry to be installed on
     * @throws IllegalStateException When Jetty Server is running
     */
    override fun install(registry: MetricRegistry) {
        logger.debug("Starting metrics collection from Jetty")
        if (server.isStarted) throw IllegalStateException("Jetty server can't be running when starting metrics collection for it")

        server.handler = HandlerCollection(*server.handlers, InstrumentedHandler(registry, JETTY_COLLECTOR_PREFIX))
        logger.debug("Metrics collector for Jetty started successfully")
    }

}
